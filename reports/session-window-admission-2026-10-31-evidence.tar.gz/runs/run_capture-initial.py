import datetime, hashlib, json, os, pathlib, subprocess, sys
root=pathlib.Path("/private/tmp/tdf-session-window-admission-20261031T1810")
out=pathlib.Path(__file__).parent
name=sys.argv[1]; command=sys.argv[2:]
assert name.replace("-", "").isalnum() and command
node="/Users/macpro/.nvm/versions/node/v24.13.1/bin"
path=node+":/private/tmp/tdf-correctness-bin-20261028:/Users/macpro/.ghcup/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
env={"HOME":os.environ["HOME"],"PATH":path,"LANG":"en_US.UTF-8","LC_ALL":"en_US.UTF-8","PYTHONDONTWRITEBYTECODE":"1"}
if os.environ.get("TMPDIR"): env["TMPDIR"]=os.environ["TMPDIR"]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
log=out/(name+".log"); meta=out/(name+".json")
with log.open("xb") as f:
    result=subprocess.run(command,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
record={"command":command,"cwd":str(root),"environment":"minimal whitelist; no database/provider test overrides", "startedAt":started,"finishedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"exitCode":result.returncode,"logSha256":hashlib.sha256(log.read_bytes()).hexdigest(),"sourceHead":subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip()}
meta.write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record)); sys.exit(result.returncode)
