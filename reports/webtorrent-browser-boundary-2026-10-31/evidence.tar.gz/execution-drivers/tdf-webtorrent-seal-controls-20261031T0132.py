from pathlib import Path
import tempfile,shutil,json,subprocess,re,base64,hashlib
w=Path('/private/tmp/tdf-webtorrent-browser-only-20261031T0132');o=Path('/private/tmp/tdf-webtorrent-browser-only-qualification-20261031T0132');out=o/'seal-controls';out.mkdir(exist_ok=True);driver=Path('/private/tmp/tdf-webtorrent-seal-20261031T0132.py');code=driver.read_text();d=Path(tempfile.mkdtemp(prefix='tdf-browser-seal-controls-',dir='/private/tmp'))
files=['source-state.json','qualification-progress.json','initial-source6b/ui-quality-execution.json','initial-source6b/ui-quality.log','mutation-controls.json','browser-runtime-execution.json','browser-results.json','installed-lock-reconciliation.json','resolver-native-provenance.json','ui-tests.log','browser-vendor-unit.log','dist/webtorrent.min.js']
q=json.loads((o/'qualification-progress.json').read_text())
files += [key+'-execution.json' for key in q['actualExits']]
files += ['mutation-'+name+'.log' for name in ['unpin-inventory','ignore-affected-advisory','drop-notice-preservation','restore-query-only-jest-mapping']]
for name in files:
 (d/name).parent.mkdir(exist_ok=True,parents=True);shutil.copyfile(o/name,d/name)
shutil.copytree(o/'assurance-committed',d/'assurance-committed');controlDriver=d/'seal.py';controlDriver.write_text(code.replace(str(o),str(d)))
def run(label):
 r=subprocess.run(['python3',str(controlDriver)],cwd=w,capture_output=True,text=True,timeout=90);(out/(label+'.log')).write_text(r.stdout+r.stderr);return r
before=run('valid-before');assert before.returncode==0,before.stderr
cases=[]
def jc(label,name,edit):
 path=d/name;original=path.read_bytes();x=json.loads(original);edit(x);path.write_text(json.dumps(x));r=run(label);path.write_bytes(original);detected=r.returncode==1 and 'AssertionError' in r.stderr and not any(t in r.stderr for t in ['FileNotFoundError','ModuleNotFoundError','SyntaxError']);cases.append({'name':label,'target':name,'actualExit':r.returncode,'assertionRejected':detected});assert detected,(label,r.stderr)
def tc(label,name,edit):
 path=d/name;original=path.read_bytes();changed=edit(original.decode());assert changed.encode()!=original;path.write_text(changed);r=run(label);path.write_bytes(original);detected=r.returncode==1 and 'AssertionError' in r.stderr and not any(t in r.stderr for t in ['FileNotFoundError','ModuleNotFoundError','SyntaxError']);cases.append({'name':label,'target':name,'actualExit':r.returncode,'assertionRejected':detected});assert detected,(label,r.stderr)
jc('wrong-qualified-source','qualification-progress.json',lambda x:x.update(sourceCommit='0'*40))
jc('failed-ui-execution','ui-tests-execution.json',lambda x:x.update(actualExit=1))
jc('wrong-proof-source','assurance-committed/report.json',lambda x:x['provenance'].update(revision='0'*40))
jc('corrupt-registered-hash','assurance-committed/sources.json',lambda x:x['files'].update({next(iter(x['files'])):'0'*64}))
tc('reduced-ui-total','ui-tests.log',lambda s:s.replace('3761 passed, 3761 total','1 passed, 1 total'))
tc('skipped-ui-case','ui-tests.log',lambda s:s.replace('3761 passed, 3761 total','1 skipped, 3760 passed, 3761 total'))
tc('hidden-ui-failure','ui-tests.log',lambda s:s+'\nFAIL src/controlled-case.test.ts\n')
tc('skipped-vendor-case','browser-vendor-unit.log',lambda s:re.sub(r'(?m)^([#ℹ]\s+skipped\s+)0\s*$',r'\g<1>1',s))
jc('inconsistent-browser-stats','browser-results.json',lambda x:x['stats'].update(unexpected=1))
def corrupt_attachment(x):
 if isinstance(x,dict):
  if x.get('name')=='browser-component-lifecycle' and 'body' in x:
   v=json.loads(base64.b64decode(x['body']));v['destroyed']=False;x['body']=base64.b64encode(json.dumps(v).encode()).decode();return True
  return any(corrupt_attachment(v) for v in x.values())
 if isinstance(x,list):return any(corrupt_attachment(v) for v in x)
 return False
jc('failed-browser-cleanup','browser-results.json',lambda x:corrupt_attachment(x))
tc('false-semantic-control-pass','mutation-ignore-affected-advisory.log',lambda s:s.replace('# fail 1','# fail 0'))
jc('unverified-native-binding','resolver-native-provenance.json',lambda x:x.update(installedBinaryByteExactOfficial=False))
after=run('restored-valid-after');assert after.returncode==0,after.stderr
result={'sourceCommit':q['sourceCommit'],'sealDriverSha256':hashlib.sha256(code.encode()).hexdigest(),'validBeforeActualExit':before.returncode,'restoredValidAfterActualExit':after.returncode,'assertionRejectedCorruptions':len(cases),'cases':cases,'scope':'Finite controlled copies of actual qualification evidence; no original source/evidence mutation, no mathematical proof or complete corruption coverage. Deliberate faults must fail by AssertionError rather than missing tools/files.'};(o/'seal-binding-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='cases'}),flush=True);shutil.rmtree(d)
