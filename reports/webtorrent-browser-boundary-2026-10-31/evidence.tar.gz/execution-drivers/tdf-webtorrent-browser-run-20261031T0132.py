from pathlib import Path
import json,subprocess,os,datetime,signal
w=Path('/private/tmp/tdf-webtorrent-browser-only-20261031T0132');o=Path('/private/tmp/tdf-webtorrent-browser-only-qualification-20261031T0132');m=json.loads((o/'source-state.json').read_text())['sourceCommit'];r=json.loads((o/'ui-build-execution.json').read_text());assert r['sourceCommit']==m and r['actualExit']==0;assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip()==m and not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env.update(PATH='/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin',SKIP_UNRS_RESOLVER_FALLBACK='1')
cmd=['node','node_modules/@playwright/test/cli.js','test','--config='+str(o/'playwright.browser.config.mjs')];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (o/'browser-runtime.log').open('w') as log:
 p=subprocess.Popen(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=p.wait(timeout=300)
 except BaseException:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
  raise
report=json.loads((o/'browser-results.json').read_text());summary={'sourceCommit':m,'command':cmd,'actualExit':code,'stats':report['stats'],'startedAtUTC':start,'completedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Actual official built browser ESM import, WebRTC/native agreement, unchanged service-worker activation/createServer/destroy/unregister and public notices in Chromium+Firefox; no torrents/peers or universal network/reachability proof. WebKit not executed on this unsupported localhost.'};(o/'browser-runtime-execution.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True);assert code==0 and report['stats']['expected']==2 and report['stats']['unexpected']==report['stats']['skipped']==report['stats']['flaky']==0
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
