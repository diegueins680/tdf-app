from pathlib import Path
import json,subprocess,os,datetime
w=Path('/private/tmp/tdf-webtorrent-browser-only-20261031T0132');o=Path('/private/tmp/tdf-webtorrent-browser-only-qualification-20261031T0132');parent='0bda432f7339a86d0206e5f7abbb2763161c0c2a'
results=json.loads((o/'metadata-results.json').read_text())['actualExits'];assert len(results)==6 and all(v==0 for v in results.values());assert not (w/'node_modules').is_symlink();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip()=='6b85177c6076ce9b563088e86bff515aeb1bf210'
old=json.loads(subprocess.check_output(['git','show',parent+':formal/system/requirements.json'],cwd=w))['requirements'];cur=json.loads((w/'formal/system/requirements.json').read_text())['requirements'];by={x['id']:x for x in cur};assert len(old)==159 and len(cur)==160 and all(by[x['id']]==x for x in old)
subprocess.run(['git','diff','--check'],cwd=w,check=True)
subprocess.run(['git','add','docs/catalog-persistence/reports/static-list-inventory.json','docs/catalog-persistence/reports/list-consumer-matrix.csv','formal/system/inventory.json','formal/system/traceability.json'],cwd=w,check=True)
assert all(x[:2] not in ['??',' M','AM','MM'] for x in subprocess.check_output(['git','status','--porcelain'],cwd=w).decode().splitlines())
subprocess.run(['git','commit','-m','test: preserve normalized WebTorrent asset imports in Jest'],cwd=w,check=True)
m=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env.update(PATH='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1')
checks={}
for label,cmd in [('source-admission',['python3','scripts/check-new-specification-surfaces.py','--base',parent,'--head',m]),('source-ci-selection',['node','scripts/ci-change-scope.mjs','--base',parent,'--head',m])]:
 with (o/(label+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 checks[label]=r.returncode;assert r.returncode==0,label
state={'baselineMain':'234ff6f7faf1aecf347c8e92a374228f4ec07aaa','parent':parent,'sourceCommit':m,'all159ParentNormsExact':True,'requirements':160,'metadataActualExits':results,'committedChecks':checks,'sourceClean':True,'completedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/'source-state.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(state),flush=True)
