from pathlib import Path
import json,subprocess,os,datetime,signal
w=Path('/private/tmp/tdf-webtorrent-browser-only-20261031T0132');o=Path('/private/tmp/tdf-webtorrent-browser-only-qualification-20261031T0132');m=json.loads((o/'source-state.json').read_text())['sourceCommit'];q=json.loads((o/'qualification-progress.json').read_text());assert q['sourceCommit']==m and all(v==0 for v in q['actualExits'].values()) and 'root-quality' in q['actualExits'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip()==m and not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env.update(PATH='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/Users/macpro/.ghcup/bin:/usr/local/bin:/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1',SKIP_UNRS_RESOLVER_FALLBACK='1')
cmd=['python3','scripts/verification-report.py','--output',str(o/'assurance-committed')]
with (o/'assurance-driver.log').open('w') as log:
 p=subprocess.Popen(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=p.wait(timeout=1800)
 except BaseException:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
  raise
(o/'assurance-execution.json').write_text(json.dumps({'sourceCommit':m,'command':cmd,'actualExit':code,'completedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n');print('Assurance actualexit '+str(code),flush=True);assert code==0
