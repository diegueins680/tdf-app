from pathlib import Path
import base64,hashlib,json,tarfile,subprocess
r=Path('/private/tmp/tdf-webtorrent-browser-only-20261031T0132'); a=Path('/private/tmp/tdf-webtorrent-browser-only-qualification-20261031T0132')
x=json.loads((r/'third_party/webtorrent/bundled-provenance.json').read_text()); sm=json.loads((a/'dist/webtorrent.min.js.map').read_text()); sources=dict(zip(sm['sources'],sm['sourcesContent'])); checks=[]; mapped=set()
sha=lambda b:hashlib.sha256(b).hexdigest()
old=json.loads(subprocess.check_output(['git','-C',str(r),'show','0bda432f7339a86d0206e5f7abbb2763161c0c2a:package-lock.json']))
for p in x['packages']:
 paths=p['sourceMapPaths']; assert len(paths)==p['mappedSourceCount']; assert not mapped.intersection(paths);mapped.update(paths)
 actual_old=sorted({e['version'] for k,e in old['packages'].items() if k.endswith('node_modules/'+p['name']) and 'version' in e});assert actual_old==p['preRemovalAppLockVersionsNotBundleIdentity']
 for c in p['matchingPublishedCandidates']:
  d=a/'license-review/acquisitions'/(p['name'].replace('/','__')+'@'+c['version'])
  if not d.exists():
   ds=[q for q in (a/'license-review/acquisitions').iterdir() if q.is_dir() and json.loads((q/'metadata.json').read_text()).get('name')==p['name'] and json.loads((q/'metadata.json').read_text()).get('version')==c['version']];assert len(ds)==1;d=ds[0]
  meta=json.loads((d/'metadata.json').read_text());body=(d/'package.tgz').read_bytes(); alg,b64=c['integrity'].split('-',1)
  assert c['integrity']==meta['dist']['integrity'];assert base64.b64encode(hashlib.new(alg,body).digest()).decode()==b64;assert sha(body)==c['tarballSha256'];assert sha((d/'metadata.json').read_bytes())==c['metadataSha256']
  with tarfile.open(d/'package.tgz','r:gz') as tf:
   for source in paths:
    relative=source.rsplit('/node_modules/'+p['name']+'/',1)[1]; member=tf.getmember('package/'+relative);assert member.isfile(); raw=tf.extractfile(member).read();assert raw.replace(b'\r\n',b'\n')==sources[source].encode().replace(b'\r\n',b'\n')
   for f in c['licenseNoticeFiles']:
    raw=tf.extractfile(f['path']).read();assert sha(raw)==f['sha256'];assert raw.decode('utf8','replace')==f['text']
   for s in c['readmeLicenseStatements']:
    raw=tf.extractfile(s['path']).read();assert sha(raw)==s['fileSha256'];lines=raw.decode('utf8','replace').splitlines();start=s['startLine']-1;assert '\n'.join(lines[start:start+len(s['text'].split('\n'))])==s['text']
  checks.append({'name':p['name'],'candidateVersion':c['version'],'sources':len(paths),'archiveSRI':True,'sourceTextMatchAfterCRLF':True,'noticesMatchArchive':True})
 for h in p['embeddedAttributionHeaders']:assert h['text'] in sources[h['sourceMapPath']];assert sha(sources[h['sourceMapPath']].encode())==h['sourceContentSha256']
for v in x['additionalComponents']:
 assert not mapped.intersection(v['sourceMapPaths']);mapped.update(v['sourceMapPaths'])
assert mapped==set(sources) and len(mapped)==99
n=r/'tdf-hq-ui/public/third-party/webtorrent-NOTICES.txt';text=n.read_text();text=text.replace('CANDIDATE THIRD-PARTY NOTICES — source review artifact, not yet tracked distribution','WebTorrent browser artifact — third-party notices',1)
# Preserve README license declarations too; archive notices already fully included, allowing CRLF normalization.
for p in x['packages']:
 for c in p['matchingPublishedCandidates']:
  for s in c['readmeLicenseStatements']:
   value=s['text'].replace('\r\n','\n').strip()
   if value and value not in text:text+='\nPublished README license evidence for '+p['name']+' '+c['version']+' '+s['path']+':\n'+value+'\n'
n.write_text(text)
mfile=r/'third_party/webtorrent/browser.json';m=json.loads(mfile.read_text());m['notices']['sha256']=sha(n.read_bytes());mfile.write_text(json.dumps(m,indent=2)+'\n')
report={'scope':'ROOT independent reread of agent-authored inventory against SRI-verified published archives, official source map and original parent lock; no package code executed; not unique build version proof or legal certification.','packages':len(x['packages']),'matchingCandidateArchives':len(checks),'all99MappedSourcesPartitioned':True,'checks':checks,'noticesSha256':sha(n.read_bytes())};(a/'root-independent-license-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='checks'}))
