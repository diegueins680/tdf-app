from pathlib import Path
import os,subprocess,json,datetime,signal
w=Path('/private/tmp/tdf-webtorrent-browser-only-20261031T0132');o=Path('/private/tmp/tdf-webtorrent-browser-only-qualification-20261031T0132')
m=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip();assert m!='0bda432f7339a86d0206e5f7abbb2763161c0c2a';assert not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env.update(PATH='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1',SKIP_UNRS_RESOLVER_FALLBACK='1')
results={}
commands=[('browser-vendor-unit',['node','--test','scripts/__tests__/browser-vendor.test.mjs']),('browser-vendor-live',['node','scripts/check-browser-vendor.mjs','--audit']),('unchanged-production-audit',['./node_modules/.bin/audit-ci','--config','./audit-ci.jsonc']),('ui-tests',['npm','run','test','--workspace=tdf-hq-ui']),('ui-build',['npm','run','build','--workspace=tdf-hq-ui']),('root-quality',['bash','scripts/quality-repo.sh']),('inventory-check',['python3','scripts/specification-inventory.py','--check']),('conformance-check',['python3','scripts/specification-conformance.py','--check'])]
for label,cmd in commands:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip()==m
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (o/(label+'.log')).open('w') as log:
  p=subprocess.Popen(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=p.wait(timeout=1800)
  except BaseException:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   raise
 result={'command':cmd,'sourceCommit':m,'actualExit':code,'startedAtUTC':start,'finishedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/(label+'-execution.json')).write_text(json.dumps(result,indent=2)+'\n');results[label]=code;print(label+' actualexit '+str(code),flush=True)
 (o/'qualification-progress.json').write_text(json.dumps({'sourceCommit':m,'actualExits':results},indent=2)+'\n')
 if code:raise SystemExit(code)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
