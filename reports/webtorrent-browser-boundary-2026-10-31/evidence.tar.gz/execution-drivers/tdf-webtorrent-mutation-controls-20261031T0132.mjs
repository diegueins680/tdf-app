import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto'; import { spawnSync } from 'node:child_process';
const w='/private/tmp/tdf-webtorrent-browser-only-20261031T0132';const o='/private/tmp/tdf-webtorrent-browser-only-qualification-20261031T0132';
const checker='scripts/check-browser-vendor.mjs';const mapper='tdf-hq-ui/jest.config.cjs';const sha=value=>crypto.createHash('sha256').update(value).digest('hex');
const mutations=[
 ['unpin-inventory',checker,s=>s.replace("\n    || m.inventory.sha256 !== '82971c29f4d319e78318ff66b933ddbfdbf30bc8d8ba83739a804a488722bede'",'')],
 ['ignore-affected-advisory',checker,s=>s.replace('if (affected.length) throw','if (false) throw')],
 ['drop-notice-preservation',checker,s=>s.replace(/function requireNotice\(text\) \{[\s\S]*?\n  \}/, 'function requireNotice(text) { return; }')],
 ['restore-query-only-jest-mapping',mapper,s=>s.replace(String.raw`(?:\\?url)?$`,String.raw`\\?url$`)],
];
const records=[];
for(const [name,target,mutate] of mutations){
 const directory=fs.mkdtempSync('/private/tmp/tdf-webtorrent-control-');const source=fs.readFileSync(path.join(w,target),'utf8');const changed=mutate(source);if(changed===source)throw new Error('Mutation was not applied: '+name);
 const files=[checker,mapper,'scripts/__tests__/browser-vendor.test.mjs','third_party/webtorrent/browser.json','third_party/webtorrent/bundled-provenance.json','tdf-hq-ui/public/third-party/webtorrent-NOTICES.txt','tdf-hq-ui/src/vendor/webtorrent/webtorrent.min.js','tdf-hq-ui/src/utils/torrentAudio.ts','package-lock.json','audit-ci.jsonc'];
 for(const file of files){fs.mkdirSync(path.dirname(path.join(directory,file)),{recursive:true});fs.copyFileSync(path.join(w,file),path.join(directory,file));}
 fs.symlinkSync(path.join(w,'node_modules'),path.join(directory,'node_modules'));fs.symlinkSync(path.join(w,'tdf-hq-ui/node_modules'),path.join(directory,'tdf-hq-ui/node_modules'));
 const before=spawnSync(process.execPath,['--test','--test-reporter=tap','scripts/__tests__/browser-vendor.test.mjs'],{cwd:directory,encoding:'utf8',timeout:60000,env:{HOME:process.env.HOME,PATH:path.dirname(process.execPath)+':/usr/bin:/bin',SKIP_UNRS_RESOLVER_FALLBACK:'1'}});if(before.status!==0)throw new Error('Unmodified copied fixture failed: '+name);
 fs.writeFileSync(path.join(directory,target),changed);
 const result=spawnSync(process.execPath,['--test','--test-reporter=tap','scripts/__tests__/browser-vendor.test.mjs'],{cwd:directory,encoding:'utf8',timeout:60000,env:{HOME:process.env.HOME,PATH:path.dirname(process.execPath)+':/usr/bin:/bin',SKIP_UNRS_RESOLVER_FALLBACK:'1'}});
 fs.writeFileSync(path.join(o,'mutation-'+name+'.log'),(result.stdout||'')+(result.stderr||''));
 const rejected=result.status===1&&/not ok/.test(result.stdout)&&/ERR_ASSERTION/.test(result.stdout)&&!/SyntaxError|ERR_MODULE_NOT_FOUND|Cannot find module/.test(result.stdout+result.stderr);
 records.push({name,target,validBeforeActualExit:before.status,actualExit:result.status,detectedByAssertions:rejected,mutatedSha256:sha(changed)});if(!rejected)throw new Error('Control did not fail by assertions: '+name);
 fs.rmSync(directory,{recursive:true,force:true});
}
fs.writeFileSync(path.join(o,'mutation-controls.json'),JSON.stringify({scope:'Controlled independent copies of the actual checker/config and tests, each altered once; not mutation completeness or formal proof.',sourceCheckerSha256:sha(fs.readFileSync(path.join(w,checker))),sourceMapperSha256:sha(fs.readFileSync(path.join(w,mapper))),sourceTestsSha256:sha(fs.readFileSync(path.join(w,'scripts/__tests__/browser-vendor.test.mjs'))),records},null,2)+'\n');console.log(JSON.stringify(records));
