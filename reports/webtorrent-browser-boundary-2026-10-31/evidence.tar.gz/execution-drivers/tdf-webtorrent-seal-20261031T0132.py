from pathlib import Path
import json,subprocess,hashlib,re,datetime
w=Path('/private/tmp/tdf-webtorrent-browser-only-20261031T0132');o=Path('/private/tmp/tdf-webtorrent-browser-only-qualification-20261031T0132');sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args,cwd=w):return subprocess.check_output(['git',*args],cwd=cwd)
p=json.loads((o/'source-state.json').read_text());m=p['sourceCommit'];parent=p['parent'];assert git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip()
q=json.loads((o/'qualification-progress.json').read_text());expected={'browser-vendor-unit','browser-vendor-live','unchanged-production-audit','ui-tests','ui-build','root-quality','inventory-check','conformance-check'};assert q['sourceCommit']==m and set(q['actualExits'])==expected and all(v==0 for v in q['actualExits'].values())
for label in expected:
 r=json.loads((o/(label+'-execution.json')).read_text());assert r['sourceCommit']==m and r['actualExit']==0
initial=json.loads((o/'initial-source6b/ui-quality-execution.json').read_text());assert initial['sourceCommit']=='6b85177c6076ce9b563088e86bff515aeb1bf210' and initial['actualExit']==1
# Lint/typecheck completed before Jest in set-e quality-ui at the exact unchanged app/typecheck inputs.
allowed={'docs/catalog-persistence/reports/static-list-inventory.json','formal/system/inventory.json','formal/system/traceability.json','scripts/__tests__/browser-vendor.test.mjs','tdf-hq-ui/jest.config.cjs'};assert set(git('diff','--name-only','-z',initial['sourceCommit'],m).decode().strip('\0').split('\0'))==allowed
assert '> tsc --noEmit -p tsconfig.app.json' in (o/'initial-source6b/ui-quality.log').read_text() and '> NODE_OPTIONS=--experimental-vm-modules jest --runInBand' in (o/'initial-source6b/ui-quality.log').read_text()
f=json.loads((o/'assurance-committed/report.json').read_text());s=json.loads((o/'assurance-committed/sources.json').read_text());assert f['execution']['passed'] and f['provenance']['revision']==s['revision']==m and not s['worktreeDirty'];assert s['digest']==sha(json.dumps(s['files'],sort_keys=True).encode())
for key in ['files','digest','revision','mobileGitlink','worktreeDirty']:assert f['provenance'][key]==s[key]
counts={'PROVEN':0,'REFUTED':0,'UNPROVEN':160,'NOT_APPLICABLE':0};assert f['metrics']['requirements']==counts
for cat in ['implementation','refinement']:assert f['metrics']['obligationsByCategory'][cat]==counts
for cat,n in [('source-derived-SMT',4),('source-derived-authorization-SMT',3),('source-derived-recovery-SMT',4)]:assert f['metrics']['obligationsByCategory'][cat]=={'PROVEN':n,'REFUTED':0,'UNPROVEN':0,'NOT_APPLICABLE':0}
assert f['release']['decision']=='BLOCKED' and f['release']['executionAllowed'] is False
mobile=git('rev-parse',m+':tdf-mobile').decode().strip();assert git('rev-parse','HEAD',cwd=w/'tdf-mobile').decode().strip()==mobile
for ism in [False,True]:
 pairs=[(path,h) for path,h in s['files'].items() if path.startswith('tdf-mobile/')==ism]
 if not pairs:continue
 cwd=w/'tdf-mobile' if ism else w;ref=mobile if ism else m;refs=[ref+':'+(path.removeprefix('tdf-mobile/') if ism else path) for path,h in pairs];raw=subprocess.check_output(['git','cat-file','--batch'],cwd=cwd,input=('\n'.join(refs)+'\n').encode());pos=0
 for path,h in pairs:
  end=raw.index(b'\n',pos);header=raw[pos:end].split();assert header[1]==b'blob';n=int(header[2]);assert sha(raw[end+1:end+1+n])==h==sha((w/path).read_bytes()),path;pos=end+1+n+1
 assert pos==len(raw)
for path,h in f['evidenceHashes'].items():assert not Path(path).is_absolute() and '..' not in Path(path).parts and sha((o/'assurance-committed'/path).read_bytes())==h
req=json.loads(git('show',m+':formal/system/requirements.json'))['requirements'];old=json.loads(git('show',parent+':formal/system/requirements.json'))['requirements'];by={x['id']:x for x in req};assert len(req)==160 and len(old)==159 and all(by[x['id']]==x for x in old)
assert git('rev-parse',m+':tdf-hq')==git('rev-parse',parent+':tdf-hq');assert not git('diff','--name-only',parent,m,'--','reports','formal/system/evidence').strip()
oldlock=json.loads(git('show',parent+':package-lock.json'));newlock=json.loads(git('show',m+':package-lock.json'));assert len(oldlock['packages'])-len(newlock['packages'])==145 and not set(newlock['packages'])-set(oldlock['packages'])
for k,e in newlock['packages'].items():
 if k:
  for field in ['version','resolved','integrity']:assert e.get(field)==oldlock['packages'][k].get(field)
oldDecisions=json.loads(git('show',parent+':docs/catalog-persistence/catalog-list-decisions.json'))['decisions'];newDecisions=json.loads(git('show',m+':docs/catalog-persistence/catalog-list-decisions.json'))['decisions'];assert newDecisions[:len(oldDecisions)]==oldDecisions and len(newDecisions)==len(oldDecisions)+13
manifest=json.loads(git('show',m+':third_party/webtorrent/browser.json'));assert sha((o/'dist/webtorrent.min.js').read_bytes())==manifest['asset']['sha256']==sha(git('show',m+':'+manifest['asset']['path']))
assert sha(git('show',m+':'+manifest['inventory']['path']))==manifest['inventory']['sha256'] and sha(git('show',m+':'+manifest['notices']['path']))==manifest['notices']['sha256']
mut=json.loads((o/'mutation-controls.json').read_text());assert len(mut['records'])==4 and all(r['actualExit']==1 and r['validBeforeActualExit']==0 and r['detectedByAssertions'] for r in mut['records'])
for field,path in [('sourceCheckerSha256','scripts/check-browser-vendor.mjs'),('sourceMapperSha256','tdf-hq-ui/jest.config.cjs'),('sourceTestsSha256','scripts/__tests__/browser-vendor.test.mjs')]:assert mut[field]==sha(git('show',m+':'+path))
b=json.loads((o/'browser-runtime-execution.json').read_text());assert b['sourceCommit']==m and b['actualExit']==0 and b['stats']['expected']==2 and b['stats']['unexpected']==b['stats']['skipped']==b['stats']['flaky']==0
assert json.loads((o/'installed-lock-reconciliation.json').read_text())['lockSha256']==sha(git('show',m+':package-lock.json'))
native=json.loads((o/'resolver-native-provenance.json').read_text());assert native['installedBinaryByteExactOfficial'] and native['loadActualExit']==0 and native['requiredByLockedUnrsExactOptionalVersion']
changedHashes={}
for name in git('diff','--name-only','-z',parent,m).decode().strip('\0').split('\0'):
 data=git('show',m+':'+name);assert data==(w/name).read_bytes();changedHashes[name]=sha(data)
ui=(o/'ui-tests.log').read_text();summaries=[line for line in ui.splitlines() if re.match(r'^(?:Test Suites|Tests|Snapshots|Time):',line)]
assert len(re.findall(r'^Test Suites:.*$',ui,re.M))==1 and re.search(r'^Test Suites:\s+324 passed, 324 total\s*$',ui,re.M)
assert len(re.findall(r'^Tests:.*$',ui,re.M))==1 and re.search(r'^Tests:\s+3761 passed, 3761 total\s*$',ui,re.M)
assert not re.search(r'^FAIL\s',ui,re.M)
unit=(o/'browser-vendor-unit.log').read_text()
for key,expectedCount in [('tests',19),('suites',0),('pass',19),('fail',0),('cancelled',0),('skipped',0),('todo',0)]:
 values=re.findall(r'^(?:#|ℹ)\s+'+key+r'\s+(\d+)\s*$',unit,re.M);assert values==[str(expectedCount)],(key,values)
assert not re.search(r'^(?:not ok|✖)\s',unit,re.M)
rawBrowser=json.loads((o/'browser-results.json').read_text());assert rawBrowser['stats']==b['stats']
browserRows=[]
def collectBrowser(value):
 if isinstance(value,dict):
  if 'projectName' in value and 'results' in value:
   assert len(value['results'])==1
   result=value['results'][0];assert result['status']=='passed'
   attachments=[a for a in result.get('attachments',[]) if a.get('name')=='browser-component-lifecycle'];assert len(attachments)==1
   import base64
   lifecycle=json.loads(base64.b64decode(attachments[0]['body'],validate=True))
   assert lifecycle=={'moduleType':'function','nativeWebRTC':True,'webRTC':True,'torrents':0,'workerState':'activated','scope':'/torrent-stream/','server':True,'destroyed':True}
   browserRows.append({'project':value['projectName'],'lifecycle':lifecycle})
  for child in value.values():collectBrowser(child)
 elif isinstance(value,list):
  for child in value:collectBrowser(child)
collectBrowser(rawBrowser);assert sorted(r['project'] for r in browserRows)==['chromium','firefox']
for variant,failures in [('unpin-inventory',2),('ignore-affected-advisory',1),('drop-notice-preservation',1),('restore-query-only-jest-mapping',1)]:
 transcript=(o/('mutation-'+variant+'.log')).read_text()
 assert re.findall(r'^# tests (\d+)\s*$',transcript,re.M)==['19']
 assert re.findall(r'^# fail (\d+)\s*$',transcript,re.M)==[str(failures)]
 assert len(re.findall(r'^not ok ',transcript,re.M))==failures and transcript.count("code: 'ERR_ASSERTION'")>=failures
 assert not re.search(r'Cannot find module|SyntaxError|ERR_MODULE_NOT_FOUND',transcript)

r={'sourceCommit':m,'parent646':parent,'baselineMain':p['baselineMain'],'sourceDigest':s['digest'],'registeredGitAndWorktreeHashesVerified':len(s['files']),'allChangedSourceGitAndWorktreeHashes':changedHashes,'assuranceArtifactHashesVerified':len(f['evidenceHashes']),'all159ParentRequirementsExact':True,'requirements':160,'implementationAndRefinementObligations':320,'wholeBackendTreeExactParent':True,'historicalReportsAndEvidenceUnchanged':True,'allParentCatalogDecisionsPreserved':True,'individuallyReviewedNewTechnicalConstantTables':13,'lockPrune':{'oldPackages':len(oldlock['packages']),'newPackages':len(newlock['packages']),'removed':145,'added':0,'allSurvivingVersionResolvedIntegrityExact':True},'browserAssetSha256':manifest['asset']['sha256'],'browserNoticesSha256':manifest['notices']['sha256'],'advisoryPackageIdentities':len(manifest['advisoryPackages']),'uiTestSummary':summaries,'lintAndTypecheck':'Lint completed at initial6b beforeJest failure and all lint inputs remain exact; no fresh full quality-ui pass claimed. Current source fullJest and productionbuild pass separately; the productionbuild also runs a fresh tsc --noEmit typecheck.','actualExits':q['actualExits'],'browserStats':b['stats'],'assertionDetectedFaults':4,'semanticMutationFailedAssertions':5,'rawBrowserLifecycles':browserRows,'formalMetrics':f['metrics'],'formalRelease':'BLOCKED','newCompleteProofs':0,'nativeResolverScope':'Exact optional1.11.1 official binaryverified separately because parent/finalrootlock omit platformbinding entry; firstfailure preserved; runtimefallback disabled during remainingqualification.','sourceCleanAfter':True,'limitations':['TESTED finite static/config/advisory/UI/browser controls, not complete correctness or reachability proofs.','Publisher source map and matching-source candidates do not uniquely prove exact upstream build versions or binary derivation; webpack compilerversionunknown.','Nine candidate archives lack standalone license notices; supplied declarations/attributions retained, no legal completeness certification.','No real torrents, peers, production playback/provider/financial operations or WebKit/physical-device validation executed.','No fresh local Haskell/Mobile qualification; exact backend/Mobile inputs retain their historical source identities and new published CI remains required.','Existing eleven source-derived conditionalSMT claims retain trusted extraction/coherence/arithmetic assumptions; whole160requirements/320implementation-refinement remainUNPROVEN and formalreleaseBLOCKED.','Initialverification/native setup failures retained; only valid-before assertionnegativecontrols count as successful fault detection.'],'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/'source-correspondence.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ['sourceCommit','registeredGitAndWorktreeHashesVerified','assuranceArtifactHashesVerified','uiTestSummary','assertionDetectedFaults','formalRelease']}),flush=True)
