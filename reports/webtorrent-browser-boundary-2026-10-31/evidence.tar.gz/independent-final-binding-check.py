from pathlib import Path
import hashlib,json,subprocess,base64,tarfile
w=Path('/private/tmp/tdf-webtorrent-browser-only-20261031T0132');o=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args,cwd=w):return subprocess.check_output(['git',*args],cwd=cwd)
m='0fbea9f229056a4f72796863d2966259576d891a';parent='0bda432f7339a86d0206e5f7abbb2763161c0c2a';main='234ff6f7faf1aecf347c8e92a374228f4ec07aaa'
assert git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip()
s=json.loads((o/'assurance-committed/sources.json').read_text());f=json.loads((o/'assurance-committed/report.json').read_text());c=json.loads((o/'source-correspondence.json').read_text());assert s['revision']==c['sourceCommit']==m
assert len(s['files'])==1444 and sha(json.dumps(s['files'],sort_keys=True).encode())==s['digest']
mobile=git('rev-parse',m+':tdf-mobile').decode().strip();verified=0
for ism in [False,True]:
 entries=[(p,h) for p,h in s['files'].items() if p.startswith('tdf-mobile/')==ism];cwd=w/'tdf-mobile' if ism else w;rev=mobile if ism else m
 references=[rev+':'+(p[len('tdf-mobile/'):] if ism else p) for p,h in entries]
 raw=subprocess.check_output(['git','cat-file','--batch'],cwd=cwd,input=('\n'.join(references)+'\n').encode());at=0
 for p,h in entries:
  end=raw.index(b'\n',at);head=raw[at:end].split();assert len(head)==3 and head[1]==b'blob';n=int(head[2]);body=raw[end+1:end+1+n];assert sha(body)==h==sha((w/p).read_bytes()),p;at=end+n+2;verified+=1
 assert at==len(raw)
for p,h in f['evidenceHashes'].items():assert sha((o/'assurance-committed'/p).read_bytes())==h
for k in ['files','digest','revision','mobileGitlink','worktreeDirty']:assert f['provenance'][k]==s[k]
assert not s['worktreeDirty'] and f['execution']['passed'] and f['release']['decision']=='BLOCKED' and f['release']['executionAllowed'] is False
for typ in ['requirements']:
 assert f['metrics'][typ]=={'PROVEN':0,'REFUTED':0,'UNPROVEN':160,'NOT_APPLICABLE':0}
for cat in ['implementation','refinement']:assert f['metrics']['obligationsByCategory'][cat]=={'PROVEN':0,'REFUTED':0,'UNPROVEN':160,'NOT_APPLICABLE':0}
old=json.loads(git('show',parent+':formal/system/requirements.json'))['requirements'];new=json.loads(git('show',m+':formal/system/requirements.json'))['requirements'];newby={r['id']:r for r in new};assert len(old)==159 and len(new)==160 and all(newby[r['id']]==r for r in old)
assert git('rev-parse',parent+':tdf-hq')==git('rev-parse',m+':tdf-hq');assert not git('diff','--name-only',parent,m,'--','reports','formal/system/evidence').strip()
assert git('show',m+':tdf-hq-ui/public/webtorrent-sw.min.js')==git('show',parent+':tdf-hq-ui/public/webtorrent-sw.min.js')
assert (w/'tdf-hq-ui/src/vendor/webtorrent/webtorrent.min.js').read_bytes()==(o/'dist/webtorrent.min.js').read_bytes()
r=json.loads((o/'browser-results.json').read_text());expected={'moduleType':'function','nativeWebRTC':True,'webRTC':True,'torrents':0,'workerState':'activated','scope':'/torrent-stream/','server':True,'destroyed':True};observed=[]
assert r['errors']==[] and r['stats']['expected']==2 and all(r['stats'][k]==0 for k in ['skipped','unexpected','flaky'])
for suite in r['suites']:
 for spec in suite.get('specs',[]):
  for test in spec['tests']:
   assert test['status']=='expected' and len(test['results'])==1
   result=test['results'][0];assert result['status']=='passed' and result['retry']==0 and not result.get('errors')
   a=[x for x in result['attachments'] if x['name']=='browser-component-lifecycle'];assert len(a)==1;body=json.loads(base64.b64decode(a[0]['body'],validate=True));assert body==expected
   observed.append(test['projectName'])
assert set(observed)=={'chromium','firefox'} and len(observed)==2
native=json.loads((o/'resolver-native-provenance.json').read_text());t=(o/'resolver-native.tgz').read_bytes();alg,sri=native['integrity'].split('-',1);assert base64.b64encode(hashlib.new(alg,t).digest()).decode()==sri
with tarfile.open(o/'resolver-native.tgz') as tf:
 members=[x for x in tf.getmembers() if x.name.endswith('.node')];assert len(members)==1;official=tf.extractfile(members[0]).read()
installed=w/'node_modules/@unrs/resolver-binding-darwin-x64/resolver.darwin-x64.node';assert sha(official)==native['nativeBinarySha256']==sha(installed.read_bytes())
paths=['source-correspondence.json','source-state.json','qualification-progress.json','browser-results.json','browser-runtime-execution.json','browser-lifecycle-observations.json','mutation-controls.json','resolver-native-provenance.json','qualification-failure-and-repair.json','root-independent-license-verification.json','ui-tests.log','ui-build.log','root-quality.log','browser-vendor-unit.log','browser-vendor-live.log','unchanged-production-audit.log']
output={'sourceCommit':m,'parent646':parent,'mainBaseline':main,'readOnlyRehashes':verified,'assuranceArtifactRehashes':len(f['evidenceHashes']),'parentNormsExact':159,'currentNorms':160,'unchangedBackendTree':True,'unchangedHistoricalReports':True,'workerExact':True,'browserAssetOfficialExact':True,'decodedActualBrowserLifecycleProjects':observed,'nativeOptionalBinaryMatchesOfficialSRIAndInstalledBytes':True,'scope':'Source/evidence read-only verification; no tests/compiler/browser or package code independently executed; own authored license inventory not semantically independently reviewed here.','receiptHashes':{p:sha((o/p).read_bytes()) for p in paths}}
(o/'independent-final-binding-check.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps({k:v for k,v in output.items() if k!='receiptHashes'},indent=2))
