from pathlib import Path
import os,subprocess,json,hashlib,time,signal,socket,uuid,datetime
w=Path('/private/tmp/tdf-music-worker-completion-main642-20261030');o=Path('/private/tmp/tdf-music-worker-completion-main642-qualification-20261030');m=json.loads((o/'preparation-state.json').read_text())['sourceCommit'];root=json.loads((o/'root-quality-result.json').read_text());assert root['sourceCommit']==m and all(x==0 for x in root['actualExits'].values())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip()==m and not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
out=o/'native-concurrency';out.mkdir(exist_ok=False);tag=uuid.uuid4().hex[:12];data=Path('/private/tmp')/('tdf-worker642-data-'+tag);sockdir=Path('/private/tmp')/('tdf-worker642-sock-'+tag);data.mkdir(mode=0o700);sockdir.mkdir(mode=0o700);pgbin=Path('/usr/local/opt/postgresql@16/bin');assert all((pgbin/x).is_file() for x in ['initdb','pg_ctl','psql'])
with socket.socket() as reservation:reservation.bind(('127.0.0.1',0));port=reservation.getsockname()[1]
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env.update(PATH=str(pgbin)+':/Users/macpro/.nvm/versions/node/v24.13.1/bin:/private/tmp/tdf-correctness-bin-20261028:/usr/local/bin:/usr/bin:/bin',PGHOST='127.0.0.1',PGPORT=str(port),PGUSER='postgres',PGDATABASE='postgres',PYTHONDONTWRITEBYTECODE='1')
paths=['scripts/test-music-release-worker-runtime.mjs','scripts/run-music-release-worker-once.sh','scripts/lib/music-test-database.mjs','scripts/lib/disposable-postgres-url.mjs','scripts/lib/test-child-completion.mjs','scripts/__tests__/test-child-completion.test.mjs','test/fixtures/music-worker/curl.mjs'];sha=lambda b:hashlib.sha256(b).hexdigest();inputs={p:sha((w/p).read_bytes()) for p in paths}
for p,h in inputs.items():assert sha(subprocess.check_output(['git','show',m+':'+p],cwd=w))==h
record={'sourceCommit':m,'phase':'SETUP','sourceSha256':inputs,'scope':'Seven actual worker concurrency scenarios with owned new loopback PostgreSQL16 cluster and transport fault injector; same30s close-based completion; no production/provider/S3 compatibility or hosted-failure repair claim.','dataDirectory':str(data),'socketDirectory':str(sockdir),'port':port,'postgresBinary':str(pgbin),'periodicSchedulingObservers':False,'startedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};attempted=False;proc=None

def save():(out/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
def stop_requested(signum,frame):raise SystemExit(128+signum)
signal.signal(signal.SIGTERM,stop_requested)
def pg(query):return subprocess.check_output([str(pgbin/'psql'),'-XAtq','-v','ON_ERROR_STOP=1','-d','postgres','-c',query],cwd=w,env=env,text=True,timeout=10).strip()
def group_exists(pid):
 try:os.killpg(pid,0);return True
 except ProcessLookupError:return False
save()
try:
 with (out/'initdb.log').open('w') as log:r=subprocess.run([str(pgbin/'initdb'),'-D',str(data),'-A','trust','-U','postgres','-E','UTF8','--no-locale'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=30)
 record['initdbExit']=r.returncode;save();assert r.returncode==0,'Owned cluster setup failed; no behavioral result'
 attempted=True
 with (out/'postgres-start.log').open('w') as log:r=subprocess.run([str(pgbin/'pg_ctl'),'-D',str(data),'-l',str(out/'postgres-server.log'),'-o',f'-h127.0.0.1 -p{port} -k{sockdir}','start'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=30)
 record['postgresStartExit']=r.returncode;save();assert r.returncode==0
 assert Path(pg('SHOW data_directory')).resolve()==data.resolve() and pg('SHOW port')==str(port)
 record['dataDirectoryIndependentlyVerified']=True;record['postgresVersion']=pg('SHOW server_version');assert pg("SELECT count(*) FROM pg_stat_activity WHERE backend_type='client backend' AND pid<>pg_backend_pid()")=='0'
 testenv=env.copy();testenv['TDF_MUSIC_WORKER_TEST_DATABASE_URL']=f'postgresql://postgres@127.0.0.1:{port}/tdf_worker_probe_test'
 record['phase']='RUNNING_SEVEN_SCENARIOS';save()
 with (out/'worker-runtime.log').open('w') as log:
  proc=subprocess.Popen(['node','scripts/test-music-release-worker-runtime.mjs','--concurrency-only'],cwd=w,env=testenv,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);record['runnerPid']=proc.pid;record['runnerProcessGroup']=proc.pid;save()
  try:code=proc.wait(timeout=450)
  except subprocess.TimeoutExpired:record['outerRunnerDeadlineExceeded']=True;save();raise
 record['actualExit']=code;save();print('Worker concurrency actualexit '+str(code),flush=True)
 pattern=f'^tdf_music_worker_{proc.pid}_[a-f0-9]{{32}}$';record['remainingOwnedFixtureSessions']=pg("SELECT count(*) FROM pg_stat_activity WHERE datname ~ '"+pattern+"'");record['remainingOwnedFixtureDatabases']=pg("SELECT count(*) FROM pg_database WHERE datname ~ '"+pattern+"'")
 raw=(out/'worker-runtime.log').read_text();assert code==0 and 'Music worker runtime: 7 scenarios passed' in raw and record['remainingOwnedFixtureSessions']==record['remainingOwnedFixtureDatabases']=='0'
 record['phase']='SCENARIOS_PASSED'
finally:
 if proc is not None:
  if group_exists(proc.pid):
   os.killpg(proc.pid,signal.SIGTERM);deadline=time.monotonic()+5
   while group_exists(proc.pid) and time.monotonic()<deadline:time.sleep(.05)
   if group_exists(proc.pid):os.killpg(proc.pid,signal.SIGKILL)
  if proc.poll() is None:proc.wait(timeout=10)
  record['ownedProcessGroupRemoved']=not group_exists(proc.pid)
 if attempted:
  status=subprocess.run([str(pgbin/'pg_ctl'),'-D',str(data),'status'],env=env,capture_output=True,text=True,timeout=10)
  if status.returncode==0:
   stopped=subprocess.run([str(pgbin/'pg_ctl'),'-D',str(data),'-m','fast','stop'],env=env,capture_output=True,text=True,timeout=30);record['postgresStopExit']=stopped.returncode;(out/'postgres-stop.log').write_text(stopped.stdout+stopped.stderr)
  else:record['postgresStatusAfter']=status.returncode
  final=subprocess.run([str(pgbin/'pg_ctl'),'-D',str(data),'status'],env=env,capture_output=True,text=True,timeout=10);record['ownedPostgresStopped']=final.returncode==3
 record['sourceUnchanged']=all(sha((w/p).read_bytes())==h for p,h in inputs.items());record['finishedAtUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
assert record['phase']=='SCENARIOS_PASSED' and record['ownedProcessGroupRemoved'] and record['ownedPostgresStopped'] and record['sourceUnchanged']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip();record['phase']='QUALIFIED_LOCAL_PG16_CONCURRENCY_CLEANED';save();print(json.dumps(record,indent=2),flush=True)
