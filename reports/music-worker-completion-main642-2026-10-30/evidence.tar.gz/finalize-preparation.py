from pathlib import Path
import subprocess,json,hashlib,datetime,csv,os
w=Path('/private/tmp/tdf-music-worker-completion-main642-20261030');o=Path('/private/tmp/tdf-music-worker-completion-main642-qualification-20261030')
state=json.loads((o/'preparation-state.json').read_text());old=state['baselineHead'];main=state['mainSha']
def git(*a):return subprocess.check_output(['git',*a],cwd=w)
def blob(r,p):return git('show',r+':'+p)
def sha(b):return hashlib.sha256(b).hexdigest()
md=json.loads((o/'metadata-results.json').read_text());assert md['ownedAliasRemoved'] and len(md['actualExits'])==7 and all(x==0 for x in md['actualExits'].values())
assert not (w/'node_modules').exists() and not (w/'node_modules').is_symlink()
owned=['scripts/lib/test-child-completion.mjs','scripts/__tests__/test-child-completion.test.mjs','scripts/test-music-release-worker-runtime.mjs'];line='node --test "$ROOT/scripts/__tests__/test-child-completion.test.mjs"\n'
for p in owned:assert (w/p).read_bytes()==blob(old,p)
assert (w/'scripts/quality-repo.sh').read_text().replace(line,'')==blob(main,'scripts/quality-repo.sh').decode()
assert git('rev-parse','HEAD').decode().strip()==json.loads((o/'unqualified-checkpoint.json').read_text())['checkpoint']
subprocess.run(['git','diff','--check'],cwd=w,check=True)
subprocess.run(['git','add','docs/catalog-persistence/reports/list-consumer-matrix.csv','docs/catalog-persistence/reports/static-list-inventory.json','formal/system/inventory.json','formal/system/traceability.json'],cwd=w,check=True)
r=subprocess.run(['git','commit','--amend','--no-edit'],cwd=w,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(o/'source-commit.log').write_text(r.stdout);assert r.returncode==0,r.stdout
m=git('rev-parse','HEAD').decode().strip();assert git('show','-s','--format=%P',m).decode().split()==[old,main];assert not git('status','--porcelain').strip()
state.update(sourceCommit=m,normalParents=[old,main],sourceCleanAtCommit=True,preparationOnly=True);(o/'preparation-state.json').write_text(json.dumps(state,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env['PATH']='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin';env['PYTHONDONTWRITEBYTECODE']='1'
py='/private/tmp/tdf-event-report-venv-20261027/bin/python';node='/Users/macpro/.nvm/versions/node/v24.13.1/bin/node';results={}
for label,cmd in [('committed-inventory-check',[py,'scripts/specification-inventory.py','--check']),('committed-conformance-check',[py,'scripts/specification-conformance.py','--check']),('source-admission',[py,'scripts/check-new-specification-surfaces.py','--base',main,'--head',m]),('source-ci-selection',[node,'scripts/ci-change-scope.mjs','--base',main,'--head',m])]:
 with (o/(label+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 results[label]=r.returncode;assert r.returncode==0,(label,r.returncode)
assert not git('status','--porcelain').strip()
mainreq=json.loads(blob(main,'formal/system/requirements.json'))['requirements'];prior=json.loads(blob(old,'formal/system/requirements.json'))['requirements'];rows=json.loads(blob(m,'formal/system/requirements.json'))['requirements'];by={x['id']:x for x in rows}
assert len(by)==len(rows)==len(mainreq)+1==160 and all(by[x['id']]==x for x in mainreq)
assert by['SYS-WORKER-COMPLETION-001']==next(x for x in prior if x['id']=='SYS-WORKER-COMPLETION-001')
for p in ['tdf-hq','tdf-hq-ui','.github','ops','tdf-mobile','package.json','package-lock.json','docs/catalog-persistence/catalog-list-decisions.json','formal/system/auth-predicates.json','formal/system/recovery-expiry-arithmetic.json']:
 assert git('rev-parse',m+':'+p)==git('rev-parse',main+':'+p),p
for p in owned:assert blob(m,p)==blob(old,p)
assert set(git('diff','--name-only',main,m,'--','scripts').decode().splitlines())==set(owned+['scripts/quality-repo.sh'])
paths=git('ls-tree','-r','-z','--name-only',old,'--','reports/music-worker-completion-2026-10-29','reports/music-worker-completion-2026-10-29.json').decode().rstrip('\0').split('\0');assert len(paths)==208;bindings={}
for p in paths:
 b=blob(old,p);assert blob(m,p)==b==(w/p).read_bytes();bindings[p]=sha(b)
contract='formal/system/music-worker-completion-observation.md';assert blob(m,contract)==blob(old,contract)
cat=json.loads((o/'current-catalog.json').read_text());assert cat['candidateCount']==1354
with (o/'current-catalog.csv').open(newline='') as f:csvrows=list(csv.DictReader(f))
assert len(csvrows)==1354
parity={'sourceCommit':m,'baselineHead':old,'mainSha':main,'normalParents':[old,main],'ownedSourceSha256':{p:sha(blob(m,p)) for p in owned+['scripts/quality-repo.sh']},'threeOwnedScriptsExactPublishedHead':True,'qualityExactMainPlusSingleOwnedUnitRegistration':True,'wholeBackendUiMobileWorkflowOpsDependenciesExactMain':True,'all159MainRequirementsExact':True,'ownedWorkerRequirementExact':True,'totalRequirements':len(rows),'historicalReportBlobCount':len(paths),'historicalReportsSha256':bindings,'workerContractExactOld':True,'catalogWholeDecisionFileExactMain':True,'strictJsonCandidates':cat['candidateCount'],'strictCsvRows':len(csvrows),'committedChecks':results,'metadataResults':md,'noNewRuntimeExecuted':True,'fullRootQualityExecuted':False,'scope':'Source preparation only; historical original worker/runtime/native results not relabeled current-main; known worker stop cause UNKNOWN and not repaired','sourceCleanAfter':True,'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/'source-preparation-checks.json').write_text(json.dumps(parity,indent=2)+'\n');print(json.dumps({k:parity[k] for k in ['sourceCommit','mainSha','historicalReportBlobCount','strictJsonCandidates','strictCsvRows','committedChecks','sourceCleanAfter']},indent=2))
