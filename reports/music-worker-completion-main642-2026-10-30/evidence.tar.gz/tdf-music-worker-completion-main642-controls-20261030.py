from pathlib import Path
import subprocess,json,hashlib,os,tempfile,datetime
w=Path('/private/tmp/tdf-music-worker-completion-main642-20261030');o=Path('/private/tmp/tdf-music-worker-completion-main642-qualification-20261030');m=json.loads((o/'preparation-state.json').read_text())['sourceCommit'];q=json.loads((o/'root-quality-result.json').read_text());assert q['sourceCommit']==m and all(x==0 for x in q['actualExits'].values())
lib='scripts/lib/test-child-completion.mjs';test='scripts/__tests__/test-child-completion.test.mjs';correct=(w/lib).read_bytes();tests=(w/test).read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest();assert correct==subprocess.check_output(['git','show',m+':'+lib],cwd=w) and tests==subprocess.check_output(['git','show',m+':'+test],cwd=w)
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env['PATH']='/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin';out=o/'current-controls';out.mkdir(exist_ok=False)
original_context='''        const error = new Error(`Worker did not stop within ${timeoutMs / 1000}s\nWorker completion snapshot: ${JSON.stringify(snapshot)}`);
        error.workerSnapshot = snapshot;'''.replace('s\nWorker','s\\nWorker')
variants=[('omit-exit-observation',"  child.once('exit', () => { exitedAt = performance.now(); });",'', 'exited parent','exited-awaiting-close'),('complete-at-exit',"    child.once('close', (status, signal) => {","    child.once('exit', (status, signal) => {",'exited parent','Missing expected rejection'),('discard-timeout-context',original_context,'        const error = new Error(`Worker did not stop within ${timeoutMs / 1000}s`);','a live child timeout','Worker completion snapshot:')]
rows=[]
with tempfile.TemporaryDirectory(prefix='tdf-worker-bound-controls-') as td:
 root=Path(td);p=root/lib;t=root/test;p.parent.mkdir(parents=True);t.parent.mkdir(parents=True);t.write_bytes(tests)
 for label,old,new,pattern,expected in variants:
  source=correct.decode();assert source.count(old)==1,label;mutant=source.replace(old,new,1);p.write_text(mutant);(out/(label+'.mjs')).write_text(mutant)
  with (out/(label+'.log')).open('w') as log:r=subprocess.run(['node','--test','--test-name-pattern='+pattern,str(t)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=25)
  raw=(out/(label+'.log')).read_text();assert r.returncode==1 and expected in raw and 'fail 1' in raw,(label,r.returncode,raw[-1000:]);rows.append({'label':label,'actualExit':1,'intendedRealProcessAssertionFailures':1,'mutantSha256':sha(mutant.encode()),'logSha256':sha((out/(label+'.log')).read_bytes())});print(label+' actualexit1/intendedassert1',flush=True)
 p.write_bytes(correct)
 with (out/'restored-positive.log').open('w') as log:r=subprocess.run(['node','--test',str(t)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=25)
 assert r.returncode==0 and 'pass 6' in (out/'restored-positive.log').read_text();assert p.read_bytes()==correct and t.read_bytes()==tests
assert (w/lib).read_bytes()==correct and (w/test).read_bytes()==tests and not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
(out/'correct-library.mjs').write_bytes(correct);(out/'correct-tests.mjs').write_bytes(tests)
(o/'controls.json').write_text(json.dumps({'sourceCommit':m,'correctLibrarySha256':sha(correct),'correctTestsSha256':sha(tests),'variants':rows,'faultVariants':3,'intendedAssertionFailures':3,'restoredPositiveCases':6,'restoredPositiveExit':0,'qualifiedWorktreeNeverMutated':True,'scope':'Actual current-source copies and real child processes; source faults isolated outside checkout. No product worker shutdown repair or universal lifecycle proof.','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n');print('All3 sourcefaults rejected; restored6/0; frozen checkout untouched',flush=True)
