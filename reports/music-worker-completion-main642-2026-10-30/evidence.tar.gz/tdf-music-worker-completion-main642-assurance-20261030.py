from pathlib import Path
import json,subprocess,os,signal,datetime
w=Path('/private/tmp/tdf-music-worker-completion-main642-20261030');o=Path('/private/tmp/tdf-music-worker-completion-main642-qualification-20261030');m=json.loads((o/'preparation-state.json').read_text())['sourceCommit']
q=json.loads((o/'root-quality-result.json').read_text());assert q['sourceCommit']==m and all(x==0 for x in q['actualExits'].values())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip()==m and not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env.update(PATH='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/Users/macpro/.ghcup/bin:/usr/local/bin:/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1')
def stop_requested(signum,frame):raise SystemExit(128+signum)
signal.signal(signal.SIGTERM,stop_requested)
p=None
with (o/'assurance-driver.log').open('w') as log:
 try:
  p=subprocess.Popen(['python3','scripts/verification-report.py','--output',str(o/'assurance-committed')],cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  code=p.wait(timeout=1800)
 except BaseException:
  if p is not None and p.poll() is None:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
  raise
(o/'assurance-execution.json').write_text(json.dumps({'sourceCommit':m,'actualExit':code,'directSession':True,'completedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n');print('Assurance actualexit '+str(code),flush=True);assert code==0
