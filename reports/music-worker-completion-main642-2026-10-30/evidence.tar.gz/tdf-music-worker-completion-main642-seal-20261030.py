from pathlib import Path
import subprocess,json,hashlib,datetime
w=Path('/private/tmp/tdf-music-worker-completion-main642-20261030');o=Path('/private/tmp/tdf-music-worker-completion-main642-qualification-20261030');sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=w):return subprocess.check_output(['git',*a],cwd=cwd)
def blob(rev,p):return git('show',rev+':'+p)
prep=json.loads((o/'preparation-state.json').read_text());m=prep['sourceCommit'];main=prep['mainSha'];old=prep['baselineHead']
assert old=='7082d7d045dcd6b2c7f8d33282e9ff2d6588d617' and git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip();assert git('show','-s','--format=%P',m).decode().split()==[old,main]
owned=['scripts/lib/test-child-completion.mjs','scripts/__tests__/test-child-completion.test.mjs','scripts/test-music-release-worker-runtime.mjs'];assert set(git('diff','--name-only',main,m,'--','scripts').decode().splitlines())==set(owned+['scripts/quality-repo.sh'])
for p in owned+['formal/system/music-worker-completion-observation.md']:assert blob(m,p)==blob(old,p)==(w/p).read_bytes(),p
quality=blob(m,'scripts/quality-repo.sh');registration=b'node --test "$ROOT/scripts/__tests__/test-child-completion.test.mjs"\n';assert quality.count(registration)==1 and quality.replace(registration,b'',1)==blob(main,'scripts/quality-repo.sh')
for p in ['tdf-hq','tdf-hq-ui','tdf-mobile','.github','ops','package.json','package-lock.json','formal/system/auth-predicates.json','formal/system/recovery-expiry-arithmetic.json','docs/catalog-persistence/catalog-list-decisions.json']:
 assert git('rev-parse',m+':'+p)==git('rev-parse',main+':'+p),p
req=json.loads(blob(m,'formal/system/requirements.json'))['requirements'];incoming=json.loads(blob(main,'formal/system/requirements.json'))['requirements'];prior=json.loads(blob(old,'formal/system/requirements.json'))['requirements'];by={x['id']:x for x in req};assert len(by)==len(req)==160 and len(incoming)==159 and all(by[x['id']]==x for x in incoming);key='SYS-WORKER-COMPLETION-001';assert by[key]==next(x for x in prior if x['id']==key)
r=json.loads((o/'root-quality-result.json').read_text());f=json.loads((o/'assurance-committed/report.json').read_text());s=json.loads((o/'assurance-committed/sources.json').read_text());ae=json.loads((o/'assurance-execution.json').read_text());c=json.loads((o/'controls.json').read_text());n=json.loads((o/'native-concurrency/execution.json').read_text());ne=json.loads((o/'native-driver-result.json').read_text());cleanup=json.loads((o/'cleanup-controls.json').read_text())
assert all(x['sourceCommit']==m for x in [r,ae,c,n,ne,cleanup]);assert all(x==0 for x in r['actualExits'].values()) and ae['actualExit']==0 and f['execution']['passed'];assert c['faultVariants']==3 and c['intendedAssertionFailures']==3 and c['restoredPositiveCases']==6 and c['restoredPositiveExit']==0 and c['qualifiedWorktreeNeverMutated'];assert c['correctLibrarySha256']==sha(blob(m,owned[0])) and c['correctTestsSha256']==sha(blob(m,owned[1]))
assert n['phase']=='QUALIFIED_LOCAL_PG16_CONCURRENCY_CLEANED' and n['actualExit']==ne['driverActualExit']==0 and n['postgresVersion'].startswith('16.') and n['dataDirectoryIndependentlyVerified'];assert n['remainingOwnedFixtureSessions']==n['remainingOwnedFixtureDatabases']=='0' and n['ownedProcessGroupRemoved'] and n['ownedPostgresStopped'] and n['postgresStopExit']==0 and n['sourceUnchanged'];assert 'Music worker runtime: 7 scenarios passed' in (o/'native-concurrency/worker-runtime.log').read_text();assert cleanup['all4Passed'] and len(cleanup['cases'])==4
native_driver=Path('/private/tmp/tdf-music-worker-completion-main642-native-pg-20261030.py');assert sha(native_driver.read_bytes())==ne['driverSha256']==cleanup['driverSha256'] and sha((o/'native-concurrency/execution.json').read_bytes())==ne['executionSha256']
for p,h in n['sourceSha256'].items():assert sha(blob(m,p))==h==sha((w/p).read_bytes()),p
assert s['revision']==m and not s['worktreeDirty'] and s['digest']==sha(json.dumps(s['files'],sort_keys=True).encode())
for p in ['files','digest','revision','mobileGitlink','worktreeDirty']:assert f['provenance'][p]==s[p]
expected={'PROVEN':0,'REFUTED':0,'UNPROVEN':160,'NOT_APPLICABLE':0};assert f['metrics']['requirements']==expected
for cat in ['implementation','refinement']:assert f['metrics']['obligationsByCategory'][cat]==expected
for cat,count in [('source-derived-SMT',4),('source-derived-authorization-SMT',3),('source-derived-recovery-SMT',4)]:assert f['metrics']['obligationsByCategory'][cat]=={'PROVEN':count,'REFUTED':0,'UNPROVEN':0,'NOT_APPLICABLE':0}
assert f['release']['decision']=='BLOCKED' and f['release']['executionAllowed'] is False
mobile=git('rev-parse',m+':tdf-mobile').decode().strip();assert git('rev-parse','HEAD',cwd=w/'tdf-mobile').decode().strip()==mobile

def bindings(pairs,rev,cwd=w):
 pairs=list(pairs);refs=[rev+':'+(p.removeprefix('tdf-mobile/') if cwd==w/'tdf-mobile' else p) for p,h in pairs];assert all('\n' not in p for p in refs)
 raw=subprocess.check_output(['git','cat-file','--batch'],cwd=cwd,input=('\n'.join(refs)+'\n').encode());pos=0
 for p,h in pairs:
  end=raw.index(b'\n',pos);header=raw[pos:end].split();assert header[1]==b'blob';size=int(header[2]);b=raw[end+1:end+1+size];assert sha(b)==sha((w/p).read_bytes())==h,p;pos=end+1+size+1
 assert pos==len(raw)
 return len(pairs)
for ism in [False,True]:bindings(((p,h) for p,h in s['files'].items() if p.startswith('tdf-mobile/')==ism),mobile if ism else m,w/'tdf-mobile' if ism else w)
backend=git('ls-tree','-r','-z','--name-only',m,'--','tdf-hq').decode().rstrip('\0').split('\0');backend_hashes={p:sha((w/p).read_bytes()) for p in backend};bindings(backend_hashes.items(),m)
history=git('ls-tree','-r','-z','--name-only',old,'--','reports/music-worker-completion-2026-10-29.json','reports/music-worker-completion-2026-10-29').decode().rstrip('\0').split('\0');assert len(history)==208;history_hashes={p:sha((w/p).read_bytes()) for p in history};bindings(history_hashes.items(),old)
assert blob(main,'scripts/run-music-release-worker-once.sh')==blob(m,'scripts/run-music-release-worker-once.sh')
for p,h in f['evidenceHashes'].items():
 rel=Path(p);assert not rel.is_absolute() and '..' not in rel.parts and sha((o/'assurance-committed'/rel).read_bytes())==h,p
assert not git('status','--porcelain').strip()
result={'sourceCommit':m,'baseMain':main,'previousPublishedHead':old,'normalParents':[old,main],'wholeProductionBackendUiWorkflowOpsDependenciesMobileExactMain':True,'threeOwnedScriptsExactPrevious':True,'qualityOnlyOriginalUnitRegistrationAdded':True,'all159MainRequirementObjectsAndOwnedSYSExact':True,'totalRequirements':160,'registeredHashesVerified':len(s['files']),'sourceDigest':s['digest'],'all987BackendGitFilesystemInputsVerified':len(backend_hashes),'historicalGitFilesystemBlobCount':len(history_hashes),'historicalGitFilesystemSha256':history_hashes,'assuranceArtifactHashesVerified':len(f['evidenceHashes']),'controls':c,'localNativeConcurrency':n,'nativeDriverResult':ne,'cleanupFaultControls':cleanup,'formalMetrics':f['metrics'],'formalRelease':f['release']['decision'],'newCompleteProofs':0,'noLocalHaskellBinaryQualificationClaim':True,'currentHeadCIRequired':True,'sourceCleanAfter':True,'limits':['Synthetic child/process and localPG16 with curl faultinjector only; no real S3/provider, production, DDEXschema, PostgreSQL17 or universal interruptedcleanup proof.','Underlying recurring hosted worker30s shutdown cause remains UNKNOWN/unrepaired; successful local7/historicalhosted23 samples do not establish its repair.','All selected fresh published-head CI/current independent approval/FIFO required; no borrowed oldhead review.'],'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/'source-correspondence.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['sourceCommit','baseMain','registeredHashesVerified','all987BackendGitFilesystemInputsVerified','historicalGitFilesystemBlobCount','assuranceArtifactHashesVerified','formalRelease']},indent=2))
