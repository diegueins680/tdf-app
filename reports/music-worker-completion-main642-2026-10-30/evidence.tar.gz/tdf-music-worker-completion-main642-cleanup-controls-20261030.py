from pathlib import Path
import ast,types,subprocess,json,hashlib,tempfile,signal,time,datetime
p=Path('/private/tmp/tdf-music-worker-completion-main642-native-pg-20261030.py');o=Path('/private/tmp/tdf-music-worker-completion-main642-qualification-20261030');tree=ast.parse(p.read_text());names={'group_exists','signal_group','cleanup_owned_resources'};functions=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in names];assert len(functions)==3
rows=[]
with tempfile.TemporaryDirectory(prefix='tdf-owned-cleanup-controls-') as td:
 out=Path(td)
 for mode in ['child-permission-error','esrch-race','primary-plus-child-error','postgres-stop-error']:
  record={};calls=[];saved=[];probes=[0]
  def killpg(pid,kind):
   assert pid==123456789
   if mode=='esrch-race':
    if kind==0:
     probes[0]+=1
     if probes[0]>1:raise ProcessLookupError('synthetic vanished owned group')
    else:raise ProcessLookupError('synthetic ESRCH between probe and signal')
   elif mode in ['child-permission-error','primary-plus-child-error']:
    if kind!=0:raise PermissionError('synthetic owned-child signal denial')
   elif kind==0:raise ProcessLookupError('synthetic already-finished group')
  def run(args,**kwargs):
   calls.append(args);assert args[0]=='/synthetic-owned-bin/pg_ctl' and args[1:3]==['-D',str(out/'owned-data')]
   if args[-1]=='stop':
    if mode=='postgres-stop-error':raise OSError('synthetic pg_ctl stop failure')
    return types.SimpleNamespace(returncode=0,stdout='synthetic owned stop\n',stderr='')
   assert args[-1]=='status';return types.SimpleNamespace(returncode=3,stdout='synthetic owned stopped\n',stderr='')
  class Proc:
   pid=123456789
   def poll(self):return 0
   def wait(self,timeout):raise AssertionError('Synthetic already-reaped child must not wait')
  ns={'os':types.SimpleNamespace(killpg=killpg),'signal':signal,'time':time,'datetime':datetime,'subprocess':types.SimpleNamespace(run=run),'record':record,'pgbin':Path('/synthetic-owned-bin'),'data':out/'owned-data','out':out,'env':{},'inputs':{},'w':out,'sha':lambda b:hashlib.sha256(b).hexdigest(),'save':lambda:saved.append(True)}
  exec(compile(ast.Module(body=functions,type_ignores=[]),str(p),'exec'),ns)
  primary=RuntimeError('synthetic original runner failure') if mode=='primary-plus-child-error' else None;caught=None
  try:ns['cleanup_owned_resources'](Proc(),True,primary)
  except BaseExceptionGroup as group:caught=group
  assert any(a[-1]=='stop' for a in calls) and any(a[-1]=='status' for a in calls) and record['ownedPostgresStopped'] and saved,mode
  if mode=='esrch-race':assert caught is None and record['ownedProcessGroupRemoved']
  elif mode=='postgres-stop-error':assert caught is not None and any(isinstance(e,OSError) for e in caught.exceptions)
  else:
   assert caught is not None and any(isinstance(e,PermissionError) for e in caught.exceptions)
   if primary is not None:assert primary in caught.exceptions
  rows.append({'case':mode,'pgStopAndStatusAttempted':True,'finalStateSaved':True,'esrchTolerated':mode=='esrch-race','unexpectedErrorRetained':caught is not None,'originalErrorRetained':primary in caught.exceptions if primary is not None else None})
result={'sourceCommit':json.loads((o/'preparation-state.json').read_text())['sourceCommit'],'driverSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'cases':rows,'all4Passed':True,'scope':'Actual AST-extracted cleanup function with mocked child-group/pg_ctl failures; no OS signal/server/database executed. Supports ordering/error-retention under listed faults, not universal interruption cleanup.','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/'cleanup-controls.json').write_text(json.dumps(result,indent=2)+'\n');print('Four cleanup fault controls passed; PG stop/status/save survives child failures, ESRCH tolerated and original/unexpected errors retained.')
