from pathlib import Path
import subprocess,json,hashlib,os,datetime
f=Path(__file__).parent;w=Path('/private/tmp/tdf-torrent-worker-control-20261031T0826');ui=f/'tdf-hq-ui';source=ui/'src/components/StudioGallery.tsx';test=ui/'src/components/StudioGallery.test.tsx';sha=lambda b:hashlib.sha256(b).hexdigest();originalSource=(f/'original-StudioGallery.tsx.txt').read_text();originalTest=(f/'original-StudioGallery.test.tsx.txt').read_text()
new="import { jest } from '@jest/globals';\nimport { createTheme } from '@mui/material/styles';\n"+originalTest.replace('within, waitFor, act','within, act');new=new.replace("describe('StudioGallery', () => {", """const leavingScreen = createTheme().transitions.duration.leavingScreen;

describe('StudioGallery', () => {
  beforeEach(() => jest.useFakeTimers());
  afterEach(() => { jest.clearAllTimers(); jest.useRealTimers(); });""");old="    await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument());";assert new.count(old)==2;new=new.replace(old,"    await act(async () => { await jest.advanceTimersByTimeAsync(leavingScreen); });\n    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();");test.write_text(new);source.write_text(originalSource);(f/'StudioGallery.clock.candidate.test.tsx').write_text(new)
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG']};env.update(PATH='/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/bin:/bin',NODE_OPTIONS='--experimental-vm-modules',SKIP_UNRS_RESOLVER_FALLBACK='1');cmd=['/Users/macpro/.nvm/versions/node/v24.13.1/bin/node','node_modules/jest/bin/jest.js','--config','tdf-hq-ui/jest.config.cjs','--runInBand','--runTestsByPath',str(test)];rows=[]
def run(label):
 r=subprocess.run(cmd,cwd=f,env=env,capture_output=True,text=True,timeout=45);b=(r.stdout+r.stderr).encode();(f/(label+'.log')).write_bytes(b);rows.append({'name':label,'actualExit':r.returncode,'logSha256':sha(b),'sourceSha256':sha(source.read_bytes()),'testSha256':sha(test.read_bytes()),'command':cmd});print(label,r.returncode,flush=True);print('\n'.join((r.stdout+r.stderr).splitlines()[-8:]),flush=True);return r
try:
 assert run('clean-clock-valid-before').returncode==0
 source.write_text(originalSource.replace('const close = () => setSelected(null);','const close = () => {};'));r=run('clean-clock-omit-close');assert r.returncode==1 and 'expect(element).not.toBeInTheDocument()' in r.stderr
 source.write_text(originalSource.replace('<Dialog open=', '<Dialog disableRestoreFocus open='));r=run('clean-clock-disable-focus');assert r.returncode==1 and 'expect(element).toHaveFocus()' in r.stderr
finally:source.write_text(originalSource)
assert run('clean-clock-valid-restored').returncode==0
assert (w/'tdf-hq-ui/src/components/StudioGallery.tsx').read_text()==originalSource and (w/'tdf-hq-ui/src/components/StudioGallery.test.tsx').read_text()==originalTest
out={'scope':'Private minimal actual-MUI fake-clock diagnostic/control; no active worktree changes, no full suite qualification or full-run cause proof','originalSourceSha256':sha(originalSource.encode()),'originalTestSha256':sha(originalTest.encode()),'candidateTestSha256':sha(new.encode()),'actualThemeExitMs':195,'controls':rows,'activeSourceAndTestUnchanged':True,'restoredPrivateSource':True,'completedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(f/'clean-clock-controls.json').write_text(json.dumps(out,indent=2)+'\n')
