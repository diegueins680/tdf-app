from pathlib import Path
import subprocess,json,hashlib,os,datetime
f=Path(__file__).parent;w=Path('/private/tmp/tdf-torrent-worker-control-20261031T0826');ui=f/'tdf-hq-ui';source=ui/'src/components/StudioGallery.tsx';test=ui/'src/components/StudioGallery.test.tsx';sha=lambda b:hashlib.sha256(b).hexdigest();originalSource=source.read_text();originalTest=test.read_text();(f/'original-StudioGallery.tsx.txt').write_text(originalSource);(f/'original-StudioGallery.test.tsx.txt').write_text(originalTest)
new="import { jest } from '@jest/globals';\nimport { createTheme } from '@mui/material/styles';\n"+originalTest.replace('within, waitFor, act','within, act')
new=new.replace("describe('StudioGallery', () => {", """const leavingScreen = createTheme().transitions.duration.leavingScreen;
describe('StudioGallery', () => {
  beforeEach(() => jest.useFakeTimers());
  afterEach(() => { jest.clearAllTimers(); jest.useRealTimers(); });""")
old="    await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument());"
assert new.count(old)==2
replacement="""    console.info('TRANSITION_AFTER_CLOSE', JSON.stringify({ dialogPresent: Boolean(screen.queryByRole('dialog')), selectedContentPresent: Boolean(screen.queryByRole('img', { name: /Consola de mezcla|Sala con batería/ })), leavingScreen }));
    await act(async () => { await jest.advanceTimersByTimeAsync(leavingScreen - 1); });
    console.info('TRANSITION_BEFORE_BOUND', JSON.stringify({ dialogPresent: Boolean(screen.queryByRole('dialog')), virtualMs: leavingScreen - 1 }));
    await act(async () => { await jest.advanceTimersByTimeAsync(1); });
    console.info('TRANSITION_AT_BOUND', JSON.stringify({ dialogPresent: Boolean(screen.queryByRole('dialog')), virtualMs: leavingScreen }));
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();"""
new=new.replace(old,replacement);test.write_text(new);(f/'clock-test-with-observations.tsx.txt').write_text(new)
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG']};env.update(PATH='/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/bin:/bin',NODE_OPTIONS='--experimental-vm-modules',SKIP_UNRS_RESOLVER_FALLBACK='1');cmd=['/Users/macpro/.nvm/versions/node/v24.13.1/bin/node','node_modules/jest/bin/jest.js','--config','tdf-hq-ui/jest.config.cjs','--runInBand','--runTestsByPath',str(test)];records=[]
def run(label):
 r=subprocess.run(cmd,cwd=f,env=env,capture_output=True,text=True,timeout=45);b=(r.stdout+r.stderr).encode();(f/(label+'.log')).write_bytes(b);records.append({'label':label,'actualExit':r.returncode,'logSha256':sha(b),'sourceSha256':sha(source.read_bytes()),'testSha256':sha(test.read_bytes()),'command':cmd});(f/'clock-control-progress.json').write_text(json.dumps(records,indent=2)+'\n');print(label,r.returncode,flush=True);print('\n'.join((r.stdout+r.stderr).splitlines()[-10:]),flush=True);return r
try:
 assert run('clock-valid-before').returncode==0
 assert originalSource.count('const close = () => setSelected(null);')==1
 source.write_text(originalSource.replace('const close = () => setSelected(null);','const close = () => {};'));r=run('clock-omit-close');assert r.returncode==1 and 'expect(element).not.toBeInTheDocument()' in r.stderr
 source.write_text(originalSource.replace('<Dialog open=', '<Dialog disableRestoreFocus open='));r=run('clock-disable-focus');assert r.returncode==1 and 'toHaveFocus' in r.stderr
finally:source.write_text(originalSource)
assert run('clock-valid-restored').returncode==0
assert (w/'tdf-hq-ui/src/components/StudioGallery.tsx').read_text()==originalSource and (w/'tdf-hq-ui/src/components/StudioGallery.test.tsx').read_text()==originalTest
out={'scope':'Private diagnostic actual-MUI clock fixture only; no production/worktree edits or full-suite qualification','controls':records,'restoredPrivateSourceExact':True,'activeGallerySourceAndTestUnchanged':True,'completedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(f/'clock-controls.json').write_text(json.dumps(out,indent=2)+'\n')
