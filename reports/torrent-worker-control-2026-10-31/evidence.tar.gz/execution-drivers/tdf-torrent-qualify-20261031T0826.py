from pathlib import Path
import json,subprocess,os,datetime,signal,sys
w=Path('/private/tmp/tdf-torrent-worker-control-20261031T0826');o=Path('/private/tmp/tdf-torrent-worker-control-qualification-20261031T0826');m=json.loads((o/'source-state.json').read_text())['sourceCommit'];phase=sys.argv[1]
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env.update(PATH='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/Users/macpro/.ghcup/bin:/usr/local/bin:/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1',SKIP_UNRS_RESOLVER_FALLBACK='1',PLAYWRIGHT_ARTIFACT_DIR=str(o/'browser-current'))
groups={'ui':[('ui-quality',['bash','scripts/quality-ui.sh'])],'repo':[('root-quality',['bash','scripts/quality-repo.sh'])],'browser':[('browser-vendor-live',['node','scripts/check-browser-vendor.mjs','--audit']),('production-audit',['./node_modules/.bin/audit-ci','--config','./audit-ci.jsonc']),('torrent-node',['node','--test','scripts/__tests__/torrent-worker-routing.test.mjs','scripts/__tests__/torrent-fixture-lifecycle.test.mjs']),('torrent-browser',['node','node_modules/@playwright/test/cli.js','test','--config=playwright.torrent-audio.config.mjs','--project=chromium','--project=firefox'])],'assurance':[('inventory-check',['python3','scripts/specification-inventory.py','--check']),('conformance-check',['python3','scripts/specification-conformance.py','--check']),('assurance',['python3','scripts/verification-report.py','--output',str(o/'assurance-committed')])]}
results={}
for label,cmd in groups[phase]:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip()==m and not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (o/(label+'.log')).open('w') as log:
  p=subprocess.Popen(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=p.wait(timeout=1800)
  except BaseException:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   raise
 result={'command':cmd,'sourceCommit':m,'actualExit':code,'startedAtUTC':start,'finishedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/(label+'-execution.json')).write_text(json.dumps(result,indent=2)+'\n');results[label]=code;print(label+' actualexit '+str(code),flush=True)
 (o/(phase+'-qualification-progress.json')).write_text(json.dumps({'sourceCommit':m,'actualExits':results},indent=2)+'\n')
 if code:raise SystemExit(code)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
