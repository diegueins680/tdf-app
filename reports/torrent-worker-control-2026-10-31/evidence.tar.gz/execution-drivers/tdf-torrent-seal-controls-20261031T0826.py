from pathlib import Path
import tempfile,shutil,json,subprocess,hashlib,re,base64
w=Path('/private/tmp/tdf-torrent-worker-control-20261031T0826');o=Path('/private/tmp/tdf-torrent-worker-control-qualification-20261031T0826');out=o/'seal-controls';out.mkdir(exist_ok=True);d=Path(tempfile.mkdtemp(prefix='tdf-torrent-seal-controls-',dir='/private/tmp'));driver=Path('/private/tmp/tdf-torrent-seal-20261031T0826.py');code=driver.read_text()
files=['source-state.json','mutation-controls.json','ci-mutation-controls.json','ui-quality.log','torrent-node.log','browser-current/results.json','component-browser-results.json','independent-applied-v4-review-bindings.json','independent-final-source-review.json','independent-final-source-review.txt','initial-source-c9/ui-quality-execution.json','initial-source-c9/ui-quality.log']
for label in ['ui-quality','root-quality','browser-vendor-live','production-audit','torrent-node','torrent-browser','inventory-check','conformance-check','assurance','component-browser']:files.append(label+'-execution.json')
for name,field in [('mutation-controls.json','results'),('ci-mutation-controls.json','records')]:
 for row in json.loads((o/name).read_text())[field]:files.append(row['name']+'.log')
for name in files:
 p=d/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(o/name,p)
shutil.copytree(o/'assurance-committed',d/'assurance-committed');shutil.copytree(o/'gallery-clock',d/'gallery-clock');seal=d/'seal.py';seal.write_text(code.replace(str(o),str(d)))
def run(label):
 r=subprocess.run(['python3',str(seal)],cwd=w,capture_output=True,text=True,timeout=90);(out/(label+'.log')).write_text(r.stdout+r.stderr);return r
before=run('valid-before');assert before.returncode==0,before.stderr
rows=[]
def mutate(label,name,edit,json_value=True):
 p=d/name;original=p.read_bytes();v=json.loads(original) if json_value else original.decode();changed=edit(v)
 if changed is not None:v=changed
 p.write_text(json.dumps(v) if json_value else v)
 try:r=run(label)
 finally:p.write_bytes(original)
 detected=r.returncode==1 and 'AssertionError' in r.stderr and not any(x in r.stderr for x in ['FileNotFoundError','ModuleNotFoundError','SyntaxError']);rows.append({'name':label,'target':name,'actualExit':r.returncode,'assertionRejected':detected});assert detected,(label,r.stderr);print(label,r.returncode,flush=True)
mutate('wrong-executed-ui-source','ui-quality-execution.json',lambda x:x.update(sourceCommit='0'*40))
mutate('failed-root-execution','root-quality-execution.json',lambda x:x.update(actualExit=1))
mutate('reduced-ui-total','ui-quality.log',lambda x:x.replace('3779 passed, 3779 total','1 passed, 1 total'),False)
mutate('hidden-ui-skip','ui-quality.log',lambda x:x.replace('3779 passed, 3779 total','1 skipped, 3778 passed, 3779 total'),False)
mutate('hidden-ui-failure','ui-quality.log',lambda x:x+'\nFAIL controlled-hidden-test.ts\n',False)
mutate('wrong-formal-source','assurance-committed/report.json',lambda x:x['provenance'].update(revision='0'*40))
mutate('corrupt-source-fingerprint','assurance-committed/sources.json',lambda x:x['files'].update({next(iter(x['files'])):'0'*64}))
mutate('false-global-proof','assurance-committed/report.json',lambda x:x['metrics']['requirements'].update(PROVEN=1,UNPROVEN=160))
mutate('unexpected-browser-result','browser-current/results.json',lambda x:x['stats'].update(unexpected=1))
def attachment(value,name,key,replacement):
 if isinstance(value,dict):
  if value.get('name')==name and 'body' in value:
   v=json.loads(base64.b64decode(value['body']));v[key]=replacement;value['body']=base64.b64encode(json.dumps(v).encode()).decode();return True
  return any(attachment(v,name,key,replacement) for v in value.values())
 if isinstance(value,list):return any(attachment(v,name,key,replacement) for v in value)
 return False
def replace_audio(x):assert attachment(x,'torrent-audio-evidence','wholeBytes',1)
def replace_cleanup(x):assert attachment(x,'browser-component-lifecycle','destroyed',False)
mutate('wrong-actual-audio-bytes','browser-current/results.json',replace_audio)
mutate('failed-component-cleanup','component-browser-results.json',replace_cleanup)
mutate('tampered-semantic-log','mutation-reply-bound.log',lambda x:x.replace('15000','15001'),False)
mutate('false-ci-mutant-pass','ci-mutation-controls.json',lambda x:next(r for r in x['records'] if r['actualExit']==1).update(actualExit=0))
mutate('unbound-independent-review','independent-applied-v4-review-bindings.json',lambda x:x['currentSourceHashes'].update({'tdf-hq-ui/src/utils/torrentWorker.ts':'0'*64}))
after=run('restored-valid-after');assert after.returncode==0,after.stderr
result={'sourceCommit':json.loads((o/'source-state.json').read_text())['sourceCommit'],'driverSha256':hashlib.sha256(code.encode()).hexdigest(),'validBeforeActualExit':0,'restoredValidAfterActualExit':0,'assertionRejectedCorruptions':len(rows),'cases':rows,'scope':'Finite copied evidence corruptions; actual source/Git untouched; expected failures must be assertion-based, not tool/file/parser errors. No exhaustive verifier or cryptographic authenticity proof.'};(o/'seal-binding-controls.json').write_text(json.dumps(result,indent=2)+'\n');shutil.rmtree(d);print('ASSERTION_REJECTIONS',len(rows),flush=True)
