from pathlib import Path
import subprocess,json,os,shutil,hashlib,datetime,signal
w=Path('/private/tmp/tdf-torrent-worker-control-20261031T0826');o=Path('/private/tmp/tdf-torrent-worker-control-qualification-20261031T0826');f=o/'mutation-fixture';f.mkdir(exist_ok=True)
for name in ['scripts/__tests__/torrent-fixture-lifecycle.test.mjs','e2e/torrent-audio/fixture-server.mjs','scripts/__tests__/torrent-worker-routing.test.mjs','tdf-hq-ui/public/webtorrent-sw.min.js','tdf-hq-ui/src/utils/torrentWorker.ts','tdf-hq-ui/src/utils/torrentWorker.test.ts','tdf-hq-ui/package.json','tdf-hq-ui/jest.config.cjs','tdf-hq-ui/jest.polyfills.cjs','tdf-hq-ui/tsconfig.json','tdf-hq-ui/tsconfig.jest.json']:
 p=f/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(w/name,p)
for source,target in [(w/'node_modules',f/'node_modules'),(w/'tdf-hq-ui/node_modules',f/'tdf-hq-ui/node_modules')]:
 if not target.exists():target.symlink_to(source,target_is_directory=True)
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG']};env.update(PATH='/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin',SKIP_UNRS_RESOLVER_FALLBACK='1',NODE_OPTIONS='--experimental-vm-modules')
node=['node','--test','scripts/__tests__/torrent-worker-routing.test.mjs'];jest=['node','node_modules/jest/bin/jest.js','--config','tdf-hq-ui/jest.config.cjs','--runInBand','--runTestsByPath',str(f/'tdf-hq-ui/src/utils/torrentWorker.test.ts')]
rows=[]
def run(name,cmd,expect,needle=None):
 with (o/(name+'.log')).open('w') as log:
  p=subprocess.Popen(cmd,cwd=f,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=p.wait(timeout=35)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=5);raise
 body=(o/(name+'.log')).read_text();assert code==expect,(name,code);assert not needle or needle in body,(name,needle)
 rows.append({'name':name,'actualExit':code,'expectedExit':expect,'assertionMarker':needle,'logSha256':hashlib.sha256(body.encode()).hexdigest()});print(name,code,flush=True)
run('mutation-node-valid-before',node,0);run('mutation-jest-valid-before',jest,0)
worker=f/'tdf-hq-ui/public/webtorrent-sw.min.js';ts=f/'tdf-hq-ui/src/utils/torrentWorker.ts'
variants=[('mutation-broadcast-controlled-request',worker,"const targets = event.clientId\n      ? [await clients.get(event.clientId)].filter(Boolean)\n      : await clients.matchAll({ type: 'window', includeUncontrolled: true });","const targets = await clients.matchAll({ type: 'window', includeUncontrolled: true });",node,'Expected values to be strictly equal'),('mutation-url-substring',worker,'if (!url.startsWith(prefix)) return;','if (!url.includes(prefix)) return;',node,'Expected values to be strictly equal'),('mutation-reply-bound',worker,'setTimeout(() => finish(null), 15_000)','setTimeout(() => finish(null), 15_001)',node,'15000'),('mutation-disable-claim-message',worker,"event.data?.type === 'tdf-torrent-claim'","event.data?.type === 'disabled-claim'",node,'Expected values to be strictly equal'),('mutation-activation-without-control',ts,"registration.active?.state === 'activated' && container.controller === registration.active","registration.active?.state === 'activated'",jest+['--testNamePattern','waits for activation and exact page control'],'Expected: false'),('mutation-drop-postlookup-guard',ts,'const existing = await container.getRegistration(TORRENT_WORKER_SCOPE);\n  assertOwnedWorker(container.controller, scriptUrl);','const existing = await container.getRegistration(TORRENT_WORKER_SCOPE);',jest+['--testNamePattern','rechecks foreign takeover after'],'Expected number of calls: 0'),('mutation-drop-state-observer',ts,"worker.addEventListener('statechange', check);","// deliberate removed state observer",jest+['--testNamePattern','observes a replacement controller'],'Expected: true'),('mutation-disable-own-claim',ts,"worker.postMessage({ type: 'tdf-torrent-claim' });","worker.postMessage({ type: 'ignored-claim' });",jest+['--testNamePattern','requests a claim once'],'tdf-torrent-claim')]
for name,p,old,new,cmd,needle in variants:
 original=p.read_text();assert original.count(old)==1,(name,original.count(old));p.write_text(original.replace(old,new))
 try:run(name,cmd,1,needle)
 finally:p.write_text(original)
lifecycle=['node','--test','scripts/__tests__/torrent-fixture-lifecycle.test.mjs']
run('mutation-resource-valid-before',lifecycle,0)
p=f/'e2e/torrent-audio/fixture-server.mjs';original=p.read_text();old='finally { await fixture.close(); }';assert original.count(old)==1;p.write_text(original.replace(old,'finally { /* deliberate omitted owned cleanup */ }'))
try:run('mutation-omit-fixture-finally',lifecycle,1,'Missing expected rejection')
finally:p.write_text(original)
run('mutation-resource-valid-after',lifecycle,0)
run('mutation-node-valid-after',node,0);run('mutation-jest-valid-after',jest,0)
result={'sourcePhase':'PRECOMMIT explicit frozen input hashes; final correspondence must bind the same files to source commit','inputs':{str(p.relative_to(f)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [worker,ts,f/'scripts/__tests__/torrent-worker-routing.test.mjs',f/'tdf-hq-ui/src/utils/torrentWorker.test.ts',f/'scripts/__tests__/torrent-fixture-lifecycle.test.mjs',f/'e2e/torrent-audio/fixture-server.mjs']},'deliberateSemanticFaults':9,'results':rows,'scope':'Isolated minimal test fixture with explicit dependency aliases only outside active source worktree; no active-source mutations, no production/peers or proof claim. Each mutated command must exit1 with intended assertion; no infrastructure error/timeout accepted.','completedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/'mutation-controls.json').write_text(json.dumps(result,indent=2)+'\n')
