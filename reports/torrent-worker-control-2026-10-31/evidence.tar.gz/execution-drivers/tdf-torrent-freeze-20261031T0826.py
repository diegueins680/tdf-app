from pathlib import Path
import json,subprocess,os,datetime,hashlib
w=Path('/private/tmp/tdf-torrent-worker-control-20261031T0826');o=Path('/private/tmp/tdf-torrent-worker-control-qualification-20261031T0826');parent='609776108e346fabb59ea0073d19e2f0bf9b9222'
def git(*args):return subprocess.check_output(['git',*args],cwd=w)
a=json.loads(git('show',parent+':formal/system/requirements.json'))['requirements'];b=json.loads((w/'formal/system/requirements.json').read_text())['requirements'];assert len(a)==160 and len(b)==161 and a[:159]==b[:159];v=dict(a[-1]);v['statement']=b[-2]['statement'];assert v==b[-2]
q=json.loads((o/'metadata-results.json').read_text())['actualExits'];assert set(q)=={'strict-catalog-csv','inventory','conformance','inventory-check','conformance-check'} and all(v==0 for v in q.values());assert 'actualexit 0' not in (o/'initial-strict-catalog-json.log').read_text() # raw tool stdout is in driver; JSON below validates actual output
catalog=json.loads((w/'docs/catalog-persistence/reports/static-list-inventory.json').read_text());assert catalog['candidateCount']==1367 and all(c['decision']!='unreviewed' for c in catalog['candidates'])
mut=json.loads((o/'mutation-controls.json').read_text());assert mut['deliberateSemanticFaults']==9 and all(x['actualExit']==x['expectedExit'] for x in mut['results']);assert len([x for x in mut['results'] if x['actualExit']==1])==9
for p,h in mut['inputs'].items():assert hashlib.sha256((w/p).read_bytes()).hexdigest()==h,p
review=json.loads((o/'independent-applied-v4-review-bindings.json').read_text());print('Review binding fields',list(review),flush=True)
assert (o/'independent-applied-v4-review.txt').read_text().startswith('ACCEPT')
subprocess.run(['git','diff','--check'],cwd=w,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=w,check=True)
subprocess.run(['git','add','docs/catalog-persistence/reports/static-list-inventory.json','docs/catalog-persistence/reports/list-consumer-matrix.csv','formal/system/inventory.json','formal/system/traceability.json'],cwd=w,check=True)
assert all(x[:2] not in ['??',' M','AM','MM'] for x in git('status','--porcelain').decode().splitlines())
subprocess.run(['git','commit','-m','fix: control torrent playback pages and route streams to their owning tab'],cwd=w,check=True)
m=git('rev-parse','HEAD').decode().strip();assert git('show','-s','--format=%P',m).decode().split()==[parent] and not git('status','--porcelain').strip()
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env.update(PATH='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1')
checks={}
for label,cmd in [('source-admission',['python3','scripts/check-new-specification-surfaces.py','--base',parent,'--head',m]),('source-ci-selection',['node','scripts/ci-change-scope.mjs','--base',parent,'--head',m])]:
 with (o/(label+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 checks[label]=r.returncode;assert r.returncode==0,label
state={'baselineMain':'234ff6f7faf1aecf347c8e92a374228f4ec07aaa','parent':parent,'sourceCommit':m,'all159EarlierNormsExact':True,'ownedVendorNormOnlyStatementAmended':True,'requirements':161,'catalogCandidateCount':1367,'catalogAllReviewed':True,'metadataActualExits':q,'committedChecks':checks,'sourceClean':True,'completedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/'source-state.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(state),flush=True)
