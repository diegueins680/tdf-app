from pathlib import Path
import subprocess,json,os,time,shutil,datetime
w=Path('/private/tmp/tdf-torrent-worker-control-20261031T0826');o=Path('/private/tmp/tdf-torrent-worker-control-qualification-20261031T0826')
lines=subprocess.check_output(['ps','-axo','pid,command'],text=True).splitlines();pids=[int(line.split(None,1)[0]) for line in lines if line.strip().endswith('tdf-torrent-qualify-20261031T0826.py ui')]
print('Waiting for existing exact-c9 full UI gate before metadata/test-only repair',pids,flush=True)
for _ in range(1200):
 alive=[]
 for pid in pids:
  try:os.kill(pid,0);alive.append(pid)
  except ProcessLookupError:pass
 if not alive:break
 time.sleep(1)
else:raise RuntimeError('UI gate wait exceeded20minutes')
r=json.loads((o/'ui-quality-execution.json').read_text());assert r['actualExit'] in (0,1) and r['sourceCommit']=='c9b2c63e45b96ff89668a3077c06357c8cfc7df2';assert not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
shutil.copy2(o/'ui-quality-execution.json',o/'initial-source-c9/ui-quality-execution.json')
p=w/'scripts/__tests__/ci-pipeline.test.mjs';s=p.read_text();old='  assert.match(workflow, /path: artifacts\\/persona-playwright/);';assert s.count(old)==1;s=s.replace(old,"""  const torrentCommand = 'node node_modules/@playwright/test/cli.js test --config=playwright.torrent-audio.config.mjs';
  const torrentStep = job.steps.find(step => step.run === torrentCommand);
  assert.ok(torrentStep);
  assert.equal(torrentStep.if, undefined);
  assert.equal(torrentStep['continue-on-error'] ?? false, false);
  assert.equal(job['continue-on-error'] ?? false, false);
  const { default: torrentConfig } = await import(pathToFileURL(path.join(root, 'playwright.torrent-audio.config.mjs')));
  assert.deepEqual(torrentConfig.projects.map(project => project.name), ['chromium', 'firefox', 'webkit']);
  assert.equal(torrentConfig.retries, 0);
  const browserEvidence = job.steps.find(step => step.name === 'Upload sanitized browser evidence');
  assert.equal(browserEvidence.uses, 'actions/upload-artifact@v7');
  assert.equal(browserEvidence.if, 'always()');
  assert.deepEqual(browserEvidence.with.path.trim().split(/\\r?\\n/), ['artifacts/persona-playwright', 'artifacts/torrent-audio-browser']);
  assert.equal(browserEvidence.with['retention-days'], 14);""");p.write_text(s)
p=w/'formal/system/requirements.json';r=json.loads(p.read_text());assert len(r['requirements'])==161;r['requirements'][-1]['tests'].append('scripts/__tests__/ci-pipeline.test.mjs');p.write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n')
subprocess.run(['git','add','scripts/__tests__/ci-pipeline.test.mjs','formal/system/requirements.json'],cwd=w,check=True)
(o/'fixture-repair-state.json').write_text(json.dumps({'phase':'TEST_AND_TRACEABILITY_ONLY_CORRECTION','qualifiedUICommit':'c9b2c63e45b96ff89668a3077c06357c8cfc7df2','uiActualExit':json.loads((o/'ui-quality-execution.json').read_text())['actualExit'],'appSourceChanged':False,'ciWorkflowChanged':False,'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env.update(PATH='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1')
cmds=[('pipeline-fixture',['node','--test','scripts/__tests__/ci-pipeline.test.mjs']),('final-catalog-json',['node','scripts/catalog-list-audit.mjs','--decisions','docs/catalog-persistence/catalog-list-decisions.json','--fail-on-unreviewed','--output','docs/catalog-persistence/reports/static-list-inventory.json']),('final-catalog-csv',['node','scripts/catalog-list-audit.mjs','--decisions','docs/catalog-persistence/catalog-list-decisions.json','--fail-on-unreviewed','--format','csv','--output','docs/catalog-persistence/reports/list-consumer-matrix.csv']),('final-inventory',['python3','scripts/specification-inventory.py']),('final-conformance',['python3','scripts/specification-conformance.py']),('final-inventory-check',['python3','scripts/specification-inventory.py','--check']),('final-conformance-check',['python3','scripts/specification-conformance.py','--check'])]
results={}
for label,cmd in cmds:
 with (o/(label+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
 results[label]=r.returncode;print(label+' actualexit '+str(r.returncode),flush=True);(o/'final-metadata-results.json').write_text(json.dumps({'actualExits':results},indent=2)+'\n');assert r.returncode==0,label
