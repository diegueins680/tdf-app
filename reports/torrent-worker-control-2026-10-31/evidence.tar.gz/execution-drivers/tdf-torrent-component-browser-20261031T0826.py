from pathlib import Path
import subprocess,json,os,datetime,time,signal
w=Path('/private/tmp/tdf-torrent-worker-control-20261031T0826');o=Path('/private/tmp/tdf-torrent-worker-control-qualification-20261031T0826');m=json.loads((o/'source-state.json').read_text())['sourceCommit'];print('Waiting for fresh final-source canonical UI gate and build',m,flush=True)
for _ in range(1800):
 p=o/'ui-quality-execution.json'
 if p.exists():
  r=json.loads(p.read_text())
  if r['sourceCommit']==m:assert r['actualExit']==0,r;break
 time.sleep(1)
else:raise RuntimeError('No final-source successful UI gate within30minutes')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip()==m and not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL']};env.update(PATH='/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin',SKIP_UNRS_RESOLVER_FALLBACK='1')
cmd=['node','node_modules/@playwright/test/cli.js','test','--config='+str(o/'playwright.component-browser.config.mjs')];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (o/'component-browser.log').open('w') as log:
 p=subprocess.Popen(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=p.wait(timeout=180)
 except BaseException:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
  raise
r={'sourceCommit':m,'command':cmd,'actualExit':code,'startedAtUTC':start,'finishedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/'component-browser-execution.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True);assert code==0
b=json.loads((o/'component-browser-results.json').read_text());assert b['stats']['expected']==2 and b['stats']['unexpected']==b['stats']['skipped']==b['stats']['flaky']==0
