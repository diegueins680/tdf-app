from pathlib import Path
import shutil,subprocess,json,os,hashlib
w=Path('/private/tmp/tdf-torrent-worker-control-20261031T0826');o=Path('/private/tmp/tdf-torrent-worker-control-qualification-20261031T0826');f=o/'ci-mutation-fixture';f.mkdir(exist_ok=True)
for name in ['scripts/__tests__/ci-pipeline.test.mjs','scripts/ci-change-scope.mjs','.github/workflows/ci.yml','playwright.config.mjs','playwright.torrent-audio.config.mjs']:
 p=f/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(w/name,p)
assert 'browserEvidence.with.path.trim()' in (f/'scripts/__tests__/ci-pipeline.test.mjs').read_text()
if not (f/'node_modules').exists():(f/'node_modules').symlink_to(w/'node_modules',target_is_directory=True)
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG']};env['PATH']='/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin'
cmd=['node','--test','--test-name-pattern=persona browser journeys are artifacted','scripts/__tests__/ci-pipeline.test.mjs'];rows=[]
def run(label,expected):
 r=subprocess.run(cmd,cwd=f,env=env,capture_output=True,text=True,timeout=20);body=r.stdout+r.stderr;(o/(label+'.log')).write_text(body);assert r.returncode==expected,(label,r.returncode,body[:200]);assert expected==0 or ('ERR_ASSERTION' in body and not any(x in body for x in ['Cannot find module','SyntaxError','ERR_MODULE_NOT_FOUND']))
 rows.append({'name':label,'actualExit':r.returncode,'expectedExit':expected,'logSha256':hashlib.sha256(body.encode()).hexdigest()});print(label,r.returncode,flush=True)
run('mutation-ci-valid-before',0);p=f/'.github/workflows/ci.yml';original=p.read_text()
for label,old,new in [('mutation-ci-drop-persona-artifact','            artifacts/persona-playwright\n',''),('mutation-ci-drop-torrent-artifact','            artifacts/torrent-audio-browser\n',''),('mutation-ci-drop-torrent-command','      - name: Verify actual torrent audio worker and streaming lifecycle\n        run: node node_modules/@playwright/test/cli.js test --config=playwright.torrent-audio.config.mjs\n\n',''),('mutation-ci-success-only-artifact','      - name: Upload sanitized browser evidence\n        if: always()','      - name: Upload sanitized browser evidence\n        if: success()')]:
 assert original.count(old)==1;p.write_text(original.replace(old,new))
 try:run(label,1)
 finally:p.write_text(original)
for label,old,new in [('mutation-ci-job-ignore-failure','  persona-web-e2e:\n','  persona-web-e2e:\n    continue-on-error: true\n'),('mutation-ci-step-ignore-failure','      - name: Verify actual torrent audio worker and streaming lifecycle\n','      - name: Verify actual torrent audio worker and streaming lifecycle\n        continue-on-error: true\n'),('mutation-ci-step-disabled','      - name: Verify actual torrent audio worker and streaming lifecycle\n','      - name: Verify actual torrent audio worker and streaming lifecycle\n        if: false\n')]:
 assert original.count(old)==1;p.write_text(original.replace(old,new))
 try:run(label,1)
 finally:p.write_text(original)
p=f/'playwright.torrent-audio.config.mjs';original=p.read_text()
for label,old,new in [('mutation-ci-drop-webkit',"    { name: 'webkit', use: { ...devices['Desktop Safari'] } },\n",''),('mutation-ci-enable-retries','workers: 1, retries: 0','workers: 1, retries: 1')]:
 assert original.count(old)==1;p.write_text(original.replace(old,new))
 try:run(label,1)
 finally:p.write_text(original)
run('mutation-ci-valid-after',0)
r={'inputs':{name:hashlib.sha256((w/name).read_bytes()).hexdigest() for name in ['scripts/__tests__/ci-pipeline.test.mjs','scripts/ci-change-scope.mjs','.github/workflows/ci.yml','playwright.config.mjs','playwright.torrent-audio.config.mjs']},'deliberateSemanticFaults':9,'records':rows,'scope':'Isolated copied static CI fixtures with owned dependency alias only outside active source; all nine faults require actualexit1 ERR_ASSERTION; validbefore/after0; no workflow execution or universal proof.'};(o/'ci-mutation-controls.json').write_text(json.dumps(r,indent=2)+'\n')
