from pathlib import Path
import subprocess,json,hashlib,re,datetime,base64,collections
w=Path('/private/tmp/tdf-torrent-worker-control-20261031T0826');o=Path('/private/tmp/tdf-torrent-worker-control-qualification-20261031T0826');sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args,cwd=w):return subprocess.check_output(['git',*args],cwd=cwd)
p=json.loads((o/'source-state.json').read_text());m=p['sourceCommit'];parent=p['parent'];assert git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip()
qualified_ui='c9b2c63e45b96ff89668a3077c06357c8cfc7df2'
assert git('diff','--name-only',qualified_ui,m,'--','tdf-hq-ui').decode().splitlines()==['tdf-hq-ui/src/components/StudioGallery.test.tsx']
for path in ['e2e/torrent-audio','e2e/web/webtorrent-browser.spec.mjs','playwright.torrent-audio.config.mjs','scripts/build-torrent-audio-fixture.mjs','scripts/quality-ui.sh','scripts/__tests__/ui-validation-bundle.test.mjs','scripts/__tests__/torrent-worker-routing.test.mjs','scripts/__tests__/torrent-fixture-lifecycle.test.mjs','scripts/check-browser-vendor.mjs','package.json','package-lock.json','audit-ci.jsonc']:
 assert git('rev-parse',m+':'+path)==git('rev-parse',qualified_ui+':'+path),path
expected={'ui-quality','root-quality','browser-vendor-live','production-audit','torrent-node','torrent-browser','inventory-check','conformance-check','assurance','component-browser'};exits={}
for label in sorted(expected):
 r=json.loads((o/(label+'-execution.json')).read_text());assert r['sourceCommit']==(qualified_ui if label in {'torrent-node','torrent-browser','browser-vendor-live','production-audit'} else m) and r['actualExit']==0,label;exits[label]=r['actualExit']
f=json.loads((o/'assurance-committed/report.json').read_text());s=json.loads((o/'assurance-committed/sources.json').read_text());assert f['execution']['passed'] and f['provenance']['revision']==s['revision']==m and not s['worktreeDirty'];assert s['digest']==sha(json.dumps(s['files'],sort_keys=True).encode())
for key in ['files','digest','revision','mobileGitlink','worktreeDirty']:assert f['provenance'][key]==s[key]
counts={'PROVEN':0,'REFUTED':0,'UNPROVEN':161,'NOT_APPLICABLE':0};assert f['metrics']['requirements']==counts
for cat in ['implementation','refinement']:assert f['metrics']['obligationsByCategory'][cat]==counts
for cat,n in [('source-derived-SMT',4),('source-derived-authorization-SMT',3),('source-derived-recovery-SMT',4)]:assert f['metrics']['obligationsByCategory'][cat]=={'PROVEN':n,'REFUTED':0,'UNPROVEN':0,'NOT_APPLICABLE':0}
assert f['release']['decision']=='BLOCKED' and f['release']['executionAllowed'] is False
mobile=git('rev-parse',m+':tdf-mobile').decode().strip();assert git('rev-parse','HEAD',cwd=w/'tdf-mobile').decode().strip()==mobile
for ism in [False,True]:
 pairs=[(path,h) for path,h in s['files'].items() if path.startswith('tdf-mobile/')==ism]
 if not pairs:continue
 cwd=w/'tdf-mobile' if ism else w;ref=mobile if ism else m;refs=[ref+':'+(path.removeprefix('tdf-mobile/') if ism else path) for path,h in pairs];raw=subprocess.check_output(['git','cat-file','--batch'],cwd=cwd,input=('\n'.join(refs)+'\n').encode());pos=0
 for path,h in pairs:
  end=raw.index(b'\n',pos);header=raw[pos:end].split();assert header[1]==b'blob';n=int(header[2]);assert sha(raw[end+1:end+1+n])==h==sha((w/path).read_bytes()),path;pos=end+1+n+1
 assert pos==len(raw)
for path,h in f['evidenceHashes'].items():assert not Path(path).is_absolute() and '..' not in Path(path).parts and sha((o/'assurance-committed'/path).read_bytes())==h
req=json.loads(git('show',m+':formal/system/requirements.json'))['requirements'];old=json.loads(git('show',parent+':formal/system/requirements.json'))['requirements'];assert len(req)==161 and len(old)==160 and req[:159]==old[:159];n=dict(old[-1]);n['statement']=req[-2]['statement'];assert n==req[-2]
for path in ['tdf-hq','tdf-mobile','package.json','package-lock.json','tdf-hq-ui/package.json','audit-ci.jsonc','third_party/webtorrent/browser.json','third_party/webtorrent/bundled-provenance.json','tdf-hq-ui/src/vendor/webtorrent/webtorrent.min.js','tdf-hq-ui/public/third-party/webtorrent-NOTICES.txt','scripts/check-browser-vendor.mjs','scripts/__tests__/browser-vendor.test.mjs','docs/catalog-persistence/catalog-list-decisions.json']:
 assert git('rev-parse',m+':'+path)==git('rev-parse',parent+':'+path),path
assert not git('diff','--name-only',parent,m,'--','reports','formal/system/evidence').strip()
mut=json.loads((o/'mutation-controls.json').read_text());assert mut['deliberateSemanticFaults']==9
for path,h in mut['inputs'].items():assert sha(git('show',m+':'+path))==h
faults=[]
for row in mut['results']:
 log=(o/(row['name']+'.log')).read_bytes();assert sha(log)==row['logSha256'] and row['actualExit']==row['expectedExit']
 if row['actualExit']==1:
  text=log.decode();assert row['assertionMarker'] in text and not re.search(r'Cannot find module|ERR_MODULE_NOT_FOUND|SyntaxError|FileNotFoundError',text)
  assert ('ERR_ASSERTION' in text or 'Expected:' in text or 'Expected number of calls:' in text or (row['name']=='mutation-disable-own-claim' and 'expect(jest.fn()).toHaveBeenCalledWith(...expected)' in text and '-   "type": "tdf-torrent-claim"' in text and '+   "type": "ignored-claim"' in text))
  faults.append(row['name'])
assert len(faults)==9 and sum(row['actualExit']==0 for row in mut['results'])==6
for row in mut['results']:
 text=(o/(row['name']+'.log')).read_text()
 if row['actualExit']==0:
  if 'jest' in row['name']:assert re.findall(r'^Tests:.*$',text,re.M)==['Tests:       18 passed, 18 total']
  else:
   total=3 if 'resource' in row['name'] else 11
   for key,n in [('tests',total),('pass',total),('fail',0),('skipped',0)]:assert re.findall(r'^(?:#|ℹ)\s+'+key+r'\s+(\d+)\s*$',text,re.M)==[str(n)]
 else:
  failures={'mutation-broadcast-controlled-request':2,'mutation-url-substring':2,'mutation-reply-bound':1,'mutation-disable-claim-message':1,'mutation-activation-without-control':1,'mutation-drop-postlookup-guard':1,'mutation-drop-state-observer':1,'mutation-disable-own-claim':1,'mutation-omit-fixture-finally':3}
  if row['name'] in ['mutation-activation-without-control','mutation-drop-postlookup-guard','mutation-drop-state-observer','mutation-disable-own-claim']:assert re.findall(r'^Tests:.*$',text,re.M)==['Tests:       1 failed, 17 skipped, 18 total']
  else:assert re.findall(r'^(?:#|ℹ)\s+fail\s+(\d+)\s*$',text,re.M)==[str(failures[row['name']])]
ci_mut=json.loads((o/'ci-mutation-controls.json').read_text());assert ci_mut['deliberateSemanticFaults']==9
for path,h in ci_mut['inputs'].items():assert sha(git('show',m+':'+path))==h
for row in ci_mut['records']:
 text=(o/(row['name']+'.log')).read_text();assert sha(text.encode())==row['logSha256'] and row['actualExit']==row['expectedExit']
 if row['actualExit']==1:
  assert 'ERR_ASSERTION' in text and not re.search(r'Cannot find module|ERR_MODULE_NOT_FOUND|SyntaxError',text)
  assert re.findall(r'^(?:#|ℹ)\s+fail\s+(\d+)\s*$',text,re.M)==['1'];faults.append(row['name'])
assert len(faults)==18
clock=json.loads((o/'gallery-clock/clean-clock-controls.json').read_text());assert clock['candidateTestSha256']==sha(git('show',m+':tdf-hq-ui/src/components/StudioGallery.test.tsx')) and clock['originalSourceSha256']==sha(git('show',m+':tdf-hq-ui/src/components/StudioGallery.tsx'))
for row in clock['controls']:
 text=(o/'gallery-clock'/(row['name']+'.log')).read_text();assert sha(text.encode())==row['logSha256'] and row['testSha256']==clock['candidateTestSha256']
 if row['actualExit']==0:assert re.findall(r'^Tests:.*$',text,re.M)==['Tests:       3 passed, 3 total'] and row['sourceSha256']==clock['originalSourceSha256']
 else:
  count=2 if row['name']=='clean-clock-omit-close' else 1
  assert row['actualExit']==1 and re.findall(r'^Tests:.*$',text,re.M)==[f'Tests:       {count} failed, {3-count} passed, 3 total'] and 'expect(' in text;faults.append(row['name'])
assert len(faults)==20

ui=(o/'ui-quality.log').read_text();assert re.findall(r'^Test Suites:.*$',ui,re.M)==['Test Suites: 325 passed, 325 total'];assert re.findall(r'^Tests:.*$',ui,re.M)==['Tests:       3779 passed, 3779 total'];assert not re.search(r'^FAIL\s',ui,re.M)
assert '> eslint "src/**/*.{ts,tsx}" --max-warnings=0' in ui and '> tsc --noEmit -p tsconfig.app.json' in ui and 'built in' in ui
node=(o/'torrent-node.log').read_text()
for key,n in [('tests',14),('pass',14),('fail',0),('cancelled',0),('skipped',0),('todo',0)]:assert re.findall(r'^(?:#|ℹ)\s+'+key+r'\s+(\d+)\s*$',node,re.M)==[str(n)]
b=json.loads((o/'browser-current/results.json').read_text());assert b['stats']['expected']==14 and b['stats']['unexpected']==b['stats']['skipped']==b['stats']['flaky']==0
rows=[];attachments=[]
def collect(value):
 if isinstance(value,dict):
  if 'projectName' in value and 'results' in value:
   assert value['status']=='expected' and len(value['results'])==1 and value['results'][0]['status']=='passed'
   rows.append(value['projectName'])
   for a in value['results'][0].get('attachments',[]):
    if a.get('body'):attachments.append((value['projectName'],a['name'],json.loads(base64.b64decode(a['body'],validate=True))))
  for v in value.values():collect(v)
 elif isinstance(value,list):
  for v in value:collect(v)
collect(b);assert collections.Counter(rows)=={'chromium':7,'firefox':7}
streams=[v for _,name,v in attachments if name=='torrent-audio-evidence'];assert len(streams)==12
for v in streams:assert v['status']=='TESTED' and v['wholeBytes']==16044 and v['rangeBytes']==44 and v['controlledByRegistration'] and v['externalHttpAttempts']==v['webSocketAttempts']==[]
for name in ['controller-handoff','two-document-streams']:
 values=[v for _,n,v in attachments if n==name];assert len(values)==2
 for v in values:
  if name=='controller-handoff':assert v['pendingUntilClaim'] and v['nativeWebRTC'] and v['observed']['state']=='ready'
  else:assert v['firstStatus']==v['secondStatus']==200 and v['firstBytes']==v['secondBytes']==16044 and v['differentTorrentNames']
c=json.loads((o/'component-browser-results.json').read_text());assert c['stats']['expected']==2 and c['stats']['unexpected']==c['stats']['skipped']==c['stats']['flaky']==0
component_rows=[]
def collect_component(value):
 if isinstance(value,dict):
  if 'projectName' in value and 'results' in value:
   assert value['status']=='expected' and len(value['results'])==1 and value['results'][0]['status']=='passed'
   evidence=[a for a in value['results'][0].get('attachments',[]) if a['name']=='browser-component-lifecycle'];assert len(evidence)==1
   lifecycle=json.loads(base64.b64decode(evidence[0]['body'],validate=True));assert lifecycle=={'moduleType':'function','nativeWebRTC':True,'webRTC':True,'torrents':0,'workerState':'activated','scope':'/','server':True,'destroyed':True};component_rows.append(value['projectName'])
  for child in value.values():collect_component(child)
 elif isinstance(value,list):
  for child in value:collect_component(child)
collect_component(c);assert collections.Counter(component_rows)=={'chromium':1,'firefox':1}

review=json.loads((o/'independent-applied-v4-review-bindings.json').read_text());assert review['decision']=='ACCEPT_APPLIED_SOURCE_FOR_FINAL_QUALIFICATION' and review['remainingConfirmedBlockers']==0
for path,h in review['currentSourceHashes'].items():
 if path!='formal/system/requirements.json':assert sha(git('show',m+':'+path))==h,path
final_review=json.loads((o/'independent-final-source-review.json').read_text());assert final_review['sourceCommit']==m and final_review['parent']==parent and final_review['combinedVariants']==20 and final_review['combinedFailedAssertions']==25 and final_review['optionalStrictGalleryExcluded']
assert (o/'independent-final-source-review.txt').read_text().startswith('ACCEPT')
initial=json.loads((o/'initial-source-c9/ui-quality-execution.json').read_text());initial_log=(o/'initial-source-c9/ui-quality.log').read_text();assert initial['sourceCommit']==qualified_ui and initial['actualExit']==1
assert re.findall(r'^Test Suites:.*$',initial_log,re.M)==['Test Suites: 1 failed, 324 passed, 325 total'] and re.findall(r'^Tests:.*$',initial_log,re.M)==['Tests:       1 failed, 3778 passed, 3779 total']
assert set(re.findall(r'^FAIL (.*)$',initial_log,re.M))=={'src/components/StudioGallery.test.tsx'}
changed={}
for path in git('diff','--name-only','-z',parent,m).decode().strip('\0').split('\0'):
 body=git('show',m+':'+path);assert body==(w/path).read_bytes();changed[path]=sha(body)
assert sha(git('show',m+':tdf-hq-ui/src/vendor/webtorrent/webtorrent.min.js'))=='98f65d27e64f5872427544e53566bba011ace28af867ac44fc8fc08c2f92bcae'
r={'baselineMain':p['baselineMain'],'parent':parent,'sourceCommit':m,'registeredGitAndWorktreeHashesVerified':len(s['files']),'assuranceArtifactHashesVerified':len(f['evidenceHashes']),'sourceDigest':s['digest'],'allChangedSourceGitAndWorktreeHashes':changed,'all159EarlierNormsExact':True,'ownedVendorNormOnlyStatementAmended':True,'requirements':161,'criticalRequirements':sum(x.get('critical',False) for x in req),'implementationRefinementObligations':322,'wholeBackendMobileAndLocksExactParent':True,'historicalReportsAndEvidenceUnchanged':True,'allCatalogDecisionsExactParent':True,'all1367CatalogCandidatesReviewed':True,'qualifiedBrowserExecutionCommit':qualified_ui,'fullUIExecutionCommit':m,'finalSourceBrowserRuntimeInputsGitExactQualified':True,'actualExits':exits,'uiSuites':325,'uiTests':3779,'nodeCases':14,'actualBrowserCases':14,'componentBrowserCases':2,'browserStats':b['stats'],'initialFailedUIExecutionRetained':True,'independentFinalSourceReviewSha256':sha((o/'independent-final-source-review.txt').read_bytes()),'assertionDetectedSemanticFaults':faults,'browserEvidence':attachments,'formalMetrics':f['metrics'],'formalRelease':'BLOCKED','newCompleteProofs':0,'scope':'TESTED finite helper/protocol/resource/actual browser controls; no universal proof, arbitrary peer or production execution. WebKit only in pinned CI, local not executed. Empty-client-ID legacy broadcast, one active server/document, normal trusted browser/registrars and initial-reply-only bound remain explicit. Supplemental noncanonical tsconfig.json includes222 existing-test diagnostics; canonical app config is the UI gate. Native resolver uses parent physical cache with separately SRI-verified optional binding, no fresh clean install claim.','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/'source-correspondence.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ['sourceCommit','registeredGitAndWorktreeHashesVerified','assuranceArtifactHashesVerified','uiTests','formalRelease']}),flush=True)
