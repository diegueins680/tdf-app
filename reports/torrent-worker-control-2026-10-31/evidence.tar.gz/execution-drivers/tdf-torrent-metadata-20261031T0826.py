from pathlib import Path
import os,subprocess,json,datetime
w=Path('/private/tmp/tdf-torrent-worker-control-20261031T0826');o=Path('/private/tmp/tdf-torrent-worker-control-qualification-20261031T0826')
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env.update(PATH='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1')
results={}
(o/'metadata-results.json').write_text(json.dumps({'actualExits':{},'phase':'RUNNING_NEW_METADATA_CHECKS'},indent=2)+'\n')
commands=[('strict-catalog-csv',['node','scripts/catalog-list-audit.mjs','--decisions','docs/catalog-persistence/catalog-list-decisions.json','--fail-on-unreviewed','--format','csv','--output','docs/catalog-persistence/reports/list-consumer-matrix.csv']),('inventory',['python3','scripts/specification-inventory.py']),('conformance',['python3','scripts/specification-conformance.py']),('inventory-check',['python3','scripts/specification-inventory.py','--check']),('conformance-check',['python3','scripts/specification-conformance.py','--check'])]
for label,cmd in commands:
 with (o/(label+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
 results[label]=r.returncode;print(label+' actualexit '+str(r.returncode),flush=True)
 (o/'metadata-results.json').write_text(json.dumps({'actualExits':results,'completedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
 if r.returncode:break
