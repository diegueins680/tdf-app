import { defineConfig, devices } from '/private/tmp/tdf-torrent-worker-control-20261031T0826/node_modules/@playwright/test/index.mjs';
export default defineConfig({
 testDir: '/private/tmp/tdf-torrent-worker-control-20261031T0826/e2e/web',
 testMatch: 'webtorrent-browser.spec.mjs',
 captureGitInfo: { diff: false },
 fullyParallel: false, workers: 1, retries: 0, forbidOnly: true, timeout: 30_000,
 outputDir: '/private/tmp/tdf-torrent-worker-control-qualification-20261031T0826/component-browser-test-results',
 reporter: [['line'], ['json', {outputFile:'/private/tmp/tdf-torrent-worker-control-qualification-20261031T0826/component-browser-results.json'}]],
 use:{baseURL:'http://127.0.0.1:43229',trace:'retain-on-failure',screenshot:'only-on-failure'},
 webServer:{command:'npm run preview --workspace=tdf-hq-ui -- --host 127.0.0.1 --port 43229 --strictPort',cwd:'/private/tmp/tdf-torrent-worker-control-20261031T0826',url:'http://127.0.0.1:43229',reuseExistingServer:false,timeout:30000},
 projects:[{name:'chromium',use:{...devices['Desktop Chrome']}},{name:'firefox',use:{...devices['Desktop Firefox']}}]
});
