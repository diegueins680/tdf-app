from pathlib import Path
import subprocess,json,hashlib,base64,collections,re
w=Path('/private/tmp/tdf-torrent-worker-control-20261031T0826');q=Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();m='b94c353569c6219e9ef70b0feeddd7d32abe223c';parent='609776108e346fabb59ea0073d19e2f0bf9b9222'
def git(*a,cwd=w):return subprocess.check_output(['git',*a],cwd=cwd)
assert git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip()
s=json.loads((q/'assurance-committed/sources.json').read_text());f=json.loads((q/'assurance-committed/report.json').read_text());c=json.loads((q/'source-correspondence.json').read_text());assert s['revision']==f['provenance']['revision']==c['sourceCommit']==m and not s['worktreeDirty'] and f['execution']['passed']
assert s['digest']==sha(json.dumps(s['files'],sort_keys=True).encode())==c['sourceDigest'];assert len(s['files'])==1455
mobile=git('rev-parse',m+':tdf-mobile').decode().strip()
for ism in [False,True]:
 entries=[(p,h) for p,h in s['files'].items() if p.startswith('tdf-mobile/')==ism];cwd=w/'tdf-mobile' if ism else w;rev=mobile if ism else m;references=[rev+':'+(p.removeprefix('tdf-mobile/') if ism else p) for p,h in entries];raw=subprocess.check_output(['git','cat-file','--batch'],cwd=cwd,input=('\n'.join(references)+'\n').encode());at=0
 for p,h in entries:
  end=raw.index(b'\n',at);head=raw[at:end].split();assert head[1]==b'blob';n=int(head[2]);assert sha(raw[end+1:end+1+n])==h==sha((w/p).read_bytes()),p;at=end+n+2
 assert at==len(raw)
for p,h in f['evidenceHashes'].items():assert sha((q/'assurance-committed'/p).read_bytes())==h
assert f['release']['decision']=='BLOCKED' and f['release']['executionAllowed'] is False
for cat in ['implementation','refinement']:assert f['metrics']['obligationsByCategory'][cat]=={'PROVEN':0,'REFUTED':0,'UNPROVEN':161,'NOT_APPLICABLE':0}
ui=(q/'ui-quality.log').read_text();assert re.findall('^Test Suites:.*$',ui,re.M)==['Test Suites: 325 passed, 325 total'];assert re.findall('^Tests:.*$',ui,re.M)==['Tests:       3779 passed, 3779 total'];assert not re.search('^FAIL ',ui,re.M)
for label in ['ui-quality','root-quality','component-browser','assurance']:
 r=json.loads((q/(label+'-execution.json')).read_text());assert r['sourceCommit']==m and r['actualExit']==0
browserDecoded={}
for fn,expectedProjects,total in [('browser-current/results.json',{'chromium':7,'firefox':7},14),('component-browser-results.json',{'chromium':1,'firefox':1},2)]:
 report=json.loads((q/fn).read_text());assert not report['errors'] and report['stats']['expected']==total and all(report['stats'][k]==0 for k in ['unexpected','skipped','flaky']);projects=[];attachments=[]
 def collect(x):
  if isinstance(x,dict):
   if 'projectName' in x and 'results' in x:
    assert x['status']=='expected' and len(x['results'])==1;r=x['results'][0];assert r['status']=='passed' and r['retry']==0 and not r.get('errors');projects.append(x['projectName'])
    for a in r.get('attachments',[]):
     if a.get('contentType')=='application/json' and a.get('body'):attachments.append({'project':x['projectName'],'name':a['name'],'value':json.loads(base64.b64decode(a['body'],validate=True))})
   for y in x.values():collect(y)
  elif isinstance(x,list):
   for y in x:collect(y)
 collect(report);assert dict(collections.Counter(projects))==expectedProjects
 if total==2:
  assert len(attachments)==2
  for a in attachments:assert a['value']=={'moduleType':'function','nativeWebRTC':True,'webRTC':True,'torrents':0,'workerState':'activated','scope':'/','server':True,'destroyed':True}
 else:
  streams=[a for a in attachments if a['name']=='torrent-audio-evidence'];assert len(streams)==12
  for a in streams:assert a['value']['wholeBytes']==16044 and a['value']['rangeBytes']==44 and a['value']['controlledByRegistration'] and a['value']['externalHttpAttempts']==a['value']['webSocketAttempts']==[]
 browserDecoded[fn]={'actualCases':total,'projectCounts':expectedProjects,'attachments':attachments}
for path,h in c['allChangedSourceGitAndWorktreeHashes'].items():assert sha(git('show',m+':'+path))==h==sha((w/path).read_bytes())
initial=json.loads((q/'initial-source-c9/ui-quality-execution.json').read_text());assert initial['sourceCommit']=='c9b2c63e45b96ff89668a3077c06357c8cfc7df2' and initial['actualExit']==1
out={'sourceCommit':m,'parent':parent,'baselineMain':'234ff6f7faf1aecf347c8e92a374228f4ec07aaa','registeredHashesIndependentlyReverified':len(s['files']),'assuranceHashesIndependentlyReverified':len(f['evidenceHashes']),'rawUiSuites':325,'rawUiCases':3779,'rawUiSkipped':0,'decodedBrowserEvidence':browserDecoded,'sourceClean':True,'initialFailedRunRetained':True,'semanticVariantCount':20,'semanticFailedAssertions':25,'limitations':'Read-only final evidence check; no new runtime rerun. Prior private Node/gallery-control execution scopes remain separately recorded. Binding corruption results reviewed separately once ready.'};(q/'independent-final-qualification-bindings.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='decodedBrowserEvidence'},indent=2))
