import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import vm from 'node:vm';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
const require = createRequire('/private/tmp/tdf-correctness-cycle-20261028/package.json');
const ts = require('typescript');
const work = '/private/tmp/tdf-event-finance-browser-precision-fix-20261030';
const output = '/private/tmp/tdf-event-finance-csv-currency-investigation-20261030';
const main = '0bd8409f0b0bbeffdbee5cb6a0abdd09c07dafe5';
const hash = x => crypto.createHash('sha256').update(x).digest('hex');
const moneyPath = 'tdf-hq-ui/src/utils/eventFinanceMoney.ts';
const csvPath = 'tdf-hq-ui/src/utils/eventFinanceCsv.ts';
const oldPath = 'tdf-hq-ui/src/pages/SocialEventsPage.tsx';
const money = fs.readFileSync(path.join(work,moneyPath),'utf8');
const csv = fs.readFileSync(path.join(work,csvPath),'utf8');
const original = execFileSync('git',['show',main+':'+oldPath],{cwd:work,encoding:'utf8'});
function declaration(source,name){
  const tree = ts.createSourceFile('source.tsx',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
  if(tree.parseDiagnostics.length) throw new Error('Source parse failed');
  const nodes = tree.statements.filter(n=>
    (ts.isFunctionDeclaration(n)&&n.name?.text===name)||
    (ts.isVariableStatement(n)&&n.declarationList.declarations.some(d=>ts.isIdentifier(d.name)&&d.name.text===name)));
  if(nodes.length!==1) throw new Error('Nonunique actual declaration '+name);
  return nodes[0].getText(tree);
}
const guard = declaration(money,'PRECISION_ERROR')+'\n'+declaration(money,'assertSafeEventFinanceMoney');
const current = declaration(csv,'buildEventFinanceCsvRows');
const before = declaration(original,'buildEventFinanceCsvRows');
fs.writeFileSync(path.join(output,'selected-guard.ts.txt'),guard+'\n');
fs.writeFileSync(path.join(output,'selected-current-csv.ts.txt'),current+'\n');
fs.writeFileSync(path.join(output,'selected-main-csv.ts.txt'),before+'\n');
function compileAndLoad(label,source,exported){
  const stitched="const resolveRuntimeCurrency = () => 'USD';\n"+source+'\n'+(exported?'':'exports.buildEventFinanceCsvRows = buildEventFinanceCsvRows;\n');
  const compiled=ts.transpileModule(stitched,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText;
  fs.writeFileSync(path.join(output,label+'.cjs.txt'),compiled);
  const context={exports:{}};vm.runInNewContext(compiled,context,{filename:label+'.cjs'});
  return context.exports.buildEventFinanceCsvRows;
}
const buildCurrent=compileAndLoad('current',guard+'\n'+current,true);
const buildBefore=compileAndLoad('main',before,false);
const fixture={
  event:{eventId:'7',eventTitle:'Synthetic currency evidence',eventStart:'2030-01-01T12:00:00Z',eventEnd:null,eventCurrency:'USD',eventOrganizerPartyId:'42',eventArtists:[]},
  budgetLines:[],
  financeEntries:[
    {efeId:'11',efeEventId:'7',efeBudgetLineId:null,efeDirection:'income',efeSource:'manual',efeCategory:'other',efeConcept:'Synthetic void record',efeAmountCents:100,efeCurrency:'EUR',efeStatus:'void',efeExternalRef:null,efeNotes:null,efeOccurredAt:'2030-01-01T12:00:00Z',efeRecordedByPartyId:'42',efeCreatedAt:'2030-01-01T12:00:00Z',efeUpdatedAt:'2030-01-01T12:00:00Z'},
    {efeId:'12',efeEventId:'7',efeBudgetLineId:null,efeDirection:'income',efeSource:'manual',efeCategory:'other',efeConcept:'Synthetic posted record',efeAmountCents:30,efeCurrency:'USD',efeStatus:'posted',efeExternalRef:null,efeNotes:null,efeOccurredAt:'2030-01-01T12:00:00Z',efeRecordedByPartyId:'42',efeCreatedAt:'2030-01-01T12:00:00Z',efeUpdatedAt:'2030-01-01T12:00:00Z'}
  ],
  summary:{efsEventId:'7',efsCurrency:'USD',efsBudgetCents:null,efsPlannedIncomeCents:0,efsPlannedExpenseCents:0,efsActualIncomeCents:30,efsActualExpenseCents:0,efsNetCents:30,efsTicketPaidRevenueCents:0,efsTicketRefundedRevenueCents:0,efsTicketPendingRevenueCents:0,efsAccountsPayableCents:0,efsAccountsReceivableCents:0,efsContractCommittedCents:0,efsContractPaidCents:0,efsProcurementCommittedCents:0,efsProcurementPaidCents:0,efsAssetInvestmentCents:0,efsLiabilityBalanceCents:0,efsBudgetVarianceCents:null,efsBudgetUtilizationPct:null}
};
fs.writeFileSync(path.join(output,'fixture.json'),JSON.stringify(fixture,null,2)+'\n');
const argumentsFor = [fixture.event,fixture.budgetLines,fixture.financeEntries,fixture.summary];
const rows=buildCurrent(...argumentsFor),oldRows=buildBefore(...argumentsFor);
if(JSON.stringify(rows)!==JSON.stringify(oldRows))throw new Error('Unexpected difference from existing main CSV layout');
const objects=rows.slice(1).map(row=>Object.fromEntries(rows[0].map((key,index)=>[key,row[index]??null])));
const entry=objects.find(x=>x.record_type==='finance_entry'&&x.entry_id==='11');
if(entry.currency!=='USD'||entry.entry_amount_cents!==100||entry.entry_status!=='void')throw new Error('Expected substitution not reproduced');
const result={baselineMain:main,currentSourceStage:'Actual current working CSV function and guard; source hashes bound below, no repository source mutation',scope:'Actual TypeScript declarations AST-extracted/transpiled and executed in isolated Node VM, locale-default stub only. No React mount, HTTP, backend handler/database, provider or production execution.',node:process.version,typescript:ts.version,sources:{[moneyPath]:hash(money),[csvPath]:hash(csv),[oldPath+'@'+main]:hash(original)},fixtureSha256:hash(fs.readFileSync(path.join(output,'fixture.json'))),sameRowsAsOriginalMain:true,entryInputCurrency:fixture.financeEntries[0].efeCurrency,entryInputAmountCents:fixture.financeEntries[0].efeAmountCents,csvEntryRow:entry,csvContainsIndependentEntryCurrencyColumn:rows[0].some(x=>/entry.*currency/i.test(x)),confirmed:'The EUR currency attached to a 100-cent void entry is not exported; the finance_entry row instead carries currency USD with unchanged raw amount100. Original main produces identical rows.',semanticBoundary:'No explicit CSV schema was located declaring the common currency column to mean amount currency rather than event metadata. Literal code substitution/unit omission is confirmed; the minimal schema correction must state that meaning explicitly.'};
fs.writeFileSync(path.join(output,'results.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
