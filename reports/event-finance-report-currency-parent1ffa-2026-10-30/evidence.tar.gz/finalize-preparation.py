from pathlib import Path
import subprocess,json,hashlib,csv,datetime,os
w=Path('/private/tmp/tdf-event-finance-currency-parent1ffa-20261030');o=Path('/private/tmp/tdf-event-finance-currency-parent1ffa-qualification-20261030');state=json.loads((o/'preparation-state.json').read_text());old=state['baselineHead'];parent=state['parentHead'];main=state['mainSha'];sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=w)
def blob(r,p):return git('show',r+':'+p)
md=json.loads((o/'metadata-results.json').read_text());assert md['ownedAliasRemoved'] and len(md['actualExits'])==7 and all(v==0 for v in md['actualExits'].values());assert not(w/'node_modules').exists() and not(w/'node_modules').is_symlink()
checkpoint=json.loads((o/'unqualified-checkpoint.json').read_text());assert git('rev-parse','HEAD').decode().strip()==checkpoint['checkpoint'];assert git('show','-s','--format=%P','HEAD').decode().split()==[old,parent]
owned=['tdf-hq/src/TDF/Server/SocialEventsHandlers.hs','tdf-hq/test/TDF/Social/FollowHandlerSpec.hs']
for p in owned:assert (w/p).read_bytes()==blob(old,p)
subprocess.run(['git','diff','--check'],cwd=w,check=True)
subprocess.run(['git','add','docs/catalog-persistence/reports/list-consumer-matrix.csv','docs/catalog-persistence/reports/static-list-inventory.json','formal/system/inventory.json','formal/system/traceability.json'],cwd=w,check=True)
r=subprocess.run(['git','commit','--amend','--no-edit'],cwd=w,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(o/'source-commit.log').write_text(r.stdout);assert r.returncode==0,r.stdout
m=git('rev-parse','HEAD').decode().strip();assert git('show','-s','--format=%P',m).decode().split()==[old,parent] and not git('status','--porcelain').strip()
state.update(sourceCommit=m,normalParents=[old,parent],sourceCleanAtCommit=True,preparationOnly=True);(o/'preparation-state.json').write_text(json.dumps(state,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env['PATH']='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin';env['PYTHONDONTWRITEBYTECODE']='1'
py='/private/tmp/tdf-event-report-venv-20261027/bin/python';node='/Users/macpro/.nvm/versions/node/v24.13.1/bin/node';checks={}
for label,cmd in [('committed-inventory-check',[py,'scripts/specification-inventory.py','--check']),('committed-conformance-check',[py,'scripts/specification-conformance.py','--check']),('source-admission',[py,'scripts/check-new-specification-surfaces.py','--base',parent,'--head',m]),('source-ci-selection',[node,'scripts/ci-change-scope.mjs','--base',parent,'--head',m])]:
 with (o/(label+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 checks[label]=r.returncode;assert r.returncode==0,(label,r.returncode)
assert not git('status','--porcelain').strip()
assert set(git('diff','--name-only',parent,m,'--','tdf-hq').decode().splitlines())==set(owned)
for p in owned:assert blob(m,p)==blob(old,p)
for p in ['tdf-hq-ui','.github','ops','scripts','tdf-mobile','package.json','package-lock.json','tdf-hq/tdf-hq.cabal','tdf-hq/stack.yaml','tdf-hq/stack.yaml.lock','docs/catalog-persistence/catalog-list-decisions.json','formal/system/auth-predicates.json','formal/system/recovery-expiry-arithmetic.json']:
 assert git('rev-parse',m+':'+p)==git('rev-parse',parent+':'+p),p
req=json.loads(blob(m,'formal/system/requirements.json'))['requirements'];par=json.loads(blob(parent,'formal/system/requirements.json'))['requirements'];prior=json.loads(blob(old,'formal/system/requirements.json'))['requirements'];by={x['id']:x for x in req};assert len(req)==len(by)==len(par)+1==161 and all(by[x['id']]==x for x in par);assert by['PAY-EVENT-REPORT-CURRENCY-001']==next(x for x in prior if x['id']=='PAY-EVENT-REPORT-CURRENCY-001')
pre=json.loads((o/'precommit-parity.json').read_text());bindings=pre['historicalBindings'];assert len(bindings)==16
for p,row in bindings.items():
 assert sha(blob(m,p))==row['sha256']==sha((w/p).read_bytes())
 for rev in row['sourceRevisions']:assert sha(blob(rev,p))==row['sha256']
for p,rev in [('formal/system/event-finance-report-currency.md',old),('formal/system/event-finance-report-range.md',parent)]:assert blob(m,p)==blob(rev,p)
cat=json.loads((o/'current-catalog.json').read_text());assert cat['candidateCount']==1354
with (o/'current-catalog.csv').open(newline='') as f:csvrows=list(csv.DictReader(f))
assert len(csvrows)==1354
pre.update(sourceCommit=m,normalParents=[old,parent],mainSha=main,committedChecks=checks,metadataResults=md,strictJsonCandidates=1354,strictCsvRows=1354,noNewRuntimeExecuted=True,fullRootQualityExecuted=False,futureNativeMustUseForceDirty=True,sourceCleanAfter=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat());(o/'source-preparation-checks.json').write_text(json.dumps(pre,indent=2)+'\n')
print(json.dumps({k:pre[k] for k in ['sourceCommit','normalParents','parentHead','mainSha','totalRequirements','historicalUnionCount','committedChecks','sourceCleanAfter']},indent=2))
