from pathlib import Path
import subprocess,json,hashlib
w=Path('/private/tmp/tdf-event-finance-currency-parent1ffa-20261030');o=Path('/private/tmp/tdf-event-finance-currency-parent1ffa-qualification-20261030');m='340be46ca3dda5a8376edbbeca2ed59528b02d47';parent='1ffa7818204e46f9aa92e1657a12efe4a5ebd2c6';old='c3a73b9400f7bd9c27b68105bcb462d4ea7fdaf5'
def git(*a):return subprocess.check_output(['git',*a],cwd=w)
def blob(ref,p):return git('show',ref+':'+p)
assert git('rev-parse','HEAD').decode().strip()==m
assert git('show','-s','--format=%P',m).decode().split()==[old,parent]
assert not git('status','--porcelain').strip()
diff=git('diff','--name-only','-z',parent,m,'--','tdf-hq').decode().strip('\0').split('\0');assert set(diff)=={'tdf-hq/src/TDF/Server/SocialEventsHandlers.hs','tdf-hq/test/TDF/Social/FollowHandlerSpec.hs'}
for p in diff:assert blob(m,p)==blob(old,p)==(w/p).read_bytes()
a=json.loads(blob(m,'formal/system/requirements.json'));b=json.loads(blob(parent,'formal/system/requirements.json'));index={r['id']:r for r in a['requirements']};assert len(index)==161 and all(index[r['id']]==r for r in b['requirements'])
c=next(r for r in json.loads(blob(old,'formal/system/requirements.json'))['requirements'] if r['id']=='PAY-EVENT-REPORT-CURRENCY-001');assert index[c['id']]==c
oldreport=json.loads((o/'source-preparation-checks.json').read_text())['historicalBindings']
for p,v in oldreport.items():
 data=blob(m,p);assert hashlib.sha256(data).hexdigest()==v['sha256']
 for ref in v['sourceRevisions']:assert blob(ref,p)==data
for path in ['tdf-hq-ui','scripts','ops','.github','package.json','package-lock.json','tdf-mobile']:assert not git('diff','--name-only',parent,m,'--',path).strip(),path
r={'sourceCommit':m,'reviewer':'ROOT independent of agent-authored reconciliation','normalParentsExact':True,'onlyTwoOwnedBackendPathsDifferParentAndExactC3':True,'all160ParentNormsExactPlusUnchangedCurrency161':True,'historical16BlobsAllParentBindingsExact':True,'functionalParentTreesExact':True,'sourceClean':True,'initialConcurrentAliasAudit':'First read-only audit refused temporary aliases owned by root-quality; no source conclusion. Rechecked after successful root-quality cleanup.','nativeQualification':'PENDING fresh force-dirty; no whole-backend-exact-C3 claim'};(o/'root-source-admission.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
