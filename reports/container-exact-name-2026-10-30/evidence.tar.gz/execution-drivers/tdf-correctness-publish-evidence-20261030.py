from pathlib import Path
import sys, json, subprocess, hashlib, tarfile, io, datetime, shutil
mode=sys.argv[1]
assert mode in ['package','cleanup','absence','name']
cfg={
 'package':{'worktree':'tdf-package-purchase-expiry-20261030','artifact':'tdf-package-purchase-expiry-qualification-20261030','private':'package-purchase-expiry-20261030','stem':'package-purchase-expiry-2026-10-30','seal':'source-correspondence.json'},
 'cleanup':{'worktree':'tdf-container-cleanup-evidence-20261030','artifact':'tdf-container-cleanup-evidence-qualification-20261030','private':'container-cleanup-evidence-20261030','stem':'container-cleanup-evidence-2026-10-30','seal':'committed-source-correspondence.json'},
 'absence':{'worktree':'tdf-container-absence-20261030','artifact':'tdf-container-absence-qualification-20261030','private':'container-absence-20261030','stem':'container-cleanup-absence-2026-10-30','seal':'committed-source-correspondence.json'},
 'name':{'worktree':'tdf-container-exact-name-20261030','artifact':'tdf-container-exact-name-qualification-20261030','private':'container-exact-name-20261030','stem':'container-exact-name-2026-10-30','seal':'committed-source-correspondence.json'}
}[mode]
w=Path('/private/tmp')/cfg['worktree']
o=Path('/private/tmp')/cfg['artifact']
private=Path('/Users/macpro/GitHub/tdf-app/.private')/cfg['private']
hand=json.loads((private/'handoff.json').read_text())
assert not hand.get('superseded'), 'Historical superseded candidate must not be published as current work'
m=json.loads((o/'preparation-state.json').read_text())['sourceCommit']
git=lambda *a:subprocess.check_output(['git',*a],cwd=w)
sha=lambda b:hashlib.sha256(b).hexdigest()
head=git('rev-parse','HEAD').decode().strip()
refresh='--refresh-own-unpublished-report' in sys.argv[2:]
assert not git('status','--porcelain').strip()
if refresh:
    assert head==hand['unpublishedReportScopeClarification']['oldHead']
    assert git('rev-parse',head+'^').decode().strip()==m
    prefix='reports/'+cfg['stem']
    assert set(git('diff','--name-only',m,head).decode().splitlines())=={prefix+'.json',prefix+'/evidence.tar.gz',prefix+'/manifest.json',prefix+'/independent-review.txt'}
else:
    assert head==m
seal=json.loads((o/cfg['seal']).read_text())
assert seal['sourceCommit']==m and seal['sourceCleanAfter']
root=json.loads((o/'root-quality-result.json').read_text())
assert root['sourceCommit']==m and all(v==0 for v in root['actualExits'].values())
formal=json.loads((o/'assurance-committed/report.json').read_text())
assert formal['execution']['passed'] and formal['provenance']['revision']==m
review=hand['finalReview']
reviewPath=Path(review['path'])
assert sha(reviewPath.read_bytes())==review['sha256']
rdir=w/'reports'/cfg['stem']
rdir.mkdir(exist_ok=refresh)
(rdir/'independent-review.txt').write_bytes(reviewPath.read_bytes())
files={}
for p in sorted(o.rglob('*')):
    assert not p.is_symlink(),p
    if p.is_file():files['qualification/'+p.relative_to(o).as_posix()]=p.read_bytes()
files['reviews/final-review.txt']=reviewPath.read_bytes()
if mode=='package':
    reviews=['tdf-package-expiry-next-review-20261030.txt','tdf-package-expiry-applied-design-review-20261030.txt','tdf-package-expiry-applied-implementation-review-20261030.txt']
    for name in reviews:files['reviews/'+name]=(Path('/private/tmp')/name).read_bytes()
    probe=Path('/private/tmp/tdf-package-expiry-probe-20261030')
    for p in sorted(probe.iterdir()):
        if p.is_file() and p.suffix in ['.json','.log','.hs']:
            files['original-component-probe/'+p.name]=p.read_bytes()
    drivers=list(Path('/private/tmp').glob('tdf-package-expiry-*-20261030.py'))
else:
    drivers=list(Path('/private/tmp').glob('tdf-container-exact-name-*-20261030.py' if mode=='name' else ('tdf-container-absence-*-20261030.py' if mode=='absence' else 'tdf-container-cleanup-*-20261030.py')))
for p in drivers:files['execution-drivers/'+p.name]=p.read_bytes()
files['execution-drivers/'+Path(__file__).name]=Path(__file__).read_bytes()
buf=io.BytesIO()
manifest=[]
with tarfile.open(fileobj=buf,mode='w:gz') as tar:
    for name,data in sorted(files.items()):
        assert not name.startswith('/') and '..' not in Path(name).parts
        info=tarfile.TarInfo(name)
        info.size=len(data);info.mtime=0;info.mode=0o644
        tar.addfile(info,io.BytesIO(data))
        manifest.append({'path':name,'sha256':sha(data),'bytes':len(data)})
blob=buf.getvalue()
(rdir/'evidence.tar.gz').write_bytes(blob)
(rdir/'manifest.json').write_text(json.dumps({'sourceCommit':m,'archiveSha256':sha(blob),'archiveBytes':len(blob),'files':manifest},indent=2)+'\n')
common={'schemaVersion':1,'dateUTC':'2026-10-30','baselineMain':'e1cec5b59723c2ff9828ac4fce45abb930d73055','sourceCommit':m,'evidenceCommit':'Containing report-only child; independently verify Git blobs and complete archive aftercommit.','rootQuality':root,'sourceSeal':seal,'formal':{'executionPassed':True,'metrics':formal['metrics'],'release':formal['release']['decision'],'newCompleteImplementationProofs':0,'scope':'Inherited conditional results retain their original assumptions; no passing test is promoted to a complete proof.'},'independentReview':{'path':str((rdir/'independent-review.txt').relative_to(w)),'sha256':review['sha256'],'scope':review['scope']},'archive':{'path':str((rdir/'evidence.tar.gz').relative_to(w)),'sha256':sha(blob),'bytes':len(blob),'innerFiles':len(manifest),'manifest':str((rdir/'manifest.json').relative_to(w))},'integration':{'draftIntended':True,'autoMerge':False,'merged':False,'deployment':'UNVERIFIED','productionWrites':False,'realProviderCalls':False,'requirements':'Fresh published-head CI/current review/main composition/protected FIFO; no bypass or borrowed approval.'},'createdAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
if mode=='package':
    native=json.loads((o/'native-quality.json').read_text());assert native['sourceCommit']==m
    force=json.loads((o/'native-force-dirty-confirmed.json').read_text());assert force['sourceCommit']==m and force['canonicalForceDirty'] and force['qualifiedCommitLiteralInVersionObjectAndTestBinary'] and force['binarySha256']==native['binarySha256']
    assert native['canonicalArtifactCurrent'] and seal['canonicalForceDirtyConfirmed']==force
    controls=json.loads((o/'controls.json').read_text());assert controls['actualVariants']==2 and controls['intendedAssertionFailures']==5
    common.update(problem='createPurchase discarded positive product validity and always persisted no expiry. The existing manual promises validity/expiry and the seed configures120days. Nonpositive handling was ambiguous until the owner explicitly selected refusal.',ownerDecisions=['Positive validity: exact stored purchasedAt plus n*86400 elapsed seconds.','Refuse zero/negative configured validity; absent value remains nonexpiring.'],correction='Snapshot expiry on new purchases and refuse invalid configured validity with409 before insertion, after existing reference/inactive checks. Two production edits only; no historical record rewrite.',properties=[{'id':'PKG-PURCHASE-EXPIRY-001/POSITIVE','status':'TESTED','statement':'A successful positive-term purchase has expiry exactly n elapsed days from its persisted purchasedAt.','bounds':'Actual1/120/365day Handler/SQLite fixtures; timestamp must fit database representation.'},{'id':'PKG-PURCHASE-EXPIRY-001/INVALID','status':'TESTED','statement':'Zero/negative configured terms refuse409 with no persisted row.','bounds':'Actual0/-1fixtures; late-refusal source fault commits a row and is detected.'},{'id':'PKG-PURCHASE-EXPIRY-001/COMPATIBILITY','status':'TESTED','statement':'Absent expiry, purchase fields and existing module/reference/inactive refusals remain.','bounds':'Finite actual Handler/SQLite fixtures and exact two-edit source reversal; no authenticatedHTTP proof.'}],baseline={'buildExit':0,'examples':11,'assertionFailures':5,'interpretation':'Three positive-term expiry counterexamples plus two owner-clarified invalid-term acceptance failures; six compatibility cases pass. Baseline invalid-term tests fail on success before their row-count assertions; baseline row counts are not claimed observed.'},native=native,forcedMetadataQualification=force,qualificationHarnessCorrection='Earlier unforced Stack call passed behavior but reused precommit binary; retained as metadata-incomplete in earlier-unforced-build. Canonical --force-dirty rerun regenerated Version and changed the binary, passed target/full tests, and was resealed. No serving executable claim.',sourceControls=controls,regressionProtection='11 real-handler cases registered through the existing ServerSpec/Cabal lane; same test bytes across baseline,controls and qualifiedsource. Wrong-unit fault3actualdateassertions, late-refusal fault2actualrowcountassertions; restored11/0.',remaining=['Very large durations/database timestamp-range admission and concurrent product-edit snapshot policy remain separate.','No new charge/payment/actor/gift/redemption/idempotency policy, real incident claim or historicaldata correction.','No actual production PostgreSQL trigger, authenticatedHTTP, serving executable or deployment qualification.','Original two-case probe linked unchanged qualified M3 objects with relevant source exactmainE1; compile/interface setup failures were not product counterexamples. Final canonical Stack artifact separately qualified current source.'],nextHighestValueTask='Normal current-head CI/review/FIFO integration and investigation of actual hosted cleanup response once diagnostic source is qualified.')
elif mode=='cleanup':
    controls=json.loads((o/'controls.json').read_text());assert len(controls['variants'])==4 and controls['restored']['tests']==10 and controls['restored']['exit']==0
    common.update(problem='PR677 hostedCI41009219715/job123911806221 received an unexpected cleanup inspect response but replaced it with a constant error, dropping command status/output. The original response and cause remainUNKNOWN.',correction='Retain a bounded diagnostic in the existing refusal: operation, synthetic name, exit code, first2000characters of each stream/truncation flags and actually completed cases. Preserve existing exception chaining and all cleanup classifications/commands/ownership safeguards.',properties=[{'id':'SYS-VERIFY-CONTAINER-CLEANUP-001/RETENTION','status':'TESTED','statement':'Unexpected inspect refusal retains bounded response context.','bounds':'Mocked actual-main-path scenarios; no actual Docker execution.'},{'id':'SYS-VERIFY-CONTAINER-CLEANUP-001/PRESERVATION','status':'TESTED','statement':'Existing failure/absence handling, foreign no-delete, verified-ID deletion and primary exception display remain.','bounds':'Mocked actual-main scenarios, four source controls and exact declared-edit reversal; no universal absence-classifier or forced-termination cleanup proof.'}],verification={'implementerSimulatedCases':10,'independentRootSimulatedCases':10,'independentExistingShellCases':2,'actualDockerExecutedLocally':False,'sourceControls':controls,'normalCIProtection':'New stdlib suite registered in quality-repo.sh; original real Docker lane retained.','harnessHistory':'Initial independent Node shell suite failed to import yaml before cachealias; proper scoped dependencyalias rerun2/0. Initial failure retained and not counted as product defect.'},regressionProtection='Actual runner main is exercised with every Docker subprocess and Git query intercepted. Four selected faulty sources each cause one intended assertion failure/zeroerrors; restored10/0. No mock result is an actual Linux/container pass.',remaining=['Original hosted Docker response/cause and primary-case outcomes remainUNKNOWN; this is diagnostic retention, not Docker/storage repair.','Existing absence substring classification is preserved rather than proved universally correct.','Stream retention limits do not bound subprocess capture memory; malformed JSON/remove/timeouts retain prior behavior.','MEDIA-PERSIST-001 production durability, actual hosted Docker execution and deployment remain separate; its requirement is unchanged.','PR676 UbuntuRACI change remains separate; new source must qualify normally without retrying an unchanged failure into a repair claim.'],nextHighestValueTask='Inspect the first actual hosted response on the diagnostic head and repair its evidenced root cause; retain all security/cleanup refusals.')
elif mode=='absence':
    controls=json.loads((o/'controls.json').read_text())
    assert len(controls['variants'])==8 and sum(v['assertionFailures'] for v in controls['variants'])==23 and controls['restored']['tests']==17 and controls['restored']['exit']==0
    domain=json.loads((o/'publication-domain.json').read_text())
    assert not set(domain).intersection(common),set(domain).intersection(common)
    common.update(domain)
else:
    controls=json.loads((o/'controls.json').read_text())
    assert controls['sourceRestored'] and controls['corrected']['tests']==controls['restored']['tests']==13 and controls['restored']['exit']==0 and controls['guardRemoval']['assertionFailures']==1
    domain=json.loads((o/'publication-domain.json').read_text())
    assert not set(domain).intersection(common),set(domain).intersection(common)
    common.update(domain)
(w/'reports'/(cfg['stem']+'.json')).write_text(json.dumps(common,indent=2)+'\n')
print(json.dumps({'mode':mode,'sourceCommit':m,'archiveBytes':len(blob),'innerFiles':len(manifest),'archiveSha256':sha(blob)},indent=2))

