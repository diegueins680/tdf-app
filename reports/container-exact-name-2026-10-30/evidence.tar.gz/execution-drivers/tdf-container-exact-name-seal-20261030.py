"""Seal the parent-based exact-name follow-up; no tests, Docker or remote calls."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

W = Path('/private/tmp/tdf-container-exact-name-20261030')
O = Path('/private/tmp/tdf-container-exact-name-qualification-20261030')
PARENT = 'b99e3543c02294179858282a326fc4912eb80002'
OBSERVED_MAIN = '0bd8409f0b0bbeffdbee5cb6a0abdd09c07dafe5'
REQ = 'SYS-VERIFY-CONTAINER-CLEANUP-001'
RUNNER = 'scripts/test-persistent-uploads-container.py'
TEST = 'scripts/test-persistent-uploads-container-diagnostics.py'
CONTRACT = 'formal/system/container-cleanup-evidence.md'
FIELDS = {'statement', 'property', 'verification', 'evidence', 'confidence', 'ambiguity'}
REVIEWED_FIELDS_SHA256 = 'dddd5e835aeea6fe5765f48cb8f6167c42cac1b6df2d5d25f72f33e58e549894'
REVIEWED_PRIMARY_CERTIFICATE_SHA256 = 'a72584f7846ef851adbbe75e71a8bbfdffc14fad707907d1514658b870319dae'


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def git(*args, cwd=W):
    return subprocess.check_output(['git', *args], cwd=cwd)


def blob(revision, path):
    return git('show', revision + ':' + path)


def clean_at(revision):
    require(git('rev-parse', 'HEAD').decode().strip() == revision, 'HEAD changed')
    require(not git('status', '--porcelain').strip(), 'Source is not clean')


def indexed(rows):
    result = {row['id']: row for row in rows}
    require(len(result) == len(rows), 'Duplicate requirement IDs')
    return result


def verify_sources(files, revision, mobile):
    for is_mobile in (False, True):
        pairs = [(p, h) for p, h in files.items() if p.startswith('tdf-mobile/') == is_mobile]
        require(bool(pairs), 'Missing root or Mobile registered sources')
        cwd, rev = (W / 'tdf-mobile', mobile) if is_mobile else (W, revision)
        refs = [rev + ':' + (p.removeprefix('tdf-mobile/') if is_mobile else p) for p, h in pairs]
        require(all('\n' not in ref for ref in refs), 'Ambiguous Git batch path')
        raw = subprocess.check_output(['git', 'cat-file', '--batch'], cwd=cwd,
                                      input=('\n'.join(refs) + '\n').encode())
        pos = 0
        for path, digest in pairs:
            end = raw.index(b'\n', pos)
            header = raw[pos:end].split()
            require(len(header) == 3 and header[1] == b'blob', 'Missing blob: ' + path)
            size = int(header[2])
            require(sha(raw[end + 1:end + 1 + size]) == digest, 'Git hash mismatch: ' + path)
            require(sha((W / path).read_bytes()) == digest, 'FS hash mismatch: ' + path)
            pos = end + 1 + size + 1
        require(pos == len(raw), 'Unused Git batch bytes')


def unit_result(log, cases, failures):
    text = log.read_text()
    require(re.search(r'^Ran ' + str(cases) + r' tests? in ', text, re.MULTILINE),
            'Wrong test count: ' + log.name)
    require(re.search(r'^ERROR: ', text, re.MULTILINE) is None, 'Setup error: ' + log.name)
    if failures:
        require(re.search(r'^FAILED \(failures=' + str(failures) + r'\)$', text, re.MULTILINE),
                'Wrong assertion failures: ' + log.name)
        require('RuntimeError not raised' in text, 'Not the exact-name refusal assertion')
    else:
        require(text.rstrip().endswith('OK'), 'Test run did not pass: ' + log.name)


def main():
    m = read_json(O / 'preparation-state.json')['sourceCommit']
    require(re.fullmatch('[0-9a-f]{40}', m), 'Invalid source commit')
    clean_at(m)
    require(git('rev-parse', m + '^').decode().strip() == PARENT, 'Unexpected stacked source parent')
    ancestry = subprocess.run(['git', 'merge-base', '--is-ancestor', OBSERVED_MAIN, PARENT],
                              cwd=W, capture_output=True)
    require(ancestry.returncode == 1, 'Observed main/parent ancestry differs or is unavailable')
    root = read_json(O / 'root-quality-result.json')
    report = read_json(O / 'assurance-committed/report.json')
    sources = read_json(O / 'assurance-committed/sources.json')
    require(root['sourceCommit'] == m and root['actualExits']
            and all(type(code) is int and code == 0 for code in root['actualExits'].values()),
            'Current committed root qualification did not pass')
    require(root['catalogUnitCases'] == 8 and root['aliasesRemoved'] is True
            and root['sourceCleanAfter'] is True, 'Root qualification incomplete')
    require(report['execution']['passed'] is True
            and report['provenance']['revision'] == sources['revision'] == m
            and sources['worktreeDirty'] is False, 'Current clean assurance did not pass')
    require(report['provenance']['files'] == sources['files'], 'Assurance source bindings differ')
    require(report['provenance']['digest'] == sources['digest']
            == sha(json.dumps(sources['files'], sort_keys=True).encode()), 'Wrong source digest')
    mobile = git('rev-parse', m + ':tdf-mobile').decode().strip()
    require(git('rev-parse', 'HEAD', cwd=W / 'tdf-mobile').decode().strip() == mobile,
            'Mobile checkout is not pinned')
    verify_sources(sources['files'], m, mobile)
    for name, digest in report['evidenceHashes'].items():
        require(sha((O / 'assurance-committed' / name).read_bytes()) == digest,
                'Assurance artifact hash mismatch: ' + name)

    old = indexed(json.loads(blob(PARENT, 'formal/system/requirements.json'))['requirements'])
    new = indexed(read_json(W / 'formal/system/requirements.json')['requirements'])
    require(set(old) == set(new) and len(new) == 159, 'Requirement set/count changed')
    require(all(old[key] == new[key] for key in old if key != REQ), 'Unrelated requirement changed')
    before, after = old[REQ], new[REQ]
    require(set(before) == set(after), 'Selected requirement fields changed')
    require({key for key in before if before[key] != after[key]} == FIELDS,
            'Unexpected selected refinement scope')
    require(sha(json.dumps({key: after[key] for key in FIELDS}, sort_keys=True).encode())
            == REVIEWED_FIELDS_SHA256, 'Reviewed six-field refinement changed')
    for key in before:
        if key not in FIELDS:
            require(before[key] == after[key], 'Core obligation changed: ' + key)
    for key in ('forbiddenTransitions', 'authorization', 'privacy', 'failure', 'preconditions',
                'allowedTransitions', 'effects', 'implementation', 'tests'):
        require(before[key] == after[key], 'Safety boundary changed: ' + key)

    source = (W / RUNNER).read_text()
    guard = "\n            and result.stderr.strip().endswith(f': {name}')"
    require(source.count(guard) == 1, 'New exact-name guard not unique')
    new_comment = ('    # Docker diagnostic prefixes differ in capitalization; names are case-sensitive.\n'
                   '    # Admit only the exact inspected nonce name, expected failure code and empty\n'
                   '    # result; daemon/transport errors\n')
    old_comment = ('    # Docker versions differ in capitalization. Admit only the exact inspected\n'
                   '    # nonce name, expected failure code and empty result; daemon/transport errors\n')
    require(source.count(new_comment) == 1, 'Reviewed comment changed')
    reverse = source.replace(guard, '').replace(new_comment, old_comment)
    require(reverse.encode() == blob(PARENT, RUNNER), 'Unexpected runner delta')
    test_source = (W / TEST).read_text()
    method = '    def test_case_different_nonce_name_is_not_absence(self):'
    require(test_source.count(method) == 1, 'New regression not unique')
    start = test_source.index(method)
    end = test_source.index('    def test_unexpected_inspect_retains_command_result_and_completed_cases(self):', start)
    require((test_source[:start] + test_source[end:]).encode() == blob(PARENT, TEST),
            'Published twelve-test body changed')
    for path in ('tdf-hq', 'tdf-hq-ui', 'tdf-mobile', '.github', 'ops', 'package.json',
                 'package-lock.json', 'scripts/quality-repo.sh', 'formal/event-operations',
                 'formal/system/auth-predicates.json', 'formal/system/recovery-expiry-arithmetic.json',
                 'docs/catalog-persistence/catalog-list-decisions.json',
                 'reports/container-cleanup-evidence-2026-10-30.json',
                 'reports/container-cleanup-evidence-2026-10-30'):
        require(git('rev-parse', m + ':' + path) == git('rev-parse', PARENT + ':' + path),
                'Protected parent surface changed: ' + path)
    changes = git('diff', '--name-only', PARENT, m, '--', 'scripts').decode().splitlines()
    require(set(changes) == {RUNNER, TEST}, 'Unexpected material script delta')

    controls = read_json(O / 'controls.json')
    baseline = read_json(O / 'baseline.json')
    require(controls['base'] == baseline['base'] == PARENT, 'Wrong test baseline')
    require(controls['sourceRestored'] is True, 'Source not restored')
    for path, key in ((RUNNER, 'runnerSha256'), (TEST, 'testSha256')):
        require(sha((W / path).read_bytes()) == controls[key] == sha(blob(m, path)),
                'Current/control input mismatch: ' + path)
    require(baseline['exit'] == 1 and baseline['tests'] == baseline['assertionFailures'] == 1
            and baseline['runnerSha256'] == sha(blob(PARENT, RUNNER))
            and baseline['testSha256'] == controls['testSha256'], 'Wrong baseline counterexample')
    unit_result(O / 'baseline.log', 1, 1)
    for phase, name, cases, failures in (
            ('corrected', 'corrected.log', 13, 0),
            ('guardRemoval', 'omit-exact-name-guard.log', 1, 1),
            ('restored', 'restored.log', 13, 0)):
        row = controls[phase]
        require(row['exit'] == (1 if failures else 0) and row['tests'] == cases
                and row['assertionFailures'] == failures, 'Control phase result mismatch')
        require(sha((O / name).read_bytes()) == row['logSha256'], 'Raw log hash mismatch: ' + name)
        unit_result(O / name, cases, failures)
    require(sha(source.replace(guard, '').encode()) == controls['guardRemoval']['mutantSha256'],
            'Control changed more than the exact-name guard')
    unit_result(O / 'independent-root-tests.log', 13, 0)

    primary_path = O / 'primary-name-identity-sources.json'
    require(sha(primary_path.read_bytes()) == REVIEWED_PRIMARY_CERTIFICATE_SHA256,
            'Reviewed primary Git-blob/excerpt certificate changed')
    primary = read_json(primary_path)
    expected_primary = {
        ('moby/moby', 'v28.5.1', 'daemon/names/names.go'): ('27523bbd9860241d681845c2f9781c9251cdd279', [6]),
        ('moby/moby', 'v28.5.1', 'daemon/container.go'): ('d6ed255423280edf3d5d4779902c427c51e5c320', [184, 188]),
        ('moby/moby', 'v28.5.1', 'container/view.go'): ('1359371ae26936324d2c09fe37bef4379e8a2eac', [480, 492]),
        ('docker/cli', 'v29.0.0', 'cli/command/system/inspect.go'): ('8bd191e2813d869ad810a601c83f96b24f806583', [281])}
    require(len(primary) == len(expected_primary), 'Wrong primary source record count')
    for row in primary:
        key = (row['repository'], row['ref'], row['path'])
        require(key in expected_primary, 'Unknown primary source')
        digest, lines = expected_primary[key]
        require(row['gitBlobSha'] == digest and [item['line'] for item in row['excerpts']] == lines,
                'Wrong primary source identity/excerpt lines')
        require(row['url'] == 'https://github.com/' + row['repository'] + '/blob/' + row['ref'] + '/' + row['path'],
                'Wrong primary URL')
    require((W / CONTRACT).read_bytes() == blob(m, CONTRACT), 'Contract not Git-bound')
    md = (W / CONTRACT).read_text()
    for fragment in ('daemon/names/names.go#L6', 'daemon/container.go#L180-L188',
                     'container/view.go#L471-L492', 'system/inspect.go#L281', PARENT):
        require(fragment in md, 'Primary source or historical context link missing')

    metrics = report['metrics']
    require(metrics['requirements']['UNPROVEN'] == 159 and metrics['requirements']['PROVEN'] == 0,
            'Unexpected whole-requirement proof scope')
    for category in ('implementation', 'refinement'):
        require(metrics['obligationsByCategory'][category]['UNPROVEN'] == 159
                and metrics['obligationsByCategory'][category]['PROVEN'] == 0,
                'Unexpected complete implementation/refinement scope')
    require(sum(metrics['obligationsByCategory'][category]['PROVEN'] for category in
                ('source-derived-SMT', 'source-derived-authorization-SMT', 'source-derived-recovery-SMT')) == 11,
            'Inherited conditional SMT scope changed')
    require(report['release']['decision'] == 'BLOCKED', 'Unexpected formal release result')
    clean_at(m)
    evidence_names = ('baseline.json', 'baseline.log', 'controls.json', 'corrected.log',
                      'omit-exact-name-guard.log', 'restored.log', 'independent-root-tests.log',
                      'primary-name-identity-sources.json')
    record = {
        'baselineParent': PARENT, 'sourceCommit': m,
        'observedMainAtTask': OBSERVED_MAIN, 'observedMainIsAncestorOfParent': False,
        'qualificationScope': 'Stacked follow-up on parent b99; no current-main composition qualification.',
        'currentMainCompositionQualified': False, 'parentApprovalBorrowed': False,
        'newHeadGitHubApprovalClaimed': False, 'remoteMainFetchedBySeal': False,
        'registeredGitFilesystemMobileHashesVerified': len(sources['files']),
        'registeredRootCount': sum(not path.startswith('tdf-mobile/') for path in sources['files']),
        'registeredMobileCount': sum(path.startswith('tdf-mobile/') for path in sources['files']),
        'sourceDigest': sources['digest'], 'mobileGitlink': mobile,
        'all158UnrelatedParentRequirementsExact': True, 'sameRequirementsTotal': len(new),
        'selectedRequirementOnlySixReviewedFieldsRefined': sorted(FIELDS),
        'allSelectedSafetyAndFailureObligationsExact': True,
        'runnerOnlyAdditiveNameGuardAndComment': True, 'publishedTwelveTestBodyExact': True,
        'outputWhitespacePrefixCompatibilityAndForeignSafetyPreserved': True,
        'applicationWorkflowsDependenciesModelsQualityHistoricalReportArchiveExactParent': True,
        'scriptChangesOnly': changes, 'rootQuality': root,
        'implementerSimulatedCases': 13, 'rootIndependentSimulatedCases': 13,
        'baselineWrongCaseAssertionFailures': 1, 'soleNewGuardControlVariants': 1,
        'soleNewGuardControlAssertionFailures': 1, 'correctSourceRestoredAndThirteenCasesPass': True,
        'runnerSha256': controls['runnerSha256'], 'testSha256': controls['testSha256'],
        'contractGitSha256': sha((W / CONTRACT).read_bytes()),
        'separatelyBoundEvidenceSha256': {name: sha((O / name).read_bytes()) for name in evidence_names},
        'primarySourceScope': 'Retained independent Git-blob/excerpt certificate; no network re-fetch by seal.',
        'freshAssuranceMetrics': metrics, 'formalRelease': report['release']['decision'],
        'newCompleteProofs': 0, 'actualLocalDockerExecuted': False, 'backendBuildExecuted': False,
        'hostedWrongCaseResponseObserved': False, 'currentHeadHostedQualificationClaimed': False,
        'sourceCleanAfter': True,
        'limits': [
            'TESTED finite simulated main-path misbound-response behavior; not an ordinary observed Docker failure.',
            'Correct tagged CLI behavior echoes requested ref; the wrong-case response is an injected input-fault model.',
            'Parent b99 already repairs the distinct lowercase spelling issue; its approval/CI do not qualify this child.',
            'Observed main0bd is not an ancestor of parent b99; no current-main composition or merge readiness claim.',
            'No actual local Docker, complete refinement, production durability, deployment or forced-termination guarantee.']}
    (O / 'committed-source-correspondence.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({key: record[key] for key in ('sourceCommit',
          'registeredGitFilesystemMobileHashesVerified', 'implementerSimulatedCases',
          'soleNewGuardControlAssertionFailures', 'formalRelease')}, indent=2))


if __name__ == '__main__':
    main()
