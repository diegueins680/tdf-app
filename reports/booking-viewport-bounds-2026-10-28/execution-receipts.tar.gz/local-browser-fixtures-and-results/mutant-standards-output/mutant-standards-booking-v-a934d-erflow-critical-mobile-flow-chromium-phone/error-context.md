# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mutant-standards.spec.mjs >> booking viewport check detects known client-width overflow @critical @mobile-flow
- Location: ../tdf-booking-viewport-observation-20261028/mutant-standards.spec.mjs:56:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 8000ms exceeded while waiting on the predicate
```

# Test source

```ts
  1   | import { expect, test } from '/private/tmp/tdf-correctness-cycle-20261028/node_modules/@playwright/test/index.mjs';
  2   | import axe from '/private/tmp/tdf-correctness-cycle-20261028/node_modules/axe-core/axe.js';
  3   | 
  4   | async function measureBookingViewport(page) {
  5   |   return page.evaluate(() => {
  6   |     const viewport = { at: performance.now(), compatMode: document.compatMode, innerWidth,
  7   |       clientWidth: document.documentElement.clientWidth,
  8   |       scrollWidth: document.documentElement.scrollWidth,
  9   |       visualViewport: visualViewport && { width: visualViewport.width, scale: visualViewport.scale } };
  10  |     // Mobile innerWidth can grow with overflowing content; clientWidth is the
  11  |     // visible content bound, including on a page whose layout viewport grows.
  12  |     return { ...viewport, overflow: viewport.scrollWidth > viewport.innerWidth };
  13  |   });
  14  | }
  15  | 
  16  | // Observe a failed measurement without changing its asserted result. In
  17  | // particular, a later fit must not turn the original failure into a pass.
  18  | async function failedViewportGeometry(page) {
  19  |   return page.evaluate(async () => {
  20  |     const describe = element => {
  21  |       if (!element) return null;
  22  |       const rect = element.getBoundingClientRect();
  23  |       return { tag: element.tagName, id: element.id, classes: element.getAttribute('class'),
  24  |         text: element.textContent?.slice(0, 100), x: rect.x, right: rect.right,
  25  |         width: rect.width, clientWidth: element.clientWidth, scrollWidth: element.scrollWidth,
  26  |         transform: element.style.transform };
  27  |     };
  28  |     const sample = label => ({ label, at: performance.now(), innerWidth,
  29  |       clientWidth: document.documentElement.clientWidth,
  30  |       scrollWidth: document.documentElement.scrollWidth,
  31  |       visualViewport: visualViewport && { width: visualViewport.width, scale: visualViewport.scale },
  32  |       bookingCard: describe(document.querySelector('[data-testid="public-booking-card"]')),
  33  |       serviceSelect: describe(document.querySelector('[role="combobox"]')),
  34  |       dateInput: describe(document.querySelector('input[type="datetime-local"]')),
  35  |       tooltip: describe(document.querySelector('[role="tooltip"]')),
  36  |       tooltipPositioner: describe(document.querySelector('[role="tooltip"]')?.closest('[data-popper-placement]')),
  37  |       beyondClientViewport: [...document.querySelectorAll('body *')].filter(element => {
  38  |         const rect = element.getBoundingClientRect();
  39  |         const style = getComputedStyle(element);
  40  |         return rect.width > 0 && rect.right > document.documentElement.clientWidth + 0.5
  41  |           && style.display !== 'none' && style.visibility !== 'hidden';
  42  |       }).slice(0, 15).map(describe),
  43  |     });
  44  |     const samples = [sample('after-failed-one-shot')];
  45  |     await Promise.race([new Promise(resolve => requestAnimationFrame(resolve)),
  46  |       new Promise(resolve => setTimeout(resolve, 250))]);
  47  |     samples.push(sample('next-frame-or-250ms'));
  48  |     await new Promise(resolve => setTimeout(resolve, 100));
  49  |     samples.push(sample('another-100ms'));
  50  |     await new Promise(resolve => setTimeout(resolve, 300));
  51  |     samples.push(sample('another-300ms'));
  52  |     return samples;
  53  |   });
  54  | }
  55  | 
  56  | test('booking viewport check detects known client-width overflow @critical @mobile-flow', async ({ page }) => {
  57  |   await page.setViewportSize({ width: 320, height: 740 });
  58  |   await page.setContent('<!doctype html><meta name="viewport" content="width=device-width, initial-scale=1"><style>html,body{margin:0}</style>');
  59  |   await expect.poll(() => page.evaluate(() => document.documentElement.clientWidth)).toBe(320);
  60  |   expect((await measureBookingViewport(page)).overflow).toBe(false);
  61  |   await page.evaluate(() => {
  62  |     const offender = document.createElement('div');
  63  |     offender.id = 'known-viewport-overflow';
  64  |     offender.style.cssText = 'position:absolute;left:0;top:0;width:calc(100vw + 80px);height:1px;background:red;';
  65  |     document.body.append(offender);
  66  |   });
> 67  |   await expect.poll(async () => (await measureBookingViewport(page)).overflow).toBe(true);
      |   ^ Error: expect(received).toBe(expected) // Object.is equality
  68  |   const wide = await measureBookingViewport(page);
  69  |   expect(wide.compatMode).toBe('CSS1Compat');
  70  |   expect(wide.clientWidth).toBe(320);
  71  |   expect(wide.scrollWidth).toBeGreaterThan(320);
  72  |   await page.locator('#known-viewport-overflow').evaluate(element => element.remove());
  73  |   await expect.poll(async () => (await measureBookingViewport(page)).overflow).toBe(false);
  74  | });
  75  | 
  76  | // All business/session APIs are fixtures. Only local static assets reach the
  77  | // preview server; no reservation, provider request or external traffic is sent.
  78  | for (const failure of ['error', 'empty']) {
  79  |   test(`public booking recovers an ${failure} catalog without losing contact details @critical @mobile-flow`, async ({ page, baseURL }, testInfo) => {
  80  |     const origin = new URL(baseURL).origin;
  81  |     const errors = [], writes = [];
  82  |     let requests = 0, recovered = false, releaseInitial, releaseRetry;
  83  |     const initial = new Promise(resolve => { releaseInitial = resolve; });
  84  |     const retry = new Promise(resolve => { releaseRetry = resolve; });
  85  |     page.on('pageerror', error => errors.push(error.message));
  86  |     await page.addInitScript(() => localStorage.setItem('tdf-hq-ui/locale', 'es'));
  87  |     await page.route('**/*', async route => {
  88  |       const request = route.request(), url = new URL(request.url());
  89  |       if (url.origin !== origin && !/(^|\.)tdfrecords\.net$/.test(url.hostname)) return route.abort();
  90  |       if (request.method() !== 'GET') {
  91  |         writes.push({ method: request.method(), path: url.pathname });
  92  |         return route.abort();
  93  |       }
  94  |       if (!['fetch', 'xhr'].includes(request.resourceType())) return url.origin === origin ? route.continue() : route.abort();
  95  |       const path = url.pathname.replace(/^\/api(?=\/)/, '');
  96  |       if (path === '/session') return route.fulfill({ json: null });
  97  |       if (path === '/health') return route.fulfill({ json: { status: 'ok', db: 'ok' } });
  98  |       if (path === '/services/catalog/public') {
  99  |         requests++;
  100 |         if (!recovered) {
  101 |           await initial;
  102 |           return failure === 'error'
  103 |             ? route.fulfill({ status: 503, json: { error: 'Synthetic catalog outage' } })
  104 |             : route.fulfill({ json: { sceItems: [] } });
  105 |         }
  106 |         await retry;
  107 |         return route.fulfill({ json: { sceSchemaVersion: 1, sceRevision: 1, sceLocale: 'es', sceItems: [{
  108 |           scId: '11111111-1111-4111-8111-111111111111', scCode: 'recording-fixture',
  109 |           scName: 'Grabación de prueba', scNameEs: 'Grabación de prueba', scNameEn: 'Test recording',
  110 |           scCategoryId: '33333333-3333-4333-8333-333333333333', scKind: 'recording',
  111 |           scPricingModelId: '44444444-4444-4444-8444-444444444444', scPricingModel: 'hourly',
  112 |           scRateCents: 10000, scCurrency: 'USD', scCurrencyId: '55555555-5555-4555-8555-555555555555',
  113 |           scBillingUnit: 'hour', scDefaultDurationMinutes: 60, scRequiresEngineer: false,
  114 |           scDefaultResources: [], scSortOrder: 0, scActive: true,
  115 |         }] } });
  116 |       }
  117 |       if (path.includes('/engineers')) return route.fulfill({ json: [] });
  118 |       if (path.includes('/reviews')) return route.fulfill({ json: { items: [], summary: { count: 0, average: 0 }, nextCursor: null } });
  119 |       if (path.includes('/availability')) return route.fulfill({ json: { available: true } });
  120 |       return route.fulfill({ status: 404, json: { error: 'No fixture for this API' } });
  121 |     });
  122 |     await page.goto('/reservar?service=recording-fixture', { waitUntil: 'domcontentloaded' });
  123 |     const name = page.getByRole('textbox', { name: 'Nombre completo', exact: true });
  124 |     const email = page.getByRole('textbox', { name: 'Correo', exact: true });
  125 |     await name.fill('Visitante de prueba');
  126 |     await email.fill('visitante@example.test');
  127 |     // SessionQueryProvider retries 503s three times (1s, 2s, 4s). Begin the
  128 |     // UI assertion after the final synthetic response, rather than spending
  129 |     // its 8s budget on that unrelated backoff. The case keeps its 30s budget.
  130 |     const initialFailure = failure === 'error' ? page.waitForResponse(response =>
  131 |       new URL(response.url()).pathname.replace(/^\/api(?=\/)/, '') === '/services/catalog/public'
  132 |       && response.status() === 503 && requests === 4) : null;
  133 |     releaseInitial();
  134 |     if (initialFailure) await initialFailure;
  135 |     const warning = page.getByRole('alert').filter({ hasText: 'No pudimos cargar el catálogo de servicios' });
  136 |     await expect(warning).toBeVisible();
  137 |     await expect(name).toBeDisabled();
  138 |     const retryButton = warning.getByRole('button', { name: 'Reintentar catálogo', exact: true });
  139 |     await expect(retryButton).toBeEnabled();
  140 |     await page.addScriptTag({ content: axe.source });
  141 |     const violations = await warning.evaluate(async element => (await globalThis.axe.run(element, {
  142 |       runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa'] },
  143 |     })).violations.filter(v => ['serious', 'critical'].includes(v.impact)).map(v => ({ id: v.id, impact: v.impact })));
  144 |     expect(violations).toEqual([]);
  145 |     const before = requests;
  146 |     recovered = true;
  147 |     await retryButton.focus();
  148 |     await retryButton.press('Enter');
  149 |     await expect(warning.getByRole('button', { name: 'Cargando catálogo…', exact: true })).toBeDisabled();
  150 |     await expect(name).toBeDisabled();
  151 |     await expect.poll(() => requests).toBe(before + 1);
  152 |     expect(writes).toEqual([]);
  153 |     releaseRetry();
  154 |     await expect(warning).toHaveCount(0);
  155 |     await expect(name).toBeEnabled();
  156 |     await expect(name).toHaveValue('Visitante de prueba');
  157 |     await expect(email).toHaveValue('visitante@example.test');
  158 |     await expect(page.getByRole('combobox', { name: /^Servicio\b/ })).toContainText('Grabación de prueba');
  159 |     await page.getByRole('button', { name: 'Continuar', exact: true }).click();
  160 |     await expect(page.getByLabel(/^Fecha y hora/)).toBeVisible();
  161 |     await page.setViewportSize({ width: 320, height: 740 });
  162 |     // The mobile marker exists at both390 and320px. Bind the measurement to
  163 |     // the requested content viewport, without waiting for overflow to vanish.
  164 |     await expect(page.getByText('Paso 2 de 3', { exact: true })).toBeVisible();
  165 |     await expect.poll(() => page.evaluate(() => {
  166 |       const width = document.documentElement.clientWidth;
  167 |       return width > 0 && width <= 320;
```