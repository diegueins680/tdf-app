from pathlib import Path
import json,subprocess,os,concurrent.futures,datetime,signal
w=Path('/private/tmp/tdf-contract-send-main642-20261030');o=Path('/private/tmp/tdf-contract-send-main642-qualification-20261030')
prep=json.loads((o/'preparation-state.json').read_text());m=prep['sourceCommit']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip()==m
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
assert Path('/private/tmp/tdf-contract-send-main642-preparation-20261030.txt').is_file()
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']}
env.update(PATH='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/Users/macpro/.ghcup/bin:/usr/local/bin:/usr/bin:/bin',STACK_ROOT='/Users/macpro/.stack',PYTHONDONTWRITEBYTECODE='1')
state={'sourceCommit':m,'baselineMain':prep['mainSha'],'phase':'ROOT_QUALITY','startedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save():(o/'verification-state.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,cmd):
 with (o/(label+'-driver.log')).open('w') as log:
  p=subprocess.Popen(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try: code=p.wait(timeout=3900)
  except BaseException:
   if p.poll() is None:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=15)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   raise
 print(label+' actualexit '+str(code),flush=True);return code
save()
root_result=o/'root-quality-result.json'
if root_result.exists():
 r=json.loads(root_result.read_text());assert r['sourceCommit']==m and all(x==0 for x in r['actualExits'].values()) and r['sourceCleanAfter']
 state['rootQualityExit']=0;state['rootQualityEvidence']='Single completed separately launched current-source run, reused without unnecessary repeat'
else:state['rootQualityExit']=run('root-quality',['python3','/private/tmp/tdf-contract-send-main642-root-quality-20261030.py'])
save();assert state['rootQualityExit']==0
state['phase']='FORCED_NATIVE_AND_FRESH_ASSURANCE';save()
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 tasks={pool.submit(run,'native',['python3','/private/tmp/tdf-contract-send-main642-qualify-native-20261030.py']):'nativeExit',pool.submit(run,'assurance',['python3','scripts/verification-report.py','--output',str(o/'assurance-committed')]):'assuranceExit'}
 for fut in concurrent.futures.as_completed(tasks):state[tasks[fut]]=fut.result();save()
assert state['nativeExit']==state['assuranceExit']==0
state['phase']='QUALIFIED_NATIVE_ROOT_AND_ASSURANCE';state['finishedAtUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
