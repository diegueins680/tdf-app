from pathlib import Path
import json, subprocess, hashlib, tarfile, gzip, io, shutil, datetime
w=Path('/private/tmp/tdf-contract-send-main642-20261030');o=Path('/private/tmp/tdf-contract-send-main642-qualification-20261030')
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=w)
prep=json.loads((o/'preparation-state.json').read_text());m=prep['sourceCommit'];base=prep['mainSha']
assert git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip()
seal=json.loads((o/'source-correspondence.json').read_text());q=json.loads((o/'native-quality.json').read_text());root=json.loads((o/'root-quality-result.json').read_text());formal=json.loads((o/'assurance-committed/report.json').read_text())
assert seal['sourceCommit']==q['sourceCommit']==root['sourceCommit']==m and formal['execution']['passed']
review=Path('/private/tmp/tdf-contract-send-main642-final-review-20261030.txt');assert m in review.read_text() and base in review.read_text()
for p in [review,Path('/private/tmp/tdf-contract-send-main642-preparation-20261030.txt'),*Path('/private/tmp').glob('tdf-contract-send-main642-*-20261030.py')]:
 assert p.is_file() and not p.is_symlink();shutil.copyfile(p,o/p.name)
manifest=[];buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.PAX_FORMAT) as archive:
 for p in sorted(o.rglob('*')):
  assert not p.is_symlink(),p
  if p.is_dir():continue
  assert p.is_file(),p
  body=p.read_bytes();name=str(p.relative_to(o));entry=tarfile.TarInfo(name);entry.size=len(body);entry.mode=0o644;entry.mtime=0;archive.addfile(entry,io.BytesIO(body));manifest.append({'path':name,'sha256':sha(body),'bytes':len(body)})
rd=w/'reports/contract-send-main642-2026-10-30';rd.mkdir(exist_ok=False)
blob=gzip.compress(buf.getvalue(),mtime=0);ap=rd/'evidence.tar.gz';ap.write_bytes(blob)
(rd/'manifest.json').write_text(json.dumps({'sourceCommit':m,'archiveSha256':sha(blob),'archiveBytes':len(blob),'files':manifest},indent=2)+'\n');shutil.copyfile(review,rd/'independent-review.txt')
report={
 'schemaVersion':1,'dateUTC':'2026-10-30','baselineMain':base,'previousPublishedHead':prep['baselineHead'],'sourceCommit':m,'evidenceCommit':'Containing report-only child; qualified source trees and all archive members independently verified against Git after commit.',
 'problem':'The legacy contract send handler claimed status sent after reading a stored file without any delivery or queue implementation. Repository audit and EO-038 establish the missing implementation.',
 'correction':'Preserve established validation/read error precedence; valid stored contract send returns501 unsupported. Actual email delivery remains unimplemented. No provider/configuration/migration change.',
 'composition':{'normalMerge':True,'parents':[prep['baselineHead'],base],'backendWholeTreeExactPreviousPublishedHead':True,'allMainRequirementsPreserved':seal['allMainNormativeRequirementsPreserved'],'contractRequirementExactPrevious':True,'allWorkflowUiMobileScriptsDependencyTreesExactMain':True,'history':'Original M3/801 report/archive and all four Git blobs preserved byte-exact; original qualification is historical, not relabeled as this source. Incoming main Ubuntu24 pins and image retained. Unmerged679/682 are not imported.'},
 'properties':[
  {'id':'MSG-CONTRACT-DELIVERY-001/TRUTHFUL-REFUSAL','status':'TESTED','statement':'No successful sent/queued claim for unsupported legacy delivery after existing validation.','evidence':'Fresh current-source native typed Handler suite; historical false-success counterexample and native mutation controls bind unchanged production/test bytes.','assumptions':'Direct Handler/file fixtures; no authenticated HTTP or actual mail provider/delivery guarantee.'},
  {'id':'MSG-CONTRACT-DELIVERY-001/COMPATIBILITY','status':'TESTED','statement':'Existing400/404/500 precedence and stored-byte nonmutation remain supported by fixtures.','evidence':'Fresh10 targeted/4055 full native examples,21 inherited pending; unchanged strict snapshots.','assumptions':'Finite sequential owned filesystem fixtures, not complete concurrent or production filesystem proof.'}
 ],
 'historicalCounterexamples':{'baselineMain':'e1cec5b59723c2ff9828ac4fce45abb930d73055','validStoredSend':'Native10 cases,1 false-sent assertion/9compatibility; successful build first.','nativeControls':'3 working-source faults: false success1, validation bypass6, completed store mutation1 intended assertions; restored10/0. Not rerun on this composition; complete backend tree and tests remain exact801.','verificationObserver':'Strict snapshot correction closes read handles; old lazy read-lock probe remains documented.','originalHostedRun':41009219715,'originalRepoQualityFailure':'Underlying Docker cleanup response/cause UNKNOWN; no speculative cause assigned. Subsequent parent679 diagnostics/fix remain separate unmerged work.','historicalEvidenceGitSha256':seal['historicalEvidenceGitSha256']},
 'verification':{'native':q,'rootQuality':root,'sourceSeal':seal,'assuranceMetrics':formal['metrics'],'formalRelease':formal['release']['decision'],'newCompleteProofs':0,'independentReview':str((rd/'independent-review.txt').relative_to(w)),'scope':'Fresh source-bound local native and repository qualification; required current published-head hosted CI and exact-head GitHub approval remain pending.'},
 'verificationHarnessReview':{'mechanicalChecksAdded':'After independent review, reread actual test Version.o, compare assurance provenance table/digest and explicit UNPROVEN/conditional/BLOCKED claims. Earlier seal retained.','evidenceControls':json.loads((o/'seal-binding-controls.json').read_text()),'interruptedRunLimitation':'Completed actual0 run only. Temporary driver cancellation/process-tree cleanup not tested; outer3900s timeout is shorter than summed per-phase maxima, and detached-descendant SIGTERM needs separate hardening before reuse for that scenario. No orphan-cleanup guarantee claimed.'},
 'regressionProtection':{'targetedCases':10,'targetRegisteredInCanonicalCabalAndSpec':True,'fullSuiteCases':4055,'inheritedPending':21,'canonicalForceDirty':True,'qualifiedCommitInRebuiltVersionObjectAndTestBinary':True,'sourceTreeComparisonPreservesHistoricalFaultDetectionBytes':True,'newDependencies':False},
 'integration':{'pullRequest':677,'draft':True,'autoMerge':False,'merged':False,'currentHeadChecksAndReview':'Required after publication; old801 approval does not approve changed head.','protectedFIFO':'Required; no bypass, actual main/head must be rechecked before integration.','deployment':False,'productionOrProviderWrites':False},
 'remainingRisks':['Actual email delivery, immutable contract versions and all-party acceptance remain missing;501 is truthful refusal rather than feature completion.','No authenticated HTTP, successful PDF rendering, actual mail provider, production filesystem/concurrency, serving executable or deployment qualification.','Whole requirements and implementation/refinement obligations remain UNPROVEN; inherited conditional SMT claims retain original translation assumptions; formal release BLOCKED.','Source tests use canonical Stack --force-dirty; report-only child Git identity needs fresh hosted build.','Current main may advance; recomposition/requalification, independent exact-head review and all protected admission rules remain required.'],
 'nextHighestValueTask':'Fresh published-head CI/exact-head independent review and normal protected admission; retain outstanding financial and accessibility defects with original counterexamples.',
 'archive':{'path':str(ap.relative_to(w)),'sha256':sha(blob),'bytes':len(blob),'innerFiles':len(manifest),'manifest':str((rd/'manifest.json').relative_to(w)),'binding':'Every member hash and four containing Git blobs must be checked after commit.'},'createdAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()
}
(w/'reports/contract-send-main642-2026-10-30.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'sourceCommit':m,'archiveBytes':len(blob),'archiveMembers':len(manifest),'archiveSha256':sha(blob)},indent=2))
