from pathlib import Path
import json, subprocess, hashlib, datetime
w=Path('/private/tmp/tdf-contract-send-main642-20261030')
o=Path('/private/tmp/tdf-contract-send-main642-qualification-20261030')
old='801b133aecf38ffd16da8b910139081e14f4e446'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args,cwd=w): return subprocess.check_output(['git',*args],cwd=cwd)
def blob(rev,path): return git('show',rev+':'+path)
def verify_current_artifact_bindings(m,q,f,s,force,binary_bytes,version_bytes,requirement_count):
 assert sha(binary_bytes)==force['binarySha256']==q['binarySha256']
 assert sha(version_bytes)==force['versionObjectSha256']
 assert m.encode() in binary_bytes and m.encode() in version_bytes
 assert q['forceDirtyIdentity']==force
 for key in ['files','digest','revision','mobileGitlink','worktreeDirty']:
  assert f['provenance'][key]==s[key],key
 expected={'PROVEN':0,'REFUTED':0,'UNPROVEN':requirement_count,'NOT_APPLICABLE':0}
 assert f['metrics']['requirements']==expected
 for category in ['implementation','refinement']:
  assert f['metrics']['obligationsByCategory'][category]==expected,category
 for category,count in [('source-derived-SMT',4),('source-derived-authorization-SMT',3),('source-derived-recovery-SMT',4)]:
  assert f['metrics']['obligationsByCategory'][category]=={'PROVEN':count,'REFUTED':0,'UNPROVEN':0,'NOT_APPLICABLE':0},category
 assert f['release']['decision']=='BLOCKED' and f['release']['executionAllowed'] is False

prep=json.loads((o/'preparation-state.json').read_text());m=prep['sourceCommit'];main=prep['mainSha']
assert git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip()
assert git('show','-s','--format=%P',m).decode().split()==[old,main]
for p in ['tdf-hq','formal/system/auth-predicates.json','formal/system/recovery-expiry-arithmetic.json','formal/system/contract-send-truthfulness.md']:
 assert git('rev-parse',m+':'+p)==git('rev-parse',old+':'+p),p
for p in ['.github','tdf-hq-ui','tdf-mobile','scripts','package.json','package-lock.json','docs/catalog-persistence/catalog-list-decisions.json']:
 assert git('rev-parse',m+':'+p)==git('rev-parse',main+':'+p),p
historical=['reports/contract-send-truthfulness-2026-10-30.json','reports/contract-send-truthfulness-2026-10-30/evidence.tar.gz','reports/contract-send-truthfulness-2026-10-30/manifest.json','reports/contract-send-truthfulness-2026-10-30/independent-review.txt']
historicalBindings={}
for p in historical:
 b=blob(old,p);assert blob(m,p)==b==(w/p).read_bytes();historicalBindings[p]=sha(b)
mainreq=json.loads(blob(main,'formal/system/requirements.json'))['requirements']
priorreq=json.loads(blob(old,'formal/system/requirements.json'))['requirements']
req=json.loads((w/'formal/system/requirements.json').read_text())['requirements'];by={x['id']:x for x in req};oldby={x['id']:x for x in priorreq}
assert len(by)==len(req)==len(mainreq)+1
assert all(by[x['id']]==x for x in mainreq)
assert by['MSG-CONTRACT-DELIVERY-001']==oldby['MSG-CONTRACT-DELIVERY-001']
q=json.loads((o/'native-quality.json').read_text());r=json.loads((o/'root-quality-result.json').read_text());f=json.loads((o/'assurance-committed/report.json').read_text());s=json.loads((o/'assurance-committed/sources.json').read_text());force=json.loads((o/'native-force-dirty-confirmed.json').read_text())
assert q['sourceCommit']==r['sourceCommit']==s['revision']==f['provenance']['revision']==force['sourceCommit']==m
assert all(x==0 for x in q['actualExits'].values()) and all(x==0 for x in r['actualExits'].values())
assert q['targeted']=={'examples':10,'failures':0,'pending':0} and q['full']=={'examples':4055,'failures':0,'pending':21}
assert force['canonicalForceDirty'] and force['qualifiedCommitLiteralInVersionObjectAndTestBinary'] and '--force-dirty' in force['command'] and force['binarySha256']==q['binarySha256']
assert Path(q['binary']).exists() and sha(Path(q['binary']).read_bytes())==q['binarySha256']
version_objects=list((w/'tdf-hq/.stack-work/dist').glob('**/build/tdf-hq-test/tdf-hq-test-tmp/TDF/Version.o'));assert len(version_objects)==1
verify_current_artifact_bindings(m,q,f,s,force,Path(q['binary']).read_bytes(),version_objects[0].read_bytes(),len(req))
assert f['execution']['passed'] and not s['worktreeDirty'] and s['digest']==sha(json.dumps(s['files'],sort_keys=True).encode())
mobile=git('rev-parse',m+':tdf-mobile').decode().strip();assert git('rev-parse','HEAD',cwd=w/'tdf-mobile').decode().strip()==mobile
for ism in [False,True]:
 pairs=[(p,h) for p,h in s['files'].items() if p.startswith('tdf-mobile/')==ism];cwd=w/'tdf-mobile' if ism else w;rev=mobile if ism else m
 refs=[rev+':'+(p.removeprefix('tdf-mobile/') if ism else p) for p,h in pairs];assert all('\n' not in x for x in refs)
 raw=subprocess.check_output(['git','cat-file','--batch'],cwd=cwd,input=('\n'.join(refs)+'\n').encode());pos=0
 for p,h in pairs:
  end=raw.index(b'\n',pos);header=raw[pos:end].split();assert header[1]==b'blob';n=int(header[2]);assert sha(raw[end+1:end+1+n])==h==sha((w/p).read_bytes()),p;pos=end+1+n+1
 assert pos==len(raw)
inputs=json.loads((o/'native-qualified-inputs.json').read_text())['allBackendTrackedGitSha256']
for p,h in inputs.items():assert sha(blob(m,p))==h==sha((w/p).read_bytes()),p
result={'sourceCommit':m,'baselineMain':main,'previousPublishedHead':old,'normalMergeParents':[old,main],'sourceDigest':s['digest'],'registeredHashesVerified':len(s['files']),'allBackendInputCount':len(inputs),'backendWholeTreeExactPreviousQualifiedHead':True,'workflowUiMobileScriptDependencyTreesExactMain':True,'allMainNormativeRequirementsPreserved':len(mainreq),'contractDeliveryRequirementExactPrevious':True,'totalRequirements':len(req),'historicalEvidenceGitSha256':historicalBindings,'historicalEvidenceScope':'Original E1/M3 local counterexamples, 3 source faults/8 intended assertions, and801 hosted run remain historical; those controls not rerun on this composition. Complete backend tree/test bytes exact801 and native current-source suite re-executed.','nativeTargeted':q['targeted'],'nativeFull':q['full'],'nativeForceDirtyIdentity':force,'assuranceMetrics':f['metrics'],'formalRelease':f['release']['decision'],'newCompleteProofs':0,'sourceCleanAfter':True,'recheckedVersionObjectAndAssuranceProvenance':True,'limitations':['Direct typed Handler and owned filesystem fixtures; no authenticated HTTP, successful PDF rendering, mail delivery/provider, production filesystem or serving-executable qualification.','No new actual Docker or PostgreSQL runtime; required hosted lanes must execute on published current head.','No import of unmerged679/682; original677 cleanup failure is unreconstructed and remains historical.','Protected current-head review/checks/FIFO and later main advances must be re-evaluated before integration.','Temporary qualification-driver cancellation/process-tree cleanup was not tested; completed actual0 runs do not prove interrupted-run cleanup. Outer timeout3900s is shorter than the sum of per-phase maxima, and detached descendant cleanup needs separate hardening before reuse for that scenario.'],'createdAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(o/'source-correspondence.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['sourceCommit','baselineMain','registeredHashesVerified','allBackendInputCount','totalRequirements','nativeTargeted','nativeFull','formalRelease']},indent=2))
