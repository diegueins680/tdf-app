(set-option :timeout 30000)
(set-logic QF_LIA)
(declare-fun requested_module_grant () Bool)
(declare-fun count_Maintenance () Int)
(declare-fun count_Fan () Int)
(declare-fun count_Customer () Int)
(declare-fun count_ReadOnly () Int)
(declare-fun count_Vendor () Int)
(declare-fun count_Student () Int)
(declare-fun count_AandR () Int)
(declare-fun count_Photographer () Int)
(declare-fun count_RoadCrew () Int)
(declare-fun count_StageManager () Int)
(declare-fun count_LabelRep () Int)
(declare-fun count_TourManager () Int)
(declare-fun count_Publicist () Int)
(declare-fun count_DJ () Int)
(declare-fun count_Songwriter () Int)
(declare-fun count_Agency () Int)
(declare-fun count_Producer () Int)
(declare-fun count_Promoter () Int)
(declare-fun count_Promotor () Int)
(declare-fun count_Webmaster () Int)
(declare-fun count_Artista () Int)
(declare-fun count_Artist () Int)
(declare-fun count_Intern () Int)
(declare-fun count_LiveSessionsProducer () Int)
(declare-fun count_Accounting () Int)
(declare-fun count_Reception () Int)
(declare-fun count_Teacher () Int)
(declare-fun count_Engineer () Int)
(declare-fun count_StudioManager () Int)
(declare-fun count_Manager () Int)
(declare-fun count_Admin () Int)
(declare-fun party () Int)
(assert (let ((a!1 (= (and (> party 0)
                   (<= count_Admin 1)
                   (<= count_Manager 1)
                   (<= count_StudioManager 1)
                   (<= count_Engineer 1)
                   (<= count_Teacher 1)
                   (<= count_Reception 1)
                   (<= count_Accounting 1)
                   (<= count_LiveSessionsProducer 1)
                   (<= count_Intern 1)
                   (<= count_Artist 1)
                   (<= count_Artista 1)
                   (<= count_Webmaster 1)
                   (<= count_Promotor 1)
                   (<= count_Promoter 1)
                   (<= count_Producer 1)
                   (<= count_Agency 1)
                   (<= count_Songwriter 1)
                   (<= count_DJ 1)
                   (<= count_Publicist 1)
                   (<= count_TourManager 1)
                   (<= count_LabelRep 1)
                   (<= count_StageManager 1)
                   (<= count_RoadCrew 1)
                   (<= count_Photographer 1)
                   (<= count_AandR 1)
                   (<= count_Student 1)
                   (<= count_Vendor 1)
                   (<= count_ReadOnly 1)
                   (<= count_Customer 1)
                   (<= count_Fan 1)
                   (<= count_Maintenance 1)
                   requested_module_grant)
              true)))
  (and (>= party (- 9223372036854775808))
       (< party 9223372036854775808)
       (>= count_Admin 0)
       (>= count_Manager 0)
       (>= count_StudioManager 0)
       (>= count_Engineer 0)
       (>= count_Teacher 0)
       (>= count_Reception 0)
       (>= count_Accounting 0)
       (>= count_LiveSessionsProducer 0)
       (>= count_Intern 0)
       (>= count_Artist 0)
       (>= count_Artista 0)
       (>= count_Webmaster 0)
       (>= count_Promotor 0)
       (>= count_Promoter 0)
       (>= count_Producer 0)
       (>= count_Agency 0)
       (>= count_Songwriter 0)
       (>= count_DJ 0)
       (>= count_Publicist 0)
       (>= count_TourManager 0)
       (>= count_LabelRep 0)
       (>= count_StageManager 0)
       (>= count_RoadCrew 0)
       (>= count_Photographer 0)
       (>= count_AandR 0)
       (>= count_Student 0)
       (>= count_Vendor 0)
       (>= count_ReadOnly 0)
       (>= count_Customer 0)
       (>= count_Fan 0)
       (>= count_Maintenance 0)
       (< (+ count_Admin
             count_Manager
             count_StudioManager
             count_Engineer
             count_Teacher
             count_Reception
             count_Accounting
             count_LiveSessionsProducer
             count_Intern
             count_Artist
             count_Artista
             count_Webmaster
             count_Promotor
             count_Promoter
             count_Producer
             count_Agency
             count_Songwriter
             count_DJ
             count_Publicist
             count_TourManager
             count_LabelRep
             count_StageManager
             count_RoadCrew
             count_Photographer
             count_AandR
             count_Student
             count_Vendor
             count_ReadOnly
             count_Customer
             count_Fan
             count_Maintenance)
          9223372036854775808)
       a!1
       a!1)))

(check-sat)
