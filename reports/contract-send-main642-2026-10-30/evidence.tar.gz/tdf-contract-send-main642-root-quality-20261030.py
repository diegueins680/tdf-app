from pathlib import Path
import os,subprocess,json,hashlib
w=Path('/private/tmp/tdf-contract-send-main642-20261030');o=Path('/private/tmp/tdf-contract-send-main642-qualification-20261030');c=Path('/private/tmp/tdf-correctness-cycle-20261028');m=json.loads((o/'preparation-state.json').read_text())['sourceCommit']
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env['PATH']='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/Users/macpro/.ghcup/bin:/usr/local/bin:/usr/bin:/bin';env['PYTHONDONTWRITEBYTECODE']='1'
for k in ['TESTOMATIO','ADMIN_TOKEN','SPOTIFY_CLIENT_ID','SPOTIFY_CLIENT_SECRET','YOUTUBE_API_KEY','DRIVE_CLIENT_ID','DRIVE_CLIENT_SECRET','DRIVE_REFRESH_TOKEN','DATABASE_URL','TDF_API_BASE','API_BASE']:env.pop(k,None)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip()==m and not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
made=[];result={}
try:
 for name in ['node_modules','tdf-hq-ui/node_modules']:
  p,t=w/name,c/name;assert not(p.exists() or p.is_symlink());p.symlink_to(t,target_is_directory=True);made.append((p,t))
 for label,cmd in [('root-quality',['bash','scripts/quality-repo.sh']),('new-surface-admission',['python3','scripts/check-new-specification-surfaces.py','--base','0bd8409f0b0bbeffdbee5cb6a0abdd09c07dafe5','--head',m]),('catalog-unit',['node','--test','scripts/__tests__/catalog-list-audit.test.mjs'])]:
  with (o/(label+'.txt')).open('w') as log:r=subprocess.run(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT)
  result[label]=r.returncode;print(label+' actualexit'+str(r.returncode),flush=True)
  assert r.returncode==0,label
finally:
 for p,t in reversed(made):assert p.is_symlink() and p.resolve()==t.resolve();p.unlink()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
(o/'root-quality-result.json').write_text(json.dumps({'sourceCommit':m,'actualExits':result,'catalogUnitCases':8,'aliasesRemoved':True,'sourceCleanAfter':True},indent=2)+'\n');print('SourceM clean; rootquality/admission/catalog passed',flush=True)
