{-# LANGUAGE OverloadedStrings #-}

-- Real PostgreSQL persistence/concurrency tests; no provider HTTP or credentials.
module TDF.Commerce.ProviderRetrySpec (spec) where

import Data.List (nub)
import           Control.Concurrent (MVar, ThreadId, forkFinally, killThread, newEmptyMVar, putMVar, readMVar, takeMVar, threadDelay, tryPutMVar)
import           Control.Exception (AsyncException(..), IOException, bracket, throwIO, toException, try)
import           Control.Monad (forM, forM_, unless, when)
import           Control.Monad.Logger (runNoLoggingT)
import           Control.Monad.IO.Class (liftIO)
import           Control.Monad.Reader (ReaderT, runReaderT)
import           Crypto.Hash (Digest, SHA256, hash)
import qualified Data.Aeson as A
import qualified Data.Aeson.KeyMap as KM
import qualified Data.ByteArray.Encoding as BAE
import qualified Data.ByteString.Char8 as BS
import qualified Data.ByteString.Lazy as BL
import           Data.Either (isLeft, isRight, rights)
import           Data.Int (Int64)
import           Data.IORef (newIORef, readIORef, atomicModifyIORef', modifyIORef')
import           Data.Pool (destroyAllResources)
import           Data.Text (Text)
import qualified Data.Text as T
import qualified Data.Text.Encoding as TE
import           Data.Time (UTCTime(..), addUTCTime, diffUTCTime, fromGregorian, getCurrentTime)
import           Data.UUID (toText)
import           Data.UUID.V4 (nextRandom)
import           Database.Persist (PersistValue(..), Entity(..), get, entityKey, entityVal)
import           Database.Persist.Postgresql (createPostgresqlPool)
import           Database.Persist.Sql (ConnectionPool, Single(..), SqlPersistT, rawExecute, rawSql, runSqlPool, toSqlKey)
import           Database.PostgreSQL.Simple (SqlError(..))
import           Network.Socket (SockAddr(..))
import           Numeric (readHex)
import qualified Network.HTTP.Client as HC
import           Servant (Handler, NoContent, ServerError, errHTTPCode, errBody, errHeaders, runHandler, getResponse, getHeaders, (:<|>)(..))
import           System.Environment (lookupEnv, setEnv, unsetEnv)
import qualified System.Timeout as Timeout
import           Test.Hspec

import qualified TDF.Commerce.CheckoutStore as Checkout
import           TDF.API.CommerceOperations
import           TDF.Auth (AuthedUser(..))
import           TDF.Models (RoleEnum(..))
import qualified TDF.Server.CommerceOperations as Operations
import           TDF.API.ProviderExecution (PaymentSessionCreateDTO(..), PaymentSessionDTO(..))
import           TDF.DB (Env(..))
import qualified TDF.Config as Config
import qualified TDF.Services.Stripe as Stripe
import qualified TDF.Commerce.PaymentIntentStore as Intent
import qualified TDF.Commerce.PaymentRuntimeStore as Runtime
import           TDF.Commerce.ProviderAdapter (AdapterOperation(..))
import qualified TDF.Commerce.ProviderAdapter as Adapter
import qualified TDF.Commerce.ProviderAdapter.Http as ProviderHttp
import qualified TDF.Commerce.ProviderAdapter.PayPhone as PayPhone
import qualified TDF.Commerce.ProviderAdapter.PlaceToPay as PlaceToPay
import           TDF.Commerce.ProviderCapabilities (PaymentMethod(..), ProviderOutcomeCertainty(..))
import qualified TDF.Commerce.ProviderCapabilities as Capabilities
import qualified TDF.Commerce.ProviderExecutionStore as Execution
import qualified TDF.Commerce.ProviderEventStore as Event
import qualified TDF.Commerce.ProviderEventWorker as EventWorker
import qualified TDF.Commerce.ProviderReconciliation as Reconciliation
import qualified TDF.Commerce.RefundStore as Refund
import qualified TDF.Commerce.RefundSafetySpec as RefundSafety
import qualified TDF.Commerce.RefundRecoverySpec as RefundRecovery
import qualified TDF.Commerce.RefundReconciliation as TicketRecovery
import qualified TDF.Commerce.ProviderAdapter.PayPalRefund as TicketQuery
import qualified TDF.Server.TicketRefunds as TicketRefundAPI
import           TDF.Commerce.StateMachine (PaymentEvent(..))
import           TDF.Server.ProviderExecution (providerReference, providerExecutionServer, providerReturnUrl)
import qualified TDF.Ticketing.Refund as TicketRefund
import qualified TDF.Ticketing.Admission as Admission
import qualified TDF.Models.SocialEventsModels as TM
import qualified TDF.DTO.SocialEventsDTO as TD
import qualified TDF.Server.SocialEventsHandlers as Social
import qualified TDF.Ticketing.Transfer as Transfer
import Database.Persist.Sql (toSqlKey, fromSqlKey)
import qualified TDF.Server.PaymentAvailability as Availability
import qualified TDF.Server.ServiceStorefront as Storefront

-- In-memory HTTP connection fixtures. These exercise the real HTTP executor,
-- not a real provider, TLS handshake, socket, merchant account or sandbox.
providerTransportSpec :: Spec
providerTransportSpec = describe "provider HTTP transport boundary" $ do
  it "allows configured provider destinations and pins redirects/header timeout" $ do
    forM_ transportOrigins $ \(provider, origin) -> do
      request <- ProviderHttp.parseProviderRequest provider (origin <> "/api/test") >>= requireRight
      HC.redirectCount request `shouldBe` 0
      HC.responseTimeout request `shouldBe` HC.responseTimeoutMicro 15000000
      HC.cookieJar request `shouldSatisfy` maybe True (const False)

  it "rejects spoofed hosts, URL credentials, explicit ports and unsafe URLs" $ do
    forM_ ["http://api-m.sandbox.paypal.com/v2/orders"
      , "https://api-m.sandbox.paypal.com.attacker.invalid/v2/orders"
      , "https://user:synthetic-private@api-m.sandbox.paypal.com/v2/orders"
      , "https://api-m.sandbox.paypal.com:443/v2/orders"
      , "https://api-m.sandbox.paypal.com/v2/orders#synthetic-private"
      , "https://api-m.sandbox.paypal.com\\@attacker.invalid/v2/orders"
      , "https://api-m.sandbox.paypal.com/v2/\nsynthetic-private"
      , "https://127.0.0.1/v2/orders", "not a URL synthetic-private"] $ \url -> do
        result <- ProviderHttp.parseProviderRequest Checkout.ProviderPayPal url
        result `shouldSatisfy` isLeft
        either show (const "unexpected accepted request") result
          `shouldNotContain` "synthetic-private"
    ProviderHttp.parseProviderRequest Checkout.ProviderDatafast
      "https://test.oppwa.com.attacker.invalid/v1/checkouts" >>= (`shouldSatisfy` isLeft)
    ProviderHttp.parseProviderRequest Checkout.ProviderPayPhone
      "https://api-m.sandbox.paypal.com/v2/orders" >>= (`shouldSatisfy` isLeft)

  it "revalidates the parsed destination and rejects Host overrides or invalid UTF8" $ do
    request <- paypalTransportRequest
    forM_ [request { HC.secure = False }, request { HC.port = 8443 }
      , request { HC.host = "attacker.invalid" }, request { HC.host = BS.pack ['\255'] }
      , request { HC.requestHeaders = [("Host", "attacker.invalid")] }] $ \altered ->
        ProviderHttp.prepareProviderRequest Checkout.ProviderPayPal altered `shouldSatisfy` isLeft

  it "preserves form/JSON bytes, authorization and stable idempotency headers" $ do
    request <- paypalTransportRequest
    let original = request { HC.method = "POST"
          , HC.requestHeaders = [("Authorization", "Bearer synthetic-token")
              , ("PayPal-Request-Id", "synthetic-stable-request")]
          , HC.requestBody = HC.RequestBodyBS "grant_type=client_credentials"
          , HC.redirectCount = 10, HC.responseTimeout = HC.responseTimeoutNone }
    prepared <- requireRight (ProviderHttp.prepareProviderRequest Checkout.ProviderPayPal original)
    HC.method prepared `shouldBe` "POST"
    HC.requestHeaders prepared `shouldBe` HC.requestHeaders original
    case HC.requestBody prepared of
      HC.RequestBodyBS bytes -> bytes `shouldBe` "grant_type=client_credentials"
      _ -> expectationFailure "Form encoding changed"
    HC.redirectCount prepared `shouldBe` 0

  it "accepts exactly one MiB of JSON without rounding or altering decimal strings" $ do
    let json = "\"" <> BS.replicate (1024 * 1024 - 2) 'a' <> "\""
    reader <- chunkReader [BS.take 1024 json, BS.drop 1024 json]
    value <- ProviderHttp.readProviderResponse 200 reader :: IO (Either ProviderHttp.AdapterTransportError A.Value)
    value `shouldBe` Right (A.String (T.replicate (1024 * 1024 - 2) "a"))
    reader2 <- chunkReader ["{\"amount\":{\"value\":\"125.15\",\"currency_code\":\"USD\"}}"]
    result <- ProviderHttp.readProviderResponse 201 reader2 :: IO (Either ProviderHttp.AdapterTransportError A.Value)
    result `shouldBe` Right (A.object ["amount" A..= A.object
      ["value" A..= ("125.15" :: Text), "currency_code" A..= ("USD" :: Text)]])

  it "stops reading at the first oversized chunk" $ do
    readCount <- newIORef (0 :: Int)
    reader <- chunkReader [BS.replicate (1024 * 1024) ' ', "x", "must-not-be-read"]
    result <- ProviderHttp.readProviderResponse 200 (modifyIORef' readCount (+1) >> reader)
      :: IO (Either ProviderHttp.AdapterTransportError A.Value)
    result `shouldSatisfy` isLeft
    readIORef readCount `shouldReturn` 2

  it "does not consume redirect, rejection or server-error response bodies" $ do
    forM_ [301, 302, 307, 308, 400, 401, 409, 422, 429, 500, 503] $ \code -> do
      result <- ProviderHttp.readProviderResponse code
        (fail "Non-2xx response body must never be consumed")
        :: IO (Either ProviderHttp.AdapterTransportError A.Value)
      result `shouldSatisfy` isLeft

  it "redacts malformed JSON and typed parser errors" $ do
    forM_ ["{synthetic-private-invalid-json", "\"synthetic-private-token\""] $ \body -> do
      reader <- chunkReader [body]
      result <- ProviderHttp.readProviderResponse 200 reader
        :: IO (Either ProviderHttp.AdapterTransportError Storefront.ServiceDatafastPaymentStatus)
      result `shouldSatisfy` isLeft
      show result `shouldNotContain` "synthetic-private"

  it "uses the same real executor for all four provider destinations" $ do
    forM_ transportOrigins $ \(provider, origin) -> do
      reader <- chunkReader [jsonWire "{\"ok\":true}"]
      withProviderWire reader $ \manager connections _ _ -> do
        request <- ProviderHttp.parseProviderRequest provider (origin <> "/api/test") >>= requireRight
        result <- ProviderHttp.executeProviderRequest manager provider request
          :: IO (Either ProviderHttp.AdapterTransportError A.Value)
        result `shouldBe` Right (A.object ["ok" A..= True])
        connections `shouldReturn` 1

  it "rejects a changed destination before opening any connection" $ do
    withProviderWire (fail "No network allowed") $ \manager connections _ _ -> do
      request <- paypalTransportRequest
      result <- ProviderHttp.executeProviderRequest manager Checkout.ProviderPayPal
        request { HC.host = "attacker.invalid" }
        :: IO (Either ProviderHttp.AdapterTransportError A.Value)
      result `shouldSatisfy` isLeft
      connections `shouldReturn` 0

  it "does not follow a credential-bearing POST redirect" $ do
    reader <- chunkReader ["HTTP/1.1 307 Temporary Redirect\r\nLocation: https://attacker.invalid/collect\r\nContent-Length: 0\r\n\r\n"]
    withProviderWire reader $ \manager connections writes _ -> do
      request <- paypalTransportRequest
      result <- ProviderHttp.executeProviderRequest manager Checkout.ProviderPayPal request
        { HC.method = "POST", HC.requestHeaders = [("Authorization", "Bearer synthetic-token")]
        , HC.requestBody = HC.RequestBodyBS "{}" }
        :: IO (Either ProviderHttp.AdapterTransportError A.Value)
      result `shouldSatisfy` isLeft
      connections `shouldReturn` 1
      sent <- writes
      sent `shouldNotSatisfy` BS.isInfixOf "attacker.invalid"

  it "redacts network parser exceptions and closes the failed response" $ do
    reader <- chunkReader ["synthetic-private-invalid-http\r\n\r\n"]
    withProviderWire reader $ \manager _ _ closes -> do
      request <- paypalTransportRequest
      result <- ProviderHttp.executeProviderRequest manager Checkout.ProviderPayPal request
        :: IO (Either ProviderHttp.AdapterTransportError A.Value)
      result `shouldSatisfy` isLeft
      show result `shouldNotContain` "synthetic-private"
      closes >>= (`shouldSatisfy` (> 0))

  it "disables stale-connection retries even for ambiguous POST results" $ do
    HC.managerRetryableException ProviderHttp.providerManagerSettings
      (toException (userError "synthetic-private-error")) `shouldBe` False
    reader <- chunkReader [jsonWire "{}"]
    withProviderWire reader $ \manager connections writes _ -> do
      request <- paypalTransportRequest
      _ <- (ProviderHttp.executeProviderRequest manager Checkout.ProviderPayPal request
        :: IO (Either ProviderHttp.AdapterTransportError A.Value)) >>= requireRight
      result <- ProviderHttp.executeProviderRequest manager Checkout.ProviderPayPal request
        { HC.method = "POST", HC.requestBody = HC.RequestBodyBS "{}" }
        :: IO (Either ProviderHttp.AdapterTransportError A.Value)
      result `shouldSatisfy` isLeft
      connections `shouldReturn` 1
      sent <- writes
      length (filter (BS.isPrefixOf "POST ") (BS.lines sent)) `shouldBe` 1

  it "bounds a body stalled after valid headers and closes its connection" $ do
    first <- newIORef True
    let reader = do
          initial <- atomicModifyIORef' first (\value -> (False, value))
          if initial then pure "HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\n"
            else threadDelay 30000000 >> pure "{}"
    withProviderWire reader $ \manager _ _ closes -> do
      request <- paypalTransportRequest
      started <- getCurrentTime
      result <- Timeout.timeout 20000000
        (ProviderHttp.executeProviderRequest manager Checkout.ProviderPayPal request
          :: IO (Either ProviderHttp.AdapterTransportError A.Value))
      result `shouldSatisfy` maybe False isLeft
      finished <- getCurrentTime
      diffUTCTime finished started `shouldSatisfy` (>= 14)
      closes >>= (`shouldSatisfy` (> 0))

  it "redacts decompression failures without throwing provider bytes" $ do
    let body = "synthetic-private-invalid-gzip"
    reader <- chunkReader ["HTTP/1.1 200 OK\r\nContent-Encoding: gzip\r\nContent-Length: "
      <> BS.pack (show (BS.length body)) <> "\r\n\r\n" <> body]
    withProviderWire reader $ \manager _ _ _ -> do
      request <- paypalTransportRequest
      result <- ProviderHttp.executeProviderRequest manager Checkout.ProviderPayPal request
        :: IO (Either ProviderHttp.AdapterTransportError A.Value)
      result `shouldBe` Left (ProviderHttp.AdapterTransportError
        "Payment provider is temporarily unavailable; reconcile before retrying.")
      show result `shouldNotContain` "synthetic-private"

  it "routes legacy PayPal order creation through the executor with stable request IDs" $ do
    let created = "{\"id\":\"SYNTHETIC-ORDER\",\"links\":[{\"rel\":\"approve\",\"href\":\"https://www.sandbox.paypal.com/checkoutnow?token=SYNTHETIC-ORDER\"}]}"
    reader <- chunkReader [jsonWire oauthFixture, jsonWire created, jsonWire oauthFixture, jsonWire created]
    withProviderWire reader $ \manager _ writes _ -> do
      let create = runHandler $ runReaderT
            (Storefront.createPaypalOrderRemoteForService manager "synthetic-client" "synthetic-secret"
              "https://api-m.sandbox.paypal.com" "synthetic-internal-order" 12515 "USD"
              "Synthetic Buyer" "buyer@example.invalid")
            (error "Remote helper must not access the database")
      first <- create
      second <- create
      first `shouldSatisfy` isRight
      second `shouldBe` first
      sent <- writes
      sent `shouldSatisfy` BS.isInfixOf "\"value\":\"125.15\""
      let keys = filter (BS.isPrefixOf "PayPal-Request-Id:") (BS.lines sent)
      length keys `shouldBe` 2
      case keys of
        [one, two] -> one `shouldBe` two
        _ -> expectationFailure "Missing stable PayPal request IDs"

  it "rejects unsafe PayPal OAuth tokens before sending a financial request" $ do
    forM_ ["{\"access_token\":\"synthetic-private\\r\\nHeader: x\",\"token_type\":\"Bearer\"}"
      , "{\"access_token\":\"synthetic-private\",\"token_type\":\"Basic\"}"] $ \oauth -> do
        reader <- chunkReader [jsonWire oauth]
        withProviderWire reader $ \manager _ writes _ -> do
          result <- runHandler $ runReaderT
            (Storefront.capturePaypalOrderRemoteForService manager "synthetic-client" "synthetic-secret"
              "https://api-m.sandbox.paypal.com" "SYNTHETIC-ORDER")
            (error "Remote helper must not access the database")
          result `shouldSatisfy` isLeft
          either (BL.toStrict . errBody) (const "unexpected success") result
            `shouldNotSatisfy` BS.isInfixOf "synthetic-private"
          sent <- writes
          sent `shouldNotSatisfy` BS.isInfixOf "/capture"

  it "preserves capture binding fields and the existing capture idempotency header" $ do
    let captured = BL.toStrict $ A.encode $ A.object
          [ "id" A..= ("SYNTHETIC-ORDER" :: Text)
          , "purchase_units" A..= [A.object
              [ "custom_id" A..= ("synthetic-internal-order" :: Text)
              , "payee" A..= A.object ["merchant_id" A..= ("synthetic-merchant" :: Text)]
              , "payments" A..= A.object ["captures" A..= [A.object
                  [ "id" A..= ("SYNTHETIC-CAPTURE" :: Text)
                  , "status" A..= ("COMPLETED" :: Text)
                  , "amount" A..= A.object ["value" A..= ("125.15" :: Text)
                      , "currency_code" A..= ("USD" :: Text)] ]]] ]]]
    reader <- chunkReader [jsonWire oauthFixture, jsonWire "{\"status\":\"COMPLETED\"}",
      jsonWire oauthFixture, jsonWire captured]
    withProviderWire reader $ \manager _ writes _ -> do
      outcome <- runHandler (runReaderT
        (Storefront.capturePaypalOrderRemoteForService manager "synthetic-client" "synthetic-secret"
          "https://api-m.sandbox.paypal.com" "SYNTHETIC-ORDER")
        (error "Remote helper must not access the database")) >>= requireRight
      Storefront.validatePaypalSuccessfulCapture "synthetic-internal-order" 12515 "USD"
        "synthetic-merchant" outcome `shouldBe` Right ()
      sent <- writes
      sent `shouldSatisfy` BS.isInfixOf "POST /v2/checkout/orders/SYNTHETIC-ORDER/capture"
      sent `shouldSatisfy` BS.isInfixOf "PayPal-Request-Id: capture-"
      sent `shouldSatisfy` BS.isInfixOf "GET /v2/checkout/orders/SYNTHETIC-ORDER "
      length (filter (BS.isPrefixOf "PayPal-Request-Id:") (BS.lines sent)) `shouldBe` 1

  it "keeps generic provider response errors redacted at the legacy API boundary" $ do
    reader <- chunkReader [jsonWire "synthetic-private-invalid-json"]
    withProviderWire reader $ \manager _ _ _ -> do
      request <- paypalTransportRequest
      result <- runHandler $ runReaderT
        (Storefront.providerResponse manager Checkout.ProviderPayPal request)
        (error "Transport helper must not access the database")
        :: IO (Either ServerError A.Value)
      result `shouldSatisfy` isLeft
      either errHTTPCode (const 0) result `shouldBe` 502
      either (BL.toStrict . errBody) (const "unexpected success") result
        `shouldNotSatisfy` BS.isInfixOf "synthetic-private"

transportOrigins :: [(Checkout.PaymentProvider, String)]
transportOrigins =
  [ (Checkout.ProviderPayPal, "https://api-m.sandbox.paypal.com")
  , (Checkout.ProviderPayPal, "https://api-m.paypal.com")
  , (Checkout.ProviderDatafast, "https://test.oppwa.com")
  , (Checkout.ProviderDatafast, "https://eu-prod.oppwa.com")
  , (Checkout.ProviderPlaceToPay, "https://checkout-test.placetopay.ec")
  , (Checkout.ProviderPlaceToPay, "https://checkout.placetopay.ec")
  , (Checkout.ProviderPayPhone, "https://pay.payphonetodoesposible.com")
  ]

paypalTransportRequest :: IO HC.Request
paypalTransportRequest = ProviderHttp.parseProviderRequest Checkout.ProviderPayPal
  "https://api-m.sandbox.paypal.com/v2/checkout/orders" >>= requireRight

chunkReader :: [BS.ByteString] -> IO HC.BodyReader
chunkReader chunks = do
  remaining <- newIORef chunks
  pure $ atomicModifyIORef' remaining $ \current -> case current of
    [] -> ([], BS.empty)
    part : rest -> (rest, part)

jsonWire :: BS.ByteString -> BS.ByteString
jsonWire body = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: "
  <> BS.pack (show (BS.length body)) <> "\r\n\r\n" <> body

oauthFixture :: BS.ByteString
oauthFixture = "{\"access_token\":\"synthetic-access-token\",\"token_type\":\"Bearer\"}"

withProviderWire
  :: HC.BodyReader
  -> (HC.Manager -> IO Int -> IO BS.ByteString -> IO Int -> IO a)
  -> IO a
withProviderWire reader action = do
  connections <- newIORef (0 :: Int)
  writes <- newIORef []
  closes <- newIORef (0 :: Int)
  let connect _ _ _ = do
        modifyIORef' connections (+1)
        HC.makeConnection reader (\bytes -> modifyIORef' writes (bytes :))
          (modifyIORef' closes (+1))
      settings = HC.managerSetProxy HC.noProxy ProviderHttp.providerManagerSettings
        { HC.managerTlsConnection = pure connect
        , HC.managerRawConnection = pure connect }
  bracket (HC.newManager settings) HC.closeManager $ \manager ->
    action manager (readIORef connections) (BS.concat . reverse <$> readIORef writes) (readIORef closes)

spec :: Spec
spec = do
  describe "provider return checkout selection" $ do
    it "binds the public checkout selector without private capabilities" $ do
      providerReturnUrl "https://www.tdfrecords.net/pagos/retorno" "checkout-public-id"
        `shouldBe` "https://www.tdfrecords.net/pagos/retorno?tdf_checkout=checkout-public-id"
    it "keeps configured query and fragment after the server-owned selector" $ do
      providerReturnUrl "https://www.tdfrecords.net/pagos/retorno?lang=es#result" "checkout-public-id"
        `shouldBe` "https://www.tdfrecords.net/pagos/retorno?tdf_checkout=checkout-public-id&lang=es#result"
  describe "complete checkout capability policy" $
    it "requires the finishing operation and preserves extra restrictions idempotently" $ do
      forM_ [MethodCard, MethodBankRedirect, MethodDeunaQr, MethodPayPhoneWallet] $ \method -> do
        let request = (completionRequest method)
              { Capabilities.prRequiredCapabilities = [Capabilities.CapabilityPartialRefund] }
            normalized = Capabilities.requireCheckoutCompletion request
        Capabilities.prRequiredCapabilities normalized `shouldBe`
          [Capabilities.CapabilityPartialRefund, Capabilities.CapabilityOneTime,
           Capabilities.CapabilityServerVerification]
        Capabilities.requireCheckoutCompletion normalized `shouldBe` normalized
      Capabilities.prRequiredCapabilities (Capabilities.requireCheckoutCompletion
        (completionRequest MethodPayPalWallet)) `shouldBe`
        [Capabilities.CapabilityOneTime, Capabilities.CapabilityCapture]
      Capabilities.prRequiredCapabilities (Capabilities.requireCheckoutCompletion
        (completionRequest MethodManualBankTransfer)) `shouldBe` [Capabilities.CapabilityOneTime]
  reconciliationReportValidationSpec
  providerQueryReportValidationSpec
  providerTransportSpec
  notificationMinimizationSpec
  notificationIdentitySpec
  RefundSafety.spec
  RefundRecovery.spec
  configured <- runIO (lookupEnv "TDF_PROVIDER_RETRY_DATABASE_URL")
  case configured of
    Nothing -> pure ()
    Just url -> beforeAll (openDatabase url) $ afterAll destroyAllResources $
      describe "provider-retry-runtime PostgreSQL" $ do
        reconciliationReportSpec
        providerQueryReportSpec
        queryRecoverySpec
        noChargeReplaySpec
        notificationInboxSpec
        notificationIdentityInboxSpec
        reconciliationTransactionSpec
        fullDomainQuerySpec
        hostedServiceOrderSpec
        closedCheckoutEvidenceSpec
        captureReplaySpec
        ticketLedgerSpec
        ticketAllocationSpec
        legacyStripeRefundSpec
        latePaypalRefundSpec
        manualCaptureReplaySpec
        completionCapabilityIntegrationSpec
        RefundSafety.databaseSpec $ \pool provider amounts ->
          captureFixtureForDomainWithLines "service_booking" "payment" Checkout.AttemptProcessing amounts pool provider
        RefundRecovery.databaseSpec
          (captureFixtureForDomain "mixing_mastering" "capture" Checkout.AttemptProcessing)
        it "serializes different keys and permits only one active attempt" $ \pool -> do
          creation <- newCheckout pool
          results <- concurrently
            [ begin pool creation
            , begin pool creation { Checkout.pacIdempotencyKey = "concurrent-different-key" }
            ]
          length (rights results) `shouldBe` 1
          assertCounts pool creation 1 1

        it "replays the same key concurrently without another attempt or intent" $ \pool -> do
          creation <- newCheckout pool
          results <- concurrently [begin pool creation, begin pool creation]
          results `shouldSatisfy` all isRight
          case results of
            [first, second] -> first `shouldBe` second
            _ -> expectationFailure "Expected both concurrent requests to finish"
          assertCounts pool creation 1 1

        it "blocks every alternate rail and method while the result is ambiguous" $ \pool -> do
          creation <- newCheckout pool
          attempt <- begin pool creation >>= requireRight
          now <- getCurrentTime
          runSqlPool (Checkout.recordPaymentFailure
            (Checkout.pacCheckout creation) attempt Checkout.ProviderPlaceToPay
            "provider_transport_ambiguous" "provider-retry-test" now) pool
          forM_ [Checkout.ProviderPlaceToPay, Checkout.ProviderPayPhone,
              Checkout.ProviderPayPal, Checkout.ProviderDatafast] $ \provider -> do
            let method = case provider of
                  Checkout.ProviderPayPhone -> MethodPayPhoneWallet
                  Checkout.ProviderPayPal -> MethodPayPalWallet
                  _ -> MethodCard
            result <- runSqlPool (Runtime.beginPaymentAttemptForMethod method creation
              { Checkout.pacProvider = provider
              , Checkout.pacIdempotencyKey = "another-key-after-timeout"
              }) pool
            result `shouldSatisfy` isLeft
          result <- runSqlPool (Runtime.beginPaymentAttemptForMethod MethodBankRedirect creation
            { Checkout.pacIdempotencyKey = "another-method-after-timeout" }) pool
          result `shouldSatisfy` isLeft
          assertCounts pool creation 1 1

        it "creates a fresh intent and provider reference only after confirmed no-charge" $ \pool -> do
          creation <- newCheckout pool
          first <- begin pool creation >>= requireRight
          firstIntent <- intentFor pool first
          now <- getCurrentTime
          _ <- runSqlPool (Intent.transitionPaymentIntent (Intent.PaymentIntentReference firstIntent)
            PaymentFailureConfirmed "provider" "verified-test-decline" now) pool >>= requireRight
          second <- begin pool creation { Checkout.pacIdempotencyKey = "retry-after-verified-decline" }
            >>= requireRight
          second `shouldNotBe` first
          secondIntent <- intentFor pool second
          secondIntent `shouldNotBe` firstIntent
          providerReference Checkout.ProviderPlaceToPay (Checkout.paymentAttemptReferenceId first)
            `shouldNotBe` providerReference Checkout.ProviderPlaceToPay
              (Checkout.paymentAttemptReferenceId second)
          -- A stale replay recovers the old attempt; it cannot create a third one.
          begin pool creation `shouldReturn` Right first
          assertCounts pool creation 2 2

        it "preserves legacy intent keys, external references and idempotent bindings" $ \pool -> do
          creation <- newCheckout pool
          now <- getCurrentTime
          legacy <- runSqlPool (Intent.createPaymentIntent Intent.PaymentIntentCreation
            { Intent.picCheckout = Checkout.pacCheckout creation
            , Intent.picEnvironment = Checkout.CheckoutSandbox
            , Intent.picProvider = Checkout.ProviderPlaceToPay
            , Intent.picPaymentMethod = MethodCard
            , Intent.picCaptureMethod = Intent.CaptureAutomatic
            , Intent.picAmountMinor = 12515
            , Intent.picCurrency = "USD"
            , Intent.picIdempotencyKey = "payment-intent:legacy-provider-key"
            , Intent.picOccurredAt = now
            , Intent.picCorrelationId = "legacy-test"
            }) pool >>= requireRight
          attempt <- runSqlPool (Checkout.beginPaymentAttempt creation) pool >>= requireRight
          _ <- runSqlPool (Intent.bindPaymentAttemptToIntent (Intent.pisReference legacy) attempt)
            pool >>= requireRight
          let reference = providerReference Checkout.ProviderPlaceToPay
                (Checkout.checkoutReferenceId (Checkout.pacCheckout creation))
          operation <- runSqlPool (Execution.prepareProviderOperation Execution.ProviderOperationPreparation
            { Execution.popAttempt = attempt
            , Execution.popProvider = Checkout.ProviderPlaceToPay
            , Execution.popEnvironment = Checkout.CheckoutSandbox
            , Execution.popMerchantRef = "synthetic-provider-retry-merchant"
            , Execution.popProviderReference = reference
            , Execution.popOperation = AdapterCreate
            , Execution.popIdempotencyKey = Checkout.pacIdempotencyKey creation
            , Execution.popRequestSha256 = T.replicate 64 "a"
            , Execution.popOccurredAt = now
            }) pool >>= requireRight
          begin pool creation `shouldReturn` Right attempt
          runSqlPool (Execution.loadAttemptProviderReference attempt) pool
            `shouldReturn` Right (Just reference)
          claims <- concurrently $ replicate 2 $ runSqlPool
            (Execution.claimProviderOperation (Execution.porReference operation) now
              "synthetic-provider-retry-encryption-key") pool
          length [() | Right (Execution.ProviderOperationClaimed _) <- claims] `shouldBe` 1
          length [() | Right Execution.ProviderOperationBusy <- claims] `shouldBe` 1
          assertCounts pool creation 1 1

        it "rejects changed immutable fields and cross-checkout idempotency reuse" $ \pool -> do
          creation <- newCheckout pool
          _ <- begin pool creation >>= requireRight
          begin pool creation { Checkout.pacAmountMinor = 1 } >>= (`shouldSatisfy` isLeft)
          other <- newCheckout pool
          begin pool other { Checkout.pacIdempotencyKey = Checkout.pacIdempotencyKey creation }
            >>= (`shouldSatisfy` isLeft)
          runSqlPool (Runtime.beginPaymentAttemptForMethod MethodBankRedirect creation) pool
            >>= (`shouldSatisfy` isLeft)
          assertCounts pool creation 1 1
          assertCounts pool other 0 0

        it "does not silently backfill or reinterpret unbound historical attempts" $ \pool -> do
          creation <- newCheckout pool
          _ <- runSqlPool (Checkout.beginPaymentAttempt creation) pool >>= requireRight
          begin pool creation >>= (`shouldSatisfy` isLeft)
          assertCounts pool creation 1 0

        it "replays Datafast status verification on the original debit-sale attempt" $ \pool -> do
          seed <- newCheckout pool
          let creation = seed { Checkout.pacProvider = Checkout.ProviderDatafast }
              start value = runSqlPool (Runtime.beginPaymentAttempt value) pool
          origin <- start creation >>= requireRight
          now <- getCurrentTime
          runSqlPool (Checkout.recordPaymentProcessing (Checkout.pacCheckout creation) origin
            Checkout.ProviderDatafast "synthetic-datafast-status" now) pool
          start creation `shouldReturn` Right origin
          start creation { Checkout.pacIdempotencyKey = "datafast-different-key-while-pending" }
            >>= (`shouldSatisfy` isLeft)
          assertCounts pool creation 1 1

        it "keeps PayPal create and capture on one intent without allowing a second capture key" $ \pool -> do
          seed <- newCheckout pool
          let creation = seed { Checkout.pacProvider = Checkout.ProviderPayPal }
              start value = runSqlPool (Runtime.beginPaymentAttempt value) pool
          origin <- start creation >>= requireRight
          now <- getCurrentTime
          _ <- runSqlPool (Checkout.bindProviderResource Checkout.ProviderBindingCreation
            { Checkout.pbcAttempt = origin
            , Checkout.pbcCheckout = Checkout.pacCheckout creation
            , Checkout.pbcProvider = Checkout.ProviderPayPal
            , Checkout.pbcEnvironment = Checkout.CheckoutSandbox
            , Checkout.pbcMerchantRef = Checkout.pacMerchantRef creation
            , Checkout.pbcResourceType = "order"
            , Checkout.pbcProviderResource = "synthetic-" <> Checkout.paymentAttemptReferenceId origin
            , Checkout.pbcResourcePath = Nothing
            , Checkout.pbcOrderReference = Checkout.checkoutReferenceId (Checkout.pacCheckout creation)
            , Checkout.pbcAmountMinor = 12515
            , Checkout.pbcCurrency = "USD"
            , Checkout.pbcStage = Checkout.AttemptRequiresCustomerAction
            , Checkout.pbcOccurredAt = now
            , Checkout.pbcCorrelationId = "synthetic-paypal-create"
            }) pool >>= requireRight
          let capture = creation
                { Checkout.pacOperation = Checkout.OperationCapture
                , Checkout.pacIdempotencyKey = "paypal-capture-original-key"
                }
          captured <- start capture >>= requireRight
          firstIntent <- intentFor pool origin
          intentFor pool captured `shouldReturn` firstIntent
          start capture `shouldReturn` Right captured
          start capture { Checkout.pacIdempotencyKey = "paypal-capture-different-key" }
            >>= (`shouldSatisfy` isLeft)
          assertCounts pool creation 2 1

        describe "exact create response recovery" $ do
          forM_ [Checkout.ProviderPlaceToPay, Checkout.ProviderPayPhone] $ \provider ->
            forM_ ["paid", "expired", "cancelled", "refunded", "disputed"] $ \checkoutStatus ->
              it ("recovers " <> show provider <> " after checkout " <> T.unpack checkoutStatus) $
                \pool -> withRecoveryEnvironment $ do
                  (creation, operation, request) <- replayFixture pool provider
                  closeCheckout pool creation checkoutStatus
                  setOperationState pool operation "succeeded" "succeeded"
                  recovered <- replayHandler pool creation request >>= requireRight
                  pssAttemptId recovered `shouldBe`
                    Checkout.paymentAttemptReferenceId (Execution.porAttempt operation)
                  pssState recovered `shouldBe` "succeeded"
                  pssCanRetryOrFallback recovered `shouldBe` False
                  assertCounts pool creation 1 1

          it "recovers with suspended accounts and absent provider credentials" $ \pool ->
            withRecoveryEnvironment $ do
              (creation, operation, request) <- replayFixture pool Checkout.ProviderPlaceToPay
              setOperationState pool operation "ambiguous" "ambiguous"
              let suspend enabled status = runSqlPool (rawExecute
                    "UPDATE commerce_provider_account SET enabled=?,status=?\
                    \ WHERE provider='placetopay' AND environment='sandbox'"
                    [PersistBool enabled, PersistText status]) pool
              bracket (suspend False "suspended") (const (suspend True "ready")) $ \_ -> do
                recovered <- replayHandler pool creation request >>= requireRight
                pssState recovered `shouldBe` "ambiguous"
                pssCanRetryOrFallback recovered `shouldBe` False
              assertCounts pool creation 1 1

          it "normalizes the exact contact replay without requiring an unexpired payable state" $ \pool ->
            withRecoveryEnvironment $ do
              (creation, operation, request) <- replayFixture pool Checkout.ProviderPayPhone
              closeCheckout pool creation "paid"
              setOperationState pool operation "succeeded" "succeeded"
              recovered <- replayHandler pool creation request
                { pscBuyerPhone = Just " 991234567 ", pscBuyerCountryCode = Just " 593 " }
                >>= requireRight
              pssState recovered `shouldBe` "succeeded"
              assertCounts pool creation 1 1

          it "requires the operation decryption key even when provider secrets are absent" $ \pool ->
            withRecoveryEnvironment $ do
              (creation, operation, request) <- replayFixture pool Checkout.ProviderPlaceToPay
              setOperationState pool operation "processing" "ambiguous"
              setEnv "COMMERCE_EVENT_ENCRYPTION_KEY" ""
              replayHandler pool creation request >>= assertHttpError 503
              assertCounts pool creation 1 1

          it "returns every contacted operation state without claiming it again" $ \pool ->
            withRecoveryEnvironment $ forM_
              [("in_flight", "ambiguous"), ("requires_customer_action", "ambiguous")
              , ("processing", "ambiguous"), ("confirmed_no_charge", "confirmed_no_charge")
              , ("failed", "rejected_before_creation")] $ \(status, certainty) -> do
                (creation, operation, request) <- replayFixture pool Checkout.ProviderPlaceToPay
                closeCheckout pool creation "expired"
                setOperationState pool operation status certainty
                recovered <- replayHandler pool creation request >>= requireRight
                pssState recovered `shouldBe` status
                if status == "requires_customer_action"
                  then pssRedirectUrl recovered `shouldBe`
                    Just "https://checkout-test.placetopay.ec/session/synthetic-recovery"
                  else pure ()
                assertCounts pool creation 1 1

          it "rejects changed method, contact, provider, key and lookup authorization" $ \pool ->
            withRecoveryEnvironment $ do
              (creation, operation, request) <- replayFixture pool Checkout.ProviderPayPhone
              closeCheckout pool creation "expired"
              setOperationState pool operation "processing" "ambiguous"
              forM_ [request { pscPaymentMethod = "card" }
                    , request { pscBuyerPhone = Just "991234568" }
                    , request { pscBuyerCountryCode = Just "1" }
                    , request { pscBuyerPhone = Nothing }] $ \changed ->
                replayHandler pool creation changed >>= assertHttpError 409
              replayHandler pool creation request { pscProvider = "placetopay" }
                >>= assertHttpError 404
              replayHandler pool creation { Checkout.pacIdempotencyKey = "changed-recovery-key" }
                request >>= assertHttpError 404
              let checkoutId = Checkout.checkoutReferenceId (Checkout.pacCheckout creation)
              runSqlPool (rawExecute
                "UPDATE commerce_checkout_session SET lookup_token_hash=? WHERE id=?::uuid"
                [PersistText "revoked-synthetic-token", PersistText checkoutId]) pool
              replayHandler pool creation request >>= assertHttpError 404
              assertCounts pool creation 1 1

          it "does not reveal another checkout operation using its request key" $ \pool ->
            withRecoveryEnvironment $ do
              (creation, operation, request) <- replayFixture pool Checkout.ProviderPlaceToPay
              setOperationState pool operation "processing" "ambiguous"
              (other, _, _) <- replayFixture pool Checkout.ProviderPlaceToPay
              closeCheckout pool other "expired"
              replayHandler pool other
                { Checkout.pacIdempotencyKey = Checkout.pacIdempotencyKey creation } request
                >>= assertHttpError 404
              assertCounts pool other 1 1

          it "does not contact a merely prepared operation on an expired checkout" $ \pool ->
            withRecoveryEnvironment $ do
              (creation, operation, request) <- replayFixture pool Checkout.ProviderPlaceToPay
              closeCheckout pool creation "expired"
              replayHandler pool creation request >>= assertHttpError 404
              let checkoutId = Checkout.checkoutReferenceId (Checkout.pacCheckout creation)
              stored <- runSqlPool (Execution.loadAuthorizedCreateOperation checkoutId
                (Checkout.paymentAttemptReferenceId (Execution.porAttempt operation))
                (digestText checkoutId) recoveryEncryptionKey) pool >>= requireRight
              Execution.porStatus stored `shouldBe` "prepared"
              assertCounts pool creation 1 1

          it "replays concurrently without additional operations or intent mutations" $ \pool ->
            withRecoveryEnvironment $ do
              (creation, operation, request) <- replayFixture pool Checkout.ProviderPlaceToPay
              closeCheckout pool creation "paid"
              setOperationState pool operation "succeeded" "succeeded"
              results <- concurrently (replicate 4 (replayHandler pool creation request))
              results `shouldSatisfy` all isRight
              length (rights results) `shouldBe` 4
              map (fmap pssOperationId) results `shouldBe`
                replicate 4 (Right (Execution.providerOperationReferenceId
                  (Execution.porReference operation)))
              assertCounts pool creation 1 1

notificationMinimizationSpec :: Spec
notificationMinimizationSpec = describe "provider notification evidence minimization" $ do
  it "retains only opaque refund correlation and preserves minimization idempotency" $ do
    forM_ ["f8409c7d-7a78-48c1-b07f-e0126f909ef4",privateMarker] $ \correlation -> do
      let original = encodeStrict $ A.object
            ["id" A..= ("WH-CORRELATION" :: Text),"event_type" A..= ("PAYMENT.CAPTURE.REFUNDED" :: Text)
            ,"create_time" A..= notificationTime
            ,"resource" A..= A.object ["id" A..= ("R-CORRELATION" :: Text),"custom_id" A..= correlation]]
      retained <- requireRight (Event.minimizeProviderEventPayload Checkout.ProviderPayPal original)
      BS.isInfixOf (TE.encodeUtf8 correlation) retained `shouldBe` (correlation /= privateMarker)
      Event.minimizeProviderEventPayload Checkout.ProviderPayPal retained `shouldBe` Right retained

  it "drops arbitrary PayPal fields recursively without changing capture evidence" $ do
    let original = paypalNotification "WH-SYNTHETIC" "125.15" privateMarker
    retained <- requireRight (Event.minimizeProviderEventPayload Checkout.ProviderPayPal original)
    BS.isInfixOf (TE.encodeUtf8 privateMarker) retained `shouldBe` False
    originalEnvelope <- requireRight (Storefront.parsePaypalWebhookEnvelope (BL.fromStrict original))
    retainedEnvelope <- requireRight (Storefront.parsePaypalWebhookEnvelope (BL.fromStrict retained))
    Storefront.parsePaypalWebhookCapture retainedEnvelope
      `shouldBe` Storefront.parsePaypalWebhookCapture originalEnvelope
    forM_ ["PAYMENT.CAPTURE.REFUNDED", "PAYMENT.CAPTURE.REVERSED"] $ \eventType -> do
      let envelope = A.object
            [ "id" A..= ("WH-SYNTHETIC" :: Text), "event_type" A..= (eventType :: Text)
            , "create_time" A..= notificationTime
            , "resource" A..= Storefront.pweResource originalEnvelope ]
      minimized <- requireRight (Event.minimizeProviderEventPayload
        Checkout.ProviderPayPal (encodeStrict envelope))
      parsed <- requireRight (Storefront.parsePaypalWebhookEnvelope (BL.fromStrict minimized))
      Storefront.parsePaypalWebhookCapture parsed
        `shouldBe` Storefront.parsePaypalWebhookCapture originalEnvelope

  it "retains no unused resource fields for unsupported PayPal events" $ do
    let payload = encodeStrict $ A.object
          [ "id" A..= ("WH-IGNORED" :: Text), "event_type" A..= ("CUSTOMER.DISPUTE.CREATED" :: Text)
          , "create_time" A..= notificationTime
          , "resource" A..= A.object ["id" A..= ("CASE-1" :: Text), "evidence" A..= privateMarker] ]
    retained <- requireRight (Event.minimizeProviderEventPayload Checkout.ProviderPayPal payload)
    BS.isInfixOf (TE.encodeUtf8 privateMarker) retained `shouldBe` False
    parsed <- requireRight (Storefront.parsePaypalWebhookEnvelope (BL.fromStrict retained))
    Storefront.pweResource parsed `shouldBe` A.object ["id" A..= ("CASE-1" :: Text)]

  it "preserves PlaceToPay signed fields and still rejects a wrong signing secret" $ do
    let original = placeToPayNotification privateMarker
        config = PlaceToPay.PlaceToPayConfig Checkout.CheckoutSandbox
          "synthetic-login" "synthetic-secret" []
    retained <- requireRight (Event.minimizeProviderEventPayload Checkout.ProviderPlaceToPay original)
    BS.isInfixOf (TE.encodeUtf8 privateMarker) retained `shouldBe` False
    originalValue <- requireRight (A.eitherDecodeStrict' original)
    retainedValue <- requireRight (A.eitherDecodeStrict' retained)
    let assessed = PlaceToPay.verifyPlaceToPayNotification config retainedValue
    assessed `shouldSatisfy` isRight
    assessed `shouldBe` PlaceToPay.verifyPlaceToPayNotification config originalValue
    PlaceToPay.verifyPlaceToPayNotification config { PlaceToPay.ptpSecretKey = "wrong-secret" }
      retainedValue `shouldSatisfy` isLeft

  it "canonicalizes PayPhone aliases and drops untrusted status/customer data" $ do
    let alias = encodeStrict $ A.object
          [ "id" A..= (1234 :: Int), "clientTransactionID" A..= ("CLIENT-1" :: Text)
          , "StoreId" A..= ("synthetic-store" :: Text), "StatusCode" A..= (3 :: Int)
          , "card" A..= privateMarker ]
    retained <- requireRight (Event.minimizeProviderEventPayload Checkout.ProviderPayPhone alias)
    retained `shouldBe` encodeStrict (A.object
      [ "TransactionId" A..= (1234 :: Int), "ClientTransactionId" A..= ("CLIENT-1" :: Text)
      , "StoreId" A..= ("synthetic-store" :: Text) ])
    adapter <- requireRight (PayPhone.payPhoneAdapter
      (PayPhone.PayPhoneConfig "synthetic-token" "synthetic-store"))
    value <- requireRight (A.eitherDecodeStrict' retained)
    assessment <- requireRight (Adapter.adapterAssessNotification adapter value)
    Adapter.notificationExternalId assessment `shouldBe` "1234"
    Adapter.notificationMerchantReference assessment `shouldBe` Just "CLIENT-1"
    Adapter.notificationAuthenticated assessment `shouldBe` False
    Adapter.notificationRequiresQuery assessment `shouldBe` True

  it "is idempotent for every supported evidence schema" $
    forM_ notificationProviders $ \provider -> do
      let original = notificationPayload provider "EVENT-1" privateMarker
      retained <- requireRight (Event.minimizeProviderEventPayload provider original)
      Event.minimizeProviderEventPayload provider retained `shouldBe` Right retained

  it "rejects malformed, oversized, wrong-type and unsupported evidence without echoing input" $ do
    forM_ ["{\"SYNTHETIC-PRIVATE\":", "[]", "{}", BS.replicate (1024 * 1024 + 1) 'x'
      , "{\"TransactionId\":1.5,\"ClientTransactionId\":\"CLIENT-1\"}"
      , "{\"TransactionId\":-1,\"ClientTransactionId\":\"CLIENT-1\"}"
      , "{\"TransactionId\":1,\"ClientTransactionId\":{\"card\":\"SYNTHETIC-PRIVATE\"}}"] $ \raw ->
        forM_ notificationProviders $ \provider -> do
          let result = Event.minimizeProviderEventPayload provider raw
          result `shouldSatisfy` isLeft
          show result `shouldNotContain` "SYNTHETIC-PRIVATE"
    Event.minimizeProviderEventPayload Checkout.ProviderDatafast
      (paypalNotification "WH-1" "125.15" privateMarker) `shouldSatisfy` isLeft

  it "does not echo malformed PayPal JSON in public parser errors" $ do
    let result = Storefront.parsePaypalWebhookEnvelope "{\"SYNTHETIC-PRIVATE\":"
    result `shouldSatisfy` isLeft
    show result `shouldNotContain` "SYNTHETIC-PRIVATE"

  it "rejects nested retained-field objects, excessive field lengths and invalid timestamps" $ do
    let invalidPayPal = encodeStrict $ A.object
          [ "id" A..= ("WH-INVALID" :: Text), "event_type" A..= ("PAYMENT.CAPTURE.COMPLETED" :: Text)
          , "create_time" A..= notificationTime
          , "resource" A..= A.object ["amount" A..= A.object
              ["value" A..= A.object ["card" A..= privateMarker]]] ]
        invalidPlaceToPay = encodeStrict $ A.object
          [ "requestId" A..= (1234 :: Int)
          , "status" A..= A.object ["status" A..= ("APPROVED" :: Text), "date" A..= privateMarker]
          , "signature" A..= ("sha256:" <> T.replicate 64 "a") ]
        invalidPayPhone = encodeStrict $ A.object
          [ "TransactionId" A..= (1234 :: Int), "ClientTransactionId" A..= T.replicate 129 "x" ]
    forM_ [(Checkout.ProviderPayPal, invalidPayPal), (Checkout.ProviderPlaceToPay, invalidPlaceToPay)
      , (Checkout.ProviderPayPhone, invalidPayPhone)] $ \(provider, raw) -> do
        let result = Event.minimizeProviderEventPayload provider raw
        result `shouldSatisfy` isLeft
        show result `shouldNotContain` T.unpack privateMarker

notificationInboxSpec :: SpecWith ConnectionPool
notificationInboxSpec = describe "minimized notification inbox" $ do
  forM_ notificationProviders $ \provider ->
    it ("encrypts only retained " <> T.unpack (Checkout.paymentProviderText provider) <> " fields") $ \pool -> do
      creation <- newNotification provider
      stored <- storeNotification pool creation >>= requireRight
      Event.pesInserted stored `shouldBe` True
      retained <- requireRight (Event.minimizeProviderEventPayload provider (Event.pecRawPayload creation))
      readStoredNotification pool stored `shouldReturn` retained
      BS.isInfixOf (TE.encodeUtf8 privateMarker) retained `shouldBe` False
      claim <- runSqlPool (Event.claimProviderEvent (Event.pesReference stored) notificationTime) pool
      claim `shouldBe` Event.ProviderEventClaimed 1
      loaded <- runSqlPool (Event.loadProviderEventPayload (Event.pesReference stored) recoveryEncryptionKey)
        pool >>= requireRight
      Event.pepRawPayload loaded `shouldBe` retained
      show loaded `shouldBe` "ProviderEventPayload {payload = <redacted>}"
      if provider == Checkout.ProviderPayPal
        then EventWorker.validateStoredPaypalEvent loaded `shouldSatisfy` isRight
        else pure ()

  it "deduplicates ignored-field variations concurrently on one immutable event" $ \pool -> do
    creation <- newNotification Checkout.ProviderPayPal
    let variant = creation { Event.pecRawPayload = paypalNotification
          (Event.pecProviderEventId creation) "125.15" "DIFFERENT-SYNTHETIC-PRIVATE" }
    stored <- concurrently [storeNotification pool creation, storeNotification pool variant]
    results <- mapM requireRight stored
    length [() | result <- results, Event.pesInserted result] `shouldBe` 1
    map Event.pesReference results `shouldSatisfy` (\refs -> head refs == last refs)

  it "rejects changed monetary evidence, metadata, resource and trust on replay" $ \pool -> do
    creation <- newNotification Checkout.ProviderPayPal
    _ <- storeNotification pool creation >>= requireRight
    let changedAmount = creation { Event.pecRawPayload = paypalNotification
          (Event.pecProviderEventId creation) "0.01" privateMarker }
    forM_ [changedAmount, creation { Event.pecProviderResource = Just "OTHER-CAPTURE" }
      , creation { Event.pecEventType = "PAYMENT.CAPTURE.REVERSED" }
      , creation { Event.pecProviderCreatedAt = Just (addUTCTime 1 notificationTime) }] $ \changed ->
        storeNotification pool changed >>= (`shouldSatisfy` isLeft)
    runSqlPool (Event.storeUntrustedProviderEvent creation) pool >>= (`shouldSatisfy` isLeft)

  forM_ notificationProviders $ \provider ->
    it ("preserves exact historical raw " <> T.unpack (Checkout.paymentProviderText provider) <> " redelivery") $ \pool -> do
      creation <- newNotification provider
      historical <- insertHistoricalNotification pool creation
      replay <- storeNotification pool creation >>= requireRight
      Event.pesReference replay `shouldBe` historical
      Event.pesInserted replay `shouldBe` False
      readStoredNotification pool replay `shouldReturn` Event.pecRawPayload creation

  it "rejects malformed evidence before creating an inbox row" $ \pool -> do
    creation <- newNotification Checkout.ProviderPayPal
    result <- storeNotification pool creation { Event.pecRawPayload = "{\"card\":\"SYNTHETIC-PRIVATE\"}" }
    result `shouldSatisfy` isLeft
    counts <- runSqlPool (rawSql
      "SELECT count(*) FROM commerce_provider_event_inbox WHERE provider_event_id=?"
      [PersistText (Event.pecProviderEventId creation)] :: SqlPersistT IO [Single Int64]) pool
    counts `shouldBe` [Single 0]

notificationIdentitySpec :: Spec
notificationIdentitySpec = describe "provider PlaceToPay signed notification identity" $ do
  it "pins the v2 array encoding with an independently calculated SHA-256 golden" $
    Event.placeToPayNotificationEventId (placeToPayNotification privateMarker)
      `shouldBe` Right "ptp-v2-59b4f46382c7696e27c2062275a40c2ae1970a83c035853876fb48b1f436c35d"

  it "ignores unsigned fields, whitespace, numeric spelling, escaped keys and signature casing" $ do
    let expected = Event.placeToPayNotificationEventId (placeToPayNotification privateMarker)
    forM_ placeToPayReplayVariants $ \raw -> do
      Event.placeToPayNotificationEventId raw `shouldBe` expected
      value <- requireRight (A.eitherDecodeStrict' raw)
      PlaceToPay.verifyPlaceToPayNotification notificationConfig value `shouldSatisfy` isRight

  it "keeps different signed request IDs, statuses, dates and signatures distinct" $ do
    let original = Event.placeToPayNotificationEventId (placeToPayNotification privateMarker)
    forM_ [signedPlaceToPayNotification 1235 "APPROVED" "2026-09-14T12:00:00Z" "synthetic-secret" ""
      , signedPlaceToPayNotification 1234 "REJECTED" "2026-09-14T12:00:00Z" "synthetic-secret" ""
      , signedPlaceToPayNotification 1234 "APPROVED" "2026-09-14T12:00:01Z" "synthetic-secret" ""
      , signedPlaceToPayNotification 1234 "APPROVED" "2026-09-14T12:00:00Z" "rotated-synthetic-secret" ""] $ \raw -> do
        Event.placeToPayNotificationEventId raw `shouldSatisfy` isRight
        Event.placeToPayNotificationEventId raw `shouldNotBe` original

  it "does not merge different field tuples even if provider concatenation is identical" $ do
    let first = signedPlaceToPayNotification 12 "34APPROVED" "2026-09-14T12:00:00Z" "synthetic-secret" ""
    Event.placeToPayNotificationEventId first
      `shouldNotBe` Event.placeToPayNotificationEventId (placeToPayNotification "")

  it "rejects invalid identity shapes and redacts payload details" $
    forM_ ["[]", "{}", "{\"SYNTHETIC-PRIVATE\":", BS.replicate (1024 * 1024 + 1) 'x'
      , signedPlaceToPayNotification (-1) "APPROVED" "2026-09-14T12:00:00Z" "synthetic-secret" ""
      , signedPlaceToPayNotification 1234 "APPROVED" "not-a-date" "synthetic-secret" ""] $ \raw -> do
        let result = Event.placeToPayNotificationEventId raw
        result `shouldSatisfy` isLeft
        show result `shouldNotContain` "SYNTHETIC-PRIVATE"

  it "never treats successful identity derivation as authentication" $ do
    let raw = signedPlaceToPayNotification 1234 "APPROVED" "2026-09-14T12:00:00Z" "wrong-secret" ""
    Event.placeToPayNotificationEventId raw `shouldSatisfy` isRight
    value <- requireRight (A.eitherDecodeStrict' raw)
    PlaceToPay.verifyPlaceToPayNotification notificationConfig value `shouldSatisfy` isLeft

notificationIdentityInboxSpec :: SpecWith ConnectionPool
notificationIdentityInboxSpec = describe "PlaceToPay signed identity inbox" $ do
  it "refuses to bypass signed deduplication through the untrusted store" $ \pool -> do
    creation <- newNotification Checkout.ProviderPlaceToPay
    runSqlPool (Event.storeUntrustedProviderEvent creation) pool >>= (`shouldSatisfy` isLeft)
    notificationRowCount pool creation `shouldReturn` 0

  it "converges concurrent raw-body and caller-ID variations on one row and one claim" $ \pool -> do
    creation <- newNotification Checkout.ProviderPlaceToPay
    results <- concurrently
      [storeNotification pool creation { Event.pecRawPayload = raw
        , Event.pecProviderEventId = "CALLER-" <> T.pack (show n) }
      | (n, raw) <- zip [1 :: Int ..] placeToPayReplayVariants] >>= mapM requireRight
    length (filter Event.pesInserted results) `shouldBe` 1
    first <- case results of
      result : _ -> pure result
      [] -> fail "Expected concurrent notification results"
    map Event.pesReference results `shouldSatisfy` all (== Event.pesReference first)
    notificationRowCount pool creation `shouldReturn` 1
    claims <- concurrently (replicate 4 (runSqlPool
      (Event.claimProviderEvent (Event.pesReference first) notificationTime) pool))
    length [() | Event.ProviderEventClaimed _ <- claims] `shouldBe` 1

  it "does not requeue a processed canonical notification" $ \pool -> do
    creation <- newNotification Checkout.ProviderPlaceToPay
    stored <- storeNotification pool creation >>= requireRight
    _ <- runSqlPool (Event.claimProviderEvent (Event.pesReference stored) notificationTime) pool
    runSqlPool (Event.markProviderEventProcessed (Event.pesReference stored)
      Nothing Nothing Nothing notificationTime) pool
    replay <- storeNotification pool creation { Event.pecRawPayload = last placeToPayReplayVariants }
      >>= requireRight
    Event.pesReference replay `shouldBe` Event.pesReference stored
    Event.pesInserted replay `shouldBe` False
    runSqlPool (Event.claimProviderEvent (Event.pesReference replay) notificationTime) pool
      `shouldReturn` Event.ProviderEventAlreadyHandled "processed"

  it "scopes deduplication by merchant and environment" $ \pool -> do
    creation <- newNotification Checkout.ProviderPlaceToPay
    results <- mapM (storeNotification pool)
      [creation, creation { Event.pecMerchantRef = Event.pecMerchantRef creation <> "-other" }
      , creation { Event.pecEnvironment = Checkout.CheckoutProduction }] >>= mapM requireRight
    map Event.pesInserted results `shouldBe` [True, True, True]

  it "retains separate out-of-order signed states for authoritative reconciliation" $ \pool -> do
    creation <- newNotification Checkout.ProviderPlaceToPay
    let changed = creation { Event.pecRawPayload = signedPlaceToPayNotification
          1234 "PENDING" "2026-09-14T11:00:00Z" "synthetic-secret" "" }
    results <- mapM (storeNotification pool) [creation, changed, changed, creation] >>= mapM requireRight
    map Event.pesInserted results `shouldBe` [True, True, False, False]
    notificationRowCount pool creation `shouldReturn` 2

  it "rejects immutable metadata changes on canonical and historical replay" $ \pool -> do
    forM_ [False, True] $ \historical -> do
      creation <- newNotification Checkout.ProviderPlaceToPay
      if historical then insertHistoricalNotification pool creation >> pure ()
        else storeNotification pool creation >>= requireRight >> pure ()
      forM_ [creation { Event.pecProviderResource = Just "OTHER-RESOURCE" }
        , creation { Event.pecEventType = "OTHER_EVENT" }
        , creation { Event.pecProviderCreatedAt = Just notificationTime }] $ \changed ->
          storeNotification pool changed >>= (`shouldSatisfy` isLeft)
      notificationRowCount pool creation `shouldReturn` 1

  it "preserves exact historical uppercase minimized evidence without rewriting it" $ \pool -> do
    creation <- newNotification Checkout.ProviderPlaceToPay
    let raw = uppercasePlaceToPaySignature (Event.pecRawPayload creation)
    -- Independently reconstruct the prior projection, which retained hex casing.
    value <- requireRight (A.eitherDecodeStrict' raw)
    let oldProjection = case value of
          A.Object fields -> encodeStrict (A.Object (KM.filterWithKey
            (\key _ -> key == "requestId" || key == "signature" || key == "status")
            (KM.mapWithKey (\key status -> if key /= "status" then status else case status of
              A.Object details -> A.Object (KM.delete "message" details)
              _ -> status) fields)))
          _ -> error "Expected synthetic object"
        replayCreation = creation { Event.pecRawPayload = raw, Event.pecProviderEventId = legacyPlaceToPayId raw }
    historical <- insertHistoricalNotification pool replayCreation { Event.pecRawPayload = oldProjection }
    replay <- storeNotification pool replayCreation >>= requireRight
    Event.pesReference replay `shouldBe` historical
    Event.pesInserted replay `shouldBe` False
    readStoredNotification pool replay `shouldReturn` oldProjection

  it "bounds reformatted pre-upgrade delivery to one canonical row and preserves the old row" $ \pool -> do
    creation <- newNotification Checkout.ProviderPlaceToPay
    historical <- insertHistoricalNotification pool creation
    results <- concurrently
      [storeNotification pool creation { Event.pecRawPayload = raw }
      | raw <- drop 1 placeToPayReplayVariants] >>= mapM requireRight
    length (filter Event.pesInserted results) `shouldBe` 1
    notificationRowCount pool creation `shouldReturn` 2
    replay <- storeNotification pool creation >>= requireRight
    Event.pesReference replay `shouldBe` historical
    readStoredNotification pool replay `shouldReturn` Event.pecRawPayload creation

  it "authenticates the original callback before identity persistence at the Servant handler" $ \pool ->
    withNotificationEnvironment $ do
      let bad = signedPlaceToPayNotification 991238 "APPROVED" "2026-09-14T12:00:00Z" "wrong-secret" privateMarker
      countBefore <- handlerNotificationCount pool
      failed <- notificationHandler pool bad
      either (\err -> do
        errHTTPCode err `shouldBe` 401
        BL.toStrict (errBody err) `shouldSatisfy` (not . BS.isInfixOf (TE.encodeUtf8 privateMarker)))
        (const (expectationFailure "Forged callback was accepted")) failed
      handlerNotificationCount pool `shouldReturn` countBefore
      let good = signedPlaceToPayNotification 991238 "APPROVED" "2026-09-14T12:00:00Z" "synthetic-secret" privateMarker
      notificationHandler pool good >>= (`shouldSatisfy` isRight)
      notificationHandler pool ("\n " <> uppercasePlaceToPaySignature good <> "\n") >>= (`shouldSatisfy` isRight)
      handlerNotificationCount pool `shouldReturn` (countBefore + 1)

notificationConfig :: PlaceToPay.PlaceToPayConfig
notificationConfig = PlaceToPay.PlaceToPayConfig Checkout.CheckoutSandbox "synthetic-login" "synthetic-secret" []

legacyPlaceToPayId :: BS.ByteString -> Text
legacyPlaceToPayId raw = "ptp-" <> digestText (TE.decodeUtf8 raw)

uppercasePlaceToPaySignature :: BS.ByteString -> BS.ByteString
uppercasePlaceToPaySignature raw = case A.eitherDecodeStrict' raw of
  Right (A.Object fields) -> encodeStrict $ A.Object $ KM.mapWithKey
    (\key value -> if key /= "signature" then value else case value of
      A.String signature -> A.String (T.toUpper signature); _ -> value) fields
  _ -> error "Expected synthetic PlaceToPay object"

placeToPayReplayVariants :: [BS.ByteString]
placeToPayReplayVariants =
  [ placeToPayNotification privateMarker
  , placeToPayNotification "DIFFERENT-SYNTHETIC-PRIVATE"
  , " \n" <> placeToPayNotification "" <> "\n "
  , uppercasePlaceToPaySignature (placeToPayNotification "")
  , TE.encodeUtf8 (T.replace "1234" "1234.0" (TE.decodeUtf8 (placeToPayNotification "")))
  , TE.encodeUtf8 (T.replace "requestId" "request\\u0049d" (TE.decodeUtf8 (placeToPayNotification "")))
  , "{\"status\":{\"date\":\"2026-09-14T12:00:00Z\",\"status\":\"APPROV\\u0045D\"},"
      <> "\"signature\":\"sha256:" <> TE.encodeUtf8 (digestText "1234APPROVED2026-09-14T12:00:00Zsynthetic-secret")
      <> "\",\"requestId\":1234,\"reference\":\"\"}"
  ]

notificationRowCount :: ConnectionPool -> Event.ProviderEventCreation -> IO Int64
notificationRowCount pool creation = do
  rows <- runSqlPool (rawSql
    "SELECT count(*) FROM commerce_provider_event_inbox WHERE provider='placetopay'\
    \ AND merchant_account_ref=?"
    [PersistText (Event.pecMerchantRef creation)] :: SqlPersistT IO [Single Int64]) pool
  case rows of [Single count] -> pure count; _ -> fail "Expected one count"

notificationHandler :: ConnectionPool -> BS.ByteString -> IO (Either ServerError NoContent)
notificationHandler pool raw = do
  let _ :<|> _ :<|> receive :<|> _ = providerExecutionServer
  runHandler (runReaderT (receive (BL.fromStrict raw)) (Env pool (error "Notification must not use AppConfig")))

handlerNotificationCount :: ConnectionPool -> IO Int64
handlerNotificationCount pool = do
  creation <- newNotification Checkout.ProviderPlaceToPay
  notificationRowCount pool creation { Event.pecMerchantRef = "synthetic-provider-retry-merchant" }

withNotificationEnvironment :: IO a -> IO a
withNotificationEnvironment action = bracket
  (forM values $ \(name, _) -> (,) name <$> lookupEnv name)
  (mapM_ (\(name, value) -> maybe (unsetEnv name) (setEnv name) value)) $ \_ -> do
    forM_ values (uncurry setEnv)
    action
  where values =
          [("COMMERCE_CHECKOUT_ENV", "sandbox"), ("COMMERCE_EVENT_ENCRYPTION_KEY", T.unpack recoveryEncryptionKey)
          , ("PLACETOPAY_LOGIN", "synthetic-login"), ("PLACETOPAY_SECRET_KEY", "synthetic-secret")
          , ("PLACETOPAY_RETURN_URL", "https://example.invalid/return")
          , ("PLACETOPAY_NOTIFICATION_URL", "https://example.invalid/notify")
          , ("PLACETOPAY_CARD_PAYMENT_METHODS", ""), ("PLACETOPAY_BANK_PAYMENT_METHODS", "")
          , ("PLACETOPAY_DEUNA_PAYMENT_METHODS", ""), ("PAYPHONE_TOKEN", "synthetic-token")
          , ("PAYPHONE_STORE_ID", "synthetic-store"), ("PAYPHONE_RESPONSE_URL", "https://example.invalid/return")]

notificationProviders :: [Checkout.PaymentProvider]
notificationProviders = [Checkout.ProviderPayPal, Checkout.ProviderPlaceToPay, Checkout.ProviderPayPhone]

privateMarker :: Text
privateMarker = "SYNTHETIC-PRIVATE-CARD-CUSTOMER-TOKEN"

notificationTime :: UTCTime
notificationTime = UTCTime (fromGregorian 2026 9 14) (12 * 60 * 60)

encodeStrict :: A.Value -> BS.ByteString
encodeStrict = BL.toStrict . A.encode

paypalNotification :: Text -> Text -> Text -> BS.ByteString
paypalNotification eventId amount privateValue = encodeStrict $ A.object
  [ "id" A..= eventId, "event_type" A..= ("PAYMENT.CAPTURE.COMPLETED" :: Text)
  , "create_time" A..= notificationTime, "payer" A..= privateValue
  , "resource" A..= A.object
      [ "id" A..= ("CAPTURE-1" :: Text), "status" A..= ("COMPLETED" :: Text)
      , "amount" A..= A.object ["value" A..= amount, "currency_code" A..= ("USD" :: Text)
          , "card" A..= privateValue]
      , "payee" A..= A.object ["merchant_id" A..= ("MERCHANT-1" :: Text), "email" A..= privateValue]
      , "supplementary_data" A..= A.object ["related_ids" A..= A.object
          ["order_id" A..= ("ORDER-1" :: Text), "token" A..= privateValue], "payer" A..= privateValue]
      , "payment_source" A..= A.object ["card" A..= privateValue]
      , "links" A..= [privateValue], "description" A..= privateValue ] ]

placeToPayNotification :: Text -> BS.ByteString
placeToPayNotification = signedPlaceToPayNotification 1234 "APPROVED" "2026-09-14T12:00:00Z" "synthetic-secret"

signedPlaceToPayNotification :: Int64 -> Text -> Text -> Text -> Text -> BS.ByteString
signedPlaceToPayNotification requestId status date secret privateValue = encodeStrict $ A.object
  [ "requestId" A..= requestId, "reference" A..= privateValue
  , "signature" A..= ("sha256:" <> digestText (T.pack (show requestId) <> status <> date <> secret))
  , "status" A..= A.object ["status" A..= status
      , "date" A..= date, "message" A..= privateValue]
  , "card" A..= privateValue ]

notificationPayload :: Checkout.PaymentProvider -> Text -> Text -> BS.ByteString
notificationPayload provider eventId privateValue = case provider of
  Checkout.ProviderPayPal -> paypalNotification eventId "125.15" privateValue
  Checkout.ProviderPlaceToPay -> placeToPayNotification privateValue
  _ -> encodeStrict $ A.object
    [ "TransactionId" A..= (1234 :: Int), "ClientTransactionId" A..= ("CLIENT-1" :: Text)
    , "StoreId" A..= ("synthetic-store" :: Text), "StatusCode" A..= (3 :: Int)
    , "customer" A..= privateValue ]

newNotification :: Checkout.PaymentProvider -> IO Event.ProviderEventCreation
newNotification provider = do
  eventId <- ("EVENT-" <>) . toText <$> nextRandom
  let rawPayload = notificationPayload provider eventId privateMarker
  pure Event.ProviderEventCreation
    { Event.pecProvider = provider, Event.pecEnvironment = Checkout.CheckoutSandbox
    , Event.pecMerchantRef = "synthetic-inbox-merchant-" <> eventId
    , Event.pecProviderEventId = if provider == Checkout.ProviderPlaceToPay
        then legacyPlaceToPayId rawPayload else eventId
    , Event.pecEventType = if provider == Checkout.ProviderPayPal
        then "PAYMENT.CAPTURE.COMPLETED" else "PAYMENT_NOTIFICATION"
    , Event.pecProviderCreatedAt = if provider == Checkout.ProviderPayPal then Just notificationTime else Nothing
    , Event.pecProviderResource = Just (if provider == Checkout.ProviderPayPal then "CAPTURE-1" else "1234")
    , Event.pecRawPayload = rawPayload
    , Event.pecEncryptionKey = recoveryEncryptionKey, Event.pecReceivedAt = notificationTime }

storeNotification :: ConnectionPool -> Event.ProviderEventCreation -> IO (Either Text Event.ProviderEventStored)
storeNotification pool creation = runSqlPool
  ((if Event.pecProvider creation == Checkout.ProviderPayPhone
      then Event.storeUntrustedProviderEvent else Event.storeVerifiedProviderEvent) creation) pool

readStoredNotification :: ConnectionPool -> Event.ProviderEventStored -> IO BS.ByteString
readStoredNotification pool stored = do
  rows <- runSqlPool (rawSql
    "SELECT pgp_sym_decrypt_bytea(payload_ciphertext, ?) FROM commerce_provider_event_inbox WHERE id=?::uuid"
    [PersistText recoveryEncryptionKey, PersistText (Event.providerEventReferenceId (Event.pesReference stored))]
    :: SqlPersistT IO [Single BS.ByteString]) pool
  case rows of
    [Single value] -> pure value
    _ -> expectationFailure "Expected one encrypted inbox row" >> pure BS.empty

insertHistoricalNotification :: ConnectionPool -> Event.ProviderEventCreation -> IO Event.ProviderEventReference
insertHistoricalNotification pool creation = do
  eventId <- toText <$> nextRandom
  let verified = Event.pecProvider creation /= Checkout.ProviderPayPhone
  runSqlPool (rawExecute
    "INSERT INTO commerce_provider_event_inbox (id,provider,environment,merchant_account_ref,\
    \provider_event_id,event_type,signature_verified,evidence_type,provider_created_at,provider_resource_id,\
    \payload_ciphertext,payload_sha256) VALUES (?::uuid,?,'sandbox',?,?,?,?,?,?,?,\
    \pgp_sym_encrypt_bytea(?::bytea,?,'cipher-algo=aes256,compress-algo=1'),?)"
    [ PersistText eventId, PersistText (Checkout.paymentProviderText (Event.pecProvider creation))
    , PersistText (Event.pecMerchantRef creation), PersistText (Event.pecProviderEventId creation)
    , PersistText (Event.pecEventType creation), PersistBool verified
    , PersistText (if verified then "signature_verified" else "untrusted_callback")
    , maybe PersistNull PersistUTCTime (Event.pecProviderCreatedAt creation)
    , maybe PersistNull PersistText (Event.pecProviderResource creation)
    , PersistByteString (Event.pecRawPayload creation), PersistText recoveryEncryptionKey
    , PersistText (digestText (TE.decodeUtf8 (Event.pecRawPayload creation))) ]) pool
  pure (Event.ProviderEventReference eventId)

recoveryEncryptionKey :: Text
recoveryEncryptionKey = "synthetic-provider-recovery-encryption-key"

-- Clear provider authentication before invoking handlers. Restore caller
-- configuration without printing it, even when an assertion fails.
withRecoveryEnvironment :: IO a -> IO a
withRecoveryEnvironment action = bracket
  (forM names $ \name -> (,) name <$> lookupEnv name)
  (mapM_ (\(name, value) -> maybe (unsetEnv name) (setEnv name) value)) $ \_ -> do
    setEnv "COMMERCE_EVENT_ENCRYPTION_KEY" (T.unpack recoveryEncryptionKey)
    setEnv "PLACETOPAY_LOGIN" ""
    setEnv "PAYPHONE_TOKEN" ""
    action
  where names = ["COMMERCE_EVENT_ENCRYPTION_KEY", "PLACETOPAY_LOGIN", "PAYPHONE_TOKEN"]

-- These tests parse synthetic official-contract-shaped query responses and
-- exercise the actual PostgreSQL financial path. They are not sandbox tests.
reconciliationReportValidationSpec :: Spec
reconciliationReportValidationSpec = describe "payment reconciliation report boundary" $ do
  it "defaults to sandbox, bounds pages and normalizes exact UUID filters" $ do
    Operations.validateReconciliationFilters Nothing Nothing Nothing Nothing Nothing
      `shouldBe` Right ("sandbox",Nothing,Nothing,25,0)
    Operations.validateReconciliationFilters (Just " production ") (Just "OPEN")
      (Just "AAAAAAAA-AAAA-4AAA-8AAA-AAAAAAAAAAAA") (Just 100) (Just 10000)
      `shouldBe` Right ("production",Just "open",Just "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",100,10000)

  it "rejects invalid filters before reading the database or echoing their contents" $ do
    forM_ [(Just "synthetic_private",Nothing,Nothing,Nothing,Nothing),
      (Nothing,Just "synthetic_private",Nothing,Nothing,Nothing),
      (Nothing,Nothing,Just "synthetic_private",Nothing,Nothing),
      (Nothing,Nothing,Nothing,Just 0,Nothing),(Nothing,Nothing,Nothing,Just 101,Nothing),
      (Nothing,Nothing,Nothing,Nothing,Just (-1)),(Nothing,Nothing,Nothing,Nothing,Just 10001)] $
      \(environment,status,checkout,limit,offset) -> do
        result <- reconciliationReport [Admin] (error "Invalid filter accessed database")
          environment status checkout limit offset
        either errHTTPCode (const 200) result `shouldBe` 400
        show result `shouldNotContain` "synthetic_private"

  it "enforces strict-admin authorization before filters or database access" $ do
    forM_ [[Customer],[Fan],[Webmaster],[StudioManager],[Admin,Webmaster],[Admin,Manager]] $ \roles -> do
      result <- reconciliationReport roles (error "Unauthorized report accessed database")
        (Just "invalid") Nothing Nothing Nothing Nothing
      either errHTTPCode (const 200) result `shouldBe` 403

reconciliationReportSpec :: SpecWith ConnectionPool
reconciliationReportSpec = describe "read-only reconciliation evidence" $ do
  it "distinguishes an empty installed report from missing schema" $ \pool -> do
    emptyReport <- reconciliationReport [Admin] pool Nothing Nothing Nothing Nothing Nothing >>= requireRight
    crrSchemaReady emptyReport `shouldBe` True
    crrEnvironment emptyReport `shouldBe` "sandbox"
    crrEntries emptyReport `shouldBe` []
    let rename fromName toName = runSqlPool (rawExecute
          ("ALTER TABLE " <> fromName <> " RENAME TO " <> toName) []) pool
    bracket (rename "commerce_provider_binding" "synthetic_hidden_review_binding")
      (const (rename "synthetic_hidden_review_binding" "commerce_provider_binding")) $ \_ -> do
        report <- reconciliationReport [Admin] pool Nothing Nothing Nothing Nothing Nothing >>= requireRight
        crrSchemaReady report `shouldBe` False
        crrEntries report `shouldBe` []

  it "redacts database failures and never reports them as empty success" $ \pool -> do
    let rename fromName toName = runSqlPool (rawExecute
          ("ALTER TABLE commerce_reconciliation_exception RENAME COLUMN " <> fromName <> " TO " <> toName) []) pool
    bracket (rename "actual_amount_minor" "synthetic_private_column")
      (const (rename "synthetic_private_column" "actual_amount_minor")) $ \_ -> do
        result <- reconciliationReport [Admin] pool Nothing Nothing Nothing Nothing Nothing
        either errHTTPCode (const 200) result `shouldBe` 503
        show result `shouldNotContain` "synthetic_private_column"
        show result `shouldNotContain` "SELECT"
        either (\problem -> errHeaders problem `shouldContain` [("Cache-Control","no-store")])
          (const (expectationFailure "Expected unavailable response")) result

  forM_ [Checkout.ProviderPlaceToPay, Checkout.ProviderPayPhone] $ \provider ->
    it ("links exact held evidence without changing " <> T.unpack (Checkout.paymentProviderText provider)) $ \pool -> do
      payment <- closedPaymentFixture pool provider "expired"
      approved <- parsedQuery payment Adapter.AdapterSucceeded
      runSqlPool (Reconciliation.applyQueryResult payment approved "review-report-fixture" notificationTime)
        pool `shouldReturn` Right Reconciliation.ReconciliationDeadLetter
      snapshot <- runSqlPool (paymentSnapshot payment) pool
      review <- runSqlPool (closedPaymentReviewSnapshot payment) pool
      let checkoutId = Checkout.checkoutReferenceId (Execution.bppCheckout payment)
          readReport = reconciliationReport [Admin,Fan,Customer] pool Nothing (Just "open")
            (Just checkoutId) Nothing Nothing >>= requireRight
      reports <- concurrently (replicate 4 readReport)
      forM_ reports $ \report -> do
        crrCheckoutId report `shouldBe` Just checkoutId
        crrStatus report `shouldBe` Just "open"
        case crrEntries report of
          [entry] -> do
            creProvider entry `shouldBe` Checkout.paymentProviderText provider
            creReason entry `shouldBe` "closed_checkout_approval"
            creCheckoutId entry `shouldBe` Just checkoutId
            crePaymentAttemptId entry `shouldBe`
              Just (Checkout.paymentAttemptReferenceId (Execution.bppAttempt payment))
            creExpectedMinor entry `shouldBe` Just "12515"
            creActualMinor entry `shouldBe` Just "12515"
          _ -> expectationFailure "Expected one exact linked review"
        let encoded = BL.toStrict (A.encode report)
        forM_ [TE.encodeUtf8 (Execution.bppMerchantRef payment),
          TE.encodeUtf8 (Execution.bppProviderResourceId payment),"merchant_account_ref",
          "provider_reference","resolution_notes","redirect","lease_token"] $ \private ->
            encoded `shouldNotSatisfy` BS.isInfixOf private
      runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot
      runSqlPool (closedPaymentReviewSnapshot payment) pool `shouldReturn` review

  it "preserves Int64 extrema as strings and redacts arbitrary legacy values" $ \pool -> do
    ident <- toText <$> nextRandom
    runSqlPool (rawExecute
      "INSERT INTO commerce_reconciliation_exception(id,provider,environment,merchant_account_ref,\
      \ exception_type,internal_reference,provider_reference,expected_amount_minor,actual_amount_minor,\
      \ currency,status,resolution_notes) VALUES (?::uuid,'synthetic_private_provider','sandbox',\
      \ 'synthetic_private_merchant','synthetic_private_type','synthetic_private_reference',\
      \ 'synthetic_private_resource',-9223372036854775808,9223372036854775807,\
      \ 'synthetic_private_currency','open','synthetic_private_notes')" [PersistText ident]) pool
    report <- reconciliationReport [Admin] pool Nothing Nothing Nothing Nothing Nothing >>= requireRight
    case filter ((== ident) . creId) (crrEntries report) of
      [entry] -> do
        creProvider entry `shouldBe` "unrecognized"
        creReason entry `shouldBe` "unrecognized"
        creCheckoutId entry `shouldBe` Nothing
        crePaymentAttemptId entry `shouldBe` Nothing
        creCurrency entry `shouldBe` Nothing
        creExpectedMinor entry `shouldBe` Just "-9223372036854775808"
        creActualMinor entry `shouldBe` Just "9223372036854775807"
      _ -> expectationFailure "Expected the redacted legacy review"
    let encoded = BL.toStrict (A.encode report)
    encoded `shouldNotSatisfy` BS.isInfixOf "synthetic_private"
    encoded `shouldSatisfy` BS.isInfixOf "\"9223372036854775807\""

  it "does not infer a binding from a checkout UUID with the wrong merchant account" $ \pool -> do
    payment <- closedPaymentFixture pool Checkout.ProviderPayPhone "cancelled"
    approved <- parsedQuery payment Adapter.AdapterSucceeded
    runSqlPool (Reconciliation.applyQueryResult payment approved "wrong-merchant-report" notificationTime)
      pool `shouldReturn` Right Reconciliation.ReconciliationDeadLetter
    let checkoutId = Checkout.checkoutReferenceId (Execution.bppCheckout payment)
    runSqlPool (rawExecute "UPDATE commerce_reconciliation_exception\
      \ SET merchant_account_ref='synthetic_private_wrong_account' WHERE internal_reference=?"
      [PersistText checkoutId]) pool
    report <- reconciliationReport [Admin] pool Nothing Nothing (Just checkoutId) Nothing Nothing >>= requireRight
    map creCheckoutId (crrEntries report) `shouldBe` [Nothing]
    map crePaymentAttemptId (crrEntries report) `shouldBe` [Nothing]

  it "separates environment and workflow filters with bounded deterministic pages" $ \pool -> do
    checkoutId <- toText <$> nextRandom
    forM_ [("sandbox","open"),("sandbox","open"),("sandbox","assigned"),("production","open")] $
      \(environment,status) -> runSqlPool (rawExecute
        "INSERT INTO commerce_reconciliation_exception(provider,environment,merchant_account_ref,\
        \ exception_type,internal_reference,provider_reference,expected_amount_minor,actual_amount_minor,currency,status)\
        \ VALUES ('paypal',?,'synthetic-account','provider_status_unknown',?,gen_random_uuid()::text,0,NULL,'USD',?)"
        [PersistText environment,PersistText checkoutId,PersistText status]) pool
    let page environment status offset = reconciliationReport [Admin] pool (Just environment)
          (Just status) (Just checkoutId) (Just 1) (Just offset) >>= requireRight
    first <- page "sandbox" "open" 0
    second <- page "sandbox" "open" 1
    crrHasMore first `shouldBe` True
    crrHasMore second `shouldBe` False
    map creId (crrEntries first) `shouldNotBe` map creId (crrEntries second)
    map creExpectedMinor (crrEntries first) `shouldBe` [Just "0"]
    map creActualMinor (crrEntries first) `shouldBe` [Nothing]
    assigned <- page "sandbox" "assigned" 0
    map creStatus (crrEntries assigned) `shouldBe` ["assigned"]
    production <- page "production" "open" 0
    crrEnvironment production `shouldBe` "production"
    length (crrEntries production) `shouldBe` 1
    crrHasMore production `shouldBe` False

  it "bounds a locked reporting read without changing the exception" $ \pool -> do
    locked <- newEmptyMVar
    release <- newEmptyMVar
    finished <- newEmptyMVar
    let hold = runSqlPool (do
          rawExecute "LOCK TABLE commerce_reconciliation_exception IN ACCESS EXCLUSIVE MODE" []
          liftIO (putMVar locked ())
          liftIO (takeMVar release)) pool
        cleanupLock _ = putMVar release () >> takeMVar finished >>= either throwIO pure
    bracket (forkFinally hold (putMVar finished)) cleanupLock $ \_ -> do
      Timeout.timeout 5000000 (takeMVar locked) `shouldReturn` Just ()
      result <- Timeout.timeout 8000000 (reconciliationReport [Admin] pool
        Nothing Nothing Nothing Nothing Nothing)
      fmap (either errHTTPCode (const 200)) result `shouldBe` Just 503

reconciliationReport
  :: [RoleEnum] -> ConnectionPool -> Maybe Text -> Maybe Text -> Maybe Text -> Maybe Int -> Maybe Int
  -> IO (Either ServerError CommerceReconciliationReportDTO)
reconciliationReport roles pool environment status checkout limit offset = do
  let user = AuthedUser (toSqlKey 1) roles mempty Nothing Nothing
      _ :<|> _ :<|> _ :<|> _ :<|> listReviews = Operations.commerceOperationsServer user
  result <- runHandler (runReaderT (listReviews environment status checkout limit offset) (queryEnv pool))
  case result of
    Left problem -> pure (Left problem)
    Right headers -> do
      getHeaders headers `shouldContain` [("Cache-Control","no-store")]
      pure (Right (getResponse headers))

providerQueryReportValidationSpec :: Spec
providerQueryReportValidationSpec = describe "provider query report boundary" $ do
  it "defaults to sandbox and validates bounded filters without echoing invalid input" $ do
    Operations.validateProviderQueryFilters Nothing Nothing Nothing Nothing
      `shouldBe` Right ("sandbox",Nothing,25,0)
    Operations.validateProviderQueryFilters (Just " production ") (Just "RETRY") (Just 100) (Just 10000)
      `shouldBe` Right ("production",Just "retry",100,10000)
    forM_ [(Just "synthetic_private",Nothing,Nothing,Nothing),
      (Nothing,Just "synthetic_private",Nothing,Nothing),
      (Nothing,Nothing,Just 0,Nothing),(Nothing,Nothing,Just 101,Nothing),
      (Nothing,Nothing,Nothing,Just (-1)),(Nothing,Nothing,Nothing,Just 10001)] $
      \(environment,status,limit,offset) -> do
        let result = Operations.validateProviderQueryFilters environment status limit offset
        result `shouldSatisfy` isLeft
        show result `shouldNotContain` "synthetic_private"

  it "projects only recognized server outcomes and never passes arbitrary diagnostics through" $ do
    Operations.providerQueryOutcome "query_binding_mismatch" `shouldBe` "query_binding_mismatch"
    Operations.providerQueryOutcome "immutable_binding_unavailable" `shouldBe` "immutable_binding_unavailable"
    Operations.providerQueryOutcome "synthetic_private_token" `shouldBe` "unrecognized"

  it "rejects invalid admin pagination before acquiring a database connection" $ do
    result <- queryReport [Admin] (error "Invalid pagination accessed the database")
      Nothing Nothing (Just 101) Nothing
    either errHTTPCode (const 200) result `shouldBe` 400

  it "denies non-strict admins before parsing filters or touching the database" $ do
    forM_ [[Customer],[Fan],[Webmaster],[StudioManager],[Admin,Webmaster],[Admin,Manager]] $ \roles -> do
      result <- queryReport roles (error "Unauthorized report accessed the database")
        (Just "invalid") Nothing Nothing Nothing
      either errHTTPCode (const 200) result `shouldBe` 403

providerQueryReportSpec :: SpecWith ConnectionPool
providerQueryReportSpec = describe "read-only provider query operations" $ do
  it "distinguishes installed empty queues from missing recovery schema" $ \pool -> do
    emptyReport <- queryReport [Admin] pool Nothing Nothing Nothing Nothing >>= requireRight
    cpqsSchemaReady emptyReport `shouldBe` True
    cpqsRecoveryFlagEnabled emptyReport `shouldBe` False
    cpqsEnvironment emptyReport `shouldBe` "sandbox"
    cpqsJobs emptyReport `shouldBe` []
    let rename fromName toName = runSqlPool (rawExecute
          ("ALTER TABLE " <> fromName <> " RENAME TO " <> toName) []) pool
    bracket (rename "commerce_provider_query_job" "synthetic_hidden_query_job")
      (const (rename "synthetic_hidden_query_job" "commerce_provider_query_job")) $ \_ -> do
        report <- queryReport [Admin] pool Nothing Nothing Nothing Nothing >>= requireRight
        cpqsSchemaReady report `shouldBe` False
        cpqsJobs report `shouldBe` []

  it "redacts SQL failures instead of returning a misleading empty report" $ \pool -> do
    let rename fromName toName = runSqlPool (rawExecute
          ("ALTER TABLE commerce_provider_query_budget RENAME COLUMN " <> fromName <> " TO " <> toName) []) pool
    bracket (rename "next_query_at" "synthetic_private_column")
      (const (rename "synthetic_private_column" "next_query_at")) $ \_ -> do
        report <- queryReport [Admin] pool Nothing Nothing Nothing Nothing
        either errHTTPCode (const 200) report `shouldBe` 503
        show report `shouldNotContain` "synthetic_private_column"
        show report `shouldNotContain` "SELECT"

  it "separates environments, bounds pages, and preserves jobs, budgets and financial history" $ \pool ->
    withQueryRecovery pool Checkout.ProviderPayPhone $ \merchant -> do
      payments <- forM [1..3 :: Int] $ \_ -> do
        payment <- reconciliationFixtureWithMerchant merchant pool Checkout.ProviderPayPhone
        prepareQueryJob pool payment
        pure payment
      beforeSnapshot <- mapM (\payment -> runSqlPool (paymentSnapshot payment) pool) payments
      first <- queryReport [Admin] pool Nothing (Just "pending") (Just 1) Nothing >>= requireRight
      second <- queryReport [Admin] pool Nothing (Just "pending") (Just 1) (Just 1) >>= requireRight
      cpqsHasMore first `shouldBe` True
      length (cpqsJobs first) `shouldBe` 1
      map cpqOperationId (cpqsJobs first) `shouldNotBe` map cpqOperationId (cpqsJobs second)
      cpqsOffset second `shouldBe` 1
      production <- queryReport [Admin] pool (Just "production") Nothing Nothing Nothing >>= requireRight
      cpqsEnvironment production `shouldBe` "production"
      cpqsJobs production `shouldBe` []
      cpqsBudgets production `shouldBe` []
      cpqsRecoveryFlagEnabled production `shouldBe` False
      cpqsRecoveryFlagEnabled first `shouldBe` True
      forM_ payments $ \payment -> queryJobState pool payment `shouldReturn` ("pending",0)
      mapM (\payment -> runSqlPool (paymentSnapshot payment) pool) payments `shouldReturn` beforeSnapshot
      -- Reading a pending queue must not reserve any remote-query budget.
      runSqlPool (rawSql "SELECT count(*) FROM commerce_provider_query_budget" []) pool
        `shouldReturn` [Single (0 :: Int64)]

  it "bounds a blocked reporting read and returns a redacted unavailable response" $ \pool -> do
    locked <- newEmptyMVar
    release <- newEmptyMVar
    finished <- newEmptyMVar
    let hold = runSqlPool (do
          rawExecute "LOCK TABLE commerce_provider_query_job IN ACCESS EXCLUSIVE MODE" []
          liftIO (putMVar locked ())
          liftIO (takeMVar release)) pool
        cleanupLock _ = do
          putMVar release ()
          takeMVar finished >>= either throwIO pure
    bracket (forkFinally hold (putMVar finished)) cleanupLock $ \_ -> do
      Timeout.timeout 5000000 (takeMVar locked) `shouldReturn` Just ()
      result <- Timeout.timeout 8000000 (queryReport [Admin] pool Nothing Nothing Nothing Nothing)
      fmap (either errHTTPCode (const 200)) result `shouldBe` Just 503

  it "redacts stored diagnostics and never exposes merchant, lease or provider references" $ \pool ->
    withQueryRecovery pool Checkout.ProviderPlaceToPay $ \merchant -> do
      payment <- reconciliationFixtureWithMerchant merchant pool Checkout.ProviderPlaceToPay
      prepareQueryJob pool payment
      runSqlPool (rawExecute
        "UPDATE commerce_provider_query_job SET last_error_code='synthetic_private_token'\
        \ WHERE operation_id IN (SELECT id FROM commerce_provider_operation WHERE payment_attempt_id=?::uuid)"
        [paymentAttemptParameter payment]) pool
      report <- queryReport [Admin,Fan,Customer] pool Nothing Nothing Nothing Nothing >>= requireRight
      let jobs = filter ((== Checkout.paymentAttemptReferenceId (Execution.bppAttempt payment))
            . cpqPaymentAttemptId) (cpqsJobs report)
          encoded = BL.toStrict (A.encode report)
      map cpqLastOutcome jobs `shouldBe` [Just "unrecognized"]
      forM_ ["synthetic_private_token",TE.encodeUtf8 merchant,"lease_token",
        "merchant_account_ref","provider_reference","provider_resource_id","redirect"] $ \forbidden ->
        encoded `shouldNotSatisfy` BS.isInfixOf forbidden

  it "shows completed checks independently from confirmed no-charge payment outcomes" $ \pool ->
    withQueryRecovery pool Checkout.ProviderPayPhone $ \merchant -> do
      payment <- reconciliationFixtureWithMerchant merchant pool Checkout.ProviderPayPhone
      prepareQueryJob pool payment
      runQueryTick pool (\_ -> pure (Right (queryValue payment Adapter.AdapterCancelled))) `shouldReturn` 1
      report <- queryReport [Admin] pool Nothing (Just "completed") Nothing Nothing >>= requireRight
      let jobs = filter ((== Checkout.paymentAttemptReferenceId (Execution.bppAttempt payment))
            . cpqPaymentAttemptId) (cpqsJobs report)
      map cpqStatus jobs `shouldBe` ["completed"]
      map cpqOperationStatus jobs `shouldBe` ["confirmed_no_charge"]
      map cpqOutcomeCertainty jobs `shouldBe` ["confirmed_no_charge"]
      noChargeStates pool payment `shouldReturn` ("cancelled","cancelled","provider_cancelled")

queryReport
  :: [RoleEnum] -> ConnectionPool -> Maybe Text -> Maybe Text -> Maybe Int -> Maybe Int
  -> IO (Either ServerError CommerceProviderQueriesDTO)
queryReport roles pool environment status limit offset = do
  let user = AuthedUser (toSqlKey 1) roles mempty Nothing Nothing
      _ :<|> _ :<|> _ :<|> listQueries :<|> _ = Operations.commerceOperationsServer user
  result <- runHandler (runReaderT (listQueries environment status limit offset) (queryEnv pool))
  case result of
    Left problem -> pure (Left problem)
    Right headers -> do
      getHeaders headers `shouldContain` [("Cache-Control", "no-store")]
      pure (Right (getResponse headers))

noChargeReplaySpec :: SpecWith ConnectionPool
noChargeReplaySpec = describe "history-preserving no-charge reconciliation" $
  forM_ [Checkout.ProviderPlaceToPay, Checkout.ProviderPayPhone] $ \provider ->
    describe (T.unpack (Checkout.paymentProviderText provider)) $ do
      it "records a new cancellation once and replays it concurrently without financial rewrites" $ \pool -> do
        payment <- reconciliationFixture pool provider
        cancelled <- parsedQuery payment Adapter.AdapterCancelled
        cancelledResult pool payment cancelled
        noChargeStates pool payment `shouldReturn` ("cancelled","cancelled","provider_cancelled")
        snapshot <- runSqlPool (paymentSnapshot payment) pool
        results <- concurrently (replicate 4 (runSqlPool
          (Reconciliation.applyQueryResult payment cancelled "duplicate-cancel" notificationTime) pool))
        results `shouldBe` replicate 4 (Right Reconciliation.ReconciliationProcessed)
        runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot

      it "preserves failed legacy intent, attempt, error code and audit after reclassified cancellation" $ \pool -> do
        payment <- reconciliationFixture pool provider
        legacy <- historicalDecline payment
        cancelledResult pool payment legacy
        noChargeStates pool payment `shouldReturn` ("failed","failed","provider_declined")
        snapshot <- runSqlPool (paymentSnapshot payment) pool
        cancelled <- parsedQuery payment Adapter.AdapterCancelled
        results <- concurrently (replicate 4 (runSqlPool
          (Reconciliation.applyQueryResult payment cancelled "legacy-cancel-replay" notificationTime) pool))
        results `shouldBe` replicate 4 (Right Reconciliation.ReconciliationProcessed)
        noChargeStates pool payment `shouldReturn` ("failed","failed","provider_declined")
        runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot

      it "does not downgrade a new cancellation when an older declined classification arrives" $ \pool -> do
        payment <- reconciliationFixture pool provider
        parsedQuery payment Adapter.AdapterCancelled >>= cancelledResult pool payment
        snapshot <- runSqlPool (paymentSnapshot payment) pool
        historicalDecline payment >>= cancelledResult pool payment
        runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot

      forM_ [False, True] $ \paid ->
        it ("preserves a replacement attempt after old no-charge replay, paid=" <> show paid) $ \pool -> do
          payment <- reconciliationFixture pool provider
          historicalDecline payment >>= cancelledResult pool payment
          let replacementProvider = if provider == Checkout.ProviderPayPhone
                then Checkout.ProviderPlaceToPay else Checkout.ProviderPayPhone
          replacement <- replacementPayment pool payment replacementProvider
          now <- getCurrentTime
          if paid then do
            succeeded <- parsedQuery replacement Adapter.AdapterSucceeded
            runSqlPool (Reconciliation.applyQueryResult replacement succeeded "replacement-success" now) pool
              `shouldReturn` Right Reconciliation.ReconciliationProcessed
            assertPaymentPosted pool replacement
          else runSqlPool (Checkout.recordPaymentProcessing (Execution.bppCheckout replacement)
            (Execution.bppAttempt replacement) replacementProvider "replacement-processing" now) pool
          originalSnapshot <- runSqlPool (paymentSnapshot payment) pool
          replacementSnapshot <- runSqlPool (paymentSnapshot replacement) pool
          parsedQuery payment Adapter.AdapterCancelled >>= cancelledResult pool payment
          runSqlPool (paymentSnapshot payment) pool `shouldReturn` originalSnapshot
          runSqlPool (paymentSnapshot replacement) pool `shouldReturn` replacementSnapshot

      it "keeps historical no-charge labels unchanged through the actual callback query pipeline" $ \pool ->
        withNotificationEnvironment $ do
          payment <- reconciliationFixture pool provider
          historicalDecline payment >>= cancelledResult pool payment
          payload <- reconciliationNotification pool payment
          snapshot <- runSqlPool (paymentSnapshot payment) pool
          outcome <- Reconciliation.processProviderEventWith
            (\_ -> pure (Right (queryValue payment Adapter.AdapterCancelled))) getCurrentTime
            (queryEnv pool) payload notificationTime
          Reconciliation.prrDisposition outcome `shouldBe` Reconciliation.ReconciliationProcessed
          runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot

      it "applies cancellation through the fenced missed-callback worker without a capture" $ \pool ->
        withQueryRecovery pool provider $ \merchant -> do
          payment <- reconciliationFixtureWithMerchant merchant pool provider
          prepareQueryJob pool payment
          runQueryTick pool (\_ -> pure (Right (queryValue payment Adapter.AdapterCancelled)))
            `shouldReturn` 1
          queryJobState pool payment `shouldReturn` ("completed",1)
          noChargeStates pool payment `shouldReturn` ("cancelled","cancelled","provider_cancelled")

      it "rejects inconsistent terminal intent/attempt history without repairing it silently" $ \pool -> do
        payment <- reconciliationFixture pool provider
        historicalDecline payment >>= cancelledResult pool payment
        runSqlPool (rawExecute "UPDATE commerce_payment_attempt SET status='processing' WHERE id=?::uuid"
          [paymentAttemptParameter payment]) pool
        snapshot <- runSqlPool (paymentSnapshot payment) pool
        cancelled <- parsedQuery payment Adapter.AdapterCancelled
        runSqlPool (Reconciliation.applyQueryResult payment cancelled "inconsistent-no-charge" notificationTime)
          pool >>= (`shouldSatisfy` isLeft)
        runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot

      it "refuses no-charge replay with authorized, captured or refunded money" $ \pool ->
        forM_ [(1,0,0),(1,1,0),(1,1,1)] $ \(authorized,captured,refunded) -> do
          payment <- reconciliationFixture pool provider
          historicalDecline payment >>= cancelledResult pool payment
          runSqlPool (rawExecute
            "UPDATE commerce_payment_intent SET authorized_minor=?,captured_minor=?,refunded_minor=?\
            \ WHERE id=?::uuid" [PersistInt64 authorized,PersistInt64 captured,PersistInt64 refunded,
              PersistText (Execution.bppPaymentIntentId payment)]) pool
          snapshot <- runSqlPool (paymentSnapshot payment) pool
          cancelled <- parsedQuery payment Adapter.AdapterCancelled
          runSqlPool (Reconciliation.applyQueryResult payment cancelled "money-conflict" notificationTime)
            pool >>= (`shouldSatisfy` isLeft)
          runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot

      it "refuses posted capture evidence even if a corrupt repair cleared intent counters" $ \pool -> do
        payment <- reconciliationFixture pool provider
        succeeded <- parsedQuery payment Adapter.AdapterSucceeded
        runSqlPool (Reconciliation.applyQueryResult payment succeeded "ledger-guard-capture" notificationTime)
          pool `shouldReturn` Right Reconciliation.ReconciliationProcessed
        -- Deliberately incoherent local fixture: no guard or ledger row is
        -- disabled/deleted. Verify the store's defense in depth directly;
        -- the public reconciler also rejects the successful operation conflict.
        runSqlPool (do
          rawExecute "UPDATE commerce_payment_attempt SET status='failed' WHERE id=?::uuid"
            [paymentAttemptParameter payment]
          rawExecute "UPDATE commerce_payment_intent SET status='failed',authorized_minor=0,\
            \ captured_minor=0,refunded_minor=0 WHERE id=?::uuid"
            [PersistText (Execution.bppPaymentIntentId payment)]) pool
        snapshot <- runSqlPool (paymentSnapshot payment) pool
        runSqlPool (Execution.validateNoChargeObservation payment) pool >>= (`shouldSatisfy` isLeft)
        runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot

-- Reconstruct the old typed result only for historical compatibility fixtures.
-- This is not presented as a result from the current PayPhone query parser.
historicalDecline :: Execution.BoundProviderPayment -> IO Adapter.AdapterResult
historicalDecline payment = do
  result <- parsedQuery payment Adapter.AdapterCancelled
  pure result { Adapter.adapterResultState = Adapter.AdapterDeclined }

cancelledResult :: ConnectionPool -> Execution.BoundProviderPayment -> Adapter.AdapterResult -> Expectation
cancelledResult pool payment result = runSqlPool
  (Reconciliation.applyQueryResult payment result "no-charge-test" notificationTime) pool
  `shouldReturn` Right Reconciliation.ReconciliationProcessed

noChargeStates :: ConnectionPool -> Execution.BoundProviderPayment -> IO (Text,Text,Text)
noChargeStates pool payment = do
  rows <- runSqlPool (rawSql
    "SELECT intent.status,attempt.status,attempt.failure_code FROM commerce_payment_attempt attempt\
    \ JOIN commerce_payment_intent intent ON intent.id=attempt.payment_intent_id\
    \ WHERE attempt.id=?::uuid AND intent.authorized_minor=0 AND intent.captured_minor=0\
    \ AND intent.refunded_minor=0 AND NOT EXISTS (SELECT 1 FROM commerce_ledger_transaction txn\
    \ WHERE txn.source_id=attempt.id::text)" [paymentAttemptParameter payment]) pool
    :: IO [(Single Text,Single Text,Single Text)]
  case rows of
    [(Single intentStatus,Single attemptStatus,Single code)] -> pure (intentStatus,attemptStatus,code)
    _ -> fail "Expected one no-charge payment without financial entries"

replacementPayment
  :: ConnectionPool -> Execution.BoundProviderPayment -> Checkout.PaymentProvider
  -> IO Execution.BoundProviderPayment
replacementPayment pool original provider = do
  now <- getCurrentTime
  key <- toText <$> nextRandom
  let creation = Checkout.PaymentAttemptCreation
        { Checkout.pacCheckout = Execution.bppCheckout original
        , Checkout.pacProvider = provider, Checkout.pacEnvironment = Checkout.CheckoutSandbox
        , Checkout.pacOperation = Checkout.OperationCreate, Checkout.pacAmountMinor = 12515
        , Checkout.pacCurrency = "USD", Checkout.pacMerchantRef = Execution.bppMerchantRef original
        , Checkout.pacIdempotencyKey = key, Checkout.pacCreatedAt = now
        , Checkout.pacCorrelationId = "synthetic-replacement"
        }
      method = if provider == Checkout.ProviderPayPhone then MethodPayPhoneWallet else MethodCard
  attempt <- runSqlPool (Runtime.beginPaymentAttemptForMethod method creation) pool >>= requireRight
  let reference = providerReference provider (Checkout.paymentAttemptReferenceId attempt)
  operation <- runSqlPool (Execution.prepareProviderOperation Execution.ProviderOperationPreparation
    { Execution.popAttempt = attempt, Execution.popProvider = provider
    , Execution.popEnvironment = Checkout.CheckoutSandbox
    , Execution.popMerchantRef = Checkout.pacMerchantRef creation
    , Execution.popProviderReference = reference, Execution.popOperation = AdapterCreate
    , Execution.popIdempotencyKey = key, Execution.popRequestSha256 = digestText key
    , Execution.popOccurredAt = now }) pool >>= requireRight
  bindReconciliationFixture pool creation operation reference

queryRecoverySpec :: SpecWith ConnectionPool
queryRecoverySpec = describe "durable missed-callback recovery" $ do
  it "installs both recovery flags disabled and enforces a shared concurrent query budget" $ \pool -> do
    flags <- runSqlPool (rawSql
      "SELECT enabled FROM revenue_feature_flag WHERE flag_key='checkout.provider_query_recovery' ORDER BY environment" [])
      pool :: IO [Single Bool]
    flags `shouldBe` [Single False, Single False]
    resetQueryBudget pool Checkout.ProviderPayPhone
    grants <- concurrently (replicate 8 (runSqlPool
      (Execution.reserveProviderQueryBudget Checkout.ProviderPayPhone Checkout.CheckoutSandbox) pool))
    length (filter id grants) `shouldBe` 1
    runSqlPool (Execution.reserveProviderQueryBudget Checkout.ProviderPlaceToPay Checkout.CheckoutProduction)
      pool `shouldReturn` True

  forM_ [Checkout.ProviderPlaceToPay, Checkout.ProviderPayPhone] $ \provider ->
    describe (T.unpack (Checkout.paymentProviderText provider)) $ do
      it "recovers a missed callback with one query and no fabricated inbox evidence" $ \pool ->
        withQueryRecovery pool provider $ \merchant -> do
          payment <- reconciliationFixtureWithMerchant merchant pool provider
          prepareQueryJob pool payment
          runQueryTick pool (successfulQuery payment) `shouldReturn` 1
          assertPaymentPosted pool payment
          queryJobState pool payment `shouldReturn` ("completed",1)
          rows <- runSqlPool (rawSql
            "SELECT count(*) FROM commerce_provider_event_inbox WHERE merchant_account_ref=?"
            [PersistText merchant]) pool :: IO [Single Int64]
          rows `shouldBe` [Single 0]

      it "honors the process switch, exact sandbox flag and runtime configuration" $ \pool ->
        withQueryRecovery pool provider $ \merchant -> do
          payment <- reconciliationFixtureWithMerchant merchant pool provider
          prepareQueryJob pool payment
          setEnv "COMMERCE_PROVIDER_QUERY_RECOVERY_ENABLED" "false"
          runQueryTick pool noQuery `shouldReturn` 0
          setEnv "COMMERCE_PROVIDER_QUERY_RECOVERY_ENABLED" "true"
          setRecoveryFlag pool False
          runQueryTick pool noQuery `shouldReturn` 0
          setRecoveryFlag pool True
          setEnv (if provider == Checkout.ProviderPlaceToPay then "PLACETOPAY_LOGIN" else "PAYPHONE_TOKEN") ""
          runQueryTick pool noQuery `shouldReturn` 0
          queryJobState pool payment `shouldReturn` ("pending",0)
          assertQueryUnpaid pool payment

      it "ignores known resources without qualified account authority" $ \pool ->
        withQueryRecovery pool provider $ \merchant -> do
          payment <- reconciliationFixtureWithMerchant merchant pool provider
          prepareQueryJob pool payment
          runSqlPool (rawExecute
            "UPDATE commerce_provider_account SET enabled=false WHERE provider=? AND environment='sandbox'"
            [PersistText (Checkout.paymentProviderText provider)]) pool
          runQueryTick pool noQuery `shouldReturn` 0
          queryJobState pool payment `shouldReturn` ("pending",0)

      it "does not enqueue or recreate an ambiguous operation without a bound resource" $ \pool ->
        withQueryRecovery pool provider $ \merchant -> do
          _ <- replayFixtureWithMerchant "service_booking" merchant pool provider
          runQueryTick pool noQuery `shouldReturn` 0
          rows <- runSqlPool (rawSql
            "SELECT count(*) FROM commerce_provider_query_job job\
            \ JOIN commerce_provider_operation operation ON operation.id=job.operation_id\
            \ WHERE operation.merchant_account_ref=?" [PersistText merchant]) pool :: IO [Single Int64]
          rows `shouldBe` [Single 0]

      it "serializes replica claims and posts only one payment" $ \pool ->
        withQueryRecovery pool provider $ \merchant -> do
          payment <- reconciliationFixtureWithMerchant merchant pool provider
          prepareQueryJob pool payment
          calls <- newIORef (0 :: Int)
          claimed <- concurrently (replicate 4 (runQueryTick pool
            (\request -> atomicModifyIORef' calls (\n -> (n+1,())) >> successfulQuery payment request)))
          sum claimed `shouldBe` 1
          readIORef calls `shouldReturn` 1
          queryJobState pool payment `shouldReturn` ("completed",1)
          assertPaymentPosted pool payment

      it "shares the callback query budget without burning job attempts" $ \pool ->
        withQueryRecovery pool provider $ \merchant -> do
          payment <- reconciliationFixtureWithMerchant merchant pool provider
          prepareQueryJob pool payment
          payload <- reconciliationNotification pool payment
          outcome <- Reconciliation.processProviderEventWith
            (\_ -> pure (Right (queryValue payment Adapter.AdapterPending))) getCurrentTime
            (queryEnv pool) payload notificationTime
          Reconciliation.prrDisposition outcome `shouldBe` Reconciliation.ReconciliationRetry
          runQueryTick pool noQuery `shouldReturn` 0
          queryJobState pool payment `shouldReturn` ("pending",0)

      it "retries transport failures with backoff and never infers no charge" $ \pool ->
        withQueryRecovery pool provider $ \merchant -> do
          payment <- reconciliationFixtureWithMerchant merchant pool provider
          prepareQueryJob pool payment
          runQueryTick pool (\_ -> pure (Left (ProviderHttp.AdapterTransportError "SYNTHETIC-PRIVATE")))
            `shouldReturn` 1
          queryJobState pool payment `shouldReturn` ("retry",1)
          assertQueryUnpaid pool payment
          rows <- runSqlPool (rawSql
            "SELECT job.next_attempt_at>clock_timestamp(),job.last_error_code FROM commerce_provider_query_job job\
            \ JOIN commerce_provider_operation operation ON operation.id=job.operation_id\
            \ WHERE operation.payment_attempt_id=?::uuid" [paymentAttemptParameter payment]) pool
            :: IO [(Single Bool,Single Text)]
          rows `shouldBe` [(Single True,Single "query_unavailable")]

      it "discards an expired response and recovers the original attempt on a fresh lease" $ \pool ->
        withQueryRecovery pool provider $ \merchant -> do
          payment <- reconciliationFixtureWithMerchant merchant pool provider
          prepareQueryJob pool payment
          runQueryTick pool (\request -> expireQueryLease pool payment >> successfulQuery payment request)
            `shouldReturn` 1
          assertQueryUnpaid pool payment
          queryJobState pool payment `shouldReturn` ("processing",1)
          resetQueryBudget pool provider
          runQueryTick pool (successfulQuery payment) `shouldReturn` 1
          queryJobState pool payment `shouldReturn` ("completed",2)
          assertPaymentPosted pool payment

      it "cannot apply a response after another worker replaces its lease token" $ \pool ->
        withQueryRecovery pool provider $ \merchant -> do
          payment <- reconciliationFixtureWithMerchant merchant pool provider
          prepareQueryJob pool payment
          replacement <- newIORef Nothing
          runQueryTick pool (\request -> do
            expireQueryLease pool payment
            resetQueryBudget pool provider
            claimed <- runSqlPool (Execution.claimProviderQuery provider Checkout.CheckoutSandbox) pool
            claimed `shouldSatisfy` maybe False (const True)
            modifyIORef' replacement (const (Execution.pqcLeaseToken <$> claimed))
            successfulQuery payment request) `shouldReturn` 1
          assertQueryUnpaid pool payment
          queryJobState pool payment `shouldReturn` ("processing",2)
          expected <- readIORef replacement
          tokens <- runSqlPool (rawSql
            "SELECT lease_token::text FROM commerce_provider_query_job job\
            \ JOIN commerce_provider_operation operation ON operation.id=job.operation_id\
            \ WHERE operation.payment_attempt_id=?::uuid" [paymentAttemptParameter payment]) pool
            :: IO [Single (Maybe Text)]
          tokens `shouldBe` [Single expected]

      it "rechecks the kill switch after the provider responds" $ \pool ->
        withQueryRecovery pool provider $ \merchant -> do
          payment <- reconciliationFixtureWithMerchant merchant pool provider
          prepareQueryJob pool payment
          runQueryTick pool (\request -> setRecoveryFlag pool False >> successfulQuery payment request)
            `shouldReturn` 1
          queryJobState pool payment `shouldReturn` ("retry",1)
          assertQueryUnpaid pool payment

      it "rechecks the process switch after the provider responds" $ \pool ->
        withQueryRecovery pool provider $ \merchant -> do
          payment <- reconciliationFixtureWithMerchant merchant pool provider
          prepareQueryJob pool payment
          runQueryTick pool (\request -> do
            setEnv "COMMERCE_PROVIDER_QUERY_RECOVERY_ENABLED" "false"
            successfulQuery payment request) `shouldReturn` 1
          queryJobState pool payment `shouldReturn` ("retry",1)
          assertQueryUnpaid pool payment

      it "rolls back financial effects if the atomic job completion fails" $ \pool ->
        withQueryRecovery pool provider $ \merchant -> do
          payment <- reconciliationFixtureWithMerchant merchant pool provider
          prepareQueryJob pool payment
          let install = runSqlPool (rawExecute
                "ALTER TABLE commerce_provider_query_job ADD CONSTRAINT synthetic_job_completion_failure\
                \ CHECK (status <> 'completed') NOT VALID" []) pool
              remove () = runSqlPool (rawExecute
                "ALTER TABLE commerce_provider_query_job DROP CONSTRAINT synthetic_job_completion_failure" []) pool
          failed <- bracket install remove (\_ -> try (runQueryTick pool (successfulQuery payment)))
            :: IO (Either SqlError Int)
          failed `shouldSatisfy` isLeft
          assertQueryUnpaid pool payment
          queryJobState pool payment `shouldReturn` ("processing",1)
          expireQueryLease pool payment
          resetQueryBudget pool provider
          runQueryTick pool (successfulQuery payment) `shouldReturn` 1
          queryJobState pool payment `shouldReturn` ("completed",2)
          assertPaymentPosted pool payment

      it "does not downgrade a callback success arriving during a pending query" $ \pool ->
        withQueryRecovery pool provider $ \merchant -> do
          payment <- reconciliationFixtureWithMerchant merchant pool provider
          prepareQueryJob pool payment
          runQueryTick pool (\_ -> do
            succeeded <- parsedQuery payment Adapter.AdapterSucceeded
            runSqlPool (Reconciliation.applyQueryResult payment succeeded
              "synthetic-concurrent-callback" notificationTime) pool
              `shouldReturn` Right Reconciliation.ReconciliationProcessed
            pure (Right (queryValue payment Adapter.AdapterPending))) `shouldReturn` 1
          queryJobState pool payment `shouldReturn` ("dead_letter",1)
          assertPaymentPosted pool payment

      it "dead-letters a crashed final lease without another remote query" $ \pool ->
        withQueryRecovery pool provider $ \merchant -> do
          payment <- reconciliationFixtureWithMerchant merchant pool provider
          prepareQueryJob pool payment
          _ <- runSqlPool (Execution.claimProviderQuery provider Checkout.CheckoutSandbox) pool
          runSqlPool (rawExecute
            "UPDATE commerce_provider_query_job SET attempt_count=24,\
            \ lease_expires_at=clock_timestamp()-INTERVAL '1 second' WHERE operation_id IN\
            \ (SELECT id FROM commerce_provider_operation WHERE payment_attempt_id=?::uuid)"
            [paymentAttemptParameter payment]) pool
          runQueryTick pool noQuery `shouldReturn` 0
          queryJobState pool payment `shouldReturn` ("dead_letter",24)
          assertQueryUnpaid pool payment

      it "dead-letters mismatched money and late payment on an expired checkout" $ \pool ->
        withQueryRecovery pool provider $ \merchant -> do
          payment <- reconciliationFixtureWithMerchant merchant pool provider
          prepareQueryJob pool payment
          runQueryTick pool (\_ -> pure (Right (queryValue payment { Execution.bppAmountMinor = 1 }
            Adapter.AdapterSucceeded))) `shouldReturn` 1
          queryJobState pool payment `shouldReturn` ("dead_letter",1)
          assertQueryUnpaid pool payment
          other <- reconciliationFixtureWithMerchant merchant pool provider
          prepareQueryJob pool other
          runSqlPool (rawExecute "UPDATE commerce_checkout_session SET status='expired' WHERE id=?::uuid"
            [PersistText (Checkout.checkoutReferenceId (Execution.bppCheckout other))]) pool
          resetQueryBudget pool provider
          runQueryTick pool (successfulQuery other) `shouldReturn` 1
          queryJobState pool other `shouldReturn` ("dead_letter",1)
          exceptions <- runSqlPool (rawSql
            "SELECT count(*) FROM commerce_reconciliation_exception\
            \ WHERE merchant_account_ref=? AND exception_type='scheduled_query_requires_review'"
            [PersistText merchant]) pool :: IO [Single Int64]
          exceptions `shouldBe` [Single 1]
          observed <- runSqlPool (rawSql
            "SELECT actual_amount_minor FROM commerce_reconciliation_exception\
            \ WHERE internal_reference=? AND exception_type='verified_payment_on_closed_checkout'"
            [PersistText (Checkout.checkoutReferenceId (Execution.bppCheckout other))]) pool
            :: IO [Single Int64]
          observed `shouldBe` [Single (Execution.bppAmountMinor other)]

      it "stops at the retry bound without converting pending into no charge" $ \pool ->
        withQueryRecovery pool provider $ \merchant -> do
          payment <- reconciliationFixtureWithMerchant merchant pool provider
          prepareQueryJob pool payment
          runSqlPool (rawExecute
            "UPDATE commerce_provider_query_job SET attempt_count=23 WHERE operation_id IN\
            \ (SELECT id FROM commerce_provider_operation WHERE payment_attempt_id=?::uuid)"
            [paymentAttemptParameter payment]) pool
          runQueryTick pool (\_ -> pure (Right (queryValue payment Adapter.AdapterPending))) `shouldReturn` 1
          queryJobState pool payment `shouldReturn` ("dead_letter",24)
          runQueryTick pool noQuery `shouldReturn` 0
          assertQueryUnpaid pool payment

      it "preserves terminal jobs and rejects invalid state or live-lease changes" $ \pool ->
        withQueryRecovery pool provider $ \merchant -> do
          payment <- reconciliationFixtureWithMerchant merchant pool provider
          prepareQueryJob pool payment
          let attemptParam = [paymentAttemptParameter payment]
              mutate suffix = try (runSqlPool (rawExecute
                ("UPDATE commerce_provider_query_job SET " <> suffix <>
                  " WHERE operation_id IN (SELECT id FROM commerce_provider_operation WHERE payment_attempt_id=?::uuid)")
                attemptParam) pool) :: IO (Either SqlError ())
          mutate "status='completed',completed_at=clock_timestamp()" >>= (`shouldSatisfy` isLeft)
          _ <- runSqlPool (Execution.claimProviderQuery provider Checkout.CheckoutSandbox) pool
          mutate "lease_token=gen_random_uuid()" >>= (`shouldSatisfy` isLeft)
          expireQueryLease pool payment
          resetQueryBudget pool provider
          runQueryTick pool (successfulQuery payment) `shouldReturn` 1
          mutate "last_error_code='rewritten'" >>= (`shouldSatisfy` isLeft)
          deleted <- try (runSqlPool (rawExecute
            "DELETE FROM commerce_provider_query_job WHERE operation_id IN\
            \ (SELECT id FROM commerce_provider_operation WHERE payment_attempt_id=?::uuid)" attemptParam) pool)
            :: IO (Either SqlError ())
          deleted `shouldSatisfy` isLeft
          queryJobState pool payment `shouldReturn` ("completed",2)

withQueryRecovery :: ConnectionPool -> Checkout.PaymentProvider -> (Text -> IO value) -> IO value
withQueryRecovery pool provider action = withNotificationEnvironment $
  bracket (lookupEnv "COMMERCE_PROVIDER_QUERY_RECOVERY_ENABLED")
    (maybe (unsetEnv "COMMERCE_PROVIDER_QUERY_RECOVERY_ENABLED")
      (setEnv "COMMERCE_PROVIDER_QUERY_RECOVERY_ENABLED")) $ \_ -> do
    merchant <- ("synthetic-query-" <>) . toText <$> nextRandom
    let restore () = do
          setRecoveryFlag pool False
          runSqlPool (rawExecute
            "UPDATE commerce_provider_account SET merchant_account_ref='synthetic-provider-retry-merchant',enabled=true\
            \ WHERE provider=? AND environment='sandbox'" [PersistText (Checkout.paymentProviderText provider)]) pool
        setup = do
          setEnv "COMMERCE_PROVIDER_QUERY_RECOVERY_ENABLED" "true"
          setEnv (if provider == Checkout.ProviderPlaceToPay then "PAYPHONE_TOKEN" else "PLACETOPAY_LOGIN") ""
          setRecoveryFlag pool True
          runSqlPool (rawExecute "UPDATE commerce_provider_account SET merchant_account_ref=?\
            \ WHERE provider=? AND environment='sandbox'"
            [PersistText merchant,PersistText (Checkout.paymentProviderText provider)]) pool
          resetQueryBudget pool provider
    bracket setup restore (const (action merchant))

setRecoveryFlag :: ConnectionPool -> Bool -> IO ()
setRecoveryFlag pool enabled = runSqlPool (rawExecute
  "UPDATE revenue_feature_flag SET enabled=? WHERE flag_key='checkout.provider_query_recovery' AND environment='sandbox'"
  [PersistBool enabled]) pool

resetQueryBudget :: ConnectionPool -> Checkout.PaymentProvider -> IO ()
resetQueryBudget pool provider = runSqlPool (rawExecute
  "UPDATE commerce_provider_query_budget SET next_query_at=clock_timestamp()-INTERVAL '1 second'\
  \ WHERE provider=? AND environment='sandbox'" [PersistText (Checkout.paymentProviderText provider)]) pool

queryEnv :: ConnectionPool -> Env
queryEnv pool = Env pool (error "Synthetic query worker must not use AppConfig")

runQueryTick :: ConnectionPool -> (Adapter.AdapterRequest -> IO (Either ProviderHttp.AdapterTransportError A.Value)) -> IO Int
runQueryTick pool fetch = Reconciliation.providerQueryWorkerTickWith fetch (queryEnv pool)

noQuery :: Adapter.AdapterRequest -> IO (Either ProviderHttp.AdapterTransportError A.Value)
noQuery _ = fail "No remote query is authorized in this test"

successfulQuery :: Execution.BoundProviderPayment -> Adapter.AdapterRequest
  -> IO (Either ProviderHttp.AdapterTransportError A.Value)
successfulQuery payment request = do
  Adapter.arOperation request `shouldBe` AdapterQuery
  Adapter.arProvider request `shouldBe` Execution.bppProvider payment
  pure (Right (queryValue payment Adapter.AdapterSucceeded))

prepareQueryJob :: ConnectionPool -> Execution.BoundProviderPayment -> IO ()
prepareQueryJob pool payment = do
  _ <- runSqlPool (Execution.enqueueProviderQueries (Execution.bppProvider payment) Checkout.CheckoutSandbox) pool
  runSqlPool (rawExecute
    "UPDATE commerce_provider_query_job SET next_attempt_at=clock_timestamp()-INTERVAL '1 day'\
    \ WHERE operation_id IN (SELECT id FROM commerce_provider_operation WHERE payment_attempt_id=?::uuid)"
    [paymentAttemptParameter payment]) pool
  queryJobState pool payment `shouldReturn` ("pending",0)

queryJobState :: ConnectionPool -> Execution.BoundProviderPayment -> IO (Text,Int)
queryJobState pool payment = do
  rows <- runSqlPool (rawSql
    "SELECT job.status,job.attempt_count FROM commerce_provider_query_job job\
    \ JOIN commerce_provider_operation operation ON operation.id=job.operation_id\
    \ WHERE operation.payment_attempt_id=?::uuid" [paymentAttemptParameter payment]) pool
    :: IO [(Single Text,Single Int)]
  case rows of [(Single status,Single count)] -> pure (status,count); _ -> fail "Expected one query job"

expireQueryLease :: ConnectionPool -> Execution.BoundProviderPayment -> IO ()
expireQueryLease pool payment = runSqlPool (rawExecute
  "UPDATE commerce_provider_query_job SET lease_expires_at=clock_timestamp()-INTERVAL '1 second'\
  \ WHERE operation_id IN (SELECT id FROM commerce_provider_operation WHERE payment_attempt_id=?::uuid)"
  [paymentAttemptParameter payment]) pool

assertQueryUnpaid :: ConnectionPool -> Execution.BoundProviderPayment -> Expectation
assertQueryUnpaid pool payment = do
  rows <- runSqlPool (rawSql
    "SELECT checkout.paid_minor,intent.captured_minor,operation.outcome_certainty,\
    \ (SELECT count(*) FROM commerce_ledger_transaction WHERE source_id=attempt.id::text),\
    \ (SELECT count(*) FROM commerce_receipt WHERE checkout_id=checkout.id)\
    \ FROM commerce_payment_attempt attempt\
    \ JOIN commerce_checkout_session checkout ON checkout.id=attempt.checkout_id\
    \ JOIN commerce_payment_intent intent ON intent.id=attempt.payment_intent_id\
    \ JOIN commerce_provider_operation operation ON operation.payment_attempt_id=attempt.id\
    \ WHERE attempt.id=?::uuid" [paymentAttemptParameter payment]) pool
    :: IO [(Single Int64,Single Int64,Single Text,Single Int64,Single Int64)]
  rows `shouldBe` [(Single 0,Single 0,Single "ambiguous",Single 0,Single 0)]

-- Shared CheckoutStore boundary: real PostgreSQL, synthetic verified evidence.
-- These tests do not exercise provider HTTP or actual refunds/disputes.
closedCheckoutEvidenceSpec :: SpecWith ConnectionPool
closedCheckoutEvidenceSpec = describe "closed checkout approval evidence" $
  forM_ [Checkout.ProviderPlaceToPay, Checkout.ProviderPayPhone] $ \provider ->
    describe (T.unpack (Checkout.paymentProviderText provider)) $
      forM_ ["expired", "cancelled"] $ \closedStatus ->
        describe (T.unpack closedStatus) $ do
          it "retains exact observed money once without applying a late capture" $ \pool -> do
            payment <- closedPaymentFixture pool provider closedStatus
            result <- parsedQuery payment Adapter.AdapterSucceeded
            financialBefore <- runSqlPool (closedPaymentFinancialSnapshot payment) pool
            outcomes <- concurrently (replicate 4 (runSqlPool
              (Reconciliation.applyQueryResult payment result "late-approval" notificationTime) pool))
            outcomes `shouldBe` replicate 4 (Right Reconciliation.ReconciliationDeadLetter)
            assertClosedPaymentEvidence pool payment
            runSqlPool (closedPaymentFinancialSnapshot payment) pool `shouldReturn` financialBefore
            snapshot <- runSqlPool (paymentSnapshot payment) pool
            runSqlPool (Reconciliation.applyQueryResult payment result "later-replay"
              (addUTCTime 3600 notificationTime)) pool
              `shouldReturn` Right Reconciliation.ReconciliationDeadLetter
            runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot

          it "rolls back review evidence and its audit with the caller savepoint" $ \pool -> do
            payment <- closedPaymentFixture pool provider closedStatus
            result <- parsedQuery payment Adapter.AdapterSucceeded
            snapshotBefore <- runSqlPool (paymentSnapshot payment) pool
            runSqlPool (do
              rawExecute "SAVEPOINT caller_owned" []
              applied <- Reconciliation.applyQueryResult payment result "late-rollback" notificationTime
              liftIO (applied `shouldBe` Right Reconciliation.ReconciliationDeadLetter)
              rawExecute "ROLLBACK TO SAVEPOINT caller_owned" []
              rawExecute "RELEASE SAVEPOINT caller_owned" []) pool
            runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshotBefore

          it "holds reordered outcomes and never releases review from an exception status edit" $ \pool -> do
            payment <- closedPaymentFixture pool provider closedStatus
            succeeded <- parsedQuery payment Adapter.AdapterSucceeded
            runSqlPool (Reconciliation.applyQueryResult payment succeeded "late-first" notificationTime)
              pool `shouldReturn` Right Reconciliation.ReconciliationDeadLetter
            forM_ ["assigned", "resolved", "ignored"] $ \reviewStatus -> do
              runSqlPool (rawExecute
                "UPDATE commerce_reconciliation_exception SET status=?,resolution_notes='synthetic review'\
                \ WHERE internal_reference=? AND exception_type='verified_payment_on_closed_checkout'"
                [PersistText reviewStatus,
                  PersistText (Checkout.checkoutReferenceId (Execution.bppCheckout payment))]) pool
              snapshot <- runSqlPool (paymentSnapshot payment) pool
              review <- runSqlPool (closedPaymentReviewSnapshot payment) pool
              forM_ [Adapter.AdapterSucceeded, Adapter.AdapterPending, Adapter.AdapterCancelled,
                  Adapter.AdapterUnknown] $ \state -> do
                result <- parsedQuery payment state
                runSqlPool (Reconciliation.applyQueryResult payment result "reordered-after-review"
                  (addUTCTime 3600 notificationTime)) pool
                  `shouldReturn` Right Reconciliation.ReconciliationDeadLetter
                runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot
                runSqlPool (closedPaymentReviewSnapshot payment) pool `shouldReturn` review

          it "does not create or acknowledge review from mismatched typed evidence" $ \pool -> do
            payment <- closedPaymentFixture pool provider closedStatus
            result <- parsedQuery payment Adapter.AdapterSucceeded
            let reject = do
                  snapshot <- runSqlPool (paymentSnapshot payment) pool
                  forM_ [result { Adapter.adapterResultAmountMinor = Nothing }
                    , result { Adapter.adapterResultAmountMinor = Just 1 }
                    , result { Adapter.adapterResultCurrency = Just "EUR" }
                    , result { Adapter.adapterResultExternalId = "SYNTHETIC-PRIVATE" }
                    , result { Adapter.adapterResultCertainty = ProviderAmbiguous }] $ \invalid -> do
                      outcome <- runSqlPool (Reconciliation.applyQueryResult payment invalid
                        "invalid-closed-approval" notificationTime) pool
                      outcome `shouldSatisfy` isLeft
                      show outcome `shouldNotContain` "SYNTHETIC-PRIVATE"
                  runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot
            reject
            runSqlPool (Reconciliation.applyQueryResult payment result "valid-closed-approval" notificationTime)
              pool `shouldReturn` Right Reconciliation.ReconciliationDeadLetter
            reject

          it "rolls back the exception if its immutable audit cannot be written" $ \pool -> do
            payment <- closedPaymentFixture pool provider closedStatus
            result <- parsedQuery payment Adapter.AdapterSucceeded
            snapshot <- runSqlPool (paymentSnapshot payment) pool
            let install = runSqlPool (rawExecute
                  "ALTER TABLE commerce_checkout_audit_event ADD CONSTRAINT synthetic_late_audit_failure\
                  \ CHECK (event_type<>'verified_payment_on_closed_checkout') NOT VALID" []) pool
                remove _ = runSqlPool (rawExecute
                  "ALTER TABLE commerce_checkout_audit_event DROP CONSTRAINT synthetic_late_audit_failure" []) pool
            failed <- bracket install remove (\_ -> try (runSqlPool
              (Reconciliation.applyQueryResult payment result "failed-review-audit" notificationTime) pool))
              :: IO (Either SqlError (Either Text Reconciliation.ReconciliationDisposition))
            failed `shouldSatisfy` isLeft
            runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot

          it "hides a retained redirect and never advertises no-charge fallback through recovery" $ \pool -> do
            payment <- closedPaymentFixture pool provider closedStatus
            let checkoutId = Checkout.checkoutReferenceId (Execution.bppCheckout payment)
                attemptId = Checkout.paymentAttemptReferenceId (Execution.bppAttempt payment)
                load token = runSqlPool (Execution.loadAuthorizedCreateOperation checkoutId attemptId
                  (digestText token) recoveryEncryptionKey) pool
            runSqlPool (rawExecute
              "UPDATE commerce_provider_operation SET redirect_url_ciphertext=pgp_sym_encrypt(?,?)\
              \ WHERE payment_attempt_id=?::uuid"
              [PersistText "https://checkout-test.placetopay.com/session/synthetic-private",
                PersistText recoveryEncryptionKey,paymentAttemptParameter payment]) pool
            original <- load checkoutId >>= requireRight
            Execution.porRedirectUrl original `shouldSatisfy` (/= Nothing)
            result <- parsedQuery payment Adapter.AdapterSucceeded
            runSqlPool (Reconciliation.applyQueryResult payment result "held-recovery" notificationTime)
              pool `shouldReturn` Right Reconciliation.ReconciliationDeadLetter
            held <- load checkoutId >>= requireRight
            Execution.porStatus held `shouldBe` "ambiguous"
            Execution.porOutcomeCertainty held `shouldBe` ProviderAmbiguous
            Execution.porRedirectUrl held `shouldBe` Nothing
            Execution.porReference held `shouldBe` Execution.porReference original
            Execution.porProviderResourceId held `shouldBe` Execution.porProviderResourceId original
            load "wrong-synthetic-token" >>= (`shouldSatisfy` isLeft)
            withRecoveryEnvironment $ do
              let _ :<|> getSession :<|> _ = providerExecutionServer
                  request token = runHandler (runReaderT (getSession checkoutId attemptId (Just token))
                    (queryEnv pool))
              dto <- request checkoutId >>= requireRight
              pssState dto `shouldBe` "ambiguous"
              pssOutcomeCertainty dto `shouldBe` "ambiguous"
              pssRedirectUrl dto `shouldBe` Nothing
              pssCanRetryOrFallback dto `shouldBe` False
              request "wrong-synthetic-token" >>= assertHttpError 404

          it "denies unauthorized polling before missing or invalid encryption configuration" $
            \pool -> withRecoveryEnvironment $ do
              payment <- closedPaymentFixture pool provider closedStatus
              otherCheckout <- toText <$> nextRandom
              otherAttempt <- toText <$> nextRandom
              let checkoutId = Checkout.checkoutReferenceId (Execution.bppCheckout payment)
                  attemptId = Checkout.paymentAttemptReferenceId (Execution.bppAttempt payment)
                  _ :<|> getSession :<|> _ = providerExecutionServer
                  request checkout attempt token = runHandler
                    (runReaderT (getSession checkout attempt token) (queryEnv pool))
              before <- runSqlPool (paymentSnapshot payment) pool
              forM_ [Nothing, Just "too-short"] $ \key -> do
                maybe (unsetEnv "COMMERCE_EVENT_ENCRYPTION_KEY")
                  (setEnv "COMMERCE_EVENT_ENCRYPTION_KEY") key
                request checkoutId attemptId Nothing >>= assertHttpError 404
                request checkoutId attemptId (Just "wrong-synthetic-token") >>= assertHttpError 404
                request otherCheckout attemptId (Just checkoutId) >>= assertHttpError 404
                request checkoutId otherAttempt (Just checkoutId) >>= assertHttpError 404
                request checkoutId attemptId (Just checkoutId) >>= assertHttpError 503
              setEnv "COMMERCE_EVENT_ENCRYPTION_KEY" (T.unpack recoveryEncryptionKey)
              request checkoutId attemptId (Just checkoutId) >>= requireRight
                >>= (\dto -> pssCheckoutId dto `shouldBe` checkoutId)
              runSqlPool (paymentSnapshot payment) pool `shouldReturn` before

          it "fails closed if a retained review record has conflicting money" $ \pool -> do
            payment <- closedPaymentFixture pool provider closedStatus
            result <- parsedQuery payment Adapter.AdapterSucceeded
            runSqlPool (Reconciliation.applyQueryResult payment result "first-review" notificationTime)
              pool `shouldReturn` Right Reconciliation.ReconciliationDeadLetter
            runSqlPool (rawExecute
              "UPDATE commerce_reconciliation_exception SET actual_amount_minor=1\
              \ WHERE internal_reference=? AND exception_type='verified_payment_on_closed_checkout'"
              [PersistText (Checkout.checkoutReferenceId (Execution.bppCheckout payment))]) pool
            snapshot <- runSqlPool (paymentSnapshot payment) pool
            review <- runSqlPool (closedPaymentReviewSnapshot payment) pool
            runSqlPool (Reconciliation.applyQueryResult payment result "conflicting-review" notificationTime)
              pool >>= (`shouldSatisfy` isLeft)
            runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot
            runSqlPool (closedPaymentReviewSnapshot payment) pool `shouldReturn` review

closedPaymentFixture
  :: ConnectionPool -> Checkout.PaymentProvider -> Text -> IO Execution.BoundProviderPayment
closedPaymentFixture pool provider status = do
  payment <- reconciliationFixture pool provider
  runSqlPool (rawExecute "UPDATE commerce_checkout_session SET status=? WHERE id=?::uuid"
    [PersistText status, PersistText (Checkout.checkoutReferenceId (Execution.bppCheckout payment))]) pool
  pure payment

closedPaymentFinancialSnapshot :: Execution.BoundProviderPayment -> SqlPersistT IO [Single Text]
closedPaymentFinancialSnapshot payment = rawSql
  "SELECT jsonb_build_object(\
  \ 'checkout',to_jsonb(checkout),'attempt',to_jsonb(attempt),'intent',to_jsonb(intent),\
  \ 'operation',to_jsonb(operation.*),\
  \ 'ledger',(SELECT jsonb_agg(to_jsonb(txn) ORDER BY txn.id) FROM commerce_ledger_transaction txn\
  \ WHERE source_id=attempt.id::text),\
  \ 'receipts',(SELECT jsonb_agg(to_jsonb(receipt) ORDER BY receipt.id) FROM commerce_receipt receipt\
  \ WHERE checkout_id=checkout.id),\
  \ 'history',(SELECT jsonb_agg(to_jsonb(history) ORDER BY history.id) FROM commerce_payment_state_history history\
  \ WHERE payment_intent_id=intent.id))::text\
  \ FROM commerce_payment_attempt attempt\
  \ JOIN commerce_checkout_session checkout ON checkout.id=attempt.checkout_id\
  \ JOIN commerce_payment_intent intent ON intent.id=attempt.payment_intent_id\
  \ JOIN commerce_provider_operation operation ON operation.payment_attempt_id=attempt.id\
  \ WHERE attempt.id=?::uuid"
  [paymentAttemptParameter payment]

closedPaymentReviewSnapshot :: Execution.BoundProviderPayment -> SqlPersistT IO [Single Text]
closedPaymentReviewSnapshot payment = rawSql
  "SELECT to_jsonb(review)::text FROM commerce_reconciliation_exception review\
  \ WHERE internal_reference=? AND exception_type='verified_payment_on_closed_checkout' ORDER BY id"
  [PersistText (Checkout.checkoutReferenceId (Execution.bppCheckout payment))]

assertClosedPaymentEvidence :: ConnectionPool -> Execution.BoundProviderPayment -> Expectation
assertClosedPaymentEvidence pool payment = do
  rows <- runSqlPool (rawSql
    "SELECT exception.expected_amount_minor,exception.actual_amount_minor,exception.currency,\
    \ exception.provider,exception.environment,exception.merchant_account_ref,exception.detected_at,\
    \ (SELECT count(*) FROM commerce_checkout_audit_event audit\
    \ WHERE audit.checkout_id=?::uuid AND audit.event_type='verified_payment_on_closed_checkout'\
    \ AND audit.metadata->>'exception_id'=exception.id::text\
    \ AND audit.metadata->>'attempt_id'=?)\
    \ FROM commerce_reconciliation_exception exception WHERE exception.internal_reference=?\
    \ AND exception.provider_reference=? AND exception.exception_type='verified_payment_on_closed_checkout'"
    [ PersistText checkoutId, paymentAttemptParameter payment, PersistText checkoutId
    , PersistText (Execution.bppProviderResourceId payment)]) pool
    :: IO [(Single Int64, Single Int64, Single Text, Single Text, Single Text,
      Single Text, Single UTCTime, Single Int64)]
  rows `shouldBe` [(Single (Execution.bppAmountMinor payment),Single (Execution.bppAmountMinor payment),
    Single (Execution.bppCurrency payment),Single (Checkout.paymentProviderText (Execution.bppProvider payment)),
    Single "sandbox",Single (Execution.bppMerchantRef payment),Single notificationTime,Single 1)]
  where checkoutId = Checkout.checkoutReferenceId (Execution.bppCheckout payment)

-- Zero commercial fees are valid; zero-valued journal lines are not.
ticketLedgerSpec :: SpecWith ConnectionPool
ticketLedgerSpec = describe "ticket capture ledger" $
  forM_ [(0,0),(0,261),(100,0),(100,261)] $ \(fee,tax) ->
    it ("conserves money and replays once with fee/tax " <> show (fee,tax)) $ \pool -> do
      [Single checkoutId] <- runSqlPool (rawSql
        "SELECT payment_test.checkout('event_ticket_order',?,?)::text"
        [PersistInt64 fee,PersistInt64 tax]) pool
      creation <- checkoutCreation pool Checkout.ProviderPayPal checkoutId
      payment <- captureFixtureFromCheckout creation "capture" Checkout.AttemptProcessing pool Checkout.ProviderPayPal
      runSqlPool (Checkout.recordVerifiedPayment payment) pool `shouldReturn` Right True
      entries <- runSqlPool (rawSql
        "SELECT entry.account_code,entry.amount_minor FROM commerce_ledger_entry entry JOIN commerce_ledger_transaction txn ON txn.id=entry.transaction_id WHERE txn.source_id=? ORDER BY entry.account_code"
        [PersistText (Checkout.paymentAttemptReferenceId (Checkout.vpAttempt payment))]) pool
          :: IO [(Single Text, Single Int64)]
      entries `shouldBe`
        ([(Single "cash.paypal",Single 12515),(Single "liability.event_organizer_payable",Single (negate (12515-fee-tax)))]
        ++ [(Single "liability.sales_tax",Single (negate tax)) | tax>0]
        ++ [(Single "revenue.event_ticket_order",Single (negate fee)) | fee>0])
      sum [amount | (_,Single amount)<-entries] `shouldBe` 0
      snapshot <- runSqlPool (captureSnapshot payment) pool
      runSqlPool (Checkout.recordVerifiedPayment payment) pool `shouldReturn` Right False
      runSqlPool (captureSnapshot payment) pool `shouldReturn` snapshot

      -- Complete partial refunds through the actual canonical state machine,
      -- then verify the combined refund journals exactly reverse the capture.
      forM_ (zip [1 :: Int ..] [2000,2000,8515]) $ \(index,amount) -> do
        key <- toText <$> nextRandom
        let creation = Refund.RefundCreation
              { Refund.rcCheckout = Checkout.vpCheckout payment
              , Refund.rcPaymentAttempt = Checkout.vpAttempt payment
              , Refund.rcProvider = Checkout.ProviderPayPal
              , Refund.rcEnvironment = Checkout.CheckoutSandbox
              , Refund.rcMerchantRef = Checkout.vpMerchantRef payment
              , Refund.rcAmountMinor = amount
              , Refund.rcCurrency = "USD"
              , Refund.rcReasonCode = "customer_request"
              , Refund.rcIdempotencyKey = key
              , Refund.rcRequestedBy = 1
              , Refund.rcCreatedAt = Checkout.vpOccurredAt payment
              }
        refund <- runSqlPool (Refund.requestSingleLineRefund creation) pool >>= requireRight
        (_,claimed) <- runSqlPool (Refund.approveRefundForProcessing (Refund.rrReference refund) 2
          (Checkout.vpOccurredAt payment)) pool >>= requireRight
        claimed `shouldBe` True
        let completion = Refund.VerifiedRefund
              { Refund.vrRefund = Refund.rrReference refund
              , Refund.vrProviderRefund = "synthetic-ticket-refund-" <> key
              , Refund.vrAmountMinor = amount
              , Refund.vrCurrency = "USD"
              , Refund.vrOccurredAt = Checkout.vpOccurredAt payment
              , Refund.vrCorrelationId = "ticket-refund-" <> T.pack (show index)
              }
        -- The full schema refuses a changed fee snapshot at its write boundary.
        -- An unrelated error is not accepted as evidence of this protection.
        when (index == 1) $ do
          beforeDenied <- runSqlPool (captureSnapshot payment) pool
          denied <- try (runSqlPool (rawExecute
            "UPDATE event_ticket_checkout_runtime SET platform_fee_minor=platform_fee_minor+1,\
            \ organizer_payable_minor=organizer_payable_minor-1 WHERE checkout_id=?::uuid"
            [captureCheckoutParameter payment]) pool) :: IO (Either SqlError ())
          case denied of
            Left problem -> sqlErrorMsg problem `shouldBe`
              "Event ticket checkout snapshot is immutable after creation"
            Right _ -> expectationFailure "Mutable ticket fee snapshot was accepted"
          runSqlPool (captureSnapshot payment) pool `shouldReturn` beforeDenied
        runSqlPool (Refund.recordVerifiedRefund completion) pool `shouldReturn` Right True
        replays <- concurrently (replicate 4 (runSqlPool (Refund.recordVerifiedRefund completion) pool))
        replays `shouldBe` replicate 4 (Right False)
      refundedEntries <- runSqlPool (rawSql
        "SELECT entry.account_code,SUM(entry.amount_minor)::bigint\
        \ FROM commerce_refund refund JOIN commerce_ledger_transaction txn\
        \ ON txn.source_type='refund' AND txn.source_id=refund.id::text\
        \ JOIN commerce_ledger_entry entry ON entry.transaction_id=txn.id\
        \ WHERE refund.checkout_id=?::uuid AND txn.status='posted'\
        \ GROUP BY entry.account_code ORDER BY entry.account_code"
        [captureCheckoutParameter payment]) pool :: IO [(Single Text,Single Int64)]
      refundedEntries `shouldBe` [(account,Single (negate amount)) | (account,Single amount) <- entries]
      receiptCounts <- runSqlPool (rawSql
        "SELECT count(*) FROM commerce_receipt WHERE checkout_id=?::uuid AND kind='credit_note'"
        [captureCheckoutParameter payment]) pool :: IO [Single Int64]
      receiptCounts `shouldBe` [Single 3]

captureReplaySpec :: SpecWith ConnectionPool
captureReplaySpec = describe "verified capture replay integrity" $
  forM_ [Checkout.ProviderDatafast, Checkout.ProviderPayPal,
      Checkout.ProviderPlaceToPay, Checkout.ProviderPayPhone] $ \provider ->
    describe (T.unpack (Checkout.paymentProviderText provider)) $ do
      it "preserves the complete financial snapshot on later and concurrent replays" $ \pool -> do
        payment <- captureFixture pool provider
        runSqlPool (Checkout.recordVerifiedPayment payment) pool `shouldReturn` Right True
        snapshot <- runSqlPool (captureSnapshot payment) pool
        let replay = payment { Checkout.vpOccurredAt = addUTCTime 3600 (Checkout.vpOccurredAt payment)
                             , Checkout.vpCorrelationId = "synthetic-later-replay" }
        outcomes <- concurrently (replicate 4 (runSqlPool (Checkout.recordVerifiedPayment replay) pool))
        outcomes `shouldBe` replicate 4 (Right False)
        runSqlPool (captureSnapshot payment) pool `shouldReturn` snapshot

      it "rejects same-amount receipts belonging to another provider or external reference" $ \pool ->
        forM_ ["adapter='synthetic-other-provider'", "external_reference='synthetic-other-reference'"
          , "external_reference=NULL", "receipt_number=receipt_number||'-other'"
          , "amount_minor=1", "currency='EUR'"] $ \change -> do
          payment <- captureFixture pool provider
          runSqlPool (Checkout.recordVerifiedPayment payment) pool `shouldReturn` Right True
          runSqlPool (rawExecute ("UPDATE commerce_receipt SET " <> change <> " WHERE checkout_id=?::uuid")
            [PersistText (Checkout.checkoutReferenceId (Checkout.vpCheckout payment))]) pool
          snapshot <- runSqlPool (captureSnapshot payment) pool
          runSqlPool (Checkout.recordVerifiedPayment payment) pool >>= (`shouldSatisfy` isLeft)
          runSqlPool (captureSnapshot payment) pool `shouldReturn` snapshot

      it "acknowledges original capture after refund or dispute without reopening checkout" $ \pool ->
        forM_ [("partially_refunded", 100), ("refunded", 12515), ("disputed", 0), ("chargeback", 0)] $ \(status, refunded) -> do
          payment <- captureFixture pool provider
          runSqlPool (Checkout.recordVerifiedPayment payment) pool `shouldReturn` Right True
          runSqlPool (do
            rawExecute "UPDATE commerce_checkout_session SET status=?,refunded_minor=? WHERE id=?::uuid"
              [PersistText status,PersistInt64 refunded,captureCheckoutParameter payment]
            rawExecute "UPDATE commerce_payment_intent SET status=?,refunded_minor=? WHERE checkout_id=?::uuid"
              [PersistText status,PersistInt64 refunded,captureCheckoutParameter payment]
            rawExecute "UPDATE commerce_receipt SET voided_at=NOW() WHERE checkout_id=?::uuid"
              [captureCheckoutParameter payment]) pool
          snapshot <- runSqlPool (captureSnapshot payment) pool
          runSqlPool (Checkout.recordVerifiedPayment payment
            { Checkout.vpOccurredAt = addUTCTime 3600 (Checkout.vpOccurredAt payment) }) pool
            `shouldReturn` Right False
          runSqlPool (captureSnapshot payment) pool `shouldReturn` snapshot

      it "does not rebuild missing receipts or accept duplicate historical receipts" $ \pool ->
        forM_ ["DELETE FROM commerce_receipt WHERE checkout_id=?::uuid"
          , "INSERT INTO commerce_receipt(checkout_id,receipt_number,kind,adapter,external_reference,amount_minor,currency,issued_at,voided_at) SELECT checkout_id,receipt_number||'-duplicate',kind,adapter,external_reference,amount_minor,currency,issued_at,NOW() FROM commerce_receipt WHERE checkout_id=?::uuid"] $ \corrupt -> do
          payment <- captureFixture pool provider
          runSqlPool (Checkout.recordVerifiedPayment payment) pool `shouldReturn` Right True
          runSqlPool (rawExecute corrupt [captureCheckoutParameter payment]) pool
          snapshot <- runSqlPool (captureSnapshot payment) pool
          runSqlPool (Checkout.recordVerifiedPayment payment) pool >>= (`shouldSatisfy` isLeft)
          runSqlPool (captureSnapshot payment) pool `shouldReturn` snapshot

      it "rejects incomplete historical money instead of silently completing it" $ \pool ->
        forM_ ["UPDATE commerce_checkout_session SET paid_minor=1 WHERE id=?::uuid"
          , "UPDATE commerce_checkout_session SET status='paid',paid_minor=total_minor WHERE id=?::uuid"
          , "UPDATE commerce_payment_attempt SET status='succeeded' WHERE checkout_id=?::uuid"] $ \corrupt -> do
          payment <- captureFixture pool provider
          if "status='paid'" `T.isInfixOf` corrupt then do
            denied <- try (runSqlPool (rawExecute corrupt [captureCheckoutParameter payment]) pool)
              :: IO (Either SqlError ())
            case denied of
              Left problem -> sqlErrorMsg problem `shouldBe`
                "Service booking checkout cannot become paid without bound verified payment evidence"
              Right _ -> expectationFailure "Unverified paid checkout was accepted"
          else do
            runSqlPool (rawExecute corrupt [captureCheckoutParameter payment]) pool
            snapshot <- runSqlPool (captureSnapshot payment) pool
            runSqlPool (Checkout.recordVerifiedPayment payment) pool >>= (`shouldSatisfy` isLeft)
            runSqlPool (captureSnapshot payment) pool `shouldReturn` snapshot

      it "preserves successful and closed attempt evidence during binding replay" $ \pool -> do
        payment <- captureFixture pool provider
        runSqlPool (Checkout.recordVerifiedPayment payment) pool `shouldReturn` Right True
        snapshot <- runSqlPool (captureSnapshot payment) pool
        let binding = (captureBinding payment)
              { Checkout.pbcOccurredAt = addUTCTime 3600 (Checkout.vpOccurredAt payment) }
        outcomes <- concurrently (replicate 4 (runSqlPool (Checkout.bindProviderResource binding) pool))
        outcomes `shouldBe` replicate 4 (Right ())
        runSqlPool (captureSnapshot payment) pool `shouldReturn` snapshot
        forM_ ["failed", "cancelled", "expired", "requires_review"] $ \status -> do
          other <- captureFixture pool provider
          runSqlPool (rawExecute "UPDATE commerce_payment_attempt SET status=? WHERE id=?::uuid"
            [PersistText status,PersistText (Checkout.paymentAttemptReferenceId (Checkout.vpAttempt other))]) pool
          closed <- runSqlPool (captureSnapshot other) pool
          runSqlPool (Checkout.bindProviderResource (captureBinding other)) pool `shouldReturn` Right ()
          runSqlPool (captureSnapshot other) pool `shouldReturn` closed

      it "advances customer action once and never regresses processing during binding replay" $ \pool -> do
        payment <- captureFixtureWithStage Checkout.AttemptRequiresCustomerAction pool provider
        runSqlPool (Checkout.bindProviderResource (captureBinding payment)) pool `shouldReturn` Right ()
        snapshot <- runSqlPool (captureSnapshot payment) pool
        runSqlPool (Checkout.bindProviderResource (captureBinding payment)
          { Checkout.pbcStage = Checkout.AttemptRequiresCustomerAction
          , Checkout.pbcOccurredAt = addUTCTime 3600 (Checkout.vpOccurredAt payment) }) pool `shouldReturn` Right ()
        runSqlPool (captureSnapshot payment) pool `shouldReturn` snapshot
        runSqlPool (Checkout.recordVerifiedPayment payment) pool `shouldReturn` Right True

      it "rejects cross-checkout bindings before inserting another resource or audit" $ \pool -> do
        payment <- captureFixture pool provider
        other <- captureFixture pool provider
        snapshots <- mapM (\value -> runSqlPool (captureSnapshot value) pool) [payment,other]
        countBefore <- runSqlPool (rawSql "SELECT count(*) FROM commerce_provider_binding" []) pool :: IO [Single Int64]
        runSqlPool (Checkout.bindProviderResource (captureBinding payment)
          { Checkout.pbcCheckout = Checkout.vpCheckout other
          , Checkout.pbcProviderResource = "synthetic-unbound-new-resource"
          , Checkout.pbcResourceType = "synthetic-other-resource" }) pool >>= (`shouldSatisfy` isLeft)
        mapM (\value -> runSqlPool (captureSnapshot value) pool) [payment,other] `shouldReturn` snapshots
        runSqlPool (rawSql "SELECT count(*) FROM commerce_provider_binding" []) pool `shouldReturn` countBefore

      it "still rejects first capture on expired or cancelled checkouts" $ \pool ->
        forM_ ["expired", "cancelled"] $ \status -> do
          payment <- captureFixture pool provider
          runSqlPool (rawExecute "UPDATE commerce_checkout_session SET status=? WHERE id=?::uuid"
            [PersistText status,captureCheckoutParameter payment]) pool
          snapshot <- runSqlPool (captureSnapshot payment) pool
          runSqlPool (Checkout.recordVerifiedPayment payment) pool >>= (`shouldSatisfy` isLeft)
          runSqlPool (captureSnapshot payment) pool `shouldReturn` snapshot

captureFixture :: ConnectionPool -> Checkout.PaymentProvider -> IO Checkout.VerifiedPayment
captureFixture = captureFixtureWithStage Checkout.AttemptProcessing

captureFixtureWithStage
  :: Checkout.PaymentAttemptStage -> ConnectionPool -> Checkout.PaymentProvider -> IO Checkout.VerifiedPayment
captureFixtureWithStage = captureFixtureForDomain "service_booking" "payment"

captureFixtureForDomain
  :: Text -> Text -> Checkout.PaymentAttemptStage -> ConnectionPool
  -> Checkout.PaymentProvider -> IO Checkout.VerifiedPayment
captureFixtureForDomain domain resourceType stage =
  captureFixtureForDomainWithLines domain resourceType stage [12515]

captureFixtureForDomainWithLines
  :: Text -> Text -> Checkout.PaymentAttemptStage -> [Int64] -> ConnectionPool
  -> Checkout.PaymentProvider -> IO Checkout.VerifiedPayment
captureFixtureForDomainWithLines domain resourceType stage amounts =
  captureFixtureForDomainWithOrder domain resourceType stage amounts Nothing

captureFixtureForDomainWithOrder
  :: Text -> Text -> Checkout.PaymentAttemptStage -> [Int64] -> Maybe Text -> ConnectionPool
  -> Checkout.PaymentProvider -> IO Checkout.VerifiedPayment
captureFixtureForDomainWithOrder domain requestedResourceType stage amounts domainOrder pool provider = do
  seed <- newCheckoutWithOrder domain amounts domainOrder pool
  captureFixtureFromCheckout seed requestedResourceType stage pool provider

captureFixtureFromCheckout :: Checkout.PaymentAttemptCreation -> Text -> Checkout.PaymentAttemptStage
  -> ConnectionPool -> Checkout.PaymentProvider -> IO Checkout.VerifiedPayment
captureFixtureFromCheckout seed requestedResourceType stage pool provider = do
  let creation = seed { Checkout.pacProvider = provider }
      method = case provider of
        Checkout.ProviderPayPal -> MethodPayPalWallet
        Checkout.ProviderPayPhone -> MethodPayPhoneWallet
        _ -> MethodCard
      checkoutId = Checkout.checkoutReferenceId (Checkout.pacCheckout creation)
      resourceType = case (provider, requestedResourceType) of
        (Checkout.ProviderDatafast, "payment") -> "checkout"
        (Checkout.ProviderDatafast, "capture") -> "checkout"
        (Checkout.ProviderPayPal, "payment") -> "capture"
        (Checkout.ProviderPlaceToPay, "payment") -> "session"
        (Checkout.ProviderPayPhone, "payment") -> "sale"
        _ -> requestedResourceType
  [Single domainReference] <- runSqlPool (rawSql
    "SELECT domain_order_id FROM commerce_checkout_session WHERE id=?::uuid"
    [PersistText checkoutId]) pool
  attempt <- runSqlPool (Runtime.beginPaymentAttemptForMethod method creation) pool >>= requireRight
  let resource = "synthetic-capture-" <> Checkout.paymentAttemptReferenceId attempt
      boundReference = if provider `elem` [Checkout.ProviderPlaceToPay, Checkout.ProviderPayPhone]
        then providerReference provider checkoutId else domainReference
  when (provider `elem` [Checkout.ProviderPlaceToPay, Checkout.ProviderPayPhone]) $
    runSqlPool (rawExecute
      "INSERT INTO commerce_provider_operation(payment_attempt_id,provider,environment,merchant_account_ref,\
      \ provider_reference,operation,idempotency_key,request_sha256,provider_resource_id,status,outcome_certainty,started_at)\
      \ VALUES (?::uuid,?,'sandbox',?,?,'create',?,repeat('a',64),?,'processing','ambiguous',NOW())"
      [PersistText (Checkout.paymentAttemptReferenceId attempt),PersistText (Checkout.paymentProviderText provider),
       PersistText (Checkout.pacMerchantRef creation),PersistText boundReference,
       PersistText (Checkout.pacIdempotencyKey creation),PersistText resource]) pool
  _ <- runSqlPool (Checkout.bindProviderResource Checkout.ProviderBindingCreation
    { Checkout.pbcAttempt = attempt, Checkout.pbcCheckout = Checkout.pacCheckout creation
    , Checkout.pbcProvider = provider, Checkout.pbcEnvironment = Checkout.CheckoutSandbox
    , Checkout.pbcMerchantRef = Checkout.pacMerchantRef creation, Checkout.pbcResourceType = resourceType
    , Checkout.pbcProviderResource = resource, Checkout.pbcResourcePath = Nothing
    , Checkout.pbcOrderReference = boundReference, Checkout.pbcAmountMinor = 12515
    , Checkout.pbcCurrency = "USD", Checkout.pbcStage = stage
    , Checkout.pbcOccurredAt = Checkout.pacCreatedAt creation
    , Checkout.pbcCorrelationId = "synthetic-capture-binding" }) pool >>= requireRight
  pure Checkout.VerifiedPayment
    { Checkout.vpAttempt = attempt, Checkout.vpCheckout = Checkout.pacCheckout creation
    , Checkout.vpProvider = provider, Checkout.vpEnvironment = Checkout.CheckoutSandbox
    , Checkout.vpMerchantRef = Checkout.pacMerchantRef creation, Checkout.vpResourceType = resourceType
    , Checkout.vpProviderResource = resource, Checkout.vpProviderResourcePath = Nothing
    , Checkout.vpOrderReference = domainReference, Checkout.vpProviderReference = boundReference
    , Checkout.vpAmountMinor = 12515, Checkout.vpCurrency = "USD"
    , Checkout.vpEvidence = "server_to_server", Checkout.vpOccurredAt = Checkout.pacCreatedAt creation
    , Checkout.vpCorrelationId = "synthetic-capture-verification" }

captureBinding :: Checkout.VerifiedPayment -> Checkout.ProviderBindingCreation
captureBinding payment = Checkout.ProviderBindingCreation
  { Checkout.pbcAttempt = Checkout.vpAttempt payment, Checkout.pbcCheckout = Checkout.vpCheckout payment
  , Checkout.pbcProvider = Checkout.vpProvider payment, Checkout.pbcEnvironment = Checkout.vpEnvironment payment
  , Checkout.pbcMerchantRef = Checkout.vpMerchantRef payment, Checkout.pbcResourceType = Checkout.vpResourceType payment
  , Checkout.pbcProviderResource = Checkout.vpProviderResource payment, Checkout.pbcResourcePath = Checkout.vpProviderResourcePath payment
  , Checkout.pbcOrderReference = Checkout.vpProviderReference payment, Checkout.pbcAmountMinor = Checkout.vpAmountMinor payment
  , Checkout.pbcCurrency = Checkout.vpCurrency payment, Checkout.pbcStage = Checkout.AttemptProcessing
  , Checkout.pbcOccurredAt = Checkout.vpOccurredAt payment, Checkout.pbcCorrelationId = "synthetic-binding-replay" }

captureCheckoutParameter :: Checkout.VerifiedPayment -> PersistValue
captureCheckoutParameter = PersistText . Checkout.checkoutReferenceId . Checkout.vpCheckout

manualCaptureReplaySpec :: SpecWith ConnectionPool
manualCaptureReplaySpec = describe "approved bank transfer replay integrity" $ do
  it "requires independent approval and preserves evidence on later settlement replay" $ \pool -> do
    seed <- newCheckoutForDomain "service_booking" pool
    let creation = seed { Checkout.pacProvider = Checkout.ProviderBankTransfer
                        , Checkout.pacOperation = Checkout.OperationManualVerify }
    attempt <- runSqlPool (Runtime.beginPaymentAttempt creation) pool >>= requireRight
    evidence <- toText <$> nextRandom
    let payment = Checkout.VerifiedPayment
          { Checkout.vpAttempt = attempt, Checkout.vpCheckout = Checkout.pacCheckout creation
          , Checkout.vpProvider = Checkout.ProviderBankTransfer
          , Checkout.vpEnvironment = Checkout.CheckoutSandbox
          , Checkout.vpMerchantRef = Checkout.pacMerchantRef creation
          , Checkout.vpResourceType = "manual_evidence", Checkout.vpProviderResource = evidence
          , Checkout.vpProviderResourcePath = Nothing
          , Checkout.vpOrderReference = Checkout.checkoutReferenceId (Checkout.pacCheckout creation)
          , Checkout.vpProviderReference = Checkout.checkoutReferenceId (Checkout.pacCheckout creation)
          , Checkout.vpAmountMinor = 12515, Checkout.vpCurrency = "USD"
          , Checkout.vpEvidence = "staff_verified_manual"
          , Checkout.vpOccurredAt = Checkout.pacCreatedAt creation
          , Checkout.vpCorrelationId = "synthetic-bank-approval" }
    runSqlPool (do
      rawExecute "INSERT INTO commerce_manual_payment_evidence(id,checkout_id,payment_attempt_id,status)\
        \ VALUES (?::uuid,?::uuid,?::uuid,'awaiting_evidence')"
        [PersistText evidence,captureCheckoutParameter payment,
          PersistText (Checkout.paymentAttemptReferenceId attempt)]
      rawExecute "UPDATE commerce_manual_payment_evidence\
        \ SET status='submitted',customer_reference='synthetic-bank-reference',submitted_amount_minor=12515,\
        \ currency='USD',submitted_at=NOW(),submitted_by=1 WHERE id=?::uuid" [PersistText evidence]) pool
    _ <- runSqlPool (Checkout.bindProviderResource (captureBinding payment)) pool >>= requireRight
    snapshot <- runSqlPool (captureSnapshot payment) pool
    runSqlPool (Checkout.recordApprovedManualPayment payment) pool >>= (`shouldSatisfy` isLeft)
    runSqlPool (captureSnapshot payment) pool `shouldReturn` snapshot
    rejected <- try (runSqlPool (rawExecute "UPDATE commerce_manual_payment_evidence\
      \ SET status='under_review',reviewed_by=1 WHERE id=?::uuid" [PersistText evidence]) pool)
      :: IO (Either SqlError ())
    rejected `shouldSatisfy` isLeft
    runSqlPool (do
      rawExecute "UPDATE commerce_manual_payment_evidence SET status='under_review',reviewed_by=2 WHERE id=?::uuid"
        [PersistText evidence]
      rawExecute "UPDATE commerce_manual_payment_evidence\
        \ SET status='approved',reviewed_at=NOW(),review_notes='Synthetic independently approved evidence' WHERE id=?::uuid"
        [PersistText evidence]) pool
    runSqlPool (Checkout.recordApprovedManualPayment payment) pool `shouldReturn` Right True
    paid <- runSqlPool (captureSnapshot payment) pool
    outcomes <- concurrently (replicate 4 (runSqlPool (Checkout.recordApprovedManualPayment payment
      { Checkout.vpOccurredAt = addUTCTime 3600 (Checkout.vpOccurredAt payment) }) pool))
    outcomes `shouldBe` replicate 4 (Right False)
    runSqlPool (captureSnapshot payment) pool `shouldReturn` paid

captureSnapshot :: Checkout.VerifiedPayment -> SqlPersistT IO [Single Text]
captureSnapshot payment = rawSql
  "SELECT jsonb_build_object('checkout',to_jsonb(checkout),'attempt',to_jsonb(attempt),\
  \ 'intent',to_jsonb(intent),\
  \ 'manual',(SELECT jsonb_agg(to_jsonb(evidence) ORDER BY evidence.id) FROM commerce_manual_payment_evidence evidence WHERE checkout_id=checkout.id),\
  \ 'receipts',(SELECT jsonb_agg(to_jsonb(receipt) ORDER BY receipt.id) FROM commerce_receipt receipt WHERE checkout_id=checkout.id),\
  \ 'ledger',(SELECT jsonb_agg(to_jsonb(txn) ORDER BY txn.id) FROM commerce_ledger_transaction txn WHERE source_id=attempt.id::text),\
  \ 'entries',(SELECT jsonb_agg(to_jsonb(entry) ORDER BY entry.id) FROM commerce_ledger_entry entry JOIN commerce_ledger_transaction txn ON txn.id=entry.transaction_id WHERE txn.source_id=attempt.id::text),\
  \ 'history',(SELECT jsonb_agg(to_jsonb(history) ORDER BY history.id) FROM commerce_payment_state_history history WHERE payment_intent_id=intent.id),\
  \ 'audit',(SELECT jsonb_agg(to_jsonb(audit) ORDER BY audit.id) FROM commerce_checkout_audit_event audit WHERE checkout_id=checkout.id)\
  \ )::text FROM commerce_payment_attempt attempt\
  \ JOIN commerce_checkout_session checkout ON checkout.id=attempt.checkout_id\
  \ JOIN commerce_payment_intent intent ON intent.id=attempt.payment_intent_id\
  \ WHERE attempt.id=?::uuid"
  [PersistText (Checkout.paymentAttemptReferenceId (Checkout.vpAttempt payment))]

hostedServiceOrderSpec :: SpecWith ConnectionPool
hostedServiceOrderSpec = describe "hosted service order reconciliation" $
  forM_ [Checkout.ProviderPlaceToPay, Checkout.ProviderPayPhone] $ \provider ->
    describe (T.unpack (Checkout.paymentProviderText provider)) $ do
      it "posts the order and one audit atomically under concurrent success/replay" $ \pool -> do
        payment <- serviceOrderFixture pool provider
        result <- parsedQuery payment Adapter.AdapterSucceeded
        let apply = runSqlPool (Reconciliation.applyQueryResult payment result "service-paid" notificationTime) pool
        concurrently (replicate 4 apply) `shouldReturn`
          replicate 4 (Right Reconciliation.ReconciliationProcessed)
        assertPaymentPosted pool payment
        rows <- runSqlPool (rawSql
          "SELECT status,payment_provider,paid_at,(SELECT count(*)\
          \ FROM service_storefront_order_status_change WHERE order_id=?::uuid AND status='paid')\
          \ FROM service_storefront_order WHERE id=?::uuid"
          (replicate 2 (PersistText (Execution.bppDomainOrderId payment)))) pool
          :: IO [(Single Text,Single Text,Single UTCTime,Single Int64)]
        rows `shouldBe` [(Single "paid",Single (Checkout.paymentProviderText provider),Single notificationTime,Single 1)]
        -- Delayed callbacks must preserve fulfillment progress and paid time.
        runSqlPool (rawExecute "UPDATE service_storefront_order SET status='in_progress' WHERE id=?::uuid"
          [PersistText (Execution.bppDomainOrderId payment)]) pool
        before <- serviceOrderSnapshot pool payment
        apply `shouldReturn` Right Reconciliation.ReconciliationProcessed
        serviceOrderSnapshot pool payment `shouldReturn` before

      it "rolls back the order, audit and payment together when the caller aborts" $ \pool -> do
        payment <- serviceOrderFixture pool provider
        result <- parsedQuery payment Adapter.AdapterSucceeded
        financial <- runSqlPool (paymentSnapshot payment) pool
        order <- serviceOrderSnapshot pool payment
        runSqlPool (do
          rawExecute "SAVEPOINT caller_service" []
          applied <- Reconciliation.applyQueryResult payment result "service-rollback" notificationTime
          liftIO (applied `shouldBe` Right Reconciliation.ReconciliationProcessed)
          rawExecute "ROLLBACK TO SAVEPOINT caller_service" []
          rawExecute "RELEASE SAVEPOINT caller_service" []) pool
        runSqlPool (paymentSnapshot payment) pool `shouldReturn` financial
        serviceOrderSnapshot pool payment `shouldReturn` order

      forM_ ["checkout_id=NULL", "price_usd_cents=12514", "status='cancelled'"] $ \damage ->
        it ("rejects inconsistent domain state without posting money: " <> T.unpack damage) $ \pool -> do
          payment <- serviceOrderFixture pool provider
          result <- parsedQuery payment Adapter.AdapterSucceeded
          runSqlPool (rawExecute ("UPDATE service_storefront_order SET " <> damage <> " WHERE id=?::uuid")
            [PersistText (Execution.bppDomainOrderId payment)]) pool
          financial <- runSqlPool (paymentSnapshot payment) pool
          order <- serviceOrderSnapshot pool payment
          runSqlPool (Reconciliation.applyQueryResult payment result "service-mismatch" notificationTime) pool
            >>= (`shouldSatisfy` isLeft)
          runSqlPool (paymentSnapshot payment) pool `shouldReturn` financial
          serviceOrderSnapshot pool payment `shouldReturn` order

serviceOrderFixture :: ConnectionPool -> Checkout.PaymentProvider -> IO Execution.BoundProviderPayment
serviceOrderFixture pool provider = do
  (creation, operation, _) <- replayFixtureForDomain "mixing_mastering" pool provider
  let checkoutId = Checkout.checkoutReferenceId (Checkout.pacCheckout creation)
  runSqlPool (rawExecute
    "INSERT INTO service_storefront_order\
    \ (id,order_number,buyer_name,buyer_email,package_id,service_kind,tier,price_usd_cents,checkout_id)\
    \ SELECT ?::uuid,?,'Synthetic buyer','synthetic@example.test',id,'Mixing','Basic',12515,?::uuid\
    \ FROM service_storefront_package ORDER BY id LIMIT 1"
    (replicate 3 (PersistText checkoutId))) pool
  bindReconciliationFixture pool creation operation (providerReference provider checkoutId)

serviceOrderSnapshot :: ConnectionPool -> Execution.BoundProviderPayment -> IO [Single Text]
serviceOrderSnapshot pool payment = runSqlPool (rawSql
  "SELECT jsonb_build_array(to_jsonb(o),(SELECT jsonb_agg(to_jsonb(h) ORDER BY h.id)\
  \ FROM service_storefront_order_status_change h WHERE h.order_id=o.id))::text\
  \ FROM service_storefront_order o WHERE o.id=?::uuid"
  [PersistText (Execution.bppDomainOrderId payment)]) pool

-- Actual adapter parsing and query application across each production domain.
-- SQL builders create accepted commercial/runtime snapshots, never paid flags.
fullDomainQuerySpec :: SpecWith ConnectionPool
fullDomainQuerySpec = describe "full-schema domain query settlement" $
  forM_ ["service_booking", "event_ticket_order", "course_registration", "domo_event_quote"] $ \domain ->
    forM_ [Checkout.ProviderPlaceToPay, Checkout.ProviderPayPhone] $ \provider ->
      it (T.unpack domain <> " settles and replays " <> show provider) $ \pool -> do
        [Single checkoutId] <- runSqlPool (rawSql "SELECT payment_test.checkout(?)::text"
          [PersistText domain]) pool
        creation <- checkoutCreation pool provider checkoutId
        let now = Checkout.pacCreatedAt creation
        (_, operation, _) <- prepareReplayCreation pool creation
        payment <- bindReconciliationFixture pool creation operation
          (providerReference provider checkoutId)
        result <- parsedQuery payment Adapter.AdapterSucceeded
        runSqlPool (Reconciliation.applyQueryResult payment result "domain-query" now) pool
          `shouldReturn` Right Reconciliation.ReconciliationProcessed
        assertPaymentPosted pool payment
        paid <- runSqlPool (paymentSnapshot payment) pool
        outcomes <- concurrently (replicate 4 (runSqlPool
          (Reconciliation.applyQueryResult payment result "domain-query-replay" now) pool))
        outcomes `shouldBe` replicate 4 (Right Reconciliation.ReconciliationProcessed)
        runSqlPool (paymentSnapshot payment) pool `shouldReturn` paid

reconciliationTransactionSpec :: SpecWith ConnectionPool
reconciliationTransactionSpec = describe "authoritative query transaction ownership" $ do
  reconciliationPipelineSpec
  forM_ [Checkout.ProviderPlaceToPay, Checkout.ProviderPayPhone] $ \provider ->
    describe (T.unpack (Checkout.paymentProviderText provider)) $ do
      it "rolls back payment, intent, ledger, receipt and audit when its caller fails" $ \pool -> do
        payment <- reconciliationFixture pool provider
        result <- parsedQuery payment Adapter.AdapterSucceeded
        snapshot <- runSqlPool (paymentSnapshot payment) pool
        failed <- try (runSqlPool (do
          applied <- Reconciliation.applyQueryResult payment result "outer-failure" notificationTime
          liftIO (applied `shouldBe` Right Reconciliation.ReconciliationProcessed)
          liftIO (throwIO (userError "synthetic caller failure"))) pool) :: IO (Either IOException ())
        failed `shouldSatisfy` isLeft
        runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot

      it "preserves the caller savepoint around closed-checkout review evidence" $ \pool -> do
        payment <- reconciliationFixture pool provider
        result <- parsedQuery payment Adapter.AdapterSucceeded
        snapshot <- runSqlPool (paymentSnapshot payment) pool
        runSqlPool (do
          rawExecute "SAVEPOINT caller_owned" []
          rawExecute "UPDATE commerce_checkout_session SET status='expired' WHERE id=?::uuid"
            [PersistText (Checkout.checkoutReferenceId (Execution.bppCheckout payment))]
          expired <- closedPaymentFinancialSnapshot payment
          applied <- Reconciliation.applyQueryResult payment result "expired-query" notificationTime
          liftIO (applied `shouldBe` Right Reconciliation.ReconciliationDeadLetter)
          closedPaymentFinancialSnapshot payment >>= liftIO . (`shouldBe` expired)
          rawExecute "ROLLBACK TO SAVEPOINT caller_owned" []
          rawExecute "RELEASE SAVEPOINT caller_owned" []
          paymentSnapshot payment >>= liftIO . (`shouldBe` snapshot)) pool
        runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot

      it "retains pre-existing row locks until the caller completes" $ \pool -> do
        payment <- reconciliationFixture pool provider
        result <- parsedQuery payment Adapter.AdapterPending
        ready <- newEmptyMVar
        checked <- newEmptyMVar
        outcomes <- concurrently
          [ runSqlPool (do
              _ <- lockOperation payment ""
              applied <- Reconciliation.applyQueryResult payment result "lock-owner" notificationTime
              liftIO (applied `shouldBe` Right Reconciliation.ReconciliationRetry)
              liftIO (putMVar ready ())
              liftIO (takeMVar checked)) pool
          , do
              takeMVar ready
              locked <- try (runSqlPool (lockOperation payment " NOWAIT") pool)
                :: IO (Either SqlError [Single Text])
              let retained = either ((== "55P03") . sqlState) (const False) locked
              putMVar checked retained
              pure retained
          ]
        outcomes `shouldBe` [True, True]

      it "serializes concurrent successes into one capture ledger, receipt and paid audit" $ \pool -> do
        payment <- reconciliationFixture pool provider
        result <- parsedQuery payment Adapter.AdapterSucceeded
        outcomes <- concurrently (replicate 4 (runSqlPool
          (Reconciliation.applyQueryResult payment result "duplicate-query" notificationTime) pool))
        outcomes `shouldBe` replicate 4 (Right Reconciliation.ReconciliationProcessed)
        assertPaymentPosted pool payment

      it "never downgrades a terminal successful operation with reordered results" $ \pool -> do
        payment <- reconciliationFixture pool provider
        succeeded <- parsedQuery payment Adapter.AdapterSucceeded
        runSqlPool (Reconciliation.applyQueryResult payment succeeded "first-success" notificationTime)
          pool `shouldReturn` Right Reconciliation.ReconciliationProcessed
        snapshot <- runSqlPool (paymentSnapshot payment) pool
        forM_ [Adapter.AdapterPending, Adapter.AdapterDeclined, Adapter.AdapterUnknown] $ \state -> do
          stale <- parsedQuery payment state
          runSqlPool (Reconciliation.applyQueryResult payment stale "stale-query" notificationTime)
            pool >>= (`shouldSatisfy` isLeft)
          runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot

      it "preserves confirmed no-charge evidence if a later success conflicts" $ \pool -> do
        payment <- reconciliationFixture pool provider
        declined <- parsedQuery payment Adapter.AdapterDeclined
        runSqlPool (Reconciliation.applyQueryResult payment declined "first-decline" notificationTime)
          pool `shouldReturn` Right Reconciliation.ReconciliationProcessed
        snapshot <- runSqlPool (paymentSnapshot payment) pool
        succeeded <- parsedQuery payment Adapter.AdapterSucceeded
        runSqlPool (Reconciliation.applyQueryResult payment succeeded "conflicting-query" notificationTime)
          pool >>= (`shouldSatisfy` isLeft)
        runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot

      it "rejects malformed typed evidence and altered bound identifiers without side effects" $ \pool -> do
        payment <- reconciliationFixture pool provider
        result <- parsedQuery payment Adapter.AdapterSucceeded
        snapshot <- runSqlPool (paymentSnapshot payment) pool
        forM_ [result { Adapter.adapterResultExternalId = "SYNTHETIC-PRIVATE" }
          , result { Adapter.adapterResultAmountMinor = Just 12514 }
          , result { Adapter.adapterResultAmountMinor = Nothing }
          , result { Adapter.adapterResultCurrency = Just "EUR" }
          , result { Adapter.adapterResultCurrency = Nothing }
          , result { Adapter.adapterResultCertainty = ProviderAmbiguous }] $ \invalid -> do
            rejected <- runSqlPool (Reconciliation.applyQueryResult payment invalid
              "invalid-evidence" notificationTime) pool
            rejected `shouldSatisfy` isLeft
            show rejected `shouldNotContain` "SYNTHETIC-PRIVATE"
        forM_ [payment { Execution.bppDomainOrderId = "SYNTHETIC-PRIVATE" }
          , payment { Execution.bppMerchantRef = "SYNTHETIC-PRIVATE" }
          , payment { Execution.bppProviderReference = "SYNTHETIC-PRIVATE" }
          , payment { Execution.bppProviderResourcePath = Just "SYNTHETIC-PRIVATE" }] $ \invalid ->
            runSqlPool (Reconciliation.applyQueryResult invalid result "invalid-binding" notificationTime)
              pool >>= (`shouldSatisfy` isLeft)
        runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot

      it "rolls back the whole transaction on a database error or thread interruption" $ \pool -> do
        payment <- reconciliationFixture pool provider
        result <- parsedQuery payment Adapter.AdapterSucceeded
        snapshot <- runSqlPool (paymentSnapshot payment) pool
        failed <- try (runSqlPool (do
          _ <- Reconciliation.applyQueryResult payment result "sql-error" notificationTime
          _ <- rawSql "SELECT 1/0" [] :: SqlPersistT IO [Single Int]
          pure ()) pool) :: IO (Either SqlError ())
        either ((`shouldBe` "22012") . sqlState) (const (expectationFailure "Expected SQL failure")) failed
        runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot
        interrupted <- try (runSqlPool (do
          _ <- Reconciliation.applyQueryResult payment result "interrupted" notificationTime
          liftIO (throwIO ThreadKilled)) pool) :: IO (Either AsyncException ())
        interrupted `shouldBe` Left ThreadKilled
        runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot

  it "keeps unknown states retryable and rolls back their exception with the caller" $ \pool -> do
    payment <- reconciliationFixture pool Checkout.ProviderPlaceToPay
    result <- parsedQuery payment Adapter.AdapterUnknown
    snapshot <- runSqlPool (paymentSnapshot payment) pool
    runSqlPool (do
      rawExecute "SAVEPOINT caller_owned" []
      applied <- Reconciliation.applyQueryResult payment result "unknown-query" notificationTime
      liftIO (applied `shouldBe` Right Reconciliation.ReconciliationRetry)
      rawExecute "ROLLBACK TO SAVEPOINT caller_owned" []
      rawExecute "RELEASE SAVEPOINT caller_owned" []) pool
    runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot

  it "applies confirmed provider cancellation atomically without creating a capture" $ \pool -> do
    payment <- reconciliationFixture pool Checkout.ProviderPlaceToPay
    result <- parsedQuery payment Adapter.AdapterCancelled
    runSqlPool (Reconciliation.applyQueryResult payment result "cancel-query" notificationTime) pool
      `shouldReturn` Right Reconciliation.ReconciliationProcessed
    rows <- runSqlPool (rawSql
      "SELECT operation.status,intent.status FROM commerce_provider_operation operation\
      \ JOIN commerce_payment_attempt attempt ON attempt.id=operation.payment_attempt_id\
      \ JOIN commerce_payment_intent intent ON intent.id=attempt.payment_intent_id\
      \ WHERE attempt.id=?::uuid" [paymentAttemptParameter payment]) pool
      :: IO [(Single Text, Single Text)]
    rows `shouldBe` [(Single "confirmed_no_charge", Single "cancelled")]

  it "rejects unsupported authorization and reversal results without changing history" $ \pool -> do
    payment <- reconciliationFixture pool Checkout.ProviderPlaceToPay
    pendingResult <- parsedQuery payment Adapter.AdapterPending
    snapshot <- runSqlPool (paymentSnapshot payment) pool
    forM_ [Adapter.AdapterAuthorized, Adapter.AdapterReversed] $ \state ->
      runSqlPool (Reconciliation.applyQueryResult payment pendingResult { Adapter.adapterResultState = state }
        "unsupported-query" notificationTime) pool >>= (`shouldSatisfy` isLeft)
    runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot

reconciliationPipelineSpec :: SpecWith ConnectionPool
reconciliationPipelineSpec = describe "persisted callback to authoritative query" $
  forM_ [Checkout.ProviderPlaceToPay, Checkout.ProviderPayPhone] $ \provider ->
    describe (T.unpack (Checkout.paymentProviderText provider)) $ do
      it "uses query status, not callback status, and records response observation time" $ \pool ->
        withNotificationEnvironment $ do
          payment <- reconciliationFixture pool provider
          payload <- reconciliationNotification pool payment
          let observedAt = addUTCTime 15 notificationTime
          calls <- newIORef (0 :: Int)
          let fetch request = do
                modifyIORef' calls (+1)
                Adapter.arOperation request `shouldBe` AdapterQuery
                Adapter.arProvider request `shouldBe` provider
                Adapter.arRetryPolicy request `shouldBe` Adapter.SafeReadRetry
                Adapter.arMethod request `shouldBe` (if provider == Checkout.ProviderPlaceToPay
                  then Adapter.AdapterPost else Adapter.AdapterGet)
                pure (Right (queryValue payment Adapter.AdapterSucceeded))
          outcome <- Reconciliation.processProviderEventWith fetch (pure observedAt)
            (Env pool (error "Synthetic reconciliation must not use AppConfig")) payload notificationTime
          Reconciliation.prrDisposition outcome `shouldBe` Reconciliation.ReconciliationProcessed
          readIORef calls `shouldReturn` 1
          assertPaymentPosted pool payment
          rows <- runSqlPool (rawSql "SELECT paid_at FROM commerce_checkout_session WHERE id=?::uuid"
            [PersistText (Checkout.checkoutReferenceId (Execution.bppCheckout payment))]) pool
            :: IO [Single (Maybe UTCTime)]
          rows `shouldBe` [Single (Just observedAt)]

      it "keeps a timed-out query ambiguous and redacts transport details" $ \pool ->
        withNotificationEnvironment $ do
          payment <- reconciliationFixture pool provider
          payload <- reconciliationNotification pool payment
          snapshot <- runSqlPool (paymentSnapshot payment) pool
          calls <- newIORef (0 :: Int)
          outcome <- Reconciliation.processProviderEventWith
            (\_ -> modifyIORef' calls (+1) >> pure (Left
              (ProviderHttp.AdapterTransportError "SYNTHETIC-PRIVATE timeout"))) getCurrentTime
            (Env pool (error "Synthetic reconciliation must not use AppConfig")) payload notificationTime
          Reconciliation.prrDisposition outcome `shouldBe` Reconciliation.ReconciliationRetry
          show outcome `shouldNotContain` "SYNTHETIC-PRIVATE"
          readIORef calls `shouldReturn` 1
          runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot

      it "dead-letters mismatched query money and records a redacted reconciliation exception" $ \pool ->
        withNotificationEnvironment $ do
          payment <- reconciliationFixture pool provider
          payload <- reconciliationNotification pool payment
          outcome <- Reconciliation.processProviderEventWith
            (\_ -> pure (Right (queryValue payment { Execution.bppAmountMinor = 1 }
              Adapter.AdapterSucceeded))) getCurrentTime
            (Env pool (error "Synthetic reconciliation must not use AppConfig")) payload notificationTime
          Reconciliation.prrDisposition outcome `shouldBe` Reconciliation.ReconciliationDeadLetter
          rows <- runSqlPool (rawSql
            "SELECT checkout.status,operation.status,\
            \ (SELECT count(*) FROM commerce_reconciliation_exception WHERE internal_reference=checkout.id::text\
            \   AND exception_type='provider_query_binding_mismatch' AND status='open'),\
            \ (SELECT count(*) FROM commerce_ledger_transaction WHERE source_id=attempt.id::text)\
            \ FROM commerce_payment_attempt attempt\
            \ JOIN commerce_provider_operation operation ON operation.payment_attempt_id=attempt.id\
            \ JOIN commerce_checkout_session checkout ON checkout.id=attempt.checkout_id WHERE attempt.id=?::uuid"
            [paymentAttemptParameter payment]) pool :: IO [(Single Text, Single Text, Single Int64, Single Int64)]
          rows `shouldBe` [(Single (if provider == Checkout.ProviderPlaceToPay then "awaiting_payment" else "processing"), Single (if provider == Checkout.ProviderPlaceToPay
            then "requires_customer_action" else "processing"), Single 1, Single 0)]

      it "rejects tampered stored callback trust before invoking the query transport" $ \pool ->
        withNotificationEnvironment $ do
          payment <- reconciliationFixture pool provider
          payload <- reconciliationNotification pool payment
          snapshot <- runSqlPool (paymentSnapshot payment) pool
          forM_ [payload { Event.pepSignatureVerified = not (Event.pepSignatureVerified payload) }
            , payload { Event.pepEvidenceType = "SYNTHETIC-PRIVATE" }
            , payload { Event.pepProviderResourceId = Just "different-resource" }
            , payload { Event.pepRawPayload = "{\"SYNTHETIC-PRIVATE\":" }] $ \tampered -> do
              outcome <- Reconciliation.processProviderEventWith
                (\_ -> fail "Invalid callback must not reach a remote query") getCurrentTime
                (Env pool (error "Synthetic reconciliation must not use AppConfig")) tampered notificationTime
              Reconciliation.prrDisposition outcome `shouldBe` Reconciliation.ReconciliationDeadLetter
              show outcome `shouldNotContain` "SYNTHETIC-PRIVATE"
          runSqlPool (paymentSnapshot payment) pool `shouldReturn` snapshot

reconciliationNotification :: ConnectionPool -> Execution.BoundProviderPayment -> IO Event.ProviderEventPayload
reconciliationNotification pool payment = do
  resetQueryBudget pool (Execution.bppProvider payment)
  creation <- newNotification (Execution.bppProvider payment)
  let resource = read (T.unpack (Execution.bppProviderResourceId payment)) :: Int64
      -- Intentionally report failure in the callback; only the subsequent
      -- authenticated query is allowed to establish the financial outcome.
      raw = if Execution.bppProvider payment == Checkout.ProviderPlaceToPay
        then signedPlaceToPayNotification resource "REJECTED" "2026-09-14T12:00:00Z" "synthetic-secret" ""
        else encodeStrict (A.object ["TransactionId" A..= resource
          , "ClientTransactionId" A..= Execution.bppProviderReference payment
          , "StoreId" A..= ("synthetic-store" :: Text), "StatusCode" A..= (2 :: Int)])
  stored <- storeNotification pool creation
    { Event.pecMerchantRef = Execution.bppMerchantRef payment
    , Event.pecProviderResource = Just (Execution.bppProviderResourceId payment)
    , Event.pecRawPayload = raw } >>= requireRight
  claim <- runSqlPool (Event.claimProviderEvent (Event.pesReference stored) notificationTime) pool
  claim `shouldBe` Event.ProviderEventClaimed 1
  runSqlPool (Event.loadProviderEventPayload (Event.pesReference stored) recoveryEncryptionKey)
    pool >>= requireRight

reconciliationFixture :: ConnectionPool -> Checkout.PaymentProvider -> IO Execution.BoundProviderPayment
reconciliationFixture = reconciliationFixtureWithMerchant "synthetic-provider-retry-merchant"

reconciliationFixtureWithMerchant
  :: Text -> ConnectionPool -> Checkout.PaymentProvider -> IO Execution.BoundProviderPayment
reconciliationFixtureWithMerchant merchant pool provider = do
  -- Exercise TDF service revenue, not a ticket order without its fee/seat
  -- snapshot. Ticket fulfillment is covered by its separate runtime harness.
  (creation, operation, _) <- replayFixtureWithMerchant "service_booking" merchant pool provider
  bindReconciliationFixture pool creation operation
    (providerReference provider (Checkout.checkoutReferenceId (Checkout.pacCheckout creation)))

bindReconciliationFixture
  :: ConnectionPool -> Checkout.PaymentAttemptCreation -> Execution.ProviderOperationRecord
  -> Text -> IO Execution.BoundProviderPayment
bindReconciliationFixture pool creation operation reference = do
  let checkoutId = Checkout.checkoutReferenceId (Checkout.pacCheckout creation)
      attempt = Execution.porAttempt operation
      provider = Checkout.pacProvider creation
      state = if provider == Checkout.ProviderPlaceToPay
        then Adapter.AdapterRequiresCustomerAction else Adapter.AdapterPending
  resourceUuid <- toText <$> nextRandom
  resource <- case readHex (T.unpack (T.take 12 (T.filter (/= '-') resourceUuid))) of
    [(number, "")] -> pure (T.pack (show (number + 1 :: Int64)))
    _ -> fail "Expected synthetic numeric provider resource"
  checkout <- runSqlPool (Execution.loadAuthorizedCheckout checkoutId (digestText checkoutId)
    (Checkout.pacCreatedAt creation)) pool >>= requireRight
  _ <- runSqlPool (Execution.claimProviderOperation (Execution.porReference operation)
    (Checkout.pacCreatedAt creation) recoveryEncryptionKey) pool >>= requireRight
  _ <- runSqlPool (Execution.recordCreateResult (Execution.porReference operation) checkout attempt
    provider (Checkout.pacMerchantRef creation) reference recoveryEncryptionKey
    (Adapter.AdapterResult state resource Nothing Nothing Nothing ProviderAmbiguous)
    "synthetic-query-binding" (Checkout.pacCreatedAt creation)) pool >>= requireRight
  runSqlPool (Execution.loadBoundProviderPayment provider Checkout.CheckoutSandbox
    (Checkout.pacMerchantRef creation) resource (Just reference)) pool >>= requireRight

parsedQuery :: Execution.BoundProviderPayment -> Adapter.AdapterResultState -> IO Adapter.AdapterResult
parsedQuery payment state = do
  adapter <- if Execution.bppProvider payment == Checkout.ProviderPlaceToPay
    then requireRight (PlaceToPay.placeToPayAdapter notificationConfig)
    else requireRight (PayPhone.payPhoneAdapter (PayPhone.PayPhoneConfig "synthetic-token" "synthetic-store"))
  requireRight (Adapter.adapterParseResponse adapter AdapterQuery
    (Adapter.PaymentLocator (Execution.bppProviderResourceId payment)
      (Adapter.ExpectedPayment (Execution.bppProviderReference payment)
        (Execution.bppAmountMinor payment) (Execution.bppCurrency payment)))
    (queryValue payment state))

queryValue :: Execution.BoundProviderPayment -> Adapter.AdapterResultState -> A.Value
queryValue payment state
  | Execution.bppProvider payment == Checkout.ProviderPlaceToPay = A.object
      [ "requestId" A..= resource, "status" A..= status
      , "request" A..= A.object ["payment" A..= A.object
          ["reference" A..= reference, "amount" A..= amount]]
      , "payment" A..= if state == Adapter.AdapterSucceeded then
          [A.object ["status" A..= status, "refunded" A..= False
            , "internalReference" A..= (1 :: Int), "reference" A..= reference
            , "amount" A..= A.object ["from" A..= amount, "to" A..= amount]]]
          else ([] :: [A.Value]) ]
  | otherwise = A.object
      ["transactionId" A..= resource, "clientTransactionId" A..= reference
      , "amount" A..= Execution.bppAmountMinor payment, "currency" A..= Execution.bppCurrency payment
      , "statusCode" A..= (case state of
          Adapter.AdapterSucceeded -> 3; Adapter.AdapterDeclined -> 2; Adapter.AdapterCancelled -> 2
          Adapter.AdapterPending -> 1; _ -> 99 :: Int)]
  where
    resource = read (T.unpack (Execution.bppProviderResourceId payment)) :: Int64
    reference = Execution.bppProviderReference payment
    amount = A.object ["currency" A..= Execution.bppCurrency payment
      , "total" A..= Adapter.minorToDecimal (Execution.bppAmountMinor payment)]
    status = A.object ["status" A..= (case state of
      Adapter.AdapterSucceeded -> "APPROVED"; Adapter.AdapterDeclined -> "REJECTED"
      Adapter.AdapterCancelled -> "CANCELLED"; Adapter.AdapterPending -> "PENDING"
      _ -> "UNKNOWN" :: Text)]

paymentAttemptParameter :: Execution.BoundProviderPayment -> PersistValue
paymentAttemptParameter = PersistText . Checkout.paymentAttemptReferenceId . Execution.bppAttempt

lockOperation :: Execution.BoundProviderPayment -> Text -> SqlPersistT IO [Single Text]
lockOperation payment lockSuffix = rawSql
  ("SELECT id::text FROM commerce_provider_operation WHERE payment_attempt_id=?::uuid FOR UPDATE" <> lockSuffix)
  [paymentAttemptParameter payment]

paymentSnapshot :: Execution.BoundProviderPayment -> SqlPersistT IO [Single Text]
paymentSnapshot payment = rawSql
  "SELECT jsonb_build_object(\
  \ 'operation',jsonb_build_array(operation.status,operation.outcome_certainty,operation.updated_at,operation.completed_at),\
  \ 'checkout',jsonb_build_array(checkout.status,checkout.paid_minor,checkout.paid_at,checkout.updated_at),\
  \ 'attempt',jsonb_build_array(attempt.status,attempt.updated_at,attempt.failure_code,attempt.failure_summary),\
  \ 'intent',jsonb_build_array(intent.status,intent.authorized_minor,intent.captured_minor,intent.updated_at),\
  \ 'ledger',(SELECT count(*) FROM commerce_ledger_transaction WHERE source_id=attempt.id::text),\
  \ 'entries',(SELECT count(*) FROM commerce_ledger_entry entry JOIN commerce_ledger_transaction txn\
  \   ON txn.id=entry.transaction_id WHERE txn.source_id=attempt.id::text),\
  \ 'receipts',(SELECT count(*) FROM commerce_receipt WHERE checkout_id=checkout.id),\
  \ 'history',(SELECT count(*) FROM commerce_payment_state_history WHERE payment_intent_id=intent.id),\
  \ 'audit',(SELECT count(*) FROM commerce_checkout_audit_event WHERE checkout_id=checkout.id),\
  \ 'exceptions',(SELECT count(*) FROM commerce_reconciliation_exception WHERE internal_reference=checkout.id::text)\
  \ )::text FROM commerce_provider_operation operation\
  \ JOIN commerce_payment_attempt attempt ON attempt.id=operation.payment_attempt_id\
  \ JOIN commerce_checkout_session checkout ON checkout.id=attempt.checkout_id\
  \ JOIN commerce_payment_intent intent ON intent.id=attempt.payment_intent_id\
  \ WHERE attempt.id=?::uuid"
  [paymentAttemptParameter payment]

assertPaymentPosted :: ConnectionPool -> Execution.BoundProviderPayment -> Expectation
assertPaymentPosted pool payment = do
  rows <- runSqlPool (rawSql
    "SELECT checkout.status,attempt.status,intent.status,checkout.paid_minor,\
    \ (SELECT count(*) FROM commerce_ledger_transaction WHERE source_id=attempt.id::text AND status='posted'),\
    \ (SELECT count(*) FROM commerce_receipt WHERE checkout_id=checkout.id AND kind='payment_receipt'),\
    \ (SELECT count(*) FROM commerce_checkout_audit_event WHERE checkout_id=checkout.id AND event_type='payment_verified')\
    \ FROM commerce_payment_attempt attempt\
    \ JOIN commerce_checkout_session checkout ON checkout.id=attempt.checkout_id\
    \ JOIN commerce_payment_intent intent ON intent.id=attempt.payment_intent_id WHERE attempt.id=?::uuid"
    [paymentAttemptParameter payment]) pool
    :: IO [(Single Text, Single Text, Single Text, Single Int64, Single Int64, Single Int64, Single Int64)]
  rows `shouldBe` [(Single "paid", Single "succeeded", Single "captured", Single (Execution.bppAmountMinor payment), Single 1, Single 1, Single 1)]

digestText :: Text -> Text
digestText value = TE.decodeUtf8
  (BAE.convertToBase BAE.Base16 (hash (TE.encodeUtf8 value) :: Digest SHA256))

replayFixture :: ConnectionPool -> Checkout.PaymentProvider
  -> IO (Checkout.PaymentAttemptCreation, Execution.ProviderOperationRecord, PaymentSessionCreateDTO)
replayFixture = replayFixtureForDomain "event_ticket_order"

replayFixtureForDomain :: Text -> ConnectionPool -> Checkout.PaymentProvider
  -> IO (Checkout.PaymentAttemptCreation, Execution.ProviderOperationRecord, PaymentSessionCreateDTO)
replayFixtureForDomain domain = replayFixtureWithMerchant domain "synthetic-provider-retry-merchant"

replayFixtureWithMerchant :: Text -> Text -> ConnectionPool -> Checkout.PaymentProvider
  -> IO (Checkout.PaymentAttemptCreation, Execution.ProviderOperationRecord, PaymentSessionCreateDTO)
replayFixtureWithMerchant domain merchant pool provider = do
  seed <- newCheckoutForDomain domain pool
  prepareReplayCreation pool (seed { Checkout.pacProvider = provider, Checkout.pacMerchantRef = merchant })

checkoutCreation :: ConnectionPool -> Checkout.PaymentProvider -> Text -> IO Checkout.PaymentAttemptCreation
checkoutCreation pool provider checkoutId = do
  [Single amount] <- runSqlPool (rawSql
    "SELECT total_minor FROM commerce_checkout_session WHERE id=?::uuid" [PersistText checkoutId]) pool
  now <- getCurrentTime
  pure Checkout.PaymentAttemptCreation
    { Checkout.pacCheckout = Checkout.CheckoutReference checkoutId
    , Checkout.pacProvider = provider
    , Checkout.pacEnvironment = Checkout.CheckoutSandbox
    , Checkout.pacOperation = Checkout.OperationCreate
    , Checkout.pacAmountMinor = amount
    , Checkout.pacCurrency = "USD"
    , Checkout.pacMerchantRef = "synthetic-provider-retry-merchant"
    , Checkout.pacIdempotencyKey = "attempt-" <> checkoutId
    , Checkout.pacCreatedAt = now
    , Checkout.pacCorrelationId = "provider-fixture-" <> checkoutId
    }

prepareReplayCreation :: ConnectionPool -> Checkout.PaymentAttemptCreation
  -> IO (Checkout.PaymentAttemptCreation, Execution.ProviderOperationRecord, PaymentSessionCreateDTO)
prepareReplayCreation pool creation = do
  let provider = Checkout.pacProvider creation
      checkoutId = Checkout.checkoutReferenceId (Checkout.pacCheckout creation)
      method = if provider == Checkout.ProviderPayPhone then MethodPayPhoneWallet else MethodCard
      phone = if provider == Checkout.ProviderPayPhone then Just "991234567" else Nothing
      country = if provider == Checkout.ProviderPayPhone then Just "593" else Nothing
      request = PaymentSessionCreateDTO (Checkout.paymentProviderText provider)
        (if provider == Checkout.ProviderPayPhone then "payphone_wallet" else "card") phone country
      -- Exercise pre-upgrade checkout-derived references, not only new UUID refs.
      reference = providerReference provider checkoutId
  runSqlPool (rawExecute
    "UPDATE commerce_checkout_session SET lookup_token_hash=? WHERE id=?::uuid"
    [PersistText (digestText checkoutId), PersistText checkoutId]) pool
  attempt <- runSqlPool (Runtime.beginPaymentAttemptForMethod method creation) pool >>= requireRight
  operation <- runSqlPool (Execution.prepareProviderOperation Execution.ProviderOperationPreparation
    { Execution.popAttempt = attempt, Execution.popProvider = provider
    , Execution.popEnvironment = Checkout.CheckoutSandbox
    , Execution.popMerchantRef = Checkout.pacMerchantRef creation
    , Execution.popProviderReference = reference, Execution.popOperation = AdapterCreate
    , Execution.popIdempotencyKey = Checkout.pacIdempotencyKey creation
    -- Reconstruct the OLD persisted byte format independently of the new helper.
    , Execution.popRequestSha256 = digestText (T.intercalate "|"
        [checkoutId, Checkout.paymentProviderText provider, pscPaymentMethod request
        , pscPaymentMethod request, reference, T.pack (show (Checkout.pacAmountMinor creation)), "USD"
        , maybe "" id phone, maybe "" id country])
    , Execution.popOccurredAt = Checkout.pacCreatedAt creation
    }) pool >>= requireRight
  pure (creation, operation, request)

closeCheckout :: ConnectionPool -> Checkout.PaymentAttemptCreation -> Text -> IO ()
closeCheckout pool creation status = do
  -- Paid/settled recovery states require the same bound query evidence as a
  -- real checkout; no direct unverified paid fixture is allowed.
  when (status `elem` ["paid", "refunded", "disputed"]) $ do
    let checkoutId = Checkout.checkoutReferenceId (Checkout.pacCheckout creation)
    [Single attemptId] <- runSqlPool (rawSql
      "SELECT id::text FROM commerce_payment_attempt WHERE checkout_id=?::uuid"
      [PersistText checkoutId]) pool
    operation <- runSqlPool (Execution.loadAuthorizedCreateOperation checkoutId attemptId
      (digestText checkoutId) recoveryEncryptionKey) pool >>= requireRight
    payment <- bindReconciliationFixture pool creation operation
      (providerReference (Checkout.pacProvider creation) checkoutId)
    result <- parsedQuery payment Adapter.AdapterSucceeded
    runSqlPool (Reconciliation.applyQueryResult payment result "fixture-paid" notificationTime)
      pool `shouldReturn` Right Reconciliation.ReconciliationProcessed
  runSqlPool (rawExecute
    "UPDATE commerce_checkout_session SET status=?,expires_at=NOW()-INTERVAL '1 hour'\
    \ WHERE id=?::uuid"
    [PersistText status, PersistText (Checkout.checkoutReferenceId (Checkout.pacCheckout creation))]) pool

-- Synthetic stored provider outcomes, not remote sandbox results.
setOperationState :: ConnectionPool -> Execution.ProviderOperationRecord -> Text -> Text -> IO ()
setOperationState pool operation status certainty = runSqlPool (rawExecute
  "UPDATE commerce_provider_operation SET status=?,outcome_certainty=?,started_at=NOW(),\
  \ provider_resource_id=COALESCE(provider_resource_id,'synthetic-recovery'),redirect_url_ciphertext=pgp_sym_encrypt(?,?)\
  \ WHERE id=?::uuid"
  [PersistText status, PersistText certainty
  , PersistText "https://checkout-test.placetopay.ec/session/synthetic-recovery"
  , PersistText recoveryEncryptionKey
  , PersistText (Execution.providerOperationReferenceId (Execution.porReference operation))]) pool

replayHandler :: ConnectionPool -> Checkout.PaymentAttemptCreation -> PaymentSessionCreateDTO
  -> IO (Either ServerError PaymentSessionDTO)
replayHandler pool creation request = do
  let create :<|> _ = providerExecutionServer
      checkoutId = Checkout.checkoutReferenceId (Checkout.pacCheckout creation)
      env = Env pool (error "Recovery must not use AppConfig")
  runHandler (runReaderT (create checkoutId (Just checkoutId)
    (Just (Checkout.pacIdempotencyKey creation)) (Just "Synthetic provider recovery test")
    (SockAddrInet 0 0) request) env)

assertHttpError :: Int -> Either ServerError PaymentSessionDTO -> Expectation
assertHttpError status = either ((`shouldBe` status) . errHTTPCode)
  (const (expectationFailure "Expected payment recovery to fail closed"))

-- Exercise the upstream completion-capability repair against the later durable
-- intent/replay implementation. All configuration is synthetic; no HTTP occurs.
completionCapabilityIntegrationSpec :: SpecWith ConnectionPool
completionCapabilityIntegrationSpec = describe "complete checkout capability integration" $ do
  it "continues Datafast debit verification without inventing a separate capture capability" $ \pool -> do
    (creation, origin) <- completionOrigin pool Checkout.ProviderDatafast
    capabilityCount <- runSqlPool (rawSql
      "SELECT COUNT(*) FROM commerce_provider_capability capability\
      \ JOIN commerce_provider_account account ON account.id=capability.provider_account_id\
      \ WHERE account.provider='datafast' AND account.environment='sandbox'\
      \ AND capability.capability='capture'" []) pool :: IO [Single Int64]
    capabilityCount `shouldBe` [Single 0]
    let capture = creation { Checkout.pacOperation = Checkout.OperationCapture
          , Checkout.pacIdempotencyKey = Checkout.pacIdempotencyKey creation <> "-verify" }
        start value = runSqlPool (Runtime.beginPaymentAttempt value) pool
    confirmed <- start capture >>= requireRight
    originalIntent <- intentFor pool origin
    intentFor pool confirmed `shouldReturn` originalIntent
    start capture `shouldReturn` Right confirmed
    start capture { Checkout.pacIdempotencyKey = Checkout.pacIdempotencyKey capture <> "-other" }
      >>= (`shouldSatisfy` isLeft)
    assertCounts pool creation 2 1

  forM_ [(Checkout.ProviderDatafast, MethodCard, "server_verification"),
         (Checkout.ProviderPayPal, MethodPayPalWallet, "capture")] $ \(provider, method, capability) -> do
    it ("rejects an unqualified continuation without orphaning the original " <> show provider) $ \pool -> do
      (creation, origin) <- completionOrigin pool provider
      originalIntent <- intentFor pool origin
      let capture = creation { Checkout.pacOperation = Checkout.OperationCapture
            , Checkout.pacIdempotencyKey = Checkout.pacIdempotencyKey creation <> "-capture" }
      withDocumentedCapability pool provider method capability $ do
        runSqlPool (Runtime.beginPaymentAttempt capture) pool >>= (`shouldSatisfy` isLeft)
        intentFor pool origin `shouldReturn` originalIntent
        assertCounts pool creation 1 1
      continued <- runSqlPool (Runtime.beginPaymentAttempt capture) pool >>= requireRight
      intentFor pool continued `shouldReturn` originalIntent
      assertCounts pool creation 2 1

    it ("requires completion evidence even with an empty public capability request for " <> show provider) $ \pool ->
      withCompletionEnvironment $ do
        let request = completionRequest method
            includes request' = elem provider <$> completionRoutes pool request'
        includes request `shouldReturn` True
        withDocumentedCapability pool provider method capability $
          includes request `shouldReturn` False
        includes request `shouldReturn` True
        includes request { Capabilities.prEnvironment = Checkout.CheckoutProduction } `shouldReturn` False
        let merchantCredential = if provider == Checkout.ProviderDatafast
              then "DATAFAST_ENTITY_ID" else "PAYPAL_MERCHANT_ID"
        setEnv merchantCredential "synthetic-wrong-merchant"
        includes request `shouldReturn` False
        setEnv merchantCredential "synthetic-provider-retry-merchant"
        includes request `shouldReturn` True
        let credential = if provider == Checkout.ProviderDatafast
              then "DATAFAST_BEARER_TOKEN" else "PAYPAL_CLIENT_SECRET"
        setEnv credential ""
        includes request `shouldReturn` False

  it "retains every marketplace completion gate at the database-backed public boundary" $ \pool ->
    withCompletionEnvironment $ do
      let request = (completionRequest MethodPayPalWallet)
            { Capabilities.prFlow = Capabilities.FlowMarketplace }
          offered = elem Checkout.ProviderPayPal <$> completionRoutes pool request
      offered `shouldReturn` True
      forM_ ["connected_accounts", "split_settlement", "seller_payouts"] $ \capability ->
        withDocumentedCapability pool Checkout.ProviderPayPal MethodPayPalWallet capability $
          offered `shouldReturn` False
      offered `shouldReturn` True

  forM_ [(Checkout.ProviderPlaceToPay, MethodBankRedirect),
         (Checkout.ProviderPlaceToPay, MethodDeunaQr),
         (Checkout.ProviderPayPhone, MethodPayPhoneWallet)] $ \(provider, method) ->
    it ("requires verified status lookup for query-backed method " <> show method) $ \pool ->
      withNotificationEnvironment $ do
        setEnv "PLACETOPAY_BANK_PAYMENT_METHODS" "synthetic_bank"
        setEnv "PLACETOPAY_DEUNA_PAYMENT_METHODS" "synthetic_deuna"
        let offered = elem provider <$> completionRoutes pool (completionRequest method)
        offered `shouldReturn` True
        withDocumentedCapability pool provider method "server_verification" $
          offered `shouldReturn` False
        offered `shouldReturn` True

completionRequest :: PaymentMethod -> Capabilities.PaymentRouteRequest
completionRequest method = Capabilities.PaymentRouteRequest
  { Capabilities.prEnvironment = Checkout.CheckoutSandbox
  , Capabilities.prBuyerCountry = "EC", Capabilities.prCurrency = "USD"
  , Capabilities.prAmountMinor = 12515, Capabilities.prMethod = method
  , Capabilities.prFlow = Capabilities.FlowEventTicket
  , Capabilities.prRequiredCapabilities = []
  }

completionRoutes :: ConnectionPool -> Capabilities.PaymentRouteRequest -> IO [Checkout.PaymentProvider]
completionRoutes pool request = do
  result <- runHandler (runReaderT (Availability.loadRuntimeReadyRoutes request) (queryEnv pool))
  map Capabilities.routeProvider <$> either (const (fail "Synthetic availability request failed")) pure result

completionOrigin :: ConnectionPool -> Checkout.PaymentProvider
  -> IO (Checkout.PaymentAttemptCreation, Checkout.PaymentAttemptReference)
completionOrigin pool provider = do
  seed <- newCheckout pool
  let creation = seed { Checkout.pacProvider = provider }
  origin <- runSqlPool (Runtime.beginPaymentAttempt creation) pool >>= requireRight
  now <- getCurrentTime
  _ <- runSqlPool (Checkout.bindProviderResource Checkout.ProviderBindingCreation
    { Checkout.pbcAttempt = origin, Checkout.pbcCheckout = Checkout.pacCheckout creation
    , Checkout.pbcProvider = provider, Checkout.pbcEnvironment = Checkout.CheckoutSandbox
    , Checkout.pbcMerchantRef = Checkout.pacMerchantRef creation
    , Checkout.pbcResourceType = if provider == Checkout.ProviderDatafast then "checkout" else "order"
    , Checkout.pbcProviderResource = "synthetic-" <> Checkout.paymentAttemptReferenceId origin
    , Checkout.pbcResourcePath = Nothing
    , Checkout.pbcOrderReference = Checkout.checkoutReferenceId (Checkout.pacCheckout creation)
    , Checkout.pbcAmountMinor = Checkout.pacAmountMinor creation, Checkout.pbcCurrency = "USD"
    , Checkout.pbcStage = Checkout.AttemptRequiresCustomerAction
    , Checkout.pbcOccurredAt = now, Checkout.pbcCorrelationId = "synthetic-completion-integration"
    }) pool >>= requireRight
  pure (creation, origin)

withDocumentedCapability :: ConnectionPool -> Checkout.PaymentProvider -> PaymentMethod -> Text -> IO a -> IO a
withDocumentedCapability pool provider method capability action = bracket
  (change "documented") (const (change "sandbox_verified")) (const action)
  where
    change status = runSqlPool (rawExecute
      "UPDATE commerce_provider_capability capability SET verification_status=?\
      \ FROM commerce_provider_account account WHERE account.id=capability.provider_account_id\
      \ AND account.provider=? AND account.environment='sandbox'\
      \ AND capability.payment_method=? AND capability.capability=?"
      [ PersistText status, PersistText (Checkout.paymentProviderText provider)
      , PersistText (Capabilities.paymentMethodText method), PersistText capability ]) pool

withCompletionEnvironment :: IO a -> IO a
withCompletionEnvironment action = bracket
  (forM values $ \(name, _) -> (,) name <$> lookupEnv name)
  (mapM_ (\(name, value) -> maybe (unsetEnv name) (setEnv name) value)) $ \_ -> do
    forM_ values (uncurry setEnv)
    action
  where
    values =
      [("DATAFAST_ENV", "sandbox"), ("DATAFAST_ENTITY_ID", "synthetic-provider-retry-merchant")
      , ("DATAFAST_BEARER_TOKEN", "synthetic-token"), ("DATAFAST_BASE_URL", "https://test.oppwa.com")
      , ("DATAFAST_TEST_MODE", "EXTERNAL"), ("PAYPAL_ENV", "sandbox")
      , ("PAYPAL_MERCHANT_ID", "synthetic-provider-retry-merchant"), ("PAYPAL_CLIENT_ID", "synthetic-client")
      , ("PAYPAL_CLIENT_SECRET", "synthetic-secret"), ("PAYPAL_WEBHOOK_ID", "synthetic-webhook")
      , ("COMMERCE_EVENT_ENCRYPTION_KEY", T.unpack recoveryEncryptionKey)]

openDatabase :: String -> IO ConnectionPool
openDatabase url = do
  pool <- runNoLoggingT (createPostgresqlPool (BS.pack url) 4)
  names <- runSqlPool (rawSql "SELECT current_database()" []) pool :: IO [Single Text]
  unless (names == [Single "tdf_provider_retry_test"]) $ do
    destroyAllResources pool
    fail "Provider retry tests require the dedicated disposable database"
  runSqlPool (do
    rawExecute
      "UPDATE commerce_provider_account SET status='ready',contract_status='approved',\
      \ credential_status='validated',enabled=true,verified_at=NOW(),verified_by=1,\
      \ merchant_account_ref='synthetic-provider-retry-merchant' WHERE environment='sandbox'" []
    rawExecute
      "UPDATE commerce_provider_capability SET verification_status='sandbox_verified',verified_at=NOW()\
      \ WHERE provider_account_id IN (SELECT id FROM commerce_provider_account WHERE environment='sandbox')" []
    ) pool
  pure pool

newCheckout :: ConnectionPool -> IO Checkout.PaymentAttemptCreation
newCheckout = newCheckoutForDomain "event_ticket_order"

newCheckoutForDomain :: Text -> ConnectionPool -> IO Checkout.PaymentAttemptCreation
newCheckoutForDomain domain = newCheckoutForDomainWithLines domain [12515]

-- Construct the immutable checkout snapshot once, before any payment attempt.
-- Refund fixtures may split its fixed total, but cannot append a second snapshot.
newCheckoutForDomainWithLines :: Text -> [Int64] -> ConnectionPool -> IO Checkout.PaymentAttemptCreation
newCheckoutForDomainWithLines domain amounts = newCheckoutWithOrder domain amounts Nothing

newCheckoutWithOrder :: Text -> [Int64] -> Maybe Text -> ConnectionPool -> IO Checkout.PaymentAttemptCreation
newCheckoutWithOrder domain amounts domainOrder pool = do
  unless (all (> 0) amounts && sum (map toInteger amounts) == 12515) $
    fail "Synthetic checkout lines must sum exactly to 12515"
  checkoutId <- toText <$> nextRandom
  now <- getCurrentTime
  runSqlPool (do
    orderReference <- case (domain, domainOrder) of
      ("event_ticket_order", Nothing) -> do
        [Single orderKey] <- rawSql "SELECT payment_test.ticket_order()" []
        pure (T.pack (show (orderKey :: Int64)))
      _ -> pure (maybe checkoutId id domainOrder)
    gross <- if domain == "event_ticket_order"
      then do
        [Single value] <- rawSql
          "SELECT tier.price_cents*orders.quantity FROM event_ticket_order orders\
          \ JOIN event_ticket_tier tier ON tier.id=orders.tier_id WHERE orders.id=?::bigint"
          [PersistText orderReference]
        pure value
      else pure (12515 :: Int64)
    rawExecute
      "INSERT INTO commerce_checkout_session(id,domain_type,domain_order_id,status,environment,\
    \ currency,subtotal_minor,discount_minor,total_minor,customer_email,lookup_token_hash,idempotency_key,expires_at)\
    \ VALUES (?::uuid,?,?,'awaiting_payment','sandbox','USD',?,?,12515,\
    \ 'synthetic@example.test',?,?,?)"
      [PersistText checkoutId, PersistText domain, PersistText orderReference, PersistInt64 gross, PersistInt64 (gross-12515),
        PersistText checkoutId, PersistText checkoutId, PersistUTCTime (addUTCTime 1800 now)]
    forM_ (zip [1..] amounts) $ \(lineNumber, amount) -> rawExecute
      "INSERT INTO commerce_checkout_line_item(checkout_id,line_number,product_type,product_id,\
      \ product_version,description,quantity,unit_amount_minor,subtotal_minor,discount_minor,total_minor,snapshot)\
      \ VALUES (?::uuid,?,?,?,'synthetic-v1','Provider retry fixture',1,?,?,?,?,'{}'::jsonb)"
      ([PersistText checkoutId, PersistInt64 lineNumber, PersistText domain, PersistText checkoutId]
        <> [PersistInt64 (if domain == "event_ticket_order" then gross else amount),
            PersistInt64 (if domain == "event_ticket_order" then gross else amount),
            PersistInt64 (if domain == "event_ticket_order" then gross-amount else 0),PersistInt64 amount])
    when (domain == "event_ticket_order" && domainOrder == Nothing) $
      attachTicketRuntime checkoutId orderReference 0 0
    ) pool
  pure Checkout.PaymentAttemptCreation
    { Checkout.pacCheckout = Checkout.CheckoutReference checkoutId
    , Checkout.pacProvider = Checkout.ProviderPlaceToPay
    , Checkout.pacEnvironment = Checkout.CheckoutSandbox
    , Checkout.pacOperation = Checkout.OperationCreate
    , Checkout.pacAmountMinor = 12515
    , Checkout.pacCurrency = "USD"
    , Checkout.pacMerchantRef = "synthetic-provider-retry-merchant"
    , Checkout.pacIdempotencyKey = "attempt-" <> checkoutId
    , Checkout.pacCreatedAt = now
    , Checkout.pacCorrelationId = "provider-retry-test-" <> checkoutId
    }

attachTicketRuntime :: Text -> Text -> Int64 -> Int64 -> SqlPersistT IO ()
attachTicketRuntime checkoutId orderReference fee tax = do
  attached <- rawSql
    "SELECT 1::bigint FROM payment_test.ticket_runtime(?::uuid,?::bigint,?,?)"
    [PersistText checkoutId,PersistText orderReference,PersistInt64 fee,PersistInt64 tax]
    :: SqlPersistT IO [Single Int64]
  unless (attached == [Single 1]) $ liftIO (fail "Ticket runtime fixture was not attached")

begin :: ConnectionPool -> Checkout.PaymentAttemptCreation
  -> IO (Either Text Checkout.PaymentAttemptReference)
begin pool creation = runSqlPool (Runtime.beginPaymentAttemptForMethod MethodCard creation) pool

intentFor :: ConnectionPool -> Checkout.PaymentAttemptReference -> IO Text
intentFor pool attempt = do
  rows <- runSqlPool (rawSql "SELECT payment_intent_id::text FROM commerce_payment_attempt WHERE id=?::uuid"
    [PersistText (Checkout.paymentAttemptReferenceId attempt)]) pool :: IO [Single Text]
  case rows of
    [Single intent] -> pure intent
    _ -> fail "Expected exactly one bound canonical intent"

assertCounts :: ConnectionPool -> Checkout.PaymentAttemptCreation -> Int64 -> Int64 -> Expectation
assertCounts pool creation attempts intents = do
  rows <- runSqlPool (rawSql
    "SELECT (SELECT COUNT(*) FROM commerce_payment_attempt WHERE checkout_id=?::uuid),\
    \ (SELECT COUNT(*) FROM commerce_payment_intent WHERE checkout_id=?::uuid)"
    (replicate 2 (PersistText (Checkout.checkoutReferenceId (Checkout.pacCheckout creation))))) pool
  (rows :: [(Single Int64, Single Int64)]) `shouldBe` [(Single attempts, Single intents)]

requireRight :: Show error => Either error value -> IO value
requireRight = either (fail . show) pure

concurrently :: [IO value] -> IO [value]
concurrently actions = do
  completions <- forM actions $ \action -> do
    completion <- newEmptyMVar
    _ <- forkFinally action (putMVar completion)
    pure completion
  mapM (\completion -> takeMVar completion >>= either throwIO pure) completions

-- These are synthetic payments; the real financial and ticket stores execute
-- together in PostgreSQL. Provider sandbox evidence remains a separate gate.
ticketAllocationSpec :: SpecWith ConnectionPool
ticketAllocationSpec = describe "ticket refund allocation transactions" $ do
  forM_ [Checkout.ProviderPayPal, Checkout.ProviderDatafast] $ \provider ->
    it ("routes the public refund request by verified provider: " <> show provider) $ \pool -> do
      (_,eventKey,orderKey,_) <- ticketAllocationFixtureForProvider provider pool
      let (_,request) = socialRefundHandlers (AuthedUser (toSqlKey 1) [Admin] mempty Nothing Nothing)
      result <- runHandler (runReaderT (request (T.pack (show (fromSqlKey eventKey))) (T.pack (show (fromSqlKey orderKey)))
        (TD.RefundRequestDTO Nothing (Just 4172))) (Env pool (error "Refund request must not call a provider")))
      response <- requireRight result
      TD.refundStatus response `shouldBe` "pending"
      [Single requestId] <- runSqlPool (rawSql
        "SELECT id FROM ticket_refund_request WHERE order_id=?" [PersistInt64 (fromSqlKey orderKey)]) pool
      binding <- runSqlPool (TicketRefund.loadTicketRefundReference (toSqlKey requestId)) pool
      fmap (const True) binding `shouldBe` (if provider == Checkout.ProviderPayPal then Just True else Nothing)
      runSqlPool (rawSql "SELECT count(*) FROM event_ticket WHERE order_ref_id=? AND status='refund_pending'"
        [PersistInt64 (fromSqlKey orderKey)]) pool
        `shouldReturn` [Single (if provider == Checkout.ProviderPayPal then 1 else 0 :: Int64)]

  it "rejects a runtime order with no succeeded payment instead of guessing its refund provider" $ \pool -> do
    -- Model a paid legacy order before a canonical runtime is attached. An
    -- unpaid fixture stops at the earlier400 check and never tests this fence.
    (_,eventKey,orderKey,_) <- ticketAllocationFixtureWithLegacyPaid True Checkout.ProviderPayPal "capture" False pool
    let (_,request) = socialRefundHandlers (AuthedUser (toSqlKey 1) [Admin] mempty Nothing Nothing)
    result <- runHandler (runReaderT (request (T.pack (show (fromSqlKey eventKey))) (T.pack (show (fromSqlKey orderKey)))
      (TD.RefundRequestDTO Nothing (Just 4172))) (Env pool (error "Unverified refund must stop locally")))
    either errHTTPCode (const 200) result `shouldBe` 409
    either errBody (const "") result `shouldBe` "Refund requires one unambiguous verified payment provider"
    runSqlPool (rawSql "SELECT count(*) FROM ticket_refund_request WHERE order_id=?"
      [PersistInt64 (fromSqlKey orderKey)]) pool `shouldReturn` [Single (0 :: Int64)]

  it "rejects an unpaid runtime order before attempting provider selection" $ \pool -> do
    (_,eventKey,orderKey,_) <- ticketAllocationFixtureWithPayment Checkout.ProviderPayPal False pool
    let (_,request) = socialRefundHandlers (AuthedUser (toSqlKey 1) [Admin] mempty Nothing Nothing)
    result <- runHandler (runReaderT (request (T.pack (show (fromSqlKey eventKey))) (T.pack (show (fromSqlKey orderKey)))
      (TD.RefundRequestDTO Nothing (Just 4172))) (Env pool (error "Unpaid refund must stop locally")))
    either errHTTPCode (const 200) result `shouldBe` 400
    either errBody (const "") result `shouldBe` "Only paid orders can be refunded"
    runSqlPool (rawSql "SELECT count(*) FROM ticket_refund_request WHERE order_id=?"
      [PersistInt64 (fromSqlKey orderKey)]) pool `shouldReturn` [Single (0 :: Int64)]

  it "rejects legacy status changes throughout a canonical partial refund without losing allocation" $ \pool -> do
    (payment,eventKey,orderKey,_) <- ticketAllocationFixture pool
    let now = Checkout.vpOccurredAt payment
        (setStatus,_) = socialRefundHandlers (AuthedUser (toSqlKey 1) [Admin] mempty Nothing Nothing)
        denyLegacy = forM_ ["paid","cancelled","refunded"] $ \status -> do
          result <- runHandler (runReaderT (setStatus (T.pack (show (fromSqlKey eventKey))) (T.pack (show (fromSqlKey orderKey)))
            (TD.TicketOrderStatusUpdateDTO status)) (Env pool (error "Legacy canonical mutation must stop before side effects")))
          either errHTTPCode (const 200) result `shouldBe` 409
    request <- runSqlPool (TicketRefund.requestTicketRefundForOrder "1" eventKey orderKey (Just 4172) Nothing now) pool
    Just ref <- runSqlPool (TicketRefund.loadTicketRefundReference (entityKey request)) pool
    denyLegacy
    runSqlPool (rawSql "SELECT count(*) FROM event_ticket WHERE order_ref_id=? AND status='refund_pending'"
      [PersistInt64 (fromSqlKey orderKey)]) pool `shouldReturn` [Single (1 :: Int64)]
    _ <- runSqlPool (Refund.approveRefundForProcessing ref 2 now) pool >>= requireRight
    runSqlPool (TicketRefund.completeTicketRefund
      (Refund.VerifiedRefund ref ("R-" <> Refund.refundReferenceId ref) 4172 "USD" now "legacy-guard-completion")) pool
      `shouldReturn` True
    denyLegacy
    runSqlPool (rawSql "SELECT quantity_sold FROM event_ticket_tier WHERE event_id=?"
      [PersistInt64 (fromSqlKey eventKey)]) pool `shouldReturn` [Single (2 :: Int64)]
    runSqlPool (rawSql "SELECT count(*) FROM event_ticket WHERE order_ref_id=? AND status='refunded'"
      [PersistInt64 (fromSqlKey orderKey)]) pool `shouldReturn` [Single (1 :: Int64)]

  it "serializes transfer creation and acceptance against refund allocation of the same ticket" $ \pool ->
    forM_ [1..4 :: Int] $ \index -> do
      (payment,eventKey,orderKey,(first:_)) <- ticketAllocationFixture pool
      now <- getCurrentTime
      let code = "transfer-refund-" <> Checkout.checkoutReferenceId (Checkout.vpCheckout payment)
      runSqlPool (do
        rawExecute "UPDATE event_ticket_tier SET allow_transfers=true WHERE event_id=?" [PersistInt64 (fromSqlKey eventKey)]
        ) pool
      let proposal = TM.TicketTransfer first (Just "1") Nothing (Just "recipient@example.invalid")
            (Just "Synthetic") "pending" code Nothing (Just (addUTCTime 1800 now)) Nothing now now
      let reserve = do
            result <- try (runSqlPool (TicketRefund.requestTicketRefund "1" eventKey orderKey
              (ticketAllocationCreation payment ("transfer-race-" <> T.pack (show index)) 4172) [first]) pool)
              :: IO (Either IOException (Either Text Refund.RefundRecord))
            pure $ case result of Right (Right _) -> True; _ -> False
          accept = runSqlPool (do
            invited <- Transfer.createTransfer "1" eventKey proposal now
            case invited of
              Left _ -> pure False
              Right _ -> isRight <$> Transfer.acceptTransfer "2" code (code <> "-rotated") now) pool
      results <- concurrently [reserve,accept]
      length (filter id results) `shouldBe` 1
      [ticket] <- runSqlPool (rawSql "SELECT ?? FROM event_ticket WHERE id=?" [PersistInt64 (fromSqlKey first)]) pool
      let current = entityVal ticket
      (TM.eventTicketStatus current,TM.eventTicketCurrentHolderPartyId current)
        `shouldSatisfy` (`elem` [("refund_pending",Just "1"),("issued",Just "2")])

  forM_ ["unknown_id","wrong_amount","wrong_correlation"] $ \scenario ->
    it ("never allocates an unmatched external refund: " <> T.unpack scenario) $ \pool -> do
      (payment,eventKey,orderKey,(_:second:_)) <- ticketAllocationFixture pool
      let now = Checkout.vpOccurredAt payment
      request <- runSqlPool (TicketRefund.requestTicketRefundForOrder "1" eventKey orderKey (Just 4172) Nothing now) pool
      Just ref <- runSqlPool (TicketRefund.loadTicketRefundReference (entityKey request)) pool
      _ <- runSqlPool (Refund.approveRefundForProcessing ref 2 now) pool >>= requireRight
      let providerId = "R-" <> Refund.refundReferenceId ref
      runSqlPool (Refund.recordRefundPending ref providerId now) pool `shouldReturn` Right ()
      let resource = A.object
            (["id" A..= (if scenario == "unknown_id" then "R-UNKNOWN" else providerId)
              ,"status" A..= ("COMPLETED" :: Text)
              ,"amount" A..= A.object ["currency_code" A..= ("USD" :: Text)
                ,"value" A..= (if scenario == "wrong_amount" then "20.00" else "41.72" :: Text)]
              ,"links" A..= [A.object ["rel" A..= ("up" :: Text),"method" A..= ("GET" :: Text)
                ,"href" A..= ("https://api.sandbox.paypal.com/v2/payments/captures/" <> Checkout.vpProviderResource payment)]]]
            <> if scenario == "wrong_correlation" then ["custom_id" A..= ("f8409c7d-7a78-48c1-b07f-e0126f909ef4" :: Text)] else [])
          envelope = Storefront.PaypalWebhookEnvelope ("WH-" <> Refund.refundReferenceId ref) "PAYMENT.CAPTURE.REFUNDED" now resource
      result <- Storefront.processPaypalWebhookEventIO (Env pool (error "No HTTP configuration needed"))
        Checkout.CheckoutSandbox (Checkout.vpMerchantRef payment) envelope now
      result `shouldBe` Storefront.PaypalEventProcessed (Just (Checkout.checkoutReferenceId (Checkout.vpCheckout payment)))
        (Just (Checkout.paymentAttemptReferenceId (Checkout.vpAttempt payment))) Nothing
      runSqlPool (Refund.loadRefund ref) pool >>= ((`shouldBe` Just "processing") . fmap Refund.rrStatus)
      runSqlPool (rawSql "SELECT quantity_sold FROM event_ticket_tier WHERE event_id=?" [PersistInt64 (fromSqlKey eventKey)]) pool
        `shouldReturn` [Single (3 :: Int64)]
      admitted <- runSqlPool (Admission.admitTicket "1" eventKey (Admission.AdmissionById second) now) pool
      admitted `shouldSatisfy` isLeft

  it "allows strict-admin cancellation before execution and denies mixed-role escalation" $ \pool -> do
    (payment,eventKey,orderKey,(first:_)) <- ticketAllocationFixture pool
    refund <- runSqlPool (TicketRefund.requestTicketRefund "1" eventKey orderKey
      (ticketAllocationCreation payment "admin-cancel" 4172) [first]) pool >>= requireRight
    let ref = Refund.rrReference refund
        now = Checkout.vpOccurredAt payment
        user roles = AuthedUser (toSqlKey 3) roles mempty Nothing Nothing
    denied <- try (runSqlPool (TicketRefund.cancelTicketRefundAs (user [Admin,Manager]) ref now) pool)
      :: IO (Either IOException ())
    denied `shouldSatisfy` isLeft
    runSqlPool (TicketRefund.cancelTicketRefundAs (user [Admin]) ref now) pool
    runSqlPool (Refund.loadRefund ref) pool >>= ((`shouldBe` Just "cancelled") . fmap Refund.rrStatus)
    runSqlPool (rawSql "SELECT status FROM event_ticket WHERE id=?" [PersistInt64 (fromSqlKey first)]) pool
      `shouldReturn` [Single ("issued" :: Text)]

  it "denies unrelated, mixed-role admin and self approvers before provider configuration" $ \pool -> do
    (payment,eventKey,orderKey,_) <- ticketAllocationFixture pool
    request <- runSqlPool (TicketRefund.requestTicketRefundForOrder "1" eventKey orderKey (Just 4172) Nothing (Checkout.vpOccurredAt payment)) pool
    forM_ [(3,[]),(3,[Admin,Manager]),(1,[Admin])] $ \(actor,roles) -> do
      let user = AuthedUser (toSqlKey actor) roles mempty Nothing Nothing
      result <- runHandler (runReaderT (TicketRefundAPI.approvePaypalTicketRefund user eventKey (entityKey request))
        (Env pool (error "Denied refund must not read provider configuration")))
      either errHTTPCode (const 200) result `shouldBe` 409

  forM_ [False,True] $ \completed ->
    it ("recovers ticket refund through existing read-only query, completed=" <> show completed) $ \pool -> do
      (payment,eventKey,orderKey,_) <- ticketAllocationFixture pool
      let now = Checkout.vpOccurredAt payment
      request <- runSqlPool (TicketRefund.requestTicketRefundForOrder "1" eventKey orderKey (Just 4172) Nothing now) pool
      Just ref <- runSqlPool (TicketRefund.loadTicketRefundReference (entityKey request)) pool
      _ <- runSqlPool (Refund.approveRefundForProcessing ref 2 now) pool >>= requireRight
      runSqlPool (Refund.recordRefundPending ref ("R-" <> Refund.refundReferenceId ref) now) pool `shouldReturn` Right ()
      runSqlPool (do
        rawExecute "INSERT INTO revenue_feature_flag(flag_key,enabled,environment,reason) VALUES ('checkout.paypal.refund_reconciliation',true,'sandbox','synthetic fixture') ON CONFLICT(flag_key,environment) DO UPDATE SET enabled=true" []
        rawExecute "UPDATE commerce_provider_account SET enabled=true,status='ready',contract_status='approved',credential_status='validated' WHERE provider='paypal' AND environment='sandbox'" []
        rawExecute "UPDATE commerce_provider_capability SET verification_status='sandbox_verified' WHERE provider_account_id=(SELECT id FROM commerce_provider_account WHERE provider='paypal' AND environment='sandbox') AND payment_method='paypal_wallet'" []
        rawExecute "DELETE FROM commerce_provider_query_budget WHERE provider='paypal' AND environment='sandbox'" []) pool
      result <- TicketRecovery.reconcileKnownRefund pool ref 2 (const (pure True)) (\binding -> do
        TicketQuery.rqbCaptureId binding `shouldBe` Checkout.vpProviderResource payment
        TicketQuery.rqbAmountMinor binding `shouldBe` 4172
        pure (Right (if completed then TicketQuery.RefundQueryCompleted else TicketQuery.RefundQueryHeld)))
      view <- requireRight result
      Refund.rrStatus (TicketRecovery.rrvRefund view) `shouldBe` (if completed then "succeeded" else "processing")
      runSqlPool (rawSql "SELECT quantity_sold FROM event_ticket_tier WHERE event_id=?" [PersistInt64 (fromSqlKey eventKey)]) pool
        `shouldReturn` [Single (if completed then 2 else 3 :: Int64)]
      runSqlPool (rawSql "SELECT count(*) FROM event_ticket WHERE order_ref_id=? AND status='refunded'" [PersistInt64 (fromSqlKey orderKey)]) pool
        `shouldReturn` [Single (if completed then 1 else 0 :: Int64)]
      runSqlPool (rawExecute "UPDATE revenue_feature_flag SET enabled=false WHERE flag_key='checkout.paypal.refund_reconciliation' AND environment='sandbox'" []) pool

  forM_ [4171,8343] $ \amount ->
    it ("selects a whole-ticket subset with remainder cents: " <> show amount) $ \pool -> do
      (payment,eventKey,orderKey,tickets) <- ticketAllocationFixture pool
      let now = Checkout.vpOccurredAt payment
      request <- runSqlPool (TicketRefund.requestTicketRefundForOrder "1" eventKey orderKey (Just amount) Nothing now) pool
      Just ref <- runSqlPool (TicketRefund.loadTicketRefundReference (entityKey request)) pool
      allocations <- runSqlPool (rawSql
        "SELECT ticket_id,amount_minor FROM event_ticket_refund_allocation WHERE refund_id=?::uuid ORDER BY ticket_id"
        [PersistText (Refund.refundReferenceId ref)]) pool :: IO [(Single Int64,Single Int64)]
      sum [value | (_,Single value) <- allocations] `shouldBe` fromIntegral amount
      map (\(Single key,_) -> key) allocations `shouldContain` [fromSqlKey (last tickets)]
      _ <- runSqlPool (Refund.approveRefundForProcessing ref 2 now) pool >>= requireRight
      _ <- runSqlPool (TicketRefund.completeTicketRefund
        (Refund.VerifiedRefund ref ("R-" <> Refund.refundReferenceId ref) (fromIntegral amount) "USD" now "cent-subset")) pool
      remaining <- runSqlPool (TicketRefund.requestTicketRefundForOrder "1" eventKey orderKey Nothing Nothing now) pool
      TM.ticketRefundRequestAmountCents (entityVal remaining) `shouldBe` 12515 - amount

  forM_ [False,True] $ \httpFailure ->
    it ("retries pre-POST OAuth failure but never ambiguous refund POST, HTTP failure=" <> show httpFailure) $ \pool ->
      withCompletionEnvironment $ bracket (lookupEnv "PAYPAL_REFUND_RECONCILIATION_ENABLED")
        (maybe (unsetEnv "PAYPAL_REFUND_RECONCILIATION_ENABLED") (setEnv "PAYPAL_REFUND_RECONCILIATION_ENABLED")) $ \_ -> do
        setEnv "PAYPAL_REFUND_RECONCILIATION_ENABLED" "true"
        runSqlPool (rawExecute
          "INSERT INTO revenue_feature_flag(flag_key,enabled,environment,reason) VALUES ('checkout.paypal.refund_reconciliation',true,'sandbox','synthetic fixture') ON CONFLICT(flag_key,environment) DO UPDATE SET enabled=true" []) pool
        (payment,eventKey,orderKey,_) <- ticketAllocationFixture pool
        request <- runSqlPool (TicketRefund.requestTicketRefundForOrder "1" eventKey orderKey (Just 4172) Nothing (Checkout.vpOccurredAt payment)) pool
        Just ref <- runSqlPool (TicketRefund.loadTicketRefundReference (entityKey request)) pool
        let approve manager = runHandler (runReaderT (TicketRefundAPI.approvePaypalTicketRefundWithManager
              manager (AuthedUser (toSqlKey 2) [Admin] mempty Nothing Nothing) eventKey (entityKey request))
              (Env pool (error "Transport fixture must not load unrelated configuration")))
            status = fmap Refund.rrStatus <$> runSqlPool (Refund.loadRefund ref) pool
            failedToken = if httpFailure then "HTTP/1.1 503 Unavailable\r\nContent-Length: 0\r\n\r\n" else jsonWire "{}"
        reader <- chunkReader [failedToken]
        withProviderWire reader $ \manager _ writes _ -> do
          result <- approve manager
          either errHTTPCode (const 200) result `shouldBe` 502
          sent <- writes
          sent `shouldSatisfy` BS.isInfixOf "POST /v1/oauth2/token "
          sent `shouldSatisfy` (not . BS.isInfixOf "/refund ")
        status `shouldReturn` Just "requested"
        Just pending <- runSqlPool (get (entityKey request)) pool
        TM.ticketRefundRequestStatus pending `shouldBe` "pending"
        -- Token succeeds on retry; an invalid POST response is ambiguous and
        -- must retain the processing fence. A later approval sends no second POST.
        retryReader <- chunkReader [jsonWire oauthFixture,jsonWire "{}"]
        withProviderWire retryReader $ \manager _ writes _ -> do
          result <- approve manager
          either errHTTPCode (const 200) result `shouldBe` 502
          sent <- writes
          sent `shouldSatisfy` BS.isInfixOf "/refund "
        status `shouldReturn` Just "processing"
        thirdReader <- chunkReader [jsonWire oauthFixture]
        withProviderWire thirdReader $ \manager _ writes _ -> do
          result <- approve manager
          either errHTTPCode (const 200) result `shouldBe` 200
          sent <- writes
          sent `shouldSatisfy` (not . BS.isInfixOf "/refund ")
        status `shouldReturn` Just "processing"
        runSqlPool (rawExecute "UPDATE revenue_feature_flag SET enabled=false WHERE flag_key='checkout.paypal.refund_reconciliation' AND environment='sandbox'" []) pool

  forM_ [False,True] $ \wrongCurrency ->
    it ("retains an accepted refund identity for exact readback after mismatch, currency=" <> show wrongCurrency) $ \pool ->
      withCompletionEnvironment $ bracket (lookupEnv "PAYPAL_REFUND_RECONCILIATION_ENABLED")
        (maybe (unsetEnv "PAYPAL_REFUND_RECONCILIATION_ENABLED") (setEnv "PAYPAL_REFUND_RECONCILIATION_ENABLED")) $ \_ -> do
        setEnv "PAYPAL_REFUND_RECONCILIATION_ENABLED" "true"
        runSqlPool (do
          rawExecute "INSERT INTO revenue_feature_flag(flag_key,enabled,environment,reason) VALUES ('checkout.paypal.refund_reconciliation',true,'sandbox','synthetic fixture') ON CONFLICT(flag_key,environment) DO UPDATE SET enabled=true" []
          rawExecute "DELETE FROM commerce_provider_query_budget WHERE provider='paypal' AND environment='sandbox'" []) pool
        (payment,eventKey,orderKey,_) <- ticketAllocationFixture pool
        request <- runSqlPool (TicketRefund.requestTicketRefundForOrder "1" eventKey orderKey (Just 4172) Nothing (Checkout.vpOccurredAt payment)) pool
        Just ref <- runSqlPool (TicketRefund.loadTicketRefundReference (entityKey request)) pool
        let refundId = "R-" <> Refund.refundReferenceId ref
            representation :: Text -> Text -> BS.ByteString
            representation amount currency = BL.toStrict $ A.encode $ A.object
              ["id" A..= refundId,"status" A..= ("COMPLETED" :: Text)
              ,"amount" A..= A.object ["value" A..= amount,"currency_code" A..= currency]
              ,"links" A..=
                [A.object ["rel" A..= ("up" :: Text),"method" A..= ("GET" :: Text)
                  ,"href" A..= ("https://api.sandbox.paypal.com/v2/payments/captures/" <> Checkout.vpProviderResource payment)]
                ,A.object ["rel" A..= ("self" :: Text),"method" A..= ("GET" :: Text)
                  ,"href" A..= ("https://api.sandbox.paypal.com/v2/payments/refunds/" <> refundId)]]]
            mismatch = representation (if wrongCurrency then "41.72" else "41.73")
              (if wrongCurrency then "EUR" else "USD")
            approve manager = runHandler (runReaderT (TicketRefundAPI.approvePaypalTicketRefundWithManager
              manager (AuthedUser (toSqlKey 2) [Admin] mempty Nothing Nothing) eventKey (entityKey request))
              (Env pool (error "Transport fixture must not load unrelated configuration")))
            load = runSqlPool (Refund.loadRefund ref) pool >>= maybe (fail "Missing refund") pure
        reader <- chunkReader [jsonWire oauthFixture,jsonWire mismatch]
        withProviderWire reader $ \manager _ _ _ ->
          approve manager >>= ((`shouldBe` 502) . either errHTTPCode (const 200))
        recorded <- load
        Refund.rrProviderRefundId recorded `shouldBe` Just refundId
        Refund.rrStatus recorded `shouldBe` "processing"
        forM_ [False,True] $ \exact -> do
          when exact $ do
            -- The production query budget remains enforced. Prove the immediate
            -- retry is denied, then advance only the disposable fixture's clock.
            heldReader <- chunkReader [jsonWire oauthFixture]
            withProviderWire heldReader $ \manager _ writes _ -> do
              approve manager >>= ((`shouldBe` 429) . either errHTTPCode (const 200))
              sent <- writes
              sent `shouldSatisfy` (not . BS.isInfixOf "GET /v2/payments/refunds/")
            resetQueryBudget pool Checkout.ProviderPayPal
          queryReader <- chunkReader [jsonWire oauthFixture,jsonWire
            (if exact then representation "41.72" "USD" else mismatch)]
          withProviderWire queryReader $ \manager _ writes _ -> do
            approve manager >>= ((`shouldBe` (if exact then 200 else 503)) . either errHTTPCode (const 200))
            sent <- writes
            sent `shouldSatisfy` BS.isInfixOf ("GET /v2/payments/refunds/" <> TE.encodeUtf8 refundId <> " ")
            sent `shouldSatisfy` (not . BS.isInfixOf "/refund ")
          afterQuery <- load
          Refund.rrStatus afterQuery `shouldBe` (if exact then "succeeded" else "processing")
        withProviderWire (fail "Completed refund replay must not contact the provider") $ \manager connections _ _ -> do
          approve manager >>= ((`shouldBe` 200) . either errHTTPCode (const 200))
          connections `shouldReturn` 0
        runSqlPool (rawSql "SELECT count(*) FROM commerce_receipt WHERE refund_id=?::uuid AND kind='credit_note'"
          [PersistText (Refund.refundReferenceId ref)]) pool `shouldReturn` [Single (1 :: Int64)]
        runSqlPool (rawExecute "UPDATE revenue_feature_flag SET enabled=false WHERE flag_key='checkout.paypal.refund_reconciliation' AND environment='sandbox'" []) pool

  it "binds organizer requests atomically, makes double clicks idempotent, and permits successive partial refunds" $ \pool -> do
    (payment,eventKey,orderKey,_) <- ticketAllocationFixture pool
    let now = Checkout.vpOccurredAt payment
        request = runSqlPool (TicketRefund.requestTicketRefundForOrder "1" eventKey orderKey (Just 4172) (Just "customer request") now) pool
    results <- concurrently (replicate 8 request)
    length (nub (map entityKey results)) `shouldBe` 1
    requestKey <- case results of
      first:_ -> pure (entityKey first)
      [] -> fail "Concurrent request fixture returned no results"
    Just ref <- runSqlPool (TicketRefund.loadTicketRefundReference requestKey) pool
    runSqlPool (rawSql "SELECT count(*) FROM commerce_refund WHERE checkout_id=?::uuid" [captureCheckoutParameter payment]) pool
      `shouldReturn` [Single (1 :: Int64)]
    self <- runSqlPool (Refund.approveRefundForProcessing ref 1 now) pool
    self `shouldSatisfy` isLeft
    _ <- runSqlPool (Refund.approveRefundForProcessing ref 2 now) pool >>= requireRight
    _ <- runSqlPool (TicketRefund.completeTicketRefund
      (Refund.VerifiedRefund ref ("R-" <> Refund.refundReferenceId ref) 4172 "USD" now "request-completion")) pool
    Just updated <- runSqlPool (get requestKey) pool
    TM.ticketRefundRequestStatus updated `shouldBe` "approved"
    TM.ticketRefundRequestStripeRefundId updated `shouldBe` Nothing
    next <- runSqlPool (TicketRefund.requestTicketRefundForOrder "1" eventKey orderKey Nothing (Just "remaining tickets") now) pool
    TM.ticketRefundRequestAmountCents (entityVal next) `shouldBe` 8343
    Just nextRef <- runSqlPool (TicketRefund.loadTicketRefundReference (entityKey next)) pool
    nextRef `shouldNotBe` ref

  forM_ ["actor", "event", "fractional", "negative", "overpaid", "legacy_pending"] $ \scenario ->
    it ("rejects invalid organizer refund request without reserving money: " <> T.unpack scenario) $ \pool -> do
      (payment,eventKey,orderKey,_) <- ticketAllocationFixture pool
      when (scenario == "legacy_pending") $ runSqlPool (rawExecute
        "INSERT INTO ticket_refund_request(order_id,requested_by_party_id,amount_cents,status) VALUES (?,'1',4172,'pending')"
        [PersistInt64 (fromSqlKey orderKey)]) pool
      let actor = if scenario == "actor" then "2" else "1"
          event = if scenario == "event" then toSqlKey 999999 else eventKey
          amount = case scenario of "fractional" -> 100; "negative" -> -1; "overpaid" -> 12516; _ -> 4172
      result <- try (runSqlPool (TicketRefund.requestTicketRefundForOrder actor event orderKey
        (Just amount) Nothing (Checkout.vpOccurredAt payment)) pool) :: IO (Either IOException (Entity TM.TicketRefundRequest))
      result `shouldSatisfy` isLeft
      runSqlPool (rawSql "SELECT count(*) FROM commerce_refund WHERE checkout_id=?::uuid" [captureCheckoutParameter payment]) pool
        `shouldReturn` [Single (0 :: Int64)]

  forM_ [False,True] $ \alreadyBound ->
    it ("projects a signed known partial refund without fencing remaining tickets, bound=" <> show alreadyBound) $ \pool -> do
      (payment,eventKey,orderKey,(first:second:_)) <- ticketAllocationFixture pool
      request <- runSqlPool (TicketRefund.requestTicketRefundForOrder "1" eventKey orderKey (Just 4172) Nothing (Checkout.vpOccurredAt payment)) pool
      Just ref <- runSqlPool (TicketRefund.loadTicketRefundReference (entityKey request)) pool
      let now = Checkout.vpOccurredAt payment
          providerId = "R-" <> Refund.refundReferenceId ref
      _ <- runSqlPool (Refund.approveRefundForProcessing ref 2 now) pool >>= requireRight
      when alreadyBound $ runSqlPool (Refund.recordRefundPending ref providerId now) pool `shouldReturn` Right ()
      let envelope = Storefront.PaypalWebhookEnvelope ("WH-" <> Refund.refundReferenceId ref) "PAYMENT.CAPTURE.REFUNDED" now
            (A.object (["id" A..= providerId,"status" A..= ("COMPLETED" :: Text)
              ,"amount" A..= A.object ["value" A..= ("41.72" :: Text),"currency_code" A..= ("USD" :: Text)]
              ,"links" A..= [A.object ["rel" A..= ("up" :: Text),"method" A..= ("GET" :: Text)
                ,"href" A..= ("https://api.sandbox.paypal.com/v2/payments/captures/" <> Checkout.vpProviderResource payment)]]]
              <> if alreadyBound then [] else ["custom_id" A..= Refund.refundReferenceId ref]))
          process = Storefront.processPaypalWebhookEventIO (Env pool (error "No HTTP configuration needed"))
            Checkout.CheckoutSandbox (Checkout.vpMerchantRef payment) envelope now
      results <- concurrently (replicate 4 process)
      results `shouldBe` replicate 4 (Storefront.PaypalEventProcessed
        (Just (Checkout.checkoutReferenceId (Checkout.vpCheckout payment)))
        (Just (Checkout.paymentAttemptReferenceId (Checkout.vpAttempt payment))) (Just (Refund.refundReferenceId ref)))
      -- The signed callback may commit before the refund POST returns. Binding
      -- that exact late response must acknowledge completion without regression.
      runSqlPool (Refund.recordRefundPending ref providerId now) pool `shouldReturn` Right ()
      runSqlPool (Refund.recordRefundPending ref "R-DIFFERENT" now) pool >>= (`shouldSatisfy` isLeft)
      denied <- runSqlPool (Admission.admitTicket "1" eventKey (Admission.AdmissionById first) now) pool
      denied `shouldSatisfy` isLeft
      accepted <- runSqlPool (Admission.admitTicket "1" eventKey (Admission.AdmissionById second) now) pool
      accepted `shouldSatisfy` isRight
      runSqlPool (rawSql "SELECT count(*) FROM commerce_reconciliation_exception WHERE provider_reference=?"
        [PersistText (Checkout.vpProviderResource payment)]) pool `shouldReturn` [Single (0 :: Int64)]

  it "reserves one ticket, denies admission, completes/replays once and retains other tickets" $ \pool -> do
    (payment,eventKey,orderKey,(first:second:_)) <- ticketAllocationFixture pool
    let creation = ticketAllocationCreation payment "partial" 4172
    refund <- runSqlPool (TicketRefund.requestTicketRefund "1" eventKey orderKey creation [first]) pool >>= requireRight
    let ref = Refund.rrReference refund
        now = Checkout.vpOccurredAt payment
        completion = Refund.VerifiedRefund ref ("refund-" <> Refund.refundReferenceId ref) 4172 "USD" now "allocation-test"
    runSqlPool (TicketRefund.requestTicketRefund "1" eventKey orderKey creation [first]) pool
      >>= ((`shouldBe` ref) . Refund.rrReference) . either (error . T.unpack) id
    denied <- runSqlPool (Admission.admitTicket "1" eventKey (Admission.AdmissionById first) now) pool
    either (const True) (const False) denied `shouldBe` True
    _ <- runSqlPool (Refund.approveRefundForProcessing ref 2 now) pool >>= requireRight
    results <- concurrently (replicate 8 (runSqlPool (TicketRefund.completeTicketRefund completion) pool))
    length (filter id results) `shouldBe` 1
    runSqlPool (rawSql "SELECT quantity_sold FROM event_ticket_tier WHERE event_id=?" [PersistInt64 (fromSqlKey eventKey)]) pool
      `shouldReturn` [Single (2 :: Int64)]
    runSqlPool (rawSql "SELECT status FROM event_ticket_order WHERE id=?" [PersistInt64 (fromSqlKey orderKey)]) pool
      `shouldReturn` [Single ("paid" :: Text)]
    runSqlPool (TicketRefund.capturedTicketRevenue eventKey "USD") pool
      `shouldReturn` [(orderKey,12515,4172)]
    accepted <- runSqlPool (Admission.admitTicket "1" eventKey (Admission.AdmissionById second) now) pool
    either (const False) (const True) accepted `shouldBe` True
    runSqlPool (rawSql "SELECT count(*) FROM commerce_receipt WHERE refund_id=?::uuid AND kind='credit_note'"
      [PersistText (Refund.refundReferenceId ref)]) pool `shouldReturn` [Single (1 :: Int64)]

  it "cancels a requested allocation without restocking or retaining an admission fence" $ \pool -> do
    (payment,eventKey,orderKey,(first:_)) <- ticketAllocationFixture pool
    refund <- runSqlPool (TicketRefund.requestTicketRefund "1" eventKey orderKey
      (ticketAllocationCreation payment "cancel" 4172) [first]) pool >>= requireRight
    let now = Checkout.vpOccurredAt payment
    runSqlPool (TicketRefund.cancelTicketRefund "1" (Refund.rrReference refund) now) pool
    runSqlPool (TicketRefund.cancelTicketRefund "1" (Refund.rrReference refund) now) pool
    accepted <- runSqlPool (Admission.admitTicket "1" eventKey (Admission.AdmissionById (first)) now) pool
    either (const False) (const True) accepted `shouldBe` True
    runSqlPool (rawSql "SELECT quantity_sold FROM event_ticket_tier WHERE event_id=?" [PersistInt64 (fromSqlKey eventKey)]) pool
      `shouldReturn` [Single (3 :: Int64)]

  forM_ ["actor","event","amount","used","transferred","duplicate","legacy_total"] $ \scenario ->
    it ("rolls the canonical request back for invalid ticket selection: " <> T.unpack scenario) $ \pool -> do
      (payment,eventKey,orderKey,(first:_)) <- ticketAllocationFixture pool
      when (scenario == "used") $ runSqlPool (rawExecute
        "UPDATE event_ticket SET status='checked_in',checked_in_at=now() WHERE id=?"
        [PersistInt64 (fromSqlKey (first))]) pool
      when (scenario == "transferred") $ runSqlPool (rawExecute
        "UPDATE event_ticket SET current_holder_party_id='2' WHERE id=?"
        [PersistInt64 (fromSqlKey (first))]) pool
      when (scenario == "legacy_total") $ runSqlPool (rawExecute
        "UPDATE event_ticket_order SET amount_cents=1 WHERE id=?"
        [PersistInt64 (fromSqlKey orderKey)]) pool
      let actor = if scenario == "actor" then "2" else "1"
          event = if scenario == "event" then toSqlKey 999999 else eventKey
          amount = if scenario == "amount" then 1 else 4172
          selection = if scenario == "duplicate" then [first,first] else [first]
      result <- try (runSqlPool (TicketRefund.requestTicketRefund actor event orderKey
        (ticketAllocationCreation payment scenario amount) selection) pool)
        :: IO (Either IOException (Either Text Refund.RefundRecord))
      result `shouldSatisfy` isLeft
      runSqlPool (rawSql "SELECT count(*) FROM commerce_refund WHERE checkout_id=?::uuid"
        [captureCheckoutParameter payment]) pool `shouldReturn` [Single (0 :: Int64)]

  it "keeps uncertain processing reserved and rolls back completion on inventory drift" $ \pool -> do
    (payment,eventKey,orderKey,tickets) <- ticketAllocationFixture pool
    refund <- runSqlPool (TicketRefund.requestTicketRefund "1" eventKey orderKey
      (ticketAllocationCreation payment "drift" 12515) tickets) pool >>= requireRight
    let ref = Refund.rrReference refund
        now = Checkout.vpOccurredAt payment
        completion = Refund.VerifiedRefund ref ("refund-" <> Refund.refundReferenceId ref) 12515 "USD" now "drift-test"
    _ <- runSqlPool (Refund.approveRefundForProcessing ref 2 now) pool >>= requireRight
    cancelled <- try (runSqlPool (TicketRefund.cancelTicketRefund "1" ref now) pool) :: IO (Either IOException ())
    cancelled `shouldSatisfy` isLeft
    runSqlPool (rawExecute "UPDATE event_ticket_tier SET quantity_sold=2 WHERE event_id=?"
      [PersistInt64 (fromSqlKey eventKey)]) pool
    completed <- try (runSqlPool (TicketRefund.completeTicketRefund completion) pool) :: IO (Either IOException Bool)
    completed `shouldSatisfy` isLeft
    runSqlPool (Refund.loadRefund ref) pool >>= ((`shouldBe` Just "processing") . fmap Refund.rrStatus)
    runSqlPool (rawSql "SELECT count(*) FROM commerce_receipt WHERE refund_id=?::uuid AND kind='credit_note'"
      [PersistText (Refund.refundReferenceId ref)]) pool `shouldReturn` [Single (0 :: Int64)]
    runSqlPool (rawExecute "UPDATE event_ticket_tier SET quantity_sold=3 WHERE event_id=?"
      [PersistInt64 (fromSqlKey eventKey)]) pool
    runSqlPool (TicketRefund.completeTicketRefund completion) pool `shouldReturn` True
    runSqlPool (TicketRefund.capturedTicketRevenue eventKey "USD") pool
      `shouldReturn` [(orderKey,12515,12515)]
    runSqlPool (rawSql "SELECT status FROM event_ticket_order WHERE id=?" [PersistInt64 (fromSqlKey orderKey)]) pool
      `shouldReturn` [Single ("refunded" :: Text)]

  it "serializes eight competing requests for the same ticket" $ \pool -> do
    (payment,eventKey,orderKey,(first:_)) <- ticketAllocationFixture pool
    results <- concurrently [try (runSqlPool (TicketRefund.requestTicketRefund "1" eventKey orderKey
      (ticketAllocationCreation payment ("race-" <> T.pack (show index)) 4172) [first]) pool)
      :: IO (Either IOException (Either Text Refund.RefundRecord)) | index <- [1..8 :: Int]]
    length [() | Right (Right _) <- results] `shouldBe` 1
    runSqlPool (rawSql "SELECT count(*) FROM commerce_refund WHERE checkout_id=?::uuid"
      [captureCheckoutParameter payment]) pool `shouldReturn` [Single (1 :: Int64)]

  it "serializes admission against reservation without refunding an admitted ticket" $ \pool -> do
    forM_ [1..4 :: Int] $ \index -> do
      (payment,eventKey,orderKey,(first:_)) <- ticketAllocationFixture pool
      let reserve = do
            result <- try (runSqlPool (TicketRefund.requestTicketRefund "1" eventKey orderKey
              (ticketAllocationCreation payment ("scan-race-" <> T.pack (show index)) 4172) [first]) pool)
              :: IO (Either IOException (Either Text Refund.RefundRecord))
            pure $ case result of Right (Right _) -> True; _ -> False
          scan = isRight <$> runSqlPool (Admission.admitTicket "1" eventKey
            (Admission.AdmissionById first) (Checkout.vpOccurredAt payment)) pool
      results <- concurrently [reserve,scan]
      length (filter id results) `shouldBe` 1

-- Exercise the actual legacy HTTP handlers against the same complete schema as
-- canonical refunds. The injected callback never contacts Stripe; it models an
-- accepted POST whose response is lost, concurrent approvers and invalid JSON.
legacyStripeRefundSpec :: SpecWith ConnectionPool
legacyStripeRefundSpec = describe "legacy Stripe ticket refund execution fence" $ do
  it "rechecks historical identities committed while approval waits for the order lock" $ \pool -> do
    fixture@(eventKey,orderKey,refundKey) <- legacyStripeRefundFixture pool 1000
    env <- legacyStripeRefundEnv pool True
    calls <- newIORef (0 :: Int)
    locked <- newEmptyMVar
    release <- newEmptyMVar
    holderFinished <- newEmptyMVar
    approvalFinished <- newEmptyMVar
    let provider _ _ _ = atomicModifyIORef' calls (\count -> (count+1,()))
          >> pure (Left "synthetic uncertain provider response")
        (approve,_) = legacyStripeRefundHandlers provider
        action = runHandler (runReaderT
          (approve (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey refundKey))) env)
        holdHistory = runSqlPool (do
          _ <- rawSql "SELECT id FROM social_event WHERE id=? FOR UPDATE"
            [PersistInt64 (fromSqlKey eventKey)] :: SqlPersistT IO [Single Int64]
          _ <- rawSql "SELECT id FROM event_ticket_order WHERE id=? FOR UPDATE"
            [PersistInt64 (fromSqlKey orderKey)] :: SqlPersistT IO [Single Int64]
          rawExecute "INSERT INTO ticket_refund_request(order_id,amount_cents,status) VALUES (?,1000,'pending')"
            [PersistInt64 (fromSqlKey orderKey)]
          liftIO $ putMVar locked ()
          liftIO $ takeMVar release) pool
        releaseHistory = do
          _ <- tryPutMVar release ()
          pure ()
    bracket (forkFinally holdHistory (putMVar holderFinished)) (\worker ->
      releaseHistory >> awaitLegacyRefundWorker worker holderFinished) $ \_ -> do
      Timeout.timeout 5000000 (readMVar locked) `shouldReturn` Just ()
      bracket (forkFinally action (putMVar approvalFinished)) (\worker ->
        releaseHistory >> awaitLegacyRefundWorker worker approvalFinished) $ \_ -> do
        Timeout.timeout 5000000 (waitForLegacyRequestWaiters pool 1 100)
          `shouldReturn` Just True
        releaseHistory
        result <- Timeout.timeout 5000000 (readMVar approvalFinished)
        case result of
          Just (Right response) -> assertLegacyRefundDenied response
          other -> expectationFailure (show other)
        readIORef calls `shouldReturn` 0
        assertLegacyStripeRefundState pool fixture "pending" "paid" 3 "issued"
        runSqlPool (rawSql
          "SELECT status FROM ticket_refund_request WHERE order_id=? ORDER BY id"
          [PersistInt64 (fromSqlKey orderKey)]) pool
          `shouldReturn` replicate 2 (Single ("pending" :: Text))

  it "keeps canonical successive partial refund replay outside the legacy history guard" $ \pool -> do
    (payment,eventKey,orderKey,_) <- ticketAllocationFixture pool
    let now = Checkout.vpOccurredAt payment
        (approve,_) = legacyStripeRefundHandlers (\_ _ _ -> fail "Canonical replay cannot call Stripe")
    forM_ [4172,8343] $ \amount -> do
      request <- runSqlPool (TicketRefund.requestTicketRefundForOrder "1" eventKey orderKey
        (Just amount) Nothing now) pool
      Just ref <- runSqlPool (TicketRefund.loadTicketRefundReference (entityKey request)) pool
      _ <- runSqlPool (Refund.approveRefundForProcessing ref 2 now) pool >>= requireRight
      _ <- runSqlPool (TicketRefund.completeTicketRefund
        (Refund.VerifiedRefund ref ("R-" <> Refund.refundReferenceId ref)
          (fromIntegral amount) "USD" now "synthetic-history-replay")) pool
      response <- runHandler (runReaderT
        (approve (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey (entityKey request))))
        (Env pool (error "Completed canonical replay cannot read Stripe configuration"))) >>= requireRight
      TD.refundStatus response `shouldBe` "approved"
    runSqlPool (rawSql "SELECT count(*)::bigint FROM ticket_refund_request WHERE order_id=?"
      [PersistInt64 (fromSqlKey orderKey)]) pool `shouldReturn` [Single (2 :: Int64)]

  forM_ [False,True] $ \simultaneous ->
    it ("refuses both historical duplicate refund identities before provider execution: concurrent=" <>
        show simultaneous) $ \pool -> do
      fixture@(eventKey,orderKey,firstKey) <- legacyStripeRefundFixture pool 1000
      secondKey <- legacyStripeDuplicateRefund pool firstKey
      env <- legacyStripeRefundEnv pool True
      calls <- newIORef (0 :: Int)
      let provider _ _ _ = atomicModifyIORef' calls (\count -> (count+1,()))
            >> pure (Left "synthetic uncertain provider response")
          (approve,_) = legacyStripeRefundHandlers provider
          action :: TM.TicketRefundRequestId -> IO (Either ServerError TD.RefundDTO)
          action key = runHandler (runReaderT
            (approve (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey key))) env)
          snapshots = legacyStripeRequestHistory pool orderKey
      historyBefore <- snapshots
      results <- if simultaneous then concurrently (map action [firstKey,secondKey])
        else mapM action [firstKey,secondKey]
      readIORef calls `shouldReturn` 0
      mapM_ assertLegacyRefundDenied results
      snapshots `shouldReturn` historyBefore
      assertLegacyStripeRefundState pool fixture "pending" "paid" 3 "issued"

  forM_ ["pending","rejected","processing","approved"] $ \otherStatus ->
    it ("counts all legacy history when refusing an ambiguous approval: other=" <> T.unpack otherStatus) $ \pool -> do
      fixture@(eventKey,orderKey,targetKey) <- legacyStripeRefundFixture pool 1000
      otherKey <- legacyStripeDuplicateRefund pool targetKey
      runSqlPool (rawExecute
        "UPDATE ticket_refund_request SET status=?,stripe_refund_id=\
        \ CASE WHEN ? IN ('processing','approved') THEN 're_synthetic_historical_observation' ELSE NULL END,\
        \ processed_at=CASE WHEN ?='approved' THEN now() ELSE NULL END WHERE id=?"
        [PersistText otherStatus,PersistText otherStatus,PersistText otherStatus,
         PersistInt64 (fromSqlKey otherKey)]) pool
      when (otherStatus == "approved") $ runSqlPool (do
        -- Legacy partial completion retired the whole order; preserve that
        -- historical snapshot without claiming its allocation is correct.
        rawExecute "UPDATE event_ticket_order SET status='refunded' WHERE id=?"
          [PersistInt64 (fromSqlKey orderKey)]
        rawExecute "UPDATE event_ticket SET status='refunded' WHERE order_ref_id=?"
          [PersistInt64 (fromSqlKey orderKey)]
        rawExecute "UPDATE event_ticket_tier SET quantity_sold=0 WHERE id=\
          \(SELECT tier_id FROM event_ticket_order WHERE id=?)"
          [PersistInt64 (fromSqlKey orderKey)]) pool
      env <- legacyStripeRefundEnv pool True
      calls <- newIORef (0 :: Int)
      let provider _ _ _ = atomicModifyIORef' calls (\count -> (count+1,()))
            >> pure (Left "synthetic unavailable response")
          (approve,_) = legacyStripeRefundHandlers provider
      historyBefore <- legacyStripeRequestHistory pool orderKey
      result <- runHandler (runReaderT
        (approve (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey targetKey))) env)
      readIORef calls `shouldReturn` 0
      assertLegacyRefundDenied result
      legacyStripeRequestHistory pool orderKey `shouldReturn` historyBefore
      let retired = otherStatus == "approved"
      assertLegacyStripeRefundState pool fixture "pending"
        (if retired then "refunded" else "paid") (if retired then 0 else 3)
        (if retired then "refunded" else "issued")

  it "serializes simultaneous legacy refund request creation for one order" $ \pool -> do
    (eventKey,orderKey) <- runSqlPool legacyStripeRefundOrderFixture pool
    locked <- newEmptyMVar
    release <- newEmptyMVar
    holderFinished <- newEmptyMVar
    firstFinished <- newEmptyMVar
    secondFinished <- newEmptyMVar
    let (_,request) = socialRefundHandlers (AuthedUser (toSqlKey 1) [Admin] mempty Nothing Nothing)
        action = runHandler (runReaderT
          (request (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey orderKey))
            (TD.RefundRequestDTO (Just "Simultaneous synthetic request") (Just 12515)))
          (Env pool (error "Refund request creation must not contact a provider")))
        holdInserts = runSqlPool (do
          rawExecute "LOCK TABLE ticket_refund_request IN SHARE MODE" []
          liftIO $ putMVar locked ()
          liftIO $ takeMVar release) pool
        releaseInserts = do
          _ <- tryPutMVar release ()
          pure ()
    -- Pool size is four: one lock holder, two handlers and one observer.
    -- Old handlers both read absence and then wait on INSERT. With the order
    -- lock, the second handler waits before its existence check instead.
    bracket (forkFinally holdInserts (putMVar holderFinished)) (\worker ->
      releaseInserts >> awaitLegacyRefundWorker worker holderFinished) $ \_ -> do
      Timeout.timeout 5000000 (readMVar locked) `shouldReturn` Just ()
      bracket (forkFinally action (putMVar firstFinished)) (\worker ->
        releaseInserts >> awaitLegacyRefundWorker worker firstFinished) $ \_ -> do
        bracket (forkFinally action (putMVar secondFinished)) (\worker ->
          releaseInserts >> awaitLegacyRefundWorker worker secondFinished) $ \_ -> do
          Timeout.timeout 5000000 (waitForLegacyRequestWaiters pool 2 100)
            `shouldReturn` Just True
          releaseInserts
          results <- forM [firstFinished,secondFinished] $ \finished -> do
            outcome <- Timeout.timeout 5000000 (readMVar finished)
            case outcome of
              Just (Right value) -> pure value
              Just (Left failure) -> expectationFailure (show failure) >> fail "Request worker failed"
              Nothing -> expectationFailure "Request worker did not finish" >> fail "Request worker timed out"
          length (rights results) `shouldBe` 1
          length [() | Left failure <- results, errHTTPCode failure == 409] `shouldBe` 1
          forM_ (rights results) $ \response -> do
            TD.refundStatus response `shouldBe` "pending"
            TD.refundAmountCents response `shouldBe` 12515
          runSqlPool (rawSql
            "SELECT status,amount_cents,stripe_refund_id,processed_at FROM ticket_refund_request\
            \ WHERE order_id=? ORDER BY id"
            [PersistInt64 (fromSqlKey orderKey)]) pool
            `shouldReturn` [(Single ("pending" :: Text),Single (12515 :: Int64),
              Single (Nothing :: Maybe Text),Single (Nothing :: Maybe UTCTime))]

  forM_ [("paid state",0,400),("buyer",1,403),("amount",2,400),("organizer",3,403)] $
    \(scenario,mutation,expectedStatus) ->
    it ("rechecks the current " <> scenario <> " before inserting a legacy refund request") $ \pool -> do
      (eventKey,orderKey) <- runSqlPool legacyStripeRefundOrderFixture pool
      -- Buyer1 and organizer2 must be independent authority paths. Otherwise
      -- changing the buyer would still leave actor1 authorized as organizer.
      runSqlPool (rawExecute "UPDATE social_event SET organizer_party_id='2' WHERE id=?"
        [PersistInt64 (fromSqlKey eventKey)]) pool
      locked <- newEmptyMVar
      release <- newEmptyMVar
      holderFinished <- newEmptyMVar
      requestFinished <- newEmptyMVar
      let actor = if mutation == (3 :: Int) then 2 else 1
          (_,request) = socialRefundHandlers (AuthedUser (toSqlKey actor) [Admin] mempty Nothing Nothing)
          action = runHandler (runReaderT
            (request (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey orderKey))
              (TD.RefundRequestDTO (Just "Synthetic stale snapshot") (Just 12515)))
            (Env pool (error "Refund request must not contact a provider")))
          holdMutation = runSqlPool (do
            _ <- rawSql "SELECT id FROM social_event WHERE id=? FOR UPDATE"
              [PersistInt64 (fromSqlKey eventKey)] :: SqlPersistT IO [Single Int64]
            _ <- rawSql "SELECT id FROM event_ticket_order WHERE id=? FOR UPDATE"
              [PersistInt64 (fromSqlKey orderKey)] :: SqlPersistT IO [Single Int64]
            case mutation of
              0 -> rawExecute "UPDATE event_ticket_order SET status='refunded' WHERE id=?"
                [PersistInt64 (fromSqlKey orderKey)]
              1 -> rawExecute "UPDATE event_ticket_order SET buyer_party_id='2' WHERE id=?"
                [PersistInt64 (fromSqlKey orderKey)]
              2 -> rawExecute "UPDATE event_ticket_order SET amount_cents=10000 WHERE id=?"
                [PersistInt64 (fromSqlKey orderKey)]
              _ -> rawExecute "UPDATE social_event SET organizer_party_id='1' WHERE id=?"
                [PersistInt64 (fromSqlKey eventKey)]
            rawExecute "LOCK TABLE ticket_refund_request IN SHARE MODE" []
            liftIO $ putMVar locked ()
            liftIO $ takeMVar release) pool
          releaseMutation = do
            _ <- tryPutMVar release ()
            pure ()
      bracket (forkFinally holdMutation (putMVar holderFinished)) (\worker ->
        releaseMutation >> awaitLegacyRefundWorker worker holderFinished) $ \_ -> do
        Timeout.timeout 5000000 (readMVar locked) `shouldReturn` Just ()
        bracket (forkFinally action (putMVar requestFinished)) (\worker ->
          releaseMutation >> awaitLegacyRefundWorker worker requestFinished) $ \_ -> do
          Timeout.timeout 5000000 (waitForLegacyRequestWaiters pool 1 100)
            `shouldReturn` Just True
          releaseMutation
          result <- Timeout.timeout 5000000 (readMVar requestFinished)
          case result of
            Just (Right (Left failure)) -> errHTTPCode failure `shouldBe` expectedStatus
            Just (Right (Right _)) -> expectationFailure "A stale request snapshot authorized an insertion"
            Just (Left failure) -> expectationFailure (show failure)
            Nothing -> expectationFailure "Request did not finish after mutation committed"
          runSqlPool (rawSql "SELECT count(*)::bigint FROM ticket_refund_request WHERE order_id=?"
            [PersistInt64 (fromSqlKey orderKey)]) pool `shouldReturn` [Single (0 :: Int64)]

  forM_ [False,True] $ \organizesEvent ->
    it ("preserves legacy organizer authority without an administrator ownership bypass: " <>
        show organizesEvent) $ \pool -> do
      (eventKey,orderKey) <- runSqlPool legacyStripeRefundOrderFixture pool
      when organizesEvent $ runSqlPool (rawExecute
        "UPDATE social_event SET organizer_party_id='2' WHERE id=?"
        [PersistInt64 (fromSqlKey eventKey)]) pool
      let (_,request) = socialRefundHandlers (AuthedUser (toSqlKey 2) [Admin] mempty Nothing Nothing)
      result <- runHandler (runReaderT
        (request (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey orderKey))
          (TD.RefundRequestDTO (Just "Synthetic organizer support request") (Just 1000)))
        (Env pool (error "Request authority checks must not contact a provider")))
      if organizesEvent then do
        response <- requireRight result
        TD.refundStatus response `shouldBe` "pending"
        TD.refundAmountCents response `shouldBe` 1000
      else case result of
        Left failure -> errHTTPCode failure `shouldBe` 403
        Right _ -> expectationFailure "An unrelated administrator cannot request a legacy buyer's refund"

  forM_ [Nothing,Just 1000,Just 12515] $ \amount ->
    it ("preserves legacy request amounts including full default and partial: " <> show amount) $ \pool -> do
      (eventKey,orderKey) <- runSqlPool legacyStripeRefundOrderFixture pool
      let (_,request) = socialRefundHandlers (AuthedUser (toSqlKey 1) [Admin] mempty Nothing Nothing)
      response <- runHandler (runReaderT
        (request (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey orderKey))
          (TD.RefundRequestDTO Nothing amount))
        (Env pool (error "Request creation does not need provider configuration"))) >>= requireRight
      TD.refundStatus response `shouldBe` "pending"
      TD.refundAmountCents response `shouldBe` maybe 12515 id amount

  forM_ [-1,0,12516] $ \amount ->
    it ("rejects an invalid legacy refund request amount without insertion: " <> show amount) $ \pool -> do
      (eventKey,orderKey) <- runSqlPool legacyStripeRefundOrderFixture pool
      let (_,request) = socialRefundHandlers (AuthedUser (toSqlKey 1) [Admin] mempty Nothing Nothing)
      result <- runHandler (runReaderT
        (request (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey orderKey))
          (TD.RefundRequestDTO Nothing (Just amount)))
        (Env pool (error "Invalid requests must not contact a provider")))
      case result of
        Left failure -> errHTTPCode failure `shouldBe` 400
        Right _ -> expectationFailure "Invalid refund amount inserted a request"
      runSqlPool (rawSql "SELECT count(*)::bigint FROM ticket_refund_request WHERE order_id=?"
        [PersistInt64 (fromSqlKey orderKey)]) pool `shouldReturn` [Single (0 :: Int64)]

  forM_ [False,True] $ \rejected ->
    it ("preserves refusal of a prior legacy request, rejected=" <> show rejected) $ \pool -> do
      (eventKey,orderKey,refundKey) <- legacyStripeRefundFixture pool 12515
      let (_,request) = socialRefundHandlers (AuthedUser (toSqlKey 1) [Admin] mempty Nothing Nothing)
      when rejected $ do
        let (_,reject) = legacyStripeRefundHandlers (\_ _ _ -> fail "Rejection cannot call a provider")
        _ <- runHandler (runReaderT
          (reject (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey refundKey))
            (TD.RejectionReasonDTO "Synthetic rejection before another request"))
          (Env pool (error "Rejection cannot need provider configuration"))) >>= requireRight
        pure ()
      result <- runHandler (runReaderT
        (request (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey orderKey))
          (TD.RefundRequestDTO Nothing (Just 12515)))
        (Env pool (error "Duplicate request cannot contact a provider")))
      case result of
        Left failure -> errHTTPCode failure `shouldBe` 409
        Right _ -> expectationFailure "A prior legacy request must prevent another insertion"
      runSqlPool (rawSql "SELECT count(*)::bigint FROM ticket_refund_request WHERE order_id=?"
        [PersistInt64 (fromSqlKey orderKey)]) pool `shouldReturn` [Single (1 :: Int64)]

  it "allows only one provider call across eight approvals and later retries" $ \pool -> do
    fixture@(eventKey,_,refundKey) <- legacyStripeRefundFixture pool 1000
    env <- legacyStripeRefundEnv pool True
    calls <- newIORef (0 :: Int)
    let provider _ _ _ = atomicModifyIORef' calls (\count -> (count+1,()))
          >> pure (Left "synthetic accepted refund with lost response")
        (approve,reject) = legacyStripeRefundHandlers provider
        action = runHandler (runReaderT (approve (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey refundKey))) env)
    results <- concurrently (replicate 8 action)
    readIORef calls `shouldReturn` 1
    length [() | Left failure <- results, errHTTPCode failure == 409] `shouldBe` 7
    results `shouldSatisfy` all isLeft
    action >>= assertLegacyRefundDenied
    runHandler (runReaderT (reject (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey refundKey))
      (TD.RejectionReasonDTO "Cannot release an uncertain refund")) env)
      >>= assertLegacyRefundDenied
    readIORef calls `shouldReturn` 1
    assertLegacyStripeRefundState pool fixture "processing" "paid" 3 "issued"

  forM_ ["transport exception","invalid JSON"] $ \scenario ->
    it ("retains the durable claim after " <> T.unpack scenario) $ \pool -> do
      fixture@(eventKey,_,refundKey) <- legacyStripeRefundFixture pool 1000
      env <- legacyStripeRefundEnv pool True
      calls <- newIORef (0 :: Int)
      let provider _ _ _ = do
            atomicModifyIORef' calls (\count -> (count+1,()))
            if scenario == "transport exception"
              then throwIO (userError "synthetic lost refund response")
              else pure (Right (A.object []))
          (approve,_) = legacyStripeRefundHandlers provider
          action = runHandler (runReaderT (approve (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey refundKey))) env)
      -- Both a translated HTTP refusal and a propagated synchronous I/O failure
      -- are failures; neither may reset the committed execution claim.
      first <- try action :: IO (Either IOException (Either ServerError TD.RefundDTO))
      first `shouldSatisfy` either (const True) isLeft
      action >>= assertLegacyRefundDenied
      readIORef calls `shouldReturn` 1
      assertLegacyStripeRefundState pool fixture "processing" "paid" 3 "issued"

  it "denies rejection and another approval while the provider response is outstanding" $ \pool -> do
    fixture@(eventKey,_,refundKey) <- legacyStripeRefundFixture pool 1000
    env <- legacyStripeRefundEnv pool True
    entered <- newEmptyMVar
    release <- newEmptyMVar
    finished <- newEmptyMVar
    calls <- newIORef (0 :: Int)
    let provider _ _ _ = do
          atomicModifyIORef' calls (\count -> (count+1,()))
          putMVar entered ()
          takeMVar release
          pure (Left "synthetic response lost after provider acceptance")
        (approve,reject) = legacyStripeRefundHandlers provider
        action = runHandler (runReaderT (approve (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey refundKey))) env)
    -- A broken execution guard must produce a bounded assertion failure, not a
    -- second callback blocked forever on the first callback's release signal.
    -- Always release and join our initial worker, even if an assertion fails.
    bracket (forkFinally action (putMVar finished)) (\worker -> do
      _ <- tryPutMVar release ()
      stopped <- Timeout.timeout 5000000 (readMVar finished)
      case stopped of
        Just _ -> pure ()
        Nothing -> do
          killThread worker
          joined <- Timeout.timeout 5000000 (readMVar finished)
          case joined of
            Just _ -> pure ()
            Nothing -> expectationFailure "Refund worker did not terminate after cancellation") $ \_ -> do
      Timeout.timeout 5000000 (takeMVar entered) `shouldReturn` Just ()
      rejection <- Timeout.timeout 5000000 $ runHandler (runReaderT
        (reject (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey refundKey))
          (TD.RejectionReasonDTO "Concurrent rejection")) env)
      case rejection of
        Just denied -> assertLegacyRefundDenied denied
        Nothing -> expectationFailure "Rejection waited for the outstanding provider response"
      repeated <- Timeout.timeout 5000000 action
      case repeated of
        Just denied -> assertLegacyRefundDenied denied
        Nothing -> expectationFailure "Repeated approval reached the blocked provider callback"
      assertLegacyStripeRefundState pool fixture "processing" "paid" 3 "issued"
    result <- Timeout.timeout 5000000 (takeMVar finished)
    case result of
      Just (Right refused) -> refused `shouldSatisfy` isLeft
      Just (Left failure) -> expectationFailure (show failure)
      Nothing -> expectationFailure "Refund callback did not finish after release"
    readIORef calls `shouldReturn` 1

  it "rejects a stale rejection after waiting for the refund execution claim to commit" $ \pool -> do
    fixture@(eventKey,_,refundKey) <- legacyStripeRefundFixture pool 1000
    env <- legacyStripeRefundEnv pool True
    holding <- newEmptyMVar
    release <- newEmptyMVar
    claimFinished <- newEmptyMVar
    rejectFinished <- newEmptyMVar
    let claim = runSqlPool (do
          rows <- rawSql
            "UPDATE ticket_refund_request SET status='processing'\
            \ WHERE id=? AND status='pending' RETURNING id"
            [PersistInt64 (fromSqlKey refundKey)] :: SqlPersistT IO [Single Int64]
          unless (rows == [Single (fromSqlKey refundKey)]) $ fail "Claim fixture must update its one pending request"
          [Single pid] <- rawSql "SELECT pg_backend_pid()::bigint" []
          liftIO $ putMVar holding (pid :: Int64)
          liftIO $ takeMVar release) pool
        (_,reject) = legacyStripeRefundHandlers (\_ _ _ -> fail "Rejection must never call Stripe")
        rejectAction = runHandler (runReaderT
          (reject (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey refundKey))
            (TD.RejectionReasonDTO "Stale rejection read pending before claim committed")) env)
        releaseClaim = do
          _ <- tryPutMVar release ()
          pure ()
    bracket (forkFinally claim (putMVar claimFinished)) (\worker ->
      releaseClaim >> awaitLegacyRefundWorker worker claimFinished) $ \_ -> do
      holder <- Timeout.timeout 5000000 (takeMVar holding)
      holderPid <- maybe (fail "Claim did not reach its uncommitted row lock") pure holder
      -- The actual handler reads the old committed pending state, then waits on
      -- its UPDATE. Observe that lock wait before releasing the competing claim;
      -- merely seeing processing on a later read would not test a stale writer.
      bracket (forkFinally rejectAction (putMVar rejectFinished)) (\worker ->
        releaseClaim >> awaitLegacyRefundWorker worker rejectFinished) $ \_ -> do
        waiting <- Timeout.timeout 5000000 (waitForLegacyRefundLock pool holderPid 100)
        waiting `shouldBe` Just True
        releaseClaim
        claimed <- Timeout.timeout 5000000 (readMVar claimFinished)
        case claimed of
          Just (Right ()) -> pure ()
          Just (Left failure) -> expectationFailure (show failure)
          Nothing -> expectationFailure "Claim transaction did not commit after release"
        rejected <- Timeout.timeout 5000000 (readMVar rejectFinished)
        case rejected of
          Just (Right result) -> assertLegacyRefundDenied result
          Just (Left failure) -> expectationFailure (show failure)
          Nothing -> expectationFailure "Stale rejection did not finish after claim commit"
        assertLegacyStripeRefundState pool fixture "processing" "paid" 3 "issued"

  it "never calls the provider for a rejected request" $ \pool -> do
    fixture@(eventKey,_,refundKey) <- legacyStripeRefundFixture pool 1000
    env <- legacyStripeRefundEnv pool True
    calls <- newIORef (0 :: Int)
    let provider _ _ _ = atomicModifyIORef' calls (\count -> (count+1,()))
          >> pure (Left "Rejected refund must not be submitted")
        (approve,reject) = legacyStripeRefundHandlers provider
    rejected <- runHandler (runReaderT (reject (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey refundKey))
      (TD.RejectionReasonDTO "Request declined before execution")) env) >>= requireRight
    TD.refundStatus rejected `shouldBe` "rejected"
    runHandler (runReaderT (approve (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey refundKey))) env)
      >>= assertLegacyRefundDenied
    readIORef calls `shouldReturn` 0
    assertLegacyStripeRefundState pool fixture "rejected" "paid" 3 "issued"

  it "leaves a request pending when Stripe configuration is unavailable" $ \pool -> do
    fixture@(eventKey,_,refundKey) <- legacyStripeRefundFixture pool 1000
    env <- legacyStripeRefundEnv pool False
    calls <- newIORef (0 :: Int)
    let provider _ _ _ = atomicModifyIORef' calls (\count -> (count+1,()))
          >> pure (Left "Unconfigured provider must not be called")
        (approve,_) = legacyStripeRefundHandlers provider
    result <- runHandler (runReaderT (approve (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey refundKey))) env)
    result `shouldSatisfy` isLeft
    readIORef calls `shouldReturn` 0
    assertLegacyStripeRefundState pool fixture "pending" "paid" 3 "issued"

  let observedId = "re_synthetic_legacy_observed" :: Text
      field name value = A.Object . KM.insert name value
      missing name = A.Object . KM.delete name
      held name change = (name,change,Just observedId)
      responseCases =
        [ held "id-only response" (\_ -> A.object ["id" A..= observedId])
        , held "missing object type" (missing "object")
        , held "null object type" (field "object" A.Null)
        , held "wrong object type" (field "object" (A.String "charge"))
        , held "non-text object type" (field "object" (A.Number 1))
        , held "missing status" (missing "status")
        , held "null status" (field "status" A.Null)
        , held "non-text status" (field "status" (A.Bool True))
        , held "pending status" (field "status" (A.String "pending"))
        , held "requires-action status" (field "status" (A.String "requires_action"))
        , held "failed status" (field "status" (A.String "failed"))
        , held "canceled status" (field "status" (A.String "canceled"))
        , held "unknown status" (field "status" (A.String "SYNTHETIC_PRIVATE_NEW_STATUS"))
        , held "uppercase success status" (field "status" (A.String "SUCCEEDED"))
        , held "padded success status" (field "status" (A.String " succeeded "))
        , held "missing amount" (missing "amount")
        , held "null amount" (field "amount" A.Null)
        , held "text amount" (field "amount" (A.String "12515"))
        , held "fractional minor-unit amount" (field "amount" (A.Number 12515.5))
        , held "zero amount" (field "amount" (A.Number 0))
        , held "negative amount" (field "amount" (A.Number (-12515)))
        , held "different amount" (field "amount" (A.Number 12516))
        , held "amount outside signed storage" (field "amount" (A.Number 9223372036854775808))
        , held "missing currency" (missing "currency")
        , held "null currency" (field "currency" A.Null)
        , held "non-text currency" (field "currency" (A.Number 1))
        , held "different currency" (field "currency" (A.String "eur"))
        , held "uppercase currency" (field "currency" (A.String "USD"))
        , held "padded currency" (field "currency" (A.String " usd "))
        , held "short currency" (field "currency" (A.String "us"))
        , held "missing payment intent" (missing "payment_intent")
        , held "null payment intent" (field "payment_intent" A.Null)
        , held "non-text payment intent" (field "payment_intent" (A.Number 1))
        , held "different payment intent" (field "payment_intent" (A.String "pi_synthetic_other_order"))
        , held "unexpected expanded payment intent" (\object ->
            field "payment_intent" (A.object ["id" A..= KM.lookup "payment_intent" object]) object)
        , ("missing refund id",missing "id",Nothing)
        , ("null refund id",field "id" A.Null,Nothing)
        , ("non-text refund id",field "id" (A.Number 1),Nothing)
        , ("empty refund id",field "id" (A.String ""),Nothing)
        , ("padded refund id",field "id" (A.String " re_synthetic_padded "),Nothing)
        , ("control character in refund id",field "id" (A.String "re_synthetic\nprivate"),Nothing)
        , ("non-ASCII refund id",field "id" (A.String "re_synthetic_\241"),Nothing)
        , ("oversized refund id",field "id" (A.String (T.replicate 129 "x")),Nothing)
        , ("non-object response",const A.Null,Nothing)
        ]
  forM_ responseCases $ \(scenario,change,expectedObservedId) ->
    it ("holds unverified Stripe completion evidence: " <> scenario) $ \pool -> do
      fixture@(eventKey,_,refundKey) <- legacyStripeRefundFixture pool 12515
      env <- legacyStripeRefundEnv pool True
      calls <- newIORef (0 :: Int)
      let provider _ paymentIntent amount = do
            atomicModifyIORef' calls (\count -> (count+1,()))
            pure (Right (change (KM.fromList
              [("id",A.String observedId),("object",A.String "refund")
              ,("status",A.String "succeeded"),("amount",A.toJSON amount)
              ,("currency",A.String "usd"),("payment_intent",A.String paymentIntent)])))
          (approve,_) = legacyStripeRefundHandlers provider
          action = runHandler (runReaderT
            (approve (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey refundKey))) env)
      result <- action
      case result of
        Left failure -> do
          errHTTPCode failure `shouldBe` 502
          BS.unpack (BL.toStrict (errBody failure)) `shouldNotContain` "SYNTHETIC_PRIVATE"
          BS.unpack (BL.toStrict (errBody failure)) `shouldNotContain` T.unpack observedId
        Right response -> expectationFailure
          ("Unverified provider evidence completed a refund: " <> show response)
      -- The provider ID is observed correlation, not proof of intent/money
      -- binding. Retain it for investigation without marking completion.
      runSqlPool (rawSql
        "SELECT stripe_refund_id,processed_at FROM ticket_refund_request WHERE id=?"
        [PersistInt64 (fromSqlKey refundKey)]) pool
        `shouldReturn` [(Single expectedObservedId,Single (Nothing :: Maybe UTCTime))]
      assertLegacyStripeRefundState pool fixture "processing" "paid" 3 "issued"
      action >>= assertLegacyRefundDenied
      readIORef calls `shouldReturn` 1

  it "preserves a conflicting observed provider id without completing or posting again" $ \pool -> do
    fixture@(eventKey,_,refundKey) <- legacyStripeRefundFixture pool 12515
    env <- legacyStripeRefundEnv pool True
    calls <- newIORef (0 :: Int)
    let priorId = "re_synthetic_prior_observation" :: Text
        returnedId = "re_synthetic_conflicting_response" :: Text
        provider _ paymentIntent amount = do
          atomicModifyIORef' calls (\count -> (count+1,()))
          -- Model another observer recording an ID after the durable claim and
          -- before this provider response. An incompatible response cannot erase it.
          changed <- runSqlPool (rawSql
            "UPDATE ticket_refund_request SET stripe_refund_id=?\
            \ WHERE id=? AND status='processing' RETURNING id"
            [PersistText priorId,PersistInt64 (fromSqlKey refundKey)]) pool
          (changed :: [Single Int64]) `shouldBe` [Single (fromSqlKey refundKey)]
          pure (Right (A.object ["id" A..= returnedId,"object" A..= ("refund" :: Text)
            ,"status" A..= ("succeeded" :: Text),"amount" A..= amount
            ,"currency" A..= ("usd" :: Text),"payment_intent" A..= paymentIntent]))
        (approve,_) = legacyStripeRefundHandlers provider
        action = runHandler (runReaderT
          (approve (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey refundKey))) env)
    result <- action
    case result of
      Left failure -> errHTTPCode failure `shouldBe` 502
      Right _ -> expectationFailure "Conflicting provider identity must not complete a refund"
    runSqlPool (rawSql
      "SELECT stripe_refund_id,processed_at FROM ticket_refund_request WHERE id=?"
      [PersistInt64 (fromSqlKey refundKey)]) pool
      `shouldReturn` [(Single (Just priorId),Single (Nothing :: Maybe UTCTime))]
    assertLegacyStripeRefundState pool fixture "processing" "paid" 3 "issued"
    action >>= assertLegacyRefundDenied
    readIORef calls `shouldReturn` 1

  it "retains observed evidence and rolls back completion after a synthetic bigint projection failure" $ \pool -> do
    fixture@(eventKey,orderKey,refundKey) <- legacyStripeRefundFixture pool 12515
    env <- legacyStripeRefundEnv pool True
    calls <- newIORef (0 :: Int)
    let returnedId = "re_synthetic_projection_failure" :: Text
        provider _ paymentIntent amount = do
          atomicModifyIORef' calls (\count -> (count+1,()))
          -- Full schema has a bigint sold counter, without a nonnegative CHECK.
          -- Force its later decrement to underflow using only our fixture row.
          -- This checks transaction rollback, not business inventory validity.
          runSqlPool (rawExecute
            "UPDATE event_ticket_tier SET quantity_sold=?\
            \ WHERE id=(SELECT tier_id FROM event_ticket_order WHERE id=?)"
            [PersistInt64 (minBound :: Int64),PersistInt64 (fromSqlKey orderKey)]) pool
          pure (Right (A.object ["id" A..= returnedId,"object" A..= ("refund" :: Text)
            ,"status" A..= ("succeeded" :: Text),"amount" A..= amount
            ,"currency" A..= ("usd" :: Text),"payment_intent" A..= paymentIntent]))
        (approve,_) = legacyStripeRefundHandlers provider
        action = runHandler (runReaderT
          (approve (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey refundKey))) env)
    -- Restore only the counter deliberately corrupted by this fault fixture,
    -- after checking rollback evidence, including when an assertion fails.
    bracket (pure ()) (\_ -> runSqlPool (rawExecute
      "UPDATE event_ticket_tier SET quantity_sold=3\
      \ WHERE id=(SELECT tier_id FROM event_ticket_order WHERE id=?)"
      [PersistInt64 (fromSqlKey orderKey)]) pool) $ \_ -> do
      result <- action
      case result of
        Left failure -> errHTTPCode failure `shouldBe` 502
        Right _ -> expectationFailure "A failed inventory projection must roll back refund completion"
      runSqlPool (rawSql
        "SELECT stripe_refund_id,processed_at FROM ticket_refund_request WHERE id=?"
        [PersistInt64 (fromSqlKey refundKey)]) pool
        `shouldReturn` [(Single (Just returnedId),Single (Nothing :: Maybe UTCTime))]
      assertLegacyStripeRefundState pool fixture "processing" "paid" minBound "issued"
      action >>= assertLegacyRefundDenied
      readIORef calls `shouldReturn` 1

  forM_
    [ ("releases inventory once for a successful full refund and denies replay", "re_synthetic_legacy")
    , ("accepts exactly 128 visible ASCII refund-id characters without assuming a prefix", T.replicate 128 "x")
    ] $ \(scenario,returnedId) -> it scenario $ \pool -> do
      fixture@(eventKey,_,refundKey) <- legacyStripeRefundFixture pool 12515
      env <- legacyStripeRefundEnv pool True
      calls <- newIORef (0 :: Int)
      let provider _ paymentIntent amount = do
            atomicModifyIORef' calls (\count -> (count+1,()))
            pure (Right (A.object ["id" A..= (returnedId :: Text)
              ,"object" A..= ("refund" :: Text)
              ,"status" A..= ("succeeded" :: Text),"amount" A..= amount
              ,"currency" A..= ("usd" :: Text),"payment_intent" A..= paymentIntent]))
          (approve,_) = legacyStripeRefundHandlers provider
          action = runHandler (runReaderT
            (approve (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey refundKey))) env)
      first <- action >>= requireRight
      TD.refundStatus first `shouldBe` "approved"
      runSqlPool (rawSql "SELECT stripe_refund_id FROM ticket_refund_request WHERE id=?"
        [PersistInt64 (fromSqlKey refundKey)]) pool
        `shouldReturn` [Single (Just returnedId)]
      action >>= assertLegacyRefundDenied
      readIORef calls `shouldReturn` 1
      assertLegacyStripeRefundState pool fixture "approved" "refunded" 0 "refunded"

  forM_ ([(sold,3) | sold <- [-1,0,1,2]] <>
    [(3,quantity) | quantity <- [0,-3,minBound :: Int64]]) $ \(sold,quantity) ->
    it ("holds invalid legacy inventory without completion: sold=" <> show sold <>
        ", quantity=" <> show quantity) $ \pool -> do
      fixture@(eventKey,orderKey,refundKey) <- legacyStripeRefundFixture pool 12515
      env <- legacyStripeRefundEnv pool True
      calls <- newIORef (0 :: Int)
      let provider _ paymentIntent amount = do
            atomicModifyIORef' calls (\count -> (count+1,()))
            pure (Right (A.object ["id" A..= ("re_synthetic_inventory" :: Text)
              ,"object" A..= ("refund" :: Text),"status" A..= ("succeeded" :: Text)
              ,"amount" A..= amount,"currency" A..= ("usd" :: Text)
              ,"payment_intent" A..= paymentIntent]))
          (approve,_) = legacyStripeRefundHandlers provider
          action = runHandler (runReaderT
            (approve (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey refundKey))) env)
          setSnapshot counter count = runSqlPool (do
            rawExecute "UPDATE event_ticket_tier SET quantity_sold=? WHERE id=\
              \(SELECT tier_id FROM event_ticket_order WHERE id=?)"
              [PersistInt64 counter,PersistInt64 (fromSqlKey orderKey)]
            rawExecute "UPDATE event_ticket_order SET quantity=? WHERE id=?"
              [PersistInt64 count,PersistInt64 (fromSqlKey orderKey)]) pool
      bracket (setSnapshot sold quantity) (\_ -> setSnapshot 3 3) $ \_ -> do
        result <- action
        case result of
          Left failure -> errHTTPCode failure `shouldBe` 502
          Right _ -> expectationFailure "Invalid inventory must not authorize refund completion"
        assertLegacyStripeRefundState pool fixture "processing" "paid" sold "issued"
        runSqlPool (rawSql
          "SELECT stripe_refund_id,processed_at FROM ticket_refund_request WHERE id=?"
          [PersistInt64 (fromSqlKey refundKey)]) pool
          `shouldReturn` [(Single (Just ("re_synthetic_inventory" :: Text)),Single (Nothing :: Maybe UTCTime))]
        action >>= assertLegacyRefundDenied
        readIORef calls `shouldReturn` 1

  it "holds a refund whose tier belongs to a different event" $ \pool -> do
    fixture@(eventKey,orderKey,refundKey) <- legacyStripeRefundFixture pool 12515
    (otherEvent,_,_) <- legacyStripeRefundFixture pool 12515
    env <- legacyStripeRefundEnv pool True
    calls <- newIORef (0 :: Int)
    let provider _ paymentIntent amount = do
          atomicModifyIORef' calls (\count -> (count+1,()))
          pure (Right (A.object ["id" A..= ("re_synthetic_foreign_tier" :: Text)
            ,"object" A..= ("refund" :: Text),"status" A..= ("succeeded" :: Text)
            ,"amount" A..= amount,"currency" A..= ("usd" :: Text)
            ,"payment_intent" A..= paymentIntent]))
        (approve,_) = legacyStripeRefundHandlers provider
        action = runHandler (runReaderT
          (approve (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey refundKey))) env)
        setEvent :: TM.SocialEventId -> IO ()
        setEvent target = runSqlPool (rawExecute
          "UPDATE event_ticket_tier SET event_id=?,code=? WHERE id=\
          \(SELECT tier_id FROM event_ticket_order WHERE id=?)"
          [PersistInt64 (fromSqlKey target),PersistText (if target == eventKey then "test"
            else "synthetic-foreign-tier-" <> keyText (fromSqlKey orderKey)),
           PersistInt64 (fromSqlKey orderKey)]) pool
    bracket (setEvent otherEvent) (\_ -> setEvent eventKey) $ \_ -> do
      result <- action
      case result of
        Left failure -> errHTTPCode failure `shouldBe` 502
        Right _ -> expectationFailure "A foreign-event tier must not release inventory"
      assertLegacyStripeRefundState pool fixture "processing" "paid" 3 "issued"
      action >>= assertLegacyRefundDenied
      readIORef calls `shouldReturn` 1

  forM_ [4,maxBound :: Int64] $ \sold ->
    it ("releases exactly the positive order quantity from sold=" <> show sold) $ \pool -> do
      fixture@(eventKey,orderKey,refundKey) <- legacyStripeRefundFixture pool 12515
      env <- legacyStripeRefundEnv pool True
      let provider _ paymentIntent amount = pure (Right (A.object
            ["id" A..= ("re_synthetic_inventory_boundary" :: Text)
            ,"object" A..= ("refund" :: Text),"status" A..= ("succeeded" :: Text)
            ,"amount" A..= amount,"currency" A..= ("usd" :: Text)
            ,"payment_intent" A..= paymentIntent]))
          (approve,_) = legacyStripeRefundHandlers provider
          setCounter counter = runSqlPool (rawExecute
            "UPDATE event_ticket_tier SET quantity_sold=? WHERE id=\
            \(SELECT tier_id FROM event_ticket_order WHERE id=?)"
            [PersistInt64 counter,PersistInt64 (fromSqlKey orderKey)]) pool
      -- Keep the deliberately extreme stock snapshot local to this fixture.
      -- Successful full retirement leaves zero sold tickets after assertions;
      -- failure also cleans up only this fixture's counter.
      bracket (setCounter sold) (\_ -> setCounter 0) $ \_ -> do
        result <- runHandler (runReaderT
          (approve (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey refundKey))) env) >>= requireRight
        TD.refundStatus result `shouldBe` "approved"
        assertLegacyStripeRefundState pool fixture "approved" "refunded" (sold-3) "refunded"

  forM_ [3,6 :: Int64] $ \sold ->
    it ("serializes distinct legacy refunds sharing a tier with sold=" <> show sold) $ \pool -> do
      first@(eventKey,orderKey,_) <- legacyStripeRefundFixture pool 12515
      (_,otherOrder,otherRefund) <- legacyStripeRefundFixture pool 12515
      let second = (eventKey,otherOrder,otherRefund)
      runSqlPool (do
        [Single unusedTier] <- rawSql "SELECT tier_id FROM event_ticket_order WHERE id=?"
          [PersistInt64 (fromSqlKey otherOrder)]
        rawExecute "UPDATE event_ticket_order SET event_id=?,tier_id=\
          \(SELECT tier_id FROM event_ticket_order WHERE id=?) WHERE id=?"
          [PersistInt64 (fromSqlKey eventKey),PersistInt64 (fromSqlKey orderKey),PersistInt64 (fromSqlKey otherOrder)]
        rawExecute "UPDATE event_ticket SET event_id=?,tier_ref_id=\
          \(SELECT tier_id FROM event_ticket_order WHERE id=?) WHERE order_ref_id=?"
          [PersistInt64 (fromSqlKey eventKey),PersistInt64 (fromSqlKey orderKey),PersistInt64 (fromSqlKey otherOrder)]
        -- Relocate this fixture's stock along with its order and tickets;
        -- the original tier is now empty and must not retain phantom stock.
        cleared <- rawSql "UPDATE event_ticket_tier SET quantity_sold=0 WHERE id=?\
          \ AND NOT EXISTS(SELECT 1 FROM event_ticket_order WHERE tier_id=?)\
          \ AND NOT EXISTS(SELECT 1 FROM event_ticket WHERE tier_ref_id=?) RETURNING id"
          (replicate 3 (PersistInt64 unusedTier))
        unless (cleared == [Single unusedTier]) $ fail "Only the fixture's empty tier may be cleared"
        rawExecute "UPDATE event_ticket_tier SET quantity_sold=? WHERE id=\
          \(SELECT tier_id FROM event_ticket_order WHERE id=?)"
          [PersistInt64 sold,PersistInt64 (fromSqlKey orderKey)]) pool
      env <- legacyStripeRefundEnv pool True
      ready <- newEmptyMVar
      calls <- newIORef (0 :: Int)
      let provider _ paymentIntent amount = do
            arrived <- atomicModifyIORef' calls (\count -> (count+1,count+1))
            when (arrived == 2) $ putMVar ready ()
            both <- Timeout.timeout 5000000 (readMVar ready)
            unless (both == Just ()) $ fail "Both distinct refunds must reach provider IO"
            pure (Right (A.object ["id" A..= ("re_" <> paymentIntent)
              ,"object" A..= ("refund" :: Text),"status" A..= ("succeeded" :: Text)
              ,"amount" A..= amount,"currency" A..= ("usd" :: Text)
              ,"payment_intent" A..= paymentIntent]))
          (approve,_) = legacyStripeRefundHandlers provider
          action :: LegacyStripeRefundFixture -> IO (Either ServerError TD.RefundDTO)
          action (_,_,refundKey) = runHandler (runReaderT
            (approve (keyText (fromSqlKey eventKey)) (keyText (fromSqlKey refundKey))) env)
      results <- concurrently (map action [first,second])
      length (rights results) `shouldBe` fromIntegral (sold `div` 3)
      readIORef calls `shouldReturn` 2
      forM_ (zip [first,second] results) $ \(fixture, result) -> do
        case result of
          Right response -> do
            TD.refundStatus response `shouldBe` "approved"
            assertLegacyStripeRefundState pool fixture "approved" "refunded" 0 "refunded"
          Left failure -> do
            errHTTPCode failure `shouldBe` 502
            assertLegacyStripeRefundState pool fixture "processing" "paid" 0 "issued"
        action fixture >>= assertLegacyRefundDenied
      readIORef calls `shouldReturn` 2

type LegacyStripeRefundFixture = (TM.SocialEventId,TM.EventTicketOrderId,TM.TicketRefundRequestId)

legacyStripeDuplicateRefund :: ConnectionPool -> TM.TicketRefundRequestId -> IO TM.TicketRefundRequestId
legacyStripeDuplicateRefund pool originalKey = runSqlPool (do
  [Single key] <- rawSql
    "INSERT INTO ticket_refund_request(order_id,requested_by_party_id,reason,amount_cents,status)\
    \ SELECT order_id,requested_by_party_id,reason,amount_cents,'pending' FROM ticket_refund_request\
    \ WHERE id=? RETURNING id" [PersistInt64 (fromSqlKey originalKey)]
  pure key) pool

legacyStripeRequestHistory :: ConnectionPool -> TM.EventTicketOrderId -> IO [Single Text]
legacyStripeRequestHistory pool key = runSqlPool (rawSql
  "SELECT row_to_json(request)::text FROM ticket_refund_request request WHERE order_id=? ORDER BY id"
  [PersistInt64 (fromSqlKey key)]) pool

legacyStripeRefundFixture :: ConnectionPool -> Int64 -> IO LegacyStripeRefundFixture
legacyStripeRefundFixture pool amount = runSqlPool (do
  (eventKey,orderKey) <- legacyStripeRefundOrderFixture
  [Single refundKey] <- rawSql
    "INSERT INTO ticket_refund_request(order_id,requested_by_party_id,reason,amount_cents,status)\
    \ VALUES (?,'1','Synthetic legacy Stripe request',?,'pending') RETURNING id"
    [PersistInt64 (fromSqlKey orderKey),PersistInt64 amount]
  pure (eventKey,orderKey,refundKey)) pool

legacyStripeRefundOrderFixture :: SqlPersistT IO (TM.SocialEventId,TM.EventTicketOrderId)
legacyStripeRefundOrderFixture = do
  -- This is a legacy order snapshot: its stored paid total is 12515 even though
  -- three current tier prices sum to 12516. No canonical runtime is attached,
  -- and this execution-fence regression does not reprice historical orders.
  [Single orderKey] <- rawSql "SELECT payment_test.ticket_order(3)" []
  [(Single eventKey,Single tierKey)] <- rawSql
    "SELECT event_id,tier_id FROM event_ticket_order WHERE id=?"
    [PersistInt64 (fromSqlKey orderKey)]
  rawExecute "UPDATE event_ticket_order SET status='paid',stripe_payment_intent_id=? WHERE id=?"
    [PersistText ("pi_synthetic_legacy_" <> keyText (fromSqlKey orderKey)),PersistInt64 (fromSqlKey orderKey)]
  forM_ [1..3 :: Int] $ \index -> rawExecute
    "INSERT INTO event_ticket(event_id,tier_ref_id,order_ref_id,code,status,current_holder_party_id,original_holder_party_id,created_at,updated_at)\
    \ VALUES (?,?,?,?,'issued','1','1',now(),now())"
    [PersistInt64 (fromSqlKey eventKey),PersistInt64 (tierKey :: Int64),PersistInt64 (fromSqlKey orderKey),
     PersistText ("legacy-stripe-" <> keyText (fromSqlKey orderKey) <> "-" <> T.pack (show index))]
  pure (eventKey,orderKey)

legacyStripeRefundEnv :: ConnectionPool -> Bool -> IO Env
legacyStripeRefundEnv pool configured = do
  config <- Config.loadConfig
  pure (Env pool (config
    { Config.stripeSecretKey = if configured then Just "sk_test_synthetic_legacy" else Nothing
    , Config.stripeWebhookSecret = if configured then Just "whsec_synthetic_legacy" else Nothing
    }))

legacyStripeRefundHandlers
  :: (Stripe.StripeConfig -> Text -> Int -> IO (Either Text A.Value))
  -> (Text -> Text -> ReaderT Env Handler TD.RefundDTO,
      Text -> Text -> TD.RejectionReasonDTO -> ReaderT Env Handler TD.RefundDTO)
legacyStripeRefundHandlers provider =
  case Social.socialEventsServerWithStripeRefund provider
    (AuthedUser (toSqlKey 2) [Admin] mempty Nothing Nothing) of
    _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> tickets :<|> _ ->
      case tickets of
        _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> approve :<|> reject :<|> _ ->
          (approve,reject)

assertLegacyRefundDenied :: Either ServerError TD.RefundDTO -> Expectation
assertLegacyRefundDenied result = case result of
  Left failure -> errHTTPCode failure `shouldBe` 409
  Right _ -> expectationFailure "A terminal or uncertain refund must not execute again"

awaitLegacyRefundWorker :: ThreadId -> MVar a -> IO ()
awaitLegacyRefundWorker worker finished = do
  stopped <- Timeout.timeout 5000000 (readMVar finished)
  case stopped of
    Just _ -> pure ()
    Nothing -> do
      killThread worker
      joined <- Timeout.timeout 5000000 (readMVar finished)
      case joined of
        Just _ -> pure ()
        Nothing -> expectationFailure "Refund fixture worker did not terminate after cancellation"

waitForLegacyRefundLock :: ConnectionPool -> Int64 -> Int -> IO Bool
waitForLegacyRefundLock _ _ 0 = pure False
waitForLegacyRefundLock pool holderPid remaining = do
  rows <- runSqlPool (rawSql
    "SELECT EXISTS (SELECT 1 FROM pg_stat_activity activity\
    \ WHERE activity.datname=current_database() AND activity.pid<>pg_backend_pid()\
    \ AND activity.wait_event_type='Lock' AND ?::integer=ANY(pg_blocking_pids(activity.pid))\
    \ AND lower(activity.query) LIKE '%ticket_refund_request%')"
    [PersistInt64 holderPid]) pool :: IO [Single Bool]
  if rows == [Single True] then pure True else do
    threadDelay 25000
    waitForLegacyRefundLock pool holderPid (remaining-1)

waitForLegacyRequestWaiters :: ConnectionPool -> Int64 -> Int -> IO Bool
waitForLegacyRequestWaiters _ _ 0 = pure False
waitForLegacyRequestWaiters pool expected remaining = do
  rows <- runSqlPool (rawSql
    "SELECT count(*)::bigint FROM pg_stat_activity\
    \ WHERE datname=current_database() AND pid<>pg_backend_pid() AND wait_event_type='Lock'\
    \ AND (lower(query) LIKE '%ticket_refund_request%'\
    \ OR ((lower(query) LIKE '%event_ticket_order%' OR lower(query) LIKE '%social_event%')\
    \ AND lower(query) LIKE '%for update%'))"
    []) pool :: IO [Single Int64]
  if rows == [Single expected] then pure True else do
    threadDelay 25000
    waitForLegacyRequestWaiters pool expected (remaining-1)

assertLegacyStripeRefundState
  :: ConnectionPool -> LegacyStripeRefundFixture -> Text -> Text -> Int64 -> Text -> Expectation
assertLegacyStripeRefundState pool (_,orderKey,refundKey) refundState orderState sold ticketState = do
  runSqlPool (rawSql
    "SELECT request.status,orders.status,tier.quantity_sold\
    \ FROM ticket_refund_request request JOIN event_ticket_order orders ON orders.id=request.order_id\
    \ JOIN event_ticket_tier tier ON tier.id=orders.tier_id WHERE request.id=?"
    [PersistInt64 (fromSqlKey refundKey)]) pool
    `shouldReturn` [(Single refundState,Single orderState,Single sold)]
  runSqlPool (rawSql "SELECT status FROM event_ticket WHERE order_ref_id=? ORDER BY id"
    [PersistInt64 (fromSqlKey orderKey)]) pool `shouldReturn` replicate 3 (Single ticketState)

keyText :: Int64 -> Text
keyText = T.pack . show

socialRefundHandlers :: AuthedUser
  -> (Text -> Text -> TD.TicketOrderStatusUpdateDTO -> ReaderT Env Handler TD.TicketOrderDTO,
      Text -> Text -> TD.RefundRequestDTO -> ReaderT Env Handler TD.RefundDTO)
socialRefundHandlers user = case Social.socialEventsServer user of
  _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> tickets :<|> _ ->
    case tickets of
      _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> setStatus :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> _ :<|> request :<|> _ ->
        (setStatus,request)

ticketAllocationCreation :: Checkout.VerifiedPayment -> Text -> Int64 -> Refund.RefundCreation
ticketAllocationCreation payment suffix amount = Refund.RefundCreation
  { Refund.rcCheckout=Checkout.vpCheckout payment, Refund.rcPaymentAttempt=Checkout.vpAttempt payment
  , Refund.rcProvider=Checkout.ProviderPayPal, Refund.rcEnvironment=Checkout.CheckoutSandbox
  , Refund.rcMerchantRef=Checkout.vpMerchantRef payment, Refund.rcAmountMinor=amount, Refund.rcCurrency="USD"
  , Refund.rcReasonCode="customer_request", Refund.rcIdempotencyKey=Checkout.checkoutReferenceId (Checkout.vpCheckout payment) <> suffix
  , Refund.rcRequestedBy=1, Refund.rcCreatedAt=Checkout.vpOccurredAt payment }

ticketAllocationFixture :: ConnectionPool
  -> IO (Checkout.VerifiedPayment,TM.SocialEventId,TM.EventTicketOrderId,[TM.EventTicketId])
ticketAllocationFixture = ticketAllocationFixtureForProvider Checkout.ProviderPayPal

ticketAllocationFixtureForProvider :: Checkout.PaymentProvider -> ConnectionPool
  -> IO (Checkout.VerifiedPayment,TM.SocialEventId,TM.EventTicketOrderId,[TM.EventTicketId])
ticketAllocationFixtureForProvider provider = ticketAllocationFixtureWithPayment provider True

ticketAllocationFixtureWithPayment :: Checkout.PaymentProvider -> Bool -> ConnectionPool
  -> IO (Checkout.VerifiedPayment,TM.SocialEventId,TM.EventTicketOrderId,[TM.EventTicketId])
ticketAllocationFixtureWithPayment provider = ticketAllocationFixtureWithResource provider "capture"

ticketAllocationFixtureWithResource :: Checkout.PaymentProvider -> Text -> Bool -> ConnectionPool
  -> IO (Checkout.VerifiedPayment,TM.SocialEventId,TM.EventTicketOrderId,[TM.EventTicketId])
ticketAllocationFixtureWithResource = ticketAllocationFixtureWithLegacyPaid False

ticketAllocationFixtureWithLegacyPaid :: Bool -> Checkout.PaymentProvider -> Text -> Bool -> ConnectionPool
  -> IO (Checkout.VerifiedPayment,TM.SocialEventId,TM.EventTicketOrderId,[TM.EventTicketId])
ticketAllocationFixtureWithLegacyPaid legacyPaid provider resourceType verified pool = do
  (eventKey,tierKey,orderKey) <- runSqlPool (do
    [Single orderKey] <- rawSql "SELECT payment_test.ticket_order(3)" []
    -- Historical legacy paid state is permitted only before runtime creation;
    -- retain the canonical paid-transition guard throughout this setup.
    when legacyPaid $ rawExecute
      "UPDATE event_ticket_order SET status='paid',purchased_at=NOW() WHERE id=?"
      [PersistInt64 (fromSqlKey orderKey)]
    [(Single eventKey,Single tierKey)] <- rawSql
      "SELECT event_id,tier_id FROM event_ticket_order WHERE id=?"
      [PersistInt64 (fromSqlKey orderKey)]
    pure (eventKey,tierKey,orderKey)) pool
  payment <- captureFixtureForDomainWithOrder "event_ticket_order" resourceType Checkout.AttemptProcessing [12515]
    (Just (T.pack (show (fromSqlKey orderKey)))) pool provider
  when (resourceType == "capture") $ do
    _ <- runSqlPool (Checkout.bindProviderResource (captureBinding payment)
      { Checkout.pbcResourceType="order",Checkout.pbcProviderResource="order-" <> Checkout.checkoutReferenceId (Checkout.vpCheckout payment) }) pool >>= requireRight
    pure ()
  tickets <- runSqlPool (do
    tickets <- forM [1..3 :: Int] $ \index -> do
      [Single key] <- rawSql
        "INSERT INTO event_ticket(event_id,tier_ref_id,order_ref_id,code,status,current_holder_party_id,original_holder_party_id,created_at,updated_at) VALUES (?,?,?,?,'issued','1','1',now(),now()) RETURNING id"
        [PersistInt64 (fromSqlKey eventKey),PersistInt64 tierKey,PersistInt64 (fromSqlKey orderKey),
         PersistText (Checkout.checkoutReferenceId (Checkout.vpCheckout payment) <> T.pack (show index))]
      pure key
    attachTicketRuntime (Checkout.checkoutReferenceId (Checkout.vpCheckout payment))
      (T.pack (show (fromSqlKey orderKey))) 0 0
    pure tickets) pool
  when verified $ do
    runSqlPool (Checkout.recordVerifiedPayment payment) pool `shouldReturn` Right True
    _ <- runSqlPool (Social.finalizePaidTicketOrder (Checkout.vpOccurredAt payment) orderKey) pool
    pure ()
  pure (payment,eventKey,orderKey,tickets)

-- A signed refund/reversal is not terminally ignored merely because its
-- capture binding has not committed yet. Reprocessing must retain the fence.
latePaypalRefundSpec :: SpecWith ConnectionPool
latePaypalRefundSpec = describe "out-of-order PayPal refunds" $
  forM_ ["PAYMENT.CAPTURE.REFUNDED","PAYMENT.CAPTURE.REVERSED"] $ \eventType ->
    it ("retries before binding then reconciles " <> T.unpack eventType) $ \pool -> do
      (unbound,eventKey,orderKey,(ticket:_)) <-
        ticketAllocationFixtureWithResource Checkout.ProviderPayPal "order" False pool
      let attempt = Checkout.vpAttempt unbound
          checkoutId = Checkout.checkoutReferenceId (Checkout.vpCheckout unbound)
          capture = "late-" <> Checkout.paymentAttemptReferenceId attempt
          envelope = Storefront.PaypalWebhookEnvelope ("WH-" <> checkoutId) eventType notificationTime
            (A.object ["id" A..= (if eventType == "PAYMENT.CAPTURE.REFUNDED" then "refund-" <> checkoutId else capture)
              , "status" A..= ("COMPLETED" :: Text)
              , "amount" A..= A.object ["currency_code" A..= ("USD" :: Text),"value" A..= ("125.15" :: Text)]
              , "links" A..= [A.object ["rel" A..= ("up" :: Text),"method" A..= ("GET" :: Text)
                  ,"href" A..= ("https://api.sandbox.paypal.com/v2/payments/captures/" <> capture)]]])
          process = Storefront.processPaypalWebhookEventIO
            (Env pool (error "Synthetic callback processing must not use configuration"))
            Checkout.CheckoutSandbox (Checkout.vpMerchantRef unbound) envelope notificationTime
      notification <- newNotification Checkout.ProviderPayPal
      stored <- storeNotification pool notification
        { Event.pecMerchantRef=Checkout.vpMerchantRef unbound
        , Event.pecProviderEventId=Storefront.pweEventId envelope
        , Event.pecEventType=eventType
        , Event.pecProviderResource=Storefront.paypalWebhookResourceId envelope
        , Event.pecRawPayload=encodeStrict (A.object
            [ "id" A..= Storefront.pweEventId envelope, "event_type" A..= eventType
            , "create_time" A..= notificationTime, "resource" A..= Storefront.pweResource envelope ])
        } >>= requireRight
      forM_ [1..8] $ \attemptCount -> do
        let retryAt = addUTCTime (fromIntegral (attemptCount * 86400)) notificationTime
        runSqlPool (Event.claimProviderEvent (Event.pesReference stored) retryAt) pool
          `shouldReturn` Event.ProviderEventClaimed attemptCount
        process `shouldReturn` Storefront.PaypalEventRetry "PayPal capture binding is not available yet"
        runSqlPool (Event.markProviderEventRetry (Event.pesReference stored) attemptCount
          "PayPal capture binding is not available yet" retryAt) pool `shouldReturn` (attemptCount == 8)
      runSqlPool (Event.claimProviderEvent (Event.pesReference stored)
        (addUTCTime (9 * 86400) notificationTime)) pool
        `shouldReturn` Event.ProviderEventAlreadyHandled "dead_letter"
      -- Exhausted deliveries retain one durable, merchant-scoped fence. No
      -- accounting amounts are invented before the capture is known.
      runSqlPool (rawSql "SELECT count(*) FROM commerce_reconciliation_exception WHERE provider='paypal' AND provider_reference=? AND internal_reference=? AND expected_amount_minor IS NULL"
        [PersistText capture,PersistText ("unmatched-capture:" <> capture)]) pool
        `shouldReturn` [Single (1 :: Int64)]
      _ <- runSqlPool (Checkout.bindProviderResource Checkout.ProviderBindingCreation
        { Checkout.pbcAttempt=attempt,Checkout.pbcCheckout=Checkout.vpCheckout unbound
        , Checkout.pbcProvider=Checkout.ProviderPayPal,Checkout.pbcEnvironment=Checkout.CheckoutSandbox
        , Checkout.pbcMerchantRef=Checkout.vpMerchantRef unbound,Checkout.pbcResourceType="capture"
        , Checkout.pbcProviderResource=capture,Checkout.pbcResourcePath=Nothing
        , Checkout.pbcOrderReference=T.pack (show (fromSqlKey orderKey)),Checkout.pbcAmountMinor=12515,Checkout.pbcCurrency="USD"
        , Checkout.pbcStage=Checkout.AttemptProcessing,Checkout.pbcOccurredAt=notificationTime
        , Checkout.pbcCorrelationId="late-capture-binding" }) pool >>= requireRight
      -- Complete the actual late capture, then exercise the real admission
      -- helper without replaying the dead-letter webhook or duplicating its SQL.
      let payment = unbound { Checkout.vpResourceType="capture", Checkout.vpProviderResource=capture }
      runSqlPool (Checkout.recordVerifiedPayment payment) pool `shouldReturn` Right True
      -- The payment store synchronizes canonical payment state; the real
      -- fulfillment operation completes the paid/issued admission precondition.
      _ <- runSqlPool (Social.finalizePaidTicketOrder notificationTime orderKey) pool
      admitted <- runSqlPool (Admission.admitTicket "1" eventKey
        (Admission.AdmissionById ticket) notificationTime) pool
      fmap (TM.eventTicketStatus . entityVal) admitted `shouldBe` Left Admission.AdmissionPaymentReview
      process `shouldReturn` Storefront.PaypalEventProcessed (Just checkoutId)
        (Just (Checkout.paymentAttemptReferenceId attempt)) Nothing
      process `shouldReturn` Storefront.PaypalEventProcessed (Just checkoutId)
        (Just (Checkout.paymentAttemptReferenceId attempt)) Nothing
      runSqlPool (rawSql "SELECT count(*) FROM commerce_reconciliation_exception WHERE provider='paypal' AND provider_reference=? AND internal_reference=?"
        [PersistText capture,PersistText (T.pack (show (fromSqlKey orderKey)))]) pool `shouldReturn` [Single (1 :: Int64)]
