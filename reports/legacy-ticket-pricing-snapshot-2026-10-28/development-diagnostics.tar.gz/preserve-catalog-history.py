import json,subprocess
from pathlib import Path

root=Path('/private/tmp/tdf-correctness-cycle-20261028')
path='docs/catalog-persistence/catalog-list-decisions.json'
parent_bytes=subprocess.check_output(['git','show','f302b3da87a5e40934b2bdf5426dff64b686be49:'+path],cwd=root)
parent=json.loads(parent_bytes)
current=json.loads((root/path).read_text());by_id={r['id']:r for r in current['decisions']}
assert len(by_id)==len(current['decisions'])==len(parent['decisions'])==1353
assert set(by_id)=={r['id'] for r in parent['decisions']}
changes=[];ordered=[]
for old in parent['decisions']:
    new=by_id[old['id']];a=dict(old);b=dict(new)
    ae=a.pop('evidence',{});be=b.pop('evidence',{})
    assert a==b,old['id']
    if ae!=be:
        ac=dict(ae);bc=dict(be);before=ac.pop('consumerCount');after=bc.pop('consumerCount')
        assert ac==bc,(old['id'],ae,be)
        changes.append({'id':old['id'],'beforeConsumerCount':before,'afterConsumerCount':after})
    ordered.append(new)
for key in parent:
    if key not in ('decisions','reconciliation'):assert parent[key]==current[key],key
allowed={'preservedDecisions':(1352,1207),'reviewedByPolicy':(0,146),'reviewBatch':('legacy-refund-history-20261028','deterministic-policy-v3')}
for key in parent['reconciliation'].keys()|current['reconciliation'].keys():
    a=parent['reconciliation'].get(key);b=current['reconciliation'].get(key)
    if a!=b:assert key in allowed and (a,b)==allowed[key],key
current['reconciliation']=parent['reconciliation']
current['decisions']=ordered
if not changes:
    assert current==parent
    (root/path).write_bytes(parent_bytes)
else:(root/path).write_text(json.dumps(current,indent=2,ensure_ascii=False)+'\n')
receipt={'normativeParentRowsPreserved':1353,'parentOrderPreserved':True,'newIds':0,'evidenceOnlyChanges':changes,'entireDecisionFileByteIdentical':not changes,'restoredGeneratedSummaryFields':list(allowed)}
Path('/private/tmp/tdf-ticket-price-snapshot-receipts-20261028/catalog-preservation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'normativeRows':1353,'evidenceOnlyRows':len(changes),'orderRestored':True}))
