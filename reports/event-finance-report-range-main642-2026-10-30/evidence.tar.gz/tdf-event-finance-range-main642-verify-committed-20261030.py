from pathlib import Path, PurePosixPath
import subprocess, json, hashlib, tarfile, gzip, io
w=Path('/private/tmp/tdf-event-finance-range-main642-20261030');o=Path('/private/tmp/tdf-event-finance-range-main642-qualification-20261030')
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=w)
e=git('rev-parse','HEAD').decode().strip();m=json.loads((o/'preparation-state.json').read_text())['sourceCommit']
assert not git('status','--porcelain').strip()
assert git('show','-s','--format=%P',e).decode().split()==[m]
rp='reports/event-finance-report-range-main642-2026-10-30.json';rd='reports/event-finance-report-range-main642-2026-10-30/'
paths=[rp,rd+'evidence.tar.gz',rd+'manifest.json',rd+'independent-review.txt']
assert set(git('diff','--name-only',m,e).decode().splitlines())==set(paths)
blobs={}
for p in paths:
 b=git('show',e+':'+p);assert b==(w/p).read_bytes();blobs[p]={'sha256':sha(b),'gitBlob':git('rev-parse',e+':'+p).decode().strip(),'bytes':len(b)}
r=json.loads((w/rp).read_text());a=r['archive'];manifest=json.loads((w/a['manifest']).read_text());body=(w/a['path']).read_bytes()
assert r['sourceCommit']==manifest['sourceCommit']==m
assert sha(body)==a['sha256']==manifest['archiveSha256'] and len(body)==a['bytes']==manifest['archiveBytes']
entries=manifest['files'];by={x['path']:x for x in entries};assert len(by)==len(entries)==a['innerFiles']
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(body)),mode='r:') as archive:
 members=archive.getmembers();assert len({x.name for x in members})==len(members)==len(by)
 for entry in members:
  p=PurePosixPath(entry.name);assert entry.isfile() and not p.is_absolute() and '..' not in p.parts and entry.name in by
  b=archive.extractfile(entry).read();item=by[entry.name];assert len(b)==item['bytes']==entry.size and sha(b)==item['sha256']
  assert b==(o/entry.name).read_bytes(),entry.name
review=git('show',e+':'+rd+'independent-review.txt');assert review==(o/'tdf-event-finance-range-main642-final-review-20261030.txt').read_bytes()
# Report-only child has exactly four report paths changed. This establishes parity for all source,
# metadata, tests, historical reports, submodule pins, workflows and dependency trees without exclusions.
result={'qualifiedSource':m,'evidenceHead':e,'exactlyFourReportOnlyBlobs':True,'allOtherSourceAndHistoricalTreesExactQualifiedSource':True,'archiveMembersVerified':len(by),'archiveSha256':sha(body),'archiveBytes':len(body),'committedBlobs':blobs,'independentReviewSha256':sha(review),'worktreeClean':True,'hostedHeadGitIdentity':'Requires fresh published-head CI; not borrowed from local source binary'}
p=Path('/Users/macpro/GitHub/tdf-app/.private/event-finance-range-main642-20261030');p.mkdir(exist_ok=True)
(p/'final-committed-evidence.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['qualifiedSource','evidenceHead','archiveMembersVerified','archiveSha256','archiveBytes','worktreeClean']},indent=2))
