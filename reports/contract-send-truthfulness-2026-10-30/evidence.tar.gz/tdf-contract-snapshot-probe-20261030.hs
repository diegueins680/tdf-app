{-# LANGUAGE OverloadedStrings #-}
import qualified Data.ByteString.Lazy as L
import qualified Data.ByteString as S
import System.IO.Temp
import Control.Exception
main = withSystemTempDirectory "tdf-contract-snapshot-" $ \d -> do
 let p=d++"/contract.json"
 L.writeFile p "old"
 before <- L.readFile p
 write <- try (L.writeFile p "new") :: IO (Either IOException ())
 putStrLn ("lazySnapshotWrite="++show write)
 print before
 S.writeFile p "old"
 strictBefore <- S.readFile p
 strictWrite <- try (S.writeFile p "new") :: IO (Either IOException ())
 putStrLn ("strictSnapshotWrite="++show strictWrite)
 strictAfter <- S.readFile p
 print (strictBefore,strictAfter)
