from pathlib import Path
import json,subprocess
w=Path('/private/tmp/tdf-contract-send-truthfulness-20261030');o=Path('/private/tmp/tdf-contract-send-qualification-20261030');c=json.loads((o/'controls.json').read_text());assert c['actualVariants']==2 and c['intendedAssertionFailures']==7
state={'phase':'CANONICAL_METADATA'}
def save():(o/'preparation-state.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,cmd):
 with (o/(label+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=w,stdout=log,stderr=subprocess.STDOUT)
 state[label+'Exit']=r.returncode;save();print(label+' actualexit '+str(r.returncode),flush=True);assert r.returncode==0,label
save();run('mobile-init',['git','submodule','update','--init','--checkout','--','tdf-mobile']);run('metadata',['python3','/private/tmp/tdf-contract-send-metadata-20261030.py']);run('diff-check',['git','diff','--check'])
paths=['tdf-hq/src/TDF/Contracts/Server.hs','tdf-hq/test/TDF/Contracts/DeliverySpec.hs','tdf-hq/test/Spec.hs','tdf-hq/tdf-hq.cabal','docs/event-operations/gap-matrix.md','formal/system/contract-send-truthfulness.md','formal/system/requirements.json','formal/system/inventory.json','formal/system/traceability.json','docs/catalog-persistence/reports/static-list-inventory.json','docs/catalog-persistence/reports/list-consumer-matrix.csv']
run('stage-source',['git','add','--',*paths]);run('commit-source',['git','commit','-m','fix(contracts): refuse unimplemented email delivery truthfully']);state['sourceCommit']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip();state['phase']='CLEAN_SOURCE_COMMITTED';save()
