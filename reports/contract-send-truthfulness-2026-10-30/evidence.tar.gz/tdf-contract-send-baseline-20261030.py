from pathlib import Path
import subprocess,os,json,hashlib,signal,datetime,re
w=Path('/private/tmp/tdf-contract-send-truthfulness-20261030');o=Path('/private/tmp/tdf-contract-send-qualification-20261030');base='e1cec5b59723c2ff9828ac4fce45abb930d73055';cache=Path('/private/tmp/tdf-contract-send-native-cache-20261030');assert not cache.exists();subprocess.run(['cp','-cR','/private/tmp/tdf-event-finance-currency-native-cache-20261029',str(cache)],check=True)
main=Path('/private/tmp/tdf-contract-send-main-20261030.hs');main.write_text('module Main (main) where\nimport Test.Hspec (hspec)\nimport qualified TDF.Contracts.DeliverySpec as Delivery\nmain :: IO ()\nmain = hspec Delivery.spec\n')
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env['PATH']='/Users/macpro/.ghcup/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin';env['STACK_ROOT']='/Users/macpro/.stack';sha=lambda b:hashlib.sha256(b).hexdigest();handler='tdf-hq/src/TDF/Contracts/Server.hs';assert (w/handler).read_bytes()==subprocess.check_output(['git','show',base+':'+handler],cwd=w)
inputs={p:sha((w/p).read_bytes()) for p in [handler,'tdf-hq/test/TDF/Contracts/DeliverySpec.hs','tdf-hq/test/Spec.hs','tdf-hq/tdf-hq.cabal','tdf-hq/stack.yaml','tdf-hq/stack.yaml.lock']};(o/'baseline-inputs.json').write_text(json.dumps({'sourceCommit':base,'productHandlerGitExact':True,'inputs':inputs},indent=2)+'\n')
binary=cache/'contract-delivery-tests';command=['/Users/macpro/.ghcup/bin/stack','exec','--','ghc','--make','-O0','-threaded','-Wall','-isrc','-itest','-odir',str(cache),'-hidir',str(cache),'-stubdir',str(cache),'-o',str(binary),str(main)];state={'sourceCommit':base,'phase':'BUILDING_BASELINE','command':command,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save():(o/'baseline-state.json').write_text(json.dumps(state,indent=2)+'\n')
def run(cmd,path,timeout):
 with path.open('w') as log:
  p=subprocess.Popen(cmd,cwd=w/'tdf-hq',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);state['activePID']=p.pid;save()
  try:return p.wait(timeout=timeout)
  except BaseException:
   if p.poll() is None:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   raise
save();state['buildExit']=run(command,o/'baseline-build.log',1800);save();assert state['buildExit']==0,'Compilation/setup error is not behavioralcounterexample';print('Nativebaseline build actualexit0',flush=True)
state['phase']='RUNNING_BASELINE';save();state['testExit']=run([str(binary)],o/'baseline-tests.log',120);save();raw=(o/'baseline-tests.log').read_text();assert state['testExit']==1 and '10 examples, 1 failure' in raw and 'Expected refused operation, got successful response' in raw and 'sent' in raw,raw[-4000:];assert all(sha((w/p).read_bytes())==h for p,h in inputs.items());state.update(phase='BASELINE_REAL_FALSE_SENT_COUNTEREXAMPLE',examples=10,assertionFailures=1,compatibilityPasses=9,binarySha256=sha(binary.read_bytes()),allInputsUnchanged=True);save();(o/'baseline-confirmed.json').write_text(json.dumps(state,indent=2)+'\n');print('10actualcases:1false-sentassertionfailure+9compatibilitypasses; originalmainhandlerunchanged',flush=True)
