from pathlib import Path
import json,subprocess
w=Path('/private/tmp/tdf-contract-send-truthfulness-20261030');o=Path('/private/tmp/tdf-contract-send-strict-qualification-20261030');state={'phase':'STRICT_SNAPSHOT_CANONICAL_METADATA'}
def save():(o/'preparation-state.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,cmd):
 with (o/(label+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=w,stdout=log,stderr=subprocess.STDOUT)
 state[label+'Exit']=r.returncode;save();print(label+' actualexit '+str(r.returncode),flush=True);assert r.returncode==0,label
save();run('metadata',['python3','/private/tmp/tdf-contract-send-strict-metadata-20261030.py']);run('diff-check',['git','diff','--check']);run('stage-reviewed-context',['git','add','--','tdf-hq/test/TDF/Contracts/DeliverySpec.hs','formal/system/contract-send-truthfulness.md','formal/system/inventory.json','formal/system/traceability.json','docs/catalog-persistence/reports/static-list-inventory.json','docs/catalog-persistence/reports/list-consumer-matrix.csv']);run('commit-reviewed-context',['git','commit','-m','test(contracts): use noninterfering strict file snapshots']);state['sourceCommit']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip();state['phase']='CLEAN_SOURCE_COMMITTED';save()
