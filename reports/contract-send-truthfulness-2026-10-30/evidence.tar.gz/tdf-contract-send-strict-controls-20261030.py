from pathlib import Path
import subprocess,json,hashlib,os,signal,re
w=Path('/private/tmp/tdf-contract-send-truthfulness-20261030');o=Path('/private/tmp/tdf-contract-send-strict-qualification-20261030');base=json.loads((o/'baseline-confirmed.json').read_text());p=w/'tdf-hq/src/TDF/Contracts/Server.hs';original=subprocess.check_output(['git','show','e1cec5b59723c2ff9828ac4fce45abb930d73055:tdf-hq/src/TDF/Contracts/Server.hs'],cwd=w);fixed=p.read_bytes();assert fixed==subprocess.check_output(['git','show','6e0076faa38b70844d7945f25cd5d80a714d0cf4:tdf-hq/src/TDF/Contracts/Server.hs'],cwd=w)
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env['PATH']='/Users/macpro/.ghcup/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin';env['STACK_ROOT']='/Users/macpro/.stack';sha=lambda b:hashlib.sha256(b).hexdigest();results=[];state={'phase':'CORRECTED_COMPONENT','sourceCommit':base['sourceCommit'],'results':results};binary=Path('/private/tmp/tdf-contract-send-native-cache-20261030/contract-delivery-tests')
def save():(o/'repair-control-state.json').write_text(json.dumps(state,indent=2)+'\n')
def run(cmd,path,timeout):
 with path.open('w') as log:
  child=subprocess.Popen(cmd,cwd=w/'tdf-hq',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);state['activePID']=child.pid;save()
  try:return child.wait(timeout=timeout)
  except BaseException:
   if child.poll() is None:
    os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
   raise

def check(label,n):
 state['phase']=label;save();build=run(base['command'],o/(label+'-build.log'),1800);assert build==0,'Not a behavioralcontrol until nativecompilation passes';code=run([str(binary)],o/(label+'-tests.log'),120);raw=(o/(label+'-tests.log')).read_text();assert re.search(r'10 examples, '+str(n)+r' failures?',raw) and code==(1 if n else 0),raw[-2500:]
 if label=='false-success':assert 'Expected refused operation, got successful response' in raw and 'sent' in raw
 if label=='store-mutation':assert 'MUTATED-CONTRACT' in raw and 'resource busy' not in raw and 'expected:' in raw
 if label=='validation-bypass':assert 'expected: 400' in raw and 'but got: 501' in raw
 results.append({'label':label,'sourceSha256':sha(p.read_bytes()),'buildExit':build,'testExit':code,'examples':10,'assertionFailures':n,'binarySha256':sha(binary.read_bytes()),'logSha256':sha((o/(label+'-tests.log')).read_bytes())});save();print(label+' actualexit '+str(code)+' assertionfailures '+str(n),flush=True)
try:
 check('corrected',0)
 p.write_bytes(original);check('false-success',1)
 text=fixed.decode();a=text.index('    sendH cid body = do');b=text.index('\npersistContract ::',a);text=text[:a]+'''    sendH _ _ =
      throwError err501 { errBody = "Contract email delivery is not implemented" }
'''+text[b:];p.write_text(text);check('validation-bypass',6)
 text=fixed.decode();needle='        Right (Just _) ->\n          throwError err501 { errBody = "Contract email delivery is not implemented" }';assert text.count(needle)==1;text=text.replace(needle,'        Right (Just _) -> do\n          liftIO $ BL.writeFile (contractPath contractId) "MUTATED-CONTRACT"\n          throwError err501 { errBody = "Contract email delivery is not implemented" }');p.write_text(text);check('store-mutation',1)
finally:p.write_bytes(fixed);assert p.read_bytes()==fixed
check('restored',0);state.update(phase='REPAIRED_TWO_CONTROLS_DETECTED_RESTORED',actualVariants=3,intendedAssertionFailures=8,sourceRestoredSha256=sha(fixed),limits='Realfilesystem/typedHandler finite tests; no delivery/authenticatedHTTP/PDFsuccess/PGclaim.');save();(o/'controls.json').write_text(json.dumps(state,indent=2)+'\n')
