module Main (main) where
import Test.Hspec (hspec)
import qualified TDF.Contracts.DeliverySpec as Delivery
main :: IO ()
main = hspec Delivery.spec
