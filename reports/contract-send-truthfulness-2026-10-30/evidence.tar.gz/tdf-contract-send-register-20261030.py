from pathlib import Path
import json,subprocess
w=Path('/private/tmp/tdf-contract-send-truthfulness-20261030');p=w/'formal/system/contract-send-truthfulness.md';p.write_text('''# Truthful unsupported contract delivery — MSG-CONTRACT-DELIVERY-001

Authority: the existing repository audit dated2026-09-14 and EO-038 gap matrix
identify fake contract-send success without delivery. The current Handler has no
email/queue implementation or dependency and only reads its file. A successful
sent response must not stand in for an action that never happened.

For the legacy file-backed send route, preserve ID/email/payload validation and
stored-contract existence/envelope validation in their established order. Invalid
input remains400, missing files404 and invalid stored envelopes500. After a valid
existing contract is loaded, unsupported email delivery returns HTTP501 with an
explicit not-implemented error; it never returns a successful sent/queued claim.
501 denotes an unimplemented function, rather than a temporary provider outage.

Contract creation/storage and PDF handling remain unchanged. No new provider,
queue, credential, email attempt, delivery receipt, persisted status or production
data mutation is introduced. EO-038's full versioned agreements, party acceptance
and actual delivery workflow remain unimplemented. This correction does not claim
that delivery now works or repair historical confirmation consequences.

Verification obligations: real typed Handler calls with valid contracts created
through the real create route inside owned temporary directories; validsend
refusal, unchanged stored bytes/file set,400/404/500 compatibility, successful
create/storage and pre-render PDF errors. Controls must detect restored false
success and bypassed validation. Full source/manifest/test registration and
canonical Stack qualification are bound separately to immutable commits.

Assumptions: trusted filesystem/compiler/Servant behavior, successful owned fixture
creation, sequential Hspec scheduling for temporary current-directory changes.
The fixture has no SMTP or database configuration; missing/corrupt PDF tests stop
before a PDF renderer. No successful PDF rendering, authenticated HTTP transport,
provider delivery, production filesystem/concurrency or complete refinement proof
follows from these finite tests. Scoped evidence is TESTED only.
''')
p=w/'formal/system/requirements.json';d=json.loads(p.read_text());old=json.loads(subprocess.check_output(['git','show','e1cec5b59723c2ff9828ac4fce45abb930d73055:formal/system/requirements.json'],cwd=w))['requirements'];assert d['requirements']==old
r={'id':'MSG-CONTRACT-DELIVERY-001','title':'Do not report unsupported contract email as sent','statement':'The file-backed contract send route must refuse unsupported delivery with501 after preserving existing input and stored-file validation; it must never claim sent/queued without an implementation.','domain':'MSG','authority':'Existing repository-audit-2026-09-14 fake-send finding and EO-038 gap; owner correctness/reliability mandate.','source':'formal/system/contract-send-truthfulness.md','contract':'formal/system/contract-send-truthfulness.md','property':'Validexistinglegacycontract+validrecipient+absentdeliveryimplementation impliesHTTP501, no successfulsent/queuedresult or storemutation;400/404/500 precedence and create/PDF behavior retained.','actors':['Authorized contract API caller','Contract recipient'],'preconditions':['Existing outer contract authorization unchanged','Current legacy Handler has no delivery/queue implementation'],'inputs':['RouteUUID','Email-only JSONpayload','File-backed storedcontract'],'state':{'initial':'Validated route request','terminal':['Existing400/404/500refusal','501unsupported-delivery refusal']},'allowedTransitions':['Validate before loading','Refuse absent functionality after successful file validation'],'forbiddenTransitions':['Claim sent or queued without implementation','Bypass established input/storage errors to returngenericunavailable','Modify a contract to simulate delivery'],'effects':['Owned read-only send filesystem access; no send/queue effect'],'authorization':'Outer production guard unchanged; directHandler tests do not prove authenticatedHTTP.','privacy':'Syntheticcontract/recipient fixtures only; no realprovider/messages or productionrecords.','concurrency':'No new production filesystem synchronization; test temporarycwd uses sequentialHspec.','idempotency':'Repeated unsupported requests cannot claim or create delivery effects.','failure':'501 for unsupportedfunction; existing400/404/500 validations retained.','recovery':'Implement actual reviewed delivery with receipts and tests before enabling successful delivery claims; do not alter historicalrecords to hide falseconfirmations.','observability':'Actual native handler failure/success-compatible logs, originalfake-success control and validation-bypass control.','implementation':['tdf-hq/src/TDF/Contracts/Server.hs'],'tests':['tdf-hq/test/TDF/Contracts/DeliverySpec.hs','tdf-hq/test/Spec.hs'],'formalModels':[],'verification':'Ten realhandler cases and source fault controls; current fullStack qualification recorded against exactcommits.','evidence':'formal/system/contract-send-truthfulness.md; reports/contract-send-truthfulness-2026-10-30.json','critical':True,'status':'specified and implemented','confidence':'Existing authoritativefake-send finding and actual native false-sent counterexample; no deliveryfeature claim.','ambiguity':['Actual delivery/versionedacceptance remains separate missingfunctionality underEO-038.','SuccessfulPDF/authenticatedHTTP/productionfilesystem/provider behavior not established by these focusedfixtures.'],'conformance':{'classification':'PARTIAL','reason':'Finite handler truthfulness/compatibility tests; complete implementation/refinement and deployment correspondence remain unproven.'}}
d['requirements'].append(r);p.write_text(json.dumps(d,indent=2)+'\n');assert len(d['requirements'])==len(old)+1;print('Preserved'+str(len(old))+'incoming requirements;newtotal'+str(len(d['requirements'])))
p=w/'docs/event-operations/gap-matrix.md';s=p.read_text();old='Current file-backed contract API lacks secure versions/party acceptance and contains placeholder/fake-send behavior.';new='Current file-backed contract API lacks secure versions/party acceptance. Legacy email delivery now refuses HTTP501 instead of claiming a send; actual delivery/versioned acceptance remain missing (MSG-CONTRACT-DELIVERY-001).';assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
