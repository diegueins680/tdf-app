# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: campaign-accessibility.spec.mjs >> Campaign controls expose row and column names at 320px @critical
- Location: e2e/web/campaign-accessibility.spec.mjs:7:3

# Error details

```
Error: Calendario

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 10

- Array []
+ Array [
+   Object {
+     "id": "color-contrast",
+     "targets": Array [
+       Array [
+         ".MuiTab-root.MuiTab-labelIcon.MuiTab-textColorPrimary:nth-child(3)",
+       ],
+     ],
+   },
+ ]
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - link "Saltar al contenido principal" [ref=e2]:
    - /url: "#main-content"
  - generic [ref=e3]:
    - generic [ref=e4]:
      - link "Saltar al contenido principal" [ref=e5]:
        - /url: "#main-content"
      - generic [ref=e6]:
        - banner [ref=e7]:
          - generic [ref=e8]:
            - button "Mostrar menú lateral" [ref=e9] [cursor=pointer]:
              - img [ref=e10]
            - generic [ref=e12]:
              - link "Buscar artistas y comunidad" [ref=e13] [cursor=pointer]:
                - /url: /buscar
                - img [ref=e14]
              - button "Buscar sección" [ref=e16] [cursor=pointer]:
                - img [ref=e18]
            - generic [ref=e20]:
              - button "Creación rápida" [ref=e21] [cursor=pointer]:
                - img [ref=e23]
              - button "Notificaciones" [ref=e25] [cursor=pointer]:
                - generic [ref=e26]:
                  - img [ref=e27]
                  - generic: "0"
              - button "Abrir menú de sesión" [ref=e29] [cursor=pointer]:
                - generic [ref=e30]: O
        - status [ref=e31]
        - main [ref=e32]:
          - generic [ref=e33]:
            - navigation "Migas de pan" [ref=e34]:
              - list [ref=e35]:
                - listitem [ref=e36]:
                  - link "Calendario" [ref=e37]:
                    - /url: /estudio/calendario
                - listitem [ref=e38]: /
                - listitem [ref=e39]:
                  - paragraph [ref=e40]: Campaña Domo
            - generic [ref=e41]:
              - generic [ref=e43]:
                - generic [ref=e44]:
                  - heading "TDF Sessions x Domo Pululahua" [level=3] [ref=e45]
                  - paragraph [ref=e46]: Centro operativo para convocatoria nacional, seguimiento de creativos, métricas, postulaciones y selección.
                - generic [ref=e47]:
                  - link "Formulario público" [ref=e48] [cursor=pointer]:
                    - /url: /live-sessions/registro
                    - img [ref=e50]
                    - text: Formulario público
                  - link "Intake interno" [ref=e52] [cursor=pointer]:
                    - /url: /estudio/live-sessions
                    - img [ref=e54]
                    - text: Intake interno
              - generic [ref=e57]:
                - generic [ref=e59]:
                  - generic [ref=e60]:
                    - generic [ref=e62]: Convocatoria nacional
                    - generic [ref=e64]: Solo 10 bandas
                    - generic [ref=e66]: Domo Pululahua
                  - generic [ref=e67]:
                    - heading "30 minutos. 4 cámaras. Un cráter. Tu banda." [level=2] [ref=e68]
                    - paragraph [ref=e69]: No es un videoclip. Es tu banda tocando de verdad en un lugar imposible de ignorar.
                  - generic [ref=e70]:
                    - link "Postula ahora" [ref=e71] [cursor=pointer]:
                      - /url: /live-sessions/registro
                      - img [ref=e73]
                      - text: Postula ahora
                    - link "Ver Domo" [ref=e75] [cursor=pointer]:
                      - /url: /domo-del-pululahua
                      - img [ref=e77]
                      - text: Ver Domo
                - generic [ref=e79]:
                  - generic [ref=e82]:
                    - img [ref=e84]
                    - paragraph [ref=e86]: Postulaciones
                    - heading "0" [level=5] [ref=e87]
                    - generic [ref=e88]: 0 calificadas
                  - generic [ref=e91]:
                    - img [ref=e93]
                    - paragraph [ref=e95]: Selección
                    - heading "0/10" [level=5] [ref=e96]
                    - generic [ref=e97]: 10 cupos restantes
                  - generic [ref=e100]:
                    - img [ref=e102]
                    - paragraph [ref=e104]: Costo por lead
                    - heading "—" [level=5] [ref=e105]
                    - generic [ref=e106]: — por calificada
                  - generic [ref=e109]:
                    - img [ref=e111]
                    - paragraph [ref=e113]: Día de campaña
                    - heading "1" [level=5] [ref=e114]
                    - generic [ref=e115]: Lanzamiento
                - generic [ref=e116]:
                  - tablist [ref=e120]:
                    - tab "Control" [ref=e121] [cursor=pointer]:
                      - img [ref=e122]
                      - text: Control
                    - tab "Calendario" [active] [selected] [ref=e125] [cursor=pointer]:
                      - img [ref=e126]
                      - text: Calendario
                    - tab "Creativos" [ref=e128] [cursor=pointer]:
                      - img [ref=e129]
                      - text: Creativos
                    - tab "Bandas" [ref=e131] [cursor=pointer]:
                      - img [ref=e132]
                      - text: Bandas
                    - tab "Copys" [ref=e134] [cursor=pointer]:
                      - img [ref=e135]
                      - text: Copys
                  - generic [ref=e142]:
                    - generic [ref=e143]:
                      - img [ref=e145]
                      - generic [ref=e147]:
                        - heading "Calendario de 21 días" [level=6] [ref=e148]
                        - paragraph [ref=e149]: 0/21 publicaciones marcadas como listas o publicadas.
                    - progressbar "Avance del calendario de campaña" [ref=e150]
                    - generic [ref=e152]:
                      - generic [ref=e155]:
                        - generic [ref=e156]:
                          - generic [ref=e157] [cursor=pointer]:
                            - checkbox "Completar día 1" [ref=e158]
                            - img [ref=e159]
                          - generic [ref=e161]:
                            - paragraph [ref=e162]: "Día 1: Trailer principal"
                            - paragraph [ref=e163]: 26-oct · Reel / Shorts
                        - generic [ref=e165]: Lanzamiento
                        - paragraph [ref=e166]: Convocatoria abierta.
                        - generic [ref=e167]: "Video 10: Convocatoria abierta"
                        - paragraph [ref=e168]: Postula ahora
                      - generic [ref=e171]:
                        - generic [ref=e172]:
                          - generic [ref=e173] [cursor=pointer]:
                            - checkbox "Completar día 2" [ref=e174]
                            - img [ref=e175]
                          - generic [ref=e177]:
                            - paragraph [ref=e178]: "Día 2: Buscamos solo 10 bandas"
                            - paragraph [ref=e179]: 27-oct · Reel
                        - generic [ref=e181]: Lanzamiento
                        - paragraph [ref=e182]: Solo 10 bandas de todo el Ecuador.
                        - generic [ref=e183]: "Video 1: La Convocatoria"
                        - paragraph [ref=e184]: Postula ahora
                      - generic [ref=e187]:
                        - generic [ref=e188]:
                          - generic [ref=e189] [cursor=pointer]:
                            - checkbox "Completar día 3" [ref=e190]
                            - img [ref=e191]
                          - generic [ref=e193]:
                            - paragraph [ref=e194]: "Día 3: Qué incluye TDF Sessions"
                            - paragraph [ref=e195]: 28-oct · Carrusel
                        - generic [ref=e197]: Lanzamiento
                        - paragraph [ref=e198]: 30 minutos, 4 cámaras, audio multipista y reels.
                        - generic [ref=e199]: "Video 9: Todo incluido"
                        - paragraph [ref=e200]: Revisa los detalles
                      - generic [ref=e203]:
                        - generic [ref=e204]:
                          - generic [ref=e205] [cursor=pointer]:
                            - checkbox "Completar día 4" [ref=e206]
                            - img [ref=e207]
                          - generic [ref=e209]:
                            - paragraph [ref=e210]: "Día 4: Tu música merece sonar y verse así"
                            - paragraph [ref=e211]: 29-oct · Reel
                        - generic [ref=e213]: Lanzamiento
                        - paragraph [ref=e214]: Tu banda ya tiene la energía; ahora necesita producción.
                        - generic [ref=e215]: "Video 2: Tu música merece esto"
                        - paragraph [ref=e216]: Postula
                      - generic [ref=e219]:
                        - generic [ref=e220]:
                          - generic [ref=e221] [cursor=pointer]:
                            - checkbox "Completar día 5" [ref=e222]
                            - img [ref=e223]
                          - generic [ref=e225]:
                            - paragraph [ref=e226]: "Día 5: Encuesta Pululahua"
                            - paragraph [ref=e227]: 30-oct · Stories
                        - generic [ref=e229]: Lanzamiento
                        - paragraph [ref=e230]: ¿Tu banda tocaría en vivo en el Pululahua?
                        - generic [ref=e231]: "Video 4: El escenario perfecto"
                        - paragraph [ref=e232]: Responde
                      - generic [ref=e235]:
                        - generic [ref=e236]:
                          - generic [ref=e237] [cursor=pointer]:
                            - checkbox "Completar día 6" [ref=e238]
                            - img [ref=e239]
                          - generic [ref=e241]:
                            - paragraph [ref=e242]: "Día 6: Desde cualquier rincón del Ecuador"
                            - paragraph [ref=e243]: 31-oct · Reel
                        - generic [ref=e245]: Lanzamiento
                        - paragraph [ref=e246]: Quito, Guayaquil, Cuenca, Loja, Manta y más.
                        - generic [ref=e247]: "Video 6: Desde cualquier rincón del Ecuador"
                        - paragraph [ref=e248]: Postula desde tu ciudad
                      - generic [ref=e251]:
                        - generic [ref=e252]:
                          - generic [ref=e253] [cursor=pointer]:
                            - checkbox "Completar día 7" [ref=e254]
                            - img [ref=e255]
                          - generic [ref=e257]:
                            - paragraph [ref=e258]: "Día 7: Live corto de convocatoria"
                            - paragraph [ref=e259]: 01-nov · Instagram Live
                        - generic [ref=e261]: Lanzamiento
                        - paragraph [ref=e262]: Explicar requisitos, beneficios y fechas.
                        - generic [ref=e263]: "Video 10: Convocatoria abierta"
                        - paragraph [ref=e264]: Haz tus preguntas
                      - generic [ref=e267]:
                        - generic [ref=e268]:
                          - generic [ref=e269] [cursor=pointer]:
                            - checkbox "Completar día 8" [ref=e270]
                            - img [ref=e271]
                          - generic [ref=e273]:
                            - paragraph [ref=e274]: "Día 8: Cámaras, audio y luces"
                            - paragraph [ref=e275]: 02-nov · Reel técnico
                        - generic [ref=e277]: Deseo
                        - paragraph [ref=e278]: 4 cámaras, audio multipista y producción real.
                        - generic [ref=e279]: "Video 5: Detrás de cámaras"
                        - paragraph [ref=e280]: Envía tu postulación
                      - generic [ref=e283]:
                        - generic [ref=e284]:
                          - generic [ref=e285] [cursor=pointer]:
                            - checkbox "Completar día 9" [ref=e286]
                            - img [ref=e287]
                          - generic [ref=e289]:
                            - paragraph [ref=e290]: "Día 9: No es videoclip vs Live Session"
                            - paragraph [ref=e291]: 03-nov · Carrusel
                        - generic [ref=e293]: Deseo
                        - paragraph [ref=e294]: Tocar de verdad cambia el resultado.
                        - generic [ref=e295]: "Video 7: No es un videoclip"
                        - paragraph [ref=e296]: Conoce el formato
                      - generic [ref=e299]:
                        - generic [ref=e300]:
                          - generic [ref=e301] [cursor=pointer]:
                            - checkbox "Completar día 10" [ref=e302]
                            - img [ref=e303]
                          - generic [ref=e305]:
                            - paragraph [ref=e306]: "Día 10: 30 minutos en vivo"
                            - paragraph [ref=e307]: 04-nov · Reel
                        - generic [ref=e309]: Deseo
                        - paragraph [ref=e310]: 30 minutos para demostrar quién eres.
                        - generic [ref=e311]: "Video 3: Tienes 30 minutos"
                        - paragraph [ref=e312]: Postula
                      - generic [ref=e315]:
                        - generic [ref=e316]:
                          - generic [ref=e317] [cursor=pointer]:
                            - checkbox "Completar día 11" [ref=e318]
                            - img [ref=e319]
                          - generic [ref=e321]:
                            - paragraph [ref=e322]: "Día 11: FAQ de postulación"
                            - paragraph [ref=e323]: 05-nov · Stories FAQ
                        - generic [ref=e325]: Deseo
                        - paragraph [ref=e326]: Costos, fechas, selección, derechos y logística.
                        - generic [ref=e327]: "Video 9: Todo incluido"
                        - paragraph [ref=e328]: Pregunta por DM
                      - generic [ref=e331]:
                        - generic [ref=e332]:
                          - generic [ref=e333] [cursor=pointer]:
                            - checkbox "Completar día 12" [ref=e334]
                            - img [ref=e335]
                          - generic [ref=e337]:
                            - paragraph [ref=e338]: "Día 12: Cada detalle cuenta"
                            - paragraph [ref=e339]: 06-nov · Reel
                        - generic [ref=e341]: Deseo
                        - paragraph [ref=e342]: Edición, color, audio y reels para redes.
                        - generic [ref=e343]: "Video 5: Detrás de cámaras · Video 9: Todo incluido"
                        - paragraph [ref=e344]: Envía tu material
                      - generic [ref=e347]:
                        - generic [ref=e348]:
                          - generic [ref=e349] [cursor=pointer]:
                            - checkbox "Completar día 13" [ref=e350]
                            - img [ref=e351]
                          - generic [ref=e353]:
                            - paragraph [ref=e354]: "Día 13: Criterios de selección"
                            - paragraph [ref=e355]: 07-nov · Post fijo
                        - generic [ref=e357]: Deseo
                        - paragraph [ref=e358]: Calidad musical, vivo, identidad y profesionalismo.
                        - generic [ref=e359]: "Video 2: Tu música merece esto"
                        - paragraph [ref=e360]: Prepara tu postulación
                      - generic [ref=e363]:
                        - generic [ref=e364]:
                          - generic [ref=e365] [cursor=pointer]:
                            - checkbox "Completar día 14" [ref=e366]
                            - img [ref=e367]
                          - generic [ref=e369]:
                            - paragraph [ref=e370]: "Día 14: Recordatorio de cupos"
                            - paragraph [ref=e371]: 08-nov · Reel / Story
                        - generic [ref=e373]: Deseo
                        - paragraph [ref=e374]: Solo 10 bandas serán parte de esta experiencia.
                        - generic [ref=e375]: "Video 1: La Convocatoria · Video 10: Convocatoria abierta"
                        - paragraph [ref=e376]: Postula hoy
                      - generic [ref=e379]:
                        - generic [ref=e380]:
                          - generic [ref=e381] [cursor=pointer]:
                            - checkbox "Completar día 15" [ref=e382]
                            - img [ref=e383]
                          - generic [ref=e385]:
                            - paragraph [ref=e386]: "Día 15: Tu próxima oportunidad"
                            - paragraph [ref=e387]: 09-nov · Reel
                        - generic [ref=e389]: Cierre
                        - paragraph [ref=e390]: Haz que te descubran con una sesión profesional.
                        - generic [ref=e391]: "Video 8: Haz que te descubran"
                        - paragraph [ref=e392]: Cierra tu postulación
                      - generic [ref=e395]:
                        - generic [ref=e396]:
                          - generic [ref=e397] [cursor=pointer]:
                            - checkbox "Completar día 16" [ref=e398]
                            - img [ref=e399]
                          - generic [ref=e401]:
                            - paragraph [ref=e402]: "Día 16: Story con contador"
                            - paragraph [ref=e403]: 10-nov · Stories
                        - generic [ref=e405]: Cierre
                        - paragraph [ref=e406]: Cuenta regresiva al cierre.
                        - generic [ref=e407]: "Video 3: Tienes 30 minutos"
                        - paragraph [ref=e408]: Activa recordatorio
                      - generic [ref=e411]:
                        - generic [ref=e412]:
                          - generic [ref=e413] [cursor=pointer]:
                            - checkbox "Completar día 17" [ref=e414]
                            - img [ref=e415]
                          - generic [ref=e417]:
                            - paragraph [ref=e418]: "Día 17: Últimos días"
                            - paragraph [ref=e419]: 11-nov · Reel
                        - generic [ref=e421]: Cierre
                        - paragraph [ref=e422]: Últimos días para postular.
                        - generic [ref=e423]: "Video 3: Tienes 30 minutos · Video 10: Convocatoria abierta"
                        - paragraph [ref=e424]: Postula ahora
                      - generic [ref=e427]:
                        - generic [ref=e428]:
                          - generic [ref=e429] [cursor=pointer]:
                            - checkbox "Completar día 18" [ref=e430]
                            - img [ref=e431]
                          - generic [ref=e433]:
                            - paragraph [ref=e434]: "Día 18: Qué recibe cada banda"
                            - paragraph [ref=e435]: 12-nov · Carrusel
                        - generic [ref=e437]: Cierre
                        - paragraph [ref=e438]: Live session completa, reels, publicación y experiencia.
                        - generic [ref=e439]: "Video 9: Todo incluido"
                        - paragraph [ref=e440]: Completa el formulario
                      - generic [ref=e443]:
                        - generic [ref=e444]:
                          - generic [ref=e445] [cursor=pointer]:
                            - checkbox "Completar día 19" [ref=e446]
                            - img [ref=e447]
                          - generic [ref=e449]:
                            - paragraph [ref=e450]: "Día 19: Domo + CTA"
                            - paragraph [ref=e451]: 13-nov · Video corto
                        - generic [ref=e453]: Cierre
                        - paragraph [ref=e454]: Un escenario imposible de ignorar.
                        - generic [ref=e455]: "Video 4: El escenario perfecto · Video 10: Convocatoria abierta"
                        - paragraph [ref=e456]: Postula antes del cierre
                      - generic [ref=e459]:
                        - generic [ref=e460]:
                          - generic [ref=e461] [cursor=pointer]:
                            - checkbox "Completar día 20" [ref=e462]
                            - img [ref=e463]
                          - generic [ref=e465]:
                            - paragraph [ref=e466]: "Día 20: Último llamado"
                            - paragraph [ref=e467]: 14-nov · Reel / Stories
                        - generic [ref=e469]: Cierre
                        - paragraph [ref=e470]: Mañana cierran postulaciones.
                        - generic [ref=e471]: "Video 3: Tienes 30 minutos · Video 8: Haz que te descubran"
                        - paragraph [ref=e472]: Entra al formulario
                      - generic [ref=e475]:
                        - generic [ref=e476]:
                          - generic [ref=e477] [cursor=pointer]:
                            - checkbox "Completar día 21" [ref=e478]
                            - img [ref=e479]
                          - generic [ref=e481]:
                            - paragraph [ref=e482]: "Día 21: Cierre de convocatoria"
                            - paragraph [ref=e483]: 15-nov · Reel / Stories
                        - generic [ref=e485]: Cierre
                        - paragraph [ref=e486]: Postulaciones cierran hoy.
                        - generic [ref=e487]: "Video 10: Convocatoria abierta"
                        - paragraph [ref=e488]: Cierra tu postulación hoy
    - generic "Control de radio":
      - generic [ref=e489]:
        - button "Reproducir radio" [ref=e490] [cursor=pointer]:
          - img [ref=e491]
        - button "Silenciar radio" [ref=e493] [cursor=pointer]:
          - img [ref=e494]
        - button "Ocultar barra de radio" [ref=e496] [cursor=pointer]:
          - img [ref=e497]
        - button "Expandir radio" [ref=e499] [cursor=pointer]:
          - img [ref=e500]
        - generic [ref=e502]:
          - paragraph [ref=e503]: "En pausa: Sin emisoras disponibles"
          - paragraph [ref=e504]: Radio
```

# Test source

```ts
  1  | import { expect, test } from '@playwright/test';
  2  | import axe from 'axe-core';
  3  | 
  4  | // The campaign tracker is local-only. Shell responses are synthetic; no campaigns,
  5  | // invitations, budgets or provider settings are changed by this regression.
  6  | for (const width of [320, 1280]) {
  7  |   test(`Campaign controls expose row and column names at ${width}px @critical`, async ({ page, baseURL }) => {
  8  |     await page.setViewportSize({ width, height: 900 });
  9  |     const origin = new URL(baseURL).origin;
  10 |     await page.route('**/*', async (route) => {
  11 |       const request = route.request();
  12 |       const url = new URL(request.url());
  13 |       if (!['fetch', 'xhr'].includes(request.resourceType())) {
  14 |         return url.origin === origin ? route.continue() : route.abort('blockedbyclient');
  15 |       }
  16 |       const path = url.pathname.replace(/^\/api(?=\/)/, '');
  17 |       const preferences = { locale: 'es', currency: 'USD', timezone: 'America/Guayaquil' };
  18 |       if (path === '/session') return route.fulfill({ json: {
  19 |         username: 'campaign-audit', displayName: 'Operador sintético', partyId: 42,
  20 |         roles: ['Admin'], modules: ['scheduling'], featureFlags: [], preferences,
  21 |       } });
  22 |       if (path === '/session/preferences') return route.fulfill({ json: preferences });
  23 |       if (path === '/health') return route.fulfill({ json: { status: 'ok', db: 'ok' } });
  24 |       if (path.startsWith('/catalogs/')) return route.fulfill({ json: { catalogs: [], items: [] } });
  25 |       return route.fulfill({ json: [] });
  26 |     });
  27 |     await page.goto('/estudio/campanas/tdf-sessions-domo');
  28 |     for (const tab of ['Control', 'Calendario', 'Creativos', 'Bandas', 'Copys']) {
  29 |       await page.getByRole('tab', { name: tab, exact: true }).click();
  30 |       if (tab === 'Calendario') {
  31 |         await expect(page.getByRole('progressbar', { name: 'Avance del calendario de campaña' })).toBeVisible();
  32 |       }
  33 |       if (tab === 'Creativos') {
  34 |         await expect(page.getByRole('progressbar', { name: 'Videos de campaña publicados' })).toBeVisible();
  35 |         const region = page.getByRole('region', { name: 'Seguimiento de creativos', exact: true });
  36 |         const rows = region.getByRole('row');
  37 |         expect(await rows.count()).toBeGreaterThan(1);
  38 |         for (const row of await rows.all()) {
  39 |           const status = row.getByRole('combobox');
  40 |           if (!(await status.count())) continue;
  41 |           const label = (await row.locator('[id$="-label"]').innerText()).replace(/\s+/g, ' ').trim();
  42 |           await expect(status).toHaveAccessibleName(`${label} Estado ${await status.innerText()}`);
  43 |           await expect(row.getByRole('textbox')).toHaveAccessibleName(`${label} Notas`);
  44 |         }
  45 |         await region.focus();
  46 |         await page.keyboard.press('Tab');
  47 |         await expect(region.getByRole('combobox').first()).toBeFocused();
  48 |         const focusIsVisible = () => page.evaluate(() => {
  49 |           const element = document.activeElement;
  50 |           const bounds = element.getBoundingClientRect();
  51 |           const hit = document.elementFromPoint(bounds.x + bounds.width / 2, bounds.y + bounds.height / 2);
  52 |           return hit === element || element.contains(hit);
  53 |         });
  54 |         await expect.poll(focusIsVisible).toBe(true);
  55 |         await page.keyboard.press('Enter');
  56 |         await expect(page.getByRole('listbox')).toBeVisible();
  57 |         await page.keyboard.press('Escape');
  58 |         await expect(region.getByRole('combobox').first()).toBeFocused();
  59 |         await page.keyboard.press('Tab');
  60 |         await expect(region.getByRole('textbox').first()).toBeFocused();
  61 |         await expect.poll(focusIsVisible).toBe(true);
  62 |       }
  63 |       await page.addScriptTag({ content: axe.source });
  64 |       const violations = await page.evaluate(async () => (await globalThis.axe.run(document, {
  65 |         runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa'] },
  66 |       })).violations.map(({ id, nodes }) => ({ id, targets: nodes.map(({ target }) => target) })));
> 67 |       expect(violations, tab).toEqual([]);
     |                               ^ Error: Calendario
  68 |       expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), tab).toBe(true);
  69 |     }
  70 |   });
  71 | }
  72 | 
```