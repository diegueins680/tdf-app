# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: marketplace-cart.spec.mjs >> Marketplace cart stays reachable after adding on a small phone @mobile-flow
- Location: e2e/web/marketplace-cart.spec.mjs:116:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('dialog', { name: 'Carrito' }).getByRole('button', { name: 'Cerrar carrito' })
    - locator resolved to <button tabindex="0" type="button" aria-label="Cerrar carrito" class="MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-f4zy4q">…</button>
  - attempting click action
    - waiting for element to be visible, enabled and stable

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - link [ref=e2]:
    - /url: "#main-content"
    - text: Saltar al contenido principal
  - generic [ref=e4]:
    - link [ref=e5]:
      - /url: "#main-content"
      - text: Saltar al contenido principal
    - banner [ref=e6]:
      - generic [ref=e8]:
        - link [ref=e10]:
          - /url: /tdf
          - img
        - generic [ref=e11]:
          - button [ref=e12] [cursor=pointer]:
            - img [ref=e14]
          - link [ref=e16] [cursor=pointer]:
            - /url: /buscar
            - img [ref=e17]
          - link [ref=e19] [cursor=pointer]:
            - /url: /login?redirect=%2Fmarketplace
            - text: Ingresar
          - button [ref=e20] [cursor=pointer]:
            - img [ref=e21]
    - main [ref=e23]:
      - generic [ref=e25]:
        - generic [ref=e26]:
          - heading [level=4] [ref=e27]: Tienda de inventario
          - paragraph [ref=e28]: 1) Elige equipos, 2) Ingresa contacto, 3) Selecciona cómo pagar. Guarda tu carrito y retoma cuando quieras.
          - alert [ref=e29]:
            - img [ref=e31]
            - generic [ref=e33]: La merch de artistas usa un catálogo y checkout separados por vendedor. Su disponibilidad depende del piloto.
            - link [ref=e35] [cursor=pointer]:
              - /url: /tiendas
              - text: Explorar merch
        - generic [ref=e36]:
          - generic [ref=e38]:
            - generic [ref=e39]:
              - generic [ref=e40]:
                - generic: Buscar equipo
                - generic [ref=e41]:
                  - textbox [ref=e42]
                  - group:
                    - generic: Buscar equipo
              - generic [ref=e43]:
                - generic [ref=e44]: Categoría
                - generic [ref=e45]:
                  - combobox [ref=e46] [cursor=pointer]: Todas
                  - textbox: all
                  - img
                  - group:
                    - generic: Categoría
              - generic [ref=e47]:
                - generic [ref=e48]: Modalidad
                - button [ref=e49] [cursor=pointer]:
                  - generic [ref=e50]: Todo
                - button [ref=e51] [cursor=pointer]:
                  - generic [ref=e52]: Venta
                - button [ref=e53] [cursor=pointer]:
                  - generic [ref=e54]: Renta
              - generic [ref=e55]:
                - generic [ref=e56]: Condición
                - button [ref=e57] [cursor=pointer]:
                  - generic [ref=e58]: Todas
                - button [ref=e59] [cursor=pointer]:
                  - generic [ref=e60]: used
                - button [ref=e61] [cursor=pointer]:
                  - generic [ref=e62]: new
              - generic [ref=e63]:
                - generic [ref=e64]: Ordenar por
                - generic [ref=e65]:
                  - combobox [ref=e66] [cursor=pointer]: Relevancia (disponible primero)
                  - textbox: relevance
                  - img
                  - group:
                    - generic: Ordenar por
              - generic [ref=e68]: 2 resultados
              - button [ref=e69] [cursor=pointer]: Limpiar filtros
            - generic [ref=e71]:
              - generic [ref=e74]:
                - generic [ref=e75]:
                  - heading [level=6] [ref=e76]: Cable XLR 10 m
                  - generic [ref=e78]: Cables
                - paragraph [ref=e79]: Mogami Gold
                - generic [ref=e80]:
                  - generic [ref=e82]: Mogami
                  - generic [ref=e84]: Gold
                  - generic [ref=e86]: Cables
                  - generic [ref=e88]: Venta
                - generic [ref=e90]:
                  - img [ref=e91]
                  - generic [ref=e93]: Sin foto
                  - generic [ref=e94]: Las fotos las gestiona Operación.
                - heading [level=5] [ref=e96]: USD $25.00
                - generic [ref=e97]:
                  - button [ref=e98] [cursor=pointer]:
                    - img [ref=e100]
                    - text: Copiar detalle
                  - button [ref=e102] [cursor=pointer]: Ver detalles
                  - button [ref=e103] [cursor=pointer]:
                    - img [ref=e104]
                    - text: Copiar enlace
                  - generic [ref=e106]:
                    - img [ref=e107]
                    - generic [ref=e109]: En stock
                  - generic [ref=e111]: "Condición: new"
                - button [ref=e114] [cursor=pointer]:
                  - img [ref=e116]
                  - text: Agregar
              - generic [ref=e120]:
                - generic [ref=e121]:
                  - heading [level=6] [ref=e122]: Micrófono Vintage SM58
                  - generic [ref=e124]: Micrófonos
                - paragraph [ref=e125]: Shure SM58
                - generic [ref=e126]:
                  - generic [ref=e128]: Shure
                  - generic [ref=e130]: SM58
                  - generic [ref=e132]: Micrófonos
                  - generic [ref=e134]: Venta
                - generic [ref=e136]:
                  - img [ref=e137]
                  - generic [ref=e139]: Sin foto
                  - generic [ref=e140]: Las fotos las gestiona Operación.
                - heading [level=5] [ref=e142]: USD $100.00
                - generic [ref=e143]:
                  - button [ref=e144] [cursor=pointer]:
                    - img [ref=e146]
                    - text: Copiar detalle
                  - button [ref=e148] [cursor=pointer]: Ver detalles
                  - button [ref=e149] [cursor=pointer]:
                    - img [ref=e150]
                    - text: Copiar enlace
                  - generic [ref=e152]:
                    - img [ref=e153]
                    - generic [ref=e155]: En stock
                  - generic [ref=e157]: "Condición: used"
                - button [ref=e160] [cursor=pointer]:
                  - img [ref=e162]
                  - text: Agregar
          - generic [ref=e166]:
            - generic [ref=e167]:
              - generic [ref=e168]:
                - generic [ref=e169]:
                  - heading [level=2] [ref=e170]: Carrito
                  - generic [ref=e171]: Sin productos aún
                - img [ref=e173]
              - generic [ref=e175]:
                - paragraph [ref=e177]: Agrega artículos para continuar al checkout.
                - generic [ref=e179]:
                  - heading [level=6] [ref=e180]: Subtotal
                  - heading [level=6] [ref=e181]: USD $0.00
            - generic [ref=e182]:
              - generic [ref=e185]: Checkout
              - generic [ref=e187]:
                - alert [ref=e188]:
                  - img [ref=e190]
                  - generic [ref=e192]: Agrega al menos un producto para continuar al checkout.
                - button [ref=e193] [cursor=pointer]: Explorar catálogo
        - alert [ref=e194]:
          - img [ref=e196]
          - generic [ref=e198]: Carrito actualizado
          - button [ref=e200] [cursor=pointer]:
            - img [ref=e201]
      - complementary [ref=e203]:
        - generic [ref=e204]:
          - paragraph [ref=e205]: Construyamos TDF Mobile juntos
          - generic [ref=e206]:
            - link [ref=e207] [cursor=pointer]:
              - /url: /app?surface=mobile_banner
              - text: Quiero participar
            - button [ref=e208] [cursor=pointer]: Ahora no
    - contentinfo [ref=e209]:
      - generic [ref=e210]:
        - complementary [ref=e211]:
          - link [ref=e214] [cursor=pointer]:
            - /url: /app?surface=footer
            - text: TDF Mobile / Testers
        - generic [ref=e215]:
          - generic [ref=e216]:
            - heading [level=6] [ref=e217]: TDF Records
            - paragraph [ref=e218]: Si te atoras, te dejamos una salida clara desde esta página para que sigas avanzando.
            - generic [ref=e219]:
              - link [ref=e220] [cursor=pointer]:
                - /url: /feedback
                - text: Necesito ayuda
              - link [ref=e221] [cursor=pointer]:
                - /url: /reservar
                - text: Reservar estudio
          - navigation [ref=e222]:
            - generic [ref=e223]: Explorar
            - generic [ref=e224]:
              - link [ref=e225] [cursor=pointer]:
                - /url: /buscar
                - text: Buscar
              - link [ref=e226] [cursor=pointer]:
                - /url: /social/eventos
                - text: Eventos
              - link [ref=e227] [cursor=pointer]:
                - /url: /tdf
                - text: TDF
              - link [ref=e228] [cursor=pointer]:
                - /url: /app?surface=nav
                - text: TDF Mobile
              - link [ref=e229] [cursor=pointer]:
                - /url: /comercio
                - text: Servicios
              - link [ref=e230] [cursor=pointer]:
                - /url: /fans
                - text: Comunidad
              - link [ref=e231] [cursor=pointer]:
                - /url: /marketplace
                - text: Tienda
              - link [ref=e232] [cursor=pointer]:
                - /url: /domo-del-pululahua
                - text: Domo
              - link [ref=e233] [cursor=pointer]:
                - /url: /reservar
                - text: Reservar
              - link [ref=e234] [cursor=pointer]:
                - /url: /records
                - text: Lanzamientos
              - link [ref=e235] [cursor=pointer]:
                - /url: /feedback
                - text: Sugerencias
              - link [ref=e236] [cursor=pointer]:
                - /url: /donar
                - text: Donar
          - generic [ref=e237]:
            - generic [ref=e238]: Gestión de mensajes
            - generic [ref=e239]:
              - link [ref=e240] [cursor=pointer]:
                - /url: /whatsapp/consentimiento
                - text: Consentimiento WhatsApp
              - link [ref=e241] [cursor=pointer]:
                - /url: /whatsapp/ok
                - text: Confirmación WhatsApp
          - link [ref=e243] [cursor=pointer]:
            - /url: /login?redirect=%2Fmarketplace
            - text: Ir a login
  - dialog "Carrito" [active] [ref=e245]:
    - generic [ref=e247]:
      - generic [ref=e248]:
        - generic [ref=e249]:
          - heading "Carrito" [level=2] [ref=e250]
          - generic [ref=e251]: Sin productos aún
        - button "Cerrar carrito" [ref=e253] [cursor=pointer]:
          - img [ref=e254]
      - generic [ref=e256]:
        - generic [ref=e257]:
          - paragraph [ref=e258]: Tu carrito está vacío.
          - button "Explorar catálogo" [ref=e259] [cursor=pointer]
        - generic [ref=e261]:
          - heading "Subtotal" [level=6] [ref=e262]
          - heading "USD $0.00" [level=6] [ref=e263]
```

# Test source

```ts
  72  |   const origin = new URL(baseURL).origin;
  73  |   const state = { items: [], creates: 0, upserts: [], cartReadFailure: false };
  74  |   await page.route('**/*', async (route) => {
  75  |     const request = route.request();
  76  |     const url = new URL(request.url());
  77  |     if (!['fetch', 'xhr'].includes(request.resourceType())) {
  78  |       return url.origin === origin ? route.continue() : route.abort('blockedbyclient');
  79  |     }
  80  |     if (url.origin !== origin) return route.abort('blockedbyclient');
  81  |     const path = url.pathname;
  82  |     const method = request.method();
  83  |     if (path === '/session') return route.fulfill({ status: 401, json: { error: 'unauthenticated' } });
  84  |     if (path === '/marketplace' && method === 'GET') return route.fulfill({ json: LISTINGS });
  85  |     if (path === '/marketplace/cart' && method === 'POST') {
  86  |       state.creates++;
  87  |       return route.fulfill({ json: buildCart(state) });
  88  |     }
  89  |     if (path === `/marketplace/cart/${CART_ID}` && method === 'GET') {
  90  |       if (state.cartReadFailure) return route.fulfill({ status: 503, json: { error: 'Synthetic temporary outage' } });
  91  |       return route.fulfill({ json: buildCart(state) });
  92  |     }
  93  |     if (path === `/marketplace/cart/${CART_ID}/items` && method === 'POST') {
  94  |       const body = request.postDataJSON();
  95  |       state.upserts.push(body);
  96  |       // The real API *sets* the quantity (0 removes), it never increments.
  97  |       state.items = state.items.filter((entry) => entry.listingId !== body.mciuListingId);
  98  |       if (body.mciuQuantity > 0) state.items.push({ listingId: body.mciuListingId, quantity: body.mciuQuantity });
  99  |       return route.fulfill({ json: buildCart(state) });
  100 |     }
  101 |     return route.fulfill({ status: 404, json: { error: 'No synthetic fixture for this API' } });
  102 |   });
  103 |   return state;
  104 | }
  105 | 
  106 | async function expectHealthyLayout(page) {
  107 |   const layout = await page.evaluate(() => ({
  108 |     scrollWidth: document.documentElement.scrollWidth,
  109 |     innerWidth: window.innerWidth,
  110 |     rootText: (document.getElementById('root')?.innerText ?? '').trim().length,
  111 |   }));
  112 |   expect(layout.scrollWidth).toBeLessThanOrEqual(layout.innerWidth);
  113 |   expect(layout.rootText).toBeGreaterThan(0);
  114 | }
  115 | 
  116 | test('Marketplace cart stays reachable after adding on a small phone @mobile-flow', async ({ page, baseURL }, testInfo) => {
  117 |   const state = await fixture(page, baseURL);
  118 |   await page.goto('/marketplace', { waitUntil: 'domcontentloaded' });
  119 | 
  120 |   const header = page.locator('header');
  121 |   const cartButton = header.getByTestId('marketplace-cart-button');
  122 |   await expect(page.getByText('Micrófono Vintage SM58').first()).toBeVisible();
  123 |   // Empty cart: the icon is visible, the count badge is not.
  124 |   await expect(cartButton).toBeVisible();
  125 |   await expect(cartButton).toHaveAccessibleName('Carrito, sin productos');
  126 |   await expect(cartButton).toBeInViewport();
  127 |   await expectHealthyLayout(page);
  128 | 
  129 |   const addMic = page.getByRole('button', { name: 'Agregar: Micrófono Vintage SM58' });
  130 |   await addMic.click();
  131 | 
  132 |   // Confirmation without navigating away, with a direct way to the cart.
  133 |   const confirmation = page.getByRole('alert').filter({ hasText: 'Agregado al carrito' });
  134 |   await expect(confirmation).toBeVisible();
  135 |   await expect(confirmation.getByRole('button', { name: 'Ver carrito' })).toBeVisible();
  136 |   await expect(page).toHaveURL(/\/marketplace(?:\?.*)?$/);
  137 |   await expect(cartButton).toHaveAccessibleName('Carrito, 1 producto');
  138 |   await expect(header.locator('.MuiBadge-badge')).toHaveText('1');
  139 |   // Without scrolling back up, the header cart control is still on screen
  140 |   // (the Marketplace header is pinned), and on phones the sticky bar too.
  141 |   await expect(cartButton).toBeInViewport();
  142 |   if ((page.viewportSize()?.width ?? 0) < 900) {
  143 |     await expect(page.getByRole('button', { name: /^Ver carrito \(1\)/ })).toBeInViewport();
  144 |   }
  145 |   expect(state.upserts).toEqual([{ mciuListingId: 'listing-mic', mciuQuantity: 1 }]);
  146 |   expect(state.creates).toBe(1);
  147 |   await expectHealthyLayout(page);
  148 |   await page.screenshot({ path: testInfo.outputPath('marketplace-cart-after-add.png') });
  149 | 
  150 |   // The header control opens the cart drawer with the cart contents.
  151 |   await cartButton.click();
  152 |   const drawer = page.getByRole('dialog', { name: 'Carrito' });
  153 |   await expect(drawer).toBeVisible();
  154 |   await expect(drawer.getByText('Micrófono Vintage SM58')).toBeVisible();
  155 |   await expect(drawer.getByRole('button', { name: 'Ir al checkout' })).toBeVisible();
  156 |   await page.screenshot({ path: testInfo.outputPath('marketplace-cart-drawer.png') });
  157 |   await drawer.getByRole('button', { name: 'Cerrar carrito' }).click();
  158 |   await expect(drawer).toBeHidden();
  159 | 
  160 |   // Refresh keeps the count (restored from localStorage, then confirmed by the server cart).
  161 |   await page.reload({ waitUntil: 'domcontentloaded' });
  162 |   await expect(cartButton).toHaveAccessibleName('Carrito, 1 producto');
  163 |   await expect(header.locator('.MuiBadge-badge')).toHaveText('1');
  164 |   await expectHealthyLayout(page);
  165 | 
  166 |   // Removing the item hides the badge but keeps the cart icon.
  167 |   await cartButton.click();
  168 |   await expect(drawer).toBeVisible();
  169 |   await drawer.getByRole('button', { name: 'Quitar Micrófono Vintage SM58 del carrito' }).click();
  170 |   await expect(drawer.getByText('Tu carrito está vacío.')).toBeVisible();
  171 |   await expect(drawer.getByRole('button', { name: 'Explorar catálogo' })).toBeVisible();
> 172 |   await drawer.getByRole('button', { name: 'Cerrar carrito' }).click();
      |                                                                ^ Error: locator.click: Test timeout of 30000ms exceeded.
  173 |   await expect(cartButton).toHaveAccessibleName('Carrito, sin productos');
  174 |   await expect(header.locator('.MuiBadge-badge.MuiBadge-invisible')).toHaveCount(1);
  175 |   await expect(cartButton).toBeVisible();
  176 |   expect(state.upserts.at(-1)).toEqual({ mciuListingId: 'listing-mic', mciuQuantity: 0 });
  177 |   await expectHealthyLayout(page);
  178 | });
  179 | 
  180 | 
  181 | test('Saved cart failure stays recoverable without creating a replacement @mobile-flow', async ({ page, baseURL }) => {
  182 |   const state = await fixture(page, baseURL);
  183 |   state.items = [{ listingId: 'listing-mic', quantity: 1 }];
  184 |   state.cartReadFailure = true;
  185 |   await page.addInitScript((cartId) => {
  186 |     localStorage.setItem('tdf-marketplace-cart-id', cartId);
  187 |     localStorage.setItem('tdf-marketplace-cart-meta', JSON.stringify({ cartId, count: 1, updatedAt: Date.now() }));
  188 |   }, CART_ID);
  189 |   await page.goto('/marketplace#carrito', { waitUntil: 'domcontentloaded' });
  190 |   const drawer = page.getByTestId('marketplace-cart-drawer');
  191 |   await expect(drawer).toBeVisible();
  192 |   await expect(drawer.getByText(/No pudimos cargar tu carrito/)).toBeVisible({ timeout: 15_000 });
  193 |   await expect(drawer.getByText('Tu carrito está vacío.', { exact: true })).toHaveCount(0);
  194 |   // The modal correctly removes the background header from the accessibility
  195 |   // tree. Verify the preserved count once the header is available to users.
  196 |   await drawer.getByRole('button', { name: 'Cerrar carrito' }).click();
  197 |   await expect(drawer).not.toBeVisible();
  198 |   const cartButton = page.locator('header').getByTestId('marketplace-cart-button');
  199 |   await expect(cartButton).toHaveAccessibleName('Carrito, 1 producto');
  200 |   await cartButton.click();
  201 |   await expect(drawer.getByText(/No pudimos cargar tu carrito/)).toBeVisible();
  202 |   expect(state.creates).toBe(0);
  203 | 
  204 |   state.cartReadFailure = false;
  205 |   await drawer.getByRole('button', { name: 'Reintentar carrito' }).click();
  206 |   await expect(drawer.getByText('Micrófono Vintage SM58', { exact: true })).toBeVisible();
  207 |   await expect(drawer.getByText(/No pudimos cargar tu carrito/)).toHaveCount(0);
  208 |   expect(state.creates).toBe(0);
  209 |   expect(state.upserts).toHaveLength(0);
  210 |   await expectHealthyLayout(page);
  211 | });
  212 | 
```