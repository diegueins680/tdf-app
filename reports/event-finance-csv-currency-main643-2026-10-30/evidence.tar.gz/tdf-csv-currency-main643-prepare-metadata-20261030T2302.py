from pathlib import Path
import os,subprocess,json,hashlib,datetime
w=Path('/private/tmp/tdf-csv-currency-main643-20261030T2302')
o=Path('/private/tmp/tdf-csv-currency-main643-qualification-20261030T2302')
c=Path('/private/tmp/tdf-correctness-cycle-20261028')
py=Path('/private/tmp/tdf-event-report-venv-20261027/bin/python')
node=Path('/Users/macpro/.nvm/versions/node/v24.13.1/bin/node')
def require(ok,message):
 if not ok:raise RuntimeError(message)
require(py.exists() and node.exists(),'Required local Python/Node cache unavailable')
require((w/'package-lock.json').read_bytes()==(c/'package-lock.json').read_bytes(),'Root dependency lock mismatch')
a=json.loads((w/'package.json').read_text());b=json.loads((c/'package.json').read_text())
require({k:v for k,v in a.items() if k!='scripts'}=={k:v for k,v in b.items() if k!='scripts'},'Dependency manifests mismatch')
require((w/'tdf-hq-ui/package.json').read_bytes()==(c/'tdf-hq-ui/package.json').read_bytes(),'UI manifest mismatch')
(o/'cache-admission.json').write_text(json.dumps({'rootLockByteExact':True,'rootManifestOnlyScriptDifferences':True,'uiManifestByteExact':True,'workspaceRootLockAuthoritative':True,'scope':'Read-only installed dependencies; no install or package mutation'},indent=2)+'\n')
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']}
env['PATH']='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin'
env['PYTHONDONTWRITEBYTECODE']='1'
alias=w/'node_modules';target=c/'node_modules';created=False;results={}
try:
 require(not(alias.exists() or alias.is_symlink()),'Own alias path already exists')
 require(target.is_dir(),'Installed root cache unavailable')
 alias.symlink_to(target,target_is_directory=True);created=True
 commands=[
 ('strict-catalog-json',[str(node),'scripts/catalog-list-audit.mjs','--decisions','docs/catalog-persistence/catalog-list-decisions.json','--fail-on-unreviewed','--output','docs/catalog-persistence/reports/static-list-inventory.json']),
 ('strict-catalog-csv',[str(node),'scripts/catalog-list-audit.mjs','--decisions','docs/catalog-persistence/catalog-list-decisions.json','--fail-on-unreviewed','--format','csv','--output','docs/catalog-persistence/reports/list-consumer-matrix.csv']),
 ('inventory',[str(py),'scripts/specification-inventory.py']),
 ('conformance',[str(py),'scripts/specification-conformance.py']),
 ('inventory-check',[str(py),'scripts/specification-inventory.py','--check']),
 ('conformance-check',[str(py),'scripts/specification-conformance.py','--check']),
 ('catalog-unit',[str(node),'--test','scripts/__tests__/catalog-list-audit.test.mjs'])]
 for label,cmd in commands:
  with (o/(label+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
  results[label]=r.returncode;print(label+' exit '+str(r.returncode),flush=True)
  (o/'metadata-progress.json').write_text(json.dumps(results,indent=2)+'\n')
  require(r.returncode==0,label+' did not pass')
 data=json.loads((w/'docs/catalog-persistence/reports/static-list-inventory.json').read_text())
 require(data['candidateCount']>0,'Missing strict candidate inventory')
 (o/'current-catalog.json').write_bytes((w/'docs/catalog-persistence/reports/static-list-inventory.json').read_bytes())
 (o/'current-catalog.csv').write_bytes((w/'docs/catalog-persistence/reports/list-consumer-matrix.csv').read_bytes())
finally:
 if created:
  require(alias.is_symlink() and alias.resolve()==target.resolve(),'Own alias replaced; refusing unrelated cleanup')
  alias.unlink()
 (o/'metadata-results.json').write_text(json.dumps({'actualExits':results,'ownedAliasRemoved':not(alias.exists() or alias.is_symlink()),'completedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
