from pathlib import Path
import json,subprocess,datetime,hashlib,sys
kind=sys.argv[1];assert kind in ['currency','csv'];prefix='tdf-event-finance-currency' if kind=='currency' else 'tdf-csv-currency';o=Path('/private/tmp/'+prefix+'-main643-qualification-20261030T2302');m=json.loads((o/'preparation-state.json').read_text())['sourceCommit'];assurance=json.loads((o/'assurance-execution.json').read_text());assert assurance['sourceCommit']==m and assurance['actualExit']==0
r={'sourceCommit':m,'actualExits':{},'scripts':{},'method':'Sequential actual subprocess exits on current qualified source, retained raw stdout.','startedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
for label in ['seal','seal-controls']:
 p=Path('/private/tmp/'+prefix+'-main643-'+label+'-20261030T2302.py');r['scripts'][str(p)]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 with (o/(label+'-execution.log')).open('w') as log:c=subprocess.run(['python3',str(p)],stdout=log,stderr=subprocess.STDOUT)
 r['actualExits'][label]=c.returncode;r['atUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat();(o/'seal-execution.json').write_text(json.dumps(r,indent=2)+'\n');print(label+' actualexit '+str(c.returncode),flush=True);assert c.returncode==0,label
