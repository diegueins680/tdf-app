from pathlib import Path
import subprocess,json,hashlib,os,datetime
w=Path('/private/tmp/tdf-csv-currency-main643-20261030T2302');o=Path('/private/tmp/tdf-csv-currency-main643-qualification-20261030T2302');old='2609922b89bd44822e790be8225356cc65dc5ab6';parent='8cbd23c1a4e3c8b24c3d0abd0ab1a29339fc6fce';main='234ff6f7faf1aecf347c8e92a374228f4ec07aaa';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=w)
def blob(ref,path):return git('show',ref+':'+path)
md=json.loads((o/'metadata-results.json').read_text());assert len(md['actualExits'])==7 and all(x==0 for x in md['actualExits'].values()) and md['ownedAliasRemoved']
assert git('rev-parse','HEAD').decode().strip()==old and git('rev-parse','MERGE_HEAD').decode().strip()==parent and not git('diff','--name-only','--diff-filter=U').strip()
req=json.loads((w/'formal/system/requirements.json').read_text())['requirements'];prior=json.loads(blob(parent,'formal/system/requirements.json'))['requirements'];oldby={x['id']:x for x in json.loads(blob(old,'formal/system/requirements.json'))['requirements']};by={x['id']:x for x in req}
assert len(by)==len(req)==161 and len(prior)==160 and all(by[x['id']]==x for x in prior);assert by['UI-EVENT-FINANCE-CSV-CURRENCY-001']==oldby['UI-EVENT-FINANCE-CSV-CURRENCY-001']
mainreq=json.loads(blob(main,'formal/system/requirements.json'))['requirements'];assert len(mainreq)==159 and all(by[x['id']]==x for x in mainreq)
subprocess.run(['git','merge-base','--is-ancestor',main,parent],cwd=w,check=True)
path='docs/catalog-persistence/catalog-list-decisions.json';assert (w/path).read_bytes()==blob(old,path);a=json.loads(blob(parent,path));b=json.loads(blob(old,path));assert b['decisions'][:-1]==a['decisions'] and b['decisions'][-1]['id']=='280d7c369a6f39bd4a13';assert {k:v for k,v in a.items() if k!='decisions'}=={k:v for k,v in b.items() if k!='decisions'}
cat=json.loads((w/'docs/catalog-persistence/reports/static-list-inventory.json').read_text());assert cat['candidateCount']==1356 and all(x['decision']!='unreviewed' for x in cat['candidates'])
subprocess.run(['git','diff','--check'],cwd=w,check=True);subprocess.run(['git','add','formal/system/requirements.json','formal/system/inventory.json','formal/system/traceability.json','docs/catalog-persistence/reports/static-list-inventory.json','docs/catalog-persistence/reports/list-consumer-matrix.csv'],cwd=w,check=True)
with(o/'source-commit.log').open('w') as f:r=subprocess.run(['git','commit','-m','Merge qualified browser precision main643 parent into CSV currency correction'],cwd=w,stdout=f,stderr=subprocess.STDOUT)
assert r.returncode==0
m=git('rev-parse','HEAD').decode().strip();assert git('show','-s','--format=%P',m).decode().split()==[old,parent] and not git('status','--porcelain').strip()
for root in ['tdf-hq-ui','package.json','package-lock.json','tdf-mobile']:assert git('rev-parse',m+':'+root)==git('rev-parse',old+':'+root),root
for root in ['tdf-hq','scripts','.github','ops','package.json','package-lock.json','tdf-mobile']:assert git('rev-parse',m+':'+root)==git('rev-parse',parent+':'+root),root
assert set(git('diff','--name-only',parent,m,'--','tdf-hq-ui').decode().splitlines())=={'tdf-hq-ui/src/utils/eventFinanceCsv.ts','tdf-hq-ui/src/utils/eventFinanceCsv.test.ts'}
def history(ref):
 rows={}
 for row in git('ls-tree','-r','-z',ref,'--','reports','formal/system/evidence').split(b'\0'):
  if row:
   hdr,path=row.split(b'\t',1);mode,kind,oid=hdr.split();assert kind==b'blob';rows[path.decode()]=oid.decode()
 return rows
now=history(m);counts={}
for ref in [old,parent]:
 oldmap=history(ref);assert all(now.get(path)==oid for path,oid in oldmap.items());counts[ref]=len(oldmap)
reportpaths=git('ls-tree','-r','-z','--name-only',old,'--','reports/event-finance-csv-currency-2026-10-30.json','reports/event-finance-csv-currency-2026-10-30').decode().strip('\0').split('\0');assert len(reportpaths)==4;bindings={path:sha(blob(old,path)) for path in reportpaths}
for path,h in bindings.items():assert sha(blob(m,path))==h==sha((w/path).read_bytes())
for path in ['formal/system/event-finance-csv-currency.md','formal/system/auth-predicates.json','formal/system/recovery-expiry-arithmetic.json']:assert blob(m,path)==blob(old,path)
checks={};env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','LANG','LC_ALL']};env.update(PATH='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1')
for label,cmd in [('inventory-check',['python3','scripts/specification-inventory.py','--check']),('conformance-check',['python3','scripts/specification-conformance.py','--check']),('source-admission',['python3','scripts/check-new-specification-surfaces.py','--base',parent,'--head',m]),('source-ci-selection',['node','scripts/ci-change-scope.mjs','--base',parent,'--head',m])]:
 with(o/('committed-'+label+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600)
 checks[label]=r.returncode;print(label+' actualexit '+str(r.returncode),flush=True);assert r.returncode==0,label
assert not git('status','--porcelain').strip()
state=json.loads((o/'preparation-state.json').read_text());state.update(phase='CLEAN_QUALIFIED_PARENT_RECONCILIATION_SOURCE_PREPARED',sourceCommit=m,parents=[old,parent],parentHead=parent,mainSha=main,metadataResults=md,committedChecks=checks,all160ParentNormativeObjectsExactPlusUnchangedCsv161=True,all159MainNormativeObjectsPreserved=True,entireUiExactOld260=True,backendScriptsWorkflowsOpsDependenciesMobileExactParent8cbd=True,historicalParentBlobCountsPreserved=counts,parentFourReportBlobsSha256=bindings,strictCatalogCandidates=1356,allPriorCatalogueDecisionObjectsExactAndOwned280dRetained=True,sourceCleanAfter=True,currentSourceQualification='NOT_RUN; source preparation only. ROOT review and qualification remain required.',historicalQualification='Original437 source helper6/Jest78/AST27 retained historical; parent835/EC7 full3811 historical; no new runtime result claimed.',completedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat());(o/'preparation-state.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps({k:state[k] for k in ['sourceCommit','parents','parentHead','committedChecks','strictCatalogCandidates','sourceCleanAfter']}),flush=True)
