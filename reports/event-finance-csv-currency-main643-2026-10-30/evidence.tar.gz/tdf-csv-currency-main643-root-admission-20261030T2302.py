from pathlib import Path
import subprocess,json,hashlib,datetime
w=Path('/private/tmp/tdf-csv-currency-main643-20261030T2302');o=Path('/private/tmp/tdf-csv-currency-main643-qualification-20261030T2302');old='2609922b89bd44822e790be8225356cc65dc5ab6';parent='8cbd23c1a4e3c8b24c3d0abd0ab1a29339fc6fce';main='234ff6f7faf1aecf347c8e92a374228f4ec07aaa'
def git(*a):return subprocess.check_output(['git',*a],cwd=w)
p=json.loads((o/'preparation-state.json').read_text());m=p['sourceCommit'];assert p['mainSha']==main and p['baselineHead']==old and p['parentHead']==parent
assert git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip() and git('show','-s','--format=%P',m).decode().split()==[old,parent]
for path in ['tdf-hq-ui','package.json','package-lock.json','tdf-mobile']:assert git('rev-parse',m+':'+path)==git('rev-parse',old+':'+path),path
for path in ['tdf-hq','.github','scripts','ops','package.json','package-lock.json','tdf-mobile']:assert git('rev-parse',m+':'+path)==git('rev-parse',parent+':'+path),path
req=json.loads(git('show',m+':formal/system/requirements.json'))['requirements'];pr=json.loads(git('show',parent+':formal/system/requirements.json'))['requirements'];orig=json.loads(git('show',old+':formal/system/requirements.json'))['requirements'];by={x['id']:x for x in req};assert len(req)==len(by)==161 and len(pr)==160 and all(by[x['id']]==x for x in pr)
assert by['UI-EVENT-FINANCE-CSV-CURRENCY-001']==next(x for x in orig if x['id']=='UI-EVENT-FINANCE-CSV-CURRENCY-001')
path='docs/catalog-persistence/catalog-list-decisions.json';assert git('show',m+':'+path)==git('show',old+':'+path);cat=json.loads(git('show',m+':docs/catalog-persistence/reports/static-list-inventory.json'));assert cat['candidateCount']==1356
historical={}
for path in ['reports/event-finance-csv-currency-2026-10-30.json',*['reports/event-finance-csv-currency-2026-10-30/'+x for x in ['evidence.tar.gz','manifest.json','independent-review.txt']]]:
 b=git('show',m+':'+path);assert b==git('show',old+':'+path);historical[path]=hashlib.sha256(b).hexdigest()
result={'sourceCommit':m,'rootIndependentOfAgentPreparation':True,'normalParentsVerified':True,'wholeUiExactOld260':True,'backendScriptsWorkflowsOpsDepsExactParent8cbd':True,'all160ParentNormsExactPlusUnchangedCsv161':True,'oldCatalogDecisionFileExact':True,'strictCandidates':1356,'historical4ReportBlobsSha256':historical,'freshRuntimeQualification':'Not yet performed at this admission phase','sourceClean':True,'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/'root-independent-source-admission.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
