{-# LANGUAGE DuplicateRecordFields #-}
{-# LANGUAGE RecordWildCards #-}
{-# LANGUAGE NamedFieldPuns #-}
{-# LANGUAGE DataKinds #-}
{-# LANGUAGE TypeOperators #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE TemplateHaskell #-}
{-# LANGUAGE TypeFamilies #-}

module TDF.Server where

import qualified TDF.Social.Chat as SocialChat
import qualified TDF.CoursePhone as CoursePhone
import qualified TDF.Social.FanEffects as FanEffects
import qualified TDF.Social.RelationshipReads as SocialReads
import qualified TDF.Social.RelationshipWrites as SocialWrites
import qualified TDF.Social.Profiles as SocialProfiles
import TDF.Social.Server (socialV2Server)
import qualified TDF.Interactions.Legacy as InteractionLegacy
import qualified TDF.Interactions.Server as InteractionsServer
import qualified TDF.Interactions.Notifications as InteractionNotifications
import qualified Database.Persist.Sql as PersistSql
import           Control.Applicative ((<|>))
import           Control.Exception (Exception, SomeAsyncException, SomeException, displayException, fromException, throwIO, try)
import qualified Control.Exception.Safe as Safe
import           Control.Concurrent (forkIO)
import           Control.Monad (foldM, forM, forM_, void, when, unless, (>=>), join)
import           Control.Monad.Except (catchError)
import           Control.Monad.IO.Class (MonadIO, liftIO)
import           Control.Monad.Reader (ReaderT, ask, asks, runReaderT)
import           Control.Monad.Trans.Class (lift)
import           Crypto.BCrypt (hashPasswordUsingPolicy, slowerBcryptHashingPolicy)
import           Crypto.Hash (Digest, SHA256, hash)
import           Data.ByteArray (constEq)
import qualified Data.ByteArray.Encoding as BAE
import           Data.Bits (xor)
import           Data.Int (Int64)
import           Data.List (find, nub, isInfixOf, sort, sortOn)
import           Data.Ord (Down(..))
import           Data.Foldable (for_, toList)
import           Data.Char
  ( GeneralCategory(Format, LineSeparator, ParagraphSeparator, Space)
  , digitToInt
  , generalCategory
  , isAscii
  , isControl
  , isDigit
  , isHexDigit
  , isAlphaNum
  , isAsciiLower
  , isAsciiUpper
  , isSpace
  , toLower
  )
import           Data.Maybe (catMaybes, fromMaybe, isJust, isNothing, listToMaybe, mapMaybe, maybeToList)
import           Data.Either (isLeft)
import qualified Data.Set as Set
import           Data.Aeson (ToJSON(..), Value(..), Object, defaultOptions, object, (.=), decodeStrict', eitherDecodeStrict', eitherDecode, FromJSON(..), Result(..), encode, fromJSON, genericParseJSON, genericToJSON)
import qualified Data.Aeson.Key as AKey
import qualified Data.Aeson.KeyMap as AKeyMap
import           Data.Aeson.Types (Parser, camelTo2, fieldLabelModifier, parseEither, parseMaybe, withObject, (.:), (.:?), (.!=))
import           Data.Text (Text)
import qualified Data.Text as T
import qualified Data.Text.Encoding as TE
import qualified Data.Text.Encoding.Error as TEE
import           Data.ByteString (ByteString)
import qualified Data.ByteString.Char8 as BS8
import qualified Data.ByteString.Lazy as BL
import qualified Data.ByteString.Lazy.Char8 as BL8
import qualified Data.Scientific as Sci
import           Data.Time
  ( Day, NominalDiffTime, UTCTime (..), ZonedTime, addDays, addUTCTime, diffTimeToPicoseconds, diffUTCTime, fromGregorian
  , getCurrentTime, secondsToDiffTime, toGregorian, utctDay, zonedTimeToUTC
  )
import           Data.Time.Format (defaultTimeLocale, formatTime)
import           Data.Time.Format.ISO8601 (iso8601ParseM)
import           GHC.Generics (Generic)
import           Data.UUID (toText)
import qualified Data.UUID as UUID
import           Data.UUID.V4 (nextRandom)
import           Data.Word (Word64)
import           Numeric (showHex)
import           System.Directory (getFileSize)
import           System.FilePath ((</>))
import           System.IO (hPutStrLn, stderr)
import           Network.HTTP.Types.Status (status404)
import qualified Network.Wai as Wai
import           Servant
import           Servant.Multipart (FileData(..), Tmp)
import           Servant.Server.Experimental.Auth (AuthHandler)
import           Text.Printf (printf)
import           Text.Read (readMaybe)
import           Web.PathPieces (fromPathPiece, toPathPiece)

import           Database.Persist
import           Database.Persist.Sql (SqlBackend, SqlPersistT, Single(..), fromSqlKey, rawExecute, rawExecuteCount, rawSql, runSqlPool, toSqlKey, transactionSave, transactionUndo, updateWhereCount)
import           Database.Persist.Postgresql ()
import           Database.PostgreSQL.Simple (SqlError (..))

import           TDF.API
import           TDF.API.Types (UserRoleSummaryDTO(..), AccountStatusDTO(..), MarketplaceItemDTO(..), MarketplaceCartDTO(..), MarketplaceCartItemUpdate(..), MarketplaceCartItemDTO(..), MarketplaceOrderDTO(..), MarketplaceOrderItemDTO(..), MarketplaceOrderUpdate(..), MarketplaceFulfillmentUpdate(..), MarketplaceRentalUpdate(..), MarketplaceRentalTermsUpdate(..), MarketplaceManualEvidenceSubmit(..), MarketplaceManualPaymentReview(..), MarketplaceManualEvidenceDTO(..), MarketplaceCommerceDTO(..), MarketplaceCustomerRequestSubmit(..), MarketplaceCustomerRequestReview(..), MarketplaceCustomerRequestDTO(..), MarketplaceDepositSettlementSubmit(..), MarketplaceDepositSettlementReview(..), MarketplaceDepositSettlementDTO(..), MarketplaceCheckoutReq(..), MarketplaceShippingAddress(..), DatafastCheckoutDTO(..), PaypalCreateDTO(..), PaypalCaptureReq(..), LabelTrackDTO(..), LabelTrackCreate(..), LabelTrackUpdate(..), LabelProjectNoteDTO(..), LabelProjectNoteCreate(..), LabelProjectNoteUpdate(..), DriveUploadDTO(..), DriveTokenExchangeRequest(..), DriveTokenRefreshRequest(..), DriveTokenResponse(..), PartyRelatedDTO(..), PartyRelatedBooking(..), PartyRelatedClassSession(..), PartyRelatedLabelTrack(..), verifyMetaWebhookSignature)
import           TDF.API.Types (maxMarketplaceCartItemQuantity)
import qualified TDF.API.Types as APITypes
import           TDF.API.WhatsApp (validateHookVerifyRequest)
import qualified TDF.API      as Api
import           TDF.API.Marketplace (MarketplaceAPI, MarketplaceAdminAPI)
import           TDF.API.Label (LabelAPI)
import           TDF.API.Drive (DriveAPI, DriveUploadForm(..))
import           TDF.Contracts.API (ContractsAPI)
import qualified TDF.Server.DDEX as DDEXServer
import qualified TDF.Server.Catalog as CatalogServer
import qualified TDF.Server.CommerceOperations as CommerceOperationsServer
import qualified TDF.Server.PaymentCapabilities as PaymentCapabilitiesServer
import qualified TDF.Server.PaymentAvailability as PaymentAvailability
import qualified TDF.Server.ProviderExecution as ProviderExecutionServer
import qualified TDF.Catalog.Models as Catalog
import           TDF.Catalog.Security
  ( applySecurityRoleAssignmentPolicy
  , hasCanonicalPartyRole
  , loadCanonicalPartyRoles
  , provisionReviewedSecurityRole
  , selectCanonicalPartyIdsByRole
  )
import qualified TDF.Courses.Production as ProductionCourse
import qualified TDF.Courses.PublicMetadata as CoursePublic
import qualified TDF.Internationalization as Internationalization
import           TDF.Config ( AppConfig(..)
                            , courseInstructorAvatarFallback
                            , courseMapFallback
                            , courseSlugFallback
                            , llmChatModelCandidates
                            , normalizeLlmApiBase
                            , normalizeConfiguredGraphNodeId
                            , normalizeConfiguredGoogleClientId
                            , normalizeConfiguredBaseUrl
                            , resolveConfiguredAppBase
                            , resolveConfiguredAssetsBase
                            )
import           TDF.DB
import qualified TDF.CampaignAutomation as CampaignAutomation
import qualified TDF.Operations.Server as OperationsServer
import qualified TDF.EventOperations.Server as EventOperationsServer
import qualified TDF.Invoice.SRI as Sri
import           TDF.Invoice.Receipt (validateReceiptSnapshot)
import           TDF.Models
import qualified TDF.Models as M
import qualified TDF.ModelsExtra as ME
import qualified TDF.Models.SocialEventsModels as Social
import           TDF.FeatureRegistry
  ( RegistryFeature(..)
  , findRegistryFeature
  , registryFeatureAccessGrantRole
  , registryFeatureAllows
  , registryFeatureRequestable
  , registryReviewerCanDecide
  , supportedFeatureActions
  )
import           TDF.DTO
import qualified TDF.DTO as DTO
import           TDF.Auth
  ( AuthedUser(..)
  , ModuleAccess(..)
  , authContext
  , hasAiToolingAccess
  , hasModuleAccess
  , hasOperationsAccess
  , hasSocialInboxAccess
  , moduleName
  , modulesForRoles
  , validateModuleAccess
  , withCurrentAuthSession
  , withCurrentModuleAccess
  )
import           TDF.Seed       (seedAll, seedInventoryAssets, seedMarketplaceListings)
import           TDF.ServerAdmin (adminServer)
import qualified TDF.LogBuffer as LogBuf
import           TDF.Server.SocialEventsHandlers
  ( publicUpcomingEventsServer
  , socialEventsServer
  , stripeWebhookServer
  , eitherStripeServerError
  , parseStripePaymentIntentResponse
  )
import qualified TDF.Services.Stripe as Stripe
import           TDF.DTO.SocialEventsDTO
  ( StripePaymentIntentDTO(..)
  )
import           TDF.ServerExtra (bandsServer, facebookServer, facebookWebhookServer, instagramServer, instagramWebhookServer, inventoryPublicServer, inventoryServer, loadBandForParty, paymentsServer, pipelinesServer, roomsPublicServer, roomsServer, serviceCatalogPublicServer, serviceCatalogServer, sessionsServer)
import qualified TDF.ServerExtra as ServerExtra
import qualified TDF.ServerAuth as AuthServer
import           TDF.ServerInstagramOAuth (instagramOAuthServer)
import           TDF.ServerInternships (internshipsServer)
import           TDF.Server.SocialSync (socialSyncServer)
import           TDF.Server.SocialDiscovery (socialDiscoveryServer)
import qualified Data.Map.Strict            as Map
import           TDF.ServerFuture (futureServer)
import           TDF.ServerRadio (radioServer)
import           TDF.ServerLiveSessions (liveSessionsServer)
import           TDF.Server.ServiceStorefront (serviceStorefrontPublicServer, serviceStorefrontAdminServer)
import qualified TDF.Server.ServiceStorefront as ServiceStorefront
import           TDF.Commerce.ProviderAdapter.Http (sharedProviderManager)
import qualified TDF.Commerce.CheckoutStore as Checkout
import qualified TDF.Commerce.Money as CommerceMoney
import qualified TDF.Commerce.PaymentRuntimeStore as PaymentRuntime
import qualified TDF.Server.CourseCheckout as CourseCheckoutServer
import qualified TDF.Server.EventTicketCheckout as EventTicketCheckoutServer
import qualified TDF.Server.DomoQuoteCheckout as DomoQuoteCheckoutServer
import qualified TDF.Commerce.MarketplaceSales as MarketplaceSales
import qualified TDF.Commerce.MarketplaceRentals as MarketplaceRentals
import qualified TDF.Commerce.MarketplaceOperations as MarketplaceOperations
import qualified TDF.Commerce.ServiceBookings as ServiceBookings
import qualified TDF.Server.Directory as DirectoryServer
import qualified TDF.Server.Merch as MerchServer
import qualified TDF.Server.MusicRelease as MusicReleaseServer
import qualified TDF.Server.Reviews as ReviewsServer
import           TDF.ServerFeedback (feedbackServer, internalFeedbackServer)
import qualified TDF.Contracts.Server as Contracts
import           TDF.ServerProposals (proposalsServer)
import           TDF.ServerFanClub (fanClubPublicGetClub, fanClubPublicGetEvents, fanClubSecureListMyClubs, fanClubSecureArtistHandlers, buildFanClubPostReactionSummary)
import           TDF.Trials.API (TrialsAPI)
import qualified TDF.Trials.Server as TrialsServer
  ( hasAmbiguousPublicUrlPath
  , isValidHttpUrl
  , trialsServer
  )
import qualified TDF.Trials.Models as Trials
import qualified TDF.Meta as Meta
import           TDF.Version      (VersionInfo(..), getVersionInfo)
import           TDF.App.Readiness (databaseReady)
import qualified TDF.Handlers.InputList as InputList
import qualified TDF.Email as Email
import qualified TDF.Email.Service as EmailSvc
import           TDF.Profiles.Artist ( fetchArtistProfileMap
                                     , fetchPartyNameMap
                                     , loadAllArtistProfilesDTO
                                     , loadArtistProfileBySlugDTO
                                     , loadArtistProfileDTO
                                     , loadOrCreateArtistProfileDTO
                                     , searchArtistProfilesDTO
                                     , resolvePublishedGenreSelections
                                     , activateOwnArtistProfile
                                     , deadlineClockAfterLock
                                     , lockPendingOnboardingRequests
                                     , upsertArtistProfileRecord
                                     , validateArtistProfileUpsert
                                     )
import           TDF.Routes.Academy ( AcademyAPI
                                    , AcademyAccountAPI
                                    , EnrollReq(..)
                                    , ProgressReq(..)
                                    , ReferralClaimReq(..)
                                    , MicrocourseDTO(..)
                                    , LessonDTO(..)
                                    , NextCohortDTO(..)
                                    , validateAcademyRole
                                    , validateAcademyReferralCode
                                    , validateAcademySlug
                                    )
import           TDF.Routes.Courses ( CoursesPublicAPI
                                    , WhatsAppHooksAPI
                                    , WhatsAppWebhookAPI
                                    , CourseMetadata(..)
                                    , CourseSession(..)
                                    , SyllabusItem(..)
                                    , CourseRegistrationRequest(..)
                                    , CourseRegistrationResponse(..)
                                    , CourseRegistrationStatusUpdate(..)
                                    , CourseRegistrationNotesUpdate(..)
                                    , CourseRegistrationReceiptCreate(..)
                                    , CourseRegistrationReceiptUpdate(..)
                                    , CourseRegistrationFollowUpCreate(..)
                                    , CourseRegistrationFollowUpUpdate(..)
                                    , UTMTags(..)
                                    , CourseUpsert(..)
                                    , CourseSessionIn(..)
                                    , CourseSyllabusIn(..)
                                    )
import qualified TDF.Routes.Courses as Courses
import           TDF.WhatsApp.Types ( WAMetaWebhook(..)
                                    , WAEntry(..)
                                    , WAChange(..)
                                    , WAMessage(..)
                                    , WAContext(..)
                                    , WAReferral(..)
                                    , WAValue(..)
                                    )
import qualified TDF.WhatsApp.Types as WA
import           TDF.WhatsApp.Client (SendTextResult)
import           TDF.WhatsApp.History ( IncomingWhatsAppRecord(..)
                                      , OutgoingWhatsAppRecord(..)
                                      , WhatsAppDeliveryUpdate(..)
                                      , applyWhatsAppDeliveryUpdate
                                      , normalizeWhatsAppPhone
                                      , receiveIncomingWhatsAppMessage
                                      , recordOutgoingWhatsAppMessage
                                      )
import           TDF.WhatsApp.Transport (WhatsAppEnv(..), loadWhatsAppEnv, sendWhatsAppTemplateIO, sendWhatsAppTextIO)
import           Data.Time.Clock.POSIX (posixSecondsToUTCTime)
import           TDF.RagStore        (retrieveRagContext)
import           Network.HTTP.Client (Manager, RequestBody(..), Response, httpLbs, parseRequest, Request(..), responseBody, responseStatus)
import           Network.HTTP.Types.URI (urlDecode, urlEncode, renderQuery, renderSimpleQuery)
import           Network.HTTP.Types.Status (statusCode)
import           System.Environment (lookupEnv)
import qualified TDF.CMS.Models as CMS
import qualified TDF.Calendar.Models as Cal
import qualified TDF.API.Calendar as CalAPI

type AppM = ReaderT Env Handler

data GoogleToken = GoogleToken
  { access_token  :: Text
  , refresh_token :: Maybe Text
  , expires_in    :: Maybe Int
  , token_type    :: Maybe Text
  } deriving (Generic, Show)
instance FromJSON GoogleToken where
  parseJSON = withObject "GoogleToken" $ \o -> do
    accessToken <- o .: "access_token" >>= parseGoogleTokenField "access_token"
    refreshToken <- parseOptionalGoogleRefreshToken o
    expiresIn <- o .: "expires_in"
    when (expiresIn <= (0 :: Int)) $
      fail "expires_in must be positive"
    tokenType <- o .: "token_type" >>= parseGoogleTokenType
    pure GoogleToken
      { access_token = accessToken
      , refresh_token = refreshToken
      , expires_in = Just expiresIn
      , token_type = Just tokenType
      }

parseOptionalGoogleRefreshToken :: Object -> Parser (Maybe Text)
parseOptionalGoogleRefreshToken o =
  case AKeyMap.lookup "refresh_token" o of
    Nothing -> pure Nothing
    Just Null -> fail "refresh_token must be omitted or a string"
    Just (String raw) -> Just <$> parseGoogleTokenField "refresh_token" raw
    Just _ -> fail "refresh_token must be a string"

parseGoogleTokenField :: Text -> Text -> Parser Text
parseGoogleTokenField fieldName raw =
  let clean = T.strip raw
  in if T.null clean
       then fail (T.unpack fieldName <> " must not be blank")
       else if T.any (\ch -> isSpace ch || isControl ch) clean
         then fail (T.unpack fieldName <> " must not contain whitespace or control characters")
         else if T.any isHiddenDriveOAuthTokenChar clean
           then fail (T.unpack fieldName <> " must not contain hidden formatting characters")
           else if T.any (not . isAscii) clean
             then fail (T.unpack fieldName <> " must contain only ASCII characters")
           else if T.length clean > maxDriveOAuthTokenChars
             then fail (T.unpack fieldName <> " must be 4096 characters or fewer")
             else pure clean

maxDriveOAuthTokenChars :: Int
maxDriveOAuthTokenChars = 4096

isHiddenDriveOAuthTokenChar :: Char -> Bool
isHiddenDriveOAuthTokenChar ch =
  generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

parseGoogleTokenType :: Text -> Parser Text
parseGoogleTokenType raw = do
  tokenTypeVal <- parseGoogleTokenField "token_type" raw
  if T.toLower tokenTypeVal == "bearer"
    then pure "Bearer"
    else fail "token_type must be Bearer"

data GoogleEventsPage = GoogleEventsPage
  { items         :: [Value]
  , nextPageToken :: Maybe Text
  , nextSyncToken :: Maybe Text
  } deriving (Show, Generic)
instance FromJSON GoogleEventsPage where
  parseJSON = withObject "GoogleEventsPage" $ \o -> do
    parsedItems <- o .: "items"
    when (length parsedItems > maxGoogleCalendarPageItems) $
      fail $
        "Google Calendar page must contain "
          <> show maxGoogleCalendarPageItems
          <> " items or fewer"
    itemIds <- forM (zip [(0 :: Int)..] parsedItems) $ uncurry validateGoogleCalendarPageItem
    when (length itemIds /= Set.size (Set.fromList itemIds)) $
      fail "Google Calendar page must not contain duplicate event ids"
    nextPage <- o .:? "nextPageToken" >>= traverse (parseGoogleCursorField "nextPageToken")
    nextSync <- o .:? "nextSyncToken" >>= traverse (parseGoogleCursorField "nextSyncToken")
    when (isJust nextPage && isJust nextSync) $
      fail "Google Calendar page must not include both nextPageToken and nextSyncToken"
    pure GoogleEventsPage
      { items = parsedItems
      , nextPageToken = nextPage
      , nextSyncToken = nextSync
      }

maxGoogleCalendarPageItems :: Int
maxGoogleCalendarPageItems = 2000

parseGoogleCursorField :: Text -> Text -> Parser Text
parseGoogleCursorField = parseGoogleTokenField

validateGoogleCalendarPageItem :: Int -> Value -> Parser Text
validateGoogleCalendarPageItem idx (Object eventObj) = do
  eventId <- case AKeyMap.lookup "id" eventObj of
    Just (String rawEventId) ->
      either
        (fail . googleItemFieldError "id")
        pure
        (validateGoogleCalendarEventId rawEventId)
    Just _ ->
      fail (googleItemFieldLabel "id" <> " must be a string")
    Nothing ->
      fail (googleItemFieldLabel "id" <> " is required")
  case AKeyMap.lookup "status" eventObj of
    Nothing -> pure ()
    Just Null -> pure ()
    Just (String rawStatus) ->
      either
        (fail . googleItemFieldError "status")
        (const (pure ()))
        (validateGoogleCalendarEventStatus rawStatus)
    Just _ ->
      fail (googleItemFieldLabel "status" <> " must be a string")
  forM_ googleCalendarPageTextFields $
    validateGoogleCalendarPageTextField idx eventObj
  validateGoogleCalendarPageTimestampField idx eventObj "updated"
  validateGoogleCalendarPageDateObjectField idx eventObj "start"
  validateGoogleCalendarPageDateObjectField idx eventObj "end"
  validateGoogleCalendarPageAttendeesField idx eventObj
  pure eventId
  where
    googleItemFieldLabel fieldName =
      "items[" <> show idx <> "]." <> T.unpack fieldName
    googleItemFieldError fieldName msg =
      googleItemFieldLabel fieldName <> ": " <> T.unpack msg
validateGoogleCalendarPageItem idx _ =
  fail ("items[" <> show idx <> "] must be an event object")

googleCalendarPageTextFields :: [Text]
googleCalendarPageTextFields =
  ["summary", "description", "location", "htmlLink"]

validateGoogleCalendarPageTextField :: Int -> Object -> Text -> Parser ()
validateGoogleCalendarPageTextField idx eventObj fieldName =
  case AKeyMap.lookup (AKey.fromText fieldName) eventObj of
    Nothing -> pure ()
    Just Null -> pure ()
    Just (String rawText)
      | fieldName == "htmlLink" ->
          either
            (fail . googleCalendarPageFieldError idx fieldName)
            (const (pure ()))
            (validateGoogleCalendarHtmlLink rawText)
      | T.length rawText > googleCalendarPageTextFieldLimit fieldName ->
          fail
            ( fieldLabel
                <> " must be "
                <> show (googleCalendarPageTextFieldLimit fieldName)
                <> " characters or fewer"
            )
      | T.any isUnsupportedGoogleCalendarPageTextChar rawText ->
          fail
            ( fieldLabel
                <> " must not contain unsupported control or formatting characters"
            )
      | otherwise -> pure ()
    Just _ ->
      fail (fieldLabel <> " must be a string")
  where
    fieldLabel = "items[" <> show idx <> "]." <> T.unpack fieldName

googleCalendarPageTextFieldLimit :: Text -> Int
googleCalendarPageTextFieldLimit "description" = 10000
googleCalendarPageTextFieldLimit _ = 1024

googleCalendarPageFieldError :: Int -> Text -> Text -> String
googleCalendarPageFieldError idx fieldName message =
  "items[" <> show idx <> "]."
    <> T.unpack fieldName
    <> ": "
    <> T.unpack message

validateGoogleCalendarPageTimestampField :: Int -> Object -> Text -> Parser ()
validateGoogleCalendarPageTimestampField idx eventObj fieldName =
  case AKeyMap.lookup (AKey.fromText fieldName) eventObj of
    Nothing -> pure ()
    Just Null -> pure ()
    Just (String rawTimestamp) ->
      either
        (fail . googleCalendarPageFieldError idx fieldName)
        (const (pure ()))
        (validateGoogleCalendarIsoTimestamp fieldName rawTimestamp)
    Just _ ->
      fail (fieldLabel <> " must be a string")
  where
    fieldLabel = "items[" <> show idx <> "]." <> T.unpack fieldName

validateGoogleCalendarPageDateObjectField :: Int -> Object -> Text -> Parser ()
validateGoogleCalendarPageDateObjectField idx eventObj fieldName =
  case AKeyMap.lookup (AKey.fromText fieldName) eventObj of
    Nothing -> pure ()
    Just Null -> pure ()
    Just (Object dateObj) -> validateDateObject dateObj
    Just _ ->
      fail (fieldLabel <> " must be an object")
  where
    fieldLabel = "items[" <> show idx <> "]." <> T.unpack fieldName
    validateDateObject dateObj = do
      let mDateTime = AKeyMap.lookup "dateTime" dateObj
          mDate = AKeyMap.lookup "date" dateObj
      when (isJust mDateTime && isJust mDate) $
        fail (fieldLabel <> " must include only one of dateTime or date")
      case (mDateTime, mDate) of
        (Just (String rawDateTime), Nothing) ->
          either
            (fail . googleCalendarPageFieldError idx (fieldName <> ".dateTime"))
            (const (pure ()))
            (validateGoogleCalendarIsoTimestamp (fieldName <> ".dateTime") rawDateTime)
        (Nothing, Just (String rawDate)) ->
          either
            (fail . googleCalendarPageFieldError idx (fieldName <> ".date"))
            (const (pure ()))
            (validateGoogleCalendarDateOnly (fieldName <> ".date") rawDate)
        (Nothing, Nothing) ->
          fail (fieldLabel <> " must include dateTime or date")
        (Just _, Nothing) ->
          fail (fieldLabel <> ".dateTime must be a string")
        (Nothing, Just _) ->
          fail (fieldLabel <> ".date must be a string")
        (Just _, Just _) ->
          fail (fieldLabel <> " must include only one of dateTime or date")

validateGoogleCalendarPageAttendeesField :: Int -> Object -> Parser ()
validateGoogleCalendarPageAttendeesField idx eventObj =
  case AKeyMap.lookup "attendees" eventObj of
    Nothing -> pure ()
    Just Null -> pure ()
    Just (Array attendeesValue) -> do
      attendeeEmails <-
        forM
          (zip [(0 :: Int)..] (toList attendeesValue))
          validateGoogleCalendarPageAttendee
      when (length attendeeEmails /= Set.size (Set.fromList attendeeEmails)) $
        fail (fieldLabel <> " must not contain duplicate attendee emails")
    Just _ ->
      fail (fieldLabel <> " must be an array")
  where
    fieldLabel = "items[" <> show idx <> "].attendees"
    validateGoogleCalendarPageAttendee (attendeeIdx, Object attendeeObj) =
      case AKeyMap.lookup "email" attendeeObj of
        Nothing ->
          fail (attendeeLabel attendeeIdx <> ".email is required")
        Just (String rawEmail) ->
          either
            (fail . attendeeFieldError attendeeIdx "email")
            pure
            (validateGoogleCalendarAttendeeEmail rawEmail)
        Just _ ->
          fail (attendeeLabel attendeeIdx <> ".email must be a string")
    validateGoogleCalendarPageAttendee (attendeeIdx, _) =
      fail (attendeeLabel attendeeIdx <> " must be an attendee object")
    attendeeLabel attendeeIdx =
      fieldLabel <> "[" <> show attendeeIdx <> "]"
    attendeeFieldError attendeeIdx fieldName message =
      attendeeLabel attendeeIdx <> "." <> T.unpack fieldName <> ": " <> T.unpack message

validateGoogleCalendarAttendeeEmail :: Text -> Either Text Text
validateGoogleCalendarAttendeeEmail rawEmail
  | T.null trimmedEmail =
      Left "Google Calendar attendee email must not be blank"
  | trimmedEmail /= rawEmail =
      Left "Google Calendar attendee email must not include surrounding whitespace"
  | T.any isUnsupportedGoogleCalendarPageTextChar rawEmail =
      Left $
        "Google Calendar attendee email must not contain unsupported control "
          <> "or formatting characters"
  | T.any isSpace rawEmail =
      Left "Google Calendar attendee email must not contain whitespace"
  | isValidCourseRegistrationEmail normalizedEmail =
      Right normalizedEmail
  | otherwise =
      Left "Google Calendar attendee email must be a valid email address"
  where
    trimmedEmail = T.strip rawEmail
    normalizedEmail = T.toLower trimmedEmail

validateGoogleCalendarIsoTimestamp :: Text -> Text -> Either Text Text
validateGoogleCalendarIsoTimestamp fieldName rawTimestamp =
  validateGoogleCalendarDateToken
    fieldName
    "ISO8601 timestamp"
    parseGoogleCalendarIsoTimestamp
    rawTimestamp

validateGoogleCalendarDateOnly :: Text -> Text -> Either Text Text
validateGoogleCalendarDateOnly fieldName rawDate =
  validateGoogleCalendarDateToken
    fieldName
    "ISO8601 date"
    parseGoogleCalendarDateOnly
    rawDate

validateGoogleCalendarDateToken
  :: Text -> Text -> (String -> Maybe a) -> Text -> Either Text Text
validateGoogleCalendarDateToken fieldName expectedShape parseToken rawValue
  | T.null value =
      Left (fieldName <> " must not be blank")
  | value /= rawValue =
      Left (fieldName <> " must not include surrounding whitespace")
  | T.any isUnsupportedGoogleCalendarPageTextChar value =
      Left
        ( fieldName
            <> " must not contain unsupported control or formatting characters"
        )
  | T.any isSpace value =
      Left (fieldName <> " must not contain whitespace")
  | isNothing (parseToken (T.unpack value)) =
      Left (fieldName <> " must be an " <> expectedShape)
  | otherwise =
      Right value
  where
    value = T.strip rawValue

parseGoogleCalendarIsoTimestamp :: String -> Maybe UTCTime
parseGoogleCalendarIsoTimestamp raw =
  iso8601ParseM raw <|> fmap zonedTimeToUTC (iso8601ParseM raw :: Maybe ZonedTime)

parseGoogleCalendarDateOnly :: String -> Maybe Day
parseGoogleCalendarDateOnly = iso8601ParseM

validateGoogleCalendarHtmlLink :: Text -> Either Text Text
validateGoogleCalendarHtmlLink rawLink
  | T.null htmlLink =
      Left "Google Calendar htmlLink must not be blank"
  | htmlLink /= rawLink =
      Left "Google Calendar htmlLink must not include surrounding whitespace"
  | T.length htmlLink > maxGoogleCalendarHtmlLinkChars =
      Left "Google Calendar htmlLink must be 2048 characters or fewer"
  | T.any isUnsupportedGoogleCalendarPageTextChar htmlLink =
      Left $
        "Google Calendar htmlLink must not contain unsupported control "
          <> "or formatting characters"
  | T.any isSpace htmlLink =
      Left "Google Calendar htmlLink must not contain whitespace"
  | not
      ( "https://" `T.isPrefixOf` T.toLower htmlLink
          && TrialsServer.isValidHttpUrl htmlLink
      ) =
      Left "Google Calendar htmlLink must be an absolute https URL"
  | "#" `T.isInfixOf` htmlLink =
      Left "Google Calendar htmlLink must not contain a fragment"
  | not (isGoogleCalendarHtmlLink htmlLink) =
      Left "Google Calendar htmlLink must be a Google Calendar web link"
  | otherwise =
      Right htmlLink
  where
    htmlLink = T.strip rawLink

maxGoogleCalendarHtmlLinkChars :: Int
maxGoogleCalendarHtmlLinkChars = 2048

isGoogleCalendarHtmlLink :: Text -> Bool
isGoogleCalendarHtmlLink rawUrl =
  case httpsUrlAuthority rawUrl of
    Just (host, portSuffix) ->
      host `elem` googleCalendarHtmlLinkHosts
        && (T.null portSuffix || portSuffix == ":443")
        && case drivePathSegments rawUrl of
             ["calendar", "event"] -> hasSingleGoogleCalendarEid rawUrl
             _ -> False
    Nothing ->
      False

googleCalendarHtmlLinkHosts :: [Text]
googleCalendarHtmlLinkHosts =
  [ "www.google.com"
  , "calendar.google.com"
  ]

hasSingleGoogleCalendarEid :: Text -> Bool
hasSingleGoogleCalendarEid rawUrl =
  case [ rawParam
       | rawParam <- queryParams rawUrl
       , isNamedQueryParam "eid" rawParam
       ] of
    [rawParam] ->
      maybe False (not . T.null . T.strip) (queryParamValue rawParam)
    _ ->
      False

isUnsupportedGoogleCalendarPageTextChar :: Char -> Bool
isUnsupportedGoogleCalendarPageTextChar ch =
  (isControl ch && ch `notElem` ("\n\r\t" :: String))
    || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

data ParsedEvent = ParsedEvent
  { peGoogleId   :: Text
  , peStatus     :: Text
  , peSummary    :: Maybe Text
  , peDescription :: Maybe Text
  , peLocation   :: Maybe Text
  , peStartAt    :: Maybe UTCTime
  , peEndAt      :: Maybe UTCTime
  , peUpdatedAt  :: Maybe UTCTime
  , peHtmlLink   :: Maybe Text
  , peAttendees  :: Maybe CMS.AesonValue
  , peRawPayload :: Maybe CMS.AesonValue
  }

runDB :: SqlPersistT IO a -> AppM a
runDB = runDb

runDb :: SqlPersistT IO a -> AppM a
runDb action = do
  Env{..} <- ask
  result <- liftIO $ tryServerError (runSqlPool action envPool)
  either throwError pure result

tryServerError :: IO a -> IO (Either ServerError a)
tryServerError = try

type CombinedAPI = TrialsAPI :<|> API

mkApp :: Env -> Application
mkApp env =
  let apiProxy = Proxy :: Proxy API
      combinedProxy = Proxy :: Proxy CombinedAPI
      ctxProxy = Proxy :: Proxy '[AuthHandler Wai.Request AuthedUser]
      ctx      = authContext env
      trials   = TrialsServer.trialsServer (envPool env)
      apiSrv   = hoistServerWithContext apiProxy ctxProxy (nt env) (server env)
  in serveWithContext combinedProxy ctx (trials :<|> apiSrv)

nt :: Env -> AppM a -> Handler a
nt env x = runReaderT x env

server :: Env -> ServerT API AppM
server env =
  let Env{envConfig} = env
      assetsRoot = assetsRootDir envConfig
  in
       versionServer
  :<|> health
  :<|> mcpServer
  :<|> AuthServer.sessionServer
  :<|> AuthServer.login
  :<|> AuthServer.googleLogin
  :<|> AuthServer.signup
  :<|> AuthServer.changePassword
  :<|> AuthServer.authV1Server
  :<|> fanPublicServer
  :<|> artistPublicServer
  :<|> coursesPublicServer
  :<|> DomoQuoteCheckoutServer.publicDomoQuotesServer
  :<|> EventTicketCheckoutServer.publicEventTicketsServer
  :<|> instagramWebhookServer
  :<|> facebookWebhookServer
  :<|> whatsappHooksServer
  :<|> whatsappWebhookServer
  :<|> metaServer
  :<|> academyServer
  :<|> seedTrigger
  :<|> inputListServer
  :<|> adsPublicServer
  :<|> cmsPublicServer
  :<|> whatsappConsentPublicServer
  :<|> inventoryPublicServer
  :<|> feedbackServer
  :<|> CatalogServer.publicCatalogServer
  :<|> InteractionsServer.publicInteractionsServer
  :<|> DirectoryServer.directoryPublicServer
  :<|> MerchServer.merchPublicServer
  :<|> publicUpcomingEventsServer
  :<|> ReviewsServer.reviewsPublicServer
  :<|> PaymentCapabilitiesServer.paymentCapabilitiesServer
  :<|> MusicReleaseServer.musicReleasePublicServer
  :<|> ProviderExecutionServer.providerExecutionServer
  :<|> protectedServer
  :<|> marketplacePublicServer
  :<|> roomsPublicServer
  :<|> serviceCatalogPublicServer
  :<|> serviceStorefrontPublicServer
  :<|> listEngineersPublic
  :<|> bookingPublicServer
  :<|> inventoryStaticServer assetsRoot
  :<|> assetsServeServer assetsRoot
  :<|> stripeWebhookServer

versionServer :: ServerT Api.VersionAPI AppM
versionServer = liftIO getVersionInfo

mcpServer :: ServerT Api.McpAPI AppM
mcpServer rawRequest =
  case parseMcpRequest rawRequest of
    Nothing -> pure (mcpErrorValue Nothing (-32600) "Invalid Request" Nothing)
    Just req -> handleMcpRequest req

data McpRequest = McpRequest
  { mcpReqId :: Maybe Value
  , mcpReqMethod :: Text
  , mcpReqParams :: Maybe Value
  } deriving (Show)

mcpProtocolVersion :: Text
mcpProtocolVersion = "2024-11-05"

mcpTools :: [Value]
mcpTools =
  [ object
      [ "name" .= ("tdf_health_check" :: Text)
      , "description" .= ("Return service health and version metadata." :: Text)
      , "inputSchema" .= object
          [ "type" .= ("object" :: Text)
          , "properties" .= object []
          , "additionalProperties" .= False
          ]
      ]
  ]

parseMcpRequest :: Value -> Maybe McpRequest
parseMcpRequest = parseMaybe $ withObject "McpRequest" $ \o -> do
  rejectUnexpectedObjectFields "McpRequest" ["jsonrpc", "id", "method", "params"] o
  version <- o .: "jsonrpc"
  when (version /= ("2.0" :: Text)) $
    fail "jsonrpc must be 2.0"
  method <- o .: "method" >>= validateMcpNameField "method"
  reqId <- case AKeyMap.lookup "id" o of
    Nothing
      | mcpMethodAllowsNotification method -> pure Nothing
      | otherwise -> fail "id is required for MCP requests"
    Just Null -> fail "id must be omitted for notifications or a string/integral number for requests"
    Just value -> validateMcpIdValue value *> pure (Just value)
  mParams <- o .:? "params"
  case mParams of
    Nothing -> pure (McpRequest reqId method Nothing)
    Just value@(Object _) -> pure (McpRequest reqId method (Just value))
    Just _ -> fail "params must be an object"

mcpMethodAllowsNotification :: Text -> Bool
mcpMethodAllowsNotification "initialized" = True
mcpMethodAllowsNotification _ = False

validateMcpIdValue :: Value -> Parser ()
validateMcpIdValue (Object _) = fail "id must be a string or integral number"
validateMcpIdValue (Array _)  = fail "id must be a string or integral number"
validateMcpIdValue (Bool _)   = fail "id must be a string or integral number"
validateMcpIdValue (String ident) = validateMcpIdString ident
validateMcpIdValue (Number n)
  | not (Sci.isInteger n) = fail "id number must be integral"
  | Just intValue <- (Sci.toBoundedInteger n :: Maybe Int64)
  , intValue >= negate mcpMaxSafeIntegerId && intValue <= mcpMaxSafeIntegerId =
      pure ()
  | otherwise =
      fail "id number must be within the JSON safe-integer range"
validateMcpIdValue Null =
  fail "id must be omitted for notifications or a string/integral number for requests"

mcpMaxSafeIntegerId :: Int64
mcpMaxSafeIntegerId = 9007199254740991

validateMcpIdString :: Text -> Parser ()
validateMcpIdString ident = do
  when (T.null (T.strip ident)) $
    fail "id string must not be blank"
  when (T.length ident > 128) $
    fail "id string must be 128 characters or fewer"
  when (T.any isUnsafeMcpIdChar ident) $
    fail "id string must not contain control characters or Unicode formatting marks"

isUnsafeMcpIdChar :: Char -> Bool
isUnsafeMcpIdChar ch =
  isControl ch
    || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

parseToolCallParams :: Value -> Maybe (Text, Value)
parseToolCallParams = parseMaybe $ withObject "ToolCallParams" $ \o -> do
  rejectUnexpectedObjectFields "ToolCallParams" ["name", "arguments"] o
  toolName <- o .: "name" >>= validateMcpNameField "name"
  args <- case AKeyMap.lookup "arguments" o of
    Nothing -> pure (object [])
    Just value@(Object _) -> pure value
    Just Null -> fail "arguments must be an object"
    Just _ -> fail "arguments must be an object"
  pure (toolName, args)

validateMcpNameField :: Text -> Text -> Parser Text
validateMcpNameField fieldName rawName = do
  let name = T.strip rawName
  when (T.null name) $
    fail (T.unpack fieldName <> " is required")
  when (rawName /= name) $
    fail (T.unpack fieldName <> " must not include surrounding whitespace")
  when (T.length name > 128) $
    fail (T.unpack fieldName <> " must be 128 characters or fewer")
  when (T.any isUnsafeMcpNameChar name) $
    fail
      ( T.unpack fieldName
          <> " must not contain whitespace, control characters, or Unicode formatting marks"
      )
  when (T.any (not . isMcpNameChar) name) $
    fail
      ( T.unpack fieldName
          <> " must use only ASCII lowercase letters, numbers, '/', '_' or '-'"
      )
  when ("/" `T.isPrefixOf` name || "/" `T.isSuffixOf` name || "//" `T.isInfixOf` name) $
    fail (T.unpack fieldName <> " must not contain empty path segments")
  pure name

isMcpNameChar :: Char -> Bool
isMcpNameChar ch =
  isAsciiLower ch
    || isDigit ch
    || ch `elem` ("/_-" :: String)

isUnsafeMcpNameChar :: Char -> Bool
isUnsafeMcpNameChar ch =
  isSpace ch
    || isControl ch
    || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

validateMcpToolArguments :: Text -> Value -> Either Text ()
validateMcpToolArguments "tdf_health_check" (Object args)
  | AKeyMap.null args = Right ()
  | otherwise = Left "tdf_health_check does not accept arguments"
validateMcpToolArguments "tdf_health_check" _ =
  Left "tdf_health_check arguments must be an object"
validateMcpToolArguments _ _ = Right ()

handleMcpRequest :: McpRequest -> AppM Value
handleMcpRequest req@McpRequest{ mcpReqMethod = method, mcpReqParams = params } =
  case method of
    "initialize" -> do
      info <- liftIO getVersionInfo
      let VersionInfo { name = appName, appVer } = info
          result =
            object
              [ "protocolVersion" .= mcpProtocolVersion
              , "capabilities" .= object
                  [ "tools" .= object []
                  , "resources" .= object []
                  , "prompts" .= object []
                  ]
              , "serverInfo" .= object
                  [ "name" .= appName
                  , "version" .= appVer
                  ]
              ]
      pure (mcpSuccess req result)
    "tools/list" ->
      pure (mcpSuccess req (object ["tools" .= mcpTools]))
    "tools/call" ->
      handleMcpToolCall req params
    "resources/list" ->
      pure (mcpSuccess req (object ["resources" .= ([] :: [Value])]))
    "prompts/list" ->
      pure (mcpSuccess req (object ["prompts" .= ([] :: [Value])]))
    "initialized" ->
      pure (mcpSuccess req (object []))
    _ ->
      pure (mcpErrorValue (mcpReqId req) (-32601) "Method not found" Nothing)

handleMcpToolCall :: McpRequest -> Maybe Value -> AppM Value
handleMcpToolCall req rawParams =
  case rawParams >>= parseToolCallParams of
    Nothing -> pure (mcpErrorValue (mcpReqId req) (-32602) "Invalid params" Nothing)
    Just (toolName, args) ->
      case toolName of
        "tdf_health_check" ->
          case validateMcpToolArguments toolName args of
            Left msg -> pure (mcpErrorValue (mcpReqId req) (-32602) msg Nothing)
            Right () -> do
              info <- liftIO getVersionInfo
              now <- liftIO getCurrentTime
              let VersionInfo { appVer, commit, buildTime } = info
                  timestamp = T.pack (formatTime defaultTimeLocale "%Y-%m-%dT%H:%M:%SZ" now)
                  message = T.intercalate "\n"
                    [ "status: ok"
                    , "time: " <> timestamp
                    , "version: " <> appVer
                    , "commit: " <> commit
                    , "buildTime: " <> buildTime
                    ]
                  result =
                    object
                      [ "content" .=
                          [ object
                              [ "type" .= ("text" :: Text)
                              , "text" .= message
                              ]
                          ]
                      ]
              pure (mcpSuccess req result)
        _ ->
          pure (mcpErrorValue (mcpReqId req) (-32602) ("Unknown tool: " <> toolName) Nothing)

mcpSuccess :: McpRequest -> Value -> Value
mcpSuccess req result =
  object
    [ "jsonrpc" .= ("2.0" :: Text)
    , "id" .= fromMaybe Null (mcpReqId req)
    , "result" .= result
    ]

mcpErrorValue :: Maybe Value -> Int -> Text -> Maybe Value -> Value
mcpErrorValue mReqId code message mData =
  object
    [ "jsonrpc" .= ("2.0" :: Text)
    , "id" .= fromMaybe Null mReqId
    , "error" .= object (baseFields <> dataField)
    ]
  where
    baseFields =
      [ "code" .= code
      , "message" .= message
      ]
    dataField = maybe [] (\datum -> ["data" .= datum]) mData

inputListServer :: ServerT Api.InputListAPI AppM
inputListServer = publicRoutes :<|> seedRoutes
  where
    publicRoutes =
           listInventory

    seedRoutes =
           seedInventory
      :<|> seedHQ

listInventory
  :: Maybe Text
  -> Maybe Text
  -> Maybe Int
  -> AppM [Entity InputList.InventoryItem]
listInventory mFieldParam mSessionParam mChannelParam = do
  parsedField <- case mFieldParam of
    Nothing -> pure Nothing
    Just rawField ->
      case InputList.parseAssetField rawField of
        Nothing    -> throwBadRequest "Unsupported field"
        Just field -> pure (Just field)
  -- Session-scoped availability is derived from a session's private input
  -- rows, so the anonymous route serves only the public inventory list.
  when (isJust mSessionParam || isJust mChannelParam) $
    throwBadRequest "sessionId and channel filters are not available on the public inventory list"
  Env{..} <- ask
  liftIO $ flip runSqlPool envPool (InputList.listInventoryDB parsedField Nothing Nothing)

seedInventory :: Maybe Text -> AppM NoContent
seedInventory rawToken = do
  requireSeedToken rawToken
  Env{..} <- ask
  liftIO $ flip runSqlPool envPool InputList.seedInventoryDB
  pure NoContent

seedHQ :: Maybe Text -> AppM NoContent
seedHQ rawToken = do
  requireSeedToken rawToken
  Env{..} <- ask
  now <- liftIO getCurrentTime
  liftIO $ flip runSqlPool envPool (InputList.seedHQDB now)
  pure NoContent

requireSeedToken :: Maybe Text -> AppM ()
requireSeedToken rawToken = do
  Env{..} <- ask
  let encodeBody = BL.fromStrict . TE.encodeUtf8
      missingHeader = throwError err401 { errBody = encodeBody "Missing X-Seed-Token header" }
      disabled = throwError err403 { errBody = encodeBody "Seeding endpoint disabled" }
      invalid = throwError err403 { errBody = encodeBody "Invalid seed token" }
      malformed = throwError err400 { errBody = encodeBody "Malformed X-Seed-Token header" }
      invalidTokenChar ch =
        isSpace ch
          || isControl ch
          || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]
  secret <- maybe disabled pure (seedTriggerToken envConfig)
  token <- maybe missingHeader pure rawToken
  when (T.null (T.strip token)) missingHeader
  when (token /= T.strip token || T.any invalidTokenChar token) malformed
  when (token /= secret) invalid
  pure ()

fanPublicServer :: ServerT FanPublicAPI AppM
fanPublicServer =
       listFanArtists
  :<|> fanArtistProfile
  :<|> fanArtistReleases
  :<|> fanArtistFans
  :<|> tipArtist
  :<|> getPublicClub
  :<|> getPublicClubEvents
  where
    listFanArtists :: AppM [ArtistProfileDTO]
    listFanArtists = do
      Env pool _ <- ask
      liftIO $ flip runSqlPool pool loadAllArtistProfilesDTO

    fanArtistProfile :: Int64 -> AppM ArtistProfileDTO
    fanArtistProfile artistId = do
      artistIdValid <- either throwError pure (validatePositiveIdField "artistId" artistId)
      Env pool _ <- ask
      mDto <- liftIO $ flip runSqlPool pool $ loadArtistProfileDTO (toSqlKey artistIdValid)
      maybe (throwError err404) pure mDto

    fanArtistReleases :: Int64 -> AppM [ArtistReleaseDTO]
    fanArtistReleases artistId = do
      artistIdValid <- either throwError pure (validatePositiveIdField "artistId" artistId)
      Env pool _ <- ask
      liftIO $ flip runSqlPool pool $ do
        releases <- selectList [ArtistReleaseArtistPartyId ==. toSqlKey artistIdValid] [Desc ArtistReleaseCreatedAt]
        pure (map toArtistReleaseDTO releases)

    fanArtistFans :: Int64 -> Maybe Int -> Maybe Int -> AppM ArtistFansResponse
    fanArtistFans artistId mPage mPageSize = do
      artistIdValid <- either throwError pure (validatePositiveIdField "artistId" artistId)
      let page = max 1 (fromMaybe 1 mPage)
          pageSize = min 100 (max 1 (fromMaybe 5 mPageSize))
          offset = (page - 1) * pageSize
      Env pool _ <- ask
      liftIO $ flip runSqlPool pool $ do
        let artistKey = toSqlKey artistIdValid
        total <- count [FanFollowArtistPartyId ==. artistKey]
        follows <- selectList
          [FanFollowArtistPartyId ==. artistKey]
          [Desc FanFollowCreatedAt, OffsetBy offset, LimitTo pageSize]
        fans <- forM follows $ \(Entity _ follow) -> do
          let fanPartyId = fanFollowFanPartyId follow
          mParty <- selectFirst [PartyId ==. fanPartyId] []
          mProfile <- selectFirst [FanProfileFanPartyId ==. fanPartyId] []
          let displayName = case mParty of
                Just (Entity _ p) -> M.partyDisplayName p
                Nothing -> "Fan"
              avatarUrl = mProfile >>= fanProfileAvatarUrl . entityVal
          pure ArtistFanDTO
            { afFanId = fromSqlKey fanPartyId
            , afDisplayName = displayName
            , afAvatarUrl = avatarUrl
            , afFollowedAt = fanFollowCreatedAt follow
            }
        pure ArtistFansResponse
          { afrItems = fans
          , afrPage = page
          , afrPageSize = pageSize
          , afrTotal = fromIntegral total
          }

    getPublicClub = fanClubPublicGetClub
    getPublicClubEvents = fanClubPublicGetEvents

    tipArtist :: Int64 -> APITypes.ArtistTipRequest -> AppM APITypes.ArtistTipResponse
    tipArtist artistIdRaw req = createArtistTip artistIdRaw req

artistPublicServer :: ServerT ArtistPublicAPI AppM
artistPublicServer =
       listArtists
  :<|> searchArtists
  :<|> artistPublicProfile
  :<|> artistProfileById
  where
    listArtists :: AppM [ArtistProfileDTO]
    listArtists = do
      Env pool _ <- ask
      liftIO $ flip runSqlPool pool loadAllArtistProfilesDTO

    searchArtists :: Maybe Text -> Maybe UUID.UUID -> Maybe Text -> AppM [ArtistProfileDTO]
    searchArtists mQuery mGenreId mLegacyGenre = do
      when (mLegacyGenre /= Nothing) $
        throwBadRequest "genre is obsolete; use the canonical genreId UUID parameter"
      Env pool _ <- ask
      liftIO $ flip runSqlPool pool $ searchArtistProfilesDTO mQuery mGenreId

    artistPublicProfile :: Text -> AppM ArtistProfileDTO
    artistPublicProfile rawRef = do
      let ref = T.strip rawRef
      when (T.null ref) $
        throwBadRequest "artistRef is required"
      Env pool _ <- ask
      mDto <- liftIO $ flip runSqlPool pool $
        case parseArtistPublicRef ref of
          ArtistPublicRefId artistId -> loadArtistProfileDTO (toSqlKey artistId)
          ArtistPublicRefSlug slug   -> loadArtistProfileBySlugDTO slug
      maybe (throwError err404 { errBody = "Artist profile not found" }) pure mDto

    artistProfileById :: Int64 -> AppM ArtistProfileDTO
    artistProfileById artistId = do
      artistIdValid <- either throwError pure (validatePositiveIdField "artistId" artistId)
      Env pool _ <- ask
      mDto <- liftIO $ flip runSqlPool pool $ loadArtistProfileDTO (toSqlKey artistIdValid)
      maybe (throwError err404 { errBody = "Artist profile not found" }) pure mDto

data ArtistPublicRef
  = ArtistPublicRefId Int64
  | ArtistPublicRefSlug Text

parseArtistPublicRef :: Text -> ArtistPublicRef
parseArtistPublicRef ref
  | T.all isDigit ref
  , Just artistId <- readMaybe (T.unpack ref)
  , artistId > 0 =
      ArtistPublicRefId artistId
  | otherwise =
      ArtistPublicRefSlug (T.toLower ref)

-- | Platform's cut of every artist tip, in basis points. 1000 = 10%.
-- Centralized so the rate is a one-line change when negotiated terms shift.
artistTipPlatformFeeBps :: Int
artistTipPlatformFeeBps = 1000

-- | POST /artists/:artistId/tips
--
-- Public destination charge that routes funds from the tipper to the artist's
-- connected Stripe account, keeping 'artistTipPlatformFeeBps' for the platform.
-- The tip row is persisted in @pending@ status BEFORE the Stripe call so we
-- always have an audit trail even if Stripe returns a transient error; the
-- @payment_intent.succeeded@ webhook flips it to @paid@.
createArtistTip
  :: Int64
  -> APITypes.ArtistTipRequest
  -> AppM APITypes.ArtistTipResponse
createArtistTip artistIdRaw req = do
  Env{..} <- ask
  now <- liftIO getCurrentTime
  when (APITypes.atrAmountCents req <= 0) $
    throwError err400 { errBody = "Tip amount must be greater than zero" }
  when (T.null (T.strip (APITypes.atrCurrency req))) $
    throwError err400 { errBody = "Tip currency is required" }
  let artistProfileKey = toSqlKey artistIdRaw :: ArtistProfileId
  mProfile <- runDB $ get artistProfileKey
  profile <- maybe (throwNotFound "Artista no encontrado") pure mProfile
  destinationAccountId <- case artistProfileStripeAccountId profile of
    Nothing -> throwError err400
      { errBody = "This artist has not finished payout onboarding" }
    Just acct -> pure acct
  let amountCents = APITypes.atrAmountCents req
      currency = T.toLower (T.strip (APITypes.atrCurrency req))
      platformFeeCents = (amountCents * artistTipPlatformFeeBps) `div` 10000
      tipRow = ME.ArtistTip
        { ME.artistTipArtistProfileId = artistProfileKey
        , ME.artistTipTipperPartyId = Nothing
        , ME.artistTipTipperEmail = APITypes.atrTipperEmail req
        , ME.artistTipTipperName = APITypes.atrTipperName req
        , ME.artistTipAmountCents = amountCents
        , ME.artistTipCurrency = currency
        , ME.artistTipPlatformFeeCents = platformFeeCents
        , ME.artistTipStripePaymentIntentId = Nothing
        , ME.artistTipStatus = "pending"
        , ME.artistTipMessage = APITypes.atrMessage req
        , ME.artistTipCreatedAt = now
        , ME.artistTipUpdatedAt = now
        }
  tipKey <- runDB $ insert tipRow
  case (stripeSecretKey envConfig, stripeWebhookSecret envConfig) of
    (Just secretKey, Just webhookSecret) -> do
      let stripeCfg = Stripe.StripeConfig
            { Stripe.stripeSecretKey = secretKey
            , Stripe.stripeWebhookSecret = webhookSecret
            , Stripe.stripeApiVersion = Stripe.defaultStripeApiVersion
            }
          tipperLabel = fromMaybe "anonymous" (APITypes.atrTipperName req)
          description = "Tip to artist " <> T.pack (show artistIdRaw) <> " from " <> tipperLabel
          metadata = object
            [ "purpose" .= ("artist_tip" :: Text)
            , "artist_tip_id" .= fromSqlKey tipKey
            , "artist_profile_id" .= artistIdRaw
            ]
          metadataJson =
            Just (TE.decodeUtf8 (BL.toStrict (encode metadata)))
      result <- liftIO $
        Stripe.createPaymentIntentForTip
          stripeCfg
          destinationAccountId
          amountCents
          platformFeeCents
          currency
          description
          metadataJson
      case result of
        Left err -> do
          runDB $ update tipKey
            [ ME.ArtistTipStatus =. "failed"
            , ME.ArtistTipUpdatedAt =. now
            ]
          throwError err500
            { errBody = BL.fromStrict (TE.encodeUtf8 ("Stripe tip error: " <> err))
            }
        Right paymentIntent -> do
          (piId, clientSecret) <- eitherStripeServerError $
            parseStripePaymentIntentResponse paymentIntent
          runDB $ update tipKey
            [ ME.ArtistTipStripePaymentIntentId =. Just piId
            , ME.ArtistTipUpdatedAt =. now
            ]
          pure APITypes.ArtistTipResponse
            { APITypes.atrespTipId = fromSqlKey tipKey
            , APITypes.atrespClientSecret = clientSecret
            , APITypes.atrespAmountCents = amountCents
            , APITypes.atrespCurrency = currency
            }
    _ -> throwError err500 { errBody = "Stripe is not configured" }

coursesPublicServer :: ServerT CoursesPublicAPI AppM
coursesPublicServer =
       courseMetadataH
  :<|> registrationH
  :<|> registrationStatusH
  :<|> datafastCheckoutH
  :<|> datafastStatusH
  :<|> paypalCreateH
  :<|> paypalCaptureH
  where
    courseMetadataH slug = do
      meta <- loadCourseMetadata slug
      terms <- CourseCheckoutServer.loadPublicCourseCheckoutTerms (normalizeSlug (courseMetaSlug meta))
      pure meta { Courses.checkoutTerms = terms }
    registrationH slug idempotencyKey payload =
      CourseCheckoutServer.createCourseCheckoutRegistration
        createOrUpdateRegistration slug idempotencyKey payload
    registrationStatusH = CourseCheckoutServer.getPublicCourseCheckout
    datafastCheckoutH = CourseCheckoutServer.createPublicCourseDatafastCheckout
    datafastStatusH = CourseCheckoutServer.confirmPublicCourseDatafastStatus
    paypalCreateH = CourseCheckoutServer.createPublicCoursePaypalOrder
    paypalCaptureH = CourseCheckoutServer.capturePublicCoursePaypalOrder

coursesAdminServer :: AuthedUser -> ServerT Courses.CoursesAdminAPI AppM
coursesAdminServer user =
       upsertCourseH
  :<|> listCourseCohortsH
  :<|> listRegistrationsH
  :<|> getRegistrationH
  :<|> getRegistrationDossierH
  :<|> listEmailEventsH
  :<|> updateStatusH
  :<|> updateNotesH
  :<|> createReceiptH
  :<|> updateReceiptH
  :<|> deleteReceiptH
  :<|> createFollowUpH
  :<|> updateFollowUpH
  :<|> deleteFollowUpH
  where
    requireCourseAdmin =
      either throwError pure (validateModuleAccess ModuleAdmin user)

    upsertCourseH payload = do
      requireCourseAdmin
      saveCourse payload

    listCourseCohortsH = do
      requireCourseAdmin
      listCourseCohorts

    listRegistrationsH mSlug mStatus mLimit = do
      requireCourseAdmin
      listCourseRegistrations mSlug mStatus mLimit

    getRegistrationH slug regId = do
      requireCourseAdmin
      fetchCourseRegistration slug regId

    getRegistrationDossierH slug regId = do
      requireCourseAdmin
      fetchCourseRegistrationDossier slug regId

    listEmailEventsH regId mLimit = do
      requireCourseAdmin
      listCourseRegistrationEmailEvents regId mLimit

    updateStatusH slug regId statusPayload = do
      requireCourseAdmin
      updateCourseRegistrationStatus user slug regId statusPayload

    updateNotesH slug regId payload = do
      requireCourseAdmin
      updateCourseRegistrationNotes slug regId payload

    createReceiptH slug regId payload = do
      requireCourseAdmin
      createCourseRegistrationReceipt user slug regId payload

    updateReceiptH slug regId receiptId payload = do
      requireCourseAdmin
      updateCourseRegistrationReceipt user slug regId receiptId payload

    deleteReceiptH slug regId receiptId = do
      requireCourseAdmin
      deleteCourseRegistrationReceipt user slug regId receiptId

    createFollowUpH slug regId payload = do
      requireCourseAdmin
      createCourseRegistrationFollowUp user slug regId payload

    updateFollowUpH slug regId followUpId payload = do
      requireCourseAdmin
      updateCourseRegistrationFollowUp user slug regId followUpId payload

    deleteFollowUpH slug regId followUpId = do
      requireCourseAdmin
      deleteCourseRegistrationFollowUp user slug regId followUpId

listEngineersPublic :: AppM [PublicEngineerDTO]
listEngineersPublic = do
  Env pool _ <- ask
  liftIO $ flip runSqlPool pool $ do
    partyIds <- selectCanonicalPartyIdsByRole Engineer
    parties <- selectList
      [ PartyId <-. partyIds
      , PartyPrimaryEmail !=. Nothing -- evita cuentas de sistema sin correo (p.ej. "Scheduling")
      ]
      [Asc PartyDisplayName]
    pure [PublicEngineerDTO (fromSqlKey pid) (M.partyDisplayName p) | Entity pid p <- parties]

data WhatsAppReceipt = WhatsAppReceipt
  { warFirst :: Bool
  -- ^ This delivery stored the message; False for a redelivery.
  , warConfirmed :: Bool
  -- ^ This delivery turned a pending consent request into consent.
  , warMessage :: Entity ME.WhatsAppMessage
  }

-- | Stores one inbound WhatsApp message and, in the same transaction, applies
-- what it asks for (opt-out keyword, consent confirmation). Meta delivers a
-- message again when an earlier delivery was slow or failed, and a signed body
-- stays valid, so a delivery that finds the message already stored changes
-- nothing: an earlier STOP must not undo a later subscription. Deliveries of
-- one message are taken one at a time.
receiveWhatsAppInbound :: UTCTime -> Maybe UTCTime -> IncomingWhatsAppRecord -> SqlPersistT IO WhatsAppReceipt
receiveWhatsAppInbound now sentAt record = do
  let externalId = T.strip (iwrExternalId record)
  unless (T.null externalId) $ do
    _ <- rawSql "SELECT 1::bigint FROM pg_advisory_xact_lock(hashtextextended(?,0))"
      [PersistText ("whatsapp-inbound:" <> externalId)] :: SqlPersistT IO [Single Int64]
    pure ()
  (first, message) <- receiveIncomingWhatsAppMessage now record
  -- Earlier versions stored the message and applied its effects in separate,
  -- later transactions, which may never have committed; such a row has no
  -- 'effects_applied' entry. Its next delivery applies them, once, so a STOP
  -- from before this version cannot stay ineffective. A row stored by this
  -- version carries the entry from its storing transaction.
  applied <- if first then pure False else whatsAppEffectsApplied (entityKey message)
  if applied
    then pure (WhatsAppReceipt False False message)
    else do
      when (CampaignAutomation.isWhatsAppCampaignOptOutMessage (iwrText record)) $
        CampaignAutomation.applyWhatsAppCampaignOptOut now (iwrSenderId record)
          (ME.whatsAppMessagePartyId (entityVal message))
      confirmed <-
        if isWhatsAppConsentConfirmationMessage (iwrText record)
          then applyWhatsAppConsentConfirmation now sentAt (iwrSenderId record)
          else pure False
      markWhatsAppEffectsApplied now (entityKey message)
      pure (WhatsAppReceipt first confirmed message)

whatsAppEffectsApplied :: Key ME.WhatsAppMessage -> SqlPersistT IO Bool
whatsAppEffectsApplied messageKey = do
  rows <- rawSql
    "SELECT 1::bigint FROM audit_log WHERE entity = 'whatsapp_message' AND entity_id = ? \
    \AND action = 'effects_applied' LIMIT 1"
    [PersistText (T.pack (show (fromSqlKey messageKey)))] :: SqlPersistT IO [Single Int64]
  pure (not (null rows))

markWhatsAppEffectsApplied :: UTCTime -> Key ME.WhatsAppMessage -> SqlPersistT IO ()
markWhatsAppEffectsApplied now messageKey =
  PersistSql.rawExecute
    "INSERT INTO audit_log(entity, entity_id, action, created_at) \
    \VALUES ('whatsapp_message', ?, 'effects_applied', ?)"
    [PersistText (T.pack (show (fromSqlKey messageKey))), toPersistValue now]

-- | Takes the one automatic reply an inbound message may receive. True for the
-- first caller only; the claim is an audit entry of the message, written
-- before the reply is sent, so a message is answered at most once. A message
-- answered before this version has no claim entry but carries its reply time,
-- which refuses the claim too.
-- | The idempotency key of the course registration a WhatsApp message makes.
whatsAppCourseRegistrationKey :: Key ME.WhatsAppMessage -> Text
whatsAppCourseRegistrationKey messageKey =
  "whatsapp-message-" <> T.pack (show (fromSqlKey messageKey))

-- | Whether a delivery of this message may reach the registration: the sender
-- is under the hourly cap, or this message already made its registration. The
-- second case is a redelivery after the registration committed and before the
-- reply was claimed; it creates nothing and must still complete the reply,
-- even when that registration was the one that filled the cap.
whatsAppCourseRegistrationAdmitted
  :: UTCTime -> Text -> Key ME.WhatsAppMessage -> SqlPersistT IO Bool
whatsAppCourseRegistrationAdmitted now phone messageKey = do
  rows <- rawSql
    "SELECT (SELECT count(*) FROM course_registration \
    \WHERE phone_e164 = ? AND source = 'whatsapp' AND created_at >= ?) < 3 \
    \OR EXISTS (SELECT 1 FROM identity_course_registration_request \
    \WHERE request_scope LIKE 'whatsapp-course:%' AND request_key = ?)"
    [ PersistText phone, PersistUTCTime (addUTCTime (-3600) now)
    , PersistText (whatsAppCourseRegistrationKey messageKey) ]
    :: SqlPersistT IO [Single Bool]
  pure (rows == [Single True])

claimWhatsAppAutoReply :: UTCTime -> Key ME.WhatsAppMessage -> SqlPersistT IO Bool
claimWhatsAppAutoReply now messageKey = do
  let messageId = T.pack (show (fromSqlKey messageKey))
  _ <- rawSql "SELECT 1::bigint FROM pg_advisory_xact_lock(hashtextextended(?,0))"
    [PersistText ("whatsapp-auto-reply:" <> messageId)] :: SqlPersistT IO [Single Int64]
  inserted <- PersistSql.rawExecuteCount
    "INSERT INTO audit_log(entity, entity_id, action, created_at) \
    \SELECT 'whatsapp_message', ?, 'auto_reply_claimed', ? \
    \WHERE NOT EXISTS (SELECT 1 FROM audit_log WHERE entity = 'whatsapp_message' \
    \AND entity_id = ? AND action = 'auto_reply_claimed') \
    \AND EXISTS (SELECT 1 FROM whats_app_message WHERE id = ? AND replied_at IS NULL)"
    [PersistText messageId, toPersistValue now, PersistText messageId, toPersistValue (fromSqlKey messageKey)]
  pure (inserted == 1)

whatsappWebhookServer :: ServerT WhatsAppWebhookAPI AppM
whatsappWebhookServer =
       verifyHook
  :<|> handleMessages
  where
    verifyHook mMode mToken mChallenge = do
      cfg <- liftIO loadWhatsAppEnv
      either throwError pure $
        validateHookVerifyRequest mMode mChallenge mToken (waVerifyToken cfg)

    handleMessages mSignature rawBody = do
      cfg <- liftIO loadWhatsAppEnv
      Env{envConfig, envPool} <- ask
      either throwError pure (verifyMetaWebhookSignature (facebookAppSecret envConfig) mSignature rawBody)
      payload <- case eitherDecode rawBody of
        Left parseErr -> throwError err400 { errBody = BL.fromStrict (TE.encodeUtf8 (T.pack ("Invalid JSON body: " <> parseErr))) }
        Right val -> pure val
      now <- liftIO getCurrentTime
      let deliveryUpdates = extractWhatsAppDeliveryUpdates payload
      let inbound = extractWhatsAppInbound payload
      liftIO $ flip runSqlPool envPool $
        for_ deliveryUpdates $ \WADeliveryStatus{..} -> do
          _ <- applyWhatsAppDeliveryUpdate now WhatsAppDeliveryUpdate
            { wduExternalId = waDeliveryExternalId
            , wduStatus = waDeliveryStatus
            , wduRecipientId = waDeliveryRecipientId
            , wduOccurredAt = waDeliveryOccurredAt
            , wduDeliveryError = waDeliveryError
            , wduStatusPayload = waDeliveryPayload
            }
          pure ()
      for_ inbound $ \WAInbound{..} -> do
        WhatsAppReceipt{warConfirmed, warMessage = incomingEntity} <-
          liftIO $ flip runSqlPool envPool $
            receiveWhatsAppInbound now waInboundSentAt IncomingWhatsAppRecord
              { iwrExternalId = waInboundExternalId
              , iwrSenderId = waInboundSenderId
              , iwrSenderName = waInboundSenderName
              , iwrText = waInboundText
              , iwrAdExternalId = waInboundAdExternalId
              , iwrAdName = waInboundAdName
              , iwrCampaignExternalId = waInboundCampaignExternalId
              , iwrCampaignName = waInboundCampaignName
              , iwrMetadata = waInboundMetadata
              , iwrTransportPayload = Nothing
              , iwrSource = Just "whatsapp_webhook"
              }
        when warConfirmed $ do
          -- Sample the outgoing notice time after the atomic inbound receipt.
          noticeAt <- liftIO getCurrentTime
          sendWhatsAppConsentNotice noticeAt waInboundSenderId waInboundSenderName "consent_confirmation"
            "Gracias, confirmamos tu suscripción a los mensajes de TDF Records por WhatsApp. Responde STOP para dejar de recibirlos."
        let lowerBody = T.toLower (T.strip waInboundText)
        -- Every delivery reaches the registration, which is keyed by the stored
        -- message and so is made once; a delivery that follows a failed one
        -- completes it. The reply is sent by the one delivery that claims it.
        when ("inscribirme" `T.isInfixOf` lowerBody) $ do
          case normalizePhone waInboundSenderId of
            Nothing -> pure ()
            Just phone -> do
              admitted <- liftIO $ flip runSqlPool envPool $
                whatsAppCourseRegistrationAdmitted now phone (entityKey incomingEntity)
              when admitted $ do
                _ <- createCourseRegistrationInScope "whatsapp-course" (productionCourseSlug envConfig)
                  (Just (whatsAppCourseRegistrationKey (entityKey incomingEntity)))
                  CourseRegistrationRequest
                  { fullName = Nothing
                  , email = Nothing
                  , phoneE164 = Just phone
                  , source = "whatsapp"
                  , howHeard = Just "whatsapp"
                  , utm = Nothing
                  , termsAccepted = Nothing
                  , acceptedTermsVersion = Nothing
                  }
                let incomingMsg = entityVal incomingEntity
                claimed <- liftIO $ flip runSqlPool envPool $
                  claimWhatsAppAutoReply now (entityKey incomingEntity)
                when claimed $ do
                  (replyTxt, replyRes) <- sendWhatsappReply cfg phone
                  liftIO $ flip runSqlPool envPool $ do
                    _ <- recordOutgoingWhatsAppMessage now OutgoingWhatsAppRecord
                      { owrRecipientPhone = phone
                      , owrRecipientPartyId = ME.whatsAppMessagePartyId incomingMsg
                      , owrRecipientName = waInboundSenderName <|> ME.whatsAppMessageSenderName incomingMsg
                      , owrRecipientEmail = ME.whatsAppMessageContactEmail incomingMsg
                      , owrActorPartyId = Nothing
                      , owrBody = replyTxt
                      , owrSource = Just "course_enrollment_auto_reply"
                      , owrReplyToMessageId = Just (entityKey incomingEntity)
                      , owrReplyToExternalId = Just (ME.whatsAppMessageExternalId incomingMsg)
                      , owrResendOfMessageId = Nothing
                      , owrMetadata = Nothing
                      }
                      replyRes
                    pure ()
      pure NoContent

whatsappHooksServer :: ServerT WhatsAppHooksAPI AppM
whatsappHooksServer = whatsappWebhookServer

whatsappMessagesServer :: AuthedUser -> ServerT Api.WhatsAppMessagesAPI AppM
whatsappMessagesServer user mLimit mDirection mRepliedOnly = do
  unless (hasSocialInboxAccess user) $
    throwError err403 { errBody = "Missing required module access" }
  limit <- either throwError pure (validateWhatsAppMessagesLimit mLimit)
  direction <- either throwError pure (parseDirectionParam mDirection)
  repliedOnly <- either throwError pure (parseBoolParam mRepliedOnly)
  let filters =
        concat
          [ maybe [] (\dir -> [ME.WhatsAppMessageDirection ==. dir]) direction
          , if repliedOnly then [ME.WhatsAppMessageRepliedAt !=. Nothing] else []
          ]
  rows <- runDB $
    selectList filters [Desc ME.WhatsAppMessageCreatedAt, LimitTo limit]
  let toObj (Entity msgKey m) = object
        [ "id" .= fromSqlKey msgKey
        , "externalId" .= ME.whatsAppMessageExternalId m
        , "partyId"    .= fmap fromSqlKey (ME.whatsAppMessagePartyId m)
        , "actorPartyId" .= fmap fromSqlKey (ME.whatsAppMessageActorPartyId m)
        , "senderId"   .= ME.whatsAppMessageSenderId m
        , "senderName" .= ME.whatsAppMessageSenderName m
        , "phoneE164"  .= ME.whatsAppMessagePhoneE164 m
        , "contactEmail" .= ME.whatsAppMessageContactEmail m
        , "text"       .= ME.whatsAppMessageText m
        , "metadata"   .= ME.whatsAppMessageMetadata m
        , "direction"  .= ME.whatsAppMessageDirection m
        , "replyStatus" .= ME.whatsAppMessageReplyStatus m
        , "repliedAt"  .= ME.whatsAppMessageRepliedAt m
        , "replyText"  .= ME.whatsAppMessageReplyText m
        , "replyError" .= ME.whatsAppMessageReplyError m
        , "deliveryStatus" .= ME.whatsAppMessageDeliveryStatus m
        , "deliveryUpdatedAt" .= ME.whatsAppMessageDeliveryUpdatedAt m
        , "deliveryError" .= ME.whatsAppMessageDeliveryError m
        , "source" .= ME.whatsAppMessageSource m
        , "resendOfMessageId" .= fmap fromSqlKey (ME.whatsAppMessageResendOfMessageId m)
        , "createdAt"  .= ME.whatsAppMessageCreatedAt m
        ]
  pure (toJSON (map toObj rows))

whatsappReplyServer :: AuthedUser -> ServerT Api.WhatsAppReplyAPI AppM
whatsappReplyServer user =
  whatsappManualReplyHandler user :<|> whatsappOperatorQuestionHandler user

whatsappManualReplyHandler :: AuthedUser -> WhatsAppReplyReq -> AppM Value
whatsappManualReplyHandler user WhatsAppReplyReq{..} = do
  unless (hasSocialInboxAccess user) $
    throwError err403 { errBody = "Missing required module access" }
  let recipientRaw = T.strip wrSenderId
  when (T.null recipientRaw) $ throwBadRequest "Remitente requerido"
  recipient <- either throwError pure (validateWhatsAppPhoneInput recipientRaw)
  mExternalId <- either throwError pure (validateWhatsAppReplyExternalId wrExternalId)
  body <- either throwError pure (validateWhatsAppReplyBody wrMessage)
  mReplyTargetRaw <- case mExternalId of
    Nothing -> pure Nothing
    Just extId -> runDB $ getBy (ME.UniqueWhatsAppMessage extId)
  mReplyTarget <- either throwError pure $
    validateWhatsAppReplyTarget recipient mExternalId mReplyTargetRaw
  now <- liftIO getCurrentTime
  waEnv <- liftIO loadWhatsAppEnv
  sendResult <- sendWhatsAppText waEnv recipient body
  sentEntity <- runDB $
    recordOutgoingWhatsAppMessage now OutgoingWhatsAppRecord
      { owrRecipientPhone = recipient
      , owrRecipientPartyId = mReplyTarget >>= (ME.whatsAppMessagePartyId . entityVal)
      , owrRecipientName = mReplyTarget >>= (ME.whatsAppMessageSenderName . entityVal)
      , owrRecipientEmail = mReplyTarget >>= (ME.whatsAppMessageContactEmail . entityVal)
      , owrActorPartyId = Just (auPartyId user)
      , owrBody = body
      , owrSource = Just "manual_reply"
      , owrReplyToMessageId = entityKey <$> mReplyTarget
      , owrReplyToExternalId = mExternalId
      , owrResendOfMessageId = Nothing
      , owrMetadata = Nothing
      }
      sendResult
  case sendResult of
    Left err ->
      pure (object
        [ "status" .= ("error" :: Text)
        , "message" .= err
        , "messageId" .= fromSqlKey (entityKey sentEntity)
        , "deliveryStatus" .= ME.whatsAppMessageDeliveryStatus (entityVal sentEntity)
        ])
    Right _ ->
      pure (object
        [ "status" .= ("ok" :: Text)
        , "message" .= ("sent" :: Text)
        , "messageId" .= fromSqlKey (entityKey sentEntity)
        , "deliveryStatus" .= ME.whatsAppMessageDeliveryStatus (entityVal sentEntity)
        ])

whatsappOperatorQuestionHandler :: AuthedUser -> WhatsAppOperatorQuestionReq -> AppM Value
whatsappOperatorQuestionHandler user WhatsAppOperatorQuestionReq{..} = do
  unless (hasSocialInboxAccess user) $
    throwError err403 { errBody = "Missing required module access" }
  Env{envConfig} <- ask
  channel <- either throwError pure (validateOperatorQuestionChannel woqChannel)
  senderId <- either throwError pure (validateOperatorQuestionRequiredIdentifier "senderId" woqSenderId)
  externalId <- either throwError pure (validateOperatorQuestionIdentifier "externalId" woqExternalId)
  inboundMessage <-
    either throwError pure
      (validateOperatorQuestionTextField "inboundMessage" operatorQuestionInboundMaxChars woqInboundMessage)
  holdReason <-
    either throwError pure
      (validateOperatorQuestionTextField "holdReason" operatorQuestionDetailMaxChars woqHoldReason)
  neededInfo <-
    either throwError pure
      (validateOperatorQuestionTextField "neededInfo" operatorQuestionDetailMaxChars woqNeededInfo)
  operatorPhone <-
    liftIO resolveOperatorWhatsAppPhone
      >>= either
        (\msg -> throwError err503 { errBody = BL.fromStrict (TE.encodeUtf8 msg) })
        pure
  let body =
        buildOperatorQuestionMessage
          envConfig
          channel
          senderId
          externalId
          inboundMessage
          holdReason
          neededInfo
      metadata =
        Just $
          TE.decodeUtf8 $
            BL.toStrict $
              encode $
                object
                  [ "source" .= ("ai_operator_question" :: Text)
                  , "channel" .= channel
                  , "senderId" .= senderId
                  , "externalId" .= externalId
                  ]
  now <- liftIO getCurrentTime
  waEnv <- liftIO loadWhatsAppEnv
  sendResult <- sendWhatsAppText waEnv operatorPhone body
  sentEntity <- runDB $
    recordOutgoingWhatsAppMessage now OutgoingWhatsAppRecord
      { owrRecipientPhone = operatorPhone
      , owrRecipientPartyId = Nothing
      , owrRecipientName = Just "Operador TDF"
      , owrRecipientEmail = Nothing
      , owrActorPartyId = Just (auPartyId user)
      , owrBody = body
      , owrSource = Just "ai_operator_question"
      , owrReplyToMessageId = Nothing
      , owrReplyToExternalId = externalId
      , owrResendOfMessageId = Nothing
      , owrMetadata = metadata
      }
      sendResult
  case sendResult of
    Left err ->
      pure (object
        [ "status" .= ("error" :: Text)
        , "message" .= err
        , "messageId" .= fromSqlKey (entityKey sentEntity)
        , "deliveryStatus" .= ME.whatsAppMessageDeliveryStatus (entityVal sentEntity)
        ])
    Right _ ->
      pure (object
        [ "status" .= ("ok" :: Text)
        , "message" .= ("Pregunta enviada por WhatsApp al operador." :: Text)
        , "messageId" .= fromSqlKey (entityKey sentEntity)
        , "deliveryStatus" .= ME.whatsAppMessageDeliveryStatus (entityVal sentEntity)
        ])

whatsappConsentServer :: AuthedUser -> ServerT Api.WhatsAppConsentAPI AppM
whatsappConsentServer user =
  let requireAdmin = unless (hasRole Admin user) $ throwError err403
  in whatsappConsentRoutes "tdf-hq-ui" True requireAdmin

whatsappConsentPublicServer :: ServerT Api.WhatsAppConsentPublicAPI AppM
whatsappConsentPublicServer =
  publicRequestWhatsAppConsent :<|> publicWhatsAppOptOut :<|> retiredPublicConsentLookup
  where
    retiredPublicConsentLookup _ =
      throwError err410
        { errBody = "The public WhatsApp consent lookup was retired; consent state is not disclosed." }

-- | A public form cannot prove control of a phone number, so it records a
-- pending request and asks the number itself to confirm by replying. The
-- response never reveals whether the number had consented or was recently
-- asked, and a number receives at most one confirmation request per interval.
publicRequestWhatsAppConsent :: WhatsAppConsentRequest -> AppM WhatsAppConsentResponse
publicRequestWhatsAppConsent WhatsAppConsentRequest{..} = do
  unless wcrConsent $ throwBadRequest "Debes aceptar el consentimiento para continuar."
  phoneVal <- either throwError pure (validateWhatsAppPhoneInput wcrPhone)
  nameClean <- either throwError pure (validateWhatsAppConsentDisplayName wcrName)
  sourceClean <- either throwError pure (validateWhatsAppConsentSource "public" wcrSource)
  now <- liftIO getCurrentTime
  claimed <- runDB (claimWhatsAppConfirmationRequest now phoneVal nameClean sourceClean)
  for_ claimed $ \requestedAt -> do
    result <- sendWhatsAppConfirmationRequest now phoneVal nameClean
    -- A request that never reached the number must not block a prompt retry,
    -- and the person can still confirm it by messaging SI themselves.
    when (isLeft result) $
      runDB (markWhatsAppConfirmationRequestUnsent requestedAt phoneVal)
  pure (publicWhatsAppConsentResponse phoneVal
    "Si el número es válido, recibirá un WhatsApp de TDF Records. Responde SI a ese mensaje para confirmar tu suscripción.")

-- | Opting out needs no proof of control; a confirmation message is sent only
-- to a number that was actually subscribed, so the form cannot message strangers.
-- The withdrawal instant invalidates a pending request; the request instant is
-- kept so that withdrawing cannot be used to request another message early.
publicWhatsAppOptOut :: WhatsAppOptOutRequest -> AppM WhatsAppConsentResponse
publicWhatsAppOptOut WhatsAppOptOutRequest{..} = do
  phoneVal <- either throwError pure (validateWhatsAppPhoneInput worPhone)
  reasonClean <- either throwError pure (validateWhatsAppOptOutReason worReason)
  now <- liftIO getCurrentTime
  wasActive <- runDB $ do
    existing <- getBy (ME.UniqueWhatsAppConsent phoneVal)
    _ <- upsert ME.WhatsAppConsent
      { ME.whatsAppConsentPhoneE164 = phoneVal
      , ME.whatsAppConsentDisplayName = Nothing
      , ME.whatsAppConsentConsent = False
      , ME.whatsAppConsentSource = Just "opt-out"
      , ME.whatsAppConsentNote = reasonClean
      , ME.whatsAppConsentConsentedAt = Nothing
      , ME.whatsAppConsentRevokedAt = Just now
      , ME.whatsAppConsentConfirmationRequestedAt = Nothing
      , ME.whatsAppConsentCreatedAt = now
      , ME.whatsAppConsentUpdatedAt = now
      }
      [ ME.WhatsAppConsentConsent =. False
      , ME.WhatsAppConsentSource =. Just "opt-out"
      , ME.WhatsAppConsentNote =. reasonClean
      , ME.WhatsAppConsentConsentedAt =. Nothing
      , ME.WhatsAppConsentRevokedAt =. Just now
      , ME.WhatsAppConsentUpdatedAt =. now
      ]
    CampaignAutomation.settleWhatsAppWithdrawalInstant phoneVal
    pure (maybe False (ME.whatsAppConsentConsent . entityVal) existing)
  when wasActive $
    sendWhatsAppConsentNotice now phoneVal Nothing "opt_out_confirmation"
      "Listo. No recibirás más mensajes de TDF Records por WhatsApp. Si fue un error, escríbenos y lo reactivamos."
  pure (publicWhatsAppConsentResponse phoneVal
    "Si el número estaba suscrito, quedó dado de baja y no recibirá más mensajes de TDF Records.")

publicWhatsAppConsentResponse :: Text -> Text -> WhatsAppConsentResponse
publicWhatsAppConsentResponse phoneVal message =
  WhatsAppConsentResponse
    { wcrsStatus = WhatsAppConsentStatus
        { wcsPhone = phoneVal
        , wcsConsent = False
        , wcsConsentedAt = Nothing
        , wcsRevokedAt = Nothing
        , wcsDisplayName = Nothing
        }
    , wcrsMessageSent = False
    , wcrsMessage = Just message
    }

sendWhatsAppConsentNotice :: UTCTime -> Text -> Maybe Text -> Text -> Text -> AppM ()
sendWhatsAppConsentNotice now phoneVal nameClean source message = do
  waEnv <- liftIO loadWhatsAppEnv
  result <- sendWhatsAppText waEnv phoneVal message
  recordWhatsAppConsentNotice now phoneVal nameClean source message result

-- | Business-initiated messages outside a customer-service window require an
-- approved template; configure WHATSAPP_CONSENT_TEMPLATE (body without
-- variables) and optionally WHATSAPP_CONSENT_TEMPLATE_LANGUAGE (default es).
-- Without it the free-form request only reaches numbers inside an open window,
-- and the person can still confirm by messaging SI first.
sendWhatsAppConfirmationRequest :: UTCTime -> Text -> Maybe Text -> AppM (Either Text SendTextResult)
sendWhatsAppConfirmationRequest now phoneVal nameClean = do
  waEnv <- liftIO loadWhatsAppEnv
  mTemplate <- liftIO (lookupEnv "WHATSAPP_CONSENT_TEMPLATE")
  mLanguage <- liftIO (lookupEnv "WHATSAPP_CONSENT_TEMPLATE_LANGUAGE")
  let template = T.strip . T.pack <$> mTemplate
      language = maybe "es" (T.strip . T.pack) mLanguage
  (body, result) <- case template of
    Just name | not (T.null name) -> do
      res <- liftIO (sendWhatsAppTemplateIO waEnv phoneVal name language [])
      pure ("[template " <> name <> "/" <> language <> "]", res)
    _ -> do
      let message = whatsAppConfirmationRequestMessage nameClean
      res <- sendWhatsAppText waEnv phoneVal message
      pure (message, res)
  recordWhatsAppConsentNotice now phoneVal nameClean "consent_confirmation_request" body result
  pure result

recordWhatsAppConsentNotice
  :: UTCTime -> Text -> Maybe Text -> Text -> Text -> Either Text SendTextResult -> AppM ()
recordWhatsAppConsentNotice now phoneVal nameClean source message result =
  void $ runDB $
    recordOutgoingWhatsAppMessage now OutgoingWhatsAppRecord
      { owrRecipientPhone = phoneVal
      , owrRecipientPartyId = Nothing
      , owrRecipientName = nameClean
      , owrRecipientEmail = Nothing
      , owrActorPartyId = Nothing
      , owrBody = message
      , owrSource = Just source
      , owrReplyToMessageId = Nothing
      , owrReplyToExternalId = Nothing
      , owrResendOfMessageId = Nothing
      , owrMetadata = Nothing
      }
      result

-- | Claims the right to send one confirmation request: at most once per number
-- per resend interval unless the previous request was not accepted by the
-- provider, never for an active consent. One conditional update, so concurrent
-- submissions cannot both claim. Returns the request instant the send is bound to.
claimWhatsAppConfirmationRequest
  :: UTCTime -> Text -> Maybe Text -> Maybe Text -> SqlPersistT IO (Maybe UTCTime)
claimWhatsAppConfirmationRequest now phoneVal nameClean sourceClean = do
  -- Simultaneous first requests for a number must not fail on its unique row.
  rawExecute
    "INSERT INTO whats_app_consent (phone_e164, display_name, consent, source, note, created_at, updated_at) \
    \VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT DO NOTHING"
    [ toPersistValue phoneVal
    , toPersistValue nameClean
    , toPersistValue False
    , toPersistValue sourceClean
    , toPersistValue whatsAppSentRequestNote
    , toPersistValue now
    , toPersistValue now
    ]
  -- A withdrawal keeps the request instant, so withdrawing cannot reopen the
  -- interval. An undelivered, unwithdrawn request may be sent again only inside
  -- its short window and keeps its instant, so retries cannot extend the time
  -- in which a number that saw no prompt could confirm.
  let intervalStart = addUTCTime (negate whatsAppConfirmationResendInterval) now
  changed <- rawExecuteCount
    "UPDATE whats_app_consent \
    \SET confirmation_requested_at = CASE \
    \WHEN confirmation_requested_at IS NULL OR confirmation_requested_at < ? THEN ? \
    \ELSE confirmation_requested_at END, \
    \display_name = ?, source = ?, note = ?, updated_at = ? \
    \WHERE phone_e164 = ? AND NOT consent \
    \AND (confirmation_requested_at IS NULL OR confirmation_requested_at < ? \
    \OR (note = ? AND confirmation_requested_at >= ? \
    \AND (revoked_at IS NULL OR revoked_at < confirmation_requested_at)))"
    [ toPersistValue intervalStart
    , toPersistValue now
    , toPersistValue nameClean
    , toPersistValue sourceClean
    , toPersistValue whatsAppSentRequestNote
    , toPersistValue now
    , toPersistValue phoneVal
    , toPersistValue intervalStart
    , toPersistValue whatsAppUnsentRequestNote
    , toPersistValue (addUTCTime (negate whatsAppUnsentConfirmationWindow) now)
    ]
  if changed /= 1
    then pure Nothing
    else fmap (>>= ME.whatsAppConsentConfirmationRequestedAt . entityVal)
           (getBy (ME.UniqueWhatsAppConsent phoneVal))

-- | Records that the provider did not accept this exact claim's request. The
-- request stays pending so the number can confirm it by messaging first, but
-- only briefly, and it no longer blocks a new request. A later claim or a
-- withdrawal is left untouched.
markWhatsAppConfirmationRequestUnsent :: UTCTime -> Text -> SqlPersistT IO ()
markWhatsAppConfirmationRequestUnsent claimedAt phoneVal =
  updateWhere
    [ ME.WhatsAppConsentPhoneE164 ==. phoneVal
    , ME.WhatsAppConsentConsent ==. False
    , ME.WhatsAppConsentConfirmationRequestedAt ==. Just claimedAt
    , ME.WhatsAppConsentNote ==. Just whatsAppSentRequestNote
    ]
    [ME.WhatsAppConsentNote =. Just whatsAppUnsentRequestNote]

whatsAppSentRequestNote :: Text
whatsAppSentRequestNote = "pending_confirmation"

whatsAppUnsentRequestNote :: Text
whatsAppUnsentRequestNote = "pending_unsent"

parseWhatsAppMessageTimestamp :: Maybe Text -> Maybe UTCTime
parseWhatsAppMessageTimestamp rawTimestamp = do
  digits <- T.strip <$> rawTimestamp
  if T.null digits || T.length digits > 12 || not (T.all isDigit digits)
    then Nothing
    else Just (posixSecondsToUTCTime (fromInteger (read (T.unpack digits))))

whatsAppConfirmationRequestMessage :: Maybe Text -> Text
whatsAppConfirmationRequestMessage nameClean =
  maybe "Hola! " (\nm -> "Hola " <> nm <> "! ") nameClean
    <> "Recibimos una solicitud para recibir mensajes de TDF Records por WhatsApp. "
    <> "Responde SI para confirmar. Si no la hiciste tú, ignora este mensaje."

whatsAppConfirmationResendInterval :: NominalDiffTime
whatsAppConfirmationResendInterval = 24 * 3600

whatsAppConfirmationWindow :: NominalDiffTime
whatsAppConfirmationWindow = 7 * 24 * 3600

-- | The number never received a prompt for an unsent request, so only a reply
-- made while the person is still completing the form may confirm it.
whatsAppUnsentConfirmationWindow :: NominalDiffTime
whatsAppUnsentConfirmationWindow = 3600

isWhatsAppConsentConfirmationMessage :: Text -> Bool
isWhatsAppConsentConfirmationMessage rawMessage =
  normalized `elem` ["si", "sí", "yes", "acepto", "confirmo"]
  where
    normalized = T.toCaseFold (T.dropAround (not . isAlphaNum) (T.strip rawMessage))

-- | Activates consent only for a pending request on the replying number that is
-- inside its confirmation window (shorter when the request was never delivered),
-- was created no later than the reply itself and has not been withdrawn since.
-- One conditional update: a concurrent opt-out wins, and a delayed or replayed
-- earlier reply cannot confirm a newer request. The request instant is kept so
-- the per-number interval still applies after a confirmation or a withdrawal.
applyWhatsAppConsentConfirmation :: UTCTime -> Maybe UTCTime -> Text -> SqlPersistT IO Bool
applyWhatsAppConsentConfirmation _ Nothing _ = pure False
applyWhatsAppConsentConfirmation now (Just sentAt) senderPhone = do
  changed <- rawExecuteCount
    "UPDATE whats_app_consent \
    \SET consent = ?, consented_at = ?, revoked_at = NULL, note = ?, updated_at = ? \
    \WHERE phone_e164 = ? AND NOT consent \
    \AND confirmation_requested_at <= ? \
    \AND (revoked_at IS NULL OR revoked_at < confirmation_requested_at) \
    \AND ((note = ? AND confirmation_requested_at >= ?) OR (note = ? AND confirmation_requested_at >= ?))"
    [ toPersistValue True
    , toPersistValue now
    , toPersistValue ("confirmed_by_reply" :: Text)
    , toPersistValue now
    , toPersistValue senderPhone
    , toPersistValue sentAt
    , toPersistValue whatsAppSentRequestNote
    , toPersistValue (addUTCTime (negate whatsAppConfirmationWindow) now)
    , toPersistValue whatsAppUnsentRequestNote
    , toPersistValue (addUTCTime (negate whatsAppUnsentConfirmationWindow) now)
    ]
  pure (changed == 1)

whatsAppConsentStatusFromRow
  :: Bool
  -> Text
  -> Maybe (Entity ME.WhatsAppConsent)
  -> WhatsAppConsentStatus
whatsAppConsentStatusFromRow exposeDisplayName phoneVal mRow =
  case mRow of
    Nothing ->
      WhatsAppConsentStatus
        { wcsPhone = phoneVal
        , wcsConsent = False
        , wcsConsentedAt = Nothing
        , wcsRevokedAt = Nothing
        , wcsDisplayName = Nothing
        }
    Just (Entity _ row) ->
      WhatsAppConsentStatus
        { wcsPhone = phoneVal
        , wcsConsent = ME.whatsAppConsentConsent row
        , wcsConsentedAt = ME.whatsAppConsentConsentedAt row
        , wcsRevokedAt = ME.whatsAppConsentRevokedAt row
        , wcsDisplayName =
            if exposeDisplayName
              then ME.whatsAppConsentDisplayName row
              else Nothing
        }

whatsappConsentRoutes :: Text -> Bool -> AppM () -> ServerT Api.WhatsAppConsentRoutes AppM
whatsappConsentRoutes defaultSource exposeDisplayName requireGate =
       createConsent
  :<|> revokeConsent
  :<|> fetchStatus
  where
    normalizePhoneOrFail raw =
      either throwError pure (validateWhatsAppPhoneInput raw)

    toStatus = whatsAppConsentStatusFromRow exposeDisplayName

    persistConsent phoneVal nameClean sourceClean noteClean now = runDB $ do
      let record =
            ME.WhatsAppConsent
              { ME.whatsAppConsentPhoneE164 = phoneVal
              , ME.whatsAppConsentDisplayName = nameClean
              , ME.whatsAppConsentConsent = True
              , ME.whatsAppConsentSource = sourceClean
              , ME.whatsAppConsentNote = noteClean
              , ME.whatsAppConsentConsentedAt = Just now
              , ME.whatsAppConsentRevokedAt = Nothing
              , ME.whatsAppConsentConfirmationRequestedAt = Nothing
              , ME.whatsAppConsentCreatedAt = now
              , ME.whatsAppConsentUpdatedAt = now
              }
      _ <- upsert record
        [ ME.WhatsAppConsentDisplayName =. nameClean
        , ME.WhatsAppConsentConsent =. True
        , ME.WhatsAppConsentSource =. sourceClean
        , ME.WhatsAppConsentNote =. noteClean
        , ME.WhatsAppConsentConsentedAt =. Just now
        , ME.WhatsAppConsentRevokedAt =. Nothing
        , ME.WhatsAppConsentUpdatedAt =. now
        ]
      getBy (ME.UniqueWhatsAppConsent phoneVal)

    persistOptOut phoneVal reasonClean now = runDB $ do
      let record =
            ME.WhatsAppConsent
              { ME.whatsAppConsentPhoneE164 = phoneVal
              , ME.whatsAppConsentDisplayName = Nothing
              , ME.whatsAppConsentConsent = False
              , ME.whatsAppConsentSource = Just "opt-out"
              , ME.whatsAppConsentNote = reasonClean
              , ME.whatsAppConsentConsentedAt = Nothing
              , ME.whatsAppConsentRevokedAt = Just now
              , ME.whatsAppConsentConfirmationRequestedAt = Nothing
              , ME.whatsAppConsentCreatedAt = now
              , ME.whatsAppConsentUpdatedAt = now
              }
      _ <- upsert record
        [ ME.WhatsAppConsentDisplayName =. Nothing
        , ME.WhatsAppConsentConsent =. False
        , ME.WhatsAppConsentSource =. Just "opt-out"
        , ME.WhatsAppConsentNote =. reasonClean
        , ME.WhatsAppConsentConsentedAt =. Nothing
        , ME.WhatsAppConsentRevokedAt =. Just now
        , ME.WhatsAppConsentUpdatedAt =. now
        ]
      CampaignAutomation.settleWhatsAppWithdrawalInstant phoneVal
      getBy (ME.UniqueWhatsAppConsent phoneVal)

    sendConsentMessage phoneVal nameClean = do
      waEnv <- liftIO loadWhatsAppEnv
      let greeting =
            case nameClean of
              Just nm -> "Hola " <> nm <> "! "
              Nothing -> "Hola! "
          msg = greeting <>
            "Gracias por aceptar recibir mensajes de TDF Records por WhatsApp. " <>
            "Responde STOP si deseas dejar de recibir mensajes."
      result <- sendWhatsAppText waEnv phoneVal msg
      pure (msg, result)

    sendOptOutMessage phoneVal = do
      waEnv <- liftIO loadWhatsAppEnv
      let msg = "Listo. No recibirás más mensajes de TDF Records por WhatsApp. " <>
                "Si fue un error, escríbenos y lo reactivamos."
      result <- sendWhatsAppText waEnv phoneVal msg
      pure (msg, result)

    createConsent WhatsAppConsentRequest{..} = do
      requireGate
      unless wcrConsent $ throwBadRequest "Debes aceptar el consentimiento para continuar."
      phoneVal <- normalizePhoneOrFail wcrPhone
      nameClean <- either throwError pure (validateWhatsAppConsentDisplayName wcrName)
      sourceClean <- either throwError pure (validateWhatsAppConsentSource defaultSource wcrSource)
      now <- liftIO getCurrentTime
      let noteClean = Just "consent"
          shouldSend = fromMaybe True wcrSendMessage
      _ <- persistConsent phoneVal nameClean sourceClean noteClean now
      (sent, msgText) <- if shouldSend
        then do
          (msg, res) <- sendConsentMessage phoneVal nameClean
          _ <- runDB $
            recordOutgoingWhatsAppMessage now OutgoingWhatsAppRecord
              { owrRecipientPhone = phoneVal
              , owrRecipientPartyId = Nothing
              , owrRecipientName = nameClean
              , owrRecipientEmail = Nothing
              , owrActorPartyId = Nothing
              , owrBody = msg
              , owrSource = Just "consent_confirmation"
              , owrReplyToMessageId = Nothing
              , owrReplyToExternalId = Nothing
              , owrResendOfMessageId = Nothing
              , owrMetadata = Nothing
              }
              res
          pure $ case res of
            Left err -> (False, Just err)
            Right _ -> (True, Just msg)
        else pure (False, Nothing)
      status <- runDB $ getBy (ME.UniqueWhatsAppConsent phoneVal)
      pure WhatsAppConsentResponse
        { wcrsStatus = toStatus phoneVal status
        , wcrsMessageSent = sent
        , wcrsMessage = msgText
        }

    revokeConsent WhatsAppOptOutRequest{..} = do
      requireGate
      phoneVal <- normalizePhoneOrFail worPhone
      reasonClean <- either throwError pure (validateWhatsAppOptOutReason worReason)
      now <- liftIO getCurrentTime
      let shouldSend = fromMaybe True worSendMessage
      _ <- persistOptOut phoneVal reasonClean now
      (sent, msgText) <- if shouldSend
        then do
          (msg, res) <- sendOptOutMessage phoneVal
          _ <- runDB $
            recordOutgoingWhatsAppMessage now OutgoingWhatsAppRecord
              { owrRecipientPhone = phoneVal
              , owrRecipientPartyId = Nothing
              , owrRecipientName = Nothing
              , owrRecipientEmail = Nothing
              , owrActorPartyId = Nothing
              , owrBody = msg
              , owrSource = Just "opt_out_confirmation"
              , owrReplyToMessageId = Nothing
              , owrReplyToExternalId = Nothing
              , owrResendOfMessageId = Nothing
              , owrMetadata = Nothing
              }
              res
          pure $ case res of
            Left err -> (False, Just err)
            Right _ -> (True, Just msg)
        else pure (False, Nothing)
      status <- runDB $ getBy (ME.UniqueWhatsAppConsent phoneVal)
      pure WhatsAppConsentResponse
        { wcrsStatus = toStatus phoneVal status
        , wcrsMessageSent = sent
        , wcrsMessage = msgText
        }

    fetchStatus mPhone = do
      requireGate
      phoneRaw <- maybe (throwBadRequest "phone requerido") pure mPhone
      phoneVal <- normalizePhoneOrFail phoneRaw
      mRow <- runDB $ getBy (ME.UniqueWhatsAppConsent phoneVal)
      pure (toStatus phoneVal mRow)

validateWhatsAppConsentDisplayName :: Maybe Text -> Either ServerError (Maybe Text)
validateWhatsAppConsentDisplayName =
  validateOptionalWhatsAppConsentText "name" maxWhatsAppConsentDisplayNameChars

validateWhatsAppConsentSource :: Text -> Maybe Text -> Either ServerError (Maybe Text)
validateWhatsAppConsentSource defaultSource rawSource =
  case validateOptionalWhatsAppConsentText "source" maxWhatsAppConsentSourceChars rawSource of
    Left err -> Left err
    Right (Just sourceVal) -> Right (Just sourceVal)
    Right Nothing -> Just <$> validateDefaultWhatsAppConsentSource defaultSource

validateDefaultWhatsAppConsentSource :: Text -> Either ServerError Text
validateDefaultWhatsAppConsentSource defaultSource =
  case validateOptionalWhatsAppConsentText "source" maxWhatsAppConsentSourceChars (Just defaultSource) of
    Right (Just sourceVal) -> Right sourceVal
    _ -> Left err500 { errBody = "Invalid WhatsApp consent default source" }

validateWhatsAppOptOutReason :: Maybe Text -> Either ServerError (Maybe Text)
validateWhatsAppOptOutReason =
  validateOptionalWhatsAppConsentText "reason" maxWhatsAppOptOutReasonChars

validateOptionalWhatsAppConsentText
  :: Text
  -> Int
  -> Maybe Text
  -> Either ServerError (Maybe Text)
validateOptionalWhatsAppConsentText fieldName maxLength rawValue =
  case cleanOptional rawValue of
    Nothing -> Right Nothing
    Just value
      | T.length value > maxLength ->
          Left err400
            { errBody =
                BL.fromStrict $
                  TE.encodeUtf8 $
                    fieldName <> " is too long (max " <> T.pack (show maxLength) <> " characters)"
            }
      | T.any isUnsupportedWhatsAppConsentTextChar value ->
          Left err400
            { errBody =
                BL.fromStrict $
                  TE.encodeUtf8 $
                    fieldName <> " must not contain control or formatting characters"
            }
      | otherwise -> Right (Just value)

isUnsupportedWhatsAppConsentTextChar :: Char -> Bool
isUnsupportedWhatsAppConsentTextChar ch =
  isControl ch
    || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

maxWhatsAppConsentDisplayNameChars :: Int
maxWhatsAppConsentDisplayNameChars = 120

maxWhatsAppConsentSourceChars :: Int
maxWhatsAppConsentSourceChars = 80

maxWhatsAppOptOutReasonChars :: Int
maxWhatsAppOptOutReasonChars = 500

validateWhatsAppMessagesLimit :: Maybe Int -> Either ServerError Int
validateWhatsAppMessagesLimit Nothing = Right 100
validateWhatsAppMessagesLimit (Just rawLimit)
  | rawLimit < 1 || rawLimit > 200 =
      Left err400 { errBody = "limit must be between 1 and 200" }
  | otherwise = Right rawLimit

operatorQuestionInboundMaxChars :: Int
operatorQuestionInboundMaxChars = 2000

operatorQuestionDetailMaxChars :: Int
operatorQuestionDetailMaxChars = 1000

operatorQuestionIdentifierMaxChars :: Int
operatorQuestionIdentifierMaxChars = 256

operatorQuestionEnvNames :: [String]
operatorQuestionEnvNames =
  [ "AI_HANDOFF_WHATSAPP_NUMBER"
  , "TDF_OPERATOR_WHATSAPP_NUMBER"
  , "OPERATOR_WHATSAPP_NUMBER"
  , "COURSE_WHATSAPP_NUMBER"
  , "WHATSAPP_CONTACT_NUMBER"
  , "WA_CONTACT_NUMBER"
  ]

validateOperatorQuestionChannel :: Text -> Either ServerError Text
validateOperatorQuestionChannel rawChannel
  | T.any isUnsupportedWhatsAppInboxFilterChar rawChannel =
      Left err400 { errBody = "channel must not contain control or formatting characters" }
  | otherwise =
      case T.toCaseFold (T.strip rawChannel) of
        "instagram" -> Right "instagram"
        "facebook" -> Right "facebook"
        "whatsapp" -> Right "whatsapp"
        _ -> Left err400 { errBody = "channel inválido (instagram|facebook|whatsapp)" }

validateOperatorQuestionRequiredIdentifier :: Text -> Text -> Either ServerError Text
validateOperatorQuestionRequiredIdentifier fieldName rawIdentifier =
  case validateOperatorQuestionIdentifier fieldName (Just rawIdentifier) of
    Right (Just identifier) -> Right identifier
    Right Nothing ->
      Left err400 { errBody = BL.fromStrict (TE.encodeUtf8 (fieldName <> " requerido")) }
    Left serverErr -> Left serverErr

validateOperatorQuestionIdentifier :: Text -> Maybe Text -> Either ServerError (Maybe Text)
validateOperatorQuestionIdentifier _ Nothing = Right Nothing
validateOperatorQuestionIdentifier fieldName (Just rawIdentifier)
  | T.null identifier =
      Left err400 { errBody = BL.fromStrict (TE.encodeUtf8 (fieldName <> " requerido")) }
  | T.length identifier > operatorQuestionIdentifierMaxChars =
      Left err400 { errBody = BL.fromStrict (TE.encodeUtf8 (fieldName <> " demasiado largo")) }
  | T.any isSpace identifier =
      Left err400 { errBody = BL.fromStrict (TE.encodeUtf8 (fieldName <> " no debe contener espacios")) }
  | T.any isUnsupportedWhatsAppInboxFilterChar identifier =
      Left err400
        { errBody =
            BL.fromStrict (TE.encodeUtf8 (fieldName <> " contiene caracteres no soportados"))
        }
  | otherwise =
      Right (Just identifier)
  where
    identifier = T.strip rawIdentifier

validateOperatorQuestionTextField :: Text -> Int -> Text -> Either ServerError Text
validateOperatorQuestionTextField fieldName maxChars rawValue
  | T.null value =
      Left err400 { errBody = BL.fromStrict (TE.encodeUtf8 (fieldName <> " requerido")) }
  | T.length value > maxChars =
      Left err400
        { errBody =
            BL.fromStrict $
              TE.encodeUtf8 $
                fieldName <> " debe tener " <> T.pack (show maxChars) <> " caracteres o menos"
        }
  | T.any isUnsupportedWhatsAppMessageChar value =
      Left err400
        { errBody =
            BL.fromStrict (TE.encodeUtf8 (fieldName <> " contiene caracteres no soportados"))
        }
  | otherwise =
      Right value
  where
    value = T.strip rawValue

resolveOperatorWhatsAppPhone :: IO (Either Text Text)
resolveOperatorWhatsAppPhone = do
  mConfigured <- lookupFirstNonEmptyOperatorEnv operatorQuestionEnvNames
  pure $
    case mConfigured of
      Nothing ->
        Left $
          "AI handoff WhatsApp number not configured. Set one of: "
            <> T.intercalate ", " (map T.pack operatorQuestionEnvNames)
      Just (envName, rawPhone) ->
        case normalizeOperatorWhatsAppPhone rawPhone of
          Just phone -> Right phone
          Nothing ->
            Left $
              T.pack envName
                <> " must be an international WhatsApp number, e.g. +14155552671"

lookupFirstNonEmptyOperatorEnv :: [String] -> IO (Maybe (String, Text))
lookupFirstNonEmptyOperatorEnv [] = pure Nothing
lookupFirstNonEmptyOperatorEnv (envName:rest) = do
  raw <- lookupEnv envName
  case T.strip . T.pack <$> raw of
    Just value | not (T.null value) -> pure (Just (envName, value))
    _ -> lookupFirstNonEmptyOperatorEnv rest

normalizeOperatorWhatsAppPhone :: Text -> Maybe Text
normalizeOperatorWhatsAppPhone = normalizeCourseRegistrationPhoneInput

buildOperatorQuestionMessage
  :: AppConfig
  -> Text
  -> Text
  -> Maybe Text
  -> Text
  -> Text
  -> Text
  -> Text
buildOperatorQuestionMessage cfg channel senderId externalId inboundMessage holdReason neededInfo =
  truncateOperatorQuestionMessage maxWhatsAppReplyBodyChars $
    T.intercalate "\n" $
      filter (not . T.null)
        [ "TDF HQ necesita tu criterio antes de responder un mensaje."
        , ""
        , "Canal: " <> channel
        , "Remitente: " <> senderId
        , maybe "" ("Mensaje ID: " <>) externalId
        , ""
        , "Mensaje recibido:"
        , inboundMessage
        , ""
        , "La IA no puede responder todavía:"
        , holdReason
        , ""
        , "Necesita preguntarte:"
        , neededInfo
        , ""
        , maybe "" (\baseUrl -> "Inbox: " <> T.dropWhileEnd (== '/') baseUrl <> "/social/inbox") (appBaseUrl cfg)
        ]

truncateOperatorQuestionMessage :: Int -> Text -> Text
truncateOperatorQuestionMessage limit value
  | T.length value <= limit = value
  | limit <= suffixLength = T.take limit suffix
  | otherwise = T.take (limit - suffixLength) value <> suffix
  where
    suffix = "\n[recortado]"
    suffixLength = T.length suffix

validateWhatsAppReplyBody :: Text -> Either ServerError Text
validateWhatsAppReplyBody rawBody
  | T.null body =
      Left err400 { errBody = "Mensaje vacío" }
  | T.length body > maxWhatsAppReplyBodyChars =
      Left err400 { errBody = "Mensaje demasiado largo (max 4096 caracteres)" }
  | T.any isUnsupportedWhatsAppMessageChar body =
      Left err400 { errBody = "Mensaje contiene caracteres de control o formato no soportados" }
  | otherwise =
      Right body
  where
    body = T.strip rawBody

maxWhatsAppReplyBodyChars :: Int
maxWhatsAppReplyBodyChars = 4096

isUnsupportedWhatsAppMessageChar :: Char -> Bool
isUnsupportedWhatsAppMessageChar ch =
  (isControl ch && ch `notElem` ("\n\r\t" :: String))
    || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

validateWhatsAppReplyExternalId :: Maybe Text -> Either ServerError (Maybe Text)
validateWhatsAppReplyExternalId = ServerExtra.validateSocialReplyExternalId

parseBoolParam :: Maybe Text -> Either ServerError Bool
parseBoolParam Nothing = Right False
parseBoolParam (Just raw)
  | T.any isUnsupportedWhatsAppInboxFilterChar raw =
      Left err400 { errBody = "repliedOnly must not contain control or formatting characters" }
  | otherwise =
      case T.toCaseFold (T.strip raw) of
        "true" -> Right True
        "1" -> Right True
        "yes" -> Right True
        "false" -> Right False
        "0" -> Right False
        "no" -> Right False
        "" -> invalidRepliedOnly
        _ -> invalidRepliedOnly
  where
    invalidRepliedOnly =
      Left err400 { errBody = "repliedOnly must be omitted or one of: true, false, 1, 0, yes, no" }

parseDirectionParam :: Maybe Text -> Either ServerError (Maybe Text)
parseDirectionParam Nothing = Right Nothing
parseDirectionParam (Just raw)
  | T.any isUnsupportedWhatsAppInboxFilterChar raw =
      Left err400 { errBody = "direction must not contain control or formatting characters" }
  | otherwise =
      case T.toCaseFold (T.strip raw) of
        "" -> invalidDirection
        "all" -> Right Nothing
        "incoming" -> Right (Just "incoming")
        "outgoing" -> Right (Just "outgoing")
        _ -> invalidDirection
  where
    invalidDirection =
      Left err400 { errBody = "direction must be omitted or one of: all, incoming, outgoing" }

isUnsupportedWhatsAppInboxFilterChar :: Char -> Bool
isUnsupportedWhatsAppInboxFilterChar ch =
  isControl ch
    || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

validateWhatsAppReplyTarget
  :: Text
  -> Maybe Text
  -> Maybe (Entity ME.WhatsAppMessage)
  -> Either ServerError (Maybe (Entity ME.WhatsAppMessage))
validateWhatsAppReplyTarget _ Nothing _ = Right Nothing
validateWhatsAppReplyTarget _ (Just _) Nothing =
  Left err404 { errBody = "WhatsApp reply target not found" }
validateWhatsAppReplyTarget recipient (Just _) (Just target@(Entity _ row))
  | ME.whatsAppMessageDirection row /= "incoming" =
      Left err400 { errBody = "WhatsApp reply target must be an incoming message" }
  | not (replyTargetMatchesRecipient recipient row) =
      Left err400 { errBody = "WhatsApp reply target does not match recipient" }
  | otherwise = Right (Just target)

replyTargetMatchesRecipient :: Text -> ME.WhatsAppMessage -> Bool
replyTargetMatchesRecipient recipient row =
  recipient `elem` normalizedCandidates
  where
    normalizedCandidates =
      mapMaybe normalizeWhatsAppPhone
        [ ME.whatsAppMessageSenderId row
        , fromMaybe "" (ME.whatsAppMessagePhoneE164 row)
        ]

data MetaChannel = MetaInstagram | MetaFacebook
  deriving (Show, Eq)

data MetaBackfillOptions = MetaBackfillOptions
  { mboPlatform :: Text
  , mboConversationLimit :: Int
  , mboMessagesPerConversation :: Int
  , mboOnlyUnread :: Bool
  , mboDryRun :: Bool
  } deriving (Show, Eq)

parseMetaBackfillOptions :: Value -> Maybe MetaBackfillOptions
parseMetaBackfillOptions = either (const Nothing) Just . validateMetaBackfillOptions

validateMetaBackfillOptions :: Value -> Either ServerError MetaBackfillOptions
validateMetaBackfillOptions raw = do
  case raw of
    Object metaBackfillFields
      | Just unknownKey <- listToMaybe (unknownMetaBackfillKeys metaBackfillFields) ->
          metaBackfillBadRequest ("Unexpected meta backfill field: " <> AKey.toText unknownKey)
      | Just nullKey <- listToMaybe (nullMetaBackfillKeys metaBackfillFields) ->
          metaBackfillBadRequest
            (AKey.toText nullKey <> " must be omitted instead of null")
    _ -> pure ()
  case parseMaybe (withObject "MetaBackfillOptions" parseOptions) raw of
    Nothing -> metaBackfillBadRequest "Invalid meta backfill payload"
    Just (mPlatform, mConversationLimit, mMessagesPerConversation, mOnlyUnread, mDryRun) -> do
      platformNorm <- validateMetaBackfillPlatform mPlatform
      convLimit <- validateMetaBackfillLimit "conversationLimit" 50 mConversationLimit
      msgLimit <- validateMetaBackfillLimit "messagesPerConversation" 50 mMessagesPerConversation
      pure MetaBackfillOptions
        { mboPlatform = platformNorm
        , mboConversationLimit = convLimit
        , mboMessagesPerConversation = msgLimit
        , mboOnlyUnread = fromMaybe True mOnlyUnread
        , mboDryRun = fromMaybe False mDryRun
        }
  where
    parseOptions o = do
      mPlatform <- o .:? "platform"
      mConversationLimit <- o .:? "conversationLimit"
      mMessagesPerConversation <- o .:? "messagesPerConversation"
      mOnlyUnread <- o .:? "onlyUnread"
      mDryRun <- o .:? "dryRun"
      pure ( mPlatform
           , mConversationLimit
           , mMessagesPerConversation
           , mOnlyUnread
           , mDryRun
           )

allowedMetaBackfillKeys :: Set.Set AKey.Key
allowedMetaBackfillKeys =
  Set.fromList (map AKey.fromText
    [ "platform"
    , "conversationLimit"
    , "messagesPerConversation"
    , "onlyUnread"
    , "dryRun"
    ])

unknownMetaBackfillKeys :: AKeyMap.KeyMap Value -> [AKey.Key]
unknownMetaBackfillKeys =
  filter (`Set.notMember` allowedMetaBackfillKeys) . AKeyMap.keys

nullMetaBackfillKeys :: AKeyMap.KeyMap Value -> [AKey.Key]
nullMetaBackfillKeys =
  map fst . filter ((== Null) . snd) . AKeyMap.toList

validateMetaBackfillPlatform :: Maybe Text -> Either ServerError Text
validateMetaBackfillPlatform Nothing = pure "all"
validateMetaBackfillPlatform (Just raw) =
  case T.toCaseFold (T.strip raw) of
    "instagram" -> pure "instagram"
    "facebook" -> pure "facebook"
    "all" -> pure "all"
    _ -> metaBackfillBadRequest "platform must be one of: all, instagram, facebook"

validateMetaBackfillLimit :: Text -> Int -> Maybe Int -> Either ServerError Int
validateMetaBackfillLimit _ defaultValue Nothing = pure defaultValue
validateMetaBackfillLimit fieldName _ (Just rawValue)
  | rawValue < 1 || rawValue > 200 =
      metaBackfillBadRequest (fieldName <> " must be between 1 and 200")
  | otherwise = pure rawValue

validateMetaBackfillConversationId :: Text -> Either ServerError Text
validateMetaBackfillConversationId rawConversationId =
  case normalizeConfiguredGraphNodeId
        "Meta backfill conversation id"
        (T.unpack rawConversationId) of
    Right (Just conversationId) -> Right conversationId
    _ ->
      Left err502
        { errBody = "Meta Graph returned an invalid conversation id"
        }

validateMetaBackfillConversationIdField :: Maybe Text -> Either ServerError Text
validateMetaBackfillConversationIdField rawConversationId =
  case cleanOptional rawConversationId of
    Nothing ->
      Left err502 { errBody = "Meta Graph conversation missing id" }
    Just conversationId ->
      validateMetaBackfillConversationId conversationId

metaBackfillBadRequest :: Text -> Either ServerError a
metaBackfillBadRequest msg =
  Left err400 { errBody = BL.fromStrict (TE.encodeUtf8 msg) }

jsonTextField :: Text -> Value -> Maybe Text
jsonTextField fieldName payload =
  join (parseMaybe (withObject "jsonTextField" (\o -> o .:? AKey.fromText fieldName)) payload)

jsonBoolField :: Text -> Value -> Maybe Bool
jsonBoolField fieldName payload =
  join (parseMaybe (withObject "jsonBoolField" (\o -> o .:? AKey.fromText fieldName)) payload)

jsonValueField :: Text -> Value -> Maybe Value
jsonValueField fieldName payload =
  join (parseMaybe (withObject "jsonValueField" (\o -> o .:? AKey.fromText fieldName)) payload)

jsonArrayField :: Text -> Value -> [Value]
jsonArrayField fieldName payload =
  fromMaybe [] (parseMaybe (withObject "jsonArrayField" (\o -> o .:? AKey.fromText fieldName .!= [])) payload)

jsonNestedArrayField :: Text -> Text -> Value -> [Value]
jsonNestedArrayField outer inner payload =
  case jsonValueField outer payload of
    Nothing -> []
    Just nested -> jsonArrayField inner nested

jsonIntFromValue :: Value -> Maybe Int
jsonIntFromValue (Number n) = Sci.toBoundedInteger n
jsonIntFromValue (String txt) =
  case reads (T.unpack (T.strip txt)) of
    [(v, "")] -> Just v
    _ -> Nothing
jsonIntFromValue _ = Nothing

jsonIntField :: Text -> Value -> Maybe Int
jsonIntField fieldName payload = jsonValueField fieldName payload >>= jsonIntFromValue

parseMetaMessageTime :: Maybe Text -> Maybe UTCTime
parseMetaMessageTime Nothing = Nothing
parseMetaMessageTime (Just txt) = iso8601ParseM (T.unpack (T.strip txt))

validateMetaBackfillMessageCreatedAt :: Maybe Text -> Either ServerError UTCTime
validateMetaBackfillMessageCreatedAt rawCreatedTime =
  case cleanOptional rawCreatedTime of
    Nothing ->
      Left err502 { errBody = "Meta Graph message missing created_time" }
    Just createdTime ->
      case iso8601ParseM (T.unpack createdTime) of
        Nothing ->
          Left err502 { errBody = "Meta Graph returned an invalid message created_time" }
        Just parsed -> Right parsed

serverErrorToText :: ServerError -> Text
serverErrorToText err =
  let bodyTxt = T.strip (TE.decodeUtf8 (BL.toStrict (errBody err)))
  in if T.null bodyTxt then "Server error" else bodyTxt

isMetaGraphTimeoutError :: ServerError -> Bool
isMetaGraphTimeoutError err =
  let bodyTxt = T.toCaseFold (serverErrorToText err)
  in "request timed out" `T.isInfixOf` bodyTxt
      || ("oauthexception" `T.isInfixOf` bodyTxt && "2534084" `T.isInfixOf` bodyTxt)
      || "reduce the amount of data you're asking for" `T.isInfixOf` bodyTxt

tokenSuffix :: Text -> Text
tokenSuffix tok =
  let trimmed = T.strip tok
      suffixLen = min 8 (T.length trimmed)
  in if suffixLen <= 0 then "empty" else T.takeEnd suffixLen trimmed

buildFacebookGraphRequest
  :: AppConfig
  -> Text
  -> [(Text, Text)]
  -> AppM Request
buildFacebookGraphRequest cfg path params = do
  let base = T.dropWhileEnd (== '/') (facebookGraphBase cfg)
      normalizedPath = if "/" `T.isPrefixOf` path then path else "/" <> path
      query = renderSimpleQuery True (map (\(k, v) -> (TE.encodeUtf8 k, TE.encodeUtf8 v)) params)
      url = T.unpack (base <> normalizedPath <> TE.decodeUtf8 query)
  reqE <- liftIO (try (parseRequest url) :: IO (Either SomeException Request))
  case reqE of
    Left err -> throwError err500 { errBody = BL.fromStrict (TE.encodeUtf8 (T.pack (displayException err))) }
    Right req -> pure req

requestFacebookGraphValue
  :: Manager
  -> AppConfig
  -> Text
  -> [(Text, Text)]
  -> AppM Value
requestFacebookGraphValue manager cfg path params = do
  req <- buildFacebookGraphRequest cfg path params
  respE <- liftIO (try (httpLbs req manager) :: IO (Either SomeException (Response BL.ByteString)))
  resp <- case respE of
    Left err ->
      throwError err502 { errBody = BL.fromStrict (TE.encodeUtf8 (T.pack (displayException err))) }
    Right ok -> pure ok
  let status = statusCode (responseStatus resp)
  when (status >= 400) $ do
    let bodySnippet = take 2000 (BL8.unpack (responseBody resp))
    throwError err502
      { errBody = BL.fromStrict (TE.encodeUtf8 ("Facebook request failed (" <> T.pack (show status) <> ") " <> T.pack bodySnippet)) }
  case eitherDecode (responseBody resp) of
    Left err ->
      throwError err502 { errBody = BL.fromStrict (TE.encodeUtf8 ("Facebook parse error: " <> T.pack err)) }
    Right val -> pure val

fetchGraphOwnId :: Manager -> AppConfig -> Text -> AppM Text
fetchGraphOwnId manager cfg accessToken = do
  payload <- requestFacebookGraphValue manager cfg "/me"
    [ ("fields", "id,name")
    , ("access_token", accessToken)
    ]
  case jsonTextField "id" payload of
    Just ownerId | not (T.null (T.strip ownerId)) -> pure (T.strip ownerId)
    _ -> throwError err502 { errBody = "Facebook /me response missing id" }

fetchGraphConversations
  :: Manager
  -> AppConfig
  -> Text
  -> Text
  -> Maybe Text
  -> MetaBackfillOptions
  -> AppM [Value]
fetchGraphConversations manager cfg path accessToken mPlatform MetaBackfillOptions{..} = do
  let fetchConversationStubs conversationLimit = do
        let baseParams =
              [ ("fields", "id,updated_time,unread_count")
              , ("limit", T.pack (show conversationLimit))
              , ("access_token", accessToken)
              ]
            params = maybe baseParams (\platformVal -> ("platform", platformVal) : baseParams) mPlatform
        payload <- requestFacebookGraphValue manager cfg path params
        pure (jsonArrayField "data" payload)

      fetchConversationMessages conversationId = do
        let trimmedId = T.strip conversationId
            msgParams =
              [ ("fields", "id,from{id,name,username},message,text,created_time,is_echo,attachments{mime_type,name,image_data,video_data,file_url}")
              , ("limit", T.pack (show mboMessagesPerConversation))
              , ("access_token", accessToken)
              ]
        payload <- requestFacebookGraphValue manager cfg ("/" <> trimmedId <> "/messages") msgParams
        pure (jsonArrayField "data" payload)

      withMessages :: Value -> Maybe Text -> [Value] -> Value
      withMessages conversationVal mConversationId messages =
        object
          [ "id" .= (mConversationId <|> cleanOptional (jsonTextField "id" conversationVal))
          , "updated_time" .= jsonTextField "updated_time" conversationVal
          , "unread_count" .= jsonIntField "unread_count" conversationVal
          , "messages" .= object [ "data" .= messages ]
          ]

      hydrateConversation conversationVal = do
        let unreadCount = fromMaybe 0 (jsonIntField "unread_count" conversationVal)
            shouldSkipMessages = mboOnlyUnread && unreadCount <= 0
        conversationId <-
          either throwError pure $
            validateMetaBackfillConversationIdField (jsonTextField "id" conversationVal)
        if shouldSkipMessages
          then pure (withMessages conversationVal (Just conversationId) [])
          else do
            messages <- fetchConversationMessages conversationId
              `catchError` \err ->
                if isMetaGraphTimeoutError err
                  then pure []
                  else throwError err
            pure (withMessages conversationVal (Just conversationId) messages)

      runAttempt conversationLimit = do
        stubs <- fetchConversationStubs conversationLimit
        mapM hydrateConversation stubs

      retryWithLowerLimit conversationLimit = do
        runAttempt conversationLimit
          `catchError` \err ->
            if isMetaGraphTimeoutError err && conversationLimit > 1
              then retryWithLowerLimit (max 1 (conversationLimit `div` 2))
              else throwError err
  retryWithLowerLimit (max 1 mboConversationLimit)

isIncomingMetaMessage :: Text -> Value -> Bool
isIncomingMetaMessage ownId msgVal =
  let mFrom = jsonValueField "from" msgVal
      senderId = mFrom >>= jsonTextField "id"
      isEcho = fromMaybe False (jsonBoolField "is_echo" msgVal)
  in case senderId of
       Nothing -> False
       Just sid ->
         let normalizedSender = T.toCaseFold (T.strip sid)
             normalizedOwn = T.toCaseFold (T.strip ownId)
         in not isEcho && normalizedSender /= normalizedOwn

selectConversationMessages :: MetaBackfillOptions -> Value -> [Value]
selectConversationMessages MetaBackfillOptions{..} conversationVal =
  let allMessages = jsonNestedArrayField "messages" "data" conversationVal
      unreadCount = jsonIntField "unread_count" conversationVal
      sortedByNewest =
        sortOn
          (Down . fromMaybe (UTCTime (fromGregorian 1970 1 1) 0) . parseMetaMessageTime . jsonTextField "created_time")
          allMessages
      toTake =
        if mboOnlyUnread
          then case unreadCount of
            Just n | n > 0 -> n
            Just _ -> 0
            Nothing -> length sortedByNewest
          else length sortedByNewest
  in take (max 0 toTake) sortedByNewest

storeBackfilledMessage
  :: MetaChannel
  -> MetaBackfillOptions
  -> Text
  -> Value
  -> AppM Bool
storeBackfilledMessage channel MetaBackfillOptions{..} conversationId msgVal = do
  let externalId = jsonTextField "id" msgVal
      mFrom = jsonValueField "from" msgVal
      mAttachments = jsonValueField "attachments" msgVal
      senderId = mFrom >>= jsonTextField "id"
      senderName = (mFrom >>= jsonTextField "name") <|> (mFrom >>= jsonTextField "username")
      bodyRaw = jsonTextField "message" msgVal <|> jsonTextField "text" msgVal
      body =
        case bodyRaw of
          Just txt | not (T.null (T.strip txt)) -> T.strip txt
          _ -> "[attachment]"
      metaPairs =
        [ "backfilled" .= True
        , "conversationId" .= conversationId
        , "source" .= ("meta-graph" :: Text)
        ]
        <> maybe [] (\fromVal -> ["from" .= fromVal]) mFrom
        <> maybe [] (\attVal -> ["attachments" .= attVal]) mAttachments
      metadata = TE.decodeUtf8 (BL.toStrict (encode (object metaPairs)))
  case (cleanOptional externalId, cleanOptional senderId) of
    (Just extId, Just sid) -> do
      createdAt <-
        either throwError pure $
          validateMetaBackfillMessageCreatedAt (jsonTextField "created_time" msgVal)
      if mboDryRun
        then pure True
        else do
          case channel of
            MetaInstagram ->
              -- A message already stored (delivered by webhook, or read by an
              -- earlier backfill) is left as it is.
              runDB $ ServerExtra.storeInstagramInboundOnce
                (InstagramMessage extId
                    sid
                    senderName
                    (Just body)
                    "incoming"
                    Nothing
                    Nothing
                    Nothing
                    Nothing
                    (Just metadata)
                    "pending"
                    Nothing
                    Nothing
                    Nothing
                    0
                    Nothing
                    Nothing
                    Nothing
                    Nothing
                    createdAt)
            MetaFacebook ->
              runDB $ ServerExtra.storeFacebookInboundOnce
                (ME.FacebookMessage extId
                    sid
                    senderName
                    (Just body)
                    "incoming"
                    Nothing
                    Nothing
                    Nothing
                    Nothing
                    (Just metadata)
                    "pending"
                    Nothing
                    Nothing
                    Nothing
                    0
                    Nothing
                    Nothing
                    Nothing
                    Nothing
                    createdAt)
          pure True
    _ -> pure False

backfillFacebookToken
  :: Manager
  -> AppConfig
  -> MetaBackfillOptions
  -> Text
  -> AppM Value
backfillFacebookToken manager cfg opts accessToken = do
  ownerId <- fetchGraphOwnId manager cfg accessToken
  conversations <- fetchGraphConversations manager cfg "/me/conversations" accessToken Nothing opts
  (incomingScanned, importedCount) <- foldM
    (\(scannedAcc, importedAcc) conversationVal -> do
      conversationId <-
        either throwError pure $
          validateMetaBackfillConversationIdField (jsonTextField "id" conversationVal)
      let incomingMessages =
            filter (isIncomingMetaMessage ownerId) (selectConversationMessages opts conversationVal)
      stored <- mapM (storeBackfilledMessage MetaFacebook opts conversationId) incomingMessages
      let imported = length (filter (\ok -> ok) stored)
      pure (scannedAcc + length incomingMessages, importedAcc + imported)
    )
    (0, 0)
    conversations
  pure (object
    [ "platform" .= ("facebook" :: Text)
    , "tokenSuffix" .= tokenSuffix accessToken
    , "ownerId" .= ownerId
    , "conversations" .= length conversations
    , "incomingScanned" .= incomingScanned
    , "imported" .= importedCount
    ])

backfillInstagramAccount
  :: Manager
  -> AppConfig
  -> MetaBackfillOptions
  -> (Text, Text, Maybe Text)
  -> AppM Value
backfillInstagramAccount manager cfg opts (igUserId, accessToken, mHandle) = do
  (conversationPath, ownerId) <-
    either throwError pure (resolveInstagramBackfillTarget cfg igUserId)
  conversations <-
    fetchGraphConversations manager cfg conversationPath accessToken (Just "instagram") opts
  (incomingScanned, importedCount) <- foldM
    (\(scannedAcc, importedAcc) conversationVal -> do
      conversationId <-
        either throwError pure $
          validateMetaBackfillConversationIdField (jsonTextField "id" conversationVal)
      let incomingMessages =
            filter (isIncomingMetaMessage ownerId) (selectConversationMessages opts conversationVal)
      stored <- mapM (storeBackfilledMessage MetaInstagram opts conversationId) incomingMessages
      let imported = length (filter (\ok -> ok) stored)
      pure (scannedAcc + length incomingMessages, importedAcc + imported)
    )
    (0, 0)
    conversations
  pure (object
    [ "platform" .= ("instagram" :: Text)
    , "igUserId" .= ownerId
    , "handle" .= mHandle
    , "tokenSuffix" .= tokenSuffix accessToken
    , "conversations" .= length conversations
    , "incomingScanned" .= incomingScanned
    , "imported" .= importedCount
    ])

resolveInstagramBackfillTarget :: AppConfig -> Text -> Either ServerError (Text, Text)
resolveInstagramBackfillTarget cfg rawIgUserId = do
  (igPath, ownerId) <-
    case normalizeConfiguredGraphNodeId "Instagram backfill account id" (T.unpack rawIgUserId) of
      Left msg ->
        Left err400 { errBody = BL.fromStrict (TE.encodeUtf8 (T.pack msg)) }
      Right Nothing ->
        Right ("/me/conversations", "")
      Right (Just igUserId) ->
        Right ("/" <> igUserId <> "/conversations", igUserId)
  case normalizeConfiguredGraphNodeId "Facebook messaging page id" (maybe "" T.unpack (facebookMessagingPageId cfg)) of
    Left msg ->
      Left err400 { errBody = BL.fromStrict (TE.encodeUtf8 (T.pack msg)) }
    Right Nothing ->
      Right (igPath, ownerId)
    Right (Just pageId) ->
      Right ("/" <> pageId <> "/conversations", ownerId)

metaBackfillServer :: AuthedUser -> Value -> AppM Value
metaBackfillServer user payload = do
  unless (hasRole Admin user) $ throwError err403
  opts <- either throwError pure (validateMetaBackfillOptions payload)
  Env{envConfig} <- ask
  manager <- pure sharedTlsManager
  rows <- runDB $
    selectList
      [ SocialSyncAccountPlatform ==. "instagram"
      , SocialSyncAccountAccessToken !=. Nothing
      , SocialSyncAccountStatus ==. "connected"
      ]
      [Desc SocialSyncAccountUpdatedAt]
  let sources =
        [ (socialSyncAccountExternalUserId acc, tok, socialSyncAccountHandle acc)
        | Entity _ acc <- rows
        , let extId = T.strip (socialSyncAccountExternalUserId acc)
        , not (T.null extId)
        , Just rawTok <- [socialSyncAccountAccessToken acc]
        , let tok = T.strip rawTok
        , not (T.null tok)
        ]
      configuredSource =
        case fmap T.strip (instagramMessagingToken envConfig) of
          Just tok | not (T.null tok) ->
            let mConfiguredIgId = fmap T.strip (instagramMessagingAccountId envConfig)
                configuredIgId = fromMaybe "" mConfiguredIgId
            in Just (configuredIgId, tok, mConfiguredIgId)
          _ -> Nothing
      configuredFacebookToken =
        case fmap T.strip (facebookMessagingToken envConfig) of
          Just tok | not (T.null tok) -> Just tok
          _ -> Nothing
      instagramSources = nub (sources ++ maybeToList configuredSource)
      facebookTokens = nub ([ tok | (_, tok, _) <- instagramSources ] ++ maybeToList configuredFacebookToken)
      runInstagram = mboPlatform opts == "all" || mboPlatform opts == "instagram"
      runFacebook = mboPlatform opts == "all" || mboPlatform opts == "facebook"
  facebookResults <-
    if runFacebook
      then forM facebookTokens $ \tok ->
        (Right <$> backfillFacebookToken manager envConfig opts tok)
          `catchError` \err ->
            pure (Left (object
              [ "platform" .= ("facebook" :: Text)
              , "tokenSuffix" .= tokenSuffix tok
              , "error" .= serverErrorToText err
              ]))
      else pure []
  instagramResults <-
    if runInstagram
      then forM instagramSources $ \src@(_igUserId, tok, _handle) ->
        (Right <$> backfillInstagramAccount manager envConfig opts src)
          `catchError` \err ->
            pure (Left (object
              [ "platform" .= ("instagram" :: Text)
              , "tokenSuffix" .= tokenSuffix tok
              , "error" .= serverErrorToText err
              ]))
      else pure []
  let successes = [val | Right val <- facebookResults ++ instagramResults]
      failures = [val | Left val <- facebookResults ++ instagramResults]
      importedTotal = sum (map (\v -> fromMaybe 0 (jsonIntField "imported" v)) successes)
      scannedTotal = sum (map (\v -> fromMaybe 0 (jsonIntField "incomingScanned" v)) successes)
  pure (object
    [ "status" .= ("ok" :: Text)
    , "options" .= object
        [ "platform" .= mboPlatform opts
        , "conversationLimit" .= mboConversationLimit opts
        , "messagesPerConversation" .= mboMessagesPerConversation opts
        , "onlyUnread" .= mboOnlyUnread opts
        , "dryRun" .= mboDryRun opts
        ]
    , "sources" .= object
        [ "instagramAccounts" .= length instagramSources
        , "facebookTokens" .= length facebookTokens
        , "configuredMessagingToken" .= isJust configuredSource
        , "configuredFacebookToken" .= isJust configuredFacebookToken
        ]
    , "totals" .= object
        [ "imported" .= importedTotal
        , "incomingScanned" .= scannedTotal
        , "successes" .= length successes
        , "failures" .= length failures
        ]
    , "results" .= successes
    , "errors" .= failures
    ])

fanSecureServer :: AuthedUser -> ServerT FanSecureAPI AppM
fanSecureServer user =
       (fanGetProfile user :<|> fanUpdateProfile user)
  :<|> (fanListFollows user :<|> fanFollowArtist user :<|> fanUnfollowArtist user)
  :<|> (artistGetOwnProfile user :<|> artistUpdateOwnProfile user)
  :<|> (notifList user :<|> notifCount user :<|> notifGet user :<|> notifMarkRead user :<|> notifMarkAllRead user)
  :<|> CatalogServer.createSelfFanRoleRequest user
  :<|> discoveryFeed user
  :<|> fanClubSecureListMyClubs user
  :<|> fanClubSecureArtistHandlers user

artistSecureServer :: AuthedUser -> ServerT ArtistSecureAPI AppM
artistSecureServer user =
       artistActivateOwnProfile user
  :<|> ( artistGetOwnProfile user
    :<|> artistUpdateOwnProfile user
    :<|> artistUpdateOwnProfile user
       )
  :<|> artistUpdateOwnPhoto user

socialServer :: AuthedUser -> ServerT SocialAPI AppM
socialServer user =
       SocialReads.relationshipList user "followers" (socialListFollowers user)
  :<|> SocialReads.relationshipList user "following" (socialListFollowing user)
  :<|> vcardExchange user
  :<|> SocialReads.relationshipList user "friends" (socialListFriends user)
  :<|> socialAddFriend user
  :<|> socialRemoveFriend user
  :<|> SocialProfiles.profileList user (socialListProfiles user)
  :<|> SocialProfiles.profileGet user (socialGetProfile user)
  :<|> SocialReads.suggestions user (socialListSuggestedFriends user)
  :<|> socialV2Server user

chatServer :: AuthedUser -> ServerT ChatAPI AppM
chatServer user = SocialChat.chatPolicyServer user $
       chatListThreads user
  :<|> chatGetOrCreateDM user
  :<|> chatListMessages user
  :<|> chatSendMessage user

driveServer :: AuthedUser -> ServerT DriveAPI AppM
driveServer user =
  driveUploadServer user
  :<|> driveTokenExchangeServer user
  :<|> driveTokenRefreshServer user

validateDriveAccess :: AuthedUser -> Either ServerError ()
validateDriveAccess user
  | not (hasCoherentAuthScope user) =
      Left err403
        { errBody = "Google Drive access requires coherent role grants"
        }
  | hasOperationsAccess user || hasPersistedArtistDriveAccess user =
      Right ()
  | otherwise =
      Left err403
        { errBody = "Google Drive access requires operations or artist role"
        }

hasPersistedArtistDriveAccess :: AuthedUser -> Bool
hasPersistedArtistDriveAccess user =
  any (`elem` auRoles user) [Artist, Artista]
    && (hasModuleAccess ModulePackages user || hasModuleAccess ModuleScheduling user)

hasCoherentAuthScope :: AuthedUser -> Bool
hasCoherentAuthScope user =
  fromSqlKey (auPartyId user) > 0
    && length (auRoles user) == length (nub (auRoles user))

driveUploadServer :: AuthedUser -> Maybe Text -> DriveUploadForm -> AppM DriveUploadDTO
driveUploadServer user mAccessToken DriveUploadForm{..} = do
  either throwError pure (validateDriveAccess user)
  providedToken <-
    either throwError pure (resolveProvidedDriveAccessToken mAccessToken duAccessToken)
  mFolderEnv <- liftIO $ lookupEnvTextNonEmpty "DRIVE_UPLOAD_FOLDER_ID"
  folder <- either throwError pure (resolveDriveUploadFolderId duFolderId mFolderEnv)
  nameOverride <- either throwError pure (resolveDriveUploadName duName (fdFileName duFile))
  fileSize <- liftIO (getFileSize (fdPayload duFile))
  either throwError pure (validateDriveUploadFileSize fileSize)
  mimeType <- either throwError pure (resolveDriveUploadMimeType (fdFileCType duFile))
  manager <- pure sharedTlsManager
  accessToken <- resolveDriveAccessToken manager providedToken
  dtoOrErr <-
    liftIO
      (try (uploadToDrive manager (auPartyId user) accessToken duFile mimeType (Just nameOverride) folder duIdempotencyKey) ::
        IO (Either SomeException DriveUploadDTO))
  case dtoOrErr of
    Right dto -> pure dto
    Left err -> case fromException err of
      Just replayError -> throwError (replayError :: ServerError)
      Nothing -> throwError err502
        { errBody = BL8.pack (formatDriveUploadException (T.pack (displayException err))) }
  where
    resolveDriveAccessToken :: Manager -> Maybe Text -> AppM Text
    resolveDriveAccessToken manager mProvided =
      case mProvided of
        Just tok | not (T.null (T.strip tok)) -> pure (T.strip tok)
        _ -> do
          mRefreshToken <- liftIO $ lookupEnvTextNonEmpty "DRIVE_REFRESH_TOKEN"
          mAccessTokenEnv <- liftIO $ lookupEnvTextNonEmpty "DRIVE_ACCESS_TOKEN"
          case mRefreshToken of
            Just rt -> do
              refreshToken <- either throwError pure (validateConfiguredDriveRefreshToken rt)
              (cid, secret) <- loadDriveClientCreds
              refreshDriveAccessToken manager cid secret refreshToken `catchError` \err ->
                handleRefreshError err mAccessTokenEnv
            Nothing -> do
              maybe
                (throwError err503
                  { errBody =
                      "Google Drive no configurado (faltan DRIVE_REFRESH_TOKEN o " <>
                      "DRIVE_ACCESS_TOKEN)."
                  })
                (either throwError pure . validateConfiguredDriveAccessToken)
                mAccessTokenEnv

    handleRefreshError :: ServerError -> Maybe Text -> AppM Text
    handleRefreshError err mAccessTokenEnv
      | isInvalidGrant err =
          case mAccessTokenEnv of
            Just tok -> either throwError pure (validateConfiguredDriveAccessToken tok)
            Nothing ->
              throwError err401
                { errBody = "Refresh token expirado o revocado. Reautoriza Google Drive." }
      | otherwise = throwError err

    isInvalidGrant :: ServerError -> Bool
    isInvalidGrant err =
      let body = map toLower (BL8.unpack (errBody err))
      in "invalid_grant" `isInfixOf` body

resolveProvidedDriveAccessToken :: Maybe Text -> Maybe Text -> Either ServerError (Maybe Text)
resolveProvidedDriveAccessToken mHeaderToken mFormToken = do
  mHeaderTokenClean <- validateProvidedDriveAccessToken "X-Goog-Access-Token" mHeaderToken
  mFormTokenClean <- validateProvidedDriveAccessToken "accessToken" mFormToken
  case (mHeaderTokenClean, mFormTokenClean) of
    (Just headerToken, Just formToken)
      | headerToken == formToken -> Right (Just headerToken)
      | otherwise ->
          Left err400
            { errBody = "Conflicting Google Drive access tokens" }
    (Just headerToken, Nothing) -> Right (Just headerToken)
    (Nothing, Just formToken) -> Right (Just formToken)
    (Nothing, Nothing) -> Right Nothing

validateProvidedDriveAccessToken :: Text -> Maybe Text -> Either ServerError (Maybe Text)
validateProvidedDriveAccessToken _ Nothing = Right Nothing
validateProvidedDriveAccessToken fieldName (Just rawToken) =
  let token = T.strip rawToken
  in if T.null token
      then
        Left err400
          { errBody =
              BL.fromStrict (TE.encodeUtf8 (fieldName <> " must not be blank"))
          }
      else Just <$> validateDriveAccessToken token

resolveDriveUploadFolderId :: Maybe Text -> Maybe Text -> Either ServerError (Maybe Text)
resolveDriveUploadFolderId mProvidedFolderId mFallbackFolderId =
  case mProvidedFolderId of
    Just providedRaw -> do
      let provided = T.strip providedRaw
      if T.null provided
        then
          Left err400
            { errBody = "folderId must not be blank" }
        else Just <$> validateDriveUploadFolderId err400 "folderId" provided
    Nothing ->
      case mFallbackFolderId of
        Nothing -> Right Nothing
        Just fallbackRaw -> do
          let fallback = T.strip fallbackRaw
          if T.null fallback
            then Left err500 { errBody = "DRIVE_UPLOAD_FOLDER_ID must not be blank" }
            else Just <$> validateDriveUploadFolderId err500 "DRIVE_UPLOAD_FOLDER_ID" fallback

validateDriveUploadFolderId :: ServerError -> Text -> Text -> Either ServerError Text
validateDriveUploadFolderId baseError fieldName folderId
  | T.null folderId = invalid
  | T.length folderId > 256 = invalid
  | not (T.any isDriveFolderIdAtom folderId) = invalid
  | not (T.all isDriveFolderIdChar folderId) = invalid
  | otherwise = Right folderId
  where
    invalid =
      Left baseError
        { errBody =
            BL.fromStrict (TE.encodeUtf8 (driveUploadFolderIdMessage fieldName))
        }

driveUploadFolderIdMessage :: Text -> Text
driveUploadFolderIdMessage fieldName =
  fieldName <> " must be a Google Drive folder id (1-256 ASCII letters, digits, '-' or '_')"

isDriveFolderIdChar :: Char -> Bool
isDriveFolderIdChar ch =
  isAsciiLower ch || isAsciiUpper ch || isDigit ch || ch == '-' || ch == '_'

isDriveFolderIdAtom :: Char -> Bool
isDriveFolderIdAtom ch =
  isAsciiLower ch || isAsciiUpper ch || isDigit ch

resolveDriveUploadName :: Maybe Text -> Text -> Either ServerError Text
resolveDriveUploadName mProvidedName rawFileName =
  case mProvidedName of
    Just providedRaw -> do
      let provided = T.strip providedRaw
      if T.null provided
        then
          Left err400
            { errBody = "name must not be blank" }
        else validateDriveUploadName "name" provided
    Nothing ->
      maybe
        (Left err400 { errBody = "fileName is required when name is not provided" })
        (validateDriveUploadName "fileName")
        (cleanOptional (Just rawFileName))

validateDriveUploadName :: Text -> Text -> Either ServerError Text
validateDriveUploadName fieldName uploadName
  | T.length uploadName > 240 =
      Left err400
        { errBody =
            BL.fromStrict (TE.encodeUtf8 (fieldName <> " must be 240 characters or fewer"))
        }
  | T.any isUnsafeDriveUploadNameChar uploadName =
      Left err400
        { errBody =
            BL.fromStrict
              (TE.encodeUtf8
                ( fieldName
                    <> " must not contain control characters or Unicode formatting marks"
                    <> " or Unicode space separators"
                ))
        }
  | T.any isPathSeparator uploadName =
      Left err400
        { errBody =
            BL.fromStrict (TE.encodeUtf8 (fieldName <> " must not contain path separators"))
        }
  | T.all (== '.') uploadName =
      Left err400
        { errBody =
            BL.fromStrict (TE.encodeUtf8 (fieldName <> " must include a non-dot name"))
        }
  | otherwise = Right uploadName
  where
    isPathSeparator ch = ch == '/' || ch == '\\'

isUnsafeDriveUploadNameChar :: Char -> Bool
isUnsafeDriveUploadNameChar ch =
  isControl ch
    || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]
    || (generalCategory ch == Space && ch /= ' ')

maxDriveUploadBytes :: Integer
maxDriveUploadBytes = 50 * 1024 * 1024

validateDriveUploadFileSize :: Integer -> Either ServerError ()
validateDriveUploadFileSize size
  | size < 0 =
      Left err400 { errBody = "Drive upload size is invalid" }
  | size == 0 =
      Left err400 { errBody = "Drive upload must not be empty" }
  | size > maxDriveUploadBytes =
      Left err400 { errBody = "Drive upload must be 50 MB or smaller" }
  | otherwise =
      Right ()

defaultDriveUploadMimeType :: Text
defaultDriveUploadMimeType = "application/octet-stream"

resolveDriveUploadMimeType :: Text -> Either ServerError Text
resolveDriveUploadMimeType rawMimeType
  | T.null cleaned =
      Right defaultDriveUploadMimeType
  | T.any isUnsafeDriveUploadMimeTypeChar cleaned =
      Left err400
        { errBody =
            "file content type must not contain control characters or Unicode formatting marks"
        }
  | hasDriveUploadContentTypeNameParameter cleaned =
      Left err400
        { errBody = "file content type must not include filename parameters" }
  | otherwise =
      validateDriveUploadMimeType mediaType
  where
    cleaned = T.toLower (T.strip rawMimeType)
    mediaType = T.strip (fst (T.breakOn ";" cleaned))

hasDriveUploadContentTypeNameParameter :: Text -> Bool
hasDriveUploadContentTypeNameParameter contentType =
  any isNameParameter (drop 1 (T.splitOn ";" contentType))
  where
    isNameParameter rawParameter =
      let key = T.strip (fst (T.breakOn "=" rawParameter))
      in key `elem` ["name", "name*", "filename", "filename*"]
           || "name*" `T.isPrefixOf` key
           || "filename*" `T.isPrefixOf` key

validateDriveUploadMimeType :: Text -> Either ServerError Text
validateDriveUploadMimeType mimeType
  | T.length mimeType > 255 = invalid
  | otherwise =
      case T.splitOn "/" mimeType of
        [typePart, subtypePart]
          | isDriveMimeToken typePart && isDriveMimeToken subtypePart ->
              Right mimeType
        _ -> invalid
  where
    invalid =
      Left err400
        { errBody = "file content type must be a MIME type like application/pdf" }

isDriveMimeToken :: Text -> Bool
isDriveMimeToken token =
  not (T.null token) && token /= "*" && T.all isDriveMimeTokenChar token

isDriveMimeTokenChar :: Char -> Bool
isDriveMimeTokenChar ch =
  isAsciiLower ch
    || isDigit ch
    || ch `elem` ("!#$%&'*+-.^_`|~" :: String)

isUnsafeDriveUploadMimeTypeChar :: Char -> Bool
isUnsafeDriveUploadMimeTypeChar ch =
  isControl ch
    || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

validateDriveAccessToken :: Text -> Either ServerError Text
validateDriveAccessToken = validateDriveAccessTokenWith err400

validateConfiguredDriveAccessToken :: Text -> Either ServerError Text
validateConfiguredDriveAccessToken rawToken =
  let token = T.strip rawToken
  in if T.null token
       then Left err503 { errBody = "DRIVE_ACCESS_TOKEN must not be blank" }
       else validateDriveAccessTokenWith err503 token

validateDriveAccessTokenWith :: ServerError -> Text -> Either ServerError Text
validateDriveAccessTokenWith baseError token
  | T.length token > 4096 =
      Left baseError { errBody = "Google Drive access token must be 4096 characters or fewer" }
  | T.any isSpace token =
      Left baseError { errBody = "Google Drive access token must not contain whitespace" }
  | T.any isControl token =
      Left baseError { errBody = "Google Drive access token must not contain control characters" }
  | T.any isHiddenDriveOAuthTokenChar token =
      Left baseError
        { errBody = "Google Drive access token must not contain hidden formatting characters" }
  | T.any (not . isAscii) token =
      Left baseError
        { errBody = "Google Drive access token must contain only ASCII characters" }
  | otherwise = Right token

driveTokenExchangeServer :: AuthedUser -> DriveTokenExchangeRequest -> AppM DriveTokenResponse
driveTokenExchangeServer user payload = do
  either throwError pure (validateDriveAccess user)
  Env{envConfig} <- ask
  manager <- pure sharedTlsManager
  (cid, secret) <- loadDriveClientCreds
  (codeVal, codeVerifierVal, redirectResolved) <-
    either throwError pure (validateDriveTokenExchangeRequest envConfig payload)
  token <- requestGoogleToken manager
    [ ("client_id", TE.encodeUtf8 cid)
    , ("client_secret", TE.encodeUtf8 secret)
    , ("code", TE.encodeUtf8 codeVal)
    , ("code_verifier", TE.encodeUtf8 codeVerifierVal)
    , ("redirect_uri", TE.encodeUtf8 redirectResolved)
    , ("grant_type", "authorization_code")
    ]
  pure (driveTokenResponseFrom token Nothing)

driveTokenRefreshServer :: AuthedUser -> DriveTokenRefreshRequest -> AppM DriveTokenResponse
driveTokenRefreshServer user payload = do
  either throwError pure (validateDriveAccess user)
  refreshTokenVal <- either throwError pure (validateDriveTokenRefreshRequest payload)
  manager <- pure sharedTlsManager
  (cid, secret) <- loadDriveClientCreds
  token <- requestGoogleToken manager
    [ ("client_id", TE.encodeUtf8 cid)
    , ("client_secret", TE.encodeUtf8 secret)
    , ("refresh_token", TE.encodeUtf8 refreshTokenVal)
    , ("grant_type", "refresh_token")
    ]
  pure (driveTokenResponseFrom token (Just refreshTokenVal))

validateDriveTokenExchangeRequest
  :: AppConfig
  -> DriveTokenExchangeRequest
  -> Either ServerError (Text, Text, Text)
validateDriveTokenExchangeRequest cfg DriveTokenExchangeRequest{..} = do
  codeVal <- validateDriveAuthorizationCode code
  codeVerifierVal <- validateDriveCodeVerifier codeVerifier
  redirectResolved <- resolveDriveRedirectUri cfg redirectUri
  pure (codeVal, codeVerifierVal, redirectResolved)

validateDriveTokenRefreshRequest :: DriveTokenRefreshRequest -> Either ServerError Text
validateDriveTokenRefreshRequest DriveTokenRefreshRequest{refreshToken = rawToken} =
  validateDriveRefreshTokenWith err400 "refreshToken" rawToken

validateDriveRefreshToken :: Text -> Either ServerError Text
validateDriveRefreshToken =
  validateDriveRefreshTokenWith err400 "refreshToken"

validateConfiguredDriveRefreshToken :: Text -> Either ServerError Text
validateConfiguredDriveRefreshToken =
  validateDriveRefreshTokenWith err503 "DRIVE_REFRESH_TOKEN"

validateDriveRefreshTokenWith :: ServerError -> Text -> Text -> Either ServerError Text
validateDriveRefreshTokenWith baseError fieldName rawToken
  | T.null tokenVal =
      invalid " is required"
  | T.any isControl tokenVal =
      invalid " must not contain control characters"
  | T.any isHiddenDriveOAuthTokenChar tokenVal =
      invalid " must not contain hidden formatting characters"
  | T.any isSpace tokenVal =
      invalid " must not contain whitespace"
  | T.any (not . isAscii) tokenVal =
      invalid " must contain only ASCII characters"
  | T.length tokenVal > maxDriveOAuthTokenChars =
      invalid " must be 4096 characters or fewer"
  | otherwise =
      Right tokenVal
  where
    tokenVal = T.strip rawToken
    invalid suffix =
      Left baseError
        { errBody = BL.fromStrict (TE.encodeUtf8 (fieldName <> suffix)) }

validateDriveAuthorizationCode :: Text -> Either ServerError Text
validateDriveAuthorizationCode rawCode =
  let codeVal = T.strip rawCode
  in if T.null codeVal
       then Left err400 { errBody = "code is required" }
       else
         if T.any isControl codeVal
           then Left err400 { errBody = "code must not contain control characters" }
           else if T.any isHiddenDriveOAuthTokenChar codeVal
             then Left err400 { errBody = "code must not contain hidden formatting characters" }
           else if T.any isSpace codeVal
           then Left err400 { errBody = "code must not contain whitespace" }
           else if T.any (not . isAscii) codeVal
           then Left err400 { errBody = "code must contain only ASCII characters" }
           else if T.length codeVal > maxDriveOAuthTokenChars
           then Left err400 { errBody = "code must be 4096 characters or fewer" }
           else Right codeVal

validateDriveCodeVerifier :: Text -> Either ServerError Text
validateDriveCodeVerifier rawVerifier =
  let verifier = T.strip rawVerifier
      verifierLen = T.length verifier
  in if verifierLen < 43 || verifierLen > 128 || not (T.all isPkceVerifierChar verifier)
       then
         Left err400
           { errBody =
               "codeVerifier must be a PKCE verifier (43-128 chars: A-Z a-z 0-9 - . _ ~)"
           }
       else Right verifier
  where
    isPkceVerifierChar ch =
      isAsciiLower ch
        || isAsciiUpper ch
        || isDigit ch
        || ch `elem` ("-._~" :: String)

resolveDriveRedirectUri :: AppConfig -> Maybe Text -> Either ServerError Text
resolveDriveRedirectUri cfg mProvided = do
  configuredRedirectUri <-
    validateConfiguredDriveRedirectUri
      (resolveConfiguredAppBase cfg <> "/oauth/google-drive/callback")
  maybe
    (Right configuredRedirectUri)
    (validateProvidedRedirectUri configuredRedirectUri)
    mProvided
  where
    validateProvidedRedirectUri configuredRedirectUri rawRedirect = do
      redirectUri <- validateDriveRedirectUri rawRedirect
      if redirectUri == configuredRedirectUri
        then Right redirectUri
        else
          Left err400
            { errBody =
                "redirectUri must match the configured Google Drive OAuth callback URL"
            }

validateDriveRedirectUri :: Text -> Either ServerError Text
validateDriveRedirectUri rawRedirect =
  if T.null (T.strip rawRedirect)
    then Left err400 { errBody = "redirectUri must be omitted instead of blank" }
    else
      case normalizeConfiguredBaseUrl "redirectUri" (T.unpack rawRedirect) of
        Right (Just uri)
          | isSafeDriveRedirectUri uri -> Right uri
          | otherwise -> invalid
        _ -> invalid
  where
    invalid =
      Left err400
        { errBody =
            "redirectUri must be an absolute https Google Drive OAuth callback URL ending "
              <> "in /oauth/google-drive/callback, or http://localhost for local development, "
              <> "without query or fragment"
        }

validateConfiguredDriveRedirectUri :: Text -> Either ServerError Text
validateConfiguredDriveRedirectUri rawRedirect =
  case normalizeConfiguredBaseUrl "HQ_APP_URL" (T.unpack rawRedirect) of
    Right (Just uri)
      | isSafeDriveRedirectUri uri -> Right uri
    _ ->
      Left err503
        { errBody =
            "Configured Google Drive OAuth callback URL must be an absolute https URL ending "
              <> "in /oauth/google-drive/callback, or http://localhost for local development, "
              <> "without query or fragment"
        }

isSafeDriveRedirectUri :: Text -> Bool
isSafeDriveRedirectUri uri
  | not (googleDriveOAuthCallbackPath `T.isSuffixOf` uri) = False
  | hasAmbiguousOAuthRedirectPath uri = False
  | "https://" `T.isPrefixOf` lowerUri =
      maybe False (not . isLocalCalendarRedirectHost) (calendarRedirectHost (T.drop 8 uri))
  | "http://" `T.isPrefixOf` lowerUri =
      maybe False isLocalCalendarRedirectHost (calendarRedirectHost (T.drop 7 uri))
  | otherwise = False
  where
    lowerUri = T.toLower uri

googleDriveOAuthCallbackPath :: Text
googleDriveOAuthCallbackPath = "/oauth/google-drive/callback"

driveTokenResponseFrom :: GoogleToken -> Maybe Text -> DriveTokenResponse
driveTokenResponseFrom GoogleToken{..} fallbackRefresh =
  DriveTokenResponse
    { accessToken = access_token
    , refreshToken = refresh_token <|> fallbackRefresh
    , expiresIn = fromMaybe 3600 expires_in
    , tokenType = token_type
    }

requestGoogleToken :: Manager -> [(ByteString, ByteString)] -> AppM GoogleToken
requestGoogleToken manager form = do
  req0 <- liftIO $ parseRequest "https://oauth2.googleapis.com/token"
  let payload = renderSimpleQuery False form
      req = req0
        { method = "POST"
        , requestBody = RequestBodyLBS (BL.fromStrict payload)
        , requestHeaders = [("Content-Type", "application/x-www-form-urlencoded")]
        }
  respOrErr <-
    liftIO
      (try (httpLbs req manager) ::
        IO (Either SomeException (Response BL.ByteString)))
  resp <- case respOrErr of
    Left err ->
      throwError err502
        { errBody = BL8.pack ("No se pudo contactar Google OAuth: " <> displayException err) }
    Right ok -> pure ok
  let codeStatus = statusCode (responseStatus resp)
  when (codeStatus >= 400) $ do
    throwError err502
      { errBody = BL8.pack (formatGoogleOAuthFailure codeStatus (responseBody resp))
      }
  token <- case eitherDecode (responseBody resp) of
    Left err ->
      throwError err502 { errBody = BL8.pack ("No se pudo parsear token: " <> err) }
    Right tok -> pure (tok :: GoogleToken)
  pure token

formatGoogleOAuthFailure :: Int -> BL.ByteString -> String
formatGoogleOAuthFailure oauthStatus responseBodyBytes =
  "Solicitud OAuth falló (" <> show oauthStatus <> ")." <> suffix
  where
    rawSnippet =
      T.take 2000 (TE.decodeUtf8With TEE.lenientDecode (BL.toStrict responseBodyBytes))
    suffix =
      maybe "" ((" " <>) . T.unpack) (sanitizeApiErrorMessage rawSnippet)

loadDriveClientCreds :: AppM (Text, Text)
loadDriveClientCreds = do
  mCid <- liftIO $ lookupEnvText "DRIVE_CLIENT_ID"
  mSecret <- liftIO $ lookupEnvText "DRIVE_CLIENT_SECRET"
  mCidFallback <- liftIO $ lookupEnvText "GOOGLE_CLIENT_ID"
  mSecretFallback <- liftIO $ lookupEnvText "GOOGLE_CLIENT_SECRET"
  either throwError pure $
    resolveDriveClientCreds mCid mSecret mCidFallback mSecretFallback

resolveDriveClientCreds
  :: Maybe Text
  -> Maybe Text
  -> Maybe Text
  -> Maybe Text
  -> Either ServerError (Text, Text)
resolveDriveClientCreds
  rawDriveClientId
  rawDriveClientSecret
  rawGoogleClientId
  rawGoogleClientSecret = do
  mDriveClientId <- validateOptionalDriveClientId "DRIVE_CLIENT_ID" rawDriveClientId
  mDriveClientSecret <-
    validateOptionalDriveClientCredential "DRIVE_CLIENT_SECRET" rawDriveClientSecret
  mGoogleClientId <- validateOptionalDriveClientId "GOOGLE_CLIENT_ID" rawGoogleClientId
  mGoogleClientSecret <-
    validateOptionalDriveClientCredential "GOOGLE_CLIENT_SECRET" rawGoogleClientSecret
  case (mDriveClientId, mDriveClientSecret) of
    (Just cid, Just secret) -> Right (cid, secret)
    (Just _, Nothing) -> Left partialDriveCredsError
    (Nothing, Just _) -> Left partialDriveCredsError
    (Nothing, Nothing) ->
      case (mGoogleClientId, mGoogleClientSecret) of
        (Just cid, Just secret) -> Right (cid, secret)
        (Just _, Nothing) -> Left partialGoogleCredsError
        (Nothing, Just _) -> Left partialGoogleCredsError
        (Nothing, Nothing) -> Left missingDriveCredsError
  where
    partialDriveCredsError =
      err503
        { errBody =
            "Google Drive no configurado: set both DRIVE_CLIENT_ID and DRIVE_CLIENT_SECRET, " <>
            "or unset both to use GOOGLE_CLIENT_ID/GOOGLE_CLIENT_SECRET fallback."
        }
    partialGoogleCredsError =
      err503
        { errBody =
            "Google Drive no configurado: GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET " <>
            "must both be set for fallback credentials."
        }
    missingDriveCredsError =
      err503
        { errBody =
            "Google Drive no configurado (faltan DRIVE_CLIENT_ID/DRIVE_CLIENT_SECRET o " <>
            "GOOGLE_CLIENT_ID/GOOGLE_CLIENT_SECRET)."
        }

validateOptionalDriveClientId :: Text -> Maybe Text -> Either ServerError (Maybe Text)
validateOptionalDriveClientId envName rawClientId =
  case rawClientId of
    Nothing -> Right Nothing
    Just clientId ->
      if T.null (T.strip clientId)
        then
          Left err503
            { errBody =
                BL.fromStrict . TE.encodeUtf8 $
                  envName <> " is configured but blank"
            }
        else
          case normalizeConfiguredGoogleClientId (T.unpack envName) (T.unpack clientId) of
            Left msg ->
              Left err503
                { errBody = BL.fromStrict (TE.encodeUtf8 (T.pack msg)) }
            Right normalized -> Right normalized

validateOptionalDriveClientCredential :: Text -> Maybe Text -> Either ServerError (Maybe Text)
validateOptionalDriveClientCredential envName rawCredential =
  case rawCredential of
    Nothing -> Right Nothing
    Just raw
      | T.null credential ->
          Left err503
            { errBody =
                BL.fromStrict . TE.encodeUtf8 $
                  envName <> " is configured but blank"
            }
      | T.any (\ch -> isControl ch || isSpace ch) credential ->
          Left err503
            { errBody =
                BL.fromStrict . TE.encodeUtf8 $
                  envName <> " must not contain control characters or whitespace"
            }
      | T.any isHiddenDriveOAuthTokenChar credential ->
          Left err503
            { errBody =
                BL.fromStrict . TE.encodeUtf8 $
                  envName <> " must not contain hidden formatting characters"
            }
      | T.any (not . isAscii) credential ->
          Left err503
            { errBody =
                BL.fromStrict . TE.encodeUtf8 $
                  envName <> " must contain only ASCII characters"
            }
      | T.length credential > maxDriveOAuthTokenChars ->
          Left err503
            { errBody =
                BL.fromStrict . TE.encodeUtf8 $
                  envName <> " must be 4096 characters or fewer"
            }
      | otherwise -> Right (Just credential)
      where
        credential = T.strip raw

refreshDriveAccessToken :: Manager -> Text -> Text -> Text -> AppM Text
refreshDriveAccessToken manager cid secret rt = do
  token <- requestGoogleToken manager
    [ ("client_id", TE.encodeUtf8 cid)
    , ("client_secret", TE.encodeUtf8 secret)
    , ("refresh_token", TE.encodeUtf8 rt)
    , ("grant_type", "refresh_token")
    ]
  pure (access_token token)

lookupEnvText :: String -> IO (Maybe Text)
lookupEnvText key = fmap (fmap T.pack) (lookupEnv key)

lookupEnvTextNonEmpty :: String -> IO (Maybe Text)
lookupEnvTextNonEmpty key = do
  mVal <- lookupEnv key
  pure $ case fmap (T.strip . T.pack) mVal of
    Just val | not (T.null val) -> Just val
    _ -> Nothing

protectedServer :: AuthedUser -> ServerT ProtectedAPI AppM
protectedServer user =
       partyServer user
  :<|> bookingServer user
  :<|> serviceMarketplaceServer user
  :<|> proposalsServer user
  :<|> serviceCatalogServer user
  :<|> packageServer user
  :<|> invoiceServer user
  :<|> receiptServer user
  :<|> adminServer user
  :<|> userRolesServer user
  :<|> fanSecureServer user
  :<|> artistSecureServer user
  :<|> inventoryServer user
  :<|> bandsServer user
  :<|> sessionsServer user
  :<|> pipelinesServer user
  :<|> roomsServer user
  :<|> liveSessionsServer user
  :<|> marketplaceAdminServer user
  :<|> paymentsServer user
  :<|> instagramServer user
  :<|> facebookServer user
  :<|> instagramOAuthServer user
  :<|> whatsappMessagesServer user
  :<|> whatsappReplyServer user
  :<|> whatsappConsentServer user
  :<|> socialServer user
  :<|> chatServer user
  :<|> chatkitSessionServer user
  :<|> tidalAgentServer user
  :<|> socialSyncServer user
  :<|> socialDiscoveryServer user
  :<|> metaBackfillServer user
  :<|> socialEventsServer user
  :<|> contractsServer user
  :<|> internshipsServer user
  :<|> internalFeedbackServer user
  :<|> adsAdminServer user
  :<|> academyAccountServer user
  :<|> coursesAdminServer user
  :<|> labelServer user
  :<|> calendarServer user
  :<|> cmsAdminServer user
  :<|> driveServer user
  :<|> radioServer user
  :<|> futureServer user
  :<|> DDEXServer.ddexServer user
  :<|> CatalogServer.catalogServer user
  :<|> serviceStorefrontAdminServer user
  :<|> accessRequestsServer user
  :<|> AuthServer.artistInvitationsServer user
  :<|> navigationPreferencesServer user
  :<|> DirectoryServer.directoryProtectedServer user
  :<|> MerchServer.merchProtectedServer user
  :<|> OperationsServer.operationsServer user
  :<|> EventOperationsServer.eventOperationsServer user
  :<|> CommerceOperationsServer.commerceOperationsServer user
  :<|> ReviewsServer.reviewsProtectedServer user
  :<|> MusicReleaseServer.musicReleaseProtectedServer user
  :<|> InteractionsServer.interactionsServer user

navigationPreferencesServer :: AuthedUser -> ServerT NavigationPreferencesAPI AppM
navigationPreferencesServer user =
       listPreferences
  :<|> updatePreference
  :<|> recordVisit
  where
    currentModules = map moduleName (Set.toList (auModules user))

    featureForPreference rawFeatureId = do
      feature <- maybe
        (throwError err404 { errBody = "Feature is unavailable" })
        pure
        (findRegistryFeature (T.strip rawFeatureId))
      unless (navigationFeatureAllowed user currentModules feature) $
        throwError err404 { errBody = "Feature is unavailable" }
      pure feature

    listPreferences = do
      rows <- runDB $ selectList
        [ME.FeatureNavigationPreferencePartyId ==. auPartyId user]
        [Asc ME.FeatureNavigationPreferencePinOrder, Desc ME.FeatureNavigationPreferenceLastVisitedAt]
      pure $ mapMaybe (visiblePreference currentModules) rows

    updatePreference rawFeatureId NavigationPreferenceUpdate{..} = do
      feature <- featureForPreference rawFeatureId
      when (npuFavorite && not (registryFeatureFavoriteEligible feature)) $
        throwError err400 { errBody = "Feature cannot be favorited" }
      when (npuPinned && not (registryFeaturePinEligible feature)) $
        throwError err400 { errBody = "Feature cannot be pinned" }
      when (not npuPinned && isJust npuPinOrder) $
        throwError err400 { errBody = "pinOrder requires pinned=true" }
      when (maybe False (\value -> value < 0 || value > 1000) npuPinOrder) $
        throwError err400 { errBody = "pinOrder must be between 0 and 1000" }
      now <- liftIO getCurrentTime
      let featureIdValue = registryFeatureId feature
          pinOrderValue = if npuPinned then Just (fromMaybe 0 npuPinOrder) else Nothing
          initial = ME.FeatureNavigationPreference
            { ME.featureNavigationPreferencePartyId = auPartyId user
            , ME.featureNavigationPreferenceFeatureId = featureIdValue
            , ME.featureNavigationPreferenceFavorite = npuFavorite
            , ME.featureNavigationPreferencePinned = npuPinned
            , ME.featureNavigationPreferencePinOrder = pinOrderValue
            , ME.featureNavigationPreferenceLastVisitedAt = Nothing
            , ME.featureNavigationPreferenceUseCount = 0
            , ME.featureNavigationPreferenceUpdatedAt = now
            }
      entity <- runDB $ upsertBy
        (ME.UniqueFeatureNavigationPreference (auPartyId user) featureIdValue)
        initial
        [ ME.FeatureNavigationPreferenceFavorite =. npuFavorite
        , ME.FeatureNavigationPreferencePinned =. npuPinned
        , ME.FeatureNavigationPreferencePinOrder =. pinOrderValue
        , ME.FeatureNavigationPreferenceUpdatedAt =. now
        ]
      pure (navigationPreferenceToDTO entity)

    recordVisit rawFeatureId = do
      feature <- featureForPreference rawFeatureId
      when (registryFeatureRecentBehavior feature == "none") $
        throwError err400 { errBody = "Feature does not support recent visits" }
      now <- liftIO getCurrentTime
      let featureIdValue = registryFeatureId feature
          unique = ME.UniqueFeatureNavigationPreference (auPartyId user) featureIdValue
      -- A first visit may arrive concurrently from multiple tabs or devices.
      -- The unique-key upsert creates once and increments under the DB row lock;
      -- visit tracking never overwrites the account's favorites or pin settings.
      entity <- runDB $ upsertBy unique
        ME.FeatureNavigationPreference
          { ME.featureNavigationPreferencePartyId = auPartyId user
          , ME.featureNavigationPreferenceFeatureId = featureIdValue
          , ME.featureNavigationPreferenceFavorite = False
          , ME.featureNavigationPreferencePinned = False
          , ME.featureNavigationPreferencePinOrder = Nothing
          , ME.featureNavigationPreferenceLastVisitedAt = Just now
          , ME.featureNavigationPreferenceUseCount = 1
          , ME.featureNavigationPreferenceUpdatedAt = now
          }
        [ ME.FeatureNavigationPreferenceLastVisitedAt =. Just now
        , ME.FeatureNavigationPreferenceUseCount +=. 1
        , ME.FeatureNavigationPreferenceUpdatedAt =. now
        ]
      pure (navigationPreferenceToDTO entity)

    visiblePreference modules entity@(Entity _ preferenceValue) = do
      feature <- findRegistryFeature (ME.featureNavigationPreferenceFeatureId preferenceValue)
      if navigationFeatureAllowed user modules feature
        then Just (navigationPreferenceToDTO entity)
        else Nothing

navigationFeatureAllowed :: AuthedUser -> [Text] -> RegistryFeature -> Bool
navigationFeatureAllowed user modules feature =
  not (registryFeatureTechnical feature)
    && registryFeatureMaturity feature `notElem` ["broken", "incomplete"]
    && registryFeatureAllows (auRoles user) modules feature "view"

navigationPreferenceToDTO :: Entity ME.FeatureNavigationPreference -> NavigationPreferenceDTO
navigationPreferenceToDTO (Entity _ preferenceValue) = NavigationPreferenceDTO
  { npFeatureId = ME.featureNavigationPreferenceFeatureId preferenceValue
  , npFavorite = ME.featureNavigationPreferenceFavorite preferenceValue
  , npPinned = ME.featureNavigationPreferencePinned preferenceValue
  , npPinOrder = ME.featureNavigationPreferencePinOrder preferenceValue
  , npLastVisitedAt = ME.featureNavigationPreferenceLastVisitedAt preferenceValue
  , npUseCount = ME.featureNavigationPreferenceUseCount preferenceValue
  , npUpdatedAt = ME.featureNavigationPreferenceUpdatedAt preferenceValue
  }

accessRequestsServer :: AuthedUser -> ServerT AccessRequestsAPI AppM
accessRequestsServer user =
       listMine
  :<|> createRequest
  :<|> listReviewQueue
  :<|> getRequest
  :<|> decideRequest
  :<|> cancelRequest
  where
    listMine = do
      now <- liftIO getCurrentTime
      runDB (expireFeatureAccessRequests now)
      rows <- runDB $ selectList
        [ME.FeatureAccessRequestRequesterPartyId ==. auPartyId user]
        [Desc ME.FeatureAccessRequestRequestedAt]
      mapM loadFeatureAccessRequestDTO rows

    createRequest (FeatureAccessRequestCreate requestedFeatureId requestedAction requestedJustification)
      | T.toLower (T.strip requestedFeatureId) == "artist.onboarding"
      , T.toLower (T.strip requestedAction) == "create" = createArtistAccess
      | otherwise = createReviewedRequest requestedFeatureId requestedAction requestedJustification

    createArtistAccess = do
      Env pool _ <- ask
      now <- liftIO getCurrentTime
      result <- liftIO $ flip runSqlPool pool $ do
        let ownOnboardingRequests =
              [ ME.FeatureAccessRequestRequesterPartyId ==. auPartyId user
              , ME.FeatureAccessRequestFeatureId ==. "artist.onboarding"
              , ME.FeatureAccessRequestAction ==. "create"
              ]
        -- Settle a lapsed onboarding request first, so self-service records a
        -- fresh approval instead of resurrecting an expired request. The rows
        -- are locked before the clock is read, in the same order activation and
        -- a reviewer's decision use.
        lockPendingOnboardingRequests (auPartyId user)
        lockedAt <- deadlineClockAfterLock now
        expirePendingAccessRequests lockedAt ownOnboardingRequests
        activated <- activateOwnArtistProfile (auPartyId user) now
        case activated of
          Left message -> pure (Left message)
          Right _ -> do
            -- Activation leaves a request that lapsed while it waited untouched.
            -- Settle it against the clock as it stands now, so the update below
            -- can only meet a request that is still open.
            activatedAt <- deadlineClockAfterLock now
            expirePendingAccessRequests activatedAt ownOnboardingRequests
            existing <- selectFirst
              [ ME.FeatureAccessRequestRequesterPartyId ==. auPartyId user
              , ME.FeatureAccessRequestFeatureId ==. "artist.onboarding"
              , ME.FeatureAccessRequestAction ==. "create"
              , ME.FeatureAccessRequestStatus <-. ["pending", "approved"]
              ] [Desc ME.FeatureAccessRequestRequestedAt]
            let note = Just "Perfil de artista activado automáticamente por su titular, sin aprobación manual."
            row <- case existing of
              Just (Entity key request) | ME.featureAccessRequestStatus request == "approved" ->
                pure (Entity key request)
              _ -> do
                (key, previous) <- case existing of
                  Just (Entity key request) -> pure (key, Just (ME.featureAccessRequestStatus request))
                  Nothing -> do
                    key <- insert ME.FeatureAccessRequest
                      { ME.featureAccessRequestRequesterPartyId = auPartyId user
                      , ME.featureAccessRequestFeatureId = "artist.onboarding"
                      , ME.featureAccessRequestAction = "create"
                      , ME.featureAccessRequestRoleContext = encodeAccessContext (map roleToText (auRoles user))
                      , ME.featureAccessRequestModuleContext = encodeAccessContext (map moduleName (Set.toList (auModules user)))
                      , ME.featureAccessRequestJustification = Nothing
                      , ME.featureAccessRequestStatus = "approved"
                      , ME.featureAccessRequestReviewerGroup = "system-policy"
                      , ME.featureAccessRequestReviewerPartyId = Nothing
                      , ME.featureAccessRequestReviewerNotes = note
                      , ME.featureAccessRequestRequestedAt = now
                      , ME.featureAccessRequestUpdatedAt = now
                      , ME.featureAccessRequestDecidedAt = Just now
                      , ME.featureAccessRequestCancelledAt = Nothing
                      , ME.featureAccessRequestExpiresAt = Nothing
                      }
                    pure (key, Nothing)
                update key
                  [ ME.FeatureAccessRequestStatus =. "approved"
                  , ME.FeatureAccessRequestReviewerPartyId =. Nothing
                  , ME.FeatureAccessRequestReviewerNotes =. note
                  , ME.FeatureAccessRequestUpdatedAt =. now
                  , ME.FeatureAccessRequestDecidedAt =. Just now
                  , ME.FeatureAccessRequestExpiresAt =. Nothing
                  ]
                insert_ (featureAccessRequestHistoryRecord key (Just (auPartyId user)) "automatically_approved" previous "approved" note now)
                writeFeatureAccessRequestAudit (Just (auPartyId user)) key "access_request_automatically_approved" "artist.onboarding" "create" "approved" now
                getJustEntity key
            pure (Right row)
      either (\message -> throwError err403 { errBody = BL.fromStrict (TE.encodeUtf8 message) }) loadFeatureAccessRequestDTO result

    createReviewedRequest requestedFeatureId requestedAction requestedJustification = do
      feature <- maybe
        (throwError err400 { errBody = "Unknown or unavailable feature" })
        pure
        (findRegistryFeature (T.strip requestedFeatureId))
      let actionName = T.toLower (T.strip requestedAction)
      unless (actionName `Set.member` supportedFeatureActions) $
        throwError err400 { errBody = "Unsupported feature action" }
      unless (registryFeatureRequestable feature actionName) $
        throwError err400 { errBody = "This feature action cannot be requested" }
      let currentModules = map moduleName (Set.toList (auModules user))
      when (registryFeatureAllows (auRoles user) currentModules feature actionName) $
        throwError err409 { errBody = "You already have access to this feature action" }
      justificationText <- either throwError pure (validateAccessRequestNote False requestedJustification)
      now <- liftIO getCurrentTime
      let featureIdValue = registryFeatureId feature
          reviewerGroupValue = reviewerGroupFor feature
          requestRecord = ME.FeatureAccessRequest
            { ME.featureAccessRequestRequesterPartyId = auPartyId user
            , ME.featureAccessRequestFeatureId = featureIdValue
            , ME.featureAccessRequestAction = actionName
            , ME.featureAccessRequestRoleContext = encodeAccessContext (map roleToText (auRoles user))
            , ME.featureAccessRequestModuleContext = encodeAccessContext currentModules
            , ME.featureAccessRequestJustification = justificationText
            , ME.featureAccessRequestStatus = "pending"
            , ME.featureAccessRequestReviewerGroup = reviewerGroupValue
            , ME.featureAccessRequestReviewerPartyId = Nothing
            , ME.featureAccessRequestReviewerNotes = Nothing
            , ME.featureAccessRequestRequestedAt = now
            , ME.featureAccessRequestUpdatedAt = now
            , ME.featureAccessRequestDecidedAt = Nothing
            , ME.featureAccessRequestCancelledAt = Nothing
            , ME.featureAccessRequestExpiresAt = Just (addUTCTime (30 * 24 * 60 * 60) now)
            }
      existing <- runDB $ selectFirst
        [ ME.FeatureAccessRequestRequesterPartyId ==. auPartyId user
        , ME.FeatureAccessRequestFeatureId ==. featureIdValue
        , ME.FeatureAccessRequestAction ==. actionName
        , ME.FeatureAccessRequestStatus ==. "pending"
        ] []
      when (isJust existing) $
        throwError err409 { errBody = "An active request already exists for this feature action" }
      Env{envPool} <- ask
      createdResult <- liftIO $ try $ flip runSqlPool envPool $ do
          requestId <- insert requestRecord
          insert_ (featureAccessRequestHistoryRecord requestId (Just (auPartyId user)) "submitted" Nothing "pending" justificationText now)
          insert_ Notification
            { notificationRecipientPartyId = auPartyId user
            , notificationNotifType = "access_request_submitted"
            , notificationTitle = "Solicitud de acceso recibida"
            , notificationBody = "Tu solicitud fue enviada al grupo revisor correspondiente."
            , notificationTargetType = Just "feature_access_request"
            , notificationTargetId = Just (fromIntegral (fromSqlKey requestId))
            , notificationTargetKey = Nothing
            , notificationIsRead = False
            , notificationCreatedAt = now
            }
          writeFeatureAccessRequestAudit (Just (auPartyId user)) requestId "access_request_submitted" featureIdValue actionName "pending" now
          notifyEligibleFeatureReviewers user feature actionName requestId now
          pure (Entity requestId requestRecord)
      created <- case createdResult of
        Right value -> pure value
        Left exception
          | isFeatureAccessRequestDuplicateConflict exception ->
              throwError err409 { errBody = "An active request already exists for this feature action" }
          | otherwise -> liftIO (throwIO exception)
      loadFeatureAccessRequestDTO created

    listReviewQueue requestedStatus = do
      unless (isFeatureAccessReviewer user) $
        throwError err403 { errBody = "Access request reviewer role required" }
      statusFilter <- either throwError pure (validateAccessRequestStatus requestedStatus)
      now <- liftIO getCurrentTime
      runDB (expireFeatureAccessRequests now)
      rows <- runDB $ selectList
        [ME.FeatureAccessRequestStatus ==. statusFilter]
        [Asc ME.FeatureAccessRequestRequestedAt]
      let visibleRows = filter (reviewerCanSeeRequest user . entityVal) rows
      mapM loadFeatureAccessRequestDTO visibleRows

    getRequest requestIdValue = do
      when (requestIdValue <= 0) $ throwError err404
      requestEntity <- runDB (getEntity (toSqlKey requestIdValue)) >>= maybe (throwError err404) pure
      let requestValue = entityVal requestEntity
          owner = ME.featureAccessRequestRequesterPartyId requestValue == auPartyId user
          reviewer = not owner && isFeatureAccessReviewer user && reviewerCanSeeRequest user requestValue
      unless (owner || reviewer) $ throwError err404
      now <- liftIO getCurrentTime
      let effective = if ME.featureAccessRequestStatus requestValue == "pending"
                         && maybe False (<= now) (ME.featureAccessRequestExpiresAt requestValue)
            then requestValue { ME.featureAccessRequestStatus = "expired" } else requestValue
      dto <- loadFeatureAccessRequestDTO (Entity (entityKey requestEntity) effective)
      pure $ object ["request" .= dto, "canReview" .= reviewer, "canCancel" .= owner]

    decideRequest requestIdValue (FeatureAccessRequestDecision requestedDecision requestedNotes) = do
      unless (isFeatureAccessReviewer user) $
        throwError err403 { errBody = "Access request reviewer role required" }
      decisionValue <- either throwError pure (validateAccessRequestDecision requestedDecision)
      notesValue <- either throwError pure (validateAccessRequestNote (decisionValue == "rejected") requestedNotes)
      let requestKey = toSqlKey requestIdValue
      requestEntity <- runDB (getEntity requestKey) >>= maybe (throwError err404) pure
      let requestValue = entityVal requestEntity
      when (ME.featureAccessRequestRequesterPartyId requestValue == auPartyId user) $
        throwError err403 { errBody = "Reviewers cannot decide their own access requests" }
      feature <- maybe (throwError err404) pure (findRegistryFeature (ME.featureAccessRequestFeatureId requestValue))
      unless (registryReviewerCanDecide user feature (ME.featureAccessRequestAction requestValue)) $
        throwError err403 { errBody = "Reviewer is not authorized to grant the requested feature action" }
      now <- liftIO getCurrentTime
      let requestNumber = T.pack (show requestIdValue)
          roleToProvision =
            if decisionValue == "approved"
              then registryFeatureAccessGrantRole
                feature
                (ME.featureAccessRequestAction requestValue)
              else Nothing
          generatedReviewNotes = fromMaybe
            ("Approved feature access request #" <> requestNumber)
            notesValue
          provisioningReason =
            "Approved feature access request #" <> requestNumber
              <> " for " <> ME.featureAccessRequestFeatureId requestValue
              <> ":" <> ME.featureAccessRequestAction requestValue
          provisioningCorrelation = "feature-access-request:" <> requestNumber
      Env{envPool} <- ask
      transactionResult <- liftIO $ try $ flip runSqlPool envPool $ do
        changed <- transitionPendingAccessRequest now requestKey
          [ ME.FeatureAccessRequestStatus =. decisionValue
          , ME.FeatureAccessRequestReviewerPartyId =. Just (auPartyId user)
          , ME.FeatureAccessRequestReviewerNotes =. notesValue
          , ME.FeatureAccessRequestUpdatedAt =. now
          , ME.FeatureAccessRequestDecidedAt =. Just now
          ]
        -- A request that is no longer pending (including one the sweep just
        -- expired) is reported as a value, not thrown: throwing would roll the
        -- expiry back and leave the lapsed request pending.
        if changed /= 1
          then pure Nothing
          else fmap Just $ do
            provisionedRole <- case roleToProvision of
              Nothing -> pure Nothing
              Just roleCode -> do
                result <- provisionReviewedSecurityRole
                  (ME.featureAccessRequestRequesterPartyId requestValue)
                  (auPartyId user)
                  roleCode
                  (ME.featureAccessRequestRequestedAt requestValue)
                  now
                  generatedReviewNotes
                  provisioningReason
                  provisioningCorrelation
                case result of
                  Left message -> liftIO (throwIO (AccessRequestProvisioningFailure message))
                  Right _ -> pure (Just roleCode)
            insert_ (featureAccessRequestHistoryRecord
              requestKey
              (Just (auPartyId user))
              decisionValue
              (Just "pending")
              decisionValue
              notesValue
              now)
            insert_ Notification
              { notificationRecipientPartyId = ME.featureAccessRequestRequesterPartyId requestValue
              , notificationNotifType = "access_request_decided"
              , notificationTitle = if decisionValue == "approved"
                  then "Solicitud de acceso aprobada"
                  else "Solicitud de acceso rechazada"
              , notificationBody = case provisionedRole of
                  Just roleCode ->
                    "La solicitud fue aprobada y el rol " <> roleToText roleCode
                      <> " ya fue otorgado mediante una revisión auditable. "
                      <> "Recarga tu sesión para verlo en la navegación."
                  Nothing | decisionValue == "approved" ->
                    "La solicitud fue aprobada para provisión manual mediante un permiso "
                      <> "compatible y auditable."
                  Nothing ->
                    "La solicitud fue revisada. Consulta las notas del revisor "
                      <> "para más información."
              , notificationTargetType = Just "feature_access_request"
              , notificationTargetId = Just (fromIntegral requestIdValue)
              , notificationTargetKey = Nothing
              , notificationIsRead = False
              , notificationCreatedAt = now
              }
            writeFeatureAccessRequestAudit
              (Just (auPartyId user))
              requestKey
              ("access_request_" <> decisionValue)
              (ME.featureAccessRequestFeatureId requestValue)
              (ME.featureAccessRequestAction requestValue)
              decisionValue
              now
            getJustEntity requestKey
      updated <- case transactionResult of
        Right (Just value) -> pure value
        Right Nothing ->
          throwError err409 { errBody = "Access request is no longer pending" }
        Left exception -> case fromException exception of
          Just (AccessRequestProvisioningFailure message) ->
            throwError err409 { errBody = BL.fromStrict (TE.encodeUtf8 message) }
          Nothing -> liftIO (throwIO (exception :: SomeException))
      loadFeatureAccessRequestDTO updated

    cancelRequest requestIdValue (FeatureAccessRequestCancel requestedNote) = do
      noteValue <- either throwError pure (validateAccessRequestNote False requestedNote)
      let requestKey = toSqlKey requestIdValue
      requestEntity <- runDB (getEntity requestKey) >>= maybe (throwError err404) pure
      let requestValue = entityVal requestEntity
      unless (ME.featureAccessRequestRequesterPartyId requestValue == auPartyId user) $
        throwError err404
      now <- liftIO getCurrentTime
      changed <- runDB $ transitionPendingAccessRequest now requestKey
        [ ME.FeatureAccessRequestStatus =. "cancelled"
        , ME.FeatureAccessRequestUpdatedAt =. now
        , ME.FeatureAccessRequestCancelledAt =. Just now
        ]
      when (changed /= 1) $
        throwError err409 { errBody = "Only pending access requests can be cancelled" }
      updated <- runDB $ do
        insert_ (featureAccessRequestHistoryRecord requestKey (Just (auPartyId user)) "cancelled" (Just "pending") "cancelled" noteValue now)
        writeFeatureAccessRequestAudit (Just (auPartyId user)) requestKey "access_request_cancelled"
          (ME.featureAccessRequestFeatureId requestValue) (ME.featureAccessRequestAction requestValue) "cancelled" now
        getJustEntity requestKey
      loadFeatureAccessRequestDTO updated

loadFeatureAccessRequestDTO :: Entity ME.FeatureAccessRequest -> AppM FeatureAccessRequestDTO
loadFeatureAccessRequestDTO (Entity requestId requestValue) = do
  requester <- runDB $ get (ME.featureAccessRequestRequesterPartyId requestValue)
  historyRows <- runDB $ selectList
    [ME.FeatureAccessRequestHistoryRequestId ==. requestId]
    [Asc ME.FeatureAccessRequestHistoryCreatedAt]
  pure FeatureAccessRequestDTO
    { farId = fromSqlKey requestId
    , farRequesterPartyId = fromSqlKey (ME.featureAccessRequestRequesterPartyId requestValue)
    , farRequesterName = normalizeOptionalInput (M.partyDisplayName <$> requester)
    , farFeatureId = ME.featureAccessRequestFeatureId requestValue
    , farAction = ME.featureAccessRequestAction requestValue
    , farRoleContext = decodeAccessContext (ME.featureAccessRequestRoleContext requestValue)
    , farModuleContext = decodeAccessContext (ME.featureAccessRequestModuleContext requestValue)
    , farStatus = ME.featureAccessRequestStatus requestValue
    , farReviewerGroup = ME.featureAccessRequestReviewerGroup requestValue
    , farJustification = ME.featureAccessRequestJustification requestValue
    , farReviewerNotes = ME.featureAccessRequestReviewerNotes requestValue
    , farRequestedAt = ME.featureAccessRequestRequestedAt requestValue
    , farUpdatedAt = ME.featureAccessRequestUpdatedAt requestValue
    , farDecidedAt = ME.featureAccessRequestDecidedAt requestValue
    , farCancelledAt = ME.featureAccessRequestCancelledAt requestValue
    , farExpiresAt = ME.featureAccessRequestExpiresAt requestValue
    , farHistory = map featureAccessRequestHistoryToDTO historyRows
    }

featureAccessRequestHistoryToDTO
  :: Entity ME.FeatureAccessRequestHistory
  -> FeatureAccessRequestHistoryDTO
featureAccessRequestHistoryToDTO (Entity historyId historyValue) = FeatureAccessRequestHistoryDTO
  { farhId = fromSqlKey historyId
  , farhTransition = ME.featureAccessRequestHistoryTransition historyValue
  , farhFromStatus = ME.featureAccessRequestHistoryFromStatus historyValue
  , farhToStatus = ME.featureAccessRequestHistoryToStatus historyValue
  , farhNote = ME.featureAccessRequestHistoryNote historyValue
  , farhCreatedAt = ME.featureAccessRequestHistoryCreatedAt historyValue
  }

featureAccessRequestHistoryRecord
  :: ME.FeatureAccessRequestId
  -> Maybe PartyId
  -> Text
  -> Maybe Text
  -> Text
  -> Maybe Text
  -> UTCTime
  -> ME.FeatureAccessRequestHistory
featureAccessRequestHistoryRecord requestId actorId transitionName fromStatusValue toStatusValue noteValue now =
  ME.FeatureAccessRequestHistory
    { ME.featureAccessRequestHistoryRequestId = requestId
    , ME.featureAccessRequestHistoryActorPartyId = actorId
    , ME.featureAccessRequestHistoryTransition = transitionName
    , ME.featureAccessRequestHistoryFromStatus = fromStatusValue
    , ME.featureAccessRequestHistoryToStatus = toStatusValue
    , ME.featureAccessRequestHistoryNote = noteValue
    , ME.featureAccessRequestHistoryCreatedAt = now
    }

validateAccessRequestNote :: Bool -> Maybe Text -> Either ServerError (Maybe Text)
validateAccessRequestNote required rawValue =
  let cleaned = cleanOptional rawValue
  in case cleaned of
      Nothing
        | required -> Left err400 { errBody = "Reviewer notes are required for rejection" }
        | otherwise -> Right Nothing
      Just value
        | T.length value > 2000 -> Left err400 { errBody = "Access request notes must be 2000 characters or fewer" }
        | T.any isUnsafeAccessRequestTextChar value -> Left err400 { errBody = "Access request notes contain unsupported control characters" }
        | otherwise -> Right (Just value)

isUnsafeAccessRequestTextChar :: Char -> Bool
isUnsafeAccessRequestTextChar char =
  (isControl char && char `notElem` ['\n', '\r', '\t'])
    || generalCategory char `elem` [Format, LineSeparator, ParagraphSeparator]

validateAccessRequestDecision :: Text -> Either ServerError Text
validateAccessRequestDecision rawValue =
  case T.toLower (T.strip rawValue) of
    "approved" -> Right "approved"
    "rejected" -> Right "rejected"
    _ -> Left err400 { errBody = "Decision must be approved or rejected" }

validateAccessRequestStatus :: Maybe Text -> Either ServerError Text
validateAccessRequestStatus rawValue =
  let statusValue = T.toLower (T.strip (fromMaybe "pending" rawValue))
  in if statusValue `elem` ["pending", "approved", "rejected", "cancelled", "expired"]
      then Right statusValue
      else Left err400 { errBody = "Unsupported access request status" }

reviewerGroupFor :: RegistryFeature -> Text
reviewerGroupFor feature =
  maybe "platform-reviewers" (<> "-reviewers") (registryFeatureNavigationGroup feature)

isFeatureAccessReviewer :: AuthedUser -> Bool
isFeatureAccessReviewer AuthedUser{..} =
  any (`elem` auRoles) [Admin, Manager, StudioManager]
    && auModules == modulesForRoles auRoles

newtype AccessRequestDecisionFailure
  = AccessRequestProvisioningFailure Text
  deriving (Show)

instance Exception AccessRequestDecisionFailure

isFeatureAccessRequestDuplicateConflict :: SomeException -> Bool
isFeatureAccessRequestDuplicateConflict exception =
  case fromException exception of
    Just sqlErr ->
      sqlState sqlErr == "23505"
        && "feature_access_requests_one_pending_idx"
          `BS8.isInfixOf` (sqlErrorMsg sqlErr <> " " <> sqlErrorDetail sqlErr)
    Nothing -> False

reviewerCanSeeRequest :: AuthedUser -> ME.FeatureAccessRequest -> Bool
reviewerCanSeeRequest reviewer requestValue =
  maybe False
    (\feature -> registryReviewerCanDecide reviewer feature (ME.featureAccessRequestAction requestValue))
    (findRegistryFeature (ME.featureAccessRequestFeatureId requestValue))

encodeAccessContext :: [Text] -> Text
encodeAccessContext = TE.decodeUtf8 . BL.toStrict . encode

decodeAccessContext :: Text -> [Text]
decodeAccessContext = fromMaybe [] . decodeStrict' . TE.encodeUtf8

-- | Apply a decision or cancellation to a request that is still pending.
-- Expiry is materialized lazily, so it is settled first in the same
-- transaction: a request past its deadline becomes terminal ("expired") and
-- the conditional update then changes no row. Returns the rows changed.
transitionPendingAccessRequest
  :: UTCTime
  -> ME.FeatureAccessRequestId
  -> [Update ME.FeatureAccessRequest]
  -> SqlPersistT IO Int64
transitionPendingAccessRequest now requestKey changes = do
  -- Only the target is settled here: a later provisioning failure rolls this
  -- transaction back, and must not undo expiry of unrelated requests.
  -- The caller sampled `now` before this transaction could own the row. Lock
  -- the target first and judge the deadline against the database clock read
  -- afterwards, so a decision that waited past `expires_at` cannot approve.
  _ <- rawSql "SELECT id FROM feature_access_requests WHERE id = ? FOR UPDATE"
    [toPersistValue requestKey] :: SqlPersistT IO [Single Int64]
  deadline <- deadlineClockAfterLock now
  expirePendingAccessRequests deadline [ME.FeatureAccessRequestId ==. requestKey]
  updateWhereCount
    [ ME.FeatureAccessRequestId ==. requestKey
    , ME.FeatureAccessRequestStatus ==. "pending"
    ]
    changes

expireFeatureAccessRequests :: UTCTime -> SqlPersistT IO ()
expireFeatureAccessRequests now = expirePendingAccessRequests now []

expirePendingAccessRequests :: UTCTime -> [Filter ME.FeatureAccessRequest] -> SqlPersistT IO ()
expirePendingAccessRequests now scope = do
  expired <- selectList
    ([ ME.FeatureAccessRequestStatus ==. "pending"
     , ME.FeatureAccessRequestExpiresAt <=. Just now
     ] <> scope) []
  forM_ expired $ \(Entity requestId requestValue) -> do
    changed <- updateWhereCount
      [ ME.FeatureAccessRequestId ==. requestId
      , ME.FeatureAccessRequestStatus ==. "pending"
      ]
      [ ME.FeatureAccessRequestStatus =. "expired"
      , ME.FeatureAccessRequestUpdatedAt =. now
      ]
    when (changed == 1) $ do
      insert_ (featureAccessRequestHistoryRecord requestId Nothing "expired" (Just "pending") "expired" Nothing now)
      writeFeatureAccessRequestAudit Nothing requestId "access_request_expired"
        (ME.featureAccessRequestFeatureId requestValue) (ME.featureAccessRequestAction requestValue) "expired" now

writeFeatureAccessRequestAudit
  :: Maybe PartyId
  -> ME.FeatureAccessRequestId
  -> Text
  -> Text
  -> Text
  -> Text
  -> UTCTime
  -> SqlPersistT IO ()
writeFeatureAccessRequestAudit actorId requestId actionName featureIdValue featureAction statusValue now =
  insert_ AuditLog
    { auditLogActorId = actorId
    , auditLogEntity = "feature_access_request"
    , auditLogEntityId = T.pack (show (fromSqlKey requestId))
    , auditLogAction = actionName
    , auditLogDiff = Just (TE.decodeUtf8 (BL.toStrict (encode (object
        [ "featureId" .= featureIdValue
        , "action" .= featureAction
        , "status" .= statusValue
        ]))))
    , auditLogCreatedAt = now
    }

notifyEligibleFeatureReviewers
  :: AuthedUser
  -> RegistryFeature
  -> Text
  -> ME.FeatureAccessRequestId
  -> UTCTime
  -> SqlPersistT IO ()
notifyEligibleFeatureReviewers requester feature actionName requestId now = do
  requesterParty <- get (auPartyId requester)
  let requesterName = fromMaybe "Un usuario sin nombre"
        (normalizeOptionalInput (M.partyDisplayName <$> requesterParty))
  reviewerPartyIds <- Set.toList . Set.fromList . concat <$>
    traverse selectCanonicalPartyIdsByRole [Admin, Manager, StudioManager]
  forM_ reviewerPartyIds $ \reviewerPartyId -> when (reviewerPartyId /= auPartyId requester) $ do
    rolesResult <- loadCanonicalPartyRoles reviewerPartyId
    roles <- either (liftIO . ioError . userError . T.unpack) pure rolesResult
    let reviewer = AuthedUser reviewerPartyId roles (modulesForRoles roles) Nothing Nothing
    when (registryReviewerCanDecide reviewer feature actionName) $
      insert_ Notification
        { notificationRecipientPartyId = reviewerPartyId
        , notificationNotifType = "access_request_review"
        , notificationTitle = "Nueva solicitud de acceso"
        , notificationBody = requesterName
            <> " solicitó acceso. La solicitud está disponible para revisión."
        , notificationTargetType = Just "feature_access_request"
        , notificationTargetId = Just (fromIntegral (fromSqlKey requestId))
        , notificationTargetKey = Nothing
        , notificationIsRead = False
        , notificationCreatedAt = now
        }

validateCalendarRedirectUri :: Text -> Either ServerError Text
validateCalendarRedirectUri rawRedirect =
  case normalizeConfiguredBaseUrl "redirectUri" (T.unpack rawRedirect) of
    Right (Just uri)
      | isSafeCalendarRedirectUri uri -> Right uri
    _ ->
      Left err400
        { errBody =
            "redirectUri must be an absolute https Google Calendar OAuth callback URL ending "
              <> "in /configuracion/integraciones/calendario, or http://localhost for local "
              <> "development, without query or fragment"
        }

validateCalendarAuthorizationCode :: Text -> Either ServerError Text
validateCalendarAuthorizationCode rawCode =
  let codeVal = T.strip rawCode
  in if T.null codeVal
       then Left err400 { errBody = "code is required" }
       else if T.any isControl codeVal
         then Left err400 { errBody = "code must not contain control characters" }
       else if T.any isHiddenDriveOAuthTokenChar codeVal
         then Left err400 { errBody = "code must not contain hidden formatting characters" }
       else if T.any isSpace codeVal
         then Left err400 { errBody = "code must not contain whitespace" }
       else if T.length codeVal > maxDriveOAuthTokenChars
         then Left err400 { errBody = "code must be 4096 characters or fewer" }
       else Right codeVal

resolveCalendarClientCreds
  :: Maybe Text
  -> Maybe Text
  -> Either ServerError (Text, Text)
resolveCalendarClientCreds rawClientId rawClientSecret = do
  mClientId <- validateOptionalDriveClientId "GOOGLE_CLIENT_ID" rawClientId
  mClientSecret <-
    validateOptionalDriveClientCredential "GOOGLE_CLIENT_SECRET" rawClientSecret
  case (mClientId, mClientSecret) of
    (Just clientId, Just clientSecret) -> Right (clientId, clientSecret)
    (Nothing, Nothing) -> Left missingCalendarCredsError
    _ -> Left partialCalendarCredsError
  where
    missingCalendarCredsError =
      err503
        { errBody =
            "Google Calendar no configurado (faltan GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET)."
        }
    partialCalendarCredsError =
      err503
        { errBody =
            "Google Calendar no configurado: GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET must both be set."
        }

validateConfiguredCalendarRedirectUri :: Text -> Either ServerError Text
validateConfiguredCalendarRedirectUri rawRedirect =
  case normalizeConfiguredBaseUrl "GOOGLE_REDIRECT_URI" (T.unpack rawRedirect) of
    Right (Just uri)
      | isSafeCalendarRedirectUri uri -> Right uri
    _ ->
      Left err503
        { errBody =
            "GOOGLE_REDIRECT_URI must be an absolute https Google Calendar OAuth callback "
              <> "URL ending in /configuracion/integraciones/calendario, or http://localhost "
              <> "for local development, without query or fragment"
        }

isSafeCalendarRedirectUri :: Text -> Bool
isSafeCalendarRedirectUri uri
  | not (googleCalendarOAuthCallbackPath `T.isSuffixOf` uri) = False
  | hasAmbiguousOAuthRedirectPath uri = False
  | "https://" `T.isPrefixOf` lowerUri =
      maybe False (not . isLocalCalendarRedirectHost) (calendarRedirectHost (T.drop 8 uri))
  | "http://" `T.isPrefixOf` lowerUri =
      maybe False isLocalCalendarRedirectHost (calendarRedirectHost (T.drop 7 uri))
  | otherwise = False
  where
    googleCalendarOAuthCallbackPath = "/configuracion/integraciones/calendario"
    lowerUri = T.toLower uri

hasAmbiguousOAuthRedirectPath :: Text -> Bool
hasAmbiguousOAuthRedirectPath uri =
  case absoluteUrlPath uri of
    Nothing -> True
    Just path ->
      T.null path
        || not ("/" `T.isPrefixOf` path)
        || any isAmbiguousSegment (drop 1 (T.splitOn "/" path))
  where
    isAmbiguousSegment segment =
      T.null segment || segment == "." || segment == ".."

absoluteUrlPath :: Text -> Maybe Text
absoluteUrlPath uri
  | "https://" `T.isPrefixOf` lowerUri = pathFromRemainder (T.drop 8 uri)
  | "http://" `T.isPrefixOf` lowerUri = pathFromRemainder (T.drop 7 uri)
  | otherwise = Nothing
  where
    lowerUri = T.toLower uri
    pathFromRemainder remainder =
      let suffix = T.dropWhile (/= '/') remainder
      in if T.null suffix
           then Nothing
           else Just (T.takeWhile (\ch -> ch /= '?' && ch /= '#') suffix)

calendarRedirectHost :: Text -> Maybe Text
calendarRedirectHost remainder =
  let authority = T.takeWhile (\c -> c /= '/' && c /= '?' && c /= '#') remainder
  in if T.null authority
       then Nothing
       else if "[" `T.isPrefixOf` authority
         then
           let (hostPart, rest) = T.breakOn "]" authority
           in if T.null rest
                then Nothing
                else Just (T.toLower (T.drop 1 hostPart))
         else
           let (host, _) = T.breakOn ":" authority
           in if T.null host then Nothing else Just (T.toLower host)

isLocalCalendarRedirectHost :: Text -> Bool
isLocalCalendarRedirectHost host =
  host == "localhost"
    || ".localhost" `T.isSuffixOf` host
    || host == "::1"
    || isLoopbackIpv4Host host

isLoopbackIpv4Host :: Text -> Bool
isLoopbackIpv4Host host =
  case traverse parseOctet (T.splitOn "." host) of
    Just [first, _, _, _] -> first == (127 :: Int)
    _ -> False
  where
    parseOctet segment = do
      value <- readMaybe (T.unpack segment)
      if value >= (0 :: Int) && value <= 255
        then Just value
        else Nothing

validateOptionalCalendarIdQuery :: Maybe Text -> Either ServerError (Maybe Text)
validateOptionalCalendarIdQuery Nothing = Right Nothing
validateOptionalCalendarIdQuery (Just rawCalendarId) =
  Just <$> either (Left . calendarQueryError) Right (CalAPI.normalizeCalendarId rawCalendarId)

validateCalendarEventListQuery
  :: Maybe Text
  -> Maybe UTCTime
  -> Maybe UTCTime
  -> Maybe Text
  -> Either ServerError (Maybe Text, Maybe UTCTime, Maybe UTCTime, Maybe Text)
validateCalendarEventListQuery mCalendarId mFrom mTo mStatus = do
  calendarIdVal <- validateOptionalCalendarIdQuery mCalendarId
  statusVal <- validateCalendarEventStatusQuery mStatus
  case (mFrom, mTo) of
    (Just fromVal, Just toVal) | toVal < fromVal ->
      Left err400 { errBody = "from must be on or before to" }
    _ -> Right (calendarIdVal, mFrom, mTo, statusVal)

validateCalendarSyncWindow
  :: Maybe Text
  -> Maybe UTCTime
  -> Maybe UTCTime
  -> Either ServerError ()
validateCalendarSyncWindow mSyncCursor mFrom mTo =
  case (validateGoogleCalendarSyncCursor mSyncCursor, mFrom <|> mTo) of
    (Left err, _) -> Left err
    (Right (Just _), Just _) ->
      Left err400
        { errBody =
            "Calendar sync range cannot be combined with an existing Google sync cursor"
        }
    (Right _, _) ->
      case (mFrom, mTo) of
        (Just fromTs, Just toTs) | toTs < fromTs ->
          Left err400 { errBody = "from must be on or before to" }
        _ -> Right ()

validateGoogleCalendarSyncCursor :: Maybe Text -> Either ServerError (Maybe Text)
validateGoogleCalendarSyncCursor Nothing = Right Nothing
validateGoogleCalendarSyncCursor (Just rawCursor)
  | T.null cursorVal =
      Left err500 { errBody = "Stored Google Calendar sync cursor is invalid" }
  | T.length cursorVal > maxGoogleCalendarSyncCursorChars =
      Left err500 { errBody = "Stored Google Calendar sync cursor is invalid" }
  | T.any isControl cursorVal =
      Left err500 { errBody = "Stored Google Calendar sync cursor is invalid" }
  | T.any isHiddenDriveOAuthTokenChar cursorVal =
      Left err500 { errBody = "Stored Google Calendar sync cursor is invalid" }
  | T.any isSpace cursorVal =
      Left err500 { errBody = "Stored Google Calendar sync cursor is invalid" }
  | otherwise =
      Right (Just cursorVal)
  where
    cursorVal = T.strip rawCursor

maxGoogleCalendarSyncCursorChars :: Int
maxGoogleCalendarSyncCursorChars = 4096

validateStoredGoogleCalendarAccessToken :: Maybe Text -> Either ServerError Text
validateStoredGoogleCalendarAccessToken Nothing =
  Left err401 { errBody = "No hay access_token para Google Calendar." }
validateStoredGoogleCalendarAccessToken (Just rawToken) =
  validateStoredGoogleCalendarOAuthToken "access token" rawToken

validateStoredGoogleCalendarRefreshToken :: Text -> Either ServerError Text
validateStoredGoogleCalendarRefreshToken =
  validateStoredGoogleCalendarOAuthToken "refresh token"

validateStoredGoogleCalendarOAuthToken :: Text -> Text -> Either ServerError Text
validateStoredGoogleCalendarOAuthToken label rawToken
  | T.null tokenVal = invalid
  | T.length tokenVal > maxDriveOAuthTokenChars = invalid
  | T.any isSpace tokenVal = invalid
  | T.any isControl tokenVal = invalid
  | T.any isHiddenDriveOAuthTokenChar tokenVal = invalid
  | T.any (not . isAscii) tokenVal = invalid
  | otherwise = Right tokenVal
  where
    tokenVal = T.strip rawToken
    invalid =
      Left err500
        { errBody =
            BL.fromStrict $
              TE.encodeUtf8 ("Stored Google Calendar " <> label <> " is invalid")
        }

validateCalendarEventStatusQuery :: Maybe Text -> Either ServerError (Maybe Text)
validateCalendarEventStatusQuery Nothing = Right Nothing
validateCalendarEventStatusQuery (Just rawStatus) = do
  statusVal <- T.toLower <$> validateCalendarQueryText "status" rawStatus
  if statusVal `elem` calendarEventStatuses
    then Right (Just statusVal)
    else
      Left err400
        { errBody = "status must be one of: confirmed, tentative, cancelled" }

validateCalendarQueryText :: Text -> Text -> Either ServerError Text
validateCalendarQueryText fieldName rawValue =
  let trimmed = T.strip rawValue
  in if T.null trimmed
       then Left (calendarQueryError (fieldName <> " must not be blank"))
       else if T.any isControl trimmed
         then Left (calendarQueryError (fieldName <> " must not contain control characters"))
       else if T.any isHiddenDriveOAuthTokenChar trimmed
         then Left (calendarQueryError (fieldName <> " must not contain hidden formatting characters"))
       else Right trimmed

calendarQueryError :: Text -> ServerError
calendarQueryError message =
  err400 { errBody = BL.fromStrict (TE.encodeUtf8 message) }

calendarEventStatuses :: [Text]
calendarEventStatuses = ["confirmed", "tentative", "cancelled"]

validateGoogleCalendarEventStatus :: Text -> Either Text Text
validateGoogleCalendarEventStatus rawStatus
  | T.null statusVal =
      Left "Google Calendar event status must not be blank"
  | T.any isControl statusVal =
      Left "Google Calendar event status must not contain control characters"
  | T.any isHiddenDriveOAuthTokenChar statusVal =
      Left "Google Calendar event status must not contain hidden formatting characters"
  | T.any isSpace statusVal =
      Left "Google Calendar event status must not contain whitespace"
  | statusVal `elem` calendarEventStatuses =
      Right statusVal
  | otherwise =
      Left "Google Calendar event status must be one of: confirmed, tentative, cancelled"
  where
    statusVal = T.toLower (T.strip rawStatus)

validateGoogleCalendarEventId :: Text -> Either Text Text
validateGoogleCalendarEventId rawEventId
  | T.null eventIdVal =
      Left "Google Calendar event id must not be blank"
  | T.length eventIdVal > maxGoogleCalendarEventIdChars =
      Left "Google Calendar event id must be 1024 characters or fewer"
  | T.any isControl eventIdVal =
      Left "Google Calendar event id must not contain control characters"
  | T.any isHiddenDriveOAuthTokenChar eventIdVal =
      Left "Google Calendar event id must not contain hidden formatting characters"
  | T.any isSpace eventIdVal =
      Left "Google Calendar event id must not contain whitespace"
  | T.any (not . isAscii) eventIdVal =
      Left "Google Calendar event id must contain only ASCII characters"
  | otherwise =
      Right eventIdVal
  where
    eventIdVal = T.strip rawEventId

maxGoogleCalendarEventIdChars :: Int
maxGoogleCalendarEventIdChars = 1024

calendarServer :: AuthedUser -> ServerT CalAPI.CalendarAPI AppM
calendarServer user =
       calendarAuthUrlH
  :<|> calendarTokenExchangeH
  :<|> calendarConfigH
  :<|> calendarSyncH
  :<|> calendarEventsH
  where
    requireAdmin = requireStrictAdmin user

    loadGoogleEnv :: Maybe Text -> AppM (Text, Text, Text)
    loadGoogleEnv mRedirect = do
      mCid <- liftIO $ lookupEnvText "GOOGLE_CLIENT_ID"
      mSecret <- liftIO $ lookupEnvText "GOOGLE_CLIENT_SECRET"
      mRedirectEnv <- liftIO $ lookupEnvTextNonEmpty "GOOGLE_REDIRECT_URI"
      (cid', sec') <- either throwError pure (resolveCalendarClientCreds mCid mSecret)
      let mProvidedRedirect = cleanOptional mRedirect
          mRedirectRaw = mProvidedRedirect <|> mRedirectEnv
      case mRedirectRaw of
        Just redirRaw -> do
          redir' <-
            either throwError pure $
              case mProvidedRedirect of
                Just _ -> validateCalendarRedirectUri redirRaw
                Nothing -> validateConfiguredCalendarRedirectUri redirRaw
          pure (cid', sec', redir')
        _ ->
          throwError err503
            { errBody = "Google Calendar no configurado (faltan GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET / GOOGLE_REDIRECT_URI)." }

    calendarAuthUrlH :: AppM CalAPI.AuthUrlResponse
    calendarAuthUrlH = do
      requireAdmin
      (cid, _sec, redirect) <- loadGoogleEnv Nothing
      let scope = urlEncode True "https://www.googleapis.com/auth/calendar.readonly"
          url = T.concat
            [ "https://accounts.google.com/o/oauth2/v2/auth?response_type=code"
            , "&client_id=", cid
            , "&redirect_uri=", redirect
            , "&scope=", TE.decodeUtf8 scope
            , "&access_type=offline&prompt=consent"
            ]
      pure (CalAPI.AuthUrlResponse url)

    calendarTokenExchangeH :: CalAPI.TokenExchangeIn -> AppM CalAPI.CalendarConfigDTO
    calendarTokenExchangeH CalAPI.TokenExchangeIn{..} = do
      requireAdmin
      codeVal <- either throwError pure (validateCalendarAuthorizationCode code)
      (cid, sec, redirect) <- loadGoogleEnv redirectUri
      manager <- pure sharedTlsManager
      token <- requestGoogleToken manager
        [ ("code", TE.encodeUtf8 codeVal)
        , ("client_id", TE.encodeUtf8 cid)
        , ("client_secret", TE.encodeUtf8 sec)
        , ("redirect_uri", TE.encodeUtf8 redirect)
        , ("grant_type", "authorization_code")
        ]
      now <- liftIO getCurrentTime
      let GoogleToken
            { access_token = gAccessToken
            , refresh_token = gRefreshToken
            , expires_in = gExpiresIn
            , token_type = gTokenType
            } = token
          expiresAt = addUTCTime . fromIntegral <$> gExpiresIn <*> pure now
      mExisting <- runDB $ getBy (Cal.UniqueCalendar calendarId)
      cfgId <- case mExisting of
        Nothing -> runDB $ insert Cal.GoogleCalendarConfig
          { Cal.googleCalendarConfigOwnerId = Just (auPartyId user)
          , Cal.googleCalendarConfigCalendarId = calendarId
          , Cal.googleCalendarConfigAccessToken = Just gAccessToken
          , Cal.googleCalendarConfigRefreshToken = gRefreshToken
          , Cal.googleCalendarConfigTokenType = gTokenType
          , Cal.googleCalendarConfigTokenExpiresAt = expiresAt
          , Cal.googleCalendarConfigSyncCursor = Nothing
          , Cal.googleCalendarConfigSyncedAt = Nothing
          , Cal.googleCalendarConfigCreatedAt = now
          , Cal.googleCalendarConfigUpdatedAt = now
          }
        Just (Entity eid oldCfg) -> do
          runDB $ update eid
            [ Cal.GoogleCalendarConfigAccessToken =. Just gAccessToken
            , Cal.GoogleCalendarConfigRefreshToken =. (gRefreshToken <|> Cal.googleCalendarConfigRefreshToken oldCfg)
            , Cal.GoogleCalendarConfigTokenType =. gTokenType
            , Cal.GoogleCalendarConfigTokenExpiresAt =. expiresAt
            , Cal.GoogleCalendarConfigUpdatedAt =. now
            ]
          pure eid
      pure CalAPI.CalendarConfigDTO
        { configId = fromIntegral (fromSqlKey cfgId)
        , calendarId = calendarId
        , syncCursor = Nothing
        , syncedAt = Nothing
        }

    calendarConfigH :: Maybe Text -> AppM (Maybe CalAPI.CalendarConfigDTO)
    calendarConfigH mCalendarId = do
      requireAdmin
      calendarIdFilter <- either throwError pure (validateOptionalCalendarIdQuery mCalendarId)
      mCfg <- case calendarIdFilter of
        Just cid -> do
          mExplicitCfg <- runDB $ getBy (Cal.UniqueCalendar cid)
          traverse (either throwError pure . validateStoredCalendarConfig) mExplicitCfg
        _ -> do
          candidates <- runDB $
            selectList [] [Desc Cal.GoogleCalendarConfigUpdatedAt, LimitTo 2]
          either throwError pure (selectUniqueCalendarConfigFallback candidates)
      pure (toCfgDTO <$> mCfg)

    calendarSyncH :: CalAPI.SyncRequest -> AppM CalAPI.SyncResult
    calendarSyncH CalAPI.SyncRequest{..} = do
      requireAdmin
      (cidEnv, secEnv, redirectEnv) <- loadGoogleEnv Nothing
      mCfg <- runDB $ getBy (Cal.UniqueCalendar calendarId)
      case mCfg of
        Nothing -> throwError err404
        Just (Entity cfgId cfg) -> do
          now <- liftIO getCurrentTime
          syncCursorVal <- either throwError pure $
            validateGoogleCalendarSyncCursor (Cal.googleCalendarConfigSyncCursor cfg)
          either throwError pure $
            validateCalendarSyncWindow syncCursorVal from to
          let cfgValidated = cfg { Cal.googleCalendarConfigSyncCursor = syncCursorVal }
          cfgFresh <- ensureAccessToken cidEnv secEnv redirectEnv cfgValidated now
          (createdCount, updatedCount, cancelledCount, newCursor) <-
            syncFromGoogle cfgFresh from to now
          runDB $ update cfgId
            [ Cal.GoogleCalendarConfigSyncedAt =. Just now
            , Cal.GoogleCalendarConfigSyncCursor =. newCursor
            ]
          pure CalAPI.SyncResult
            { created = createdCount
            , updated = updatedCount
            , deleted = cancelledCount
            , cursor = newCursor
            }

    calendarEventsH :: Maybe Text -> Maybe UTCTime -> Maybe UTCTime -> Maybe Text -> AppM [CalAPI.CalendarEventDTO]
    calendarEventsH mCal fromTs toTs mStatus = do
      requireAdmin
      (calendarIdFilter, fromFilter, toFilter, statusFilter) <-
        either throwError pure (validateCalendarEventListQuery mCal fromTs toTs mStatus)
      let baseFilters =
            maybe [] (\cid -> [Cal.GoogleCalendarEventCalendarId ==. cid]) calendarIdFilter
          dateFilters =
            maybe [] (\fromVal -> [Cal.GoogleCalendarEventStartAt >=. Just fromVal]) fromFilter
            ++ maybe [] (\toVal -> [Cal.GoogleCalendarEventStartAt <=. Just toVal]) toFilter
          statusFilters = maybe [] (\st -> [Cal.GoogleCalendarEventStatus ==. st]) statusFilter
          filters = baseFilters ++ dateFilters ++ statusFilters
      rows <- runDB $ selectList filters [Desc Cal.GoogleCalendarEventStartAt, Desc Cal.GoogleCalendarEventUpdatedLocal]
      pure (map toEventDTO rows)

    toCfgDTO :: Entity Cal.GoogleCalendarConfig -> CalAPI.CalendarConfigDTO
    toCfgDTO (Entity cfgId cfg) =
      CalAPI.CalendarConfigDTO
        { configId = fromIntegral (fromSqlKey cfgId)
        , calendarId = Cal.googleCalendarConfigCalendarId cfg
        , syncCursor = Cal.googleCalendarConfigSyncCursor cfg
        , syncedAt = Cal.googleCalendarConfigSyncedAt cfg
        }

    toEventDTO :: Entity Cal.GoogleCalendarEvent -> CalAPI.CalendarEventDTO
    toEventDTO (Entity eid e) =
      CalAPI.CalendarEventDTO
        { eventId = entityKeyInt eid
        , googleId = Cal.googleCalendarEventGoogleId e
        , calendarId = Cal.googleCalendarEventCalendarId e
        , status = Cal.googleCalendarEventStatus e
        , summary = Cal.googleCalendarEventSummary e
        , description = Cal.googleCalendarEventDescription e
        , location = Cal.googleCalendarEventLocation e
        , startAt = Cal.googleCalendarEventStartAt e
        , endAt = Cal.googleCalendarEventEndAt e
        , updatedAt = Cal.googleCalendarEventUpdatedAt e
        , htmlLink = Cal.googleCalendarEventHtmlLink e
        , rawPayload = CMS.unAesonValue <$> Cal.googleCalendarEventRawPayload e
        }

    ensureAccessToken :: Text -> Text -> Text -> Cal.GoogleCalendarConfig -> UTCTime -> AppM Cal.GoogleCalendarConfig
    ensureAccessToken cid sec redirect cfg now =
      case Cal.googleCalendarConfigTokenExpiresAt cfg of
        Just expAt | expAt > addUTCTime 60 now -> pure cfg
        _ -> do
          case Cal.googleCalendarConfigRefreshToken cfg of
            Nothing -> throwError err401 { errBody = "No hay refresh_token para Google Calendar." }
            Just rt -> do
              refreshToken <- either throwError pure (validateStoredGoogleCalendarRefreshToken rt)
              refreshAccessToken cid sec redirect cfg refreshToken now

    refreshAccessToken :: Text -> Text -> Text -> Cal.GoogleCalendarConfig -> Text -> UTCTime -> AppM Cal.GoogleCalendarConfig
    refreshAccessToken cid sec redirect cfg rt now = do
      manager <- pure sharedTlsManager
      token <- requestGoogleToken manager
        [ ("client_id", TE.encodeUtf8 cid)
        , ("client_secret", TE.encodeUtf8 sec)
        , ("refresh_token", TE.encodeUtf8 rt)
        , ("grant_type", "refresh_token")
        , ("redirect_uri", TE.encodeUtf8 redirect)
        ]
      let GoogleToken
            { access_token = gAccessToken
            , expires_in = gExpiresIn
            , token_type = gTokenType
            } = token
          expiresAt = addUTCTime . fromIntegral <$> gExpiresIn <*> pure now
          updatedCfg = cfg
            { Cal.googleCalendarConfigAccessToken = Just gAccessToken
            , Cal.googleCalendarConfigTokenType = gTokenType
            , Cal.googleCalendarConfigTokenExpiresAt = expiresAt
            , Cal.googleCalendarConfigUpdatedAt = now
            }
      _ <- runDB $ updateWhere
        [Cal.GoogleCalendarConfigCalendarId ==. Cal.googleCalendarConfigCalendarId cfg]
        [ Cal.GoogleCalendarConfigAccessToken =. Cal.googleCalendarConfigAccessToken updatedCfg
        , Cal.GoogleCalendarConfigTokenType =. Cal.googleCalendarConfigTokenType updatedCfg
        , Cal.GoogleCalendarConfigTokenExpiresAt =. Cal.googleCalendarConfigTokenExpiresAt updatedCfg
        , Cal.GoogleCalendarConfigUpdatedAt =. now
        ]
      pure updatedCfg

    syncFromGoogle :: Cal.GoogleCalendarConfig -> Maybe UTCTime -> Maybe UTCTime -> UTCTime -> AppM (Int, Int, Int, Maybe Text)
    syncFromGoogle cfg fromTs toTs now = do
      manager <- pure sharedTlsManager
      token <- either throwError pure $
        validateStoredGoogleCalendarAccessToken (Cal.googleCalendarConfigAccessToken cfg)
      (events, cursor) <-
        fetchAllPages
          manager
          token
          (Cal.googleCalendarConfigCalendarId cfg)
          (Cal.googleCalendarConfigSyncCursor cfg)
          fromTs
          toTs
          Nothing
          []
      results <- mapM (upsertEvent now (Cal.googleCalendarConfigCalendarId cfg)) events
      let createdCount = length (filter (== "created") results)
          updatedCount = length (filter (== "updated") results)
          deletedCount = length (filter (== "cancelled") results)
      pure (createdCount, updatedCount, deletedCount, cursor)

    fetchAllPages
      :: Manager
      -> Text
      -> Text
      -> Maybe Text
      -> Maybe UTCTime
      -> Maybe UTCTime
      -> Maybe Text
      -> [Value]
      -> AppM ([Value], Maybe Text)
    fetchAllPages manager token calendarId mSync mFrom mTo mPage acc = do
      let baseUrl = googleCalendarEventsEndpoint calendarId
          timeParams =
            case mSync of
              Just _ -> []
              Nothing ->
                [ ("singleEvents", Just "true")
                , ("showDeleted", Just "true")
                , ("maxResults", Just "2000")
                ] ++ maybe [] (\fromVal -> [("timeMin", Just (formatTime' fromVal))]) mFrom
                  ++ maybe [] (\toVal -> [("timeMax", Just (formatTime' toVal))]) mTo
          syncParams = maybe [] (\st -> [("syncToken", Just (TE.encodeUtf8 st))]) mSync
          pageParams = maybe [] (\pt -> [("pageToken", Just (TE.encodeUtf8 pt))]) mPage
          params = timeParams ++ syncParams ++ pageParams
          query = renderQuery True params
      req0 <- liftIO $ parseRequest (baseUrl ++ BL8.unpack (BL.fromStrict query))
      let req = req0 { requestHeaders = [("Authorization", "Bearer " <> TE.encodeUtf8 token)] }
      resp <- liftIO $ httpLbs req manager
      let codeStatus = statusCode (responseStatus resp)
      if codeStatus == 410
        then do
          let (retrySync, retryFrom, retryTo, retryPage, retryAcc) =
                expiredGoogleCalendarSyncRetryState mFrom mTo acc
          fetchAllPages manager token calendarId retrySync retryFrom retryTo retryPage retryAcc
        else do
          when (codeStatus >= 400) $
            throwError err502 { errBody = "Google Calendar devolvió error al sincronizar." }
          page <- case eitherDecode (responseBody resp) of
            Left err -> throwError err502 { errBody = BL8.pack ("No se pudo parsear eventos: " <> err) }
            Right val -> pure val
          let GoogleEventsPage items nextPage nextSync = page
              acc' = acc <> items
          case nextPage of
            Just p -> fetchAllPages manager token calendarId mSync mFrom mTo (Just p) acc'
            Nothing -> pure (acc', nextSync)

    upsertEvent :: UTCTime -> Text -> Value -> AppM Text
    upsertEvent now calendarId eventVal =
      case parseEvent calendarId eventVal of
        Nothing -> pure "skipped"
        Just ev -> do
          let keyFilter =
                [ Cal.GoogleCalendarEventCalendarId ==. calendarId
                , Cal.GoogleCalendarEventGoogleId ==. peGoogleId ev
                ]
          existing <- runDB $ selectFirst keyFilter []
          case existing of
            Nothing -> do
              _ <- runDB $ insert Cal.GoogleCalendarEvent
                { Cal.googleCalendarEventCalendarId = calendarId
                , Cal.googleCalendarEventGoogleId = peGoogleId ev
                , Cal.googleCalendarEventStatus = peStatus ev
                , Cal.googleCalendarEventSummary = peSummary ev
                , Cal.googleCalendarEventDescription = peDescription ev
                , Cal.googleCalendarEventLocation = peLocation ev
                , Cal.googleCalendarEventStartAt = peStartAt ev
                , Cal.googleCalendarEventEndAt = peEndAt ev
                , Cal.googleCalendarEventUpdatedAt = peUpdatedAt ev
                , Cal.googleCalendarEventHtmlLink = peHtmlLink ev
                , Cal.googleCalendarEventAttendees = peAttendees ev
                , Cal.googleCalendarEventRawPayload = peRawPayload ev
                , Cal.googleCalendarEventCreatedAt = now
                , Cal.googleCalendarEventUpdatedLocal = now
                }
              pure (if peStatus ev == "cancelled" then "cancelled" else "created")
            Just (Entity eid _) -> do
              runDB $ update eid
                [ Cal.GoogleCalendarEventStatus =. peStatus ev
                , Cal.GoogleCalendarEventSummary =. peSummary ev
                , Cal.GoogleCalendarEventDescription =. peDescription ev
                , Cal.GoogleCalendarEventLocation =. peLocation ev
                , Cal.GoogleCalendarEventStartAt =. peStartAt ev
                , Cal.GoogleCalendarEventEndAt =. peEndAt ev
                , Cal.GoogleCalendarEventUpdatedAt =. peUpdatedAt ev
                , Cal.GoogleCalendarEventHtmlLink =. peHtmlLink ev
                , Cal.GoogleCalendarEventAttendees =. peAttendees ev
                , Cal.GoogleCalendarEventRawPayload =. peRawPayload ev
                , Cal.GoogleCalendarEventUpdatedLocal =. now
                ]
              pure (if peStatus ev == "cancelled" then "cancelled" else "updated")

    parseEvent :: Text -> Value -> Maybe ParsedEvent
    parseEvent _ val =
      parseMaybe (withObject "GoogleEvent" $ \o -> do
        gid <-
          o .: "id"
            >>= either (fail . T.unpack) pure . validateGoogleCalendarEventId
        status <-
          o .:? "status"
            >>= maybe
              (pure "confirmed")
              (either (fail . T.unpack) pure . validateGoogleCalendarEventStatus)
        summary <- o .:? "summary"
        description <- o .:? "description"
        location <- o .:? "location"
        htmlLink <-
          o .:? "htmlLink"
            >>= traverse
              (either (fail . T.unpack) pure . validateGoogleCalendarHtmlLink)
        updatedRaw <- o .:? "updated"
        attendeesVal <- o .:? "attendees"
        startObj <- o .:? "start"
        endObj <- o .:? "end"
        let startAt = startObj >>= parseDateFields
            endAt = endObj >>= parseDateFields
            updatedAt = updatedRaw >>= parseIso
        pure ParsedEvent
          { peGoogleId = gid
          , peStatus = status
          , peSummary = summary
          , peDescription = description
          , peLocation = location
          , peStartAt = startAt
          , peEndAt = endAt
          , peUpdatedAt = updatedAt
          , peHtmlLink = htmlLink
          , peAttendees = CMS.AesonValue <$> attendeesVal
          , peRawPayload = Just (CMS.AesonValue val)
          }) val

    parseDateFields :: Value -> Maybe UTCTime
    parseDateFields =
      parseMaybe (withObject "DateTime" $ \o -> do
        dateTime <- o .:? "dateTime"
        dateOnly <- o .:? "date"
        case (dateTime :: Maybe Text, dateOnly :: Maybe Text) of
          (Just dt, _) -> pure dt
          (Nothing, Just d) -> pure (d <> "T00:00:00Z")
          _ -> fail "no date"
      ) >=> parseIso

    parseIso :: Text -> Maybe UTCTime
    parseIso txt = iso8601ParseM (T.unpack txt)

    formatTime' :: UTCTime -> ByteString
    formatTime' t = TE.encodeUtf8 (T.pack (formatTime defaultTimeLocale "%Y-%m-%dT%H:%M:%SZ" t))

expiredGoogleCalendarSyncRetryState
  :: Maybe UTCTime
  -> Maybe UTCTime
  -> [Value]
  -> (Maybe Text, Maybe UTCTime, Maybe UTCTime, Maybe Text, [Value])
expiredGoogleCalendarSyncRetryState mFrom mTo _partialEvents =
  (Nothing, mFrom, mTo, Nothing, [])

googleCalendarEventsEndpoint :: Text -> String
googleCalendarEventsEndpoint calendarId =
  T.unpack $
    "https://www.googleapis.com/calendar/v3/calendars/"
      <> encodeGooglePathSegment calendarId
      <> "/events"

selectUniqueCalendarConfigFallback
  :: [Entity Cal.GoogleCalendarConfig]
  -> Either ServerError (Maybe (Entity Cal.GoogleCalendarConfig))
selectUniqueCalendarConfigFallback candidates = do
  validatedCandidates <- traverse validateStoredCalendarConfig candidates
  case validatedCandidates of
    [] -> Right Nothing
    [cfg] -> Right (Just cfg)
    _ ->
      Left err409
        { errBody =
            "calendarId is required when multiple Google Calendar configs exist"
        }

validateStoredCalendarConfig
  :: Entity Cal.GoogleCalendarConfig
  -> Either ServerError (Entity Cal.GoogleCalendarConfig)
validateStoredCalendarConfig (Entity cfgId cfg) = do
  unless (fromSqlKey cfgId > 0) invalidStoredCalendarConfigId
  when
    (Cal.googleCalendarConfigUpdatedAt cfg < Cal.googleCalendarConfigCreatedAt cfg)
    invalidStoredCalendarTimestamps
  when
    ( maybe False
        (< Cal.googleCalendarConfigCreatedAt cfg)
        (Cal.googleCalendarConfigSyncedAt cfg)
    )
    invalidStoredCalendarTimestamps
  when
    ( maybe False
        (< Cal.googleCalendarConfigCreatedAt cfg)
        (Cal.googleCalendarConfigTokenExpiresAt cfg)
    )
    invalidStoredCalendarTimestamps
  case Cal.googleCalendarConfigOwnerId cfg of
    Just ownerId | fromSqlKey ownerId <= 0 -> invalidStoredCalendarOwnerId
    _ -> pure ()
  calendarIdVal <-
    case CalAPI.normalizeCalendarId storedCalendarId of
      Right val -> Right val
      Left _ -> invalidStoredCalendarId
  unless (calendarIdVal == storedCalendarId) invalidStoredCalendarId
  accessTokenVal <-
    traverse
      (validateStoredGoogleCalendarOAuthToken "access token")
      (Cal.googleCalendarConfigAccessToken cfg)
  refreshTokenVal <-
    traverse
      validateStoredGoogleCalendarRefreshToken
      (Cal.googleCalendarConfigRefreshToken cfg)
  tokenTypeVal <-
    validateStoredGoogleCalendarTokenType (Cal.googleCalendarConfigTokenType cfg)
  when
    ( isNothing accessTokenVal
        && (isJust refreshTokenVal
              || isJust tokenTypeVal
              || isJust (Cal.googleCalendarConfigTokenExpiresAt cfg)
           )
    )
    invalidStoredCalendarOAuthState
  syncCursorVal <- validateGoogleCalendarSyncCursor (Cal.googleCalendarConfigSyncCursor cfg)
  Right
    ( Entity cfgId
        cfg
          { Cal.googleCalendarConfigAccessToken = accessTokenVal
          , Cal.googleCalendarConfigRefreshToken = refreshTokenVal
          , Cal.googleCalendarConfigTokenType = tokenTypeVal
          , Cal.googleCalendarConfigSyncCursor = syncCursorVal
          }
    )
  where
    storedCalendarId = Cal.googleCalendarConfigCalendarId cfg
    invalidStoredCalendarConfigId =
      Left err500
        { errBody = "Stored Google Calendar config id is invalid"
        }
    invalidStoredCalendarId =
      Left err500
        { errBody = "Stored Google Calendar config calendarId is invalid"
        }
    invalidStoredCalendarOwnerId =
      Left err500
        { errBody = "Stored Google Calendar config ownerId is invalid"
        }
    invalidStoredCalendarOAuthState =
      Left err500
        { errBody = "Stored Google Calendar OAuth state is invalid"
        }
    invalidStoredCalendarTimestamps =
      Left err500
        { errBody = "Stored Google Calendar config timestamps are invalid"
        }

validateStoredGoogleCalendarTokenType :: Maybe Text -> Either ServerError (Maybe Text)
validateStoredGoogleCalendarTokenType Nothing = Right Nothing
validateStoredGoogleCalendarTokenType (Just rawTokenType) = do
  tokenTypeVal <- validateStoredGoogleCalendarOAuthToken "token_type" rawTokenType
  if T.toLower tokenTypeVal == "bearer"
    then Right (Just "Bearer")
    else
      Left err500
        { errBody = "Stored Google Calendar token_type is invalid"
        }

encodeGooglePathSegment :: Text -> Text
encodeGooglePathSegment =
  TE.decodeUtf8 . urlEncode True . TE.encodeUtf8

productionCourseSlug :: AppConfig -> Text
productionCourseSlug = courseSlugFallback
productionCoursePrice :: Double
productionCoursePrice = fromIntegral ProductionCourse.productionCoursePriceCents / 100
productionCourseCapacity :: Int
productionCourseCapacity = ProductionCourse.productionCourseCapacity

-- Backward-compatible helpers used by cron jobs
buildLandingUrl :: AppConfig -> Text
buildLandingUrl cfg = buildLandingUrlFor cfg (productionCourseSlug cfg)

courseMetadataFor :: AppConfig -> Maybe Text -> Text -> Maybe CourseMetadata
courseMetadataFor cfg mWaContact slugVal =
  let fallbackSlug = productionCourseSlug cfg
      startDate = firstSaturdayOfConfiguredProductionSlug fallbackSlug
  in if normalizeSlug slugVal == fallbackSlug
       then Just (productionCourseMetadataForStartDate cfg mWaContact fallbackSlug startDate Nothing)
       else Nothing

courseMetaSlug :: CourseMetadata -> Text
courseMetaSlug Courses.CourseMetadata{Courses.slug = value} = value

courseMetaTitle :: CourseMetadata -> Text
courseMetaTitle Courses.CourseMetadata{Courses.title = value} = value

courseMetaSubtitle :: CourseMetadata -> Text
courseMetaSubtitle Courses.CourseMetadata{Courses.subtitle = value} = value

courseMetaFormat :: CourseMetadata -> Text
courseMetaFormat Courses.CourseMetadata{Courses.format = value} = value

courseMetaDuration :: CourseMetadata -> Text
courseMetaDuration Courses.CourseMetadata{Courses.duration = value} = value

courseMetaPrice :: CourseMetadata -> Double
courseMetaPrice Courses.CourseMetadata{Courses.price = value} = value

courseMetaCurrency :: CourseMetadata -> Text
courseMetaCurrency Courses.CourseMetadata{Courses.currency = value} = value

courseMetaCapacity :: CourseMetadata -> Int
courseMetaCapacity Courses.CourseMetadata{Courses.capacity = value} = value

courseMetaSessionStartHour :: CourseMetadata -> Int
courseMetaSessionStartHour Courses.CourseMetadata{Courses.sessionStartHour = value} = value

courseMetaSessionDurationHours :: CourseMetadata -> Int
courseMetaSessionDurationHours Courses.CourseMetadata{Courses.sessionDurationHours = value} = value

courseMetaLocationLabel :: CourseMetadata -> Text
courseMetaLocationLabel Courses.CourseMetadata{Courses.locationLabel = value} = value

courseMetaLocationMapUrl :: CourseMetadata -> Text
courseMetaLocationMapUrl Courses.CourseMetadata{Courses.locationMapUrl = value} = value

courseMetaDaws :: CourseMetadata -> [Text]
courseMetaDaws Courses.CourseMetadata{Courses.daws = value} = value

courseMetaIncludes :: CourseMetadata -> [Text]
courseMetaIncludes Courses.CourseMetadata{Courses.includes = value} = value

courseMetaInstructorName :: CourseMetadata -> Maybe Text
courseMetaInstructorName Courses.CourseMetadata{Courses.instructorName = value} = value

courseMetaInstructorBio :: CourseMetadata -> Maybe Text
courseMetaInstructorBio Courses.CourseMetadata{Courses.instructorBio = value} = value

courseMetaInstructorAvatarUrl :: CourseMetadata -> Maybe Text
courseMetaInstructorAvatarUrl Courses.CourseMetadata{Courses.instructorAvatarUrl = value} = value

courseMetaSessions :: CourseMetadata -> [CourseSession]
courseMetaSessions Courses.CourseMetadata{Courses.sessions = value} = value

courseMetaSyllabus :: CourseMetadata -> [SyllabusItem]
courseMetaSyllabus Courses.CourseMetadata{Courses.syllabus = value} = value

courseMetaWhatsappCtaUrl :: CourseMetadata -> Text
courseMetaWhatsappCtaUrl Courses.CourseMetadata{Courses.whatsappCtaUrl = value} = value

courseMetaLandingUrl :: CourseMetadata -> Text
courseMetaLandingUrl Courses.CourseMetadata{Courses.landingUrl = value} = value

courseSessionLabel :: CourseSession -> Text
courseSessionLabel Courses.CourseSession{Courses.label = value} = value

courseSessionDate :: CourseSession -> Day
courseSessionDate Courses.CourseSession{Courses.date = value} = value

syllabusItemTitle :: SyllabusItem -> Text
syllabusItemTitle Courses.SyllabusItem{Courses.title = value} = value

syllabusItemTopics :: SyllabusItem -> [Text]
syllabusItemTopics Courses.SyllabusItem{Courses.topics = value} = value

productionCourseMetadataForStartDate
  :: AppConfig
  -> Maybe Text
  -> Text
  -> Day
  -> Maybe CourseMetadata
  -> CourseMetadata
productionCourseMetadataForStartDate cfg mWaContact slugVal startDate mTemplate =
  let landing = buildLandingUrlFor cfg slugVal
      templateText field defaultValue =
        case mTemplate of
          Just meta ->
            let value = field meta
            in if T.null (T.strip value) then defaultValue else value
          Nothing -> defaultValue
      templateList field defaultValue =
        case mTemplate of
          Just meta ->
            let values = filter (not . T.null . T.strip) (field meta)
            in if null values then defaultValue else values
          Nothing -> defaultValue
      templateMaybe field defaultValue =
        case cleanOptional (mTemplate >>= field) of
          Just value -> Just value
          Nothing -> defaultValue
      templateInt field defaultValue =
        case mTemplate of
          Just meta | field meta > 0 -> field meta
          _ -> defaultValue
      templatePrice =
        case mTemplate of
          Just meta | courseMetaPrice meta >= 0 -> courseMetaPrice meta
          _ -> productionCoursePrice
      sessions =
        [ CourseSession labelTxt dayVal
        | (labelTxt, dayVal) <- ProductionCourse.productionCourseSessions startDate
        ]
      syllabus =
        [ SyllabusItem titleTxt topics
        | (titleTxt, topics) <- ProductionCourse.productionCourseSyllabus
        ]
      titleVal = templateText courseMetaTitle ProductionCourse.productionCourseTitle
  in CourseMetadata
      { slug = slugVal
      , title = titleVal
      , subtitle = ProductionCourse.productionCourseSubtitleForStartDate startDate
      , format = templateText courseMetaFormat ProductionCourse.productionCourseFormat
      , duration = templateText courseMetaDuration ProductionCourse.productionCourseDuration
      , price = templatePrice
      , currency = templateText courseMetaCurrency (defaultCurrency cfg)
      , capacity = templateInt courseMetaCapacity ProductionCourse.productionCourseCapacity
      , remaining = templateInt courseMetaCapacity ProductionCourse.productionCourseCapacity
      , sessionStartHour = templateInt courseMetaSessionStartHour ProductionCourse.productionCourseSessionStartHour
      , sessionDurationHours = templateInt courseMetaSessionDurationHours ProductionCourse.productionCourseSessionDurationHours
      , locationLabel = templateText courseMetaLocationLabel ProductionCourse.productionCourseLocationLabel
      , locationMapUrl = templateText courseMetaLocationMapUrl (courseMapFallback cfg)
      , daws = templateList courseMetaDaws ProductionCourse.productionCourseDaws
      , includes = templateList courseMetaIncludes ProductionCourse.productionCourseIncludes
      , instructorName = templateMaybe courseMetaInstructorName (Just ProductionCourse.productionCourseInstructorName)
      , instructorBio = templateMaybe courseMetaInstructorBio (Just ProductionCourse.productionCourseInstructorBio)
      , instructorAvatarUrl = templateMaybe courseMetaInstructorAvatarUrl (Just (courseInstructorAvatarFallback cfg))
      , sessions = sessions
      , syllabus = syllabus
      , whatsappCtaUrl = buildWhatsappCtaFor mWaContact titleVal landing
      , landingUrl = landing
      , checkoutTerms = Nothing
      }

firstSaturdayOfConfiguredProductionSlug :: Text -> Day
firstSaturdayOfConfiguredProductionSlug slugVal =
  let fallback = fromGregorian 2026 6 6
      parts = T.splitOn "-" slugVal
      mYear = readMaybe . T.unpack =<< listToMaybe (reverse parts)
      mMonth = listToMaybe (mapMaybe monthSlugToNumber parts)
  in case (mYear, mMonth) of
       (Just y, Just m) -> nextSaturdayOnOrAfterDay (fromGregorian y m 1)
       _ -> fallback

monthSlugToNumber :: Text -> Maybe Int
monthSlugToNumber "ene" = Just 1
monthSlugToNumber "feb" = Just 2
monthSlugToNumber "mar" = Just 3
monthSlugToNumber "abr" = Just 4
monthSlugToNumber "may" = Just 5
monthSlugToNumber "jun" = Just 6
monthSlugToNumber "jul" = Just 7
monthSlugToNumber "ago" = Just 8
monthSlugToNumber "sep" = Just 9
monthSlugToNumber "oct" = Just 10
monthSlugToNumber "nov" = Just 11
monthSlugToNumber "dic" = Just 12
monthSlugToNumber _ = Nothing

nextSaturdayOnOrAfterDay :: Day -> Day
nextSaturdayOnOrAfterDay day =
  fromMaybe day . listToMaybe $
    [ candidate
    | offset <- [0..6]
    , let candidate = addDays offset day
    , formatTime defaultTimeLocale "%u" candidate == "6"
    ]

ensureCurrentProductionCourseMetadata
  :: AppConfig
  -> WhatsAppEnv
  -> Day
  -> Text
  -> AppM (Maybe CourseMetadata)
ensureCurrentProductionCourseMetadata cfg waEnv today requestedSlug
  | not (isProductionCoursePublicSlug cfg requestedSlug) = pure Nothing
  | otherwise = do
      productionMetas <- loadProductionCourseMetadatasFromDB cfg waEnv
      let hasRequiredLead meta =
            CoursePublic.hasRequiredProductionLead today (firstCourseSessionDate meta)
          mRequestedValid =
            find
              (\meta -> normalizeSlug (courseMetaSlug meta) == requestedSlug && hasRequiredLead meta)
              productionMetas
          mEarliestValid =
            listToMaybe
              (sortOn
                (fromMaybe (fromGregorian 9999 12 31) . firstCourseSessionDate)
                (filter hasRequiredLead productionMetas))
      case mRequestedValid <|> mEarliestValid of
        Just meta -> pure (Just meta)
        Nothing -> do
          meta <- createProductionCourseForStartDate
            cfg
            waEnv
            (ProductionCourse.nextProductionCourseStartDate today)
            productionMetas
          pure (Just meta)

isProductionCoursePublicSlug :: AppConfig -> Text -> Bool
isProductionCoursePublicSlug cfg =
  CoursePublic.isProductionCoursePublicSlug (productionCourseSlug cfg)

firstCourseSessionDate :: CourseMetadata -> Maybe Day
firstCourseSessionDate meta =
  listToMaybe (sort [courseSessionDate session | session <- courseMetaSessions meta])

loadProductionCourseMetadatasFromDB :: AppConfig -> WhatsAppEnv -> AppM [CourseMetadata]
loadProductionCourseMetadatasFromDB cfg waEnv =
  runDB $ do
    courses <- selectList [] [Desc Trials.CourseUpdatedAt]
    fmap catMaybes $ forM courses $ \(Entity cid course) -> do
      if "produccion-musical-" `T.isPrefixOf` normalizeSlug (Trials.courseSlug course)
        then do
          sessions <- selectList
            [Trials.CourseSessionModelCourseId ==. cid]
            [Asc Trials.CourseSessionModelOrder, Asc Trials.CourseSessionModelDate]
          syllabus <- selectList
            [Trials.CourseSyllabusItemCourseId ==. cid]
            [Asc Trials.CourseSyllabusItemOrder, Asc Trials.CourseSyllabusItemId]
          pure (Just (toCourseMetadata cfg waEnv course sessions syllabus))
        else pure Nothing

createProductionCourseForStartDate
  :: AppConfig
  -> WhatsAppEnv
  -> Day
  -> [CourseMetadata]
  -> AppM CourseMetadata
createProductionCourseForStartDate cfg waEnv startDate productionMetas =
  case find ((== Just startDate) . firstCourseSessionDate) productionMetas of
    Just meta -> pure meta
    Nothing -> do
      now <- liftIO getCurrentTime
      slugVal <- runDB (firstAvailableProductionCourseSlug startDate)
      let mTemplate =
            listToMaybe productionMetas
              <|> courseMetadataFor cfg (waContactNumber waEnv) (productionCourseSlug cfg)
          meta = productionCourseMetadataForStartDate cfg (waContactNumber waEnv) slugVal startDate mTemplate
      runDB (insertProductionCourseMetadata cfg now meta)
      fromMaybe meta <$> loadCourseMetadataFromDB cfg waEnv slugVal

firstAvailableProductionCourseSlug :: Day -> SqlPersistT IO Text
firstAvailableProductionCourseSlug startDate =
  firstAvailable
    (baseSlug : daySlug : [daySlug <> "-" <> T.pack (show n) | n <- [2 :: Int ..]])
  where
    baseSlug = ProductionCourse.productionCourseSlugForStartDate startDate
    daySlug = ProductionCourse.productionCourseDaySlugForStartDate startDate

    firstAvailable [] = pure baseSlug
    firstAvailable (candidate:rest) = do
      mExisting <- getBy (Trials.UniqueCourseSlug candidate)
      case mExisting of
        Nothing -> pure candidate
        Just _ -> firstAvailable rest

insertProductionCourseMetadata :: AppConfig -> UTCTime -> CourseMetadata -> SqlPersistT IO ()
insertProductionCourseMetadata cfg now meta = do
  let cleanTextList values =
        let cleaned = filter (not . T.null) (map T.strip values)
        in if null cleaned then Nothing else Just cleaned
      coursePriceCents = max 0 (round (courseMetaPrice meta * 100) :: Int)
      textOr defaultValue value =
        let cleaned = T.strip value
        in if T.null cleaned then defaultValue else cleaned
  courseId <- insert Trials.Course
    { Trials.courseSlug = normalizeSlug (courseMetaSlug meta)
    , Trials.courseTitle = textOr ProductionCourse.productionCourseTitle (courseMetaTitle meta)
    , Trials.courseSubtitle = cleanOptional (Just (courseMetaSubtitle meta))
    , Trials.courseFormat = cleanOptional (Just (courseMetaFormat meta))
    , Trials.courseDuration = cleanOptional (Just (courseMetaDuration meta))
    , Trials.coursePriceCents = coursePriceCents
    , Trials.courseCurrency = textOr (defaultCurrency cfg) (courseMetaCurrency meta)
    , Trials.courseCapacity = max 1 (courseMetaCapacity meta)
    , Trials.courseSessionStartHour = Just (courseMetaSessionStartHour meta)
    , Trials.courseSessionDurationHours = Just (courseMetaSessionDurationHours meta)
    , Trials.courseLocationLabel = cleanOptional (Just (courseMetaLocationLabel meta))
    , Trials.courseLocationMapUrl = cleanOptional (Just (courseMetaLocationMapUrl meta))
    , Trials.courseWhatsappCtaUrl = cleanOptional (Just (courseMetaWhatsappCtaUrl meta))
    , Trials.courseLandingUrl = cleanOptional (Just (courseMetaLandingUrl meta))
    , Trials.courseDaws = Nothing
    , Trials.courseIncludes = Nothing
    , Trials.courseInstructorName = cleanOptional (courseMetaInstructorName meta)
    , Trials.courseInstructorBio = cleanOptional (courseMetaInstructorBio meta)
    , Trials.courseInstructorAvatarUrl = cleanOptional (courseMetaInstructorAvatarUrl meta)
    , Trials.courseStripeSubscriptionPriceId = Nothing
    , Trials.courseCreatedAt = now
    , Trials.courseUpdatedAt = now
    }
  persistCourseTextArrayField courseId "daws" (cleanTextList (courseMetaDaws meta))
  persistCourseTextArrayField courseId "includes" (cleanTextList (courseMetaIncludes meta))
  for_ (zip [1 :: Int ..] (courseMetaSessions meta)) $ \(idx, session) ->
    insert_ Trials.CourseSessionModel
      { Trials.courseSessionModelCourseId = courseId
      , Trials.courseSessionModelLabel = courseSessionLabel session
      , Trials.courseSessionModelDate = courseSessionDate session
      , Trials.courseSessionModelOrder = Just idx
      }
  for_ (zip [1 :: Int ..] (courseMetaSyllabus meta)) $ \(idx, item) ->
    insert_ Trials.CourseSyllabusItem
      { Trials.courseSyllabusItemCourseId = courseId
      , Trials.courseSyllabusItemTitle = syllabusItemTitle item
      , Trials.courseSyllabusItemTopics = syllabusItemTopics item
      , Trials.courseSyllabusItemOrder = Just idx
      }

persistCourseTextArrayField :: Trials.CourseId -> Text -> Maybe [Text] -> SqlPersistT IO ()
persistCourseTextArrayField courseId columnName Nothing =
  rawExecute
    ("UPDATE course SET " <> columnName <> " = NULL WHERE id = ?")
    [PersistInt64 (fromSqlKey courseId)]
persistCourseTextArrayField courseId columnName (Just values) =
  rawExecute
    ("UPDATE course SET " <> columnName <> " = ARRAY(SELECT jsonb_array_elements_text(?::jsonb)) WHERE id = ?")
    [ PersistText (TE.decodeUtf8 (BL.toStrict (encode values)))
    , PersistInt64 (fromSqlKey courseId)
    ]

loadCourseMetadata :: Text -> AppM CourseMetadata
loadCourseMetadata rawSlug = do
  normalized <- either throwError pure (validateCourseSlug rawSlug)
  Env{..} <- ask
  waEnv <- liftIO loadWhatsAppEnv
  now <- liftIO getCurrentTime
  let today = utctDay now
  mProductionMeta <- ensureCurrentProductionCourseMetadata envConfig waEnv today normalized
  mDbMeta <- case mProductionMeta of
    Just _ -> pure Nothing
    Nothing -> loadCourseMetadataFromDB envConfig waEnv normalized
  let fallbackMeta = courseMetadataFor envConfig (waContactNumber waEnv) normalized
  baseMeta <- maybe (maybe (throwNotFound "Curso no encontrado") pure fallbackMeta) pure (mProductionMeta <|> mDbMeta)
  let Courses.CourseMetadata{ Courses.capacity = baseCapacity } = baseMeta
      countSlug = normalizeSlug (courseMetaSlug baseMeta)
  _ <- runDB (rawSql "SELECT course_checkout_expire_holds(?)"
    [PersistUTCTime now] :: SqlPersistT IO [Single Int])
  occupiedRows <- runDB (rawSql
    "SELECT (\
    \ SELECT count(*) FROM course_registration_checkout_runtime runtime\
    \ JOIN course course ON course.id = runtime.course_id\
    \ WHERE course.slug = ? AND (\
    \   runtime.enrollment_status IN ('enrolled','transfer_requested','completed')\
    \   OR (runtime.enrollment_status = 'seat_held' AND runtime.hold_expires_at > ?)\
    \ )) + (\
    \ SELECT count(*) FROM course_registration registration\
    \ WHERE registration.course_slug = ? AND registration.status = 'paid'\
    \ AND NOT EXISTS (SELECT 1 FROM course_registration_checkout_runtime runtime\
    \   WHERE runtime.registration_id = registration.id))"
    [PersistText countSlug, PersistUTCTime now, PersistText countSlug]
    :: SqlPersistT IO [Single Int64])
  let occupied = case occupiedRows of
        [Single value] -> value
        _ -> fromIntegral baseCapacity
      remainingSeats = max 0 (baseCapacity - fromIntegral occupied)
  pure baseMeta { Courses.remaining = remainingSeats }

loadCourseMetadataFromDB :: AppConfig -> WhatsAppEnv -> Text -> AppM (Maybe CourseMetadata)
loadCourseMetadataFromDB cfg waEnv slugVal = do
  runDB $ do
    mCourse <- getBy (Trials.UniqueCourseSlug slugVal)
    case mCourse of
      Nothing -> pure Nothing
      Just (Entity cid course) -> do
        sessions <- selectList
          [Trials.CourseSessionModelCourseId ==. cid]
          [Asc Trials.CourseSessionModelOrder, Asc Trials.CourseSessionModelDate]
        syllabus <- selectList
          [Trials.CourseSyllabusItemCourseId ==. cid]
          [Asc Trials.CourseSyllabusItemOrder, Asc Trials.CourseSyllabusItemId]
        pure $ Just (toCourseMetadata cfg waEnv course sessions syllabus)

toCourseMetadata
  :: AppConfig
  -> WhatsAppEnv
  -> Trials.Course
  -> [Entity Trials.CourseSessionModel]
  -> [Entity Trials.CourseSyllabusItem]
  -> CourseMetadata
toCourseMetadata cfg waEnv course sessions syllabus =
  let slugVal = Trials.courseSlug course
      landingUrlVal =
        fromMaybe
          (buildLandingUrlFor cfg slugVal)
          (sanitizeStoredCoursePublicUrl "landingUrl" (Trials.courseLandingUrl course))
      whatsappUrl =
        fromMaybe
          (buildWhatsappCtaFor (waContactNumber waEnv) (Trials.courseTitle course) landingUrlVal)
          (sanitizeStoredCoursePublicUrl "whatsappCtaUrl" (Trials.courseWhatsappCtaUrl course))
      dawsList = filter (not . T.null) (maybe [] (map T.strip) (Trials.courseDaws course))
      includesList = filter (not . T.null) (maybe [] (map T.strip) (Trials.courseIncludes course))
      instructorNameVal = cleanOptional (Trials.courseInstructorName course)
      instructorBioVal = cleanOptional (Trials.courseInstructorBio course)
      instructorAvatarVal =
        sanitizeStoredCoursePublicUrl "instructorAvatarUrl" (Trials.courseInstructorAvatarUrl course)
      toSession (Entity _ s) =
        CourseSession
          { label = Trials.courseSessionModelLabel s
          , date = Trials.courseSessionModelDate s
          }
      toSyllabus (Entity _ s) =
        SyllabusItem
          { title = Trials.courseSyllabusItemTitle s
          , topics = filter (not . T.null . T.strip) (Trials.courseSyllabusItemTopics s)
          }
  in CourseMetadata
      { slug = slugVal
      , title = Trials.courseTitle course
      , subtitle = fromMaybe "" (Trials.courseSubtitle course)
      , format = fromMaybe "" (Trials.courseFormat course)
      , duration = fromMaybe "" (Trials.courseDuration course)
      , price = fromIntegral (Trials.coursePriceCents course) / 100
      , currency = Trials.courseCurrency course
      , capacity = Trials.courseCapacity course
      , remaining = Trials.courseCapacity course
      , sessionStartHour = fromMaybe 0 (Trials.courseSessionStartHour course)
      , sessionDurationHours = fromMaybe 0 (Trials.courseSessionDurationHours course)
      , locationLabel = fromMaybe "" (Trials.courseLocationLabel course)
      , locationMapUrl =
          fromMaybe
            (courseMapFallback cfg)
            (sanitizeStoredCoursePublicUrl "locationMapUrl" (Trials.courseLocationMapUrl course))
      , daws = dawsList
      , includes = includesList
      , instructorName = instructorNameVal
      , instructorBio = instructorBioVal
      , instructorAvatarUrl = instructorAvatarVal
      , sessions = map toSession sessions
      , syllabus = map toSyllabus syllabus
      , whatsappCtaUrl = whatsappUrl
      , landingUrl = landingUrlVal
      , checkoutTerms = Nothing
      }

buildLandingUrlFor :: AppConfig -> Text -> Text
buildLandingUrlFor cfg slugVal =
  let base = resolveConfiguredAppBase cfg
  in base <> "/curso/" <> slugVal

buildWhatsappCtaFor :: Maybe Text -> Text -> Text -> Text
buildWhatsappCtaFor mNumber courseTitle landingUrl =
  let msg = "INSCRIBIRME " <> courseTitle <> " " <> landingUrl
      encoded = TE.decodeUtf8 (urlEncode True (TE.encodeUtf8 msg))
  in case resolveWhatsappCtaNumber mNumber of
       Just num -> "https://wa.me/" <> num <> "?text=" <> encoded
       Nothing  -> "https://wa.me/?text=" <> encoded

resolveWhatsappCtaNumber :: Maybe Text -> Maybe Text
resolveWhatsappCtaNumber mNumber =
  case mNumber >>= normalizeCourseRegistrationPhoneInput of
    Just phone ->
      let digitsOnly = T.filter isAsciiPhoneDigit phone
      in if isInternationalWhatsappCtaNumber digitsOnly
           then Just digitsOnly
           else Nothing
    Nothing -> Nothing

isInternationalWhatsappCtaNumber :: Text -> Bool
isInternationalWhatsappCtaNumber = CoursePublic.isInternationalWhatsappCtaNumber

saveCourse :: CourseUpsert -> AppM CourseMetadata
saveCourse Courses.CourseUpsert{..} = do
  now <- liftIO getCurrentTime
  Env{..} <- ask
  waEnv <- liftIO loadWhatsAppEnv
  slugVal <- either throwError pure (validateCourseSlug slug)
  titleClean <- either throwError pure (validateRequiredCourseTextField "title" 160 title)
  capacityClean <- either throwError pure (validateCoursePositiveField "capacity" capacity)
  priceCentsClean <- either throwError pure (validateCourseNonNegativeField "priceCents" priceCents)
  startHourClean <- either throwError pure (validateOptionalCourseSessionStartHour sessionStartHour)
  durationHoursClean <- either throwError pure (validateOptionalCourseSessionDurationHours sessionDurationHours)
  either throwError pure (validateCourseSessionScheduleWindow startHourClean durationHoursClean)
  sessionsClean <- either throwError pure (validateCourseSessionInputs sessions)
  syllabusClean <- either throwError pure (validateCourseSyllabusInputs syllabus)
  dawsClean <- either throwError pure (validateCourseTextListField "daws" 160 daws)
  includesClean <- either throwError pure (validateCourseTextListField "includes" 160 includes)
  locationMapUrlClean <- either throwError pure (validateCoursePublicUrlField "locationMapUrl" locationMapUrl)
  landingUrlClean <- either throwError pure (validateCoursePublicUrlField "landingUrl" landingUrl)
  whatsappClean <- either throwError pure (validateCoursePublicUrlField "whatsappCtaUrl" whatsappCtaUrl)
  instructorAvatarClean <- either throwError pure (validateCoursePublicUrlField "instructorAvatarUrl" instructorAvatarUrl)
  currencyClean <- either throwError pure (validateCourseCurrency currency)
  unless (currencyClean `elem` supportedCurrencies envConfig) $
    throwError err400 { errBody = "Currency is not enabled by SUPPORTED_CURRENCIES" }
  let
      subtitleClean = cleanOptional subtitle
      formatClean = cleanOptional format
      durationClean = cleanOptional duration
      locationLabelClean = cleanOptional locationLabel
      landingResolved = fromMaybe (buildLandingUrlFor envConfig slugVal) landingUrlClean
      whatsappResolved = fromMaybe (buildWhatsappCtaFor (waContactNumber waEnv) titleClean landingResolved) whatsappClean
      instructorNameClean = cleanOptional instructorName
      instructorBioClean = cleanOptional instructorBio
      withOrder fallbackIdx mOrder = fromMaybe fallbackIdx mOrder
      -- Persistent is misencoding text[] here, so store course arrays through SQL.
      persistTextArrayField courseId columnName Nothing =
        rawExecute
          ("UPDATE course SET " <> columnName <> " = NULL WHERE id = ?")
          [PersistInt64 (fromSqlKey courseId)]
      persistTextArrayField courseId columnName (Just values) =
        rawExecute
          ("UPDATE course SET " <> columnName <> " = ARRAY(SELECT jsonb_array_elements_text(?::jsonb)) WHERE id = ?")
          [ PersistText (TE.decodeUtf8 (BL.toStrict (encode values)))
          , PersistInt64 (fromSqlKey courseId)
          ]
  runDB $ do
    mExisting <- getBy (Trials.UniqueCourseSlug slugVal)
    courseId <- case mExisting of
      Nothing -> insert Trials.Course
        { Trials.courseSlug = slugVal
        , Trials.courseTitle = titleClean
        , Trials.courseSubtitle = subtitleClean
        , Trials.courseFormat = formatClean
        , Trials.courseDuration = durationClean
        , Trials.coursePriceCents = priceCentsClean
        , Trials.courseCurrency = currencyClean
        , Trials.courseCapacity = capacityClean
        , Trials.courseSessionStartHour = startHourClean
        , Trials.courseSessionDurationHours = durationHoursClean
        , Trials.courseLocationLabel = locationLabelClean
        , Trials.courseLocationMapUrl = locationMapUrlClean
        , Trials.courseWhatsappCtaUrl = Just whatsappResolved
        , Trials.courseLandingUrl = Just landingResolved
        , Trials.courseDaws = Nothing
        , Trials.courseIncludes = Nothing
        , Trials.courseInstructorName = instructorNameClean
        , Trials.courseInstructorBio = instructorBioClean
        , Trials.courseInstructorAvatarUrl = instructorAvatarClean
        , Trials.courseStripeSubscriptionPriceId = Nothing
        , Trials.courseCreatedAt = now
        , Trials.courseUpdatedAt = now
        }
      Just (Entity cid _) -> do
        update cid
          [ Trials.CourseSlug =. slugVal
          , Trials.CourseTitle =. titleClean
          , Trials.CourseSubtitle =. subtitleClean
          , Trials.CourseFormat =. formatClean
          , Trials.CourseDuration =. durationClean
          , Trials.CoursePriceCents =. priceCentsClean
          , Trials.CourseCurrency =. currencyClean
          , Trials.CourseCapacity =. capacityClean
          , Trials.CourseSessionStartHour =. startHourClean
          , Trials.CourseSessionDurationHours =. durationHoursClean
          , Trials.CourseLocationLabel =. locationLabelClean
          , Trials.CourseLocationMapUrl =. locationMapUrlClean
          , Trials.CourseWhatsappCtaUrl =. Just whatsappResolved
          , Trials.CourseLandingUrl =. Just landingResolved
          , Trials.CourseDaws =. Nothing
          , Trials.CourseIncludes =. Nothing
          , Trials.CourseInstructorName =. instructorNameClean
          , Trials.CourseInstructorBio =. instructorBioClean
          , Trials.CourseInstructorAvatarUrl =. instructorAvatarClean
          , Trials.CourseUpdatedAt =. now
          ]
        pure cid

    persistTextArrayField courseId "daws" dawsClean
    persistTextArrayField courseId "includes" includesClean

    deleteWhere [Trials.CourseSessionModelCourseId ==. courseId]
    deleteWhere [Trials.CourseSyllabusItemCourseId ==. courseId]

    let sessionPayload = zip [1..] sessionsClean
    for_ sessionPayload $ \(idx, CourseSessionIn{..}) -> do
      let ordVal = withOrder idx order
      insert_ Trials.CourseSessionModel
        { Trials.courseSessionModelCourseId = courseId
        , Trials.courseSessionModelLabel = label
        , Trials.courseSessionModelDate = date
        , Trials.courseSessionModelOrder = Just ordVal
        }

    let syllabusPayload = zip [1..] syllabusClean
    for_ syllabusPayload $ \(idx, CourseSyllabusIn{title = syllabusTitle, topics = syllabusTopics, order = syllabusOrder}) -> do
      let ordVal = withOrder idx syllabusOrder
      insert_ Trials.CourseSyllabusItem
        { Trials.courseSyllabusItemCourseId = courseId
        , Trials.courseSyllabusItemTitle = syllabusTitle
        , Trials.courseSyllabusItemTopics = syllabusTopics
        , Trials.courseSyllabusItemOrder = Just ordVal
        }
  loadCourseMetadata slugVal

listCourseCohorts :: AppM [DTO.CourseCohortOptionDTO]
listCourseCohorts = do
  courses <- runDB $ selectList [] [Desc Trials.CourseUpdatedAt]
  registrationSlugs <- runDB $
    rawSql
      "SELECT DISTINCT course_slug FROM course_registration WHERE course_slug IS NOT NULL AND course_slug <> '' ORDER BY course_slug"
      []
  let fromCourse (Entity _ course) =
        DTO.CourseCohortOptionDTO
          { DTO.ccSlug = Trials.courseSlug course
          , DTO.ccTitle = Just (Trials.courseTitle course)
          }
      courseOptions = map fromCourse courses
      knownSlugs = Set.fromList (map DTO.ccSlug courseOptions)
      extraOptions =
        [ DTO.CourseCohortOptionDTO
            { DTO.ccSlug = slugVal
            , DTO.ccTitle = Nothing
            }
        | Single slugVal <- registrationSlugs
        , not (Set.member slugVal knownSlugs)
        ]
  pure (courseOptions <> extraOptions)

listCourseRegistrations
  :: Maybe Text
  -> Maybe Text
  -> Maybe Int
  -> AppM [DTO.CourseRegistrationDTO]
listCourseRegistrations mSlug mStatus mLimit = do
  normalizedSlug <- either throwError pure (validateOptionalCourseSlugFilter mSlug)
  normalizedStatus <- either throwError pure (validateOptionalCourseRegistrationStatusFilter mStatus)
  limit <- either throwError pure (validateCourseRegistrationListLimit 200 mLimit)
  let filters = catMaybes
        [ (ME.CourseRegistrationCourseSlug ==.) <$> normalizedSlug
        , (ME.CourseRegistrationStatus ==.) <$> normalizedStatus
        ]
  rowsWithCounts <- runDB $ do
    rows <- selectList filters [Desc ME.CourseRegistrationCreatedAt, LimitTo limit]
    receiptCounts <- loadCourseRegistrationReceiptCounts rows
    followUpCounts <- loadCourseRegistrationFollowUpCounts rows
    pure
      [ ( row
        , Map.findWithDefault 0 (entityKey row) receiptCounts
        , Map.findWithDefault 0 (entityKey row) followUpCounts
        )
      | row <- rows
      ]
  pure
    [ toCourseRegistrationDTOWithCounts receiptCount followUpCount row
    | (row, receiptCount, followUpCount) <- rowsWithCounts
    ]

fetchCourseRegistrationEntity :: Text -> Int64 -> AppM (Entity ME.CourseRegistration)
fetchCourseRegistrationEntity rawSlug regId = do
  regIdValid <- either throwError pure (validateCourseRegistrationId regId)
  slugVal <- either throwError pure (validateCourseSlug rawSlug)
  let key = toSqlKey regIdValid
  mRow <- runDB $ getEntity key
  case mRow of
    Nothing -> throwNotFound "Registro no encontrado"
    Just ent@(Entity _ reg)
      | ME.courseRegistrationCourseSlug reg /= slugVal -> throwNotFound "Registro no encontrado"
      | otherwise -> pure ent

fetchCourseRegistration :: Text -> Int64 -> AppM DTO.CourseRegistrationDTO
fetchCourseRegistration rawSlug regId = do
  ent <- fetchCourseRegistrationEntity rawSlug regId
  (receiptCount, followUpCount) <- runDB $ loadCourseRegistrationCounts (entityKey ent)
  pure (toCourseRegistrationDTOWithCounts receiptCount followUpCount ent)

requireAutomaticSecurityPolicyDb
  :: Text
  -> PartyId
  -> Bool
  -> Maybe PartyId
  -> Text
  -> Text
  -> UTCTime
  -> SqlPersistT IO ()
requireAutomaticSecurityPolicyDb policyCode partyKey verifiedEmail actorId sourcePlatform correlationId now = do
  result <- applySecurityRoleAssignmentPolicy
    policyCode partyKey verifiedEmail actorId sourcePlatform correlationId now
  case result of
    Right _ -> pure ()
    Left message ->
      liftIO $ throwIO err503
        { errBody = BL.fromStrict (TE.encodeUtf8 message)
        }

ensureCourseRegistrationPartyRoles :: PartyId -> UTCTime -> SqlPersistT IO ()
ensureCourseRegistrationPartyRoles pid now =
  requireAutomaticSecurityPolicyDb
    "course.registration.student"
    pid
    False
    Nothing
    "course-registration"
    ("course-registration:" <> T.pack (show (fromSqlKey pid)))
    now

ensurePartyForCourseRegistrationDb
  :: Maybe Text
  -> Maybe Text
  -> Maybe Text
  -> UTCTime
  -> SqlPersistT IO (Either ServerError PartyId)
ensurePartyForCourseRegistrationDb mName mEmail mPhone now = do
  let display = fromMaybe "Alumno / cliente" (cleanOptional mName <|> mEmail <|> mPhone)
  Right <$> insert Party
    { partyLegalName = Nothing
    , partyDisplayName = display
    , partyIsOrg = False
    , partyTaxId = Nothing
    , partyPrimaryEmail = mEmail
    , partyPrimaryPhone = mPhone
    , partyWhatsapp = mPhone
    , partyInstagram = Nothing
    , partyEmergencyContact = Nothing
    , partyNotes = Just "Unverified course contact; supplied details do not establish account identity."
    , partyStripeCustomerId = Nothing
    , partyCountryCode = Nothing
    , partyCountryId = Nothing
    , partyCreatedAt = now
    }

ensureCourseRegistrationParty
  :: Maybe Text
  -> Maybe Text
  -> Maybe Text
  -> UTCTime
  -> AppM (Maybe PartyId, Maybe (Text, Text))
ensureCourseRegistrationParty mName mEmail mPhone now = do
  result <- runDB $ ensurePartyForCourseRegistrationDb mName mEmail mPhone now
  partyId <- either throwError pure result
  pure (Just partyId, Nothing)

ensureCourseRegistrationPartyLink
  :: Entity ME.CourseRegistration
  -> AppM (Entity ME.CourseRegistration)
ensureCourseRegistrationPartyLink (Entity regId _) = runDB $ do
  -- Re-read under a row lock so concurrent administrative reads cannot create
  -- competing contacts for the same source registration.
  _ <- rawSql "SELECT id FROM course_registration WHERE id=? FOR UPDATE"
    [toPersistValue regId] :: SqlPersistT IO [Single Int64]
  reg <- getJust regId
  case ME.courseRegistrationPartyId reg of
    Just _ -> pure (Entity regId reg)
    Nothing -> do
      now <- liftIO getCurrentTime
      result <- ensurePartyForCourseRegistrationDb
        (ME.courseRegistrationFullName reg)
        (ME.courseRegistrationEmail reg)
        (ME.courseRegistrationPhoneE164 reg) now
      partyId <- either (liftIO . throwIO) pure result
      update regId [ME.CourseRegistrationPartyId =. Just partyId, ME.CourseRegistrationUpdatedAt =. now]
      pure (Entity regId reg { ME.courseRegistrationPartyId = Just partyId, ME.courseRegistrationUpdatedAt = now })

parseOptionalUtcText :: Text -> Maybe Text -> AppM (Maybe UTCTime)
parseOptionalUtcText fieldName mValue =
  case cleanOptional mValue of
    Nothing -> pure Nothing
    Just value ->
      case iso8601ParseM (T.unpack value) of
        Just ts -> pure (Just ts)
        Nothing -> throwBadRequest (fieldName <> " inválido")

courseFollowUpTypeOptions :: [Text]
courseFollowUpTypeOptions =
  [ "note"
  , "call"
  , "whatsapp"
  , "email"
  , "payment_receipt"
  , "status_change"
  , "registration"
  ]

normalizeCourseFollowUpTypeToken :: Text -> Maybe Text
normalizeCourseFollowUpTypeToken raw =
  case normalizeBookingStatusToken raw of
    "note" -> Just "note"
    "call" -> Just "call"
    "whatsapp" -> Just "whatsapp"
    "email" -> Just "email"
    "paymentreceipt" -> Just "payment_receipt"
    "statuschange" -> Just "status_change"
    "registration" -> Just "registration"
    _ -> Nothing

normalizeCourseFollowUpType :: Maybe Text -> Text
normalizeCourseFollowUpType =
  fromMaybe "note" . (>>= normalizeCourseFollowUpTypeToken) . cleanOptional

parseCourseFollowUpType :: Maybe Text -> Either ServerError Text
parseCourseFollowUpType Nothing = Right "note"
parseCourseFollowUpType (Just raw) =
  case cleanOptional (Just raw) >>= normalizeCourseFollowUpTypeToken of
    Just entryTypeVal -> Right entryTypeVal
    Nothing ->
      Left err400
        { errBody =
            BL.fromStrict . TE.encodeUtf8 $
              "Invalid course follow-up entryType. Allowed values: "
                <> T.intercalate ", " courseFollowUpTypeOptions
        }

registrationHasReceipts :: Key ME.CourseRegistration -> AppM Bool
registrationHasReceipts regKey = do
  mReceipt <- runDB $ selectFirst
    [ME.CourseRegistrationReceiptRegistrationId ==. regKey]
    [Desc ME.CourseRegistrationReceiptCreatedAt]
  pure (isJust mReceipt)

validateCourseRegistrationReceiptDeletion :: Text -> Int -> Either ServerError ()
validateCourseRegistrationReceiptDeletion rawStatus receiptCount
  | normalizedStatus == Just "paid" && receiptCount <= 1 =
      Left err409
        { errBody =
            "No puedes eliminar el unico comprobante de una inscripcion pagada. Cambia el estado antes de borrarlo."
        }
  | otherwise =
      Right ()
  where
    normalizedStatus = normalizeCourseRegistrationStatus rawStatus

insertCourseRegistrationFollowUp
  :: Key ME.CourseRegistration
  -> Maybe PartyId
  -> Maybe PartyId
  -> Text
  -> Maybe Text
  -> Text
  -> Maybe Text
  -> Maybe Text
  -> Maybe UTCTime
  -> UTCTime
  -> SqlPersistT IO (Entity ME.CourseRegistrationFollowUp)
insertCourseRegistrationFollowUp regKey mPartyId mCreatedBy rawEntryType mSubject rawNotes mAttachmentUrl mAttachmentName mNextFollowUpAt now = do
  let notesVal = T.strip rawNotes
      subjectVal = cleanOptional mSubject
      attachmentUrlVal = cleanOptional mAttachmentUrl
      attachmentNameVal = cleanOptional mAttachmentName
      entryTypeVal = normalizeCourseFollowUpType (Just rawEntryType)
  followUpId <- insert ME.CourseRegistrationFollowUp
    { ME.courseRegistrationFollowUpRegistrationId = regKey
    , ME.courseRegistrationFollowUpPartyId = mPartyId
    , ME.courseRegistrationFollowUpEntryType = entryTypeVal
    , ME.courseRegistrationFollowUpSubject = subjectVal
    , ME.courseRegistrationFollowUpNotes = notesVal
    , ME.courseRegistrationFollowUpAttachmentUrl = attachmentUrlVal
    , ME.courseRegistrationFollowUpAttachmentName = attachmentNameVal
    , ME.courseRegistrationFollowUpNextFollowUpAt = mNextFollowUpAt
    , ME.courseRegistrationFollowUpCreatedBy = mCreatedBy
    , ME.courseRegistrationFollowUpCreatedAt = now
    , ME.courseRegistrationFollowUpUpdatedAt = now
    }
  pure $ Entity followUpId ME.CourseRegistrationFollowUp
    { ME.courseRegistrationFollowUpRegistrationId = regKey
    , ME.courseRegistrationFollowUpPartyId = mPartyId
    , ME.courseRegistrationFollowUpEntryType = entryTypeVal
    , ME.courseRegistrationFollowUpSubject = subjectVal
    , ME.courseRegistrationFollowUpNotes = notesVal
    , ME.courseRegistrationFollowUpAttachmentUrl = attachmentUrlVal
    , ME.courseRegistrationFollowUpAttachmentName = attachmentNameVal
    , ME.courseRegistrationFollowUpNextFollowUpAt = mNextFollowUpAt
    , ME.courseRegistrationFollowUpCreatedBy = mCreatedBy
    , ME.courseRegistrationFollowUpCreatedAt = now
    , ME.courseRegistrationFollowUpUpdatedAt = now
    }

recordCourseRegistrationStatusChange
  :: AuthedUser
  -> Entity ME.CourseRegistration
  -> Text
  -> Text
  -> UTCTime
  -> AppM ()
recordCourseRegistrationStatusChange user (Entity regId reg) oldStatus newStatus now = do
  let oldLabel = T.toLower (T.strip oldStatus)
      newLabel = T.toLower (T.strip newStatus)
  unless (oldLabel == newLabel) $
    void $ runDB $ insertCourseRegistrationFollowUp
      regId
      (ME.courseRegistrationPartyId reg)
      (Just (auPartyId user))
      "status_change"
      (Just ("Estado: " <> newLabel))
      ("Cambio de estado automático de " <> oldLabel <> " a " <> newLabel <> ".")
      Nothing
      Nothing
      Nothing
      now

fetchCourseRegistrationDossier :: Text -> Int64 -> AppM DTO.CourseRegistrationDossierDTO
fetchCourseRegistrationDossier rawSlug regId = do
  ent <- fetchCourseRegistrationEntity rawSlug regId >>= ensureCourseRegistrationPartyLink
  let regKey = entityKey ent
  receipts <- runDB $ selectList
    [ME.CourseRegistrationReceiptRegistrationId ==. regKey]
    [Desc ME.CourseRegistrationReceiptCreatedAt]
  followUps <- runDB $ selectList
    [ME.CourseRegistrationFollowUpRegistrationId ==. regKey]
    [Desc ME.CourseRegistrationFollowUpCreatedAt]
  let followUpCount =
        Map.findWithDefault 0 regKey (courseRegistrationFollowUpCounts followUps)
  pure DTO.CourseRegistrationDossierDTO
    { DTO.crdRegistration = toCourseRegistrationDTOWithCounts (length receipts) followUpCount ent
    , DTO.crdReceipts = map toCourseRegistrationReceiptDTO receipts
    , DTO.crdFollowUps = map toCourseRegistrationFollowUpDTO followUps
    , DTO.crdCanMarkPaid = not (null receipts)
    }

updateCourseRegistrationStatus
  :: AuthedUser
  -> Text
  -> Int64
  -> CourseRegistrationStatusUpdate
  -> AppM CourseRegistrationResponse
updateCourseRegistrationStatus user rawSlug regId CourseRegistrationStatusUpdate{..} = do
  let rawStatus = T.strip status
  when (T.null rawStatus) $
    throwBadRequest "status requerido"
  newStatus <- either throwError pure (parseCourseRegistrationStatus rawStatus)
  ent <- fetchCourseRegistrationEntity rawSlug regId >>= ensureCourseRegistrationPartyLink
  let regKey = entityKey ent
      reg = entityVal ent
  when (newStatus == "paid") $ do
    canonicalStatuses <- runDB (rawSql
      "SELECT checkout.status FROM course_registration_checkout_runtime runtime\
      \ JOIN commerce_checkout_session checkout ON checkout.id = runtime.checkout_id\
      \ WHERE runtime.registration_id = ?"
      [toPersistValue regKey] :: SqlPersistT IO [Single Text])
    case canonicalStatuses of
      [Single "paid"] -> pure ()
      [] -> do
        hasReceipt <- registrationHasReceipts regKey
        unless hasReceipt $
          throwBadRequest "Debes subir un comprobante de pago antes de marcar esta inscripción como pagada."
      [Single _] -> throwError err409
        { errBody = "La inscripción usa checkout canónico y solo un pago verificado por el servidor puede marcarla como pagada." }
      _ -> throwError err500
        { errBody = "El estado de pago canónico de la inscripción es ambiguo." }
  now <- liftIO getCurrentTime
  runDB $ update regKey
    [ ME.CourseRegistrationStatus =. newStatus
    , ME.CourseRegistrationUpdatedAt =. now
    ]
  recordCourseRegistrationStatusChange user ent (ME.courseRegistrationStatus reg) newStatus now
  pure CourseRegistrationResponse { id = regId, status = newStatus }

updateCourseRegistrationNotes
  :: Text
  -> Int64
  -> CourseRegistrationNotesUpdate
  -> AppM DTO.CourseRegistrationDTO
updateCourseRegistrationNotes rawSlug regId CourseRegistrationNotesUpdate{..} = do
  ent <- fetchCourseRegistrationEntity rawSlug regId
  now <- liftIO getCurrentTime
  let regKey = entityKey ent
      reg = entityVal ent
      notesVal = cleanOptional notes
      updated = reg
        { ME.courseRegistrationAdminNotes = notesVal
        , ME.courseRegistrationUpdatedAt = now
        }
  (receiptCount, followUpCount) <- runDB $ do
    update regKey
      [ ME.CourseRegistrationAdminNotes =. notesVal
      , ME.CourseRegistrationUpdatedAt =. now
      ]
    loadCourseRegistrationCounts regKey
  pure (toCourseRegistrationDTOWithCounts receiptCount followUpCount (Entity regKey updated))

createCourseRegistrationReceipt
  :: AuthedUser
  -> Text
  -> Int64
  -> CourseRegistrationReceiptCreate
  -> AppM DTO.CourseRegistrationReceiptDTO
createCourseRegistrationReceipt user rawSlug regId CourseRegistrationReceiptCreate{..} = do
  ent <- fetchCourseRegistrationEntity rawSlug regId >>= ensureCourseRegistrationPartyLink
  fileUrlVal <- do
    normalized <- either throwError pure (validateCourseRegistrationUrlField "fileUrl" (Just fileUrl))
    maybe (throwBadRequest "fileUrl requerido") pure normalized
  fileNameVal <- either throwError pure (validateCourseRegistrationStoredName "fileName" fileName)
  mimeTypeVal <- either throwError pure (validateCourseRegistrationReceiptMimeType mimeType)
  now <- liftIO getCurrentTime
  let regKey = entityKey ent
      reg = entityVal ent
      receipt = ME.CourseRegistrationReceipt
        { ME.courseRegistrationReceiptRegistrationId = regKey
        , ME.courseRegistrationReceiptPartyId = ME.courseRegistrationPartyId reg
        , ME.courseRegistrationReceiptFileUrl = fileUrlVal
        , ME.courseRegistrationReceiptFileName = fileNameVal
        , ME.courseRegistrationReceiptMimeType = mimeTypeVal
        , ME.courseRegistrationReceiptNotes = cleanOptional notes
        , ME.courseRegistrationReceiptUploadedBy = Just (auPartyId user)
        , ME.courseRegistrationReceiptCreatedAt = now
        , ME.courseRegistrationReceiptUpdatedAt = now
        }
  receiptId <- runDB $ insert receipt
  void $ runDB $ insertCourseRegistrationFollowUp
    regKey
    (ME.courseRegistrationPartyId reg)
    (Just (auPartyId user))
    "payment_receipt"
    (Just "Comprobante de pago agregado")
    (fromMaybe "Se agregó un comprobante de pago." (cleanOptional notes <|> fileNameVal))
    (Just fileUrlVal)
    fileNameVal
    Nothing
    now
  pure (toCourseRegistrationReceiptDTO (Entity receiptId receipt))

fetchCourseRegistrationReceiptEntity
  :: Text
  -> Int64
  -> Int64
  -> AppM (Entity ME.CourseRegistration, Entity ME.CourseRegistrationReceipt)
fetchCourseRegistrationReceiptEntity rawSlug regId receiptId = do
  receiptIdValid <- either throwError pure (validateCourseRegistrationReceiptId receiptId)
  ent <- fetchCourseRegistrationEntity rawSlug regId
  let regKey = entityKey ent
      receiptKey = toSqlKey receiptIdValid
  mReceipt <- runDB $ getEntity receiptKey
  case mReceipt of
    Nothing -> throwNotFound "Comprobante no encontrado"
    Just receiptEnt@(Entity _ receipt)
      | ME.courseRegistrationReceiptRegistrationId receipt /= regKey -> throwNotFound "Comprobante no encontrado"
      | otherwise -> pure (ent, receiptEnt)

updateCourseRegistrationReceipt
  :: AuthedUser
  -> Text
  -> Int64
  -> Int64
  -> CourseRegistrationReceiptUpdate
  -> AppM DTO.CourseRegistrationReceiptDTO
updateCourseRegistrationReceipt _ rawSlug regId receiptId CourseRegistrationReceiptUpdate{..} = do
  (ent, Entity receiptKey receipt) <- fetchCourseRegistrationReceiptEntity rawSlug regId receiptId
  now <- liftIO getCurrentTime
  fileUrlVal <- case fileUrl of
    Nothing -> pure (ME.courseRegistrationReceiptFileUrl receipt)
    Just rawUrl -> do
      normalized <- either throwError pure (validateCourseRegistrationUrlField "fileUrl" (Just rawUrl))
      maybe (throwBadRequest "fileUrl requerido") pure normalized
  fileNameVal <- case fileName of
    Nothing -> pure (ME.courseRegistrationReceiptFileName receipt)
    Just _ -> either throwError pure (validateCourseRegistrationStoredName "fileName" fileName)
  mimeTypeVal <- case mimeType of
    Nothing -> pure (ME.courseRegistrationReceiptMimeType receipt)
    Just rawMimeType ->
      either throwError pure (validateCourseRegistrationReceiptMimeType (Just rawMimeType))
  let updated =
        receipt
          { ME.courseRegistrationReceiptPartyId = ME.courseRegistrationPartyId (entityVal ent)
          , ME.courseRegistrationReceiptFileUrl = fileUrlVal
          , ME.courseRegistrationReceiptFileName = fileNameVal
          , ME.courseRegistrationReceiptMimeType = mimeTypeVal
          , ME.courseRegistrationReceiptNotes =
              maybe (ME.courseRegistrationReceiptNotes receipt) (cleanOptional . Just) notes
          , ME.courseRegistrationReceiptUpdatedAt = now
          }
  runDB $ update receiptKey
    [ ME.CourseRegistrationReceiptPartyId =. ME.courseRegistrationReceiptPartyId updated
    , ME.CourseRegistrationReceiptFileUrl =. ME.courseRegistrationReceiptFileUrl updated
    , ME.CourseRegistrationReceiptFileName =. ME.courseRegistrationReceiptFileName updated
    , ME.CourseRegistrationReceiptMimeType =. ME.courseRegistrationReceiptMimeType updated
    , ME.CourseRegistrationReceiptNotes =. ME.courseRegistrationReceiptNotes updated
    , ME.CourseRegistrationReceiptUpdatedAt =. now
    ]
  pure (toCourseRegistrationReceiptDTO (Entity receiptKey updated))

deleteCourseRegistrationReceipt
  :: AuthedUser
  -> Text
  -> Int64
  -> Int64
  -> AppM NoContent
deleteCourseRegistrationReceipt _ rawSlug regId receiptId = do
  (Entity regKey reg, Entity receiptKey _) <- fetchCourseRegistrationReceiptEntity rawSlug regId receiptId
  receiptCount <- runDB $ count [ME.CourseRegistrationReceiptRegistrationId ==. regKey]
  either throwError pure $
    validateCourseRegistrationReceiptDeletion (ME.courseRegistrationStatus reg) receiptCount
  runDB $ delete receiptKey
  pure NoContent

fetchCourseRegistrationFollowUpEntity
  :: Text
  -> Int64
  -> Int64
  -> AppM (Entity ME.CourseRegistration, Entity ME.CourseRegistrationFollowUp)
fetchCourseRegistrationFollowUpEntity rawSlug regId followUpId = do
  followUpIdValid <- either throwError pure (validateCourseRegistrationFollowUpId followUpId)
  ent <- fetchCourseRegistrationEntity rawSlug regId
  let regKey = entityKey ent
      followUpKey = toSqlKey followUpIdValid
  mFollowUp <- runDB $ getEntity followUpKey
  case mFollowUp of
    Nothing -> throwNotFound "Seguimiento no encontrado"
    Just followUpEnt@(Entity _ followUp)
      | ME.courseRegistrationFollowUpRegistrationId followUp /= regKey -> throwNotFound "Seguimiento no encontrado"
      | otherwise -> pure (ent, followUpEnt)

createCourseRegistrationFollowUp
  :: AuthedUser
  -> Text
  -> Int64
  -> CourseRegistrationFollowUpCreate
  -> AppM DTO.CourseRegistrationFollowUpDTO
createCourseRegistrationFollowUp user rawSlug regId CourseRegistrationFollowUpCreate{..} = do
  ent <- fetchCourseRegistrationEntity rawSlug regId >>= ensureCourseRegistrationPartyLink
  let notesVal = T.strip notes
  when (T.null notesVal) $
    throwBadRequest "notes requerido"
  entryTypeVal <- either throwError pure (parseCourseFollowUpType entryType)
  attachmentUrlVal <- either throwError pure (validateCourseRegistrationUrlField "attachmentUrl" attachmentUrl)
  attachmentNameVal <-
    either throwError pure
      (resolveCourseRegistrationAttachmentName attachmentUrlVal Nothing attachmentName)
  mNextFollowUpAt <- parseOptionalUtcText "nextFollowUpAt" nextFollowUpAt
  now <- liftIO getCurrentTime
  followUp <- runDB $ insertCourseRegistrationFollowUp
    (entityKey ent)
    (ME.courseRegistrationPartyId (entityVal ent))
    (Just (auPartyId user))
    entryTypeVal
    subject
    notesVal
    attachmentUrlVal
    attachmentNameVal
    mNextFollowUpAt
    now
  pure (toCourseRegistrationFollowUpDTO followUp)

updateCourseRegistrationFollowUp
  :: AuthedUser
  -> Text
  -> Int64
  -> Int64
  -> CourseRegistrationFollowUpUpdate
  -> AppM DTO.CourseRegistrationFollowUpDTO
updateCourseRegistrationFollowUp _ rawSlug regId followUpId CourseRegistrationFollowUpUpdate{..} = do
  (ent, Entity followUpKey followUp) <- fetchCourseRegistrationFollowUpEntity rawSlug regId followUpId
  notesVal <- case notes of
    Nothing -> pure (ME.courseRegistrationFollowUpNotes followUp)
    Just raw ->
      let trimmed = T.strip raw
      in if T.null trimmed
        then throwBadRequest "notes requerido"
        else pure trimmed
  entryTypeVal <- case entryType of
    Nothing -> pure (ME.courseRegistrationFollowUpEntryType followUp)
    Just raw -> either throwError pure (parseCourseFollowUpType (Just raw))
  attachmentUrlVal <- case attachmentUrl of
    Nothing -> pure (ME.courseRegistrationFollowUpAttachmentUrl followUp)
    Just rawUrl -> either throwError pure (validateCourseRegistrationUrlField "attachmentUrl" (Just rawUrl))
  attachmentNameVal <-
    either throwError pure $
      resolveCourseRegistrationAttachmentName
        attachmentUrlVal
        (ME.courseRegistrationFollowUpAttachmentName followUp)
        attachmentName
  mNextFollowUpAt <- case nextFollowUpAt of
    Nothing -> pure (ME.courseRegistrationFollowUpNextFollowUpAt followUp)
    Just raw -> parseOptionalUtcText "nextFollowUpAt" raw
  now <- liftIO getCurrentTime
  let updated =
        followUp
          { ME.courseRegistrationFollowUpPartyId = ME.courseRegistrationPartyId (entityVal ent)
          , ME.courseRegistrationFollowUpEntryType = entryTypeVal
          , ME.courseRegistrationFollowUpSubject =
              maybe (ME.courseRegistrationFollowUpSubject followUp) (cleanOptional . Just) subject
          , ME.courseRegistrationFollowUpNotes = notesVal
          , ME.courseRegistrationFollowUpAttachmentUrl = attachmentUrlVal
          , ME.courseRegistrationFollowUpAttachmentName = attachmentNameVal
          , ME.courseRegistrationFollowUpNextFollowUpAt = mNextFollowUpAt
          , ME.courseRegistrationFollowUpUpdatedAt = now
          }
  runDB $ update followUpKey
    [ ME.CourseRegistrationFollowUpPartyId =. ME.courseRegistrationFollowUpPartyId updated
    , ME.CourseRegistrationFollowUpEntryType =. ME.courseRegistrationFollowUpEntryType updated
    , ME.CourseRegistrationFollowUpSubject =. ME.courseRegistrationFollowUpSubject updated
    , ME.CourseRegistrationFollowUpNotes =. ME.courseRegistrationFollowUpNotes updated
    , ME.CourseRegistrationFollowUpAttachmentUrl =. ME.courseRegistrationFollowUpAttachmentUrl updated
    , ME.CourseRegistrationFollowUpAttachmentName =. ME.courseRegistrationFollowUpAttachmentName updated
    , ME.CourseRegistrationFollowUpNextFollowUpAt =. ME.courseRegistrationFollowUpNextFollowUpAt updated
    , ME.CourseRegistrationFollowUpUpdatedAt =. now
    ]
  pure (toCourseRegistrationFollowUpDTO (Entity followUpKey updated))

deleteCourseRegistrationFollowUp
  :: AuthedUser
  -> Text
  -> Int64
  -> Int64
  -> AppM NoContent
deleteCourseRegistrationFollowUp _ rawSlug regId followUpId = do
  (_, Entity followUpKey _) <- fetchCourseRegistrationFollowUpEntity rawSlug regId followUpId
  runDB $ delete followUpKey
  pure NoContent

listCourseRegistrationEmailEvents
  :: Int64
  -> Maybe Int
  -> AppM [DTO.CourseEmailEventDTO]
listCourseRegistrationEmailEvents regId mLimit = do
  regIdValid <- either throwError pure (validateCourseRegistrationId regId)
  let regKey = toSqlKey regIdValid :: Key ME.CourseRegistration
  capped <- either throwError pure (validateCourseRegistrationEmailEventListLimit mLimit)
  mRow <- runDB $ getEntity regKey
  case mRow of
    Nothing -> throwNotFound "Registro no encontrado"
    Just (Entity _ reg) -> do
      let mEmail =
            case ME.courseRegistrationEmail reg of
              Nothing -> Nothing
              Just raw ->
                let normalized = T.toLower (T.strip raw)
                in if T.null normalized then Nothing else Just normalized
          byRegistration = [ME.CourseEmailEventRegistrationId ==. Just regKey]
          rowsQuery =
            case mEmail of
              Nothing -> selectList byRegistration [Desc ME.CourseEmailEventCreatedAt, LimitTo capped]
              Just emailVal ->
                selectList
                  (byRegistration ||.
                    [ ME.CourseEmailEventCourseSlug ==. ME.courseRegistrationCourseSlug reg
                    , ME.CourseEmailEventRecipientEmail ==. emailVal
                    ])
                  [Desc ME.CourseEmailEventCreatedAt, LimitTo capped]
      rows <- runDB rowsQuery
      pure (map toCourseEmailEventDTO rows)

toCourseRegistrationDTO :: Entity ME.CourseRegistration -> DTO.CourseRegistrationDTO
toCourseRegistrationDTO =
  toCourseRegistrationDTOWithCounts 0 0

toCourseRegistrationDTOWithReceiptCount
  :: Int
  -> Entity ME.CourseRegistration
  -> DTO.CourseRegistrationDTO
toCourseRegistrationDTOWithReceiptCount receiptCount =
  toCourseRegistrationDTOWithCounts receiptCount 0

toCourseRegistrationDTOWithCounts
  :: Int
  -> Int
  -> Entity ME.CourseRegistration
  -> DTO.CourseRegistrationDTO
toCourseRegistrationDTOWithCounts receiptCount followUpCount (Entity rid reg) =
  DTO.CourseRegistrationDTO
    { DTO.crId = fromSqlKey rid
    , DTO.crCourseSlug = ME.courseRegistrationCourseSlug reg
    , DTO.crPartyId = fromSqlKey <$> ME.courseRegistrationPartyId reg
    , DTO.crFullName = ME.courseRegistrationFullName reg
    , DTO.crEmail = ME.courseRegistrationEmail reg
    , DTO.crPhoneE164 = ME.courseRegistrationPhoneE164 reg
    , DTO.crSource = ME.courseRegistrationSource reg
    , DTO.crStatus = ME.courseRegistrationStatus reg
    , DTO.crReceiptCount = receiptCount
    , DTO.crFollowUpCount = followUpCount
    , DTO.crAdminNotes = ME.courseRegistrationAdminNotes reg
    , DTO.crHowHeard = ME.courseRegistrationHowHeard reg
    , DTO.crUtmSource = ME.courseRegistrationUtmSource reg
    , DTO.crUtmMedium = ME.courseRegistrationUtmMedium reg
    , DTO.crUtmCampaign = ME.courseRegistrationUtmCampaign reg
    , DTO.crUtmContent = ME.courseRegistrationUtmContent reg
    , DTO.crCreatedAt = ME.courseRegistrationCreatedAt reg
    , DTO.crUpdatedAt = ME.courseRegistrationUpdatedAt reg
    }

loadCourseRegistrationCounts
  :: Key ME.CourseRegistration
  -> SqlPersistT IO (Int, Int)
loadCourseRegistrationCounts regKey = do
  receiptCount <- count [ME.CourseRegistrationReceiptRegistrationId ==. regKey]
  followUpCount <- count
    [ ME.CourseRegistrationFollowUpRegistrationId ==. regKey
    , ME.CourseRegistrationFollowUpEntryType !=. "registration"
    ]
  pure (receiptCount, followUpCount)

loadCourseRegistrationReceiptCounts
  :: [Entity ME.CourseRegistration]
  -> SqlPersistT IO (Map.Map (Key ME.CourseRegistration) Int)
loadCourseRegistrationReceiptCounts [] = pure Map.empty
loadCourseRegistrationReceiptCounts rows = do
  receipts <- selectList
    [ME.CourseRegistrationReceiptRegistrationId <-. map entityKey rows]
    []
  pure (courseRegistrationReceiptCounts receipts)

courseRegistrationReceiptCounts
  :: [Entity ME.CourseRegistrationReceipt]
  -> Map.Map (Key ME.CourseRegistration) Int
courseRegistrationReceiptCounts =
  foldl' addReceipt Map.empty
  where
    addReceipt countsByRegistration (Entity _ receipt) =
      Map.insertWith (+) (ME.courseRegistrationReceiptRegistrationId receipt) 1 countsByRegistration

loadCourseRegistrationFollowUpCounts
  :: [Entity ME.CourseRegistration]
  -> SqlPersistT IO (Map.Map (Key ME.CourseRegistration) Int)
loadCourseRegistrationFollowUpCounts [] = pure Map.empty
loadCourseRegistrationFollowUpCounts rows = do
  followUps <- selectList
    [ ME.CourseRegistrationFollowUpRegistrationId <-. map entityKey rows
    , ME.CourseRegistrationFollowUpEntryType !=. "registration"
    ]
    []
  pure (courseRegistrationFollowUpCounts followUps)

courseRegistrationFollowUpCounts
  :: [Entity ME.CourseRegistrationFollowUp]
  -> Map.Map (Key ME.CourseRegistration) Int
courseRegistrationFollowUpCounts =
  foldl' addFollowUp Map.empty
    . filter isCourseRegistrationListFollowUpActivity
  where
    isCourseRegistrationListFollowUpActivity (Entity _ followUp) =
      ME.courseRegistrationFollowUpEntryType followUp /= "registration"

    addFollowUp countsByRegistration (Entity _ followUp) =
      Map.insertWith
        (+)
        (ME.courseRegistrationFollowUpRegistrationId followUp)
        1
        countsByRegistration

toCourseRegistrationReceiptDTO :: Entity ME.CourseRegistrationReceipt -> DTO.CourseRegistrationReceiptDTO
toCourseRegistrationReceiptDTO (Entity receiptId receipt) =
  DTO.CourseRegistrationReceiptDTO
    { DTO.crrId = fromSqlKey receiptId
    , DTO.crrRegistrationId = fromSqlKey (ME.courseRegistrationReceiptRegistrationId receipt)
    , DTO.crrPartyId = fromSqlKey <$> ME.courseRegistrationReceiptPartyId receipt
    , DTO.crrFileUrl = ME.courseRegistrationReceiptFileUrl receipt
    , DTO.crrFileName = ME.courseRegistrationReceiptFileName receipt
    , DTO.crrMimeType = ME.courseRegistrationReceiptMimeType receipt
    , DTO.crrNotes = ME.courseRegistrationReceiptNotes receipt
    , DTO.crrUploadedBy = fromSqlKey <$> ME.courseRegistrationReceiptUploadedBy receipt
    , DTO.crrCreatedAt = ME.courseRegistrationReceiptCreatedAt receipt
    , DTO.crrUpdatedAt = ME.courseRegistrationReceiptUpdatedAt receipt
    }

toCourseRegistrationFollowUpDTO :: Entity ME.CourseRegistrationFollowUp -> DTO.CourseRegistrationFollowUpDTO
toCourseRegistrationFollowUpDTO (Entity followUpId followUp) =
  DTO.CourseRegistrationFollowUpDTO
    { DTO.crfId = fromSqlKey followUpId
    , DTO.crfRegistrationId = fromSqlKey (ME.courseRegistrationFollowUpRegistrationId followUp)
    , DTO.crfPartyId = fromSqlKey <$> ME.courseRegistrationFollowUpPartyId followUp
    , DTO.crfEntryType = ME.courseRegistrationFollowUpEntryType followUp
    , DTO.crfSubject = ME.courseRegistrationFollowUpSubject followUp
    , DTO.crfNotes = ME.courseRegistrationFollowUpNotes followUp
    , DTO.crfAttachmentUrl = ME.courseRegistrationFollowUpAttachmentUrl followUp
    , DTO.crfAttachmentName = ME.courseRegistrationFollowUpAttachmentName followUp
    , DTO.crfNextFollowUpAt = ME.courseRegistrationFollowUpNextFollowUpAt followUp
    , DTO.crfCreatedBy = fromSqlKey <$> ME.courseRegistrationFollowUpCreatedBy followUp
    , DTO.crfCreatedAt = ME.courseRegistrationFollowUpCreatedAt followUp
    , DTO.crfUpdatedAt = ME.courseRegistrationFollowUpUpdatedAt followUp
    }

toCourseEmailEventDTO :: Entity ME.CourseEmailEvent -> DTO.CourseEmailEventDTO
toCourseEmailEventDTO (Entity eventId ev) =
  DTO.CourseEmailEventDTO
    { DTO.ceId = fromSqlKey eventId
    , DTO.ceCourseSlug = ME.courseEmailEventCourseSlug ev
    , DTO.ceRegistrationId = fromSqlKey <$> ME.courseEmailEventRegistrationId ev
    , DTO.ceRecipientEmail = ME.courseEmailEventRecipientEmail ev
    , DTO.ceRecipientName = ME.courseEmailEventRecipientName ev
    , DTO.ceEventType = ME.courseEmailEventEventType ev
    , DTO.ceStatus = ME.courseEmailEventStatus ev
    , DTO.ceMessage = ME.courseEmailEventMessage ev
    , DTO.ceCreatedAt = ME.courseEmailEventCreatedAt ev
    }

recordCourseEmailEvent
  :: Text
  -> Maybe ME.CourseRegistrationId
  -> Text
  -> Maybe Text
  -> Text
  -> Text
  -> Maybe Text
  -> AppM ()
recordCourseEmailEvent rawSlug mRegistrationId rawRecipientEmail mRecipientName rawEventType rawStatus mMessage = do
  let recipientEmail = T.toLower (T.strip rawRecipientEmail)
  unless (T.null recipientEmail) $ do
    now <- liftIO getCurrentTime
    runDB $ insert_ ME.CourseEmailEvent
      { ME.courseEmailEventCourseSlug = normalizeSlug rawSlug
      , ME.courseEmailEventRegistrationId = mRegistrationId
      , ME.courseEmailEventRecipientEmail = recipientEmail
      , ME.courseEmailEventRecipientName = cleanOptional mRecipientName
      , ME.courseEmailEventEventType = T.toLower (T.strip rawEventType)
      , ME.courseEmailEventStatus = T.toLower (T.strip rawStatus)
      , ME.courseEmailEventMessage = cleanOptional mMessage
      , ME.courseEmailEventCreatedAt = now
      }

courseEmailSentWithinLast24Hours :: ME.CourseRegistrationId -> Text -> AppM Bool
courseEmailSentWithinLast24Hours registrationKey rawRecipientEmail = do
  let recipientEmail = T.toLower (T.strip rawRecipientEmail)
  if T.null recipientEmail
    then pure False
    else do
      now <- liftIO getCurrentTime
      let cutoff = addUTCTime (negate 86400) now
      mRecent <- runDB $ selectFirst
        [ ME.CourseEmailEventRecipientEmail ==. recipientEmail
        , ME.CourseEmailEventRegistrationId ==. Just registrationKey
        , ME.CourseEmailEventEventType ==. "registration_confirmation"
        , ME.CourseEmailEventStatus ==. "sent"
        , ME.CourseEmailEventCreatedAt >=. cutoff
        ]
        [Desc ME.CourseEmailEventCreatedAt]
      pure (isJust mRecent)

createOrUpdateRegistration :: Text -> Maybe Text -> CourseRegistrationRequest -> AppM CourseRegistrationResponse
createOrUpdateRegistration = createCourseRegistrationInScope "public-course"

createCourseRegistrationInScope :: Text -> Text -> Maybe Text -> CourseRegistrationRequest -> AppM CourseRegistrationResponse
createCourseRegistrationInScope namespace rawSlug mRequestKey payload@CourseRegistrationRequest{..} = do
  requestKey <- either (throwError . marketplaceCheckoutBadRequest) pure $
    ServiceStorefront.validateIdempotencyKey mRequestKey
  unless (T.all (\ch -> ch <= '\x7f' && (isAlphaNum ch || ch == '-' || ch == '_')) requestKey) $
    throwBadRequest "Course Idempotency-Key must contain only ASCII letters, digits, hyphens or underscores"
  metaRaw <- loadCourseMetadata rawSlug
  let Courses.CourseMetadata{ Courses.slug = metaSlug
                            , Courses.sessions = metaSessions
                            , Courses.title = metaTitle
                            , Courses.landingUrl = metaLanding
                            , Courses.remaining = metaRemaining
                            } = metaRaw
  now <- liftIO getCurrentTime
  sourceClean <- either throwError pure (validateCourseRegistrationSource source)
  nameClean <- either throwError pure (validateOptionalCourseRegistrationTextField "fullName" 160 fullName)
  howHeardClean <- either throwError pure (validateOptionalCourseRegistrationTextField "howHeard" 256 howHeard)
  (utmSourceVal, utmMediumVal, utmCampaignVal, utmContentVal) <-
    either throwError pure (validateCourseRegistrationUtm utm)
  let slugVal = normalizeSlug metaSlug
      pendingStatus = "pending_payment"
  normalizedEmail <- either throwError pure (validateCourseRegistrationEmail email)
  phoneClean <- either throwError pure (validateCourseRegistrationPhoneE164 phoneE164)
  either throwError pure (validateCourseRegistrationContactChannels normalizedEmail phoneClean)
  when (sourceClean == "landing" && isNothing nameClean) $
    throwBadRequest "nombre requerido"
  when (sourceClean == "landing" && isNothing normalizedEmail) $
    throwBadRequest "email requerido"
  let requestScope = namespace <> ":" <> slugVal
      requestBody = TE.decodeUtf8 (BL.toStrict (encode payload))
  (regId, savedStatus, created) <- runDB $ do
    _ <- rawSql "SELECT 1::bigint FROM pg_advisory_xact_lock(hashtextextended(?,0))"
      [PersistText (requestScope <> ":" <> requestKey)] :: SqlPersistT IO [Single Int64]
    previous <- rawSql "SELECT receipt.registration_id, receipt.request_payload=?::jsonb, registration.status FROM identity_course_registration_request receipt JOIN course_registration registration ON registration.id=receipt.registration_id WHERE receipt.request_scope=? AND receipt.request_key=?"
      [PersistText requestBody, PersistText requestScope, PersistText requestKey]
    case previous of
      [(Single existingId, Single True, Single existingStatus)] -> pure (toSqlKey existingId, existingStatus, False)
      [(_, Single False, _)] -> liftIO $ throwIO err409 { errBody = "This registration changed after an earlier send. Review the saved registration before starting another submission." }
      [] -> do
          when (namespace == "public-course") $ do
            existingCheckout <- rawSql "SELECT registration_id FROM course_registration_checkout_runtime WHERE create_idempotency_key=?"
              [PersistText requestKey] :: SqlPersistT IO [Single Int64]
            unless (null existingCheckout) $ liftIO $ throwIO err409 { errBody = "A checkout already exists for this request. Retry to load its saved result." }
          either (liftIO . throwIO) pure $ validateCourseRegistrationSeatAvailability metaRemaining Nothing
          partyResult <- ensurePartyForCourseRegistrationDb nameClean normalizedEmail phoneClean now
          partyId <- either (liftIO . throwIO) pure partyResult
          let mPartyId = Just partyId
          regId <- insert ME.CourseRegistration
            { ME.courseRegistrationCourseSlug = slugVal
            , ME.courseRegistrationPartyId = mPartyId
            , ME.courseRegistrationFullName = nameClean
            , ME.courseRegistrationEmail = normalizedEmail
            , ME.courseRegistrationPhoneE164 = phoneClean
            , ME.courseRegistrationSource = sourceClean
            , ME.courseRegistrationStatus = pendingStatus
            , ME.courseRegistrationAdminNotes = Nothing
            , ME.courseRegistrationHowHeard = howHeardClean
            , ME.courseRegistrationUtmSource = utmSourceVal
            , ME.courseRegistrationUtmMedium = utmMediumVal
            , ME.courseRegistrationUtmCampaign = utmCampaignVal
            , ME.courseRegistrationUtmContent = utmContentVal
            , ME.courseRegistrationStripePaymentIntentId = Nothing
            , ME.courseRegistrationStripeSubscriptionId = Nothing
            , ME.courseRegistrationSubscriptionStatus = Nothing
            , ME.courseRegistrationCreatedAt = now
            , ME.courseRegistrationUpdatedAt = now
            }
          void $ insertCourseRegistrationFollowUp
            regId
            mPartyId
            Nothing
            "registration"
            (Just "Inscripción recibida")
            ("Nueva inscripción capturada desde " <> sourceClean <> ".")
            Nothing
            Nothing
            Nothing
            now
          rawExecute "INSERT INTO identity_course_registration_request(request_scope,request_key,request_payload,registration_id) VALUES (?,?,?::jsonb,?)"
            [PersistText requestScope, PersistText requestKey, PersistText requestBody, toPersistValue regId]
          pure (regId, pendingStatus, True)
      _ -> liftIO $ throwIO err500 { errBody = "Could not resolve registration request" }
  when created $ sendConfirmation slugVal regId metaTitle metaLanding metaSessions nameClean normalizedEmail Nothing
  pure CourseRegistrationResponse { id = fromSqlKey regId, status = savedStatus }
  where
    sendConfirmation courseSlug regKey courseTitle landing metaSessions nameClean mEmail mNewUser =
      case mEmail of
        Nothing -> pure ()
        Just emailAddr -> do
          Env{..} <- ask
          let emailSvc = EmailSvc.mkEmailService envConfig
              displayName = fromMaybe "" nameClean
              datesSummary =
                let fmt d = T.pack (formatTime defaultTimeLocale "%d %b %Y" d)
                in T.intercalate ", " (map (\Courses.CourseSession{ Courses.date = d } -> fmt d) metaSessions)
          -- Check if email is configured before attempting to send
          case EmailSvc.esConfig emailSvc of
            Nothing -> do
              let msg = "[CourseRegistration] WARNING: SMTP not configured. Email confirmation not sent to " <> emailAddr
              liftIO $ do
                hPutStrLn stderr (T.unpack msg)
                LogBuf.addLog LogBuf.LogWarning msg
              recordCourseEmailEvent
                courseSlug
                (Just regKey)
                emailAddr
                nameClean
                "registration_confirmation"
                "skipped"
                (Just msg)
            Just _ -> do
              alreadySent <- courseEmailSentWithinLast24Hours regKey emailAddr
              if alreadySent
                then do
                  let msg = "[CourseRegistration] Skipped registration confirmation to " <> emailAddr <> ": this registration already received a confirmation within 24h."
                  liftIO $ LogBuf.addLog LogBuf.LogWarning msg
                  recordCourseEmailEvent
                    courseSlug
                    (Just regKey)
                    emailAddr
                    nameClean
                    "registration_confirmation"
                    "skipped"
                    (Just msg)
                else do
                  result <- liftIO $ try $ EmailSvc.sendCourseRegistration emailSvc displayName emailAddr courseTitle landing datesSummary
                  case result of
                    Left err -> do
                      let errorMsg = T.pack (displayException (err :: SomeException))
                          msg = "[CourseRegistration] Failed to send confirmation email to " <> emailAddr <> ": " <> errorMsg
                      liftIO $ do
                        hPutStrLn stderr (T.unpack msg)
                        LogBuf.addLog LogBuf.LogError msg
                      recordCourseEmailEvent
                        courseSlug
                        (Just regKey)
                        emailAddr
                        nameClean
                        "registration_confirmation"
                        "failed"
                        (Just errorMsg)
                    Right () -> do
                      let msg = "[CourseRegistration] Successfully sent confirmation email to " <> emailAddr
                      liftIO $ LogBuf.addLog LogBuf.LogInfo msg
                      recordCourseEmailEvent
                        courseSlug
                        (Just regKey)
                        emailAddr
                        nameClean
                        "registration_confirmation"
                        "sent"
                        Nothing
              -- Send welcome email if we just created credentials.
              -- This is evaluated after registration_confirmation, so a just-sent
              -- confirmation will block welcome in the same request.
              for_ mNewUser $ \(username, tempPassword) -> do
                welcomeAlreadySent <- courseEmailSentWithinLast24Hours regKey emailAddr
                if welcomeAlreadySent
                  then do
                    let msg = "[CourseRegistration] Skipped welcome email to " <> emailAddr <> ": this registration already received a confirmation within 24h."
                    liftIO $ LogBuf.addLog LogBuf.LogWarning msg
                    recordCourseEmailEvent
                      courseSlug
                      (Just regKey)
                      emailAddr
                      nameClean
                      "welcome_credentials"
                      "skipped"
                      (Just msg)
                  else do
                    welcomeResult <- liftIO $ try $ EmailSvc.sendWelcome emailSvc displayName emailAddr username tempPassword
                    case welcomeResult of
                      Left err -> do
                        let errorMsg = T.pack (displayException (err :: SomeException))
                            msg = "[CourseRegistration] Failed to send welcome email to " <> emailAddr <> ": " <> errorMsg
                        liftIO $ do
                          hPutStrLn stderr (T.unpack msg)
                          LogBuf.addLog LogBuf.LogError msg
                        recordCourseEmailEvent
                          courseSlug
                          (Just regKey)
                          emailAddr
                          nameClean
                          "welcome_credentials"
                          "failed"
                          (Just errorMsg)
                      Right () -> do
                        let msg = "[CourseRegistration] Sent welcome credentials to " <> emailAddr
                        liftIO $ LogBuf.addLog LogBuf.LogInfo msg
                        recordCourseEmailEvent
                          courseSlug
                          (Just regKey)
                          emailAddr
                          nameClean
                          "welcome_credentials"
                          "sent"
                          Nothing

-- | Returns messages that include text bodies, paired with the sender phone.
extractTextMessages :: WAMetaWebhook -> [(Text, Text)]
extractTextMessages payload =
  [ (waInboundSenderId, waInboundText)
  | WAInbound{waInboundSenderId, waInboundText} <- extractWhatsAppInbound payload
  ]

data WAInbound = WAInbound
  { waInboundExternalId :: Text
  , waInboundSenderId   :: Text
  , waInboundSenderName :: Maybe Text
  , waInboundText       :: Text
  , waInboundAdExternalId :: Maybe Text
  , waInboundAdName     :: Maybe Text
  , waInboundCampaignExternalId :: Maybe Text
  , waInboundCampaignName :: Maybe Text
  , waInboundMetadata   :: Maybe Text
  , waInboundSentAt     :: Maybe UTCTime
  } deriving (Show)

extractWhatsAppInbound :: WAMetaWebhook -> [WAInbound]
extractWhatsAppInbound WAMetaWebhook{entry} =
  concatMap extractEntry entry
  where
    extractEntry WAEntry{changes} = concatMap extractChange changes

    extractChange WAChange{value=WAValue{messages=Just msgs, contacts=mContacts}} =
      let contactMap = Map.fromList
            [ (waIdVal, cleanOptional (WA.name =<< WA.waIdProfile contact))
            | contact <- fromMaybe [] mContacts
            , Just waIdVal <- [cleanOptional (WA.waIdValue contact) >>= normalizeWhatsAppPhone]
            ]
      in
        [ WAInbound
            { waInboundExternalId = resolvedExternalId senderId msg
            , waInboundSenderId = senderId
            , waInboundSenderName = join (Map.lookup senderId contactMap)
            , waInboundText = body
            , waInboundAdExternalId = adExt
            , waInboundAdName = adName
            , waInboundCampaignExternalId = Nothing
            , waInboundCampaignName = Nothing
            , waInboundMetadata = metaTxt
            , waInboundSentAt = parseWhatsAppMessageTimestamp (waTimestamp msg)
            }
        | msg@WAMessage{waType, text=Just txtBody} <- msgs
        , waType == "text"
        , Just senderId <- [cleanOptional (Just (WA.from msg)) >>= normalizeWhatsAppPhone]
        , Just body <- [cleanOptional (Just (WA.body txtBody))]
        , let referral = waReferral msg <|> (waContext msg >>= waContextReferral)
              (adExt, adName, metaTxt) = waReferralMeta referral
        ]
    extractChange _ = []

    resolvedExternalId senderId msg =
      fromMaybe
        (whatsAppWebhookFallbackExternalId senderId msg)
        (cleanWhatsAppWebhookExternalId (waId msg))

    cleanWhatsAppWebhookExternalId rawExternalId =
      cleanOptional rawExternalId >>= \externalId ->
        if T.length externalId <= 256
            && not (T.any isUnsafeWebhookExternalIdChar externalId)
          then Just externalId
          else Nothing

    isUnsafeWebhookExternalIdChar ch =
      isSpace ch
        || isControl ch
        || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

    whatsAppWebhookFallbackExternalId senderId msg =
      let timestampToken =
            case cleanOptional (waTimestamp msg) of
              Just ts | T.all isDigit ts && T.length ts <= 20 -> ts
              _ -> "0"
          bodyToken =
            case text msg of
              Just txtBody -> fromMaybe "" (cleanOptional (Just (WA.body txtBody)))
              Nothing -> ""
          referral = waReferral msg <|> (waContext msg >>= waContextReferral)
          referralToken = TE.decodeUtf8 (BL.toStrict (encode (waReferralMetaObject referral)))
          rawIdToken = fromMaybe "" (waId msg)
          hashInput =
            T.intercalate "|"
              [ senderId
              , timestampToken
              , bodyToken
              , rawIdToken
              , referralToken
              ]
      in senderId <> "-" <> timestampToken <> "-" <> stableWebhookHash hashInput

    stableWebhookHash txt =
      let hexTxt = T.pack (showHex (T.foldl' hashStep fnvOffset txt) "")
      in T.justifyRight 16 '0' hexTxt

    hashStep h c = (h `xor` fromIntegral (fromEnum c)) * fnvPrime

    fnvOffset = 14695981039346656037 :: Word64
    fnvPrime = 1099511628211 :: Word64

    waReferralMeta Nothing = (Nothing, Nothing, Nothing)
    waReferralMeta (Just WAReferral{sourceId, headline, waBody, sourceType, sourceUrl}) =
      let adName = headline <|> waBody
          metaObj =
            waReferralMetaObject
              (Just WAReferral{sourceId, headline, waBody, sourceType, sourceUrl})
          metaTxt = Just (TE.decodeUtf8 (BL.toStrict (encode metaObj)))
      in (sourceId, adName, metaTxt)

    waReferralMetaObject :: Maybe WAReferral -> Value
    waReferralMetaObject Nothing =
      Object mempty
    waReferralMetaObject (Just WAReferral{sourceId, headline, waBody, sourceType, sourceUrl}) =
      object
        [ "source_id" .= sourceId
        , "source_type" .= sourceType
        , "source_url" .= sourceUrl
        , "headline" .= headline
        , "body" .= waBody
        ]

data WADeliveryStatus = WADeliveryStatus
  { waDeliveryExternalId :: Text
  , waDeliveryStatus     :: Text
  , waDeliveryRecipientId :: Maybe Text
  , waDeliveryOccurredAt :: Maybe UTCTime
  , waDeliveryError      :: Maybe Text
  , waDeliveryPayload    :: Maybe Text
  } deriving (Show)

extractWhatsAppDeliveryUpdates :: WAMetaWebhook -> [WADeliveryStatus]
extractWhatsAppDeliveryUpdates WAMetaWebhook{entry} =
  concatMap extractEntry entry
  where
    extractEntry WAEntry{changes} = concatMap extractChange changes

    extractChange WAChange{value=WAValue{statuses=Just rows}} =
      [ WADeliveryStatus
          { waDeliveryExternalId = externalId
          , waDeliveryStatus = fromMaybe "unknown" (cleanOptional (WA.waStatus statusRow))
          , waDeliveryRecipientId = cleanOptional (WA.waRecipientId statusRow)
          , waDeliveryOccurredAt = WA.waStatusTimestamp statusRow >>= parseWhatsAppEpoch
          , waDeliveryError = foldMap summarizeErrors (WA.waStatusErrors statusRow)
          , waDeliveryPayload = Just (TE.decodeUtf8 (BL.toStrict (encode payload)))
          }
      | statusRow <- rows
      , let externalId = fromMaybe "" (cleanOptional (WA.waStatusId statusRow))
            payload = object
              [ "id" .= WA.waStatusId statusRow
              , "status" .= WA.waStatus statusRow
              , "recipient_id" .= WA.waRecipientId statusRow
              , "timestamp" .= WA.waStatusTimestamp statusRow
              , "errors" .= WA.waStatusErrors statusRow
              ]
      , not (T.null externalId)
      ]
    extractChange _ = []

    summarizeErrors errs =
      let rendered = TE.decodeUtf8 (BL.toStrict (encode errs))
      in cleanOptional (Just rendered)

    parseWhatsAppEpoch raw = do
      value <- cleanOptional (Just raw)
      seconds <- readMaybe (T.unpack value) :: Maybe Integer
      pure (addUTCTime (fromInteger seconds) (UTCTime (fromGregorian 1970 1 1) 0))

sendWhatsappReply :: WhatsAppEnv -> Text -> AppM (Text, Either Text SendTextResult)
sendWhatsappReply waEnv phone = do
  Env{envConfig} <- ask
  let slugVal = productionCourseSlug envConfig
  metaRaw <- loadCourseMetadata slugVal
  let Courses.CourseMetadata{ Courses.title = metaTitle
                            , Courses.capacity = metaCapacity
                            , Courses.landingUrl = metaLanding
                            } = metaRaw
  let msg = "¡Gracias por tu interés en " <> metaTitle <> "! Aquí tienes el link de inscripción: "
            <> metaLanding <> ". Cupos limitados (" <> T.pack (show metaCapacity) <> ")."
  res <- liftIO $ sendWhatsAppTextIO waEnv phone msg
  pure (msg, res)

sendWhatsAppText :: WhatsAppEnv -> Text -> Text -> AppM (Either Text SendTextResult)
sendWhatsAppText waEnv phone msg = liftIO $ sendWhatsAppTextIO waEnv phone msg

normalizePhone :: Text -> Maybe Text
normalizePhone = normalizeWhatsAppPhone

normalizeCourseRegistrationPhoneInput :: Text -> Maybe Text
normalizeCourseRegistrationPhoneInput = CoursePhone.normalizeInternationalPhoneInput

isAsciiPhoneDigit :: Char -> Bool
isAsciiPhoneDigit ch = ch >= '0' && ch <= '9'

normalizeSlug :: Text -> Text
normalizeSlug = T.toLower . T.strip

validateCourseSlug :: Text -> Either ServerError Text
validateCourseSlug rawSlug =
  let slugVal = normalizeSlug rawSlug
  in
    if T.null slugVal
      then Left err400 { errBody = "slug requerido" }
      else
        if CoursePublic.isValidNormalizedCourseSlug slugVal
          then Right slugVal
          else Left invalidCourseSlug
  where
    invalidCourseSlug =
      err400
        { errBody =
            "slug must contain only ASCII letters, numbers, and hyphens, "
              <> "include at least one letter or number, and be 96 characters or fewer"
        }

validateOptionalCourseSlugFilter :: Maybe Text -> Either ServerError (Maybe Text)
validateOptionalCourseSlugFilter Nothing = Right Nothing
validateOptionalCourseSlugFilter (Just rawSlug)
  | T.null (T.strip rawSlug) =
      Left invalidOptionalCourseSlug
  | otherwise =
      case validateCourseSlug rawSlug of
        Right slugVal -> Right (Just slugVal)
        Left _ -> Left invalidOptionalCourseSlug
  where
    invalidOptionalCourseSlug =
      err400
        { errBody =
            "slug must be omitted or use only ASCII letters, numbers, and hyphens"
        }

validateCourseRegistrationSource :: Text -> Either ServerError Text
validateCourseRegistrationSource raw =
  let sourceVal = T.toLower (T.strip raw)
      isSourceChar ch = isAsciiLower ch || isDigit ch || ch == '_' || ch == '-'
      isSourceAtom ch = isAsciiLower ch || isDigit ch
  in if T.null sourceVal
    then Left err400 { errBody = "source requerido" }
    else
      if T.length sourceVal <= 64
          && T.all isSourceChar sourceVal
          && T.any isSourceAtom sourceVal
        then Right sourceVal
        else
          Left err400
            { errBody =
                "source must be an ASCII keyword using letters, numbers, underscores, "
                  <> "or hyphens (64 chars max)"
            }

validateCourseRegistrationPhoneE164 :: Maybe Text -> Either ServerError (Maybe Text)
validateCourseRegistrationPhoneE164 Nothing = Right Nothing
validateCourseRegistrationPhoneE164 (Just rawPhone) =
  case cleanOptional (Just rawPhone) of
    Nothing -> Right Nothing
    Just _ ->
      -- Course visitors may type an Ecuador national number (0988384849).
      case CoursePhone.normalizeCoursePhone rawPhone of
        Just phoneClean -> Right (Just phoneClean)
        Nothing -> Left err400 { errBody = "phoneE164 inválido" }

validateAdsInquiryPhone :: Maybe Text -> Either ServerError (Maybe Text)
validateAdsInquiryPhone Nothing = Right Nothing
validateAdsInquiryPhone (Just rawPhone) =
  case normalizeOptionalInput (Just rawPhone) of
    Nothing -> Right Nothing
    Just _ ->
      case normalizeCourseRegistrationPhoneInput rawPhone of
        Just phoneClean -> Right (Just phoneClean)
        Nothing -> Left err400 { errBody = "phone inválido" }

validateAdsInquiryContactChannels :: Maybe Text -> Maybe Text -> Either ServerError ()
validateAdsInquiryContactChannels mEmail mPhone
  | isNothing mEmail && isNothing mPhone =
      Left err400 { errBody = "email o phone requerido" }
  | otherwise =
      Right ()

validateAdsInquiryChannel :: Maybe Text -> Either ServerError (Maybe Text)
validateAdsInquiryChannel Nothing = Right Nothing
validateAdsInquiryChannel (Just rawChannel)
  | T.null (T.strip rawChannel) =
      Left err400 { errBody = "channel must be omitted instead of blank" }
validateAdsInquiryChannel (Just rawChannel) =
  case normalizeOptionalInput (Just rawChannel) of
    Nothing -> Right Nothing
    Just channel ->
      let channelVal = T.toLower channel
      in if T.length channelVal <= 64
            && T.all isChannelChar channelVal
            && T.any isChannelAtom channelVal
           then Right (Just channelVal)
           else
             Left err400
               { errBody =
                   "channel must be an ASCII keyword using letters, numbers, underscores, "
                     <> "or hyphens (64 chars max)"
               }
  where
    isChannelChar ch = isAsciiLower ch || isDigit ch || ch == '_' || ch == '-'
    isChannelAtom ch = isAsciiLower ch || isDigit ch

validateAdsInquiryMessage :: Maybe Text -> Either ServerError (Maybe Text)
validateAdsInquiryMessage Nothing = Right Nothing
validateAdsInquiryMessage (Just rawMessage) =
  case normalizeOptionalInput (Just rawMessage) of
    Nothing -> Right Nothing
    Just message
      | T.length message > adsInquiryMessageMaxLength ->
          Left err400 { errBody = "message must be 2000 characters or fewer" }
      | T.any isUnsafeAdsInquiryMessageChar message ->
          Left err400
            { errBody =
                "message must not contain control characters "
                  <> "other than tabs or line breaks, or hidden formatting characters"
            }
      | otherwise ->
          Right (Just message)
  where
    isUnsafeAdsInquiryMessageChar ch =
      (isControl ch && ch /= '\n' && ch /= '\r' && ch /= '\t')
        || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

adsInquiryMessageMaxLength :: Int
adsInquiryMessageMaxLength = 2000

validateWhatsAppPhoneInput :: Text -> Either ServerError Text
validateWhatsAppPhoneInput rawPhone =
  case cleanOptional (Just rawPhone) of
    Nothing -> invalidWhatsAppPhone
    Just _ ->
      case normalizeCourseRegistrationPhoneInput rawPhone of
        Just phoneClean -> Right phoneClean
        Nothing -> invalidWhatsAppPhone
  where
    invalidWhatsAppPhone =
      Left err400 { errBody = "Número de WhatsApp inválido." }

validatePublicBookingContactDetails :: Text -> Maybe Text -> Either ServerError (Text, Maybe Text)
validatePublicBookingContactDetails rawEmail rawPhone = do
  emailClean <-
    case cleanOptional (Just rawEmail) of
      Nothing ->
        Left err400 { errBody = "email requerido" }
      Just _ -> do
        normalizedEmail <- validateCourseRegistrationEmail (Just rawEmail)
        case normalizedEmail of
          Just emailVal -> Right emailVal
          Nothing -> Left err400 { errBody = "email requerido" }
  phoneClean <- validateCourseRegistrationPhoneE164 rawPhone
  pure (emailClean, phoneClean)

validatePublicBookingFullName :: Text -> Either ServerError Text
validatePublicBookingFullName rawName =
  case cleanOptional (Just rawName) of
    Nothing -> Left err400 { errBody = "nombre requerido" }
    Just nameVal
      | T.length nameVal > 160 ->
          Left err400 { errBody = "nombre debe tener 160 caracteres o menos" }
      | not (hasPublicBookingLabelContent nameVal) ->
          Left err400 { errBody = "nombre debe incluir letras o números" }
      | T.any isAmbiguousPublicBookingSpace nameVal ->
          Left err400 { errBody = "nombre no debe contener espacios Unicode ambiguos" }
      | T.any isUnsafePublicBookingLabelChar nameVal ->
          Left err400
            { errBody =
                "nombre no debe contener caracteres de control o marcas Unicode invisibles"
            }
      | otherwise ->
          Right nameVal

isUnsafePublicBookingLabelChar :: Char -> Bool
isUnsafePublicBookingLabelChar ch =
  isControl ch
    || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

isAmbiguousPublicBookingSpace :: Char -> Bool
isAmbiguousPublicBookingSpace ch =
  generalCategory ch == Space && ch /= ' '

hasPublicBookingLabelContent :: Text -> Bool
hasPublicBookingLabelContent = T.any isAlphaNum

validateRequiredBookingTitle :: Text -> Either ServerError Text
validateRequiredBookingTitle rawTitle =
  let titleVal = T.strip rawTitle
  in if T.null titleVal
       then Left err400 { errBody = "title is required" }
       else if T.length titleVal > bookingTitleMaxLength
         then Left err400 { errBody = "title must be 160 characters or fewer" }
         else if T.any isUnsafeBookingTitleChar titleVal
           then Left err400
             { errBody =
                 "title must not contain control characters or hidden formatting characters"
             }
           else Right titleVal

validateOptionalBookingTitleUpdate :: Maybe Text -> Either ServerError (Maybe Text)
validateOptionalBookingTitleUpdate Nothing = Right Nothing
validateOptionalBookingTitleUpdate (Just rawTitle) =
  Just <$> validateRequiredBookingTitle rawTitle

bookingTitleMaxLength :: Int
bookingTitleMaxLength = 160

isUnsafeBookingTitleChar :: Char -> Bool
isUnsafeBookingTitleChar ch =
  isControl ch
    || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

validateBookingNotes :: Maybe Text -> Either ServerError (Maybe Text)
validateBookingNotes Nothing = Right Nothing
validateBookingNotes (Just rawNotes) =
  case normalizeOptionalInput (Just rawNotes) of
    Nothing -> Right Nothing
    Just notesVal
      | T.length notesVal > publicBookingNotesMaxLength ->
          Left err400 { errBody = "notes must be 1000 characters or fewer" }
      | T.any isUnsafeNoteChar notesVal ->
          Left err400
            { errBody =
                "notes must not contain control characters "
                  <> "other than tabs or line breaks, or hidden formatting characters"
            }
      | otherwise ->
          Right (Just notesVal)
  where
    isUnsafeNoteChar ch =
      (isControl ch && ch /= '\n' && ch /= '\r' && ch /= '\t')
        || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

validatePublicBookingNotes :: Maybe Text -> Either ServerError (Maybe Text)
validatePublicBookingNotes = validateBookingNotes

publicBookingNotesMaxLength :: Int
publicBookingNotesMaxLength = 1000

validatePublicBookingDurationMinutes :: Maybe Int -> Either ServerError Int
validatePublicBookingDurationMinutes Nothing = Right 60
validatePublicBookingDurationMinutes (Just durationMinutes)
  | durationMinutes < publicBookingMinDurationMinutes
      || durationMinutes > publicBookingMaxDurationMinutes =
      Left err400 { errBody = "durationMinutes must be between 30 and 480" }
  | durationMinutes `mod` publicBookingDurationStepMinutes /= 0 =
      Left err400 { errBody = "durationMinutes must be a multiple of 15" }
  | otherwise =
      Right durationMinutes

publicBookingMinDurationMinutes :: Int
publicBookingMinDurationMinutes = 30

publicBookingMaxDurationMinutes :: Int
publicBookingMaxDurationMinutes = 480

publicBookingDurationStepMinutes :: Int
publicBookingDurationStepMinutes = 15

validatePublicBookingStartAt :: UTCTime -> UTCTime -> Either ServerError UTCTime
validatePublicBookingStartAt now startsAt
  | startsAt <= now = Left err400 { errBody = "startsAt must be in the future" }
  | startsAt > addUTCTime (fromIntegral publicBookingMaxLeadDays * 86400) now =
      Left err400 { errBody = "startsAt must be within 365 days" }
  | not (isPublicBookingStartOnGrid startsAt) =
      Left err400 { errBody = "startsAt must align to a 15-minute slot" }
  | otherwise = Right startsAt

publicBookingMaxLeadDays :: Int
publicBookingMaxLeadDays = 365

isPublicBookingStartOnGrid :: UTCTime -> Bool
isPublicBookingStartOnGrid startsAt =
  let picoseconds = diffTimeToPicoseconds (utctDayTime startsAt)
      stepPicoseconds =
        fromIntegral (publicBookingDurationStepMinutes * 60) * picosecondsPerSecond
  in picoseconds `mod` stepPicoseconds == 0

picosecondsPerSecond :: Integer
picosecondsPerSecond = 1000000000000

validateBookingTimeRange :: UTCTime -> UTCTime -> Either ServerError ()
validateBookingTimeRange startsAt endsAt
  | endsAt > startsAt = Right ()
  | otherwise = Left err400 { errBody = "endsAt must be after startsAt" }

validateCourseRegistrationEmail :: Maybe Text -> Either ServerError (Maybe Text)
validateCourseRegistrationEmail Nothing = Right Nothing
validateCourseRegistrationEmail (Just rawEmail) =
  case cleanOptional (Just rawEmail) of
    Nothing -> Right Nothing
    Just emailVal ->
      let normalized = T.toLower emailVal
      in if isValidCourseRegistrationEmail normalized
        then Right (Just normalized)
        else Left err400 { errBody = "email inválido" }

validateMarketplaceBuyerEmail :: Text -> Either ServerError Text
validateMarketplaceBuyerEmail rawEmail =
  case validateCourseRegistrationEmail (Just rawEmail) of
    Right (Just emailVal) -> Right emailVal
    Right Nothing -> Left err400 { errBody = "buyerEmail requerido" }
    Left _ -> Left err400 { errBody = "buyerEmail inválido" }

validateMarketplaceBuyerPhone :: Maybe Text -> Either ServerError (Maybe Text)
validateMarketplaceBuyerPhone rawPhone =
  case validateCourseRegistrationPhoneE164 rawPhone of
    Right phoneVal -> Right phoneVal
    Left _ -> Left err400 { errBody = "buyerPhone inválido" }

validateMarketplaceBuyerName :: Text -> Either ServerError Text
validateMarketplaceBuyerName rawName =
  case cleanOptional (Just rawName) of
    Nothing -> Left err400 { errBody = "buyerName requerido" }
    Just nameVal
      | T.length nameVal > 160 ->
          Left err400 { errBody = "buyerName must be 160 characters or fewer" }
      | T.any isUnsafeMarketplaceBuyerNameChar nameVal ->
          Left err400
            { errBody =
                "buyerName must not contain control characters or "
                  <> "Unicode formatting/separator characters"
            }
      | not (T.any isAlphaNum nameVal) ->
          Left err400 { errBody = "buyerName must include letters or numbers" }
      | otherwise ->
          Right nameVal

isUnsafeMarketplaceBuyerNameChar :: Char -> Bool
isUnsafeMarketplaceBuyerNameChar ch =
  isControl ch
    || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]
    || (generalCategory ch == Space && ch /= ' ')

validateCourseRegistrationUrlField :: Text -> Maybe Text -> Either ServerError (Maybe Text)
validateCourseRegistrationUrlField _ Nothing = Right Nothing
validateCourseRegistrationUrlField fieldName (Just rawUrl) =
  case cleanOptional (Just rawUrl) of
    Nothing -> Right Nothing
    Just urlVal
      | T.length urlVal > maxCourseRegistrationUrlChars ->
          Left err400
            { errBody =
                BL.fromStrict . TE.encodeUtf8 $
                  fieldName
                    <> " must be "
                    <> T.pack (show maxCourseRegistrationUrlChars)
                    <> " characters or fewer"
            }
      | not
          ( "https://" `T.isPrefixOf` T.toLower urlVal
              && TrialsServer.isValidHttpUrl urlVal
          ) ->
          Left err400
            { errBody =
                BL.fromStrict . TE.encodeUtf8 $
                  fieldName <> " must be an absolute https URL"
            }
      | "#" `T.isInfixOf` urlVal ->
          Left err400
            { errBody =
                BL.fromStrict . TE.encodeUtf8 $
                  fieldName <> " must not include a URL fragment"
            }
      | TrialsServer.hasAmbiguousPublicUrlPath urlVal ->
          Left err400
            { errBody =
                BL.fromStrict . TE.encodeUtf8 $
                  fieldName
                    <> " path must not contain empty, dot, or dot-dot segments "
                    <> "or encoded separators"
            }
      | otherwise ->
          Right (Just urlVal)

maxCourseRegistrationUrlChars :: Int
maxCourseRegistrationUrlChars = 2048

resolveCourseRegistrationAttachmentName
  :: Maybe Text
  -> Maybe Text
  -> Maybe Text
  -> Either ServerError (Maybe Text)
resolveCourseRegistrationAttachmentName mAttachmentUrl mExistingName mProvidedName =
  case mAttachmentUrl of
    Nothing ->
      case cleanOptional mProvidedName of
        Just _ ->
          Left err400 { errBody = "attachmentName requires attachmentUrl" }
        Nothing ->
          Right Nothing
    Just _ ->
      case mProvidedName of
        Nothing -> Right mExistingName
        Just _ -> validateCourseRegistrationStoredName "attachmentName" mProvidedName

validateCourseRegistrationStoredName
  :: Text
  -> Maybe Text
  -> Either ServerError (Maybe Text)
validateCourseRegistrationStoredName _ Nothing = Right Nothing
validateCourseRegistrationStoredName fieldName (Just rawName) =
  case cleanOptional (Just rawName) of
    Nothing -> Right Nothing
    Just nameVal
      | T.length nameVal > 240 ->
          Left err400
            { errBody =
                BL.fromStrict (TE.encodeUtf8 (fieldName <> " must be 240 characters or fewer"))
            }
      | T.any isUnsafeCourseRegistrationStoredNameChar nameVal ->
          Left err400
            { errBody =
                BL.fromStrict (TE.encodeUtf8 (courseRegistrationStoredNameUnsafeMessage fieldName))
            }
      | T.any isPathSeparator nameVal ->
          Left err400
            { errBody =
                BL.fromStrict (TE.encodeUtf8 (fieldName <> " must not contain path separators"))
            }
      | otherwise ->
          Right (Just nameVal)
  where
    isPathSeparator ch = ch == '/' || ch == '\\'

isUnsafeCourseRegistrationStoredNameChar :: Char -> Bool
isUnsafeCourseRegistrationStoredNameChar ch =
  isControl ch
    || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

courseRegistrationStoredNameUnsafeMessage :: Text -> Text
courseRegistrationStoredNameUnsafeMessage fieldName =
  fieldName
    <> " must not contain control characters or Unicode formatting/"
    <> "separator characters"

validateCourseRegistrationReceiptMimeType :: Maybe Text -> Either ServerError (Maybe Text)
validateCourseRegistrationReceiptMimeType Nothing = Right Nothing
validateCourseRegistrationReceiptMimeType (Just rawMimeType) =
  case cleanOptional (Just rawMimeType) of
    Nothing -> Right Nothing
    Just mimeTypeVal ->
      let normalized = T.toLower mimeTypeVal
      in if T.length normalized > 100
        then Left err400 { errBody = "mimeType must be 100 characters or fewer" }
        else
          if isValidCourseRegistrationReceiptMimeType normalized
            then Right (Just normalized)
            else
              Left err400
                { errBody = "mimeType must be a media type like application/pdf" }

isValidCourseRegistrationReceiptMimeType :: Text -> Bool
isValidCourseRegistrationReceiptMimeType mimeTypeVal =
  case T.splitOn "/" mimeTypeVal of
    [typePart, subTypePart] ->
      isValidReceiptMimeToken typePart && isValidReceiptMimeToken subTypePart
    _ -> False

isValidReceiptMimeToken :: Text -> Bool
isValidReceiptMimeToken token =
  not (T.null token) && T.all isReceiptMimeTokenChar token

isReceiptMimeTokenChar :: Char -> Bool
isReceiptMimeTokenChar ch =
  isAsciiLower ch || isDigit ch || ch `elem` ("!#$%&'*+-.^_`|~" :: String)

validateCoursePublicUrlField :: Text -> Maybe Text -> Either ServerError (Maybe Text)
validateCoursePublicUrlField fieldName value =
  case CoursePublic.validateCoursePublicUrlField fieldName value of
    Left message -> Left err400 { errBody = BL.fromStrict (TE.encodeUtf8 message) }
    Right result -> Right result

sanitizeStoredCoursePublicUrl :: Text -> Maybe Text -> Maybe Text
sanitizeStoredCoursePublicUrl = CoursePublic.sanitizeStoredCoursePublicUrl

isValidCourseRegistrationEmail :: Text -> Bool
isValidCourseRegistrationEmail candidate =
  case T.splitOn "@" candidate of
    [localPart, domain] ->
      T.length candidate <= 254
        && isValidEmailLocalPart localPart
        && not (T.null domain)
        && not (T.any isSpace candidate)
        && T.isInfixOf "." domain
        && hasValidEmailTopLevelLabel domain
        && all isValidEmailDomainLabel (T.splitOn "." domain)
    _ -> False

hasValidEmailTopLevelLabel :: Text -> Bool
hasValidEmailTopLevelLabel domain =
  case reverse (T.splitOn "." domain) of
    topLevelLabel : _ ->
      T.length topLevelLabel >= 2
        && T.any isAsciiLower topLevelLabel
    _ -> False

isValidEmailLocalPart :: Text -> Bool
isValidEmailLocalPart localPart =
  not (T.null localPart)
    && T.length localPart <= 64
    && not (T.isPrefixOf "." localPart)
    && not (T.isSuffixOf "." localPart)
    && not (T.isInfixOf ".." localPart)
    && T.all isValidEmailLocalChar localPart

isValidEmailLocalChar :: Char -> Bool
isValidEmailLocalChar c =
  isAsciiLower c || isDigit c || c `elem` ("!#$%&'*+/=?^_`{|}~.-" :: String)

isValidEmailDomainLabel :: Text -> Bool
isValidEmailDomainLabel label =
  not (T.null label)
    && T.length label <= 63
    && not (T.isPrefixOf "-" label)
    && not (T.isSuffixOf "-" label)
    && T.all isValidEmailDomainChar label

isValidEmailDomainChar :: Char -> Bool
isValidEmailDomainChar c = isAsciiLower c || isDigit c || c == '-'

validateCourseRegistrationContactChannels :: Maybe Text -> Maybe Text -> Either ServerError ()
validateCourseRegistrationContactChannels mEmail mPhone
  | isNothing mEmail && isNothing mPhone =
      Left err400 { errBody = "email o phoneE164 requerido" }
  | otherwise =
      Right ()

validateCourseRegistrationSeatAvailability :: Int -> Maybe Text -> Either ServerError ()
validateCourseRegistrationSeatAvailability remainingSeats mExistingStatus
  | remainingSeats > 0 =
      Right ()
  | maybe False isPendingCourseRegistrationStatus mExistingStatus =
      Right ()
  | otherwise =
      Left err409 { errBody = "course has no remaining seats" }

isPendingCourseRegistrationStatus :: Text -> Bool
isPendingCourseRegistrationStatus rawStatus =
  normalizeCourseRegistrationStatus rawStatus == Just "pending_payment"

validateRequiredCourseTextField :: Text -> Int -> Text -> Either ServerError Text
validateRequiredCourseTextField fieldName maxLength rawValue =
  case validateOptionalCourseTextField fieldName maxLength (Just rawValue) of
    Right (Just value) -> Right value
    Right Nothing ->
      Left err400
        { errBody =
            BL.fromStrict . TE.encodeUtf8 $
              fieldName <> " is required"
        }
    Left err -> Left err

validateCourseTextListField :: Text -> Int -> [Text] -> Either ServerError (Maybe [Text])
validateCourseTextListField _ _ [] = Right Nothing
validateCourseTextListField fieldName maxLength rawValues = do
  values <- traverse validateIndexed (zip [1 :: Int ..] rawValues)
  let foldedValues = map T.toCaseFold values
  if length foldedValues /= Set.size (Set.fromList foldedValues)
    then
      Left err400
        { errBody =
            BL.fromStrict . TE.encodeUtf8 $
              fieldName <> " entries must be unique after trimming"
        }
    else Right (Just values)
  where
    validateIndexed (idx, rawValue) =
      validateRequiredCourseTextField
        (fieldName <> "[" <> T.pack (show idx) <> "]")
        maxLength
        rawValue

validateOptionalCourseTextField :: Text -> Int -> Maybe Text -> Either ServerError (Maybe Text)
validateOptionalCourseTextField _ _ Nothing = Right Nothing
validateOptionalCourseTextField fieldName maxLength (Just rawValue) =
  case cleanOptional (Just rawValue) of
    Nothing -> Right Nothing
    Just value
      | T.length value > maxLength ->
          Left err400
            { errBody =
                BL.fromStrict . TE.encodeUtf8 $
                  fieldName <> " must be " <> T.pack (show maxLength) <> " characters or fewer"
            }
      | T.any isUnsafeCourseTextChar value ->
          Left err400
            { errBody =
                BL.fromStrict . TE.encodeUtf8 $
                  fieldName <> " must not contain control characters or hidden formatting characters"
            }
      | otherwise -> Right (Just value)

isUnsafeCourseTextChar :: Char -> Bool
isUnsafeCourseTextChar ch =
  isControl ch || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

validateOptionalCourseRegistrationTextField :: Text -> Int -> Maybe Text -> Either ServerError (Maybe Text)
validateOptionalCourseRegistrationTextField = validateOptionalCourseTextField

validateCourseRegistrationUtm :: Maybe UTMTags -> Either ServerError (Maybe Text, Maybe Text, Maybe Text, Maybe Text)
validateCourseRegistrationUtm Nothing = Right (Nothing, Nothing, Nothing, Nothing)
validateCourseRegistrationUtm (Just UTMTags{..}) = do
  sourceVal <- validateOptionalCourseRegistrationTextField "utm.source" 256 source
  mediumVal <- validateOptionalCourseRegistrationTextField "utm.medium" 256 medium
  campaignVal <- validateOptionalCourseRegistrationTextField "utm.campaign" 256 campaign
  contentVal <- validateOptionalCourseRegistrationTextField "utm.content" 256 content
  pure (sourceVal, mediumVal, campaignVal, contentVal)

-- Guest commerce creates only the customer Party. Account creation remains an
-- explicit post-purchase choice; creating a credential without delivering its
-- random password would leave the customer with an inaccessible account.
ensurePartyRecord :: Maybe Text -> Text -> Maybe Text -> AppM (Key Party)
ensurePartyRecord mName emailAddr mPhone = do
  now <- liftIO getCurrentTime
  partyResult <- runDB (ensurePartyRecordDb now mName emailAddr mPhone)
  either throwError pure partyResult

ensurePartyRecordDb
  :: UTCTime
  -> Maybe Text
  -> Text
  -> Maybe Text
  -> SqlPersistT IO (Either ServerError (Key Party))
ensurePartyRecordDb now mName emailAddr mPhone = do
  let display = case fmap T.strip mName of
        Just nameTxt | not (T.null nameTxt) -> nameTxt
        _                                   -> emailAddr
      phoneClean = mPhone >>= normalizePhone
  Right <$> insert Party
        { partyLegalName = Nothing
        , partyDisplayName = display
        , partyIsOrg = False
        , partyTaxId = Nothing
        , partyPrimaryEmail = Just emailAddr
        , partyPrimaryPhone = phoneClean
        , partyWhatsapp = Nothing
        , partyInstagram = Nothing
        , partyEmergencyContact = Nothing
        , partyNotes = Just "Unverified guest booking contact; supplied contact details do not establish account identity."
        , partyStripeCustomerId = Nothing
        , partyCountryCode = Nothing
        , partyCountryId = Nothing
        , partyCreatedAt = now
        }

selectUniquePartyByPrimaryEmail
  :: Text
  -> SqlPersistT IO (Either ServerError (Maybe (Entity Party)))
selectUniquePartyByPrimaryEmail emailAddr =
  selectUniquePartyByContact "email" [PartyPrimaryEmail ==. Just emailAddr]

selectUniquePartyByPrimaryPhone
  :: Text
  -> SqlPersistT IO (Either ServerError (Maybe (Entity Party)))
selectUniquePartyByPrimaryPhone phoneNumber =
  selectUniquePartyByContact "phone" [PartyPrimaryPhone ==. Just phoneNumber]

selectUniquePartyByContact
  :: Text
  -> [Filter Party]
  -> SqlPersistT IO (Either ServerError (Maybe (Entity Party)))
selectUniquePartyByContact contactLabel filters = do
  matches <- selectList filters [Asc PartyId, LimitTo 2]
  pure $ case matches of
    [] -> Right Nothing
    [partyEnt] -> Right (Just partyEnt)
    _ ->
      Left err409
        { errBody =
            BL.fromStrict $
              TE.encodeUtf8
                ( "Multiple parties match this "
                    <> contactLabel
                    <> "; merge duplicate party records before linking new records"
                )
        }

deriveBaseUsername :: Maybe Text -> Text -> Text
deriveBaseUsername mName emailAddr =
  let emailLocal = T.takeWhile (/= '@') emailAddr
      candidate = fromMaybe emailLocal (slugify <$> mName)
  in if T.null candidate then emailLocal else candidate

generateUniqueUsername :: Text -> PartyId -> SqlPersistT IO Text
generateUniqueUsername base partyId = go (0 :: Int)
  where
    baseClean = T.take 60 (T.filter (\c -> isAlphaNum c || c `elem` (".-_" :: String)) (T.toLower (T.strip base)))
    fallback = "tdf-user-" <> T.pack (show (fromSqlKey partyId))
    root = if T.null baseClean then fallback else baseClean
    go attempt = do
      let suffix = if attempt == 0 then "" else "-" <> T.pack (show attempt)
          candidate = T.take 60 (root <> suffix)
      conflict <- getBy (UniqueCredentialUsername candidate)
      case conflict of
        Nothing -> pure candidate
        Just _  -> go (attempt + 1)

slugify :: Text -> Text
slugify =
  T.take 60 . T.filter (\c -> isAlphaNum c || c `elem` ("._-" :: String)) . T.toLower . T.strip

hashPasswordText :: Text -> IO Text
hashPasswordText pwd = do
  let raw = TE.encodeUtf8 pwd
  mHash <- hashPasswordUsingPolicy slowerBcryptHashingPolicy raw
  case mHash of
    Nothing   -> fail "Failed to hash password"
    Just hash -> pure (TE.decodeUtf8 hash)

findExistingRegistration
  :: Text
  -> Maybe Text
  -> Maybe Text
  -> SqlPersistT IO (Either ServerError (Maybe (Entity ME.CourseRegistration)))
findExistingRegistration slugVal mEmail mPhone = do
  byEmail <- case mEmail of
    Nothing -> pure (Right Nothing)
    Just e  -> selectUniqueCourseRegistrationByContact "email"
      [ ME.CourseRegistrationCourseSlug ==. slugVal
      , ME.CourseRegistrationEmail ==. Just e
      ]
  byPhone <- case mPhone of
    Nothing -> pure (Right Nothing)
    Just p -> selectUniqueCourseRegistrationByContact "phone"
      [ ME.CourseRegistrationCourseSlug ==. slugVal
      , ME.CourseRegistrationPhoneE164 ==. Just p
      ]
  pure $ do
    emailHit <- byEmail
    phoneHit <- byPhone
    case (emailHit, phoneHit) of
      (Just emailRow, Just phoneRow)
        | entityKey emailRow /= entityKey phoneRow ->
            Left err409
              { errBody =
                  "email and phone match different course registrations"
              }
      _ ->
        Right (emailHit <|> phoneHit)

selectUniqueCourseRegistrationByContact
  :: Text
  -> [Filter ME.CourseRegistration]
  -> SqlPersistT IO (Either ServerError (Maybe (Entity ME.CourseRegistration)))
selectUniqueCourseRegistrationByContact contactLabel filters = do
  matches <- selectList filters [Desc ME.CourseRegistrationCreatedAt, LimitTo 2]
  pure $ do
    statuses <- traverse validateStoredCourseRegistrationStatus matches
    case matches of
      [] -> Right Nothing
      [registration] -> Right (Just registration)
      _ ->
        Left err409
          { errBody =
              BL.fromStrict . TE.encodeUtf8 $
                duplicateCourseRegistrationMessage contactLabel statuses
          }

validateStoredCourseRegistrationStatus
  :: Entity ME.CourseRegistration
  -> Either ServerError Text
validateStoredCourseRegistrationStatus (Entity _ registration) =
  case normalizeCourseRegistrationStatus (ME.courseRegistrationStatus registration) of
    Just statusVal -> Right statusVal
    Nothing ->
      Left err500
        { errBody = "Stored course registration status is invalid"
        }

duplicateCourseRegistrationMessage :: Text -> [Text] -> Text
duplicateCourseRegistrationMessage contactLabel statuses
  | not (null statuses) && all (== "pending_payment") statuses =
      "Multiple pending course registrations match this " <> contactLabel
  | otherwise =
      "Multiple course registrations match this " <> contactLabel

-- Health
health :: AppM (Headers '[Header "Cache-Control" Text] TDF.API.HealthStatus)
health = do
  pool <- asks envPool
  ready <- liftIO (databaseReady pool)
  if ready
    then pure (addHeader "no-store" (HealthStatus "ok" "ok"))
    else throwError err503
      { errBody = encode (HealthStatus "degraded" "unavailable")
      , errHeaders = [("Content-Type", "application/json"), ("Cache-Control", "no-store"), ("Retry-After", "5")]
      }



fanGetProfile :: AuthedUser -> AppM FanProfileDTO
fanGetProfile user = do
  requireFanAccess user
  Env pool _ <- ask
  liftIO $ flip runSqlPool pool $ loadFanProfileDTO (auPartyId user)

fanUpdateProfile :: AuthedUser -> FanProfileUpdate -> AppM FanProfileDTO
fanUpdateProfile user rawUpdate = do
  requireFanAccess user
  validatedUpdate <- either throwError pure (validateFanProfileUpdate rawUpdate)
  let FanProfileUpdate{..} = validatedUpdate
  Env pool _ <- ask
  now <- liftIO getCurrentTime
  result <- liftIO $ flip runSqlPool pool $ do
    let fanId = auPartyId user
    resolvedGenres <- resolvePublishedGenreSelections "fpuFavoriteGenreIds" fpuFavoriteGenreIds
    case resolvedGenres of
      Left validationError -> pure (Left validationError)
      Right genres -> do
        _ <- upsert FanProfile
          { fanProfileFanPartyId     = fanId
          , fanProfileDisplayName    = fpuDisplayName
          , fanProfileAvatarUrl      = fpuAvatarUrl
          , fanProfileFavoriteGenres = Nothing
          , fanProfileBio            = fpuBio
          , fanProfileCity           = fpuCity
          , fanProfileCreatedAt      = now
          , fanProfileUpdatedAt      = Just now
          }
          [ FanProfileDisplayName    =. fpuDisplayName
          , FanProfileAvatarUrl      =. fpuAvatarUrl
          , FanProfileBio            =. fpuBio
          , FanProfileCity           =. fpuCity
          , FanProfileUpdatedAt      =. Just now
          ]
        deleteWhere [FanProfileGenreMembershipFanPartyId ==. fanId]
        forM_ (zip [0 :: Int ..] genres) $ \(position, (genreId, _)) ->
          insert_ FanProfileGenreMembership
            { fanProfileGenreMembershipFanPartyId = fanId
            , fanProfileGenreMembershipGenreId = genreId
            , fanProfileGenreMembershipSortOrder = position
            , fanProfileGenreMembershipCreatedAt = now
            }
        Right <$> loadFanProfileDTO fanId
  either throwBadRequest pure result

validateFanProfileUpdate :: FanProfileUpdate -> Either ServerError FanProfileUpdate
validateFanProfileUpdate payload@FanProfileUpdate{..} = do
  displayNameVal <- validateOptionalFanProfileDisplayName fpuDisplayName
  Right payload { fpuDisplayName = displayNameVal }

validateOptionalFanProfileDisplayName :: Maybe Text -> Either ServerError (Maybe Text)
validateOptionalFanProfileDisplayName rawDisplayName =
  case cleanOptional rawDisplayName of
    Nothing -> Right Nothing
    Just displayNameVal
      | T.length displayNameVal > maxFanProfileDisplayNameChars ->
          Left err400 { errBody = "displayName must be 160 characters or fewer" }
      | T.any isUnsafeFanProfileDisplayNameChar displayNameVal ->
          Left err400
            { errBody =
                "displayName must not contain control characters or hidden formatting characters"
            }
      | otherwise -> Right (Just displayNameVal)

maxFanProfileDisplayNameChars :: Int
maxFanProfileDisplayNameChars = 160

isUnsafeFanProfileDisplayNameChar :: Char -> Bool
isUnsafeFanProfileDisplayNameChar ch =
  isControl ch || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

fanListFollows :: AuthedUser -> AppM [FanFollowDTO]
fanListFollows user = do
  requireFanAccess user
  Env pool _ <- ask
  liftIO $ flip runSqlPool pool $ do
    follows <- selectList [FanFollowFanPartyId ==. auPartyId user] [Desc FanFollowCreatedAt]
    let artistIds = map (fanFollowArtistPartyId . entityVal) follows
    nameMap <- fetchPartyNameMap artistIds
    profileMap <- fetchArtistProfileMap artistIds
    pure (map (fanFollowEntityToDTO nameMap profileMap) follows)

fanFollowArtist :: AuthedUser -> Int64 -> AppM FanFollowDTO
fanFollowArtist = FanEffects.followArtist

fanUnfollowArtist :: AuthedUser -> Int64 -> AppM NoContent
fanUnfollowArtist = FanEffects.unfollowArtist

recordEngagementEvent
  :: Maybe PartyId
  -> Maybe PartyId
  -> Text
  -> Maybe Int
  -> Text
  -> Maybe Text
  -> UTCTime
  -> SqlPersistT IO ()
recordEngagementEvent actorPartyId targetArtistId entityType entityId eventType metadata createdAt =
  insert_ EngagementEvent
    { engagementEventActorPartyId = actorPartyId
    , engagementEventTargetArtistId = targetArtistId
    , engagementEventEntityType = entityType
    , engagementEventEntityId = entityId
    , engagementEventEventType = eventType
    , engagementEventMetadata = metadata
    , engagementEventCreatedAt = createdAt
    }

resolveFanFollowArtistTarget :: Int64 -> SqlPersistT IO (Either ServerError PartyId)
resolveFanFollowArtistTarget rawArtistId =
  case validatePositiveIdField "artistId" rawArtistId of
    Left err -> pure (Left err)
    Right artistId -> do
      let artistKey = toSqlKey artistId :: PartyId
      mProfile <- getBy (UniqueArtistProfile artistKey)
      pure $
        case mProfile of
          Nothing ->
            Left err404 { errBody = "Artist profile not found" }
          Just _ ->
            Right artistKey

-- Chat (1:1 DM between parties)

normalizeDmPair :: PartyId -> PartyId -> (PartyId, PartyId)
normalizeDmPair a b =
  if fromSqlKey a <= fromSqlKey b
    then (a, b)
    else (b, a)

ensureCanChatWith :: AuthedUser -> PartyId -> AppM ()
ensureCanChatWith user otherPartyId = do
  if hasRole Admin user
    then pure ()
    else do
      let me = auPartyId user
      isMutual <- runDB $ do
        mAB <- getBy (UniquePartyFollow me otherPartyId)
        mBA <- getBy (UniquePartyFollow otherPartyId me)
        pure (isJust mAB && isJust mBA)
      unless isMutual $
        throwError err403
          { errBody = BL.fromStrict (TE.encodeUtf8 ("Solo puedes chatear con amigos mutuos." :: Text)) }

requireChatThreadParticipant :: AuthedUser -> ChatThread -> AppM ()
requireChatThreadParticipant user ChatThread{chatThreadDmPartyA, chatThreadDmPartyB} = do
  let me = auPartyId user
  unless (me == chatThreadDmPartyA || me == chatThreadDmPartyB) $
    throwError err404

chatThreadToDTO
  :: PartyId
  -> ChatThreadId
  -> ChatThread
  -> Maybe Party
  -> Maybe (Entity ChatMessage)
  -> ChatThreadDTO
chatThreadToDTO otherKey threadId ChatThread{chatThreadUpdatedAt} mOtherParty mLastMessage =
  let otherName = maybe "Unknown" M.partyDisplayName mOtherParty
      (lastBody, lastAt) =
        case mLastMessage of
          Nothing -> (Nothing, Nothing)
          Just (Entity _ msg) -> (Just (chatMessageBody msg), Just (chatMessageCreatedAt msg))
  in ChatThreadDTO
      { ctThreadId = fromSqlKey threadId
      , ctOtherPartyId = fromSqlKey otherKey
      , ctOtherDisplayName = otherName
      , ctLastMessage = lastBody
      , ctLastMessageAt = lastAt
      , ctUpdatedAt = chatThreadUpdatedAt
      }

chatMessageToDTO :: Entity ChatMessage -> ChatMessageDTO
chatMessageToDTO (Entity mid ChatMessage{..}) =
  ChatMessageDTO
    { cmId = fromSqlKey mid
    , cmThreadId = fromSqlKey chatMessageThreadId
    , cmSenderPartyId = fromSqlKey chatMessageSenderPartyId
    , cmBody = chatMessageBody
    , cmCreatedAt = chatMessageCreatedAt
    }

chatListThreads :: AuthedUser -> AppM [ChatThreadDTO]
chatListThreads user = do
  let me = auPartyId user
  threads <-
    runDB $
      selectList
        ([ChatThreadDmPartyA ==. me] ||. [ChatThreadDmPartyB ==. me])
        [Desc ChatThreadUpdatedAt, Desc ChatThreadId]
  forM threads $ \(Entity tid thread) -> do
    let otherKey =
          if chatThreadDmPartyA thread == me
            then chatThreadDmPartyB thread
            else chatThreadDmPartyA thread
    mOther <- runDB $ get otherKey
    mLast <- runDB $ selectFirst [ChatMessageThreadId ==. tid] [Desc ChatMessageId]
    pure (chatThreadToDTO otherKey tid thread mOther mLast)

chatGetOrCreateDM :: AuthedUser -> Int64 -> AppM ChatThreadDTO
chatGetOrCreateDM user otherPartyId = do
  when (otherPartyId <= 0) $ throwBadRequest "Invalid party id"
  let me = auPartyId user
      otherKey = toSqlKey otherPartyId :: PartyId
  when (me == otherKey) $
    throwBadRequest "No puedes chatear contigo mismo"
  mOther <- runDB $ get otherKey
  when (isNothing mOther) $ throwError err404
  ensureCanChatWith user otherKey
  let (a, b) = normalizeDmPair me otherKey
  now <- liftIO getCurrentTime
  existing <- runDB $ getBy (UniqueChatThread a b)
  case existing of
    Just (Entity tid thread) -> do
      mLast <- runDB $ selectFirst [ChatMessageThreadId ==. tid] [Desc ChatMessageId]
      pure (chatThreadToDTO otherKey tid thread mOther mLast)
    Nothing -> do
      let thread = ChatThread
            { chatThreadDmPartyA = a
            , chatThreadDmPartyB = b
            , chatThreadCreatedAt = now
            , chatThreadUpdatedAt = now
            }
      tid <- runDB $ insert thread
      pure (chatThreadToDTO otherKey tid thread mOther Nothing)

chatListMessages :: AuthedUser -> Int64 -> Maybe Int -> Maybe Int64 -> Maybe Int64 -> AppM [ChatMessageDTO]
chatListMessages user threadId mLimit mBeforeId mAfterId = do
  let limit = fromMaybe 50 mLimit
  when (limit < 1 || limit > 200) $
    throwBadRequest "limit must be between 1 and 200"
  (threadIdValid, mBeforeIdValid, mAfterIdValid) <-
    either throwError pure (validateChatMessageListLookup threadId mBeforeId mAfterId)
  let tid = toSqlKey threadIdValid :: ChatThreadId
  mThread <- runDB $ get tid
  thread <-
    case mThread of
      Nothing -> throwError err404
      Just t  -> pure t
  requireChatThreadParticipant user thread
  beforeCursorKey <- resolveChatMessageCursorInThread tid "beforeId" mBeforeIdValid
  afterCursorKey <- resolveChatMessageCursorInThread tid "afterId" mAfterIdValid
  let baseFilters = [ChatMessageThreadId ==. tid]
  messages <- runDB $
    case (beforeCursorKey, afterCursorKey) of
      (Just beforeKey, Nothing) -> do
        rows <- selectList (baseFilters ++ [ChatMessageId <. beforeKey]) [Desc ChatMessageId, LimitTo limit]
        pure (reverse rows)
      (Nothing, Just afterKey) -> do
        selectList (baseFilters ++ [ChatMessageId >. afterKey]) [Asc ChatMessageId, LimitTo limit]
      _ -> do
        rows <- selectList baseFilters [Desc ChatMessageId, LimitTo limit]
        pure (reverse rows)
  pure (map chatMessageToDTO messages)

resolveChatMessageCursorInThread
  :: ChatThreadId
  -> Text
  -> Maybe Int64
  -> AppM (Maybe ChatMessageId)
resolveChatMessageCursorInThread _ _ Nothing = pure Nothing
resolveChatMessageCursorInThread threadKey fieldName (Just rawCursorId) = do
  let cursorKey = toSqlKey rawCursorId :: ChatMessageId
  mCursor <- runDB $ get cursorKey
  case mCursor of
    Just ChatMessage{chatMessageThreadId}
      | chatMessageThreadId == threadKey -> pure (Just cursorKey)
    _ ->
      throwError err404
        { errBody = BL.fromStrict (TE.encodeUtf8 (fieldName <> " not found in this thread"))
        }

chatSendMessage :: AuthedUser -> Int64 -> ChatSendMessageRequest -> AppM ChatMessageDTO
chatSendMessage user threadId ChatSendMessageRequest{..} = do
  bodyClean <- either throwError pure (validateChatSendMessageBody csmBody)
  threadIdValid <- either throwError pure (validatePositiveIdField "threadId" threadId)
  let tid = toSqlKey threadIdValid :: ChatThreadId
      me  = auPartyId user
  mThread <- runDB $ get tid
  thread <-
    case mThread of
      Nothing -> throwError err404
      Just t  -> pure t
  requireChatThreadParticipant user thread
  let otherKey =
        if chatThreadDmPartyA thread == me
          then chatThreadDmPartyB thread
          else chatThreadDmPartyA thread
  ensureCanChatWith user otherKey
  now <- liftIO getCurrentTime
  mid <- runDB $ do
    mid' <- insert ChatMessage
      { chatMessageThreadId = tid
      , chatMessageSenderPartyId = me
      , chatMessageBody = bodyClean
      , chatMessageCreatedAt = now
      }
    update tid [ChatThreadUpdatedAt =. now]
    pure mid'
  pure
    ChatMessageDTO
      { cmId = fromSqlKey mid
      , cmThreadId = fromSqlKey tid
      , cmSenderPartyId = fromSqlKey me
      , cmBody = bodyClean
      , cmCreatedAt = now
      }

-- Social graph (party <-> party follows)
socialListFollowers :: AuthedUser -> AppM [PartyFollowDTO]
socialListFollowers user = do
  Env pool _ <- ask
  liftIO $ flip runSqlPool pool $ do
    rows <- selectList [PartyFollowFollowingPartyId ==. auPartyId user] [Desc PartyFollowCreatedAt]
    partyFollowEntitiesToDTO rows

socialListFollowing :: AuthedUser -> AppM [PartyFollowDTO]
socialListFollowing user = do
  Env pool _ <- ask
  liftIO $ flip runSqlPool pool $ do
    rows <- selectList [PartyFollowFollowerPartyId ==. auPartyId user] [Desc PartyFollowCreatedAt]
    partyFollowEntitiesToDTO rows

socialListFriends :: AuthedUser -> AppM [PartyFollowDTO]
socialListFriends user = do
  Env pool _ <- ask
  liftIO $ flip runSqlPool pool $ do
    following <- selectList [PartyFollowFollowerPartyId ==. auPartyId user] []
    let otherIds = map (partyFollowFollowingPartyId . entityVal) following
    reverseRows <- if null otherIds
      then pure []
      else selectList
             [ PartyFollowFollowerPartyId <-. otherIds
             , PartyFollowFollowingPartyId ==. auPartyId user
             ] []
    let mutualIds = Set.fromList (map (partyFollowFollowerPartyId . entityVal) reverseRows)
        mutual = filter (\(Entity _ pf) -> partyFollowFollowingPartyId pf `Set.member` mutualIds) following
    partyFollowEntitiesToDTO mutual

-- Suggest friends-of-friends that are not already connected to the user.
socialListSuggestedFriends :: AuthedUser -> AppM [SuggestedFriendDTO]
socialListSuggestedFriends user = do
  Env pool _ <- ask
  liftIO $ flip runSqlPool pool $ do
    following <- selectList [PartyFollowFollowerPartyId ==. auPartyId user] []
    followers <- selectList [PartyFollowFollowingPartyId ==. auPartyId user] []
    let followingIds = map (partyFollowFollowingPartyId . entityVal) following
        followerIds  = map (partyFollowFollowerPartyId . entityVal) followers
        directSet    = Set.fromList (auPartyId user : followingIds ++ followerIds)
        seeds        = Set.toList (Set.delete (auPartyId user) directSet)
    if null seeds
      then pure []
      else do
        secondDegree <- selectList [PartyFollowFollowerPartyId <-. seeds] []
        let counts = foldl' (\acc (Entity _ pf) ->
                              let candidate = partyFollowFollowingPartyId pf
                              in if Set.member candidate directSet
                                   then acc
                                   else Map.insertWith (+) candidate 1 acc
                            ) Map.empty secondDegree
            ordered = take 20 $ sortOn (Down . snd) (Map.toList counts)
        pure
          [ SuggestedFriendDTO
              { sfPartyId = fromSqlKey candidateId
              , sfMutualCount = mutuals
              }
          | (candidateId, mutuals) <- ordered
          ]

socialAddFriend :: AuthedUser -> Int64 -> AppM [PartyFollowDTO]
socialAddFriend = SocialWrites.addFriend

socialRemoveFriend :: AuthedUser -> Int64 -> AppM NoContent
socialRemoveFriend = SocialWrites.removeFriend

vcardExchange :: AuthedUser -> VCardExchangeRequest -> AppM [PartyFollowDTO]
vcardExchange = SocialWrites.exchangeVCard

resolveSocialTargetPartyId :: Int64 -> SqlPersistT IO (Either ServerError PartyId)
resolveSocialTargetPartyId rawPartyId =
  case validatePositiveIdField "partyId" rawPartyId of
    Left err -> pure (Left err)
    Right partyId -> do
      let targetKey = toSqlKey partyId :: PartyId
      mTarget <- get targetKey
      pure $
        case mTarget of
          Nothing -> Left err404 { errBody = "Party not found" }
          Just _ -> Right targetKey

socialListProfiles :: AuthedUser -> [Int64] -> AppM [SocialPartyProfileDTO]
socialListProfiles _ rawPartyIds = do
  partyIds <- either throwError pure (validateSocialProfilePartyIds rawPartyIds)
  if null partyIds
    then pure []
    else do
      Env pool _ <- ask
      liftIO $ flip runSqlPool pool $ loadSocialPartyProfilesDTO partyIds

maxSocialProfilePartyIds :: Int
maxSocialProfilePartyIds = 100

validateSocialProfilePartyIds :: [Int64] -> Either ServerError [Int64]
validateSocialProfilePartyIds = SocialProfiles.validateProfileIds

socialGetProfile :: AuthedUser -> Int64 -> AppM SocialPartyProfileDTO
socialGetProfile _ partyId = do
  when (partyId <= 0) $ throwBadRequest "Invalid party id"
  Env pool _ <- ask
  mProfile <- liftIO $ flip runSqlPool pool $ loadSocialPartyProfileDTO (toSqlKey partyId)
  maybe (throwError err404) pure mProfile

requireFanAccess :: AuthedUser -> AppM ()
requireFanAccess = FanEffects.requireFanAccess

requireArtistAccess :: AuthedUser -> AppM ()
requireArtistAccess user@AuthedUser{..} = do
  unless (Artist `elem` auRoles || Artista `elem` auRoles || Admin `elem` auRoles) $
    throwError err403 { errBody = BL.fromStrict (TE.encodeUtf8 "Artist access required") }
  unless (hasCoherentAuthScope user) $
    throwError err403 { errBody = "Artist access requires coherent role grants" }

artistActivateOwnProfile :: AuthedUser -> AppM ArtistProfileDTO
artistActivateOwnProfile user = do
  unless (hasCoherentAuthScope user) $
    throwError err403 { errBody = "Artist activation requires a coherent account" }
  Env pool _ <- ask
  now <- liftIO getCurrentTime
  result <- liftIO $ flip runSqlPool pool $ activateOwnArtistProfile (auPartyId user) now
  either (\message -> throwError err403 { errBody = BL.fromStrict (TE.encodeUtf8 message) }) pure result

artistGetOwnProfile :: AuthedUser -> AppM ArtistProfileDTO
artistGetOwnProfile user = do
  requireArtistAccess user
  Env pool _ <- ask
  liftIO $ flip runSqlPool pool $ loadOrCreateArtistProfileDTO (auPartyId user)

artistUpdateOwnProfile :: AuthedUser -> ArtistProfileUpsert -> AppM ArtistProfileDTO
artistUpdateOwnProfile user payload = do
  requireArtistAccess user
  let artistKey = auPartyId user
      sanitized = payload { apuArtistId = fromSqlKey artistKey }
  validated <- either throwBadRequest pure (validateArtistProfileUpsert sanitized)
  Env pool _ <- ask
  now <- liftIO getCurrentTime
  result <- liftIO $ flip runSqlPool pool $ upsertArtistProfileRecord artistKey validated now
  either throwBadRequest pure result

artistUpdateOwnPhoto :: AuthedUser -> ArtistProfilePhotoUpdate -> AppM ArtistProfileDTO
artistUpdateOwnPhoto user ArtistProfilePhotoUpdate{..} = do
  requireArtistAccess user
  let heroImageUrl = T.strip aphuHeroImageUrl
  when (T.null heroImageUrl) $
    throwBadRequest "heroImageUrl is required"
  current <- artistGetOwnProfile user
  let payload = ArtistProfileUpsert
        { apuArtistId = fromSqlKey (auPartyId user)
        , apuDisplayName = Just (apDisplayName current)
        , apuSlug = apSlug current
        , apuBio = apBio current
        , apuCity = apCity current
        , apuHeroImageUrl = Just heroImageUrl
        , apuSpotifyArtistId = apSpotifyArtistId current
        , apuSpotifyUrl = apSpotifyUrl current
        , apuYoutubeChannelId = apYoutubeChannelId current
        , apuYoutubeUrl = apYoutubeUrl current
        , apuWebsiteUrl = apWebsiteUrl current
        , apuFeaturedVideoUrl = apFeaturedVideoUrl current
        , apuGenreIds = apGenreIds current
        , apuHighlights = apHighlights current
        }
  artistUpdateOwnProfile user payload

-- ============================================================================
-- Notifications
-- ============================================================================

notifList :: AuthedUser -> Maybe Bool -> AppM [NotificationDTO]
notifList user mUnreadOnly = do
  result <- runDB $ InteractionNotifications.notificationRows user (mUnreadOnly == Just True) Nothing
  rows <- either throwError pure result
  pure (map notificationToDTO rows)

notifGet :: AuthedUser -> Int64 -> AppM NotificationDTO
notifGet user ident = do
  result <- runDB $ InteractionNotifications.notificationRows user False (Just ident)
  rows <- either throwError pure result
  case rows of
    [entity] -> pure (notificationToDTO entity)
    _ -> throwError err404

notificationToDTO :: Entity Notification -> NotificationDTO
notificationToDTO (Entity nid n) = NotificationDTO
      { nId = fromSqlKey nid
      , nType = notificationNotifType n
      , nTitle = notificationTitle n
      , nBody = notificationBody n
      , nTargetType = notificationTargetType n
      , nTargetId = fmap fromIntegral (notificationTargetId n)
      , nTargetKey = notificationTargetKey n
      , nIsRead = notificationIsRead n
      , nCreatedAt = notificationCreatedAt n
      }

notifCount :: AuthedUser -> AppM NotificationCountDTO
notifCount user = do
  result <- runDB $ InteractionNotifications.notificationUnreadCount user
  cnt <- either throwError pure result
  pure NotificationCountDTO { ncUnread = cnt }

notifMarkRead :: AuthedUser -> Int64 -> AppM NoContent
notifMarkRead user notifId = do
  Env pool _ <- ask
  liftIO $ flip runSqlPool pool $
    updateWhere
      [ NotificationId ==. toSqlKey notifId
      , NotificationRecipientPartyId ==. auPartyId user
      ]
      [NotificationIsRead =. True]
  pure NoContent

notifMarkAllRead :: AuthedUser -> AppM NoContent
notifMarkAllRead user = do
  Env pool _ <- ask
  liftIO $ flip runSqlPool pool $
    updateWhere
      [ NotificationRecipientPartyId ==. auPartyId user
      , NotificationIsRead ==. False
      ]
      [NotificationIsRead =. True]
  pure NoContent

-- ============================================================================
-- Discovery Feed
-- ============================================================================

discoveryFeed :: AuthedUser -> Maybe Int -> AppM [FanClubFeedItemDTO]
discoveryFeed user mLimit = do
  Env pool _ <- ask
  liftIO $ flip runSqlPool pool $ do
    let lim = min 50 (fromMaybe 20 mLimit)
    boosted <- selectList [] [Desc BoostedContentBoostedAt, LimitTo lim]
    items <- forM boosted $ \(Entity _ bc) -> do
      case boostedContentTargetType bc of
        "post" -> do
          let postKey = toSqlKey (fromIntegral (boostedContentTargetId bc)) :: FanClubPostId
          readable <- InteractionLegacy.visible (auPartyId user) "club_post" (T.pack (show (fromSqlKey postKey)))
          mPost <- if readable then get postKey else pure Nothing
          case mPost of
            Nothing -> pure Nothing
            Just p -> do
              reactions <- buildFanClubPostReactionSummary postKey (auPartyId user)
              mParty <- get (fanClubPostFanPartyId p)
              let authorName = maybe "Desconocido" M.partyDisplayName mParty
              pure $ Just FanClubFeedItemDTO
                { fcfId = fromIntegral (boostedContentTargetId bc)
                , fcfKind = "post"
                , fcfTitle = fanClubPostTitle p
                , fcfContent = fanClubPostContent p
                , fcfAuthorId = fromSqlKey (fanClubPostFanPartyId p)
                , fcfAuthorName = authorName
                , fcfAvatarUrl = Nothing
                , fcfMediaUrls = maybe [] (T.splitOn ",") (fanClubPostMediaUrls p)
                , fcfIsPinned = False
                , fcfIsOfficer = False
                , fcfIsHidden = False
                , fcfReactions = reactions
                , fcfCreatedAt = fanClubPostCreatedAt p
                }
        _ -> pure Nothing
    pure (catMaybes items)

loadFanProfileDTO :: PartyId -> SqlPersistT IO FanProfileDTO
loadFanProfileDTO fanId = do
  mProfile <- getBy (UniqueFanProfile fanId)
  party <- get fanId
  now <- liftIO getCurrentTime
  profileEntity <- case mProfile of
    Nothing -> do
      let displayName = M.partyDisplayName <$> party
          record = FanProfile
            { fanProfileFanPartyId     = fanId
            , fanProfileDisplayName    = displayName
            , fanProfileAvatarUrl      = Nothing
            , fanProfileFavoriteGenres = Nothing
            , fanProfileBio            = Nothing
            , fanProfileCity           = Nothing
            , fanProfileCreatedAt      = now
            , fanProfileUpdatedAt      = Nothing
            }
      key <- insert record
      pure (Entity key record)
    Just ent -> pure ent
  genreMemberships <- selectList
    [FanProfileGenreMembershipFanPartyId ==. fanId]
    [Asc FanProfileGenreMembershipSortOrder]
  let genreIds = map (fanProfileGenreMembershipGenreId . entityVal) genreMemberships
  genres <- if null genreIds
    then pure []
    else selectList [Catalog.GenreId <-. map Catalog.GenreKey genreIds] []
  let genreMap = Map.fromList
        [ (genreId, Catalog.genreNameEs genre)
        | Entity (Catalog.GenreKey genreId) genre <- genres
        ]
      favoriteGenres = mapMaybe
        (\(Entity _ membership) -> do
          let genreId = fanProfileGenreMembershipGenreId membership
          label <- Map.lookup genreId genreMap
          pure (genreId, label))
        genreMemberships
  let fallbackName = maybe Nothing (Just . M.partyDisplayName) party
  pure (fanProfileToDTO fallbackName favoriteGenres (entityVal profileEntity))

loadSocialPartyProfilesDTO :: [Int64] -> SqlPersistT IO [SocialPartyProfileDTO]
loadSocialPartyProfilesDTO rawIds = do
  let uniqueIds = nub rawIds
      partyKeys = map toSqlKey uniqueIds :: [PartyId]
  parties <- if null partyKeys then pure [] else selectList [PartyId <-. partyKeys] []
  profiles <- if null partyKeys then pure [] else selectList [FanProfileFanPartyId <-. partyKeys] []
  let partyMap = Map.fromList [(entityKey ent, ent) | ent <- parties]
      profileMap = Map.fromList [(fanProfileFanPartyId profile, profile) | Entity _ profile <- profiles]
  pure $ mapMaybe
    (\rawId -> do
      let partyKey = toSqlKey rawId :: PartyId
      partyEnt <- Map.lookup partyKey partyMap
      pure (toSocialPartyProfileDTO (Map.lookup partyKey profileMap) partyEnt)
    )
    uniqueIds

loadSocialPartyProfileDTO :: PartyId -> SqlPersistT IO (Maybe SocialPartyProfileDTO)
loadSocialPartyProfileDTO partyId = do
  mParty <- getEntity partyId
  case mParty of
    Nothing -> pure Nothing
    Just partyEnt -> do
      mProfile <- getBy (UniqueFanProfile partyId)
      pure (Just (toSocialPartyProfileDTO (entityVal <$> mProfile) partyEnt))

toSocialPartyProfileDTO :: Maybe FanProfile -> Entity Party -> SocialPartyProfileDTO
toSocialPartyProfileDTO mProfile (Entity partyId party) =
  SocialPartyProfileDTO
    { sppPartyId = fromSqlKey partyId
    , sppDisplayName =
        fromMaybe
          (M.partyDisplayName party)
          ( resolveFanProfileDisplayName
              (mProfile >>= fanProfileDisplayName)
              (Just (M.partyDisplayName party))
          )
    , sppAvatarUrl = mProfile >>= fanProfileAvatarUrl
    , sppBio = mProfile >>= fanProfileBio
    , sppCity = mProfile >>= fanProfileCity
    }

partyFollowEntitiesToDTO :: [Entity PartyFollow] -> SqlPersistT IO [PartyFollowDTO]
partyFollowEntitiesToDTO rows = do
  let partyIds = Set.toList . Set.fromList $ concatMap (\(Entity _ follow) ->
        [partyFollowFollowerPartyId follow, partyFollowFollowingPartyId follow]) rows
  parties <- if null partyIds then pure [] else selectList [PartyId <-. partyIds] []
  let names = Map.fromList
        [ (partyId, M.partyDisplayName party)
        | Entity partyId party <- parties
        ]
  pure (map (partyFollowEntityToDTO names) rows)

partyFollowEntityToDTO :: Map.Map PartyId Text -> Entity PartyFollow -> PartyFollowDTO
partyFollowEntityToDTO names (Entity _ pf) =
  PartyFollowDTO
    { pfFollowerId  = fromSqlKey (partyFollowFollowerPartyId pf)
    , pfFollowingId = fromSqlKey (partyFollowFollowingPartyId pf)
    , pfFollowerName = Map.lookup (partyFollowFollowerPartyId pf) names
    , pfFollowingName = Map.lookup (partyFollowFollowingPartyId pf) names
    , pfViaNfc      = partyFollowViaNfc pf
    , pfStartedAt   = utctDay (partyFollowCreatedAt pf)
    }


toArtistReleaseDTO :: Entity ArtistRelease -> ArtistReleaseDTO
toArtistReleaseDTO (Entity releaseId release) =
  ArtistReleaseDTO
    { arArtistId      = fromSqlKey (artistReleaseArtistPartyId release)
    , arReleaseId     = fromSqlKey releaseId
    , arTitle         = artistReleaseTitle release
    , arReleaseDate   = artistReleaseReleaseDate release
    , arDescription   = artistReleaseDescription release
    , arCoverImageUrl = artistReleaseCoverImageUrl release
    , arSpotifyUrl    = artistReleaseSpotifyUrl release
    , arYoutubeUrl    = artistReleaseYoutubeUrl release
    }

fanProfileToDTO :: Maybe Text -> [(UUID.UUID, Text)] -> FanProfile -> FanProfileDTO
fanProfileToDTO fallback favoriteGenres FanProfile{..} = FanProfileDTO
  { fpArtistId        = fromSqlKey fanProfileFanPartyId
  , fpDisplayName     = resolveFanProfileDisplayName fanProfileDisplayName fallback
  , fpAvatarUrl       = fanProfileAvatarUrl
  , fpFavoriteGenres  =
      if null favoriteGenres
        then fanProfileFavoriteGenres
        else Just (T.intercalate ", " (map snd favoriteGenres))
  , fpFavoriteGenreIds = map fst favoriteGenres
  , fpBio             = fanProfileBio
  , fpCity            = fanProfileCity
  }

resolveFanProfileDisplayName :: Maybe Text -> Maybe Text -> Maybe Text
resolveFanProfileDisplayName profileDisplayName fallback =
  cleanOptional profileDisplayName <|> cleanOptional fallback

fanFollowEntityToDTO
  :: Map.Map PartyId Text
  -> Map.Map PartyId ArtistProfile
  -> Entity FanFollow
  -> FanFollowDTO
fanFollowEntityToDTO nameMap profileMap (Entity _ follow) =
  let artistId = fanFollowArtistPartyId follow
      profile = Map.lookup artistId profileMap
  in FanFollowDTO
      { ffArtistId     = fromSqlKey artistId
      , ffArtistName   = Map.findWithDefault "Artista" artistId nameMap
      , ffHeroImageUrl = profile >>= artistProfileHeroImageUrl
      , ffSpotifyUrl   = profile >>= artistProfileSpotifyUrl
      , ffYoutubeUrl   = profile >>= artistProfileYoutubeUrl
      , ffStartedAt    = utctDay (fanFollowCreatedAt follow)
      }

loadFanFollowDTO :: PartyId -> PartyId -> SqlPersistT IO (Maybe FanFollowDTO)
loadFanFollowDTO fanId artistId = do
  mFollow <- selectFirst [FanFollowFanPartyId ==. fanId, FanFollowArtistPartyId ==. artistId] []
  case mFollow of
    Nothing -> pure Nothing
    Just followEnt -> do
      nameMap <- fetchPartyNameMap [artistId]
      profileMap <- fetchArtistProfileMap [artistId]
      pure $ Just (fanFollowEntityToDTO nameMap profileMap followEnt)

metaServer :: ServerT Meta.MetaAPI AppM
metaServer = hoistServer metaProxy lift Meta.metaServer
  where
    metaProxy = Proxy :: Proxy Meta.MetaAPI

academyServer :: ServerT AcademyAPI AppM
academyServer =
       microcourseH
  :<|> nextCohortH
  where
    microcourseH rawSlug = do
      slug <- requireSlug rawSlug
      mCourse <- runDB $ getBy (UniqueAcademyMicrocourseSlug slug)
      case mCourse of
        Nothing -> throwNotFound "Microcurso no disponible"
        Just (Entity courseId course) -> do
          lessons <- runDB $ selectList
            [AcademyLessonMicrocourseId ==. courseId]
            [Asc AcademyLessonDay]
          pure MicrocourseDTO
            { mcSlug    = academyMicrocourseSlug course
            , mcTitle   = academyMicrocourseTitle course
            , mcSummary = academyMicrocourseSummary course
            , lessons   = map lessonToDTO lessons
            }

    nextCohortH = do
      now <- liftIO getCurrentTime
      mCohort <- runDB $ selectFirst
        [CohortEndsAt >=. now]
        [Asc CohortStartsAt]
      cohortEnt <- maybe (throwNotFound "Sin cohortes activas") pure mCohort
      seatsTaken <- runDB $ count [CohortEnrollmentCohortId ==. entityKey cohortEnt]
      let cohort = entityVal cohortEnt
          remaining = max 0 (cohortSeatCap cohort - seatsTaken)
      pure NextCohortDTO
        { nextSlug      = cohortSlug cohort
        , nextTitle     = cohortTitle cohort
        , nextStartsAt  = cohortStartsAt cohort
        , nextEndsAt    = cohortEndsAt cohort
        , nextSeatCap   = cohortSeatCap cohort
        , nextSeatsLeft = remaining
        }

    lessonToDTO (Entity _ lesson) = LessonDTO
      { lessonDay   = academyLessonDay lesson
      , lessonTitle = academyLessonTitle lesson
      , lessonBody  = academyLessonBody lesson
      }

cleanOptional :: Maybe Text -> Maybe Text
cleanOptional Nothing = Nothing
cleanOptional (Just raw) =
  let trimmed = T.strip raw
  in if T.null trimmed then Nothing else Just trimmed

academyAccountServer :: AuthedUser -> ServerT AcademyAccountAPI AppM
academyAccountServer user =
       enrollH
  :<|> progressH
  :<|> claimReferralH
  where
    enrollH EnrollReq{..} = do
      normalizedEmail <- requireAcademyAccountEmail user email
      normalizedRole  <- requireRole role
      let platformClean = cleanOptional platform
      academyUser <- upsertAcademyUser normalizedEmail normalizedRole platformClean
      for_ (cleanOptional referralCode) $ \codeTxt ->
        claimReferral normalizedEmail (Just (entityKey academyUser)) codeTxt
      pure NoContent

    progressH ProgressReq{..} = do
      normalizedEmail <- requireAcademyAccountEmail user email
      courseSlug <- requireSlug slug
      dayNumber <- requireDay day
      mUser <- runDB $ getBy (UniqueAcademyUserEmail normalizedEmail)
      academyUser <- maybe (throwNotFound "Usuario no inscrito") pure mUser
      mCourse <- runDB $ getBy (UniqueAcademyMicrocourseSlug courseSlug)
      course <- maybe (throwNotFound "Microcurso no disponible") pure mCourse
      mLesson <- runDB $ selectFirst
        [ AcademyLessonMicrocourseId ==. entityKey course
        , AcademyLessonDay ==. dayNumber
        ]
        []
      lesson <- maybe (throwNotFound "Lección no encontrada") pure mLesson
      now <- liftIO getCurrentTime
      void $ runDB $ upsert
        (AcademyProgress (entityKey academyUser) (entityKey lesson) now)
        [AcademyProgressCompletedAt =. now]
      pure NoContent

    claimReferralH ReferralClaimReq{..} = do
      normalizedEmail <- requireAcademyAccountEmail user email
      mUser <- runDB $ getBy (UniqueAcademyUserEmail normalizedEmail)
      claimReferral normalizedEmail (entityKey <$> mUser) code
      pure NoContent

-- | The academy record belongs to the signed-in account's email. A request for
-- any other email is refused rather than silently rebound.
requireAcademyAccountEmail :: AuthedUser -> Text -> AppM Text
requireAcademyAccountEmail user suppliedRaw = do
  supplied <- requireEmail suppliedRaw
  mParty <- runDB $ get (auPartyId user)
  let accountEmail = T.toLower . T.strip <$> (mParty >>= partyPrimaryEmail)
  case accountEmail of
    Just account | not (T.null account) -> do
      unless (supplied == account) $
        throwError err403 { errBody = "email must match the signed-in account" }
      pure account
    _ -> throwError err409 { errBody = "The signed-in account has no email address" }

requireEmail :: Text -> AppM Text
requireEmail raw = do
  let normalized = T.toLower (T.strip raw)
  when (T.null normalized) (throwBadRequest "email requerido")
  pure normalized

requireRole :: Text -> AppM Text
requireRole raw = do
  either throwBadRequest pure (validateAcademyRole raw)

requireSlug :: Text -> AppM Text
requireSlug raw = do
  either throwBadRequest pure (validateAcademySlug raw)

requireDay :: Int -> AppM Int
requireDay n = do
  when (n <= 0) (throwBadRequest "day debe ser positivo")
  pure n

requireReferralCode :: Text -> AppM Text
requireReferralCode raw = do
  either throwBadRequest pure (validateAcademyReferralCode raw)

upsertAcademyUser :: Text -> Text -> Maybe Text -> AppM (Entity AcademyUser)
upsertAcademyUser emailVal roleVal platformVal = do
  now <- liftIO getCurrentTime
  runDB $ do
    mExisting <- getBy (UniqueAcademyUserEmail emailVal)
    case mExisting of
      Nothing -> do
        let record = AcademyUser emailVal roleVal platformVal now
        key <- insert record
        pure (Entity key record)
      Just (Entity key _) -> do
        update key
          [ AcademyUserRole =. roleVal
          , AcademyUserPlatform =. platformVal
          ]
        updated <- getJust key
        pure (Entity key updated)

claimReferral :: Text -> Maybe (Key AcademyUser) -> Text -> AppM ()
claimReferral emailVal mUser rawCode = do
  codeTxt <- requireReferralCode rawCode
  let codeKey = ReferralCodeKey codeTxt
  existing <- runDB $ get codeKey
  case existing of
    Nothing -> throwNotFound "Código de referido inválido"
    Just _  -> pure ()
  now <- liftIO getCurrentTime
  void $ runDB $ upsert
    ReferralClaim
      { referralClaimCodeId = codeKey
      , referralClaimClaimantUserId = mUser
      , referralClaimEmail = emailVal
      , referralClaimClaimedAt = now
      }
    [ ReferralClaimClaimantUserId =. mUser
    , ReferralClaimEmail =. emailVal
    , ReferralClaimClaimedAt =. now
    ]

throwNotFound :: Text -> AppM a
throwNotFound msg = throwError err404 { errBody = BL.fromStrict (TE.encodeUtf8 msg) }

seedTrigger :: Maybe Text -> AppM NoContent
seedTrigger rawToken = do
  requireSeedToken rawToken
  Env{..} <- ask
  liftIO $ flip runSqlPool envPool seedAll
  pure NoContent

-- Parties
partyServer :: AuthedUser -> ServerT PartyAPI AppM
partyServer user = listParties user :<|> createParty user :<|> searchParties user :<|> partyById
  where
    partyById pid = getParty user pid :<|> updateParty user pid :<|> partyRelated user pid

-- Selector search is intentionally separate from the CRM list endpoint.  Its
-- payload excludes contact information and queries are bounded so it cannot be
-- used as a directory-enumeration primitive.
searchParties
  :: AuthedUser
  -> Maybe Text
  -> Maybe Text
  -> Maybe Text
  -> Maybe Text
  -> Maybe Bool
  -> [Int64]
  -> Maybe Int64
  -> Maybe Int
  -> AppM PartySelectorPageDTO
searchParties user rawQuery rawContext rawScopeId rawKind accountOnly excluded rawCursor rawLimit
  | (T.toLower . T.strip <$> rawContext) == Just "interaction_mention" = do
      queryText <- either throwError pure (validatePartySelectorQuery rawQuery)
      limit <- either throwError pure (validatePartySelectorLimit rawLimit)
      scope <- maybe (throwError err400 {errBody="scopeId is required"}) pure rawScopeId
      DirectoryServer.consumeRate user "party_selector:interaction_mention" 300
      InteractionsServer.searchMentions user scope queryText rawCursor (Just limit)
  | otherwise = searchPartiesStandard user rawQuery rawContext rawScopeId rawKind accountOnly excluded rawCursor rawLimit

searchPartiesStandard
  :: AuthedUser -> Maybe Text -> Maybe Text -> Maybe Text -> Maybe Text -> Maybe Bool -> [Int64] -> Maybe Int64 -> Maybe Int
  -> AppM PartySelectorPageDTO
searchPartiesStandard user rawQuery rawContext rawScopeId rawKind accountOnly excluded rawCursor rawLimit = do
  query <- either throwError pure (validatePartySelectorQuery rawQuery)
  context <- either throwError pure (validatePartySelectorContext rawContext)
  for_ (partySelectorContextModule context) (requireModule user)
  when (context `elem` ["event_invitation", "social_connection"]) $
    DirectoryServer.consumeRate user ("party_selector:" <> context) 300
  kind <- either throwError pure (validatePartySelectorKind rawKind)
  cursor <- either throwError pure (traverse validatePartySelectorCursor rawCursor)
  limit <- either throwError pure (validatePartySelectorLimit rawLimit)
  when (length excluded > 100 || any (<= 0) excluded) $
    throwError err400 { errBody = "excludePartyId must contain at most 100 positive ids" }
  Env pool _ <- ask
  scopeId <- either throwError pure (validatePartySelectorScopeId context rawScopeId)
  for_ scopeId $ \eventId -> when (context == "event_logistics") $ do
    allowed <- liftIO $ flip runSqlPool pool $
      canSearchEventLogisticsParties (auPartyId user) (toSqlKey eventId)
    unless allowed $
      throwError err403 { errBody = "Event logistics selector access denied" }
  let publicDiscovery = isPublicPartySelectorContext context
      databaseTerms = partySelectorTerms query
      discoveryTerm = normalizePartySelectorLookupText $ fromMaybe query
        (listToMaybe (sortOn (Down . T.length) databaseTerms))
      -- Three characters let PostgreSQL use pg_trgm for normal searches. The
      -- documented two-character minimum remains supported by the bounded
      -- expression-index fallback.
      discoveryPrefixLength = min 3 (T.length discoveryTerm)
      patternText = "%" <> T.take discoveryPrefixLength discoveryTerm <> "%"
      exactText = normalizePartySelectorLookupText query
      normalizedDisplayName = "regexp_replace(translate(lower(display_name), 'áàäâéèëêíìïîóòöôúùüûñ', 'aaaaeeeeiiiioooouuuun'), '[@''’‘_.[:space:]-]+', '', 'g')"
      normalizedLegalName = "regexp_replace(translate(lower(COALESCE(legal_name, '')), 'áàäâéèëêíìïîóòöôúùüûñ', 'aaaaeeeeiiiioooouuuun'), '[@''’‘_.[:space:]-]+', '', 'g')"
      normalizedUsername = partySelectorNormalizedUsernameSql
      nameSql
        | publicDiscovery =
            "SELECT ?? FROM party WHERE NOT EXISTS (SELECT 1 FROM identity_party_archive a WHERE a.party_id=party.id) AND " <> normalizedDisplayName <> " LIKE ? ORDER BY CASE WHEN " <> normalizedDisplayName <> " = ? THEN 0 ELSE 1 END, id ASC LIMIT 401"
        | otherwise =
            "SELECT ?? FROM party WHERE NOT EXISTS (SELECT 1 FROM identity_party_archive a WHERE a.party_id=party.id) AND (" <> normalizedDisplayName <> " LIKE ? OR " <> normalizedLegalName <> " LIKE ?) ORDER BY CASE WHEN " <> normalizedDisplayName <> " = ? THEN 0 WHEN " <> normalizedLegalName <> " = ? THEN 1 ELSE 2 END, id ASC LIMIT 401"
      usernameSql =
        "SELECT ?? FROM user_credential WHERE id > 0 AND " <> normalizedUsername <> " LIKE ? AND active = TRUE ORDER BY CASE WHEN " <> normalizedUsername <> " = ? THEN 0 ELSE 1 END, id ASC LIMIT 401"
  (parties, credentials, fanProfiles, engineerPartyIds) <- liftIO $ flip runSqlPool pool $ do
    named <- rawSql nameSql
      (if publicDiscovery
        then [toPersistValue patternText, toPersistValue exactText]
        else [toPersistValue patternText, toPersistValue patternText, toPersistValue exactText, toPersistValue exactText])
    matchedCredentials <- rawSql usernameSql [toPersistValue patternText, toPersistValue exactText]
    let credentialPartyIds = nub
          [ userCredentialPartyId credential
          | Entity _ credential <- (matchedCredentials :: [Entity UserCredential])
          ]
    credentialParties <- if null credentialPartyIds
      then pure []
      else selectList [PartyId <-. credentialPartyIds] []
    let candidateMap = Map.fromList [(entityKey party, party) | party <- named ++ credentialParties]
        candidateIds = Map.keys candidateMap
    allCredentials <- if null candidateIds then pure [] else selectList [UserCredentialPartyId <-. candidateIds] []
    profiles <- if null candidateIds then pure [] else selectList [FanProfileFanPartyId <-. candidateIds] []
    eligibleEngineers <- if context == "booking_engineer"
      then Set.fromList <$> selectCanonicalPartyIdsByRole Engineer
      else pure Set.empty
    pure (Map.elems candidateMap, allCredentials, profiles, eligibleEngineers)
  let credentialsByParty = Map.fromListWith choosePartySelectorCredential
        [ (userCredentialPartyId credential, credential) | Entity _ credential <- credentials ]
      profilesByParty = Map.fromList
        [ (fanProfileFanPartyId profile, profile) | Entity _ profile <- fanProfiles ]
      effectiveKind
        | publicDiscovery || context == "booking_engineer" = "person"
        | otherwise = kind
      effectiveAccountOnly = publicDiscovery || fromMaybe False accountOnly
      matchesKind party = case effectiveKind of
        "person" -> not (partyIsOrg (entityVal party))
        "organization" -> partyIsOrg (entityVal party)
        _ -> True
      hasAccount party = case Map.lookup (entityKey party) credentialsByParty of
        Just credential -> userCredentialActive credential
        Nothing -> False
      isExcluded party = fromSqlKey (entityKey party) `elem` excluded
        || (publicDiscovery && entityKey party == auPartyId user)
      matchesQuery party =
        let partyValue = entityVal party
            rawUsername = userCredentialUsername <$> Map.lookup (entityKey party) credentialsByParty
            visibleLegalName = partySelectorVisibleLegalName context (partyLegalName partyValue)
        in partySelectorMatches query (M.partyDisplayName partyValue) visibleLegalName rawUsername
      eligible party =
        matchesKind party
          && matchesQuery party
          && not (isExcluded party)
          && (not effectiveAccountOnly || hasAccount party)
          && (context /= "booking_engineer" || Set.member (entityKey party) engineerPartyIds)
      option party =
        let mCredential = Map.lookup (entityKey party) credentialsByParty
            mProfile = Map.lookup (entityKey party) profilesByParty
            partyValue = entityVal party
            rawUsername = userCredentialUsername <$> mCredential
            visibleLegalName = partySelectorVisibleLegalName context (partyLegalName partyValue)
            accountState = case mCredential of
              Just credential | userCredentialActive credential -> "active"
              Just _ -> "inactive"
              Nothing -> "no-account"
            score = partySelectorScore query (M.partyDisplayName partyValue) visibleLegalName rawUsername
            secondary = visibleLegalName <|> (if partyIsOrg partyValue then Just "Organización" else Nothing)
        in (score, fromSqlKey (entityKey party), PartySelectorOptionDTO
          { partyId = fromSqlKey (entityKey party)
          , partyType = if partyIsOrg partyValue then "organization" else "person"
          , displayName = M.partyDisplayName partyValue
          , username = rawUsername
          , avatarUrl = mProfile >>= fanProfileAvatarUrl
          , secondaryLabel = secondary
          , accountStatus = accountState
          })
      sorted = sortOn (\(score, partyKey, _) -> (score, partyKey)) (map option (filter eligible parties))
      cursorOffset = fromIntegral (fromMaybe 0 cursor)
      page = take (limit + 1) (drop cursorOffset sorted)
      visible = take limit page
      next = if length page > limit then Just (fromIntegral (cursorOffset + limit)) else Nothing
  pure PartySelectorPageDTO { items = map (\(_, _, value) -> value) visible, nextCursor = next }

choosePartySelectorCredential :: UserCredential -> UserCredential -> UserCredential
choosePartySelectorCredential left right
  | credentialRank left <= credentialRank right = left
  | otherwise = right
  where
    credentialRank credential =
      (Down (userCredentialActive credential), normalizePartySelectorLookupText (userCredentialUsername credential))

-- Keep this expression byte-for-byte aligned with the active username indexes.
-- Candidate discovery must fold the same supported diacritics as the in-memory
-- matcher or valid username hits can be discarded before relevance ranking.
partySelectorNormalizedUsernameSql :: Text
partySelectorNormalizedUsernameSql =
  "regexp_replace(translate(lower(username), 'áàäâéèëêíìïîóòöôúùüûñ', 'aaaaeeeeiiiioooouuuun'), '[@''’‘_.[:space:]-]+', '', 'g')"

canSearchEventLogisticsParties :: MonadIO m => PartyId -> Social.SocialEventId -> SqlPersistT m Bool
canSearchEventLogisticsParties actorPartyId eventId = do
  mEvent <- get eventId
  case mEvent of
    Nothing -> pure False
    Just event -> do
      let actorText = T.pack (show (fromSqlKey actorPartyId))
      if Social.socialEventOrganizerPartyId event == Just actorText
        then pure True
        else do
          mMember <- getBy (Social.UniqueEventLogisticsMember eventId actorText)
          pure $ case mMember of
            Just (Entity _ member) -> Social.eventLogisticsMemberMemberRole member == "editor"
            Nothing -> False

validatePartySelectorQuery :: Maybe Text -> Either ServerError Text
validatePartySelectorQuery raw =
  let clean = T.strip (fromMaybe "" raw)
      searchableCharacters = T.length (T.filter isAlphaNum clean)
  in if T.length clean < 2 || searchableCharacters < 2
       then Left err400 { errBody = "q must contain at least two characters" }
       else if T.length clean > 120 || T.any isUnsafePartyDisplayNameChar clean
         then Left err400 { errBody = "q is invalid" }
         else Right clean

validatePartySelectorKind :: Maybe Text -> Either ServerError Text
validatePartySelectorKind raw =
  case T.toLower (T.strip (fromMaybe "any" raw)) of
    "any" -> Right "any"
    "person" -> Right "person"
    "organization" -> Right "organization"
    _ -> Left err400 { errBody = "kind must be any, person, or organization" }

validatePartySelectorContext :: Maybe Text -> Either ServerError Text
validatePartySelectorContext raw =
  let context = T.toLower (T.strip (fromMaybe "crm_assignment" raw))
      supported =
        [ "crm_assignment", "booking", "booking_engineer", "billing_contact", "artist_link"
        , "campaign_enrollment", "event_invitation", "social_connection"
        , "operations", "internal_feedback", "live_session", "event_logistics"
        ]
  in if context `elem` supported
      then Right context
      else Left err400 { errBody = "context is invalid" }

isPublicPartySelectorContext :: Text -> Bool
isPublicPartySelectorContext context = context `elem` ["event_invitation", "social_connection"]

partySelectorContextModule :: Text -> Maybe ModuleAccess
partySelectorContextModule context = case context of
  "crm_assignment" -> Just ModuleCRM
  "booking" -> Just ModuleScheduling
  "booking_engineer" -> Just ModuleScheduling
  "billing_contact" -> Just ModuleInvoicing
  "artist_link" -> Just ModuleCatalog
  "campaign_enrollment" -> Just ModuleCRM
  "operations" -> Just ModuleOps
  "internal_feedback" -> Just ModuleInternships
  "live_session" -> Just ModuleScheduling
  "event_invitation" -> Nothing
  "social_connection" -> Nothing
  "event_logistics" -> Nothing
  _ -> Just ModuleCRM

validatePartySelectorScopeId :: Text -> Maybe Text -> Either ServerError (Maybe Int64)
validatePartySelectorScopeId context rawScopeId =
  case (context, T.strip <$> rawScopeId) of
    ("event_logistics", Just rawId)
      | Just eventId <- readMaybe (T.unpack rawId), eventId > 0 -> Right (Just eventId)
      | otherwise -> invalid "scopeId must be a positive event id for event_logistics"
    ("event_logistics", Nothing) -> invalid "scopeId is required for event_logistics"
    (_, Just rawId) | not (T.null rawId) -> invalid "scopeId is not supported for this context"
    _ -> Right Nothing
  where
    invalid message = Left err400 { errBody = BL.fromStrict (TE.encodeUtf8 message) }

partySelectorVisibleLegalName :: Text -> Maybe Text -> Maybe Text
partySelectorVisibleLegalName context legalName
  | isPublicPartySelectorContext context = Nothing
  | otherwise = legalName

validatePartySelectorLimit :: Maybe Int -> Either ServerError Int
validatePartySelectorLimit raw =
  let value = fromMaybe 15 raw
  in if value >= 1 && value <= 20
       then Right value
       else Left err400 { errBody = "limit must be between 1 and 20" }

validatePartySelectorCursor :: Int64 -> Either ServerError Int64
validatePartySelectorCursor value
  | value > 0 && value <= 800 = Right value
  | otherwise = Left err400 { errBody = "cursor is invalid" }

partySelectorTerms :: Text -> [Text]
partySelectorTerms =
  filter (not . T.null)
    . T.words
    . T.map (\char -> if isAlphaNum char || char `elem` ("-'_." :: String) then char else ' ')
    . normalizePartySelectorDatabaseText

partySelectorWithinOneEdit :: Text -> Text -> Bool
partySelectorWithinOneEdit left right
  | left == right = True
  | abs (length leftChars - length rightChars) > 1 = False
  | length leftChars == length rightChars =
      length mismatches <= 1 || adjacentTransposition mismatches
  | length leftChars + 1 == length rightChars = oneInsertion leftChars rightChars
  | otherwise = oneInsertion rightChars leftChars
  where
    leftChars = T.unpack left
    rightChars = T.unpack right
    mismatches = [index | (index, (a, b)) <- zip [0 :: Int ..] (zip leftChars rightChars), a /= b]
    adjacentTransposition [first, second] =
      second == first + 1
        && leftChars !! first == rightChars !! second
        && leftChars !! second == rightChars !! first
    adjacentTransposition _ = False
    oneInsertion shorter longer = go shorter longer False
      where
        go [] _ _ = True
        go _ [] _ = False
        go short@(a:as) (b:bs) skipped
          | a == b = go as bs skipped
          | skipped = False
          | otherwise = go short bs True

partySelectorTermMatches :: Text -> Text -> Bool
partySelectorTermMatches queryTerm candidateTerm =
  queryTerm `T.isInfixOf` candidateTerm
    || (T.length queryTerm >= 4 && partySelectorWithinOneEdit queryTerm candidateTerm)

partySelectorMatches :: Text -> Text -> Maybe Text -> Maybe Text -> Bool
partySelectorMatches query displayName legalName username =
  let queryTerms = partySelectorTerms query
      candidateTerms = partySelectorTerms
        (T.intercalate " " [displayName, fromMaybe "" legalName, fromMaybe "" username])
  in not (null queryTerms)
      && all (\queryTerm -> any (partySelectorTermMatches queryTerm) candidateTerms) queryTerms

partySelectorScore :: Text -> Text -> Maybe Text -> Maybe Text -> Int
partySelectorScore query displayName legalName username
  | normalizedUsername == normalizedQuery = 0
  | normalizedName == normalizedQuery = 1
  | normalizedQuery `T.isPrefixOf` normalizedUsername = 2
  | any (\queryTerm -> any (queryTerm `T.isPrefixOf`) nameTerms) queryTerms = 3
  | all (\queryTerm -> any (queryTerm `T.isPrefixOf`) allTerms) queryTerms = 4
  | all (\queryTerm -> any (queryTerm `T.isInfixOf`) allTerms) queryTerms = 5
  | otherwise = 6
  where
    normalizedQuery = normalizePartySelectorText query
    normalizedName = normalizePartySelectorText displayName
    normalizedUsername = normalizePartySelectorText (fromMaybe "" username)
    queryTerms = partySelectorTerms query
    nameTerms = partySelectorTerms (T.intercalate " " [displayName, fromMaybe "" legalName])
    allTerms = nameTerms ++ partySelectorTerms (fromMaybe "" username)

normalizePartySelectorText :: Text -> Text
normalizePartySelectorText = normalizePartySelectorLookupText

normalizePartySelectorDatabaseText :: Text -> Text
normalizePartySelectorDatabaseText = T.map replaceAccent . T.toLower . T.filter (/= '@')
  where
    replaceAccent char = case char of
      'á' -> 'a'; 'à' -> 'a'; 'ä' -> 'a'; 'â' -> 'a'
      'é' -> 'e'; 'è' -> 'e'; 'ë' -> 'e'; 'ê' -> 'e'
      'í' -> 'i'; 'ì' -> 'i'; 'ï' -> 'i'; 'î' -> 'i'
      'ó' -> 'o'; 'ò' -> 'o'; 'ö' -> 'o'; 'ô' -> 'o'
      'ú' -> 'u'; 'ù' -> 'u'; 'ü' -> 'u'; 'û' -> 'u'
      'ñ' -> 'n'
      other -> other

normalizePartySelectorLookupText :: Text -> Text
normalizePartySelectorLookupText = T.filter isAlphaNum . normalizePartySelectorDatabaseText

listParties :: AuthedUser -> Maybe Int -> Maybe Int -> AppM [PartyDTO]
listParties user mLimit mOffset = do
  requireModule user ModuleCRM
  Env pool _ <- ask
  (limit, offset) <- either throwError pure (validatePartyListPagination mLimit mOffset)
  (entities, accountIds) <- liftIO $ flip runSqlPool pool $ do
    parts <- rawSql "SELECT ?? FROM party WHERE NOT EXISTS (SELECT 1 FROM identity_party_archive a WHERE a.party_id=party.id) ORDER BY id LIMIT ? OFFSET ?" [toPersistValue limit, toPersistValue offset]
    let partyIds = map entityKey parts
    creds <- selectList [UserCredentialPartyId <-. partyIds] []
    let accountSet = Set.fromList (map (userCredentialPartyId . entityVal) creds)
    pure (parts, accountSet)
  pure (map (\ent -> toPartyDTO (Set.member (entityKey ent) accountIds) ent) entities)

createParty :: AuthedUser -> Maybe Text -> PartyCreate -> AppM PartyDTO
createParty user requestKey req = do
  requireModule user ModuleCRM
  when (isNothing requestKey) $
    throwError err400 { errBody = "Update the app or refresh the contact form before creating a contact so retries can be saved safely." }
  for_ requestKey $ \key ->
    unless (T.length key >= 16 && T.length key <= 128 && T.all (\ch -> ch <= '\x7f' && (isAlphaNum ch || ch == '-' || ch == '_')) key) $
      throwError err400 { errBody = "Idempotency-Key must contain 16-128 ASCII letters, digits, hyphens or underscores" }
  displayNameVal <- either throwError pure (validatePartyDisplayName (cDisplayName req))
  primaryEmailVal <- either throwError pure (validatePartyPrimaryEmail (cPrimaryEmail req))
  Env pool _ <- ask
  result <- liftIO $ try $ flip runSqlPool pool $ case requestKey of
    Nothing -> pure Nothing
    Just key -> do
      let body = object
            [ "display_name" .= displayNameVal, "legal_name" .= cLegalName req
            , "is_org" .= cIsOrg req, "tax_id" .= cTaxId req
            , "primary_email" .= primaryEmailVal, "primary_phone" .= cPrimaryPhone req
            , "whatsapp" .= cWhatsapp req, "instagram" .= cInstagram req
            , "emergency_contact" .= cEmergencyContact req, "notes" .= cNotes req
            ]
      ids <- rawSql "SELECT identity_create_contact(?, ?, ?::jsonb)"
        [toPersistValue (auPartyId user), PersistText key, PersistText (TE.decodeUtf8 (BL.toStrict (encode body)))]
      case ids of
        [Single pid] -> getEntity (toSqlKey pid :: PartyId)
        _ -> pure Nothing
  case result of
    Left sqlError
      | sqlState sqlError `elem` ["22023", "55000"] ->
          throwError err409 { errBody = "This contact request has changed or was archived. Review the contact before retrying." }
      | otherwise -> throwError err500 { errBody = "Contact creation failed" }
    Right Nothing -> throwError err500 { errBody = "Contact creation failed" }
    Right (Just ent) -> getParty user (fromSqlKey (entityKey ent))

getParty :: AuthedUser -> Int64 -> AppM PartyDTO
getParty user pidI = do
  requireModule user ModuleCRM
  pidValid <- either throwError pure (validatePositiveIdField "partyId" pidI)
  Env pool _ <- ask
  let pid = toSqlKey pidValid :: Key Party
  mp <- liftIO $ flip runSqlPool pool $ do
    mappings <- rawSql "SELECT canonical_party_id FROM identity_party_archive WHERE party_id=?" [toPersistValue pid]
    case mappings of
      [Single canonicalId] -> getEntity (toSqlKey canonicalId)
      _ -> getEntity pid
  case mp of
    Nothing -> throwError err404
    Just ent -> do
      bandDetails <- liftIO $ flip runSqlPool pool $ loadBandForParty (entityKey ent)
      hasAccount <- liftIO $ flip runSqlPool pool $
        fmap isJust (selectFirst [UserCredentialPartyId ==. entityKey ent] [])
      pure (toPartyDTOWithBand bandDetails hasAccount ent)

updateParty :: AuthedUser -> Int64 -> PartyUpdate -> AppM PartyDTO
updateParty user pidI req = do
  requireModule user ModuleCRM
  pidValid <- either throwError pure (validatePositiveIdField "partyId" pidI)
  displayNameUpdate <- either throwError pure (validatePartyDisplayNameUpdate (uDisplayName req))
  primaryEmailUpdate <- either throwError pure (validatePartyPrimaryEmailUpdate (uPrimaryEmail req))
  Env pool _ <- ask
  let pid = toSqlKey pidValid :: Key Party
  result <- liftIO $ try $ flip runSqlPool pool $ do
    mp <- get pid
    case mp of
      Nothing -> pure ()
      Just p -> do
        let p' = p
              { partyLegalName        = maybe (partyLegalName p) Just (uLegalName req)
              , partyDisplayName      = fromMaybe (M.partyDisplayName p) displayNameUpdate
              , partyIsOrg            = fromMaybe (partyIsOrg p)         (uIsOrg req)
              , partyTaxId            = maybe (partyTaxId p) Just       (uTaxId req)
              , partyPrimaryEmail     = fromMaybe (partyPrimaryEmail p) primaryEmailUpdate
              , partyPrimaryPhone     = maybe (partyPrimaryPhone p) Just (uPrimaryPhone req)
              , partyWhatsapp         = maybe (partyWhatsapp p) Just    (uWhatsapp req)
              , partyInstagram        = maybe (partyInstagram p) Just   (uInstagram req)
              , partyEmergencyContact = maybe (partyEmergencyContact p) Just (uEmergencyContact req)
              , partyNotes            = maybe (partyNotes p) Just       (uNotes req)
              }
        replace pid p'
  case result of
    Left sqlError
      | sqlState sqlError == "55000" ->
          throwError err409 { errBody = "This contact was archived. Open its current record before editing." }
      | otherwise -> throwError err500 { errBody = "Contact update failed" }
    Right () -> getParty user pidValid

validatePartyDisplayName :: Text -> Either ServerError Text
validatePartyDisplayName rawDisplayName =
  let displayNameVal = T.strip rawDisplayName
  in if T.null displayNameVal
       then Left err400 { errBody = "displayName must not be blank" }
       else if T.any isUnsafePartyDisplayNameChar displayNameVal
         then Left err400
           { errBody =
               "displayName must not contain control characters or hidden formatting characters"
           }
         else Right displayNameVal

validatePartyDisplayNameUpdate :: Maybe Text -> Either ServerError (Maybe Text)
validatePartyDisplayNameUpdate Nothing = Right Nothing
validatePartyDisplayNameUpdate (Just rawDisplayName) =
  Just <$> validatePartyDisplayName rawDisplayName

validatePartyPrimaryEmail :: Maybe Text -> Either ServerError (Maybe Text)
validatePartyPrimaryEmail rawEmail =
  case validateCourseRegistrationEmail rawEmail of
    Right emailVal -> Right emailVal
    Left _ -> Left err400 { errBody = "primaryEmail inválido" }

validatePartyPrimaryEmailUpdate :: Maybe Text -> Either ServerError (Maybe (Maybe Text))
validatePartyPrimaryEmailUpdate Nothing = Right Nothing
validatePartyPrimaryEmailUpdate (Just rawEmail) =
  Just <$> validatePartyPrimaryEmail (Just rawEmail)

isUnsafePartyDisplayNameChar :: Char -> Bool
isUnsafePartyDisplayNameChar ch =
  isControl ch
    || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

partyRelated :: AuthedUser -> Int64 -> AppM PartyRelatedDTO
partyRelated user pidI = do
  requireModule user ModuleCRM
  partyKey <- runDB (resolvePartyRelatedTarget pidI) >>= either throwError pure
  now <- liftIO getCurrentTime

  (asCustomer, asEngineer) <- runDB $ do
    customerRows <- selectList (bookingScopeFilters user ++ [BookingPartyId ==. Just partyKey]) [Desc BookingStartsAt, LimitTo 50]
    engineerRows <- selectList (bookingScopeFilters user ++ [BookingEngineerPartyId ==. Just partyKey]) [Desc BookingStartsAt, LimitTo 50]
    pure (customerRows, engineerRows)

  (studentSessions, teacherSessions, subjectMap, partyNameMap, bookingMap) <- runDB $ do
    studentRows <- selectList [Trials.ClassSessionStudentId ==. partyKey] [Desc Trials.ClassSessionStartAt, LimitTo 50]
    teacherRows <- selectList [Trials.ClassSessionTeacherId ==. partyKey] [Desc Trials.ClassSessionStartAt, LimitTo 50]
    let sessions = studentRows ++ teacherRows
        subjectIds = Set.toList $ Set.fromList $ map (Trials.classSessionSubjectId . entityVal) sessions
        teacherIds = Set.toList $ Set.fromList $ map (Trials.classSessionTeacherId . entityVal) sessions
        studentIds = Set.toList $ Set.fromList $ map (Trials.classSessionStudentId . entityVal) sessions
        bookingIds = catMaybes $ map (Trials.classSessionBookingId . entityVal) sessions

    subjects <- if null subjectIds
      then pure []
      else selectList [Trials.SubjectId <-. subjectIds] []
    let subjectsById = Map.fromList [ (entityKey e, entityVal e) | e <- subjects ]

    let partyIds = Set.toList (Set.fromList (teacherIds ++ studentIds))
    parties <- if null partyIds
      then pure []
      else selectList [PartyId <-. partyIds] []
    let partyNamesById = Map.fromList [ (entityKey e, M.partyDisplayName (entityVal e)) | e <- parties ]

    bookings <- if null bookingIds
      then pure []
      else selectList (bookingScopeFilters user ++ [BookingId <-. bookingIds]) []
    let bookingsById = Map.fromList [ (entityKey e, entityVal e) | e <- bookings ]

    pure (studentRows, teacherRows, subjectsById, partyNamesById, bookingsById)

  tracks <- runDB $
    selectList [ME.LabelTrackOwnerPartyId ==. Just partyKey] [Desc ME.LabelTrackUpdatedAt, LimitTo 100]

  let toRelatedBooking role (Entity bookingId booking) =
        PartyRelatedBooking
          { prbBookingId  = fromSqlKey bookingId
          , prbRole       = role
          , prbTitle      = bookingTitle booking
          , prbServiceType = bookingServiceType booking
          , prbStartsAt   = bookingStartsAt booking
          , prbEndsAt     = bookingEndsAt booking
          , prbStatus     = T.pack (show (bookingStatus booking))
          }

      classStatusLabel attended startAt mBooking =
        case bookingStatus <$> mBooking of
          Just Cancelled  -> "cancelada"
          Just NoShow     -> "cancelada"
          Just Completed  -> "realizada"
          Just Tentative  -> "por-confirmar"
          Just InProgress -> "programada"
          Just Confirmed  -> "programada"
          _ ->
            if attended
              then "realizada"
              else if startAt > now then "programada" else "por-confirmar"

      toRelatedClass role (Entity classSessionId cs) =
        let teacherId = Trials.classSessionTeacherId cs
            studentId = Trials.classSessionStudentId cs
            subjectId = Trials.classSessionSubjectId cs
            mBooking = Trials.classSessionBookingId cs >>= (`Map.lookup` bookingMap)
        in PartyRelatedClassSession
          { prcClassSessionId = fromSqlKey classSessionId
          , prcRole           = role
          , prcSubjectId      = fromSqlKey subjectId
          , prcSubjectName    = Trials.subjectName <$> Map.lookup subjectId subjectMap
          , prcTeacherId      = fromSqlKey teacherId
          , prcTeacherName    = Map.lookup teacherId partyNameMap
          , prcStudentId      = fromSqlKey studentId
          , prcStudentName    = Map.lookup studentId partyNameMap
          , prcStartAt        = Trials.classSessionStartAt cs
          , prcEndAt          = Trials.classSessionEndAt cs
          , prcStatus         = classStatusLabel (Trials.classSessionAttended cs) (Trials.classSessionStartAt cs) mBooking
          , prcBookingId      = if isJust mBooking then fromSqlKey <$> Trials.classSessionBookingId cs else Nothing
          }

      toRelatedTrack (Entity key t) =
        PartyRelatedLabelTrack
          { prtId        = toPathPiece key
          , prtTitle     = ME.labelTrackTitle t
          , prtStatus    = ME.labelTrackStatus t
          , prtCreatedAt = ME.labelTrackCreatedAt t
          , prtUpdatedAt = ME.labelTrackUpdatedAt t
          }

      bookingsOut =
        map (toRelatedBooking "cliente") asCustomer
          ++ map (toRelatedBooking "ingeniero") asEngineer

      classSessionsOut =
        map (toRelatedClass "estudiante") studentSessions
          ++ map (toRelatedClass "profesor") teacherSessions

  pure PartyRelatedDTO
    { prPartyId = fromSqlKey partyKey
    , prBookings = bookingsOut
    , prClassSessions = classSessionsOut
    , prLabelTracks = map toRelatedTrack tracks
    }

resolvePartyRelatedTarget :: Int64 -> SqlPersistT IO (Either ServerError PartyId)
resolvePartyRelatedTarget rawPartyId =
  case validatePositiveIdField "partyId" rawPartyId of
    Left err -> pure (Left err)
    Right partyId -> do
      let partyKey = toSqlKey partyId :: PartyId
      mParty <- get partyKey
      pure $
        case mParty of
          Nothing -> Left err404 { errBody = "Party not found" }
          Just _ -> Right partyKey

-- Service marketplace
serviceMarketplaceServer :: AuthedUser -> ServerT Api.ServiceMarketplaceAPI AppM
serviceMarketplaceServer user =
       listServiceAds
  :<|> createServiceAd user
  :<|> listServiceAdSlots
  :<|> createServiceAdSlot user
  :<|> createServiceMarketplaceBooking user
  :<|> completeServiceMarketplaceBooking user
  :<|> releaseServiceMarketplaceEscrow user

listServiceAds :: AppM [Api.ServiceAdDTO]
listServiceAds = do
  pool <- asks envPool
  liftIO $ flip runSqlPool pool $ do
    ads <- selectList [ServiceAdActive ==. True] [Desc ServiceAdCreatedAt]
    let providerIds = map (serviceAdProviderPartyId . entityVal) ads
    providers <- if null providerIds then pure [] else selectList [PartyId <-. providerIds] []
    let providerMap =
          Map.fromList
            [ ( entityKey p
              , normalizeOptionalInput (Just (M.partyDisplayName (entityVal p))) <|> M.partyLegalName (entityVal p)
              )
            | p <- providers
            ]
    pure $ map (toServiceAdDTO providerMap) ads

resolveServiceAdEntity :: Int64 -> SqlPersistT IO (Entity ServiceAd)
resolveServiceAdEntity rawAdId = do
  adId <- case validatePositiveIdField "adId" rawAdId of
    Left serverErr -> liftIO $ throwIO serverErr
    Right validAdId -> pure validAdId
  let adKey = toSqlKey adId :: Key ServiceAd
  mAd <- getEntity adKey
  maybe
    (liftIO $ throwIO err404 { errBody = "Service ad not found" })
    pure
    mAd

resolveServiceAdSlotEntity :: Int64 -> SqlPersistT IO (Entity ServiceAdSlot)
resolveServiceAdSlotEntity rawSlotId = do
  slotId <- case validatePositiveIdField "slotId" rawSlotId of
    Left serverErr -> liftIO $ throwIO serverErr
    Right validSlotId -> pure validSlotId
  let slotKey = toSqlKey slotId :: Key ServiceAdSlot
  mSlot <- getEntity slotKey
  maybe
    (liftIO $ throwIO err404 { errBody = "Service ad slot not found" })
    pure
    mSlot

resolveServiceMarketplaceBookingEntity :: Int64 -> SqlPersistT IO (Entity Booking)
resolveServiceMarketplaceBookingEntity rawBookingId = do
  bookingId <- case validatePositiveIdField "bookingId" rawBookingId of
    Left serverErr -> liftIO $ throwIO serverErr
    Right validBookingId -> pure validBookingId
  let bookingKey = toSqlKey bookingId :: Key Booking
  mBooking <- getEntity bookingKey
  maybe
    (liftIO $ throwIO err404 { errBody = "Service marketplace booking not found" })
    pure
    mBooking

createServiceAd :: AuthedUser -> Api.ServiceAdCreateReq -> AppM Api.ServiceAdDTO
createServiceAd user Api.ServiceAdCreateReq{..} = do
  when (T.null (T.strip sacRoleTag) || T.null (T.strip sacHeadline)) $
    throwError err400 { errBody = "roleTag and headline are required" }
  when (sacFeeCents <= 0) $ throwError err400 { errBody = "feeCents must be > 0" }
  catalogId <- either throwError pure (validateServiceAdCatalogId sacServiceCatalogId)
  cfg <- asks envConfig
  currency <- either throwError pure (validateServiceAdCurrency (sacCurrency <|> Just (defaultCurrency cfg)))
  unless (currency `elem` supportedCurrencies cfg) $
    throwError err400 { errBody = "Currency is not enabled by SUPPORTED_CURRENCIES" }
  slotMinutes <- either throwError pure (validateServiceAdSlotMinutes sacSlotMinutes)
  now <- liftIO getCurrentTime
  pool <- asks envPool
  let catalogKey = toSqlKey catalogId
  liftIO $ flip runSqlPool pool $ do
    mCatalog <- get catalogKey
    case validateServiceMarketplaceCatalog mCatalog of
      Left serverErr -> liftIO $ throwIO serverErr
      Right _ -> pure ()
  let record = ServiceAd
        { serviceAdProviderPartyId = auPartyId user
        , serviceAdServiceCatalogId = Just catalogKey
        , serviceAdRoleTag = T.strip sacRoleTag
        , serviceAdHeadline = T.strip sacHeadline
        , serviceAdDescription = normalizeOptionalInput sacDescription
        , serviceAdFeeCents = sacFeeCents
        , serviceAdCurrency = currency
        , serviceAdSlotMinutes = slotMinutes
        , serviceAdActive = True
        , serviceAdCreatedAt = now
        }
  dto <- liftIO $ flip runSqlPool pool $ do
    adId <- insert record
    ent <- getJustEntity adId
    mProvider <- get (auPartyId user)
    let providerName =
          mProvider >>= (\p -> normalizeOptionalInput (Just (M.partyDisplayName p)) <|> M.partyLegalName p)
    pure (toServiceAdDTO (Map.singleton (auPartyId user) providerName) ent)
  pure dto

listServiceAdSlots :: Int64 -> AppM [Api.ServiceAdSlotDTO]
listServiceAdSlots adId = do
  pool <- asks envPool
  liftIO $ flip runSqlPool pool $ do
    Entity adKey _ <- resolveServiceAdEntity adId
    slots <- selectList [ServiceAdSlotAdId ==. adKey] [Asc ServiceAdSlotStartsAt]
    pure (map toServiceAdSlotDTO slots)

createServiceAdSlot :: AuthedUser -> Int64 -> Api.ServiceAdSlotCreateReq -> AppM Api.ServiceAdSlotDTO
createServiceAdSlot user adId Api.ServiceAdSlotCreateReq{..} = do
  pool <- asks envPool
  liftIO $ flip runSqlPool pool $ do
    ad@(Entity adKey _) <- resolveServiceAdEntity adId
    when (serviceAdProviderPartyId (entityVal ad) /= auPartyId user) $
      liftIO $ throwIO err403
    case validateServiceAdSlotWindow (serviceAdSlotMinutes (entityVal ad)) sascStartsAt sascEndsAt of
      Left serverErr -> liftIO $ throwIO serverErr
      Right () -> pure ()
    now <- liftIO getCurrentTime
    slotId <- insert ServiceAdSlot
      { serviceAdSlotAdId = adKey
      , serviceAdSlotStartsAt = sascStartsAt
      , serviceAdSlotEndsAt = sascEndsAt
      , serviceAdSlotStatus = "open"
      , serviceAdSlotCreatedAt = now
      }
    slot <- getJustEntity slotId
    pure (toServiceAdSlotDTO slot)

createServiceMarketplaceBooking :: AuthedUser -> Api.ServiceMarketplaceBookingReq -> AppM Api.ServiceMarketplaceBookingDTO
-- SYS-ESCROW-001: nominal Payment rows are not evidence of held funds.
-- Keep the route fail-closed until a separately approved verified escrow flow exists.
createServiceMarketplaceBooking _ _ =
  throwError err503 { errBody = "Service marketplace booking is unavailable until verified escrow is supported" }

completeServiceMarketplaceBooking :: AuthedUser -> Int64 -> AppM Api.ServiceMarketplaceBookingDTO
completeServiceMarketplaceBooking user rawBookingId = do
  pool <- asks envPool
  liftIO $ flip runSqlPool pool $ do
    Entity bookingKey booking <- resolveServiceMarketplaceBookingEntity rawBookingId
    escrowEnt <- getBy (UniqueServiceEscrowBooking bookingKey)
    escrow <- either (liftIO . throwIO) pure (requireServiceEscrowForBooking escrowEnt)
    let canComplete = serviceEscrowProviderPartyId (entityVal escrow) == auPartyId user || hasRole Admin user
    when (not canComplete) $ liftIO $ throwIO err403
    case validateServiceMarketplaceCompletion (bookingStatus booking) (entityVal escrow) of
      Left serverErr -> liftIO $ throwIO serverErr
      Right () -> pure ()
    update bookingKey [BookingStatus =. Completed]
    update (serviceEscrowServiceOrderId (entityVal escrow)) [ServiceOrderStatus =. "performed"]
    pure (mkEscrowBookingDTO escrow)

requireServiceEscrowForBooking
  :: Maybe (Entity ServiceEscrow)
  -> Either ServerError (Entity ServiceEscrow)
requireServiceEscrowForBooking =
  maybe
    (Left err404 { errBody = "Service escrow not found for booking" })
    Right

validateServiceMarketplaceCompletion :: BookingStatus -> ServiceEscrow -> Either ServerError ()
validateServiceMarketplaceCompletion bookingStatusVal escrow
  | serviceEscrowStatus escrow /= "held" =
      Left err409 { errBody = "Escrow must be held before booking completion" }
  | bookingStatusVal == Confirmed || bookingStatusVal == InProgress =
      Right ()
  | otherwise =
      Left err409 { errBody = "Booking must be confirmed or in progress before marketplace completion" }

releaseServiceMarketplaceEscrow :: AuthedUser -> Int64 -> AppM Api.ServiceMarketplaceBookingDTO
-- SYS-ESCROW-002: completion or a nominal hold cannot authorize a payout.
releaseServiceMarketplaceEscrow _ _ =
  throwError err503 { errBody = "Service marketplace escrow release is unavailable until verified escrow is supported" }

escrowTransitionAllowed :: Text -> Text -> Bool
escrowTransitionAllowed "held" "released" = True
escrowTransitionAllowed "held" "refunded" = True
escrowTransitionAllowed fromState toState = fromState == toState

toServiceAdDTO :: Map.Map (Key Party) (Maybe Text) -> Entity ServiceAd -> Api.ServiceAdDTO
toServiceAdDTO providerMap (Entity adId ad) = Api.ServiceAdDTO
  { Api.sadId = fromSqlKey adId
  , Api.sadProviderPartyId = fromSqlKey (serviceAdProviderPartyId ad)
  , Api.sadProviderName = join (Map.lookup (serviceAdProviderPartyId ad) providerMap)
  , Api.sadServiceCatalogId = fromSqlKey <$> serviceAdServiceCatalogId ad
  , Api.sadRoleTag = serviceAdRoleTag ad
  , Api.sadHeadline = serviceAdHeadline ad
  , Api.sadDescription = serviceAdDescription ad
  , Api.sadFeeCents = serviceAdFeeCents ad
  , Api.sadCurrency = serviceAdCurrency ad
  , Api.sadSlotMinutes = serviceAdSlotMinutes ad
  , Api.sadActive = serviceAdActive ad
  , Api.sadCreatedAt = serviceAdCreatedAt ad
  }

toServiceAdSlotDTO :: Entity ServiceAdSlot -> Api.ServiceAdSlotDTO
toServiceAdSlotDTO (Entity slotId slot) = Api.ServiceAdSlotDTO
  { Api.sasId = fromSqlKey slotId
  , Api.sasAdId = fromSqlKey (serviceAdSlotAdId slot)
  , Api.sasStartsAt = serviceAdSlotStartsAt slot
  , Api.sasEndsAt = serviceAdSlotEndsAt slot
  , Api.sasStatus = serviceAdSlotStatus slot
  }

mkEscrowBookingDTO :: Entity ServiceEscrow -> Api.ServiceMarketplaceBookingDTO
mkEscrowBookingDTO (Entity escrowId escrow) = Api.ServiceMarketplaceBookingDTO
  { Api.smbBookingId = fromSqlKey (serviceEscrowBookingId escrow)
  , Api.smbServiceOrderId = fromSqlKey (serviceEscrowServiceOrderId escrow)
  , Api.smbEscrowId = fromSqlKey escrowId
  , Api.smbEscrowStatus = serviceEscrowStatus escrow
  , Api.smbEscrowAmountCents = serviceEscrowAmountCents escrow
  , Api.smbEscrowCurrency = serviceEscrowCurrency escrow
  }

parsePaymentMethodText :: Maybe Text -> Either ServerError PaymentMethod
parsePaymentMethodText Nothing = Right OtherM
parsePaymentMethodText (Just rawPaymentMethod)
  | T.any isControl rawPaymentMethod =
      Left err400 { errBody = "paymentMethod must not contain control characters" }
  | T.any isHiddenDriveOAuthTokenChar paymentMethod =
      Left err400 { errBody = "paymentMethod must not contain hidden formatting characters" }
  | T.null paymentMethod =
      Left err400 { errBody = "paymentMethod cannot be blank; omit paymentMethod to use other" }
  | otherwise =
      case T.toLower paymentMethod of
        "cash" -> Right CashM
        "bank_transfer" -> Right BankTransferM
        "bank" -> Right BankTransferM
        "card" -> Right CardPOSM
        "paypal" -> Right PayPalM
        "crypto" -> Right CryptoM
        "stripe" -> Right StripeM
        "wompi" -> Right WompiM
        "payphone" -> Right PayPhoneM
        "other" -> Right OtherM
        _ ->
          Left err400
            { errBody =
                "paymentMethod must be one of: cash, bank_transfer, bank, card, paypal, crypto, stripe, wompi, payphone, other"
            }
  where
    paymentMethod = T.strip rawPaymentMethod

-- Bookings
bookingPublicServer :: ServerT Api.BookingPublicAPI AppM
bookingPublicServer =
       getPublicBookingAvailability
  :<|> createPublicBooking
  :<|> createPublicBookingCheckout
  :<|> getPublicBookingCheckout
  :<|> createPublicBookingDatafastCheckout
  :<|> confirmPublicBookingDatafastStatus
  :<|> createPublicBookingPaypalOrder
  :<|> capturePublicBookingPaypalOrder
  :<|> selectPublicBookingManualPayment
  :<|> submitPublicBookingManualEvidence

inventoryStaticServer :: FilePath -> ServerT Api.AssetsAPI AppM
inventoryStaticServer assetsRoot =
  serveDirectoryFileServer (assetsRoot </> "inventory")

assetsServeServer :: FilePath -> ServerT Api.AssetsServeAPI AppM
assetsServeServer assetsRoot =
  case serveDirectoryFileServer assetsRoot of
    Tagged staticApplication -> Tagged $ \request sendResponse ->
      if assetsServePathAllowed (Wai.pathInfo request)
        then staticApplication request sendResponse
        else sendResponse (Wai.responseLBS status404 [] "Not found")

assetsServePathAllowed :: [Text] -> Bool
assetsServePathAllowed (firstSegment : _) = firstSegment /= ".internal-feedback"
assetsServePathAllowed [] = True

bookingServer :: AuthedUser -> ServerT BookingAPI AppM
bookingServer user =
       listBookings user
  :<|> createBooking user
  :<|> updateBooking user
  :<|> getServiceBookingCommerce user
  :<|> reviewServiceBookingManualPayment user

loadServiceBookingManualEvidenceDTO
  :: Checkout.CheckoutReference
  -> SqlPersistT IO (Maybe Api.ServiceBookingManualEvidenceDTO)
loadServiceBookingManualEvidenceDTO checkout = do
  rows <- (rawSql
    "SELECT evidence.id::text, attempt.provider, evidence.status,\
    \ evidence.customer_reference, evidence.submitted_amount_minor, evidence.currency,\
    \ evidence.submitted_by, evidence.submitted_at, evidence.reviewed_by,\
    \ evidence.reviewed_at, evidence.review_notes\
    \ FROM commerce_manual_payment_evidence evidence\
    \ JOIN commerce_payment_attempt attempt ON attempt.id = evidence.payment_attempt_id\
    \ WHERE evidence.checkout_id = ?::uuid\
    \ AND attempt.checkout_id = evidence.checkout_id\
    \ AND attempt.provider IN ('bank_transfer','cash','pos')\
    \ ORDER BY (attempt.status = 'succeeded') DESC, attempt.updated_at DESC, evidence.id DESC\
    \ LIMIT 1"
    [PersistText (Checkout.checkoutReferenceId checkout)]
    :: SqlPersistT IO
      [( Single Text, Single Text, Single Text, Single (Maybe Text), Single (Maybe Int64)
       , Single (Maybe Text), Single (Maybe Int64), Single (Maybe UTCTime)
       , Single (Maybe Int64), Single (Maybe UTCTime), Single (Maybe Text)
       )])
  pure $ case rows of
    [( Single evidenceId, Single paymentMethod, Single status, Single customerReference
     , Single submittedAmountMinor, Single currency, Single submittedBy, Single submittedAt
     , Single reviewedBy, Single reviewedAt, Single reviewNotes
     )] -> Just Api.ServiceBookingManualEvidenceDTO
        { Api.sbmeEvidenceId = evidenceId
        , Api.sbmePaymentMethod = paymentMethod
        , Api.sbmeStatus = status
        , Api.sbmeCustomerReference = customerReference
        , Api.sbmeSubmittedAmountMinor = submittedAmountMinor
        , Api.sbmeCurrency = currency
        , Api.sbmeSubmittedBy = submittedBy
        , Api.sbmeSubmittedAt = submittedAt
        , Api.sbmeReviewedBy = reviewedBy
        , Api.sbmeReviewedAt = reviewedAt
        , Api.sbmeReviewNotes = reviewNotes
        }
    _ -> Nothing

loadServiceBookingCommerceDTO
  :: Key Booking
  -> SqlPersistT IO (Maybe Api.ServiceBookingCommerceDTO)
loadServiceBookingCommerceDTO bookingKey = do
  mRuntime <- loadServiceBookingRuntimeView bookingKey
  case mRuntime of
    Nothing -> pure Nothing
    Just ServiceBookingRuntimeView{..} -> do
      manualEvidence <- loadServiceBookingManualEvidenceDTO
        (Checkout.CheckoutReference sbrvCheckoutId)
      pure $ Just Api.ServiceBookingCommerceDTO
        { Api.sbmcBookingId = fromSqlKey bookingKey
        , Api.sbmcCheckoutId = sbrvCheckoutId
        , Api.sbmcPaymentStatus = sbrvPaymentStatus
        , Api.sbmcFulfillmentStatus = sbrvFulfillmentStatus
        , Api.sbmcDepositMinor = sbrvDepositMinor
        , Api.sbmcCurrency = sbrvCurrency
        , Api.sbmcHoldExpiresAt = sbrvHoldExpiresAt
        , Api.sbmcManualEvidence = manualEvidence
        }

getServiceBookingCommerce
  :: AuthedUser
  -> Int64
  -> AppM Api.ServiceBookingCommerceDTO
getServiceBookingCommerce user rawBookingId = do
  requireModule user ModuleInvoicing
  bookingId <- either throwError pure $
    validatePositiveIdField "bookingId" rawBookingId
  let bookingKey = toSqlKey bookingId :: Key Booking
  runDB (loadServiceBookingCommerceDTO bookingKey)
    >>= maybe (throwError err404 { errBody = "Booking commerce order not found" }) pure

validateServiceBookingManualReview
  :: Api.ServiceBookingManualReviewReq
  -> Either ServerError (Text, Text)
validateServiceBookingManualReview Api.ServiceBookingManualReviewReq{..}
  | action `notElem` ["approve", "reject"] =
      Left err400 { errBody = "Manual payment review action must be approve or reject" }
  | T.length notes < 3 || T.length notes > 2000 =
      Left err400 { errBody = "Manual payment review notes must contain 3 to 2000 characters" }
  | T.any isUnsafeAccessRequestTextChar notes =
      Left err400 { errBody = "Manual payment review notes contain unsupported characters" }
  | otherwise = Right (action, notes)
  where
    action = T.toLower (T.strip sbmrAction)
    notes = T.strip sbmrReviewNotes

manualPaymentProviderFromText :: Text -> Maybe Checkout.PaymentProvider
manualPaymentProviderFromText provider = case provider of
  "bank_transfer" -> Just Checkout.ProviderBankTransfer
  "cash" -> Just Checkout.ProviderCash
  "pos" -> Just Checkout.ProviderPos
  _ -> Nothing

reviewServiceBookingManualPayment
  :: AuthedUser
  -> Int64
  -> Api.ServiceBookingManualReviewReq
  -> AppM Api.ServiceBookingCommerceDTO
reviewServiceBookingManualPayment user rawBookingId request = do
  requireModule user ModuleInvoicing
  bookingId <- either throwError pure $
    validatePositiveIdField "bookingId" rawBookingId
  (reviewAction, reviewNotes) <- either throwError pure $
    validateServiceBookingManualReview request
  let bookingKey = toSqlKey bookingId :: Key Booking
      reviewerId = fromSqlKey (auPartyId user)
  context <- loadServiceBookingPaymentContext bookingKey
  now <- liftIO getCurrentTime
  outcome <- runDB $ do
    rows <- (rawSql
      "SELECT checkout.status, runtime.hold_expires_at, attempt.id::text,\
      \ attempt.provider, attempt.merchant_account_ref, attempt.status,\
      \ evidence.id::text, evidence.status, evidence.submitted_by, evidence.reviewed_by\
      \ FROM service_booking_checkout_runtime runtime\
      \ JOIN commerce_checkout_session checkout ON checkout.id = runtime.checkout_id\
      \ JOIN commerce_payment_attempt attempt ON attempt.checkout_id = checkout.id\
      \ JOIN commerce_manual_payment_evidence evidence\
      \   ON evidence.checkout_id = checkout.id\
      \  AND evidence.payment_attempt_id = attempt.id\
      \ WHERE runtime.booking_id = ?\
      \ AND checkout.id = ?::uuid\
      \ AND checkout.domain_type = 'service_booking'\
      \ AND checkout.domain_order_id = ?\
      \ AND checkout.environment = ?\
      \ AND checkout.total_minor = ?\
      \ AND checkout.currency = ?\
      \ AND attempt.environment = checkout.environment\
      \ AND attempt.amount_minor = checkout.total_minor\
      \ AND attempt.currency = checkout.currency\
      \ AND attempt.provider IN ('bank_transfer','cash','pos')\
      \ AND attempt.operation = 'manual_verify'\
      \ ORDER BY (attempt.status = 'succeeded') DESC, attempt.updated_at DESC, evidence.id DESC\
      \ FOR UPDATE OF runtime, checkout, attempt, evidence"
      [ toPersistValue bookingKey
      , PersistText (Checkout.checkoutReferenceId (sbpcCheckout context))
      , PersistText (toPathPiece bookingKey)
      , PersistText (Checkout.checkoutEnvironmentText (sbpcEnvironment context))
      , PersistInt64 (sbpcDepositMinor context)
      , PersistText (sbpcCurrency context)
      ] :: SqlPersistT IO
        [( Single Text, Single UTCTime, Single Text, Single Text, Single Text
         , Single Text, Single Text, Single Text, Single (Maybe Int64), Single (Maybe Int64)
         )])
    case rows of
      [] -> pure (Left "No submitted manual payment evidence exists for this booking")
      [_first, _second] -> pure (Left "Manual payment evidence is ambiguous and requires reconciliation")
      (_:_:_) -> pure (Left "Manual payment evidence is ambiguous and requires reconciliation")
      [( Single checkoutStatus, Single holdExpiresAt, Single attemptId, Single providerText
       , Single merchantRef, Single attemptStatus, Single evidenceId, Single evidenceStatus
       , Single mSubmittedBy, Single mReviewedBy
       )] -> case (mSubmittedBy, manualPaymentProviderFromText providerText) of
        (Nothing, _) -> pure (Left "Manual payment evidence has no verified submitter")
        (_, Nothing) -> pure (Left "Manual payment evidence uses an unsupported provider")
        (Just submittedBy, Just provider)
          | submittedBy == reviewerId ->
              pure (Left "Manual payment evidence requires an independent reviewer")
          | evidenceStatus == "approved"
              && reviewAction == "approve"
              && checkoutStatus == "paid"
              && attemptStatus == "succeeded" -> pure (Right ())
          | evidenceStatus == "approved" ->
              pure (Left "Approved manual payment evidence cannot be changed")
          | evidenceStatus == "rejected" && reviewAction == "reject" -> pure (Right ())
          | evidenceStatus == "rejected" ->
              pure (Left "Rejected evidence must be resubmitted before approval")
          | evidenceStatus `notElem` ["submitted", "under_review"] ->
              pure (Left "Manual payment evidence is not ready for review")
          | evidenceStatus == "under_review" && mReviewedBy /= Just reviewerId ->
              pure (Left "Manual payment evidence is already under review by another staff member")
          | checkoutStatus == "paid" -> do
              Checkout.recordReconciliationException
                provider (sbpcEnvironment context) merchantRef
                "manual_evidence_after_other_payment"
                (toPathPiece bookingKey) evidenceId
                (sbpcDepositMinor context) (Just (sbpcDepositMinor context))
                (sbpcCurrency context) now
              pure (Left "This checkout is already paid by another payment attempt")
          | reviewAction == "approve" && holdExpiresAt <= now -> do
              Checkout.recordReconciliationException
                provider (sbpcEnvironment context) merchantRef
                "manual_payment_after_booking_hold_expiry"
                (toPathPiece bookingKey) evidenceId
                (sbpcDepositMinor context) (Just (sbpcDepositMinor context))
                (sbpcCurrency context) now
              pure (Left "The booking hold expired; payment requires reconciliation and cannot confirm this booking")
          | reviewAction == "approve"
              && checkoutStatus `notElem` ["awaiting_payment","failed","processing"] ->
              pure (Left "This checkout no longer accepts manual payment approval")
          | otherwise -> do
              transactionSave
              when (evidenceStatus == "submitted") $
                rawExecute
                  "UPDATE commerce_manual_payment_evidence\
                  \ SET status = 'under_review', reviewed_by = ?, review_notes = ?\
                  \ WHERE id = ?::uuid"
                  [PersistInt64 reviewerId, PersistText reviewNotes, PersistText evidenceId]
              if reviewAction == "reject"
                then do
                  rawExecute
                    "UPDATE commerce_manual_payment_evidence\
                    \ SET status = 'rejected', reviewed_at = ?, review_notes = ?\
                    \ WHERE id = ?::uuid"
                    [PersistUTCTime now, PersistText reviewNotes, PersistText evidenceId]
                  Checkout.recordPaymentFailure
                    (sbpcCheckout context)
                    (Checkout.PaymentAttemptReference attemptId)
                    provider
                    "manual_evidence_rejected"
                    (serviceBookingPaymentCorrelationId context provider "manual-review")
                    now
                  insertServiceBookingManualReviewAudit
                    context provider reviewerId attemptId evidenceId "manual_payment_rejected"
                  pure (Right ())
                else do
                  rawExecute
                    "UPDATE commerce_manual_payment_evidence\
                    \ SET status = 'approved', reviewed_at = ?, review_notes = ?\
                    \ WHERE id = ?::uuid"
                    [PersistUTCTime now, PersistText reviewNotes, PersistText evidenceId]
                  binding <- Checkout.bindProviderResource Checkout.ProviderBindingCreation
                    { Checkout.pbcAttempt = Checkout.PaymentAttemptReference attemptId
                    , Checkout.pbcCheckout = sbpcCheckout context
                    , Checkout.pbcProvider = provider
                    , Checkout.pbcEnvironment = sbpcEnvironment context
                    , Checkout.pbcMerchantRef = merchantRef
                    , Checkout.pbcResourceType = "manual_evidence"
                    , Checkout.pbcProviderResource = evidenceId
                    , Checkout.pbcResourcePath = Nothing
                    , Checkout.pbcOrderReference = toPathPiece bookingKey
                    , Checkout.pbcAmountMinor = sbpcDepositMinor context
                    , Checkout.pbcCurrency = sbpcCurrency context
                    , Checkout.pbcStage = Checkout.AttemptProcessing
                    , Checkout.pbcOccurredAt = now
                    , Checkout.pbcCorrelationId = serviceBookingPaymentCorrelationId
                        context provider "manual-review"
                    }
                  case binding of
                    Left bindingError -> transactionUndo >> pure (Left bindingError)
                    Right () -> do
                      verified <- Checkout.recordApprovedManualPayment Checkout.VerifiedPayment
                        { Checkout.vpAttempt = Checkout.PaymentAttemptReference attemptId
                        , Checkout.vpCheckout = sbpcCheckout context
                        , Checkout.vpProvider = provider
                        , Checkout.vpEnvironment = sbpcEnvironment context
                        , Checkout.vpMerchantRef = merchantRef
                        , Checkout.vpResourceType = "manual_evidence"
                        , Checkout.vpProviderResource = evidenceId
                        , Checkout.vpProviderResourcePath = Nothing
                        , Checkout.vpOrderReference = toPathPiece bookingKey
                        , Checkout.vpProviderReference = toPathPiece bookingKey
                        , Checkout.vpAmountMinor = sbpcDepositMinor context
                        , Checkout.vpCurrency = sbpcCurrency context
                        , Checkout.vpEvidence = "staff_verified_manual"
                        , Checkout.vpOccurredAt = now
                        , Checkout.vpCorrelationId = serviceBookingPaymentCorrelationId
                            context provider "manual-review"
                        }
                      case verified of
                        Left verificationError -> transactionUndo >> pure (Left verificationError)
                        Right _ -> do
                          insertServiceBookingManualReviewAudit
                            context provider reviewerId attemptId evidenceId "manual_payment_approved"
                          pure (Right ())
  either (throwError . marketplaceCheckoutConflict) pure outcome
  runDB (loadServiceBookingCommerceDTO bookingKey)
    >>= maybe (throwError (marketplaceCheckoutInternal
          "Reviewed booking commerce order could not be reloaded")) pure

insertServiceBookingManualReviewAudit
  :: ServiceBookingPaymentContext
  -> Checkout.PaymentProvider
  -> Int64
  -> Text
  -> Text
  -> Text
  -> SqlPersistT IO ()
insertServiceBookingManualReviewAudit context provider reviewerId attemptId evidenceId eventType =
  rawExecute
    "INSERT INTO commerce_checkout_audit_event(\
    \ checkout_id, event_type, actor_type, actor_id, correlation_id, metadata\
    \) VALUES (?::uuid, ?, 'staff', ?, ?,\
    \ jsonb_build_object('attempt_id', ?, 'evidence_id', ?))"
    [ PersistText (Checkout.checkoutReferenceId (sbpcCheckout context))
    , PersistText eventType
    , PersistText (T.pack (show reviewerId))
    , PersistText (serviceBookingPaymentCorrelationId
        context provider "manual-review")
    , PersistText attemptId
    , PersistText evidenceId
    ]

-- Scheduling module admission is not object authority. Product decision2026-10-05:
-- only these four roles may inspect/operate the complete studio calendar.
hasStudioBookingAccess :: AuthedUser -> Bool
hasStudioBookingAccess user = any (`elem` auRoles user) [Admin, Manager, StudioManager, Reception]

canAccessBooking :: AuthedUser -> Booking -> Bool
canAccessBooking user booking = hasStudioBookingAccess user
  || bookingPartyId booking == Just (auPartyId user)
  || bookingEngineerPartyId booking == Just (auPartyId user)

bookingScopeFilters :: AuthedUser -> [Filter Booking]
bookingScopeFilters user
  | hasStudioBookingAccess user = []
  | otherwise = [BookingPartyId ==. Just (auPartyId user)]
      ||. [BookingEngineerPartyId ==. Just (auPartyId user)]

-- Keep current-session validation and every mutation in the same transaction.
-- Constraint/retry failures are conflicts; raw SQL diagnostics stay private.
runBookingTransaction :: AuthedUser -> SqlPersistT IO (Either ServerError a) -> AppM a
runBookingTransaction user action = do
  Env pool _ <- ask
  outcome <- liftIO $ try $ flip runSqlPool pool $ do
    checked <- withCurrentAuthSession user action
    let result = fromMaybe (Left err401) checked
    case result of
      Left _ -> transactionUndo >> pure result
      Right _ -> pure result
  case outcome of
    Left sqlError
      | sqlState sqlError `elem` ["23P01", "23514", "40001", "40P01"] ->
          throwError err409 { errBody = "Booking conflicts with the resource calendar or checkout lifecycle" }
      | otherwise -> liftIO (throwIO (sqlError :: SqlError))
    Right result -> either throwError pure result

listBookings :: AuthedUser -> Maybe Int64 -> Maybe Int64 -> Maybe Int64 -> AppM [BookingDTO]
listBookings user mBookingId mPartyId mEngineerPartyId = do
  requireModule user ModuleScheduling
  (bookingIdFilter, partyIdFilter, engineerPartyIdFilter) <-
    either throwError pure $
      validateBookingListFilters mBookingId mPartyId mEngineerPartyId
  Env pool _ <- ask
  liftIO $ do
    dbBookings <- flip runSqlPool pool $ do
      case bookingIdFilter of
        Just bid | bid > 0 -> do
          let bookingKey = toSqlKey bid :: Key Booking
          mBooking <- getEntity bookingKey
          case mBooking of
            Nothing -> pure []
            Just ent | canAccessBooking user (entityVal ent) -> buildBookingDTOs [ent]
                     | otherwise -> pure []
        _ -> do
          let loadByParty pid = do
                let pidKey = toSqlKey pid :: Key Party
                selectList (bookingScopeFilters user ++ [BookingPartyId ==. Just pidKey]) [Desc BookingStartsAt, LimitTo 500]
              loadByEngineer pid = do
                let pidKey = toSqlKey pid :: Key Party
                selectList (bookingScopeFilters user ++ [BookingEngineerPartyId ==. Just pidKey]) [Desc BookingStartsAt, LimitTo 500]
          case (partyIdFilter, engineerPartyIdFilter) of
            (Nothing, Nothing) -> do
              bookings <- selectList (bookingScopeFilters user) [Desc BookingId]
              buildBookingDTOs bookings
            _ -> do
              byParty <- maybe (pure []) loadByParty partyIdFilter
              byEngineer <- maybe (pure []) loadByEngineer engineerPartyIdFilter
              let merged = dedupeByKey (byParty ++ byEngineer)
              buildBookingDTOs merged
    if not (hasStudioBookingAccess user) || isJust bookingIdFilter || isJust partyIdFilter || isJust engineerPartyIdFilter
      then pure dbBookings
      else do
        courseSessions <- flip runSqlPool pool courseCalendarBookings
        pure (dbBookings ++ courseSessions)
  where
    dedupeByKey :: [Entity Booking] -> [Entity Booking]
    dedupeByKey = go Set.empty []
      where
        go _ acc [] = reverse acc
        go seen acc (e:es) =
          let key = entityKey e
          in if Set.member key seen
               then go seen acc es
               else go (Set.insert key seen) (e:acc) es

courseCalendarBookings :: SqlPersistT IO [BookingDTO]
courseCalendarBookings = do
  now <- liftIO getCurrentTime
  _ <- (rawSql "SELECT course_checkout_expire_holds(?)"
    [PersistUTCTime now] :: SqlPersistT IO [Single Int])
  courses <- selectList [] []
  fmap concat $ forM courses $ \(Entity courseId course) -> do
    occupiedRows <- (rawSql
      "SELECT (\
      \ SELECT count(*) FROM course_registration_checkout_runtime runtime\
      \ WHERE runtime.course_id = ? AND (\
      \   runtime.enrollment_status IN ('enrolled','transfer_requested','completed')\
      \   OR (runtime.enrollment_status = 'seat_held' AND runtime.hold_expires_at > ?)\
      \ )) + (\
      \ SELECT count(*) FROM course_registration registration\
      \ WHERE registration.course_slug = ? AND registration.status = 'paid'\
      \ AND NOT EXISTS (SELECT 1 FROM course_registration_checkout_runtime runtime\
      \   WHERE runtime.registration_id = registration.id))"
      [toPersistValue courseId, PersistUTCTime now, PersistText (Trials.courseSlug course)]
      :: SqlPersistT IO [Single Int64])
    let regCount = case occupiedRows of
          [Single value] -> value
          _ -> fromIntegral (Trials.courseCapacity course)
    sessions <- selectList [Trials.CourseSessionModelCourseId ==. courseId] [Asc Trials.CourseSessionModelOrder, Asc Trials.CourseSessionModelDate]
    let metaTitle = Trials.courseTitle course
        slugVal = Trials.courseSlug course
        capacityVal = Trials.courseCapacity course
        remainingVal = max 0 (capacityVal - fromIntegral regCount)
        startHour = fromMaybe 0 (Trials.courseSessionStartHour course)
        durationHours = fromMaybe 0 (Trials.courseSessionDurationHours course)
        coursePriceD = fromIntegral (Trials.coursePriceCents course) / 100
        mkBooking :: Int -> Entity Trials.CourseSessionModel -> BookingDTO
        mkBooking idx (Entity _ s) =
          let dateVal = Trials.courseSessionModelDate s
              startUtc = UTCTime dateVal (secondsToDiffTime (fromIntegral startHour * 60 * 60))
              endUtc   = addUTCTime (fromIntegral durationHours * 60 * 60) startUtc
          in BookingDTO
               { bookingId          = negate (fromIntegral (1000 + idx))
               , title              = "Curso: " <> Trials.courseSessionModelLabel s
               , startsAt           = startUtc
               , endsAt             = endUtc
               , status             = "course"
               , notes              = Just ("Curso: " <> metaTitle)
               , partyId            = Nothing
               , engineerPartyId    = Nothing
               , engineerName       = Nothing
               , serviceOfferingId  = Nothing
               , serviceType        = Just "Curso"
               , serviceOrderId     = Nothing
               , serviceOrderTitle  = Nothing
               , customerName       = Nothing
               , partyDisplayName   = Nothing
               , resources          = []
               , courseSlug         = Just slugVal
               , coursePrice        = Just coursePriceD
               , courseCurrency     = Just (Trials.courseCurrency course)
               , courseCapacity     = Just capacityVal
               , courseRemaining    = Just remainingVal
               , courseLocation     = Trials.courseLocationLabel course
               }
    pure (zipWith mkBooking [1 :: Int ..] sessions)

data ApprovedServiceBookingPolicy = ApprovedServiceBookingPolicy
  { asbpId :: Text
  , asbpVersion :: Text
  , asbpCurrency :: Text
  , asbpRateMinor :: Int64
  , asbpRateUnitMinutes :: Int
  , asbpTaxBps :: Int
  , asbpDepositBps :: Int
  , asbpHoldMinutes :: Int
  , asbpMinDurationMinutes :: Int
  , asbpMaxDurationMinutes :: Int
  , asbpDurationStepMinutes :: Int
  , asbpTimezone :: Text
  , asbpTermsVersion :: Text
  } deriving (Eq, Show)

loadApprovedServiceBookingPolicy
  :: UTCTime
  -> Key Catalog.ServiceOffering
  -> SqlPersistT IO (Maybe ApprovedServiceBookingPolicy)
loadApprovedServiceBookingPolicy now offeringKey = do
  coreRows <- (rawSql
    "SELECT id::text, policy_version, currency, rate_minor, rate_unit_minutes,\
    \ tax_bps, deposit_bps, hold_minutes, min_duration_minutes, max_duration_minutes\
    \ FROM service_booking_commerce_policy\
    \ WHERE service_offering_id = ?::uuid AND active\
    \ AND approval_status = 'approved' AND approved_at IS NOT NULL\
    \ AND (effective_from IS NULL OR effective_from <= ?)\
    \ AND (effective_until IS NULL OR effective_until > ?)"
    [ PersistText (toPathPiece offeringKey)
    , PersistUTCTime now
    , PersistUTCTime now
    ] :: SqlPersistT IO
      [( Single Text, Single Text, Single Text, Single Int64, Single Int
       , Single Int, Single Int, Single Int, Single Int, Single Int
       )])
  case coreRows of
    [( Single policyId, Single version, Single currency, Single rateMinor
     , Single rateUnitMinutes, Single taxBps, Single depositBps, Single holdMinutes
     , Single minDurationMinutes, Single maxDurationMinutes
     )] -> do
      detailRows <- (rawSql
        "SELECT duration_step_minutes, timezone, terms_version\
        \ FROM service_booking_commerce_policy WHERE id = ?::uuid"
        [PersistText policyId]
        :: SqlPersistT IO [(Single Int, Single Text, Single Text)])
      pure $ case detailRows of
        [(Single durationStepMinutes, Single timezone, Single termsVersion)] ->
          Just ApprovedServiceBookingPolicy
            { asbpId = policyId
            , asbpVersion = version
            , asbpCurrency = currency
            , asbpRateMinor = rateMinor
            , asbpRateUnitMinutes = rateUnitMinutes
            , asbpTaxBps = taxBps
            , asbpDepositBps = depositBps
            , asbpHoldMinutes = holdMinutes
            , asbpMinDurationMinutes = minDurationMinutes
            , asbpMaxDurationMinutes = maxDurationMinutes
            , asbpDurationStepMinutes = durationStepMinutes
            , asbpTimezone = timezone
            , asbpTermsVersion = termsVersion
            }
        _ -> Nothing
    _ -> pure Nothing

calculateApprovedServiceBookingPrice
  :: ApprovedServiceBookingPolicy
  -> Int
  -> Either ServerError ServiceBookings.BookingPriceBreakdown
calculateApprovedServiceBookingPrice ApprovedServiceBookingPolicy{..} durationMinutes =
  either
    (Left . (\message -> err422 { errBody = BL.fromStrict (TE.encodeUtf8 message) }))
    Right
    (ServiceBookings.calculateBookingPrice
      asbpRateMinor
      asbpRateUnitMinutes
      asbpTaxBps
      asbpDepositBps
      asbpMinDurationMinutes
      asbpMaxDurationMinutes
      asbpDurationStepMinutes
      durationMinutes)

serviceBookingQuoteDTO
  :: ApprovedServiceBookingPolicy
  -> ServiceBookings.BookingPriceBreakdown
  -> Api.PublicBookingQuoteDTO
serviceBookingQuoteDTO ApprovedServiceBookingPolicy{..} price =
  Api.PublicBookingQuoteDTO
    { Api.pbqPolicyVersion = asbpVersion
    , Api.pbqCurrency = asbpCurrency
    , Api.pbqDurationMinutes = ServiceBookings.bpbDurationMinutes price
    , Api.pbqSubtotalMinor = ServiceBookings.bpbSubtotalMinor price
    , Api.pbqTaxMinor = ServiceBookings.bpbTaxMinor price
    , Api.pbqTotalMinor = ServiceBookings.bpbTotalMinor price
    , Api.pbqDepositMinor = ServiceBookings.bpbDepositMinor price
    , Api.pbqBalanceMinor = ServiceBookings.bpbBalanceMinor price
    , Api.pbqDepositBps = asbpDepositBps
    , Api.pbqTermsVersion = asbpTermsVersion
    }

getPublicBookingAvailability
  :: UUID.UUID
  -> UTCTime
  -> Int
  -> AppM Api.PublicBookingAvailabilityDTO
getPublicBookingAvailability offeringId requestedStart requestedDuration = do
  now <- liftIO getCurrentTime
  durationMinutes <- either throwError pure $
    validatePublicBookingDurationMinutes (Just requestedDuration)
  startsAtClean <- either throwError pure $
    validatePublicBookingStartAt now requestedStart
  offering@(Entity offeringKey _) <- runDB $
    loadSelectableServiceOffering now offeringId
  let endsAtClean = addUTCTime (fromIntegral durationMinutes * 60) startsAtClean
  mPolicy <- runDB (loadApprovedServiceBookingPolicy now offeringKey)
  case mPolicy of
    Just policy -> case calculateApprovedServiceBookingPrice policy durationMinutes of
      Left serverErr -> pure Api.PublicBookingAvailabilityDTO
        { Api.pbaAvailable = False
        , Api.pbaReason = Just (bookingServerErrorText serverErr)
        , Api.pbaServiceOfferingId = offeringId
        , Api.pbaStartsAt = startsAtClean
        , Api.pbaEndsAt = endsAtClean
        , Api.pbaResourceIds = []
        , Api.pbaResourceNames = []
        , Api.pbaQuote = Nothing
        }
      Right price -> resolveAvailability offering (Just (serviceBookingQuoteDTO policy price)) startsAtClean endsAtClean
    Nothing -> resolveAvailability offering Nothing startsAtClean endsAtClean
  where
    resolveAvailability offering quote startsAtClean endsAtClean = do
      resolved <- (Right <$> runDB
          (resolveResourcesForBooking (Just offering) [] startsAtClean endsAtClean))
        `catchError` \serverErr ->
          if errHTTPCode serverErr == 409
            then pure (Left serverErr)
            else throwError serverErr
      case resolved of
        Left serverErr -> pure Api.PublicBookingAvailabilityDTO
          { Api.pbaAvailable = False
          , Api.pbaReason = Just (bookingServerErrorText serverErr)
          , Api.pbaServiceOfferingId = offeringId
          , Api.pbaStartsAt = startsAtClean
          , Api.pbaEndsAt = endsAtClean
          , Api.pbaResourceIds = []
          , Api.pbaResourceNames = []
          , Api.pbaQuote = quote
          }
        Right resourceKeys -> do
          resourcesFound <- runDB (mapM getJust resourceKeys)
          pure Api.PublicBookingAvailabilityDTO
            { Api.pbaAvailable = True
            , Api.pbaReason = Nothing
            , Api.pbaServiceOfferingId = offeringId
            , Api.pbaStartsAt = startsAtClean
            , Api.pbaEndsAt = endsAtClean
            , Api.pbaResourceIds = map toPathPiece resourceKeys
            , Api.pbaResourceNames = map resourceName resourcesFound
            , Api.pbaQuote = quote
            }

bookingServerErrorText :: ServerError -> Text
bookingServerErrorText =
  T.strip . TE.decodeUtf8With TEE.lenientDecode . BL.toStrict . errBody

data ServiceBookingRuntimeView = ServiceBookingRuntimeView
  { sbrvCheckoutId :: Text
  , sbrvPaymentStatus :: Text
  , sbrvFulfillmentStatus :: Text
  , sbrvHoldExpiresAt :: UTCTime
  , sbrvPolicyVersion :: Text
  , sbrvCurrency :: Text
  , sbrvDurationMinutes :: Int
  , sbrvSubtotalMinor :: Int64
  , sbrvTaxMinor :: Int64
  , sbrvTotalMinor :: Int64
  , sbrvDepositMinor :: Int64
  , sbrvBalanceMinor :: Int64
  , sbrvDepositBps :: Int
  , sbrvTermsVersion :: Text
  }

loadServiceBookingRuntimeView
  :: Key Booking
  -> SqlPersistT IO (Maybe ServiceBookingRuntimeView)
loadServiceBookingRuntimeView bookingKey = do
  coreRows <- (rawSql
    "SELECT runtime.checkout_id::text, checkout.status, runtime.fulfillment_status,\
    \ runtime.hold_expires_at, runtime.policy_version, runtime.currency,\
    \ runtime.duration_minutes, runtime.subtotal_minor, runtime.tax_minor, runtime.total_minor\
    \ FROM service_booking_checkout_runtime runtime\
    \ JOIN commerce_checkout_session checkout ON checkout.id = runtime.checkout_id\
    \ WHERE runtime.booking_id = ?"
    [toPersistValue bookingKey]
    :: SqlPersistT IO
      [( Single Text, Single Text, Single Text, Single UTCTime, Single Text
       , Single Text, Single Int, Single Int64, Single Int64, Single Int64
       )])
  case coreRows of
    [( Single checkoutId, Single paymentStatus, Single fulfillmentStatus
     , Single holdExpiresAt, Single policyVersion, Single currency
     , Single durationMinutes, Single subtotalMinor, Single taxMinor, Single totalMinor
     )] -> do
      detailRows <- (rawSql
        "SELECT deposit_minor, balance_minor, deposit_bps, terms_version\
        \ FROM service_booking_checkout_runtime WHERE booking_id = ?"
        [toPersistValue bookingKey]
        :: SqlPersistT IO [(Single Int64, Single Int64, Single Int, Single Text)])
      pure $ case detailRows of
        [(Single depositMinor, Single balanceMinor, Single depositBps, Single termsVersion)] ->
          Just ServiceBookingRuntimeView
            { sbrvCheckoutId = checkoutId
            , sbrvPaymentStatus = paymentStatus
            , sbrvFulfillmentStatus = fulfillmentStatus
            , sbrvHoldExpiresAt = holdExpiresAt
            , sbrvPolicyVersion = policyVersion
            , sbrvCurrency = currency
            , sbrvDurationMinutes = durationMinutes
            , sbrvSubtotalMinor = subtotalMinor
            , sbrvTaxMinor = taxMinor
            , sbrvTotalMinor = totalMinor
            , sbrvDepositMinor = depositMinor
            , sbrvBalanceMinor = balanceMinor
            , sbrvDepositBps = depositBps
            , sbrvTermsVersion = termsVersion
            }
        _ -> Nothing
    _ -> pure Nothing

loadPublicBookingManualPayment
  :: Checkout.CheckoutReference
  -> SqlPersistT IO (Maybe Api.PublicBookingManualPaymentDTO)
loadPublicBookingManualPayment checkout = do
  rows <- (rawSql
    "SELECT attempt.provider, evidence.status, evidence.submitted_at\
    \ FROM commerce_manual_payment_evidence evidence\
    \ JOIN commerce_payment_attempt attempt ON attempt.id = evidence.payment_attempt_id\
    \ WHERE evidence.checkout_id = ?::uuid\
    \ AND attempt.checkout_id = evidence.checkout_id\
    \ AND attempt.provider IN ('bank_transfer','cash','pos')\
    \ ORDER BY (attempt.status = 'succeeded') DESC, attempt.updated_at DESC, evidence.id DESC\
    \ LIMIT 1"
    [PersistText (Checkout.checkoutReferenceId checkout)]
    :: SqlPersistT IO [(Single Text, Single Text, Single (Maybe UTCTime))])
  pure $ case rows of
    [(Single paymentMethod, Single status, Single submittedAt)] ->
      Just Api.PublicBookingManualPaymentDTO
        { Api.pbmpPaymentMethod = paymentMethod
        , Api.pbmpStatus = status
        , Api.pbmpSubmittedAt = submittedAt
        }
    _ -> Nothing

loadPublicBookingCheckoutDTO
  :: Key Booking
  -> Maybe Text
  -> AppM Api.PublicBookingCheckoutDTO
loadPublicBookingCheckoutDTO bookingKey lookupToken = do
  Env{ envPool } <- ask
  loaded <- liftIO $ flip runSqlPool envPool $ do
    mBooking <- getEntity bookingKey
    mRuntime <- loadServiceBookingRuntimeView bookingKey
    case (mBooking, mRuntime) of
      (Just bookingEntity, Just runtimeView) -> do
        dtos <- buildBookingDTOs [bookingEntity]
        pure $ case requirePersistedBookingDTO dtos of
          Left _ -> Nothing
          Right dto -> Just (dto, runtimeView)
      _ -> pure Nothing
  case loaded of
    Nothing -> throwError serviceBookingLookupNotFound
    Just (dto, ServiceBookingRuntimeView{..}) -> do
      let checkout = Checkout.CheckoutReference sbrvCheckoutId
      manualPayment <- runDB (loadPublicBookingManualPayment checkout)
      paymentMethods <- loadPublicBookingPaymentMethods
        checkout
        sbrvPaymentStatus
        sbrvHoldExpiresAt
        (Api.pbmpStatus <$> manualPayment)
        sbrvDepositMinor
        sbrvCurrency
      pure Api.PublicBookingCheckoutDTO
        { Api.pbcBooking = dto
        , Api.pbcCheckoutId = sbrvCheckoutId
        , Api.pbcLookupToken = lookupToken
        , Api.pbcPaymentStatus = sbrvPaymentStatus
        , Api.pbcFulfillmentStatus = sbrvFulfillmentStatus
        , Api.pbcHoldExpiresAt = sbrvHoldExpiresAt
        , Api.pbcQuote = Api.PublicBookingQuoteDTO
            { Api.pbqPolicyVersion = sbrvPolicyVersion
            , Api.pbqCurrency = sbrvCurrency
            , Api.pbqDurationMinutes = sbrvDurationMinutes
            , Api.pbqSubtotalMinor = sbrvSubtotalMinor
            , Api.pbqTaxMinor = sbrvTaxMinor
            , Api.pbqTotalMinor = sbrvTotalMinor
            , Api.pbqDepositMinor = sbrvDepositMinor
            , Api.pbqBalanceMinor = sbrvBalanceMinor
            , Api.pbqDepositBps = sbrvDepositBps
            , Api.pbqTermsVersion = sbrvTermsVersion
            }
        , Api.pbcPaymentMethods = paymentMethods
        , Api.pbcManualPayment = manualPayment
        }

loadPublicBookingPaymentMethods
  :: Checkout.CheckoutReference
  -> Text
  -> UTCTime
  -> Maybe Text
  -> Int64
  -> Text
  -> AppM [Text]
loadPublicBookingPaymentMethods checkout paymentStatus holdExpiresAt manualStatus amountMinor currency = do
  now <- liftIO getCurrentTime
  if paymentStatus `notElem` ["awaiting_payment", "failed"]
      || holdExpiresAt <= now
      || manualStatus `elem` [Just "submitted", Just "under_review"]
    then pure []
    else do
      storedEnvironment <- runDB (Checkout.loadCheckoutEnvironment checkout)
        >>= either (const (pure Nothing)) (pure . Just)
      case storedEnvironment of
        Nothing -> pure []
        Just checkoutEnvironment -> do
          domainEnabled <- runDB $
            Checkout.domainEnabledForEnvironment checkoutEnvironment "service_bookings"
          if not domainEnabled
            then pure []
            else PaymentAvailability.availableImplementedPaymentMethods
              checkoutEnvironment
              PaymentAvailability.FlowBooking
              amountMinor
              currency
              True

serviceBookingLookupNotFound :: ServerError
serviceBookingLookupNotFound = err404 { errBody = "Booking order not found" }

getPublicBookingCheckout
  :: Int64
  -> Maybe Text
  -> AppM Api.PublicBookingCheckoutDTO
getPublicBookingCheckout rawBookingId mLookupToken = do
  bookingId <- either throwError pure (validatePositiveIdField "bookingId" rawBookingId)
  let bookingKey = toSqlKey (fromIntegral bookingId) :: Key Booking
  requirePublicBookingLookupToken bookingKey mLookupToken
  loadPublicBookingCheckoutDTO bookingKey Nothing

requirePublicBookingLookupToken :: Key Booking -> Maybe Text -> AppM ()
requirePublicBookingLookupToken bookingKey mLookupToken = do
  suppliedToken <- maybe (throwError serviceBookingLookupNotFound) (pure . T.strip) mLookupToken
  storedHashes <- runDB (rawSql
    "SELECT lookup_token_hash FROM service_booking_checkout_runtime WHERE booking_id = ?"
    [toPersistValue bookingKey] :: SqlPersistT IO [Single Text])
  storedHash <- case storedHashes of
    [Single value] -> pure value
    _ -> throwError serviceBookingLookupNotFound
  let suppliedHash = marketplaceSha256Text suppliedToken
  unless (constEq (TE.encodeUtf8 storedHash) (TE.encodeUtf8 suppliedHash)) $
    throwError serviceBookingLookupNotFound

data ServiceBookingPaymentContext = ServiceBookingPaymentContext
  { sbpcBookingKey :: Key Booking
  , sbpcCheckout :: Checkout.CheckoutReference
  , sbpcCreateIdempotencyKey :: Text
  , sbpcCheckoutStatus :: Text
  , sbpcEnvironment :: Checkout.CheckoutEnvironment
  , sbpcDepositMinor :: Int64
  , sbpcCurrency :: Text
  , sbpcHoldExpiresAt :: UTCTime
  , sbpcBuyerName :: Text
  , sbpcBuyerEmail :: Text
  , sbpcBuyerPhone :: Maybe Text
  } deriving (Eq, Show)

loadServiceBookingPaymentContext
  :: Key Booking
  -> AppM ServiceBookingPaymentContext
loadServiceBookingPaymentContext bookingKey = do
  rows <- runDB (rawSql
    "SELECT runtime.checkout_id::text, runtime.create_idempotency_key, checkout.status,\
    \ checkout.environment, runtime.deposit_minor, runtime.currency, runtime.hold_expires_at,\
    \ party.display_name, party.primary_email, party.primary_phone\
    \ FROM service_booking_checkout_runtime runtime\
    \ JOIN commerce_checkout_session checkout ON checkout.id = runtime.checkout_id\
    \ JOIN booking booked ON booked.id = runtime.booking_id\
    \ JOIN party party ON party.id = booked.party_id\
    \ WHERE runtime.booking_id = ?\
    \ AND checkout.domain_type = 'service_booking'\
    \ AND checkout.domain_order_id = runtime.booking_id::text\
    \ AND checkout.total_minor = runtime.deposit_minor\
    \ AND checkout.currency = runtime.currency"
    [toPersistValue bookingKey]
    :: SqlPersistT IO
      [( Single Text, Single Text, Single Text, Single Text, Single Int64
       , Single Text, Single UTCTime, Single Text, Single (Maybe Text), Single (Maybe Text)
       )])
  case rows of
    [( Single checkoutId, Single createKey, Single checkoutStatus, Single environmentText
     , Single depositMinor, Single currency, Single holdExpiresAt, Single buyerName
     , Single mBuyerEmail, Single buyerPhone
     )] -> do
      checkoutEnvironment <- either
        (throwError . marketplaceCheckoutInternal)
        pure
        (Checkout.resolveCheckoutEnvironment (Just (T.unpack environmentText)))
      buyerEmail <- maybe
        (throwError (marketplaceCheckoutInternal
          "Service booking customer email is missing"))
        pure
        mBuyerEmail
      pure ServiceBookingPaymentContext
        { sbpcBookingKey = bookingKey
        , sbpcCheckout = Checkout.CheckoutReference checkoutId
        , sbpcCreateIdempotencyKey = createKey
        , sbpcCheckoutStatus = checkoutStatus
        , sbpcEnvironment = checkoutEnvironment
        , sbpcDepositMinor = depositMinor
        , sbpcCurrency = currency
        , sbpcHoldExpiresAt = holdExpiresAt
        , sbpcBuyerName = buyerName
        , sbpcBuyerEmail = buyerEmail
        , sbpcBuyerPhone = buyerPhone
        }
    [] -> throwError serviceBookingLookupNotFound
    _ -> throwError (marketplaceCheckoutInternal
      "Service booking payment context is ambiguous")

requireServiceBookingPaymentContext
  :: Int64
  -> Maybe Text
  -> AppM ServiceBookingPaymentContext
requireServiceBookingPaymentContext rawBookingId mLookupToken = do
  context <- authorizeServiceBookingPaymentContext rawBookingId mLookupToken
  now <- liftIO getCurrentTime
  when
      ( sbpcHoldExpiresAt context <= now
        && sbpcCheckoutStatus context `elem` ["holding", "awaiting_payment", "failed"]
      ) $ do
    _ <- runDB (rawSql "SELECT service_booking_expire_holds(?)"
      [PersistUTCTime now] :: SqlPersistT IO [Single Int])
    throwError err409
      { errBody = "This booking checkout hold expired; choose availability again" }
  unless
      (sbpcCheckoutStatus context `elem`
        ["holding", "awaiting_payment", "processing", "failed", "paid"]) $
    throwError err409
      { errBody = "This booking checkout no longer accepts payment actions" }
  pure context

authorizeServiceBookingPaymentContext
  :: Int64
  -> Maybe Text
  -> AppM ServiceBookingPaymentContext
authorizeServiceBookingPaymentContext rawBookingId mLookupToken = do
  bookingId <- either throwError pure (validatePositiveIdField "bookingId" rawBookingId)
  let bookingKey = toSqlKey bookingId :: Key Booking
  requirePublicBookingLookupToken bookingKey mLookupToken
  loadServiceBookingPaymentContext bookingKey

requireServiceBookingProvider
  :: ServiceBookingPaymentContext
  -> Checkout.CheckoutEnvironment
  -> Checkout.PaymentProvider
  -> AppM ()
requireServiceBookingProvider context configuredEnvironment provider = do
  unless (configuredEnvironment == sbpcEnvironment context) $
    throwError err503
      { errBody = "Configured provider environment does not match this immutable booking checkout" }
  domainEnabled <- runDB $
    Checkout.domainEnabledForEnvironment configuredEnvironment "service_bookings"
  unless domainEnabled $
    throwError err503
      { errBody = "Public service booking checkout is disabled in this environment" }
  providerEnabled <- runDB $
    Checkout.providerEnabledForEnvironment configuredEnvironment provider
  unless providerEnabled $
    throwError err503
      { errBody = "Payment provider is disabled for this checkout environment" }

ensureNoSubmittedServiceBookingManualEvidence
  :: ServiceBookingPaymentContext
  -> AppM ()
ensureNoSubmittedServiceBookingManualEvidence context = do
  rows <- runDB (rawSql
    "SELECT EXISTS (\
    \ SELECT 1 FROM commerce_manual_payment_evidence evidence\
    \ JOIN commerce_payment_attempt attempt ON attempt.id = evidence.payment_attempt_id\
    \ WHERE evidence.checkout_id = ?::uuid\
    \ AND attempt.checkout_id = evidence.checkout_id\
    \ AND attempt.provider IN ('bank_transfer','cash','pos')\
    \ AND evidence.status IN ('submitted','under_review'))"
    [PersistText (Checkout.checkoutReferenceId (sbpcCheckout context))]
    :: SqlPersistT IO [Single Bool])
  when (rows == [Single True]) $
    throwError err409
      { errBody = "Manual payment evidence is under review; another charge cannot be started" }

ensureNoActiveServiceBookingOnlineAttempt
  :: ServiceBookingPaymentContext
  -> AppM ()
ensureNoActiveServiceBookingOnlineAttempt context = do
  rows <- runDB (rawSql
    "SELECT EXISTS (\
    \ SELECT 1 FROM commerce_payment_attempt\
    \ WHERE checkout_id = ?::uuid\
    \ AND provider NOT IN ('bank_transfer','cash','pos')\
    \ AND status IN ('requires_customer_action','processing'))"
    [PersistText (Checkout.checkoutReferenceId (sbpcCheckout context))]
    :: SqlPersistT IO [Single Bool])
  when (rows == [Single True]) $
    throwError err409
      { errBody = "An online payment attempt is still active; verify or cancel it before selecting manual payment" }

serviceBookingPaymentIdempotencyKey
  :: ServiceBookingPaymentContext
  -> Checkout.PaymentProvider
  -> Checkout.PaymentOperation
  -> Text
serviceBookingPaymentIdempotencyKey context provider operation =
  marketplaceSha256Text $
    "service-booking-payment:"
      <> sbpcCreateIdempotencyKey context
      <> ":" <> Checkout.paymentProviderText provider
      <> ":" <> case operation of
        Checkout.OperationCreate -> "create"
        Checkout.OperationAuthorize -> "authorize"
        Checkout.OperationCapture -> "capture"
        Checkout.OperationManualVerify -> "manual-verify"

serviceBookingPaymentCorrelationId
  :: ServiceBookingPaymentContext
  -> Checkout.PaymentProvider
  -> Text
  -> Text
serviceBookingPaymentCorrelationId context provider operation =
  "service-booking:"
    <> toPathPiece (sbpcBookingKey context)
    <> ":" <> Checkout.paymentProviderText provider
    <> ":" <> operation

beginServiceBookingPaymentAttempt
  :: ServiceBookingPaymentContext
  -> Checkout.PaymentProvider
  -> Checkout.PaymentOperation
  -> Text
  -> Text
  -> AppM Checkout.PaymentAttemptReference
beginServiceBookingPaymentAttempt context provider operation merchantRef operationLabel = do
  now <- liftIO getCurrentTime
  result <- runDB $ PaymentRuntime.beginPaymentAttempt Checkout.PaymentAttemptCreation
    { Checkout.pacCheckout = sbpcCheckout context
    , Checkout.pacProvider = provider
    , Checkout.pacEnvironment = sbpcEnvironment context
    , Checkout.pacOperation = operation
    , Checkout.pacAmountMinor = sbpcDepositMinor context
    , Checkout.pacCurrency = sbpcCurrency context
    , Checkout.pacMerchantRef = merchantRef
    , Checkout.pacIdempotencyKey = serviceBookingPaymentIdempotencyKey context provider operation
    , Checkout.pacCreatedAt = now
    , Checkout.pacCorrelationId = serviceBookingPaymentCorrelationId
        context provider operationLabel
    }
  either (throwError . marketplaceCheckoutConflict) pure result

failServiceBookingPaymentAttempt
  :: ServiceBookingPaymentContext
  -> Checkout.PaymentAttemptReference
  -> Checkout.PaymentProvider
  -> Text
  -> ServerError
  -> AppM a
failServiceBookingPaymentAttempt context attempt provider failureCode providerError = do
  now <- liftIO getCurrentTime
  runDB $ Checkout.recordPaymentFailure
    (sbpcCheckout context)
    attempt
    provider
    failureCode
    (serviceBookingPaymentCorrelationId context provider "provider-error")
    now
  throwError providerError

loadServiceBookingProviderBinding
  :: ServiceBookingPaymentContext
  -> Checkout.PaymentProvider
  -> Text
  -> Text
  -> AppM (Maybe (Text, Maybe Text))
loadServiceBookingProviderBinding context provider merchantRef resourceType = do
  rows <- runDB (rawSql
    "SELECT binding.provider_resource_id, binding.provider_resource_path\
    \ FROM commerce_provider_binding binding\
    \ JOIN commerce_payment_attempt attempt ON attempt.id = binding.payment_attempt_id\
    \ WHERE attempt.checkout_id = ?::uuid AND attempt.provider = ?\
    \ AND attempt.environment = ? AND attempt.merchant_account_ref = ?\
    \ AND binding.provider = attempt.provider\
    \ AND binding.environment = attempt.environment\
    \ AND binding.merchant_account_ref = attempt.merchant_account_ref\
    \ AND binding.resource_type = ? AND binding.merchant_reference = ?\
    \ AND binding.amount_minor = ? AND binding.currency = ?"
    [ PersistText (Checkout.checkoutReferenceId (sbpcCheckout context))
    , PersistText (Checkout.paymentProviderText provider)
    , PersistText (Checkout.checkoutEnvironmentText (sbpcEnvironment context))
    , PersistText merchantRef
    , PersistText resourceType
    , PersistText (toPathPiece (sbpcBookingKey context))
    , PersistInt64 (sbpcDepositMinor context)
    , PersistText (sbpcCurrency context)
    ] :: SqlPersistT IO [(Single Text, Single (Maybe Text))])
  case rows of
    [] -> pure Nothing
    [(Single resourceId, Single resourcePath)] -> pure (Just (resourceId, resourcePath))
    _ -> throwError (marketplaceCheckoutInternal
      "Service booking provider binding is ambiguous")

bindServiceBookingProviderResource
  :: ServiceBookingPaymentContext
  -> Checkout.PaymentAttemptReference
  -> Checkout.PaymentProvider
  -> Checkout.CheckoutEnvironment
  -> Text
  -> Text
  -> Text
  -> Maybe Text
  -> Checkout.PaymentAttemptStage
  -> Text
  -> AppM ()
bindServiceBookingProviderResource
    context attempt provider environment merchantRef resourceType resourceId resourcePath stage operationLabel = do
  now <- liftIO getCurrentTime
  result <- runDB $ Checkout.bindProviderResource Checkout.ProviderBindingCreation
    { Checkout.pbcAttempt = attempt
    , Checkout.pbcCheckout = sbpcCheckout context
    , Checkout.pbcProvider = provider
    , Checkout.pbcEnvironment = environment
    , Checkout.pbcMerchantRef = merchantRef
    , Checkout.pbcResourceType = resourceType
    , Checkout.pbcProviderResource = resourceId
    , Checkout.pbcResourcePath = resourcePath
    , Checkout.pbcOrderReference = toPathPiece (sbpcBookingKey context)
    , Checkout.pbcAmountMinor = sbpcDepositMinor context
    , Checkout.pbcCurrency = sbpcCurrency context
    , Checkout.pbcStage = stage
    , Checkout.pbcOccurredAt = now
    , Checkout.pbcCorrelationId = serviceBookingPaymentCorrelationId
        context provider operationLabel
    }
  either (throwError . marketplaceCheckoutConflict) pure result

createPublicBookingDatafastCheckout
  :: Int64
  -> Maybe Text
  -> AppM DatafastCheckoutDTO
createPublicBookingDatafastCheckout rawBookingId mLookupToken = do
  context <- requireServiceBookingPaymentContext rawBookingId mLookupToken
  when (sbpcCheckoutStatus context == "paid") $
    throwError err409 { errBody = "This booking deposit is already paid" }
  ensureNoSubmittedServiceBookingManualEvidence context
  datafast <- ServiceStorefront.loadServiceDatafastEnv
  requireServiceBookingProvider
    context (ServiceStorefront.sdfEnvironment datafast) Checkout.ProviderDatafast
  attempt <- beginServiceBookingPaymentAttempt
    context Checkout.ProviderDatafast Checkout.OperationCreate
    (ServiceStorefront.sdfEntityId datafast) "create"
  existing <- loadServiceBookingProviderBinding
    context Checkout.ProviderDatafast (ServiceStorefront.sdfEntityId datafast) "checkout"
  (checkoutId, widgetUrl) <- case existing of
    Just (storedCheckoutId, _) -> pure
      ( storedCheckoutId
      , normalizeBaseUrl (ServiceStorefront.sdfBaseUrl datafast)
          <> "/v1/paymentWidgets.js?checkoutId=" <> T.unpack storedCheckoutId
      )
    Nothing -> ServiceStorefront.requestDatafastCheckoutForService
      (toPathPiece (sbpcBookingKey context))
      (fromIntegral (sbpcDepositMinor context))
      (sbpcCurrency context)
      (sbpcBuyerName context)
      (sbpcBuyerEmail context)
      (sbpcBuyerPhone context)
      `catchError` failServiceBookingPaymentAttempt
        context attempt Checkout.ProviderDatafast "datafast_checkout_create"
  let resourcePath = "/v1/checkouts/" <> checkoutId <> "/payment"
  bindServiceBookingProviderResource
    context attempt Checkout.ProviderDatafast (ServiceStorefront.sdfEnvironment datafast)
    (ServiceStorefront.sdfEntityId datafast) "checkout" checkoutId
    (Just resourcePath) Checkout.AttemptRequiresCustomerAction "create"
  pure DatafastCheckoutDTO
    { dcOrderId = toPathPiece (sbpcBookingKey context)
    , dcCheckoutId = checkoutId
    , dcWidgetUrl = T.pack widgetUrl
    , dcAmount = Internationalization.formatMinorUnitsDecimal
        (sbpcCurrency context) (fromIntegral (sbpcDepositMinor context))
    , dcCurrency = sbpcCurrency context
    , dcLookupToken = Nothing
    }

confirmPublicBookingDatafastStatus
  :: Int64
  -> Maybe Text
  -> Text
  -> AppM Api.PublicBookingCheckoutDTO
confirmPublicBookingDatafastStatus rawBookingId mLookupToken rawResourcePath = do
  initialContext <- authorizeServiceBookingPaymentContext rawBookingId mLookupToken
  nowBeforeVerification <- liftIO getCurrentTime
  when
      ( sbpcHoldExpiresAt initialContext <= nowBeforeVerification
        && sbpcCheckoutStatus initialContext `elem` ["holding", "awaiting_payment", "failed"]
      ) $ do
    _ <- runDB (rawSql "SELECT service_booking_expire_holds(?)"
      [PersistUTCTime nowBeforeVerification] :: SqlPersistT IO [Single Int])
    pure ()
  context <- loadServiceBookingPaymentContext (sbpcBookingKey initialContext)
  if sbpcCheckoutStatus context == "paid"
    then loadPublicBookingCheckoutDTO (sbpcBookingKey context) Nothing
    else do
      datafast <- ServiceStorefront.loadServiceDatafastEnv
      unless (ServiceStorefront.sdfEnvironment datafast == sbpcEnvironment context) $
        throwError err503
          { errBody = "Configured Datafast environment does not match this immutable booking checkout" }
      existing <- loadServiceBookingProviderBinding
        context Checkout.ProviderDatafast (ServiceStorefront.sdfEntityId datafast) "checkout"
      (checkoutId, storedResourcePath) <- maybe
        (throwError err409 { errBody = "This booking has no bound Datafast checkout" })
        pure
        existing
      resourcePath <- either
        (throwError . marketplaceCheckoutBadRequest)
        pure
        (ServiceStorefront.validateDatafastOrderResourcePath (Just checkoutId) rawResourcePath)
      unless (storedResourcePath == Just resourcePath) $
        throwError err409
          { errBody = "Datafast resource path does not match the immutable booking binding" }
      attempt <- beginServiceBookingPaymentAttempt
        context Checkout.ProviderDatafast Checkout.OperationCreate
        (ServiceStorefront.sdfEntityId datafast) "create"
      providerStatus <- ServiceStorefront.checkDatafastPaymentStatus resourcePath
        `catchError` failServiceBookingPaymentAttempt
          context attempt Checkout.ProviderDatafast "datafast_status_request"
      now <- liftIO getCurrentTime
      let resultCode = ServiceStorefront.sdfpsResultCode providerStatus
          success = ServiceStorefront.isDatafastPaymentSuccess
            (ServiceStorefront.sdfEnvironment datafast) resultCode
          pending = resultCode == "000.200.000"
      if success
        then do
          case ServiceStorefront.validateDatafastSuccessfulPayment
              (toPathPiece (sbpcBookingKey context))
              (fromIntegral (sbpcDepositMinor context))
              (sbpcCurrency context)
              providerStatus of
            Left validationMessage -> do
              let actualAmount = ServiceStorefront.sdfpsAmount providerStatus
                    >>= either (const Nothing) Just . ServiceStorefront.parseDatafastCents
                  providerRef = fromMaybe checkoutId
                    (ServiceStorefront.sdfpsPaymentId providerStatus)
              runDB $ do
                Checkout.recordReconciliationException
                  Checkout.ProviderDatafast (sbpcEnvironment context)
                  (ServiceStorefront.sdfEntityId datafast)
                  "provider_binding_mismatch"
                  (toPathPiece (sbpcBookingKey context))
                  providerRef
                  (sbpcDepositMinor context)
                  (fromIntegral <$> actualAmount)
                  (sbpcCurrency context)
                  now
                Checkout.recordPaymentFailure
                  (sbpcCheckout context) attempt Checkout.ProviderDatafast
                  "provider_binding_mismatch"
                  (serviceBookingPaymentCorrelationId context Checkout.ProviderDatafast "status")
                  now
              throwError err502
                { errBody = BL.fromStrict (TE.encodeUtf8 validationMessage) }
            Right () -> pure ()
          when (sbpcCheckoutStatus context == "expired") $ do
            let actualAmount = ServiceStorefront.sdfpsAmount providerStatus
                  >>= either (const Nothing) Just . ServiceStorefront.parseDatafastCents
                providerRef = fromMaybe checkoutId
                  (ServiceStorefront.sdfpsPaymentId providerStatus)
            runDB $ Checkout.recordReconciliationException
              Checkout.ProviderDatafast (sbpcEnvironment context)
              (ServiceStorefront.sdfEntityId datafast)
              "payment_after_booking_hold_expiry"
              (toPathPiece (sbpcBookingKey context))
              providerRef
              (sbpcDepositMinor context)
              (fromIntegral <$> actualAmount)
              (sbpcCurrency context)
              now
            throwError err409
              { errBody = "Datafast reports payment after this booking hold expired; staff reconciliation is required and the booking is not confirmed" }
          paymentId <- maybe
            (throwError err502 { errBody = "Datafast payment ID is missing" })
            pure
            (ServiceStorefront.sdfpsPaymentId providerStatus)
          bindServiceBookingProviderResource
            context attempt Checkout.ProviderDatafast (sbpcEnvironment context)
            (ServiceStorefront.sdfEntityId datafast) "payment" paymentId
            (Just resourcePath) Checkout.AttemptProcessing "status"
          verified <- runDB $ Checkout.recordVerifiedPayment Checkout.VerifiedPayment
            { Checkout.vpAttempt = attempt
            , Checkout.vpCheckout = sbpcCheckout context
            , Checkout.vpProvider = Checkout.ProviderDatafast
            , Checkout.vpEnvironment = sbpcEnvironment context
            , Checkout.vpMerchantRef = ServiceStorefront.sdfEntityId datafast
            , Checkout.vpResourceType = "checkout"
            , Checkout.vpProviderResource = checkoutId
            , Checkout.vpProviderResourcePath = Just resourcePath
            , Checkout.vpOrderReference = toPathPiece (sbpcBookingKey context)
            , Checkout.vpProviderReference = toPathPiece (sbpcBookingKey context)
            , Checkout.vpAmountMinor = sbpcDepositMinor context
            , Checkout.vpCurrency = sbpcCurrency context
            , Checkout.vpEvidence = "server_to_server"
            , Checkout.vpOccurredAt = now
            , Checkout.vpCorrelationId = serviceBookingPaymentCorrelationId
                context Checkout.ProviderDatafast "status"
            }
          either (throwError . marketplaceCheckoutConflict) (const (pure ())) verified
        else if sbpcCheckoutStatus context == "expired"
          then pure ()
          else if pending
          then runDB $ Checkout.recordPaymentProcessing
            (sbpcCheckout context) attempt Checkout.ProviderDatafast
            (serviceBookingPaymentCorrelationId context Checkout.ProviderDatafast "status")
            now
          else runDB $ Checkout.recordPaymentFailure
            (sbpcCheckout context) attempt Checkout.ProviderDatafast resultCode
            (serviceBookingPaymentCorrelationId context Checkout.ProviderDatafast "status")
            now
      loadPublicBookingCheckoutDTO (sbpcBookingKey context) Nothing

createPublicBookingPaypalOrder
  :: Int64
  -> Maybe Text
  -> AppM PaypalCreateDTO
createPublicBookingPaypalOrder rawBookingId mLookupToken = do
  context <- requireServiceBookingPaymentContext rawBookingId mLookupToken
  when (sbpcCheckoutStatus context == "paid") $
    throwError err409 { errBody = "This booking deposit is already paid" }
  ensureNoSubmittedServiceBookingManualEvidence context
  (clientId, clientSecret, baseUrl, paypalEnvironment, merchantRef) <-
    ServiceStorefront.loadPaypalEnvForService
  requireServiceBookingProvider context paypalEnvironment Checkout.ProviderPayPal
  attempt <- beginServiceBookingPaymentAttempt
    context Checkout.ProviderPayPal Checkout.OperationCreate merchantRef "create"
  existing <- loadServiceBookingProviderBinding
    context Checkout.ProviderPayPal merchantRef "order"
  (paypalOrderId, approvalUrl) <- case existing of
    Just (storedOrderId, _) -> pure (storedOrderId, Nothing)
    Nothing -> ServiceStorefront.createPaypalOrderRemoteForService
      sharedProviderManager clientId clientSecret baseUrl
      (toPathPiece (sbpcBookingKey context))
      (fromIntegral (sbpcDepositMinor context))
      (sbpcCurrency context)
      (sbpcBuyerName context)
      (sbpcBuyerEmail context)
      `catchError` failServiceBookingPaymentAttempt
        context attempt Checkout.ProviderPayPal "paypal_create_order"
  bindServiceBookingProviderResource
    context attempt Checkout.ProviderPayPal paypalEnvironment merchantRef
    "order" paypalOrderId (Just ("/v2/checkout/orders/" <> paypalOrderId))
    Checkout.AttemptRequiresCustomerAction "create"
  pure PaypalCreateDTO
    { pcOrderId = toPathPiece (sbpcBookingKey context)
    , pcPaypalOrderId = paypalOrderId
    , pcApprovalUrl = approvalUrl
    , pcLookupToken = Nothing
    }

capturePublicBookingPaypalOrder
  :: Int64
  -> Maybe Text
  -> Api.PublicBookingPaypalCaptureReq
  -> AppM Api.PublicBookingCheckoutDTO
capturePublicBookingPaypalOrder
    rawBookingId mLookupToken Api.PublicBookingPaypalCaptureReq{..} = do
  context <- requireServiceBookingPaymentContext rawBookingId mLookupToken
  if sbpcCheckoutStatus context == "paid"
    then loadPublicBookingCheckoutDTO (sbpcBookingKey context) Nothing
    else do
      ensureNoSubmittedServiceBookingManualEvidence context
      suppliedPaypalOrderId <- either throwError pure $
        validatePayPalCaptureOrderId pbpcPaypalOrderId
      (clientId, clientSecret, baseUrl, paypalEnvironment, merchantRef) <-
        ServiceStorefront.loadPaypalEnvForService
      requireServiceBookingProvider context paypalEnvironment Checkout.ProviderPayPal
      existing <- loadServiceBookingProviderBinding
        context Checkout.ProviderPayPal merchantRef "order"
      storedPaypalOrderId <- maybe
        (throwError err409 { errBody = "This booking has no bound PayPal order" })
        (pure . fst)
        existing
      unless (storedPaypalOrderId == suppliedPaypalOrderId) $
        throwError err409
          { errBody = "PayPal order does not match the immutable booking binding" }
      attempt <- beginServiceBookingPaymentAttempt
        context Checkout.ProviderPayPal Checkout.OperationCapture merchantRef "capture"
      outcome <- ServiceStorefront.capturePaypalOrderRemoteForService
        sharedProviderManager clientId clientSecret baseUrl suppliedPaypalOrderId
        `catchError` failServiceBookingPaymentAttempt
          context attempt Checkout.ProviderPayPal "paypal_capture_request"
      now <- liftIO getCurrentTime
      case ServiceStorefront.spcoStatus outcome of
        "COMPLETED" -> do
          case ServiceStorefront.validatePaypalSuccessfulCapture
              (toPathPiece (sbpcBookingKey context))
              (fromIntegral (sbpcDepositMinor context))
              (sbpcCurrency context)
              merchantRef
              outcome of
            Left validationMessage -> do
              let actualAmount = ServiceStorefront.spcoAmount outcome
                    >>= either (const Nothing) Just . ServiceStorefront.parseDatafastCents
              runDB $ do
                Checkout.recordReconciliationException
                  Checkout.ProviderPayPal paypalEnvironment merchantRef
                  "provider_binding_mismatch"
                  (toPathPiece (sbpcBookingKey context))
                  suppliedPaypalOrderId
                  (sbpcDepositMinor context)
                  (fromIntegral <$> actualAmount)
                  (sbpcCurrency context)
                  now
                Checkout.recordPaymentFailure
                  (sbpcCheckout context) attempt Checkout.ProviderPayPal
                  "provider_binding_mismatch"
                  (serviceBookingPaymentCorrelationId context Checkout.ProviderPayPal "capture")
                  now
              throwError err502
                { errBody = BL.fromStrict (TE.encodeUtf8 validationMessage) }
            Right () -> pure ()
          captureId <- maybe
            (throwError err502 { errBody = "PayPal capture ID is missing" })
            pure
            (ServiceStorefront.spcoCaptureId outcome)
          bindServiceBookingProviderResource
            context attempt Checkout.ProviderPayPal paypalEnvironment merchantRef
            "capture" captureId
            (Just ("/v2/checkout/orders/" <> suppliedPaypalOrderId <> "/capture"))
            Checkout.AttemptProcessing "capture"
          verified <- runDB $ Checkout.recordVerifiedPayment Checkout.VerifiedPayment
            { Checkout.vpAttempt = attempt
            , Checkout.vpCheckout = sbpcCheckout context
            , Checkout.vpProvider = Checkout.ProviderPayPal
            , Checkout.vpEnvironment = paypalEnvironment
            , Checkout.vpMerchantRef = merchantRef
            , Checkout.vpResourceType = "capture"
            , Checkout.vpProviderResource = captureId
            , Checkout.vpProviderResourcePath = Just
                ("/v2/checkout/orders/" <> suppliedPaypalOrderId <> "/capture")
            , Checkout.vpOrderReference = toPathPiece (sbpcBookingKey context)
            , Checkout.vpProviderReference = toPathPiece (sbpcBookingKey context)
            , Checkout.vpAmountMinor = sbpcDepositMinor context
            , Checkout.vpCurrency = sbpcCurrency context
            , Checkout.vpEvidence = "server_to_server"
            , Checkout.vpOccurredAt = now
            , Checkout.vpCorrelationId = serviceBookingPaymentCorrelationId
                context Checkout.ProviderPayPal "capture"
            }
          either (throwError . marketplaceCheckoutConflict) (const (pure ())) verified
        "APPROVED" -> runDB $ Checkout.recordPaymentProcessing
          (sbpcCheckout context) attempt Checkout.ProviderPayPal
          (serviceBookingPaymentCorrelationId context Checkout.ProviderPayPal "capture")
          now
        "PENDING" -> runDB $ Checkout.recordPaymentProcessing
          (sbpcCheckout context) attempt Checkout.ProviderPayPal
          (serviceBookingPaymentCorrelationId context Checkout.ProviderPayPal "capture")
          now
        status -> runDB $ Checkout.recordPaymentFailure
          (sbpcCheckout context) attempt Checkout.ProviderPayPal
          ("paypal_" <> T.toLower status)
          (serviceBookingPaymentCorrelationId context Checkout.ProviderPayPal "capture")
          now
      loadPublicBookingCheckoutDTO (sbpcBookingKey context) Nothing

selectPublicBookingManualPayment
  :: Int64
  -> Maybe Text
  -> Api.PublicBookingManualPaymentReq
  -> AppM Api.PublicBookingCheckoutDTO
selectPublicBookingManualPayment
    rawBookingId mLookupToken Api.PublicBookingManualPaymentReq{..} = do
  context <- requireServiceBookingPaymentContext rawBookingId mLookupToken
  let method = T.toLower (T.strip pbmprPaymentMethod)
  unless (method == "bank_transfer") $
    throwError err400 { errBody = "Only bank transfer is available for public manual payment" }
  when (sbpcCheckoutStatus context == "processing") $
    throwError err409
      { errBody = "Another payment rail is currently processing; verify it before switching methods" }
  ensureNoActiveServiceBookingOnlineAttempt context
  requireServiceBookingProvider
    context (sbpcEnvironment context) Checkout.ProviderBankTransfer
  attempt <- beginServiceBookingPaymentAttempt
    context Checkout.ProviderBankTransfer Checkout.OperationManualVerify
    "tdf-manual-settlement" "manual-select"
  now <- liftIO getCurrentTime
  runDB $ Checkout.recordManualPaymentSelection
    (sbpcCheckout context) attempt Checkout.ProviderBankTransfer
    (serviceBookingPaymentCorrelationId context Checkout.ProviderBankTransfer "manual-select")
    now
  loadPublicBookingCheckoutDTO (sbpcBookingKey context) Nothing

validatePublicBookingManualReference :: Text -> Either ServerError Text
validatePublicBookingManualReference raw
  | T.length clean < 3 || T.length clean > 120 =
      Left err400 { errBody = "Bank transfer reference must contain 3 to 120 characters" }
  | T.any isUnsafeAccessRequestTextChar clean =
      Left err400 { errBody = "Bank transfer reference contains unsupported characters" }
  | otherwise = Right clean
  where
    clean = T.strip raw

submitPublicBookingManualEvidence
  :: Int64
  -> Maybe Text
  -> Api.PublicBookingManualEvidenceReq
  -> AppM Api.PublicBookingCheckoutDTO
submitPublicBookingManualEvidence
    rawBookingId mLookupToken Api.PublicBookingManualEvidenceReq{..} = do
  context <- requireServiceBookingPaymentContext rawBookingId mLookupToken
  customerReference <- either throwError pure $
    validatePublicBookingManualReference pbmeCustomerReference
  outcome <- runDB $ do
    rows <- (rawSql
      "SELECT evidence.id::text, evidence.status, evidence.customer_reference,\
      \ evidence.submitted_by, attempt.id::text, booked.party_id\
      \ FROM commerce_manual_payment_evidence evidence\
      \ JOIN commerce_payment_attempt attempt ON attempt.id = evidence.payment_attempt_id\
      \ JOIN service_booking_checkout_runtime runtime ON runtime.checkout_id = evidence.checkout_id\
      \ JOIN booking booked ON booked.id = runtime.booking_id\
      \ WHERE evidence.checkout_id = ?::uuid\
      \ AND attempt.checkout_id = evidence.checkout_id\
      \ AND attempt.provider = 'bank_transfer'\
      \ AND attempt.operation = 'manual_verify'\
      \ FOR UPDATE OF evidence, attempt"
      [PersistText (Checkout.checkoutReferenceId (sbpcCheckout context))]
      :: SqlPersistT IO
        [( Single Text, Single Text, Single (Maybe Text), Single (Maybe Int64)
         , Single Text, Single (Maybe Int64)
         )])
    case rows of
      [( Single evidenceId, Single status, Single existingReference
       , Single existingSubmitter, Single attemptId, Single mCustomerId
       )] -> case mCustomerId of
        Nothing -> pure (Left "Booking customer identity is missing")
        Just customerId
          | status `elem` ["submitted", "under_review"]
              && existingReference == Just customerReference
              && existingSubmitter == Just customerId -> pure (Right ())
          | status == "approved" -> pure (Right ())
          | status `elem` ["submitted", "under_review"] ->
              pure (Left "Different manual evidence is already under review")
          | status `elem` ["awaiting_evidence", "rejected"] -> do
              now <- liftIO getCurrentTime
              when (status == "rejected") $
                Checkout.recordManualPaymentSelection
                  (sbpcCheckout context)
                  (Checkout.PaymentAttemptReference attemptId)
                  Checkout.ProviderBankTransfer
                  (serviceBookingPaymentCorrelationId
                    context Checkout.ProviderBankTransfer "manual-resubmit")
                  now
              rawExecute
                "UPDATE commerce_manual_payment_evidence\
                \ SET customer_reference = ?, submitted_amount_minor = ?, currency = ?,\
                \ submitted_at = ?, submitted_by = ?, status = 'submitted',\
                \ reviewed_by = NULL, reviewed_at = NULL, review_notes = NULL\
                \ WHERE id = ?::uuid"
                [ PersistText customerReference
                , PersistInt64 (sbpcDepositMinor context)
                , PersistText (sbpcCurrency context)
                , PersistUTCTime now
                , PersistInt64 customerId
                , PersistText evidenceId
                ]
              rawExecute
                "INSERT INTO commerce_checkout_audit_event(\
                \ checkout_id, event_type, actor_type, actor_id, correlation_id, metadata\
                \) VALUES (?::uuid, 'manual_payment_evidence_submitted', 'customer', ?, ?,\
                \ jsonb_build_object('attempt_id', ?))"
                [ PersistText (Checkout.checkoutReferenceId (sbpcCheckout context))
                , PersistText (T.pack (show customerId))
                , PersistText (serviceBookingPaymentCorrelationId
                    context Checkout.ProviderBankTransfer "manual-evidence")
                , PersistText attemptId
                ]
              pure (Right ())
          | otherwise -> pure (Left "Manual evidence cannot be submitted in its current state")
      [] -> pure (Left "Select bank transfer before submitting evidence")
      _ -> pure (Left "Manual payment evidence is ambiguous")
  either (throwError . marketplaceCheckoutConflict) pure outcome
  loadPublicBookingCheckoutDTO (sbpcBookingKey context) Nothing

createPublicBookingCheckout
  :: Maybe Text
  -> Api.PublicBookingCheckoutReq
  -> AppM Api.PublicBookingCheckoutDTO
createPublicBookingCheckout mIdempotency Api.PublicBookingCheckoutReq{..} = do
  unless pbcTermsAccepted $
    throwError err400 { errBody = "Booking terms must be accepted before checkout" }
  idempotencyKey <- either (throwError . marketplaceCheckoutBadRequest) pure $
    ServiceStorefront.validateIdempotencyKey mIdempotency
  fullNameClean <- either throwError pure (validatePublicBookingFullName pbcFullName)
  (emailClean, phoneClean) <- either throwError pure $
    validatePublicBookingContactDetails pbcEmail pbcPhone
  durationMinutes <- either throwError pure $
    validatePublicBookingDurationMinutes (Just pbcDurationMinutes)
  now <- liftIO getCurrentTime
  startsAtClean <- either throwError pure $
    validatePublicBookingStartAt now pbcStartsAt
  offering@(Entity offeringKey offeringValue) <- runDB $
    loadSelectableServiceOffering now pbcServiceOfferingId
  policy <- runDB (loadApprovedServiceBookingPolicy now offeringKey)
    >>= maybe (throwError err409
          { errBody = "This service does not have an approved active booking price and policy" }) pure
  price <- either throwError pure $
    calculateApprovedServiceBookingPrice policy durationMinutes
  when (ServiceBookings.bpbTotalMinor price > fromIntegral (maxBound :: Int)) $
    throwError err409 { errBody = "Booking quote exceeds the supported service-order range" }
  checkoutEnvironment <- loadMarketplaceCheckoutEnvironment
  domainEnabled <- runDB $
    Checkout.domainEnabledForEnvironment checkoutEnvironment "service_bookings"
  unless domainEnabled $
    throwError err503 { errBody = "Public service booking checkout is disabled in this environment" }
  engineerIdClean <- either throwError pure $
    validateOptionalPositiveIdField "engineerPartyId" pbcEngineerPartyId
  let engineerNameClean = normalizeOptionalInput pbcEngineerName
  case validateEngineer
      (Catalog.serviceOfferingRequiresEngineer offeringValue)
      engineerIdClean engineerNameClean of
    Left message -> throwBadRequest message
    Right () -> pure ()
  mEngineerParty <- runDB (resolveOptionalBookingEngineerReference engineerIdClean)
    >>= either throwError pure
  notesClean <- either throwError pure (validatePublicBookingNotes pbcNotes)
  let endsAtClean = addUTCTime (fromIntegral durationMinutes * 60) startsAtClean
      requestedResourceIds = fromMaybe [] pbcResourceIds
      requestHash = marketplaceSha256Text . TE.decodeUtf8 . BL.toStrict . encode $ object
        [ "full_name" .= fullNameClean
        , "email" .= emailClean
        , "phone" .= phoneClean
        , "service_offering_id" .= UUID.toText pbcServiceOfferingId
        , "starts_at" .= startsAtClean
        , "duration_minutes" .= durationMinutes
        , "notes" .= notesClean
        , "engineer_party_id" .= engineerIdClean
        , "engineer_name" .= engineerNameClean
        , "resource_ids" .= requestedResourceIds
        , "terms_version" .= asbpTermsVersion policy
        ]
  existing <- lookupServiceBookingIdempotency idempotencyKey
  let lookupToken = marketplaceSha256Text
        ("service-booking-order-lookup:" <> idempotencyKey)
  case existing of
    Just (existingBookingKey, storedHash)
      | storedHash == requestHash ->
          loadPublicBookingCheckoutDTO existingBookingKey (Just lookupToken)
      | otherwise -> throwError err409
          { errBody = "Idempotency key was already used for a different booking checkout" }
    Nothing -> do
      resourceKeys <- runDB $
        resolveResourcesForBooking (Just offering) requestedResourceIds startsAtClean endsAtClean
      let lookupHash = marketplaceSha256Text lookupToken
          holdExpiresAt = addUTCTime (fromIntegral (asbpHoldMinutes policy) * 60) now
          resolvedEngineerName = resolveBookingEngineerName engineerNameClean mEngineerParty
      creation <- createServiceBookingCheckoutTransaction
        checkoutEnvironment now holdExpiresAt idempotencyKey requestHash lookupHash
        fullNameClean emailClean notesClean phoneClean mEngineerParty resolvedEngineerName
        offering policy price startsAtClean endsAtClean resourceKeys
      case creation of
        Left serverErr -> throwError serverErr
        Right bookingKey -> loadPublicBookingCheckoutDTO bookingKey (Just lookupToken)

lookupServiceBookingIdempotency
  :: Text
  -> AppM (Maybe (Key Booking, Text))
lookupServiceBookingIdempotency idempotencyKey = do
  rows <- runDB (rawSql
    "SELECT booking_id, create_request_sha256\
    \ FROM service_booking_checkout_runtime WHERE create_idempotency_key = ?"
    [PersistText idempotencyKey]
    :: SqlPersistT IO [(Single Int64, Single Text)])
  pure $ case rows of
    [(Single bookingId, Single requestHash)] ->
      Just (toSqlKey bookingId, requestHash)
    _ -> Nothing

createServiceBookingCheckoutTransaction
  :: Checkout.CheckoutEnvironment
  -> UTCTime
  -> UTCTime
  -> Text
  -> Text
  -> Text
  -> Text
  -> Text
  -> Maybe Text
  -> Maybe Text
  -> Maybe (Entity Party)
  -> Maybe Text
  -> Entity Catalog.ServiceOffering
  -> ApprovedServiceBookingPolicy
  -> ServiceBookings.BookingPriceBreakdown
  -> UTCTime
  -> UTCTime
  -> [Key Resource]
  -> AppM (Either ServerError (Key Booking))
createServiceBookingCheckoutTransaction
    checkoutEnvironment now holdExpiresAt idempotencyKey requestHash lookupHash
    fullNameClean emailClean notesClean phoneClean mEngineerParty resolvedEngineerName
    (Entity offeringKey offering) policy price startsAtClean endsAtClean resourceKeys = do
  Env{ envPool } <- ask
  result <- liftIO $
    (try (flip runSqlPool envPool transactionBody)
      :: IO (Either SomeException (Either ServerError (Key Booking))))
  case result of
    Right value -> pure value
    Left exception -> case fromException exception :: Maybe SomeAsyncException of
      Just _ -> liftIO (throwIO exception)
      Nothing -> case fromException exception :: Maybe SqlError of
        Just sqlError | sqlState sqlError == "23P01" -> pure (Left err409
          { errBody = "The selected room or resource was reserved by another request" })
        _ -> liftIO (throwIO exception)
  where
    transactionBody = do
      _ <- (rawSql
        "SELECT 1::bigint FROM (SELECT pg_advisory_xact_lock(hashtextextended(?, 0))) locked"
        [PersistText ("service-booking:" <> idempotencyKey)]
        :: SqlPersistT IO [Single Int64])
      existing <- (rawSql
        "SELECT booking_id, create_request_sha256\
        \ FROM service_booking_checkout_runtime WHERE create_idempotency_key = ?"
        [PersistText idempotencyKey]
        :: SqlPersistT IO [(Single Int64, Single Text)])
      case existing of
        [(Single existingBookingId, Single storedHash)]
          | storedHash == requestHash -> pure (Right (toSqlKey existingBookingId))
          | otherwise -> pure (Left err409
              { errBody = "Idempotency key was already used for a different booking checkout" })
        [] -> createNew
        _ -> pure (Left err500 { errBody = "Booking idempotency lookup was ambiguous" })
    createNew = do
      _ <- (rawSql "SELECT service_booking_expire_holds(?)"
        [PersistUTCTime now] :: SqlPersistT IO [Single Int])
      forM_ resourceKeys $ \resourceKey -> do
        _ <- (rawSql "SELECT id FROM resource WHERE id = ? FOR UPDATE"
          [toPersistValue resourceKey] :: SqlPersistT IO [Single Int64])
        pure ()
      catalogKey <- case Catalog.serviceOfferingLegacyServiceCatalogId offering of
        Just catalogId -> pure (toSqlKey catalogId :: Key ServiceCatalog)
        Nothing -> liftIO . throwIO $ err409
          { errBody = "Approved booking service is not linked to the service-order catalog" }
      mCatalog <- get catalogKey
      catalog <- maybe (liftIO . throwIO $ err409
          { errBody = "Approved booking service references a missing service-order catalog" }) pure mCatalog
      let totalMinorInt = fromIntegral (ServiceBookings.bpbTotalMinor price)
          serviceLabel = Catalog.serviceOfferingNameEs offering
      -- The request lock and existing-order check precede contact creation.
      -- Email is contact data, never proof of access to an existing account.
      partyResult <- ensurePartyRecordDb now (Just fullNameClean) emailClean phoneClean
      partyId <- either (liftIO . throwIO) pure partyResult
      serviceOrderKey <- insert ServiceOrder
        { serviceOrderCustomerId = partyId
        , serviceOrderArtistId = entityKey <$> mEngineerParty
        , serviceOrderCatalogId = catalogKey
        , serviceOrderServiceOfferingId = serviceOfferingUUIDFromKey offeringKey
        , serviceOrderServiceKind = serviceCatalogKind catalog
        , serviceOrderTitle = Just (serviceLabel <> " · " <> fullNameClean)
        , serviceOrderDescription = notesClean
        , serviceOrderStatus = "deposit_due"
        , serviceOrderPriceQuotedCents = Just totalMinorInt
        , serviceOrderQuoteSentAt = Just now
        , serviceOrderScheduledStart = Just startsAtClean
        , serviceOrderScheduledEnd = Just endsAtClean
        , serviceOrderCreatedAt = now
        }
      bookingKey <- insert Booking
        { bookingTitle = serviceLabel <> " · " <> fullNameClean
        , bookingServiceOrderId = Just serviceOrderKey
        , bookingPartyId = Just partyId
        , bookingServiceType = Nothing
        , bookingServiceOfferingId = serviceOfferingUUIDFromKey offeringKey
        , bookingBookingTypeId = Nothing
        , bookingWorkflowStateId = Nothing
        , bookingEngineerPartyId = entityKey <$> mEngineerParty
        , bookingEngineerName = resolvedEngineerName
        , bookingStartsAt = startsAtClean
        , bookingEndsAt = endsAtClean
        , bookingStatus = Tentative
        , bookingCreatedBy = Nothing
        , bookingNotes = notesClean
        , bookingCreatedAt = now
        }
      let checkoutSnapshot = object
            [ "domain" .= ("service_booking" :: Text)
            , "booking_id" .= fromSqlKey bookingKey
            , "service_order_id" .= fromSqlKey serviceOrderKey
            , "service_offering_id" .= toPathPiece offeringKey
            , "policy_id" .= asbpId policy
            , "policy_version" .= asbpVersion policy
            , "starts_at" .= startsAtClean
            , "ends_at" .= endsAtClean
            , "duration_minutes" .= ServiceBookings.bpbDurationMinutes price
            , "rate_minor" .= asbpRateMinor policy
            , "rate_unit_minutes" .= asbpRateUnitMinutes policy
            , "tax_bps" .= asbpTaxBps policy
            , "deposit_bps" .= asbpDepositBps policy
            , "subtotal_minor" .= ServiceBookings.bpbSubtotalMinor price
            , "tax_minor" .= ServiceBookings.bpbTaxMinor price
            , "total_minor" .= ServiceBookings.bpbTotalMinor price
            , "deposit_minor" .= ServiceBookings.bpbDepositMinor price
            , "balance_minor" .= ServiceBookings.bpbBalanceMinor price
            , "terms_version" .= asbpTermsVersion policy
            , "resource_ids" .= map toPathPiece resourceKeys
            ]
      checkout <- Checkout.createCheckout Checkout.CheckoutCreation
        { Checkout.ccDomainType = "service_booking"
        , Checkout.ccDomainOrderId = T.pack (show (fromSqlKey bookingKey))
        , Checkout.ccEnvironment = checkoutEnvironment
        , Checkout.ccCurrency = asbpCurrency policy
        , Checkout.ccAmountMinor = ServiceBookings.bpbDepositMinor price
        , Checkout.ccCustomerEmail = emailClean
        , Checkout.ccLookupTokenHash = lookupHash
        , Checkout.ccIdempotencyKey = idempotencyKey
        , Checkout.ccExpiresAt = holdExpiresAt
        , Checkout.ccProductType = "service_booking_deposit"
        , Checkout.ccProductId = toPathPiece offeringKey
        , Checkout.ccProductVersion = asbpVersion policy
        , Checkout.ccDescription = serviceLabel <> " — confirmation deposit"
        , Checkout.ccSnapshot = checkoutSnapshot
        , Checkout.ccCorrelationId = "service-booking-create:" <> T.pack (show (fromSqlKey bookingKey))
        }
      rawExecute
        "INSERT INTO service_booking_checkout_runtime(\
        \ booking_id, service_order_id, checkout_id, service_offering_id, policy_id, policy_version,\
        \ lookup_token_hash, create_idempotency_key, create_request_sha256, fulfillment_status,\
        \ deposit_status, balance_status, starts_at, ends_at, timezone, duration_minutes, currency,\
        \ rate_minor, rate_unit_minutes, tax_bps, deposit_bps, subtotal_minor, tax_minor, total_minor,\
        \ deposit_minor, balance_minor, terms_version, terms_accepted_at, hold_expires_at\
        \) VALUES (?, ?, ?::uuid, ?::uuid, ?::uuid, ?, ?, ?, ?, 'on_hold',\
        \ 'awaiting_payment', 'not_due', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)"
        [ toPersistValue bookingKey
        , toPersistValue serviceOrderKey
        , PersistText (Checkout.checkoutReferenceId checkout)
        , PersistText (toPathPiece offeringKey)
        , PersistText (asbpId policy)
        , PersistText (asbpVersion policy)
        , PersistText lookupHash
        , PersistText idempotencyKey
        , PersistText requestHash
        , PersistUTCTime startsAtClean
        , PersistUTCTime endsAtClean
        , PersistText (asbpTimezone policy)
        , PersistInt64 (fromIntegral (ServiceBookings.bpbDurationMinutes price))
        , PersistText (asbpCurrency policy)
        , PersistInt64 (asbpRateMinor policy)
        , PersistInt64 (fromIntegral (asbpRateUnitMinutes policy))
        , PersistInt64 (fromIntegral (asbpTaxBps policy))
        , PersistInt64 (fromIntegral (asbpDepositBps policy))
        , PersistInt64 (ServiceBookings.bpbSubtotalMinor price)
        , PersistInt64 (ServiceBookings.bpbTaxMinor price)
        , PersistInt64 (ServiceBookings.bpbTotalMinor price)
        , PersistInt64 (ServiceBookings.bpbDepositMinor price)
        , PersistInt64 (ServiceBookings.bpbBalanceMinor price)
        , PersistText (asbpTermsVersion policy)
        , PersistUTCTime holdExpiresAt
        ]
      forM_ (zip [0 :: Int ..] (nub resourceKeys)) $ \(index, resourceKey) ->
        insert_ BookingResource
          { bookingResourceBookingId = bookingKey
          , bookingResourceResourceId = resourceKey
          , bookingResourceRole = if index == 0 then "primary" else "secondary"
          }
      rawExecute
        "INSERT INTO service_booking_event(booking_id, from_status, to_status, actor_type, reason_code, notes)\
        \ VALUES (?, NULL, 'on_hold', 'system', 'checkout_created',\
        \ 'Atomic resource hold created; deposit payment and service fulfillment remain separate')"
        [toPersistValue bookingKey]
      pure (Right bookingKey)

createPublicBooking :: Maybe Text -> PublicBookingReq -> AppM BookingDTO
createPublicBooking mIdempotency PublicBookingReq{..} = do
  idempotencyKey <- either (throwError . marketplaceCheckoutBadRequest) pure $
    ServiceStorefront.validateIdempotencyKey mIdempotency
  fullNameClean <- either throwError pure (validatePublicBookingFullName pbFullName)
  Env pool _ <- ask
  now <- liftIO getCurrentTime
  (emailClean, phoneClean) <-
    either throwError pure $
      validatePublicBookingContactDetails pbEmail pbPhone
  durationMins <-
    either throwError pure $
      validatePublicBookingDurationMinutes pbDurationMinutes
  startsAtClean <-
    either throwError pure $
      validatePublicBookingStartAt now pbStartsAt
  serviceOffering <- runDB $
    loadSelectableServiceOffering now pbServiceOfferingId
  let serviceTypeLabel = Catalog.serviceOfferingNameEs (entityVal serviceOffering)
  engineerIdClean <-
    either throwError pure $
      validateOptionalPositiveIdField "engineerPartyId" pbEngineerPartyId
  let engineerNameClean = normalizeOptionalInput pbEngineerName
  case validateEngineer (Catalog.serviceOfferingRequiresEngineer (entityVal serviceOffering)) engineerIdClean engineerNameClean of
    Left msg -> throwBadRequest msg
    Right () -> pure ()
  mEngineerParty <-
    liftIO (flip runSqlPool pool (resolveOptionalBookingEngineerReference engineerIdClean))
      >>= either throwError pure
  let endsAt       = addUTCTime (fromIntegral durationMins * 60) startsAtClean
  notesClean <-
    either throwError pure $
      validatePublicBookingNotes pbNotes
  let requestedResourceIds = fromMaybe [] pbResourceIds
      requestHash = marketplaceSha256Text . TE.decodeUtf8 . BL.toStrict . encode $ object
        [ "full_name" .= fullNameClean
        , "email" .= emailClean
        , "phone" .= phoneClean
        , "service_offering_id" .= UUID.toText pbServiceOfferingId
        , "starts_at" .= startsAtClean
        , "duration_minutes" .= durationMins
        , "notes" .= notesClean
        , "engineer_party_id" .= engineerIdClean
        , "engineer_name" .= engineerNameClean
        , "resource_ids" .= requestedResourceIds
        ]
  let resolvedEngineerName =
        resolveBookingEngineerName engineerNameClean mEngineerParty
  let bookingRecord partyId = Booking
        { bookingTitle          = serviceTypeLabel <> " · " <> fullNameClean
        , bookingServiceOrderId = Nothing
        , bookingPartyId        = Just partyId
        , bookingServiceType    = Nothing
        , bookingServiceOfferingId = Just pbServiceOfferingId
        , bookingBookingTypeId = Nothing
        , bookingWorkflowStateId = Nothing
        , bookingEngineerPartyId = entityKey <$> mEngineerParty
        , bookingEngineerName    = resolvedEngineerName
        , bookingStartsAt       = startsAtClean
        , bookingEndsAt         = endsAt
        , bookingStatus         = Tentative
        , bookingCreatedBy      = Nothing
        , bookingNotes          = notesClean
        , bookingCreatedAt      = now
        }
  creation <- createPublicTentativeBookingTransaction
    idempotencyKey requestHash now (Just fullNameClean) emailClean phoneClean
    bookingRecord
    (resolveResourcesForBooking
      (Just serviceOffering) requestedResourceIds startsAtClean endsAt)
  (bookingId, createdNow) <- either throwError pure creation
  dtoResult <- liftIO $ flip runSqlPool pool $ do
    created <- getJustEntity bookingId
    dtos <- buildBookingDTOs [created]
    pure (requirePersistedBookingDTO dtos)
  dto <- either throwError pure dtoResult
  when createdNow (notifyEngineerIfNeeded dto)
  pure dto

createPublicTentativeBookingTransaction
  :: Text
  -> Text
  -> UTCTime
  -> Maybe Text
  -> Text
  -> Maybe Text
  -> (Key Party -> Booking)
  -> SqlPersistT IO [Key Resource]
  -> AppM (Either ServerError (Key Booking, Bool))
createPublicTentativeBookingTransaction
    idempotencyKey requestHash now partyName emailClean phoneClean buildBooking resolveResourceKeys = do
  Env{ envPool } <- ask
  result <- liftIO $
    (try (flip runSqlPool envPool transactionBody)
      :: IO (Either SomeException (Either ServerError (Key Booking, Bool))))
  case result of
    Right value -> pure value
    Left exception -> case fromException exception :: Maybe SomeAsyncException of
      Just _ -> liftIO (throwIO exception)
      Nothing -> case fromException exception :: Maybe SqlError of
        Just sqlError | sqlState sqlError == "23P01" -> pure (Left err409
          { errBody = "The selected room or resource was reserved by another request" })
        _ -> liftIO (throwIO exception)
  where
    transactionBody = do
      _ <- (rawSql
        "SELECT 1::bigint FROM (SELECT pg_advisory_xact_lock(hashtextextended(?, 0))) locked"
        [PersistText ("public-tentative-booking:" <> idempotencyKey)]
        :: SqlPersistT IO [Single Int64])
      existing <- (rawSql
        "SELECT booking_id, request_sha256\
        \ FROM service_booking_tentative_request WHERE idempotency_key = ?"
        [PersistText idempotencyKey]
        :: SqlPersistT IO [(Single Int64, Single Text)])
      case existing of
        [(Single existingBookingId, Single storedHash)]
          | storedHash == requestHash ->
              pure (Right (toSqlKey existingBookingId, False))
          | otherwise -> pure (Left err409
              { errBody = "Idempotency key was already used for a different tentative booking" })
        [] -> createNew
        _ -> pure (Left err500
          { errBody = "Tentative booking idempotency lookup was ambiguous" })
    createNew = do
      resourceKeys <- resolveResourceKeys
      forM_ (sortOn fromSqlKey (nub resourceKeys)) $ \resourceKey -> do
        _ <- (rawSql "SELECT id FROM resource WHERE id = ? FOR UPDATE"
          [toPersistValue resourceKey] :: SqlPersistT IO [Single Int64])
        pure ()
      partyResult <- ensurePartyRecordDb now partyName emailClean phoneClean
      case partyResult of
        Left serverErr -> pure (Left serverErr)
        Right partyId -> do
          bookingId <- insert (buildBooking partyId)
          forM_ (zip [0 :: Int ..] (nub resourceKeys)) $ \(idx, key) ->
            insert_ BookingResource
              { bookingResourceBookingId = bookingId
              , bookingResourceResourceId = key
              , bookingResourceRole = if idx == 0 then "primary" else "secondary"
              }
          rawExecute
            "INSERT INTO service_booking_tentative_request(\
            \ idempotency_key, request_sha256, booking_id\
            \) VALUES (?, ?, ?)"
            [ PersistText idempotencyKey
            , PersistText requestHash
            , toPersistValue bookingId
            ]
          pure (Right (bookingId, True))

createBooking :: AuthedUser -> CreateBookingReq -> AppM BookingDTO
createBooking user req = do
  requireModule user ModuleScheduling
  now <- liftIO getCurrentTime

  titleClean <- either throwError pure (validateRequiredBookingTitle (cbTitle req))
  status' <- either throwBadRequest pure (parseBookingStatus (cbStatus req))
  either throwError pure $
    validateBookingTimeRange (cbStartsAt req) (cbEndsAt req)
  serviceOffering <- runDB $
    loadSelectableServiceOffering now (cbServiceOfferingId req)
  engineerIdClean <-
    either throwError pure $
      validateOptionalPositiveIdField "engineerPartyId" (cbEngineerPartyId req)
  partyIdClean <-
    either throwError pure $
      validateOptionalPositiveIdField "partyId" (cbPartyId req)
  unless (hasStudioBookingAccess user || maybe True (== fromSqlKey (auPartyId user)) partyIdClean) $
    throwError err403 { errBody = "Booking creation requires the customer owner or studio staff" }
  let effectivePartyId = if hasStudioBookingAccess user then partyIdClean else Just (fromSqlKey (auPartyId user))
  mParty <- runDB (resolveOptionalBookingPartyReference "partyId" effectivePartyId)
      >>= either throwError pure
  mEngineerParty <-
    runDB (resolveOptionalBookingEngineerReference engineerIdClean)
      >>= either throwError pure
  let engineerNameClean = normalizeOptionalInput (cbEngineerName req)
      partyKey         = entityKey <$> mParty
      requestedRooms   = fromMaybe [] (cbResourceIds req)
  notesClean <- either throwError pure (validateBookingNotes (cbNotes req))
  case validateEngineer (Catalog.serviceOfferingRequiresEngineer (entityVal serviceOffering)) engineerIdClean engineerNameClean of
    Left msg -> throwBadRequest msg
    Right () -> pure ()

  resourceKeys <- runDB $
    resolveResourcesForBooking (Just serviceOffering) requestedRooms (cbStartsAt req) (cbEndsAt req)
  let resolvedEngineerName =
        resolveBookingEngineerName engineerNameClean mEngineerParty

  let bookingRecord = Booking
        { bookingTitle          = titleClean
        , bookingServiceOrderId = Nothing
        , bookingPartyId        = partyKey
        , bookingServiceType    = Nothing
        , bookingServiceOfferingId = Just (cbServiceOfferingId req)
        , bookingBookingTypeId = Nothing
        , bookingWorkflowStateId = Nothing
        , bookingEngineerPartyId = entityKey <$> mEngineerParty
        , bookingEngineerName    = resolvedEngineerName
        , bookingStartsAt       = cbStartsAt req
        , bookingEndsAt         = cbEndsAt req
        , bookingStatus         = status'
        , bookingCreatedBy      = Just (auPartyId user)
        , bookingNotes          = notesClean
        , bookingCreatedAt      = now
        }

  dto <- runBookingTransaction user $ do
    bookingId <- insert bookingRecord
    let uniqueResources = nub resourceKeys
    forM_ (zip [0 :: Int ..] uniqueResources) $ \(idx, key) ->
      insert_ BookingResource
        { bookingResourceBookingId = bookingId
        , bookingResourceResourceId = key
        , bookingResourceRole = if idx == 0 then "primary" else "secondary"
        }
    created <- getJustEntity bookingId
    dtos <- buildBookingDTOs [created]
    pure (requirePersistedBookingDTO dtos)
  notifyEngineerIfNeeded dto
  pure dto

updateBooking :: AuthedUser -> Int64 -> UpdateBookingReq -> AppM BookingDTO
updateBooking user bookingIdI req = do
  requireModule user ModuleScheduling
  bookingIdValid <- either throwError pure (validatePositiveIdField "bookingId" bookingIdI)
  either throwError pure (validateUpdateBookingRequestHasChanges req)
  now <- liftIO getCurrentTime
  titleUpdate <- either throwError pure (validateOptionalBookingTitleUpdate (ubTitle req))
  notesUpdate <- either throwError pure (validateBookingNotes (ubNotes req))
  requestedServiceOffering <-
    traverse (runDB . loadSelectableServiceOffering now) (ubServiceOfferingId req)
  requestedEngineerId <-
    either throwError pure $
      validateOptionalPositiveIdField "engineerPartyId" (ubEngineerPartyId req)
  let bookingId = toSqlKey bookingIdValid :: Key Booking
  runBookingTransaction user $ do
    -- Serialize read/replace so concurrent edits cannot overwrite unrelated fields
    -- from an older record. The database projection enforces resource exclusion.
    _ <- (rawSql "SELECT id FROM booking WHERE id = ? FOR UPDATE"
      [toPersistValue bookingId] :: SqlPersistT IO [Single Int64])
    mBooking <- getEntity bookingId
    case mBooking of
      Nothing -> pure (Left err404)
      Just (Entity _ current) | not (canAccessBooking user current) -> pure (Left err404)
      Just (Entity _ current) -> do
        existingServiceOffering <-
          case bookingServiceOfferingId current >>= serviceOfferingKeyFromUUID of
            Nothing -> pure Nothing
            Just offeringKey -> getEntity offeringKey
        currentEngineerParty <-
          case bookingEngineerPartyId current of
            Nothing -> pure Nothing
            Just engineerKey -> getEntity engineerKey
        requestedEngineerRef <- resolveOptionalBookingEngineerReference requestedEngineerId
        case requestedEngineerRef of
          Left refErr -> pure (Left refErr)
          Right requestedEngineerParty ->
            case traverse parseBookingStatus (ubStatus req) of
              Left msg -> pure (Left err400 { errBody = BL8.fromStrict (TE.encodeUtf8 msg) })
              Right requestedStatus -> do
                let engineerNameFallback =
                      maybe (bookingEngineerName current) (normalizeOptionalInput . Just) (ubEngineerName req)
                    effectiveEngineerParty =
                      requestedEngineerParty <|> currentEngineerParty
                    effectiveServiceOffering =
                      requestedServiceOffering <|> existingServiceOffering
                    updated = current
                      { bookingTitle       = fromMaybe (bookingTitle current) titleUpdate
                      , bookingServiceType =
                          if isJust requestedServiceOffering
                            then Nothing
                            else bookingServiceType current
                      , bookingServiceOfferingId =
                          ubServiceOfferingId req <|> bookingServiceOfferingId current
                      , bookingNotes       =
                          if isJust (ubNotes req)
                            then notesUpdate
                            else bookingNotes current
                      , bookingStatus      = fromMaybe (bookingStatus current) requestedStatus
                      , bookingStartsAt    = fromMaybe (bookingStartsAt current) (ubStartsAt req)
                      , bookingEndsAt      = fromMaybe (bookingEndsAt current) (ubEndsAt req)
                      , bookingEngineerPartyId =
                          maybe
                            (bookingEngineerPartyId current)
                            (Just . entityKey)
                            requestedEngineerParty
                      , bookingEngineerName =
                          resolveBookingEngineerName engineerNameFallback effectiveEngineerParty
                      }
                case validateBookingTimeRange (bookingStartsAt updated) (bookingEndsAt updated) of
                  Left bookingErr -> pure (Left bookingErr)
                  Right () ->
                    case validateEngineer (maybe False (Catalog.serviceOfferingRequiresEngineer . entityVal) effectiveServiceOffering) (fmap fromSqlKey (bookingEngineerPartyId updated)) (bookingEngineerName updated) of
                      Left msg -> pure (Left err400 { errBody = BL8.fromStrict (TE.encodeUtf8 msg) })
                      Right () -> do
                        replace bookingId updated
                        dtos <- buildBookingDTOs [Entity bookingId updated]
                        pure (maybe (Left err500) Right (listToMaybe dtos))

resolveOptionalBookingPartyReference
  :: Text
  -> Maybe Int64
  -> SqlPersistT IO (Either ServerError (Maybe (Entity Party)))
resolveOptionalBookingPartyReference _ Nothing = pure (Right Nothing)
resolveOptionalBookingPartyReference fieldName (Just rawId) = do
  case validatePositiveIdField fieldName rawId of
    Left serverErr -> pure (Left serverErr)
    Right partyId -> do
      let partyKey = toSqlKey (fromIntegral partyId) :: Key Party
      mParty <- getEntity partyKey
      pure $
        case mParty of
          Nothing ->
            Left err422
              { errBody =
                  BL.fromStrict (TE.encodeUtf8 (fieldName <> " references an unknown party"))
              }
          Just partyEnt -> Right (Just partyEnt)

serviceOfferingKeyFromUUID :: UUID.UUID -> Maybe (Key Catalog.ServiceOffering)
serviceOfferingKeyFromUUID = fromPathPiece . UUID.toText

serviceOfferingUUIDFromKey :: Key Catalog.ServiceOffering -> Maybe UUID.UUID
serviceOfferingUUIDFromKey = UUID.fromText . toPathPiece

loadSelectableServiceOffering
  :: UTCTime
  -> UUID.UUID
  -> SqlPersistT IO (Entity Catalog.ServiceOffering)
loadSelectableServiceOffering now rawOfferingId =
  case serviceOfferingKeyFromUUID rawOfferingId of
    Nothing -> liftIO . throwIO $ invalidServiceOfferingReference
    Just offeringKey -> do
      mOffering <- getEntity offeringKey
      case mOffering of
        Nothing -> liftIO . throwIO $ invalidServiceOfferingReference
        Just offeringEntity@(Entity _ offering) -> do
          mWorkflowState <- get (Catalog.serviceOfferingWorkflowStateId offering)
          let today = utctDay now
              effective =
                maybe True (<= today) (Catalog.serviceOfferingEffectiveFrom offering)
                  && maybe True (>= today) (Catalog.serviceOfferingEffectiveUntil offering)
              published = maybe False ((== "published") . Catalog.workflowStateCode) mWorkflowState
              selectable =
                Catalog.serviceOfferingActive offering
                  && isNothing (Catalog.serviceOfferingDeprecatedAt offering)
                  && effective
                  && published
          if selectable
            then pure offeringEntity
            else liftIO . throwIO $ invalidServiceOfferingReference
  where
    invalidServiceOfferingReference =
      err422
        { errBody =
            "serviceOfferingId must reference an active, effective, published service offering"
        }


resolveOptionalBookingEngineerReference
  :: Maybe Int64
  -> SqlPersistT IO (Either ServerError (Maybe (Entity Party)))
resolveOptionalBookingEngineerReference Nothing = pure (Right Nothing)
resolveOptionalBookingEngineerReference engineerId = do
  resolved <- resolveOptionalBookingPartyReference "engineerPartyId" engineerId
  case resolved of
    Left serverErr -> pure (Left serverErr)
    Right Nothing -> pure (Right Nothing)
    Right (Just partyEnt) -> do
      activeEngineer <- hasCanonicalPartyRole (entityKey partyEnt) Engineer
      pure $ case activeEngineer of
        False ->
          Left err422
            { errBody = "engineerPartyId must reference an active engineer" }
        True ->
          Right (Just partyEnt)


loadBookingResourceMap :: [Key Booking] -> SqlPersistT IO (Map.Map (Key Booking) [BookingResourceDTO])
loadBookingResourceMap [] = pure Map.empty
loadBookingResourceMap bookingIds = do
  bookingResources <- selectList [BookingResourceBookingId <-. bookingIds] []
  if null bookingResources
    then pure Map.empty
    else do
      let resourceIds = map (bookingResourceResourceId . entityVal) bookingResources
      resources <- selectList [ResourceId <-. resourceIds] []
      let resourceMap = Map.fromList [ (entityKey resEnt, resEnt) | resEnt <- resources ]
          accumulate acc (Entity _ br) =
            case Map.lookup (bookingResourceResourceId br) resourceMap of
              Nothing      -> acc
              Just resEnt  ->
                let bookingKey = bookingResourceBookingId br
                    dto = BookingResourceDTO
                      { brRoomId   = toPathPiece (bookingResourceResourceId br)
                      , brRoomName = resourceName (entityVal resEnt)
                      , brRole     = bookingResourceRole br
                      }
                in Map.insertWith (++) bookingKey [dto] acc
      pure (foldl' accumulate Map.empty bookingResources)

buildBookingDTOs :: [Entity Booking] -> SqlPersistT IO [BookingDTO]
buildBookingDTOs [] = pure []
buildBookingDTOs bookings = do
  let bookingIds       = map entityKey bookings
      bookingPartyIds  = catMaybes $ map (bookingPartyId . entityVal) bookings
      serviceOrderKeys = catMaybes $ map (bookingServiceOrderId . entityVal) bookings
      serviceOfferingKeys =
        mapMaybe (bookingServiceOfferingId . entityVal >=> serviceOfferingKeyFromUUID) bookings
  resMap <- loadBookingResourceMap bookingIds
  serviceOrderMap <- loadServiceOrderMap serviceOrderKeys
  serviceOfferingRows <-
    selectList [Catalog.ServiceOfferingId <-. nub serviceOfferingKeys] []
  let serviceOfferingMap =
        Map.fromList [(entityKey row, row) | row <- serviceOfferingRows]
  let servicePartyIds = map (M.serviceOrderCustomerId . entityVal) (Map.elems serviceOrderMap)
      partyIds = nub (bookingPartyIds ++ servicePartyIds)
  partyMap <- loadPartyDisplayMap partyIds
  pure $ map (toDTO resMap partyMap serviceOrderMap serviceOfferingMap) bookings
  where
    toDTO resMap partyMap soMap offeringMap (Entity bid b) =
      let resources = Map.findWithDefault [] bid resMap
          partyDisplay = bookingPartyId b >>= (`Map.lookup` partyMap)
          serviceOrderEnt = bookingServiceOrderId b >>= (`Map.lookup` soMap)
          serviceOrderTitleText = serviceOrderEnt >>= (M.serviceOrderTitle . entityVal)
          customerNameText = serviceOrderEnt >>= \soEnt ->
            Map.lookup (M.serviceOrderCustomerId (entityVal soEnt)) partyMap
          fallbackOrderTitle = normalizeOptionalInput (Just (bookingTitle b))
          fallbackCustomer = partyDisplay
          canonicalServiceLabel = do
            rawOfferingId <- bookingServiceOfferingId b
            offeringKey <- serviceOfferingKeyFromUUID rawOfferingId
            offering <- Map.lookup offeringKey offeringMap
            pure (Catalog.serviceOfferingNameEs (entityVal offering))
      in BookingDTO
        { bookingId   = fromSqlKey bid
        , title       = bookingTitle b
        , startsAt    = bookingStartsAt b
        , endsAt      = bookingEndsAt b
        , status      = T.pack (show (bookingStatus b))
        , notes       = bookingNotes b
        , partyId     = fmap fromSqlKey (bookingPartyId b)
        , engineerPartyId = fmap fromSqlKey (bookingEngineerPartyId b)
        , engineerName    = bookingEngineerName b
        , serviceOfferingId = bookingServiceOfferingId b
        , serviceType = canonicalServiceLabel <|> bookingServiceType b
        , serviceOrderId    = fmap fromSqlKey (bookingServiceOrderId b)
        , serviceOrderTitle = serviceOrderTitleText <|> fallbackOrderTitle
        , customerName      = customerNameText <|> fallbackCustomer
        , partyDisplayName  = partyDisplay
        , resources   = resources
        , courseSlug        = Nothing
        , coursePrice       = Nothing
        , courseCurrency    = Nothing
        , courseCapacity    = Nothing
        , courseRemaining   = Nothing
        , courseLocation    = Nothing
        }

requirePersistedBookingDTO :: [BookingDTO] -> Either ServerError BookingDTO
requirePersistedBookingDTO (dto:_) = Right dto
requirePersistedBookingDTO [] =
  Left err500
    { errBody = "Booking DTO projection returned no rows after persistence"
    }

loadPartyDisplayMap :: [Key Party] -> SqlPersistT IO (Map.Map (Key Party) Text)
loadPartyDisplayMap [] = pure Map.empty
loadPartyDisplayMap partyIds = do
  parties <- selectList [PartyId <-. partyIds] []
  pure $ Map.fromList
    [ (entityKey ent, M.partyDisplayName (entityVal ent))
    | ent <- parties
    ]

loadServiceOrderMap :: [Key ServiceOrder] -> SqlPersistT IO (Map.Map (Key ServiceOrder) (Entity ServiceOrder))
loadServiceOrderMap [] = pure Map.empty
loadServiceOrderMap serviceOrderIds = do
  serviceOrders <- selectList [ServiceOrderId <-. serviceOrderIds] []
  pure $ Map.fromList [ (entityKey ent, ent) | ent <- serviceOrders ]

normalizeOptionalInput :: Maybe Text -> Maybe Text
normalizeOptionalInput Nothing = Nothing
normalizeOptionalInput (Just raw) =
  let trimmed = T.strip raw
  in if T.null trimmed then Nothing else Just trimmed

validatePartyListPagination :: Maybe Int -> Maybe Int -> Either ServerError (Int, Int)
validatePartyListPagination mLimit mOffset =
  (,) <$> validatePartyListLimit mLimit <*> validatePartyListOffset mOffset

validatePartyListLimit :: Maybe Int -> Either ServerError Int
validatePartyListLimit Nothing = Right 200
validatePartyListLimit (Just rawLimit)
  | rawLimit < 1 || rawLimit > maxPartyListLimit =
      Left err400 { errBody = "limit must be between 1 and 500" }
  | otherwise =
      Right rawLimit

validatePartyListOffset :: Maybe Int -> Either ServerError Int
validatePartyListOffset Nothing = Right 0
validatePartyListOffset (Just rawOffset)
  | rawOffset < 0 =
      Left err400 { errBody = "offset must be greater than or equal to 0" }
  | rawOffset > maxPartyListOffset =
      Left err400 { errBody = "offset must be 10000 or fewer" }
  | otherwise =
      Right rawOffset

maxPartyListLimit :: Int
maxPartyListLimit = 500

maxPartyListOffset :: Int
maxPartyListOffset = 10000

validatePositiveIdField :: Text -> Int64 -> Either ServerError Int64
validatePositiveIdField fieldName rawId
  | rawId <= 0 =
      Left err400
        { errBody =
            BL.fromStrict (TE.encodeUtf8 (fieldName <> " must be a positive integer"))
        }
  | otherwise = Right rawId

validateOptionalPositiveIdField :: Text -> Maybe Int64 -> Either ServerError (Maybe Int64)
validateOptionalPositiveIdField _ Nothing = Right Nothing
validateOptionalPositiveIdField fieldName (Just rawId)
  | otherwise = Just <$> validatePositiveIdField fieldName rawId

validateCourseRegistrationId :: Int64 -> Either ServerError Int64
validateCourseRegistrationId = validatePositiveIdField "registrationId"

validateCourseRegistrationReceiptId :: Int64 -> Either ServerError Int64
validateCourseRegistrationReceiptId = validatePositiveIdField "receiptId"

validateCourseRegistrationFollowUpId :: Int64 -> Either ServerError Int64
validateCourseRegistrationFollowUpId = validatePositiveIdField "followUpId"

validateChatMessageListLookup
  :: Int64
  -> Maybe Int64
  -> Maybe Int64
  -> Either ServerError (Int64, Maybe Int64, Maybe Int64)
validateChatMessageListLookup = SocialChat.validateLookup

validateChatSendMessageBody :: Text -> Either ServerError Text
validateChatSendMessageBody = SocialChat.validateBody

validateBookingListFilters :: Maybe Int64 -> Maybe Int64 -> Maybe Int64 -> Either ServerError (Maybe Int64, Maybe Int64, Maybe Int64)
validateBookingListFilters mBookingId mPartyId mEngineerPartyId = do
  bookingIdFilter <- validateOptionalPositiveIdField "bookingId" mBookingId
  partyIdFilter <- validateOptionalPositiveIdField "partyId" mPartyId
  engineerPartyIdFilter <- validateOptionalPositiveIdField "engineerPartyId" mEngineerPartyId
  when
    ( isJust bookingIdFilter
        && (isJust partyIdFilter || isJust engineerPartyIdFilter)
    )
    (Left err400 { errBody = "bookingId cannot be combined with partyId or engineerPartyId" })
  pure (bookingIdFilter, partyIdFilter, engineerPartyIdFilter)

validateUpdateBookingRequestHasChanges :: UpdateBookingReq -> Either ServerError ()
validateUpdateBookingRequestHasChanges UpdateBookingReq{..}
  | or
      [ isJust ubTitle
      , isJust ubServiceOfferingId
      , isJust ubStatus
      , isJust ubNotes
      , isJust ubStartsAt
      , isJust ubEndsAt
      , isJust ubEngineerPartyId
      , isJust ubEngineerName
      ] =
      Right ()
  | otherwise =
      Left err400 { errBody = "Booking update must include at least one field" }

validateServiceMarketplaceBookingRefs :: Int64 -> Int64 -> Either ServerError (Int64, Int64)
validateServiceMarketplaceBookingRefs rawAdId rawSlotId = do
  adId <- validatePositiveIdField "adId" rawAdId
  slotId <- validatePositiveIdField "slotId" rawSlotId
  pure (adId, slotId)

validateServiceMarketplaceBookingTitle :: Maybe Text -> Either ServerError (Maybe Text)
validateServiceMarketplaceBookingTitle Nothing = Right Nothing
validateServiceMarketplaceBookingTitle (Just rawTitle)
  | T.null (T.strip rawTitle) =
      Left err400 { errBody = "title cannot be blank; omit title to use the service ad headline" }
  | otherwise =
      Just <$> validateRequiredBookingTitle rawTitle

validateServiceMarketplaceBookingNotes :: Maybe Text -> Either ServerError (Maybe Text)
validateServiceMarketplaceBookingNotes =
  validateBookingNotes

validateServiceMarketplaceBookingSlot
  :: Key ServiceAd
  -> ServiceAdSlot
  -> Either ServerError ()
validateServiceMarketplaceBookingSlot adKey slot
  | serviceAdSlotAdId slot /= adKey =
      Left err400 { errBody = "slotId does not belong to adId" }
  | T.toCaseFold (T.strip (serviceAdSlotStatus slot)) /= "open" =
      Left err409 { errBody = "Slot is not available" }
  | otherwise =
      Right ()

normalizeOptionalCmsFilter :: Maybe Text -> Maybe Text
normalizeOptionalCmsFilter = normalizeOptionalInput

validateCmsLocaleFilter :: Maybe Text -> Either ServerError Text
validateCmsLocaleFilter rawLocale =
  case normalizeOptionalCmsFilter rawLocale of
    Nothing -> Right "es"
    Just locale
      | isValidCmsLocale locale -> Right (canonicalizeCmsLocale locale)
      | otherwise ->
          Left err400
            { errBody =
                "locale must be omitted or a BCP-47 language tag such as es, en, or es-EC"
            }
  where
    isValidCmsLocale locale =
      T.length locale <= 35
        && case T.splitOn "-" locale of
          [] -> False
          primary : subtags ->
            isValidPrimarySubtag primary && all isValidLocaleSubtag subtags

    isValidPrimarySubtag subtag =
      let len = T.length subtag
      in len >= 2 && len <= 8 && T.all isAsciiLetter subtag

    isValidLocaleSubtag subtag =
      let len = T.length subtag
      in len >= 2 && len <= 8 && T.all isAsciiAlphaNum subtag

    isAsciiLetter ch = isAsciiLower ch || isAsciiUpper ch
    isAsciiAlphaNum ch = isAsciiLetter ch || isDigit ch

canonicalizeCmsLocale :: Text -> Text
canonicalizeCmsLocale rawLocale =
  case T.splitOn "-" rawLocale of
    [] -> rawLocale
    primary : subtags ->
      T.intercalate "-" (T.toLower primary : map canonicalizeSubtag subtags)
  where
    canonicalizeSubtag subtag
      | T.length subtag == 2 && T.all isAsciiLetter subtag = T.toUpper subtag
      | otherwise = T.toLower subtag

    isAsciiLetter ch = isAsciiLower ch || isAsciiUpper ch

validateOptionalCmsLocaleFilter :: Maybe Text -> Either ServerError (Maybe Text)
validateOptionalCmsLocaleFilter Nothing = Right Nothing
validateOptionalCmsLocaleFilter (Just rawLocale)
  | T.null (T.strip rawLocale) =
      Left err400
        { errBody =
            "locale must be omitted or a BCP-47 language tag such as es, en, or es-EC"
        }
  | otherwise = Just <$> validateCmsLocaleFilter (Just rawLocale)

validateRequiredCmsLocale :: Text -> Either ServerError Text
validateRequiredCmsLocale rawLocale =
  case normalizeOptionalCmsFilter (Just rawLocale) of
    Nothing ->
      Left err400 { errBody = "locale requerido" }
    Just _ ->
      validateCmsLocaleFilter (Just rawLocale)

validateRequiredCmsSlug :: Text -> Either ServerError Text
validateRequiredCmsSlug rawSlug =
  let slugVal = normalizeSlug rawSlug
      isSlugAtom ch = isAsciiLower ch || isDigit ch
      isSlugChar ch = isSlugAtom ch || ch == '-'
  in if T.null slugVal
    then Left err400 { errBody = "slug requerido" }
    else
      if T.length slugVal <= cmsSlugMaxLength
          && T.all isSlugChar slugVal
          && T.any isSlugAtom slugVal
        then Right slugVal
        else Left invalidCmsSlug
  where
    cmsSlugMaxLength = 96
    invalidCmsSlug =
      err400
        { errBody =
            "slug must contain only ASCII letters, numbers, and hyphens, "
              <> "include at least one letter or number, and be 96 characters or fewer"
        }

validateCmsContentPathId :: Int -> Either ServerError (Key CMS.CmsContent)
validateCmsContentPathId rawId =
  toSqlKey <$> validatePositiveIdField "contentId" (fromIntegral rawId)

validateOptionalCmsContentIdFilter :: Maybe Text -> Either ServerError (Maybe UUID.UUID)
validateOptionalCmsContentIdFilter Nothing = Right Nothing
validateOptionalCmsContentIdFilter (Just rawContentId) =
  case UUID.fromText (T.strip rawContentId) of
    Just contentId -> Right (Just contentId)
    Nothing -> Left err400 { errBody = "contentId must be a canonical UUID" }

validateOptionalCmsSlugFilter :: Maybe Text -> Either ServerError (Maybe Text)
validateOptionalCmsSlugFilter Nothing = Right Nothing
validateOptionalCmsSlugFilter (Just rawSlug)
  | T.null (T.strip rawSlug) =
      Left err400
        { errBody =
            "slug must be omitted or use only ASCII letters, numbers, and hyphens"
        }
  | otherwise = Just <$> validateRequiredCmsSlug rawSlug

validateOptionalCmsSlugPrefix :: Maybe Text -> Either ServerError (Maybe Text)
validateOptionalCmsSlugPrefix Nothing = Right Nothing
validateOptionalCmsSlugPrefix (Just rawPrefix)
  | T.null (T.strip rawPrefix) =
      Left invalidCmsSlugPrefix
  | otherwise =
      case validateRequiredCmsSlug rawPrefix of
        Right prefix -> Right (Just prefix)
        Left _ -> Left invalidCmsSlugPrefix
  where
    invalidCmsSlugPrefix =
      err400
        { errBody =
            "slugPrefix must be omitted or use only ASCII letters, numbers, and hyphens"
        }

validateRequiredCmsField :: Text -> Text -> Either ServerError Text
validateRequiredCmsField fieldName rawValue =
  case normalizeOptionalCmsFilter (Just rawValue) of
    Just value -> Right value
    Nothing ->
      Left err400
        { errBody =
            BL.fromStrict (TE.encodeUtf8 (fieldName <> " requerido"))
        }

validateOptionalCmsTitle :: Maybe Text -> Either ServerError (Maybe Text)
validateOptionalCmsTitle rawTitle =
  case cleanOptional rawTitle of
    Nothing -> Right Nothing
    Just title
      | T.length title > 160 ->
          Left err400 { errBody = "title must be 160 characters or fewer" }
      | T.any isUnsafeCmsTitleChar title ->
          Left err400
            { errBody =
                "title must not contain control characters or hidden formatting characters"
            }
      | otherwise -> Right (Just title)
  where
    isUnsafeCmsTitleChar ch =
      isControl ch || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

validateCmsContentStatus :: Maybe Text -> Either ServerError Text
validateCmsContentStatus Nothing = Right "draft"
validateCmsContentStatus (Just rawStatus) =
  case T.toCaseFold <$> normalizeOptionalInput (Just rawStatus) of
    Just "draft" -> Right "draft"
    Just "published" -> Right "published"
    Just "archived" -> Right "archived"
    _ -> Left err400 { errBody = "status must be one of: draft, published, archived" }

validateOptionalCmsPayload :: Maybe Value -> Either ServerError (Maybe Value)
validateOptionalCmsPayload Nothing = Right Nothing
validateOptionalCmsPayload (Just Null) =
  Left err400 { errBody = "payload must be omitted instead of JSON null" }
validateOptionalCmsPayload payload@(Just (Object _))
  | BL.length (encode payload) > maxCmsPayloadBytes =
      Left err400
        { errBody =
            BL.fromStrict . TE.encodeUtf8 $
              "payload must be "
                <> T.pack (show maxCmsPayloadBytes)
                <> " bytes or fewer"
        }
  | otherwise = Right payload
validateOptionalCmsPayload (Just _) =
  Left err400 { errBody = "payload must be a JSON object when present" }

maxCmsPayloadBytes :: Int64
maxCmsPayloadBytes = 262144

validateCourseNonNegativeField :: Text -> Int -> Either ServerError Int
validateCourseNonNegativeField fieldName value
  | value < 0 =
      Left err400
        { errBody =
            BL.fromStrict (TE.encodeUtf8 (fieldName <> " must be greater than or equal to 0"))
        }
  | otherwise = Right value

validateOptionalCourseNonNegativeField :: Text -> Maybe Int -> Either ServerError (Maybe Int)
validateOptionalCourseNonNegativeField fieldName =
  traverse (validateCourseNonNegativeField fieldName)

validateCoursePositiveField :: Text -> Int -> Either ServerError Int
validateCoursePositiveField fieldName value
  | value <= 0 =
      Left err400
        { errBody =
            BL.fromStrict (TE.encodeUtf8 (fieldName <> " must be greater than 0"))
        }
  | otherwise = Right value

validateOptionalCoursePositiveField :: Text -> Maybe Int -> Either ServerError (Maybe Int)
validateOptionalCoursePositiveField fieldName =
  traverse (validateCoursePositiveField fieldName)

validateOptionalCourseSessionDurationHours :: Maybe Int -> Either ServerError (Maybe Int)
validateOptionalCourseSessionDurationHours =
  traverse validateCourseSessionDurationHours

validateCourseSessionDurationHours :: Int -> Either ServerError Int
validateCourseSessionDurationHours value
  | value <= 0 =
      Left err400
        { errBody =
            BL.fromStrict (TE.encodeUtf8 "sessionDurationHours must be greater than 0")
        }
  | value > 24 =
      Left err400
        { errBody =
            BL.fromStrict (TE.encodeUtf8 "sessionDurationHours must be 24 or fewer")
        }
  | otherwise = Right value

validateCourseCurrency :: Text -> Either ServerError Text
validateCourseCurrency rawCurrency =
  validateCurrencyCode (normalizeOptionalInput (Just rawCurrency))

validateOptionalCourseSessionStartHour :: Maybe Int -> Either ServerError (Maybe Int)
validateOptionalCourseSessionStartHour =
  traverse validateCourseSessionStartHour

validateCourseSessionStartHour :: Int -> Either ServerError Int
validateCourseSessionStartHour value
  | value < 0 || value > 23 =
      Left err400
        { errBody =
            BL.fromStrict (TE.encodeUtf8 "sessionStartHour must be between 0 and 23")
        }
  | otherwise = Right value

validateCourseSessionScheduleWindow :: Maybe Int -> Maybe Int -> Either ServerError ()
validateCourseSessionScheduleWindow (Just startHour) (Just durationHours)
  | startHour + durationHours > 24 =
      Left err400
        { errBody =
            BL.fromStrict
              (TE.encodeUtf8 "sessionStartHour plus sessionDurationHours must not exceed 24")
        }
  | otherwise = Right ()
validateCourseSessionScheduleWindow _ _ = Right ()

validateCourseSessionInputs :: [CourseSessionIn] -> Either ServerError [CourseSessionIn]
validateCourseSessionInputs rawSessions = do
  sessionsClean <- traverse (uncurry validateCourseSessionInput) (zip [1 :: Int ..] rawSessions)
  validateDistinctResolvedCourseOrderValues
    "sessions"
    [ (idx, fromMaybe idx orderVal)
    | (idx, CourseSessionIn _ _ orderVal) <- zip [1 :: Int ..] sessionsClean
    ]
  pure sessionsClean

validateCourseSessionInput :: Int -> CourseSessionIn -> Either ServerError CourseSessionIn
validateCourseSessionInput idx (CourseSessionIn rawLabel dayVal orderVal) = do
  labelClean <-
    validateRequiredCourseTextField
      ("sessions[" <> T.pack (show idx) <> "].label")
      160
      rawLabel
  orderClean <-
    validateOptionalCoursePositiveField
      ("sessions[" <> T.pack (show idx) <> "].order")
      orderVal
  Right (CourseSessionIn labelClean dayVal orderClean)

validateCourseSyllabusInputs :: [CourseSyllabusIn] -> Either ServerError [CourseSyllabusIn]
validateCourseSyllabusInputs rawItems = do
  syllabusClean <- traverse (uncurry validateCourseSyllabusInput) (zip [1 :: Int ..] rawItems)
  validateDistinctResolvedCourseOrderValues
    "syllabus"
    [ (idx, fromMaybe idx orderVal)
    | (idx, CourseSyllabusIn _ _ orderVal) <- zip [1 :: Int ..] syllabusClean
    ]
  pure syllabusClean

validateCourseSyllabusInput :: Int -> CourseSyllabusIn -> Either ServerError CourseSyllabusIn
validateCourseSyllabusInput idx (CourseSyllabusIn rawTitle rawTopics orderVal) = do
  titleClean <-
    validateRequiredCourseTextField
      ("syllabus[" <> T.pack (show idx) <> "].title")
      160
      rawTitle
  orderClean <-
    validateOptionalCoursePositiveField
      ("syllabus[" <> T.pack (show idx) <> "].order")
      orderVal
  topicsClean <-
    fmap catMaybes $
      traverse
        (uncurry validateTopic)
        (zip [1 :: Int ..] rawTopics)
  if null topicsClean
    then
      Left err400
        { errBody =
            BL.fromStrict . TE.encodeUtf8 $
              "syllabus[" <> T.pack (show idx) <> "].topics must include at least one non-blank topic"
        }
    else
      Right (CourseSyllabusIn titleClean topicsClean orderClean)
  where
    validateTopic topicIdx rawTopic =
      validateOptionalCourseTextField
        ( "syllabus["
            <> T.pack (show idx)
            <> "].topics["
            <> T.pack (show topicIdx)
            <> "]"
        )
        160
        (Just rawTopic)

validateDistinctResolvedCourseOrderValues :: Text -> [(Int, Int)] -> Either ServerError ()
validateDistinctResolvedCourseOrderValues fieldName =
  go Set.empty
  where
    go _ [] = Right ()
    go seen ((idx, resolvedOrder) : rest)
      | Set.member resolvedOrder seen =
          Left err400
            { errBody =
                BL.fromStrict . TE.encodeUtf8 $
                  fieldName
                    <> "["
                    <> T.pack (show idx)
                    <> "].order must be unique after applying defaults; duplicate order "
                    <> T.pack (show resolvedOrder)
            }
      | otherwise =
          go (Set.insert resolvedOrder seen) rest

parseBookingStatus :: Text -> Either Text BookingStatus
parseBookingStatus raw =
  maybe
    (Left ("Estado inválido. Usa uno de: " <> bookingStatusOptions))
    Right
    (Map.lookup (normalizeBookingStatusToken raw) bookingStatusAliases)
  where
    bookingStatusAliases =
      Map.fromList
        [ (normalizeBookingStatusToken (T.pack (show statusVal)), statusVal)
        | statusVal <- ([minBound .. maxBound] :: [BookingStatus])
        ]
    bookingStatusOptions =
      T.intercalate ", "
        [ T.pack (show statusVal)
        | statusVal <- ([minBound .. maxBound] :: [BookingStatus])
        ]

normalizeBookingStatusToken :: Text -> Text
normalizeBookingStatusToken =
  T.toLower . T.filter isAlphaNum . T.strip

parseCourseRegistrationStatus :: Text -> Either ServerError Text
parseCourseRegistrationStatus raw =
  maybe invalidStatus pure (normalizeCourseRegistrationStatus raw)
  where
    invalidStatus =
      Left err400
        { errBody =
            "Invalid course registration status. Allowed values: pending_payment, paid, cancelled"
        }

validateOptionalCourseRegistrationStatusFilter :: Maybe Text -> Either ServerError (Maybe Text)
validateOptionalCourseRegistrationStatusFilter Nothing = Right Nothing
validateOptionalCourseRegistrationStatusFilter (Just rawStatus) =
  let trimmed = T.strip rawStatus
  in if T.null trimmed
       then
         Left err400
           { errBody = "status must be omitted or one of: pending_payment, paid, cancelled"
           }
       else Just <$> parseCourseRegistrationStatus trimmed

validateCourseRegistrationListLimit :: Int -> Maybe Int -> Either ServerError Int
validateCourseRegistrationListLimit defaultLimit Nothing = Right defaultLimit
validateCourseRegistrationListLimit _ (Just rawLimit)
  | rawLimit < 1 || rawLimit > 500 =
      Left err400 { errBody = "limit must be between 1 and 500" }
  | otherwise =
      Right rawLimit

validateCourseRegistrationEmailEventListLimit :: Maybe Int -> Either ServerError Int
validateCourseRegistrationEmailEventListLimit =
  validateCourseRegistrationListLimit 100

validateMarketplaceOrderListLimit :: Maybe Int -> Either ServerError Int
validateMarketplaceOrderListLimit Nothing = Right 50
validateMarketplaceOrderListLimit (Just rawLimit)
  | rawLimit < 1 || rawLimit > 200 =
      Left err400 { errBody = "limit must be between 1 and 200" }
  | otherwise =
      Right rawLimit

validateMarketplaceOrderListOffset :: Maybe Int -> Either ServerError Int
validateMarketplaceOrderListOffset Nothing = Right 0
validateMarketplaceOrderListOffset (Just rawOffset)
  | rawOffset < 0 =
      Left err400 { errBody = "offset must be greater than or equal to 0" }
  | rawOffset > maxMarketplaceOrderListOffset =
      Left err400 { errBody = "offset must be 10000 or fewer" }
  | otherwise =
      Right rawOffset

maxMarketplaceOrderListOffset :: Int
maxMarketplaceOrderListOffset = 10000

validateOptionalMarketplaceOrderStatus :: Maybe Text -> Either ServerError (Maybe Text)
validateOptionalMarketplaceOrderStatus Nothing = Right Nothing
validateOptionalMarketplaceOrderStatus (Just rawStatus) =
  Just <$>
    validateMarketplaceOrderStatusValue
      marketplaceOptionalOrderStatusErrorBody
      marketplaceOptionalOrderStatusErrorBody
      rawStatus

validateMarketplaceOrderUpdateStatus :: Maybe Text -> Either ServerError (Maybe Text)
validateMarketplaceOrderUpdateStatus Nothing = Right Nothing
validateMarketplaceOrderUpdateStatus (Just rawStatus) =
  Just <$>
    validateMarketplaceOrderStatusValue
      "status cannot be blank"
      marketplaceOrderStatusErrorBody
      rawStatus

validateMarketplaceOrderStatusValue
  :: BL.ByteString
  -> BL.ByteString
  -> Text
  -> Either ServerError Text
validateMarketplaceOrderStatusValue blankBody invalidBody rawStatus
  | T.any isUnsafeMarketplaceOrderStatusChar rawStatus =
      Left err400 { errBody = invalidBody }
  | otherwise =
      case normalizeOptionalInput (Just rawStatus) of
        Nothing -> Left err400 { errBody = blankBody }
        Just statusVal ->
          case normalizeMarketplaceOrderStatus statusVal of
            Just normalized -> Right normalized
            Nothing -> Left err400 { errBody = invalidBody }

isUnsafeMarketplaceOrderStatusChar :: Char -> Bool
isUnsafeMarketplaceOrderStatusChar ch =
  isControl ch || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

validateOptionalMarketplacePaymentProviderUpdate :: Maybe (Maybe Text) -> Either ServerError (Maybe (Maybe Text))
validateOptionalMarketplacePaymentProviderUpdate Nothing =
  Right Nothing
validateOptionalMarketplacePaymentProviderUpdate (Just Nothing) =
  Right (Just Nothing)
validateOptionalMarketplacePaymentProviderUpdate (Just (Just rawProvider))
  | T.null normalized =
      Left err400 { errBody = "paymentProvider cannot be blank; use null to clear it" }
  | T.length normalized > 64 =
      Left err400 { errBody = "paymentProvider must be 64 characters or fewer" }
  | not (T.any isPaymentProviderAtom normalized) =
      Left err400 { errBody = "paymentProvider must contain at least one ASCII letter or digit" }
  | not (T.all isPaymentProviderSlugChar normalized) =
      Left err400
        { errBody =
            "paymentProvider must contain only ASCII letters, digits, hyphen, or underscore"
        }
  | otherwise =
      Right (Just (Just normalized))
  where
    normalized = T.toLower (T.strip rawProvider)
    isPaymentProviderAtom ch =
      isAsciiLower ch || isDigit ch
    isPaymentProviderSlugChar ch =
      isAsciiLower ch || isDigit ch || ch == '-' || ch == '_'

marketplaceOrderStatusErrorBody :: BL.ByteString
marketplaceOrderStatusErrorBody =
  "status must be one of: pending, contact, paid, cancelled, failed, "
    <> "datafast_init, datafast_pending, datafast_failed, paypal_pending, "
    <> "paypal_failed, stripe_pending, stripe_failed"

marketplaceOptionalOrderStatusErrorBody :: BL.ByteString
marketplaceOptionalOrderStatusErrorBody =
  "status must be omitted or one of: pending, contact, paid, cancelled, failed, "
    <> "datafast_init, datafast_pending, datafast_failed, paypal_pending, "
    <> "paypal_failed, stripe_pending, stripe_failed"

parsePayPalCaptureOrderStatus :: Text -> Either ServerError Text
parsePayPalCaptureOrderStatus rawStatus = do
  status <- validatePayPalCaptureStatusField (Just rawStatus)
  case normalizePayPalCaptureOrderStatus status of
    Just normalized -> Right normalized
    Nothing ->
      Left err502
        { errBody =
            BL.fromStrict . TE.encodeUtf8 $
              "Unsupported PayPal capture status: " <> status
        }

validatePayPalCaptureOrderId :: Text -> Either ServerError Text
validatePayPalCaptureOrderId rawOrderId =
  case normalizeOptionalInput (Just rawOrderId) of
    Nothing ->
      Left err400 { errBody = "paypalOrderId is required" }
    Just orderId
      | T.length orderId > 128 ->
          Left err400 { errBody = "paypalOrderId must be 128 characters or fewer" }
      | not (T.any isPayPalOrderIdAtom orderId) ->
          Left err400
            { errBody =
                "paypalOrderId must contain at least one ASCII letter or digit"
            }
      | T.all isPayPalOrderIdChar orderId ->
          Right orderId
      | otherwise ->
          Left err400
            { errBody =
                "paypalOrderId must contain only ASCII letters, digits, hyphen, or underscore"
            }

validatePayPalCreateOrderIdField :: Text -> Either ServerError Text
validatePayPalCreateOrderIdField rawOrderId =
  case normalizeOptionalInput (Just rawOrderId) of
    Just orderId | isValidPayPalOrderId orderId ->
      Right orderId
    _ ->
      Left err502 { errBody = "PayPal create response returned an invalid order id" }

isValidPayPalOrderId :: Text -> Bool
isValidPayPalOrderId orderId =
  not (T.null orderId)
    && T.length orderId <= 128
    && T.any isPayPalOrderIdAtom orderId
    && T.all isPayPalOrderIdChar orderId

isPayPalOrderIdAtom :: Char -> Bool
isPayPalOrderIdAtom c =
  isAsciiDecimalDigit c || isAsciiLower c || isAsciiUpper c

isPayPalOrderIdChar :: Char -> Bool
isPayPalOrderIdChar c =
  isAsciiDecimalDigit c || isAsciiLower c || isAsciiUpper c || c == '-' || c == '_'

validatePayPalCaptureOrderReference :: Maybe Text -> Text -> Either ServerError Text
validatePayPalCaptureOrderReference mStoredOrderId paypalOrderId =
  case mStoredOrderId of
    Nothing ->
      Left err409 { errBody = "Order does not have a PayPal order to capture" }
    Just rawStoredOrderId -> do
      storedOrderId <- validateStoredPayPalOrderId rawStoredOrderId
      if storedOrderId == paypalOrderId
        then Right paypalOrderId
        else Left err400 { errBody = "paypalOrderId does not match this order's PayPal order" }

validateStoredPayPalOrderId :: Text -> Either ServerError Text
validateStoredPayPalOrderId rawStoredOrderId
  | T.null storedOrderId =
      Left err409 { errBody = "Order does not have a PayPal order to capture" }
  | isValidPayPalOrderId storedOrderId =
      Right storedOrderId
  | otherwise =
      Left err500 { errBody = "Stored PayPal order id is invalid" }
  where
    storedOrderId = T.strip rawStoredOrderId

normalizeMarketplaceOrderStatus :: Text -> Maybe Text
normalizeMarketplaceOrderStatus rawStatus =
  case normalizeMarketplaceOrderStatusParts rawStatus of
    Just ["pending"] -> Just "pending"
    Just ["contact"] -> Just "contact"
    Just ["paid"] -> Just "paid"
    Just ["cancelled"] -> Just "cancelled"
    Just ["canceled"] -> Just "cancelled"
    Just ["failed"] -> Just "failed"
    Just ["datafast", "init"] -> Just "datafast_init"
    Just ["datafast", "pending"] -> Just "datafast_pending"
    Just ["datafast", "failed"] -> Just "datafast_failed"
    Just ["paypal", "pending"] -> Just "paypal_pending"
    Just ["paypal", "failed"] -> Just "paypal_failed"
    Just ["stripe", "pending"] -> Just "stripe_pending"
    Just ["stripe", "failed"] -> Just "stripe_failed"
    _ -> Nothing

normalizePayPalCaptureOrderStatus :: Text -> Maybe Text
normalizePayPalCaptureOrderStatus rawStatus =
  case T.toLower (T.strip rawStatus) of
    "completed" -> Just "paid"
    "approved" -> Just "paypal_pending"
    "created" -> Just "paypal_pending"
    "payer_action_required" -> Just "paypal_pending"
    "payeractionrequired" -> Just "paypal_pending"
    "pending" -> Just "paypal_pending"
    "saved" -> Just "paypal_pending"
    "cancelled" -> Just "cancelled"
    "canceled" -> Just "cancelled"
    "voided" -> Just "cancelled"
    "failed" -> Just "paypal_failed"
    "declined" -> Just "paypal_failed"
    "denied" -> Just "paypal_failed"
    "expired" -> Just "paypal_failed"
    _ -> Nothing

normalizeMarketplaceOrderStatusToken :: Text -> Text
normalizeMarketplaceOrderStatusToken =
  T.filter isAlphaNum . T.toLower . T.strip

normalizeMarketplaceOrderStatusParts :: Text -> Maybe [Text]
normalizeMarketplaceOrderStatusParts rawStatus =
  let statusVal = T.strip rawStatus
      parts = T.split isMarketplaceOrderStatusSeparator (T.toLower statusVal)
  in
    if T.null statusVal || T.any (not . isMarketplaceOrderStatusTokenChar) statusVal
      then Nothing
      else
        if any T.null parts
          then Nothing
          else Just parts

isMarketplaceOrderStatusTokenChar :: Char -> Bool
isMarketplaceOrderStatusTokenChar ch =
  isMarketplaceOrderStatusAtom ch || isMarketplaceOrderStatusSeparator ch

isMarketplaceOrderStatusSeparator :: Char -> Bool
isMarketplaceOrderStatusSeparator ch =
  ch == '_' || ch == '-' || ch == ' '

isMarketplaceOrderStatusAtom :: Char -> Bool
isMarketplaceOrderStatusAtom ch =
  isAsciiLower ch || isAsciiUpper ch || isAsciiDecimalDigit ch

normalizeCourseRegistrationStatus :: Text -> Maybe Text
normalizeCourseRegistrationStatus raw =
  case normalizeBookingStatusToken raw of
    "pendingpayment" -> Just "pending_payment"
    "paid" -> Just "paid"
    "cancelled" -> Just "cancelled"
    "canceled" -> Just "cancelled"
    _ -> Nothing

validateServiceMarketplaceCatalog :: Maybe ServiceCatalog -> Either ServerError ServiceKind
validateServiceMarketplaceCatalog Nothing =
  Left err404 { errBody = "Service catalog not found" }
validateServiceMarketplaceCatalog (Just catalog)
  | not (serviceCatalogActive catalog) =
      Left err409 { errBody = "Service catalog is inactive" }
  | otherwise =
      Right (serviceCatalogKind catalog)

validateServiceAdCatalogId :: Maybe Int64 -> Either ServerError Int64
validateServiceAdCatalogId Nothing =
  Left err400 { errBody = "serviceCatalogId is required" }
validateServiceAdCatalogId (Just rawCatalogId) =
  validatePositiveIdField "serviceCatalogId" rawCatalogId

validateServiceAdCurrency :: Maybe Text -> Either ServerError Text
validateServiceAdCurrency = validateCurrencyCode

validateReceiptCurrency :: Maybe Text -> Either ServerError (Maybe Text)
validateReceiptCurrency Nothing = Right Nothing
validateReceiptCurrency (Just rawCurrency) =
  Just <$> validateCurrencyCode (Just rawCurrency)

validateReceiptBuyerName :: Maybe Text -> Either ServerError (Maybe Text)
validateReceiptBuyerName Nothing = Right Nothing
validateReceiptBuyerName (Just rawName) =
  case cleanOptional (Just rawName) of
    Nothing -> Left err400 { errBody = "buyerName must not be blank" }
    Just nameVal
      | T.length nameVal > 160 ->
          Left err400 { errBody = "buyerName must be 160 characters or fewer" }
      | T.any isUnsafeMarketplaceBuyerNameChar nameVal ->
          Left err400
            { errBody =
                "buyerName must not contain control characters or "
                  <> "Unicode formatting/separator characters"
            }
      | otherwise ->
          Right (Just nameVal)

validateReceiptBuyerEmail :: Maybe Text -> Either ServerError (Maybe Text)
validateReceiptBuyerEmail Nothing = Right Nothing
validateReceiptBuyerEmail (Just rawEmail) =
  case cleanOptional (Just rawEmail) of
    Nothing ->
      Left err400 { errBody = "buyerEmail must not be blank" }
    Just _ ->
      case validateCourseRegistrationEmail (Just rawEmail) of
        Right (Just emailVal) -> Right (Just emailVal)
        _ -> Left err400 { errBody = "buyerEmail must be a valid email address" }

validateCurrencyCode :: Maybe Text -> Either ServerError Text
validateCurrencyCode Nothing = Left err400 { errBody = "currency is required" }
validateCurrencyCode (Just rawCurrency) =
  case normalizeCurrencyCodeText rawCurrency of
    Just currency -> Right currency
    Nothing -> Left err400 { errBody = "currency must be a 3-letter ISO code" }

normalizeCurrencyCodeText :: Text -> Maybe Text
normalizeCurrencyCodeText rawCurrency =
  normalizeOptionalInput (Just rawCurrency) >>= Internationalization.normalizeCurrencyCode

validateServiceAdSlotMinutes :: Maybe Int -> Either ServerError Int
validateServiceAdSlotMinutes Nothing = Right 60
validateServiceAdSlotMinutes (Just rawMinutes)
  | rawMinutes < 15 =
      Left err400 { errBody = "slotMinutes must be at least 15" }
  | otherwise = Right rawMinutes

validateServiceAdSlotWindow :: Int -> UTCTime -> UTCTime -> Either ServerError ()
validateServiceAdSlotWindow slotMinutes startsAt endsAt = do
  validSlotMinutes <- validateServiceAdSlotMinutes (Just slotMinutes)
  validateBookingTimeRange startsAt endsAt
  if diffUTCTime endsAt startsAt == fromIntegral (validSlotMinutes * 60)
    then Right ()
    else Left err400 { errBody = "slot duration must match service ad slotMinutes" }

validateEngineer :: Bool -> Maybe Int64 -> Maybe Text -> Either Text ()
validateEngineer engineerRequired mEngineerId mEngineerName
  | Just engineerName <- mEngineerName
  , T.length (T.strip engineerName) > 160 =
      Left "engineerName debe tener 160 caracteres o menos"
  | Just engineerName <- mEngineerName
  , T.any isControl (T.strip engineerName) =
      Left "engineerName no debe contener caracteres de control"
  | Just engineerName <- mEngineerName
  , T.any isUnsafeEngineerNameFormattingChar (T.strip engineerName) =
      Left "engineerName no debe contener marcas Unicode invisibles"
  | Just engineerName <- mEngineerName
  , let engineerNameClean = T.strip engineerName
  , not (T.null engineerNameClean)
  , not (T.any isAlphaNum engineerNameClean) =
      Left "engineerName debe incluir letras o números"
  | engineerRequired && isNothing mEngineerId && maybe True T.null (fmap T.strip mEngineerName) =
      Left "Selecciona un ingeniero para grabación/mezcla/mastering"
  | otherwise = Right ()

isUnsafeEngineerNameFormattingChar :: Char -> Bool
isUnsafeEngineerNameFormattingChar ch =
  generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

resolveBookingEngineerName :: Maybe Text -> Maybe (Entity Party) -> Maybe Text
resolveBookingEngineerName fallbackName mEngineerParty =
  normalizeEngineerNameCandidate (M.partyDisplayName . entityVal <$> mEngineerParty)
    <|> normalizeEngineerNameCandidate fallbackName

normalizeEngineerNameCandidate :: Maybe Text -> Maybe Text
normalizeEngineerNameCandidate rawName = do
  name <- normalizeOptionalInput rawName
  case validateEngineer False Nothing (Just name) of
    Right () -> Just name
    Left _ -> Nothing

notifyEngineerIfNeeded :: BookingDTO -> AppM ()
notifyEngineerIfNeeded BookingDTO{engineerPartyId = Nothing, engineerName = Nothing} = pure ()
notifyEngineerIfNeeded booking = do
  Env pool cfg <- ask
  mEngineer <- liftIO $ flip runSqlPool pool $ case engineerPartyId booking of
    Just pid -> get (toSqlKey (fromIntegral pid) :: Key Party)
    Nothing  -> pure Nothing
  let displayName = DTO.engineerName booking
        <|> (M.partyDisplayName <$> mEngineer)
      emailAddr = mEngineer >>= partyPrimaryEmail
  case emailAddr of
    Nothing -> pure ()
    Just engineerEmail -> do
      let name = fromMaybe engineerEmail displayName
          emailSvc = EmailSvc.mkEmailService cfg
          subjectSvc = fromMaybe "Reserva" (DTO.serviceType booking)
          startTxt = T.pack (formatTime defaultTimeLocale "%Y-%m-%d %H:%M UTC" (DTO.startsAt booking))
          customer = DTO.customerName booking <|> DTO.partyDisplayName booking
          noteText = case booking of DTO.BookingDTO{DTO.notes = ns} -> ns
      notifyResult <- liftIO $
        ((try $
          EmailSvc.sendEngineerBooking
            emailSvc
            name
            engineerEmail
            subjectSvc
            startTxt
            customer
            noteText) :: IO (Either SomeException ()))
      case notifyResult of
        Left err -> do
          let msg = "[Bookings] Failed to notify engineer " <> engineerEmail <> ": " <> T.pack (displayException err)
          liftIO $ do
            hPutStrLn stderr (T.unpack msg)
            LogBuf.addLog LogBuf.LogWarning msg
        Right () -> pure ()

resolveResourcesForBooking :: Maybe (Entity Catalog.ServiceOffering) -> [Text] -> UTCTime -> UTCTime -> SqlPersistT IO [Key Resource]
resolveResourcesForBooking serviceOffering requested start end =
  case normalizeRequestedResourceIds requested of
    Left err -> liftIO (throwIO err)
    Right [] -> defaultResourcesForService serviceOffering start end
    Right explicit -> resolveRequestedResources explicit start end

maxBookingResourceIds :: Int
maxBookingResourceIds = 20

maxBookingResourceIdLength :: Int
maxBookingResourceIdLength = 160

normalizeRequestedResourceIds :: [Text] -> Either ServerError [Text]
normalizeRequestedResourceIds rawIds =
  let normalized = map T.strip rawIds
  in if any T.null normalized
       then Left err400 { errBody = "resourceIds must not contain blank entries" }
       else if length normalized > maxBookingResourceIds
       then
         Left err400
           { errBody =
               BL8.pack $
                 "resourceIds must contain "
                   <> show maxBookingResourceIds
                   <> " entries or fewer"
           }
       else if any ((> maxBookingResourceIdLength) . T.length) normalized
       then
         Left err400
           { errBody =
               BL8.pack $
                 "resourceIds entries must be "
                   <> show maxBookingResourceIdLength
                   <> " characters or fewer"
           }
       else if any (T.any isUnsafeResourceIdChar) normalized
       then
         Left err400
           { errBody =
               "resourceIds must not contain control characters or Unicode formatting marks"
           }
       else case duplicateRequestedResourceIds normalized of
         [] -> Right normalized
         duplicateIds ->
           Left err400
             { errBody =
                 BL.fromStrict . TE.encodeUtf8 $
                   "resourceIds must not contain duplicate entries: "
                     <> T.intercalate ", " duplicateIds
             }

isUnsafeResourceIdChar :: Char -> Bool
isUnsafeResourceIdChar ch =
  isControl ch
    || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

duplicateRequestedResourceIds :: [Text] -> [Text]
duplicateRequestedResourceIds = go Set.empty Set.empty []
  where
    go _ _ duplicates [] = reverse duplicates
    go seen reported duplicates (rid:rest) =
      let normalized = T.toLower rid
      in if Set.member normalized seen
           then
             if Set.member normalized reported
               then go seen reported duplicates rest
               else go seen (Set.insert normalized reported) (rid : duplicates) rest
           else go (Set.insert normalized seen) reported duplicates rest

resolveRequestedResources :: [Text] -> UTCTime -> UTCTime -> SqlPersistT IO [Key Resource]
resolveRequestedResources requestedIds start end = do
  rooms <- selectList [ResourceResourceType ==. Room, ResourceActive ==. True] [Asc ResourceId]
  studioRooms <- selectList [ME.RoomIsBookable ==. True] [Asc ME.RoomName]
  let indexById = Map.fromList $ map (\(Entity k room) -> (k, room)) rooms
      indexBySlug = Map.fromList $ map (\(Entity k room) -> (T.toLower (resourceSlug room), k)) rooms
      indexByName = Map.fromList $ map (\(Entity k room) -> (T.toLower (resourceName room), k)) rooms
      indexByStudioRoomId = Map.fromList $ mapMaybe
        (\(Entity roomKey room) ->
          case Map.lookup (T.toLower (ME.roomName room)) indexByName of
            Nothing -> Nothing
            Just resourceKey -> Just (roomKey, resourceKey))
        studioRooms
      resolveStudioRoomId rid = do
        roomKey <- fromPathPiece rid :: Maybe (Key ME.Room)
        Map.lookup roomKey indexByStudioRoomId
      resolveOne rid =
        case fromPathPiece rid of
          Just key | Map.member key indexById -> Just key
          _ ->
            let normalized = T.toLower rid
            in Map.lookup normalized indexBySlug
                <|> Map.lookup normalized indexByName
                <|> resolveStudioRoomId rid
      unresolved = [rid | rid <- requestedIds, isNothing (resolveOne rid)]
  case dedupeStable unresolved of
    [] -> do
      let resolved = dedupeStable (mapMaybe resolveOne requestedIds)
      availability <- forM resolved $ \key -> do
        available <- isResourceAvailableDB key start end
        pure (key, available)
      let unavailable = [key | (key, False) <- availability]
          unavailableIds =
            dedupeStable
              [ rid
              | rid <- requestedIds
              , Just key <- [resolveOne rid]
              , key `elem` unavailable
              ]
      case unavailableIds of
        [] -> pure resolved
        invalidIds ->
          liftIO . throwIO $
            err409
              { errBody =
                  BL.fromStrict . TE.encodeUtf8 $
                    "resourceIds contain unavailable rooms: "
                      <> T.intercalate ", " invalidIds
              }
    invalidIds ->
      liftIO . throwIO $
        err400
          { errBody =
              BL.fromStrict . TE.encodeUtf8 $
                "resourceIds contain unknown or unavailable rooms: "
                  <> T.intercalate ", " invalidIds
          }

dedupeStable :: Ord a => [a] -> [a]
dedupeStable = go Set.empty
  where
    go _ [] = []
    go seen (x:xs)
      | Set.member x seen = go seen xs
      | otherwise = x : go (Set.insert x seen) xs

defaultResourcesForService :: Maybe (Entity Catalog.ServiceOffering) -> UTCTime -> UTCTime -> SqlPersistT IO [Key Resource]
defaultResourcesForService Nothing _ _ = pure []
defaultResourcesForService (Just (Entity offeringKey offering)) start end = do
  relationships <- selectList
    [ Catalog.ServiceOfferingDefaultResourceServiceOfferingId ==. offeringKey
    , Catalog.ServiceOfferingDefaultResourceActive ==. True
    ]
    [ Asc Catalog.ServiceOfferingDefaultResourceSortOrder
    , Asc Catalog.ServiceOfferingDefaultResourceId
    ]
  resources <- forM relationships $ \(Entity _ relationship) -> do
    mResource <- getEntity (Catalog.serviceOfferingDefaultResourceResourceId relationship)
    selectionModeRows <- case Catalog.serviceOfferingDefaultResourceSelectionModeId relationship of
      Nothing -> pure []
      Just selectionModeKey ->
        rawSql
          "SELECT code FROM service_resource_selection_mode WHERE id=? AND active=TRUE"
          [toPersistValue selectionModeKey]
    case (mResource, selectionModeRows :: [Single Text]) of
      (Just resourceEntity, [Single selectionModeCode])
        | resourceActive (entityVal resourceEntity)
        , resourceResourceType (entityVal resourceEntity) == Room ->
            pure (selectionModeCode, resourceEntity)
      _ ->
        liftIO . throwIO $
          err503
            { errBody =
                "A configured default resource or selection policy is missing or inactive for service offering "
                  <> BL.fromStrict (TE.encodeUtf8 (Catalog.serviceOfferingCode offering))
            }
  let allResources = [resource | ("all", resource) <- resources]
      alternatives = [resource | ("first-available", resource) <- resources]
      unknownModes = dedupeStable [mode | (mode, _) <- resources, mode `notElem` ["all", "first-available"]]
      serviceLabel = Catalog.serviceOfferingCode offering
  unless (null unknownModes) $
    liftIO . throwIO $
      err503
        { errBody =
            BL.fromStrict . TE.encodeUtf8 $
              "Unsupported default-resource selection mode for service offering "
                <> serviceLabel
        }
  required <- requireAvailableDefaultResources serviceLabel allResources start end
  selectedAlternative <- pickAvailableDefaultResource serviceLabel alternatives start end
  pure (dedupeStable (required <> selectedAlternative))

requireAvailableDefaultResources
  :: Text
  -> [Entity Resource]
  -> UTCTime
  -> UTCTime
  -> SqlPersistT IO [Key Resource]
requireAvailableDefaultResources _ [] _ _ = pure []
requireAvailableDefaultResources serviceLabel candidates start end = do
  availability <- defaultResourceAvailability candidates start end
  let unavailableNames =
        [ resourceName room
        | (Entity _ room, False) <- availability
        ]
  case unavailableNames of
    [] -> pure (map entityKey candidates)
    names -> liftIO . throwIO $ unavailableDefaultResourcesError serviceLabel names

pickAvailableDefaultResource
  :: Text
  -> [Entity Resource]
  -> UTCTime
  -> UTCTime
  -> SqlPersistT IO [Key Resource]
pickAvailableDefaultResource _ [] _ _ = pure []
pickAvailableDefaultResource serviceLabel candidates start end = do
  availability <- defaultResourceAvailability candidates start end
  case [ key | (Entity key _, True) <- availability ] of
    key:_ -> pure [key]
    [] ->
      liftIO . throwIO $
        unavailableDefaultResourcesError
          serviceLabel
          [ resourceName room | (Entity _ room, False) <- availability ]

defaultResourceAvailability
  :: [Entity Resource]
  -> UTCTime
  -> UTCTime
  -> SqlPersistT IO [(Entity Resource, Bool)]
defaultResourceAvailability candidates start end =
  forM candidates $ \candidate@(Entity key _) -> do
    available <- isResourceAvailableDB key start end
    pure (candidate, available)

unavailableDefaultResourcesError :: Text -> [Text] -> ServerError
unavailableDefaultResourcesError serviceLabel names =
  err409
    { errBody =
        BL.fromStrict . TE.encodeUtf8 $
          "default resources for service "
            <> serviceLabel
            <> " are unavailable: "
            <> T.intercalate ", " names
    }

isResourceAvailableDB :: Key Resource -> UTCTime -> UTCTime -> SqlPersistT IO Bool
isResourceAvailableDB _ start end | start >= end = pure False
isResourceAvailableDB resourceKey start end = do
  -- The exclusion-backed allocation is the authority, including paid runtime
  -- holds and released/completed history. Booking status alone is insufficient.
  rows <- (rawSql
    "SELECT EXISTS (SELECT 1 FROM service_booking_resource_allocation\
    \ WHERE resource_id = ? AND allocation_status IN ('holding','reserved')\
    \ AND starts_at < ? AND ends_at > ?)"
    [toPersistValue resourceKey, PersistUTCTime end, PersistUTCTime start]
    :: SqlPersistT IO [Single Bool])
  pure $ case rows of
    [Single occupied] -> not occupied
    _ -> False

-- Packages
packageServer :: AuthedUser -> ServerT PackageAPI AppM
packageServer user = listProducts user :<|> createPurchase user

listProducts :: AuthedUser -> AppM [PackageProductDTO]
listProducts user = do
  requireModule user ModulePackages
  Env pool _ <- ask
  ps <- liftIO $ flip runSqlPool pool $ selectList [PackageProductActive ==. True] [Asc PackageProductId]
  pure $ map toDTO ps
  where
    toDTO (Entity pid p) = PackageProductDTO
      { ppId         = fromSqlKey pid
      , ppName       = packageProductName p
      , ppService    = T.pack (show (packageProductServiceKind p))
      , ppUnitsKind  = T.pack (show (packageProductUnitsKind p))
      , ppUnitsQty   = packageProductUnitsQty p
      , ppPriceCents = packageProductPriceCents p
      }

createPurchase :: AuthedUser -> PackagePurchaseReq -> AppM NoContent
createPurchase user req = do
  requireModule user ModulePackages
  Env pool _ <- ask
  now <- liftIO getCurrentTime
  result <- liftIO $ flip runSqlPool pool $ do
    resolved <- resolvePackagePurchaseRefs req
    case resolved of
      Left err -> pure (Left err)
      Right (buyerKey, productKey, productRecord) -> do
        let qty = packageProductUnitsQty productRecord
            priceC = packageProductPriceCents productRecord
        _ <- insert PackagePurchase
              { packagePurchaseBuyerId        = buyerKey
              , packagePurchaseProductId      = productKey
              , packagePurchasePurchasedAt    = now
              , packagePurchasePriceCents     = priceC
              , packagePurchaseExpiresAt      =
                  (\days -> addUTCTime (fromIntegral days * 86400) now)
                    <$> packageProductExpiresDays productRecord
              , packagePurchaseRemainingUnits = qty
              , packagePurchaseStatus         = "Active"
              }
        pure (Right ())
  either throwError pure result
  pure NoContent

resolvePackagePurchaseRefs
  :: PackagePurchaseReq
  -> SqlPersistT IO (Either ServerError (Key Party, Key PackageProduct, PackageProduct))
resolvePackagePurchaseRefs PackagePurchaseReq{buyerId = rawBuyerId, productId = rawProductId} =
  case
    (,) <$> validatePositiveIdField "buyerId" rawBuyerId
        <*> validatePositiveIdField "productId" rawProductId of
    Left err -> pure (Left err)
    Right (buyerIdValid, productIdValid) -> do
      let buyerKey = toSqlKey buyerIdValid :: Key Party
          productKey = toSqlKey productIdValid :: Key PackageProduct
      mBuyer <- get buyerKey
      mProduct <- get productKey
      pure $
        case mBuyer of
          Nothing ->
            Left err422
              { errBody = "buyerId references an unknown party" }
          Just _ ->
            case mProduct of
              Nothing ->
                Left err422
                  { errBody = "productId references an unknown package product" }
              Just productRecord
                | not (packageProductActive productRecord) ->
                    Left err409 { errBody = "Package product is inactive" }
                | maybe False (<= 0) (packageProductExpiresDays productRecord) ->
                    Left err409 { errBody = "Package product validity must be positive when configured" }
                | otherwise ->
                    Right (buyerKey, productKey, productRecord)

resolveInvoiceCustomerId :: Int64 -> SqlPersistT IO (Either ServerError (Key Party))
resolveInvoiceCustomerId rawCustomerId =
  case validatePositiveIdField "customerId" rawCustomerId of
    Left err -> pure (Left err)
    Right customerIdValid -> do
      let customerKey = toSqlKey customerIdValid :: Key Party
      mCustomer <- get customerKey
      pure $
        case mCustomer of
          Nothing ->
            Left err422
              { errBody = "customerId references an unknown party" }
          Just _ ->
            Right customerKey

-- Invoices
invoiceServer :: AuthedUser -> ServerT InvoiceAPI AppM
invoiceServer user =
       listInvoices user
  :<|> createInvoice user
  :<|> generateInvoiceForSession user
  :<|> getInvoicesBySession user
  :<|> getInvoiceById user

generateInvoiceForSession :: AuthedUser -> Text -> Value -> AppM Value
generateInvoiceForSession user sessionId payload = do
  requireModule user ModuleInvoicing
  sessionKey <- parseSessionKey sessionId
  req <- case fromJSON payload of
    Error err -> throwBadRequest ("Invalid generate-invoice payload: " <> T.pack err)
    Success decoded -> pure decoded
  Env pool _ <- ask
  sessionEnt <- liftIO $ flip runSqlPool pool $ getEntity sessionKey
  session <- maybe (throwError err404 { errBody = "Session not found" }) pure sessionEnt
  customerKey <- resolveSessionInvoiceCustomer session req
  now <- liftIO getCurrentTime
  dto <- createInvoice user (toCreateInvoiceReq customerKey req)
  let invoiceKey = toSqlKey (invId dto) :: Key Invoice
  liftIO $ flip runSqlPool pool $ do
    _ <- insertUnique ME.SessionInvoice
      { ME.sessionInvoiceSessionId = sessionKey
      , ME.sessionInvoiceInvoiceId = invoiceKey
      , ME.sessionInvoiceCreatedAt = now
      }
    pure ()
  sriValue <-
    if fromMaybe True (gsiIssueSri req)
      then do
        customer <- loadCustomerForSri customerKey
        sriResult <- liftIO (Sri.runSriInvoiceScript (toSriScriptRequest customer req))
        case sriResult of
          Left err ->
            pure (object ["ok" .= False, "error" .= err])
          Right result -> do
            when (sirStatus result == "issued") $
              liftIO $ flip runSqlPool pool $
                update invoiceKey
                  [ InvoiceStatus =. Sent
                  , InvoiceSriDocumentId =. sirAuthorizationNumber result
                  , InvoiceNumber =. sirInvoiceNumber result
                  ]
            pure (toJSON result)
      else pure Null
  refreshed <- loadInvoiceDTOOr404 invoiceKey
  pure $
    object
      [ "ok" .= True
      , "sessionId" .= sessionId
      , "invoice" .= refreshed
      , "sri" .= sriValue
      ]

getInvoicesBySession :: AuthedUser -> Text -> AppM Value
getInvoicesBySession user sessionId = do
  requireModule user ModuleInvoicing
  sessionKey <- parseSessionKey sessionId
  Env pool _ <- ask
  mInvoices <- liftIO $ flip runSqlPool pool $ do
    mSession <- get sessionKey
    case mSession of
      Nothing -> pure Nothing
      Just _ -> do
        links <- selectList [ME.SessionInvoiceSessionId ==. sessionKey] [Desc ME.SessionInvoiceCreatedAt]
        let invoiceIds = map (ME.sessionInvoiceInvoiceId . entityVal) links
        Just <$> loadInvoiceDTOs invoiceIds
  invoices <- maybe (throwError err404 { errBody = "Session not found" }) pure mInvoices
  pure (toJSON invoices)

getInvoiceById :: AuthedUser -> Int64 -> AppM Value
getInvoiceById user invoiceId = do
  requireModule user ModuleInvoicing
  invoiceIdValid <- either throwError pure (validatePositiveIdField "invoiceId" invoiceId)
  dto <- loadInvoiceDTOOr404 (toSqlKey invoiceIdValid)
  pure (toJSON dto)

listInvoices :: AuthedUser -> AppM [InvoiceDTO]
listInvoices user = do
  requireModule user ModuleInvoicing
  Env pool _ <- ask
  liftIO $ flip runSqlPool pool $ do
    invoices <- selectList [] [Desc InvoiceId]
    let invoiceIds = map entityKey invoices
    lineEntities <-
      if null invoiceIds
        then pure []
        else selectList [InvoiceLineInvoiceId <-. invoiceIds] [Asc InvoiceLineId]
    receiptEntities <-
      if null invoiceIds
        then pure []
        else selectList [ReceiptInvoiceId <-. invoiceIds] []
    let lineMap = foldr (\ent@(Entity _ line) acc ->
                      Map.insertWith (++) (invoiceLineInvoiceId line) [ent] acc)
                    Map.empty
                    lineEntities
        receiptMap = Map.fromList
          [ (receiptInvoiceId rec, entityKey ent)
          | ent@(Entity _ rec) <- receiptEntities
          ]
    pure
      [ invoiceToDTO invEnt
          (Map.findWithDefault [] (entityKey invEnt) lineMap)
          (Map.lookup (entityKey invEnt) receiptMap)
      | invEnt <- invoices
      ]

createInvoice :: AuthedUser -> CreateInvoiceReq -> AppM InvoiceDTO
createInvoice user CreateInvoiceReq{..} = do
  requireModule user ModuleInvoicing
  either throwBadRequest pure (validateInvoiceLineItemCount ciLineItems)
  explicitCurrency <- traverse (either throwError pure . validateCurrencyCode . Just) ciCurrency
  number <- either throwBadRequest pure (validateOptionalInvoiceNumber ciNumber)
  preparedLines <- case traverse prepareLine ciLineItems of
    Left msg   -> throwBadRequest msg
    Right vals -> pure vals
  subtotal <- either throwBadRequest pure $
    validatePreparedCents
      "Invoice subtotal"
      (sum (map (toInteger . plSubtotal) preparedLines))
  taxTotal <- either throwBadRequest pure $
    validatePreparedCents
      "Invoice tax"
      (sum (map (toInteger . plTax) preparedLines))
  grand <- either throwBadRequest pure $
    validatePreparedCents
      "Invoice total"
      (sum (map (toInteger . plTotal) preparedLines))
  Env _ cfg <- ask
  currency <-
    maybe
      (either throwError pure (validateCurrencyCode (Just (defaultCurrency cfg))))
      pure
      explicitCurrency
  unless (currency `elem` supportedCurrencies cfg) $
    throwError err400 { errBody = "Currency is not enabled by SUPPORTED_CURRENCIES" }
  now <- liftIO getCurrentTime
  let day      = utctDay now
      notes    = normalizeOptionalText ciNotes
      invoiceRecord customerKey = Invoice
        { invoiceCustomerId    = customerKey
        , invoiceIssueDate     = day
        , invoiceDueDate       = day
        , invoiceNumber        = number
        , invoiceStatus        = Draft
        , invoiceCurrency      = currency
        , invoiceSubtotalCents = subtotal
        , invoiceTaxCents      = taxTotal
        , invoiceTotalCents    = grand
        , invoiceSriDocumentId = Nothing
        , invoiceNotes         = notes
        , invoiceCreatedAt     = now
        }
  (invoiceEnt, lineEntities, maybeReceiptKey) <- runInvoiceTransaction user $ do
    customerKey <- resolveInvoiceCustomerId ciCustomerId >>= either rejectInvoiceTransaction pure
    let record = invoiceRecord customerKey
    iid <- insert record
    let invEntity = Entity iid record
    invoiceLines <- forM preparedLines $ \pl -> do
      let line = invoiceLineFromPrepared iid pl
      lid <- insert line
      pure (Entity lid line)
    receiptKey <-
      if fromMaybe False ciGenerateReceipt
        then do
          (receiptEnt, _) <- issueReceipt now Nothing Nothing notes Nothing invEntity invoiceLines
          pure (Just (entityKey receiptEnt))
        else pure Nothing
    pure (invEntity, invoiceLines, receiptKey)
  pure $ invoiceToDTO invoiceEnt lineEntities maybeReceiptKey

-- Receipts
receiptServer :: AuthedUser -> ServerT ReceiptAPI AppM
receiptServer user = listReceipts user :<|> createReceipt user :<|> getReceipt user

listReceipts :: AuthedUser -> AppM [ReceiptDTO]
listReceipts user = do
  requireModule user ModuleInvoicing
  Env pool _ <- ask
  liftIO $ flip runSqlPool pool $ do
    receipts <- selectList [] [Desc ReceiptId]
    let receiptIds = map entityKey receipts
    lineEntities <-
      if null receiptIds
        then pure []
        else selectList [ReceiptLineReceiptId <-. receiptIds] [Asc ReceiptLineId]
    let lineMap = foldr (\ent@(Entity _ line) acc ->
                      Map.insertWith (++) (receiptLineReceiptId line) [ent] acc)
                    Map.empty
                    lineEntities
    pure
      [ receiptToDTO recEnt (Map.findWithDefault [] (entityKey recEnt) lineMap)
      | recEnt <- receipts
      ]

createReceipt :: AuthedUser -> CreateReceiptReq -> AppM ReceiptDTO
createReceipt user CreateReceiptReq{..} = do
  requireModule user ModuleInvoicing
  invoiceIdValid <- either throwError pure (validatePositiveIdField "invoiceId" crInvoiceId)
  currencyOverride <- either throwError pure (validateReceiptCurrency crCurrency)
  buyerNameOverride <- either throwError pure (validateReceiptBuyerName crBuyerName)
  buyerEmailOverride <- either throwError pure (validateReceiptBuyerEmail crBuyerEmail)
  now <- liftIO getCurrentTime
  let iid = toSqlKey invoiceIdValid :: Key Invoice
      notesOverride = normalizeOptionalText crNotes
  runInvoiceTransaction user $ do
    -- This row is the idempotency domain. Same-invoice replays serialize here;
    -- different invoices share only the short annual number allocation lock.
    invoices <- rawSql "SELECT ?? FROM invoice WHERE id=? FOR UPDATE" [toPersistValue iid]
    invEnt <- case invoices of
      [entity] -> pure entity
      _ -> rejectInvoiceTransaction err404 { errBody = "Invoice not found" }
    let inv = entityVal invEnt
    when (maybe False (/= invoiceCurrency inv) currencyOverride) $
      rejectInvoiceTransaction err422 { errBody = "Receipt currency must match invoice currency" }
    existing <- getBy (UniqueReceiptInvoice iid)
    case existing of
      Just receiptEnt@(Entity rid rec) -> do
        unless (maybe True (== M.receiptBuyerName rec) buyerNameOverride
             && maybe True (\value -> Just value == M.receiptBuyerEmail rec) buyerEmailOverride
             && maybe True (\value -> Just value == M.receiptNotes rec) notesOverride) $
          rejectInvoiceTransaction err409 { errBody = "Receipt replay parameters differ from issued evidence" }
        receiptLines <- selectList [ReceiptLineReceiptId ==. rid] [Asc ReceiptLineId]
        pure (receiptToDTO receiptEnt receiptLines)
      Nothing -> do
        invoiceLines <- rawSql
          "SELECT ?? FROM invoice_line WHERE invoice_id=? ORDER BY id FOR SHARE"
          [toPersistValue iid]
        (receiptEnt, receiptLines) <- issueReceipt now buyerNameOverride buyerEmailOverride
          notesOverride currencyOverride invEnt invoiceLines
        pure (receiptToDTO receiptEnt receiptLines)

-- Throw inside runSqlPool so every rejected write rolls back before conversion
-- to an HTTP error. Unexpected and asynchronous failures retain their semantics.
newtype InvoiceTransactionRejected = InvoiceTransactionRejected ServerError deriving Show
instance Exception InvoiceTransactionRejected

rejectInvoiceTransaction :: ServerError -> SqlPersistT IO a
rejectInvoiceTransaction = liftIO . throwIO . InvoiceTransactionRejected

runInvoiceTransaction :: AuthedUser -> SqlPersistT IO a -> AppM a
runInvoiceTransaction user action = do
  Env pool _ <- ask
  result <- liftIO $ Safe.tryAny $ flip runSqlPool pool $ do
    admitted <- withCurrentModuleAccess ModuleInvoicing user action
    either rejectInvoiceTransaction pure admitted
  case result of
    Right value -> pure value
    Left failure -> case fromException failure of
      Just (InvoiceTransactionRejected rejected) -> throwError rejected
      Nothing -> case fromException failure of
        Just sqlError
          | sqlState sqlError `elem` ["23505", "23503", "23514", "22003", "40001", "40P01"] ->
              throwError err409 { errBody = "Invoice receipt conflicts with stored evidence; reload before retrying" }
          | otherwise -> liftIO (throwIO (sqlError :: SqlError))
        Nothing -> liftIO (throwIO failure)

getReceipt :: AuthedUser -> Int64 -> AppM ReceiptDTO
getReceipt user ridParam = do
  requireModule user ModuleInvoicing
  receiptIdValid <- either throwError pure (validatePositiveIdField "receiptId" ridParam)
  Env pool _ <- ask
  let rid = toSqlKey receiptIdValid :: Key Receipt
  result <- liftIO $ flip runSqlPool pool $ do
    mReceipt <- getEntity rid
    case mReceipt of
      Nothing -> pure Nothing
      Just rec -> do
        receiptLines <- selectList [ReceiptLineReceiptId ==. rid] [Asc ReceiptLineId]
        pure (Just (receiptToDTO rec receiptLines))
  maybe (throwError err404) pure result

data PreparedLine = PreparedLine
  { plDescription       :: Text
  , plQuantity          :: Int
  , plUnitCents         :: Int
  , plTaxBps            :: Int
  , plServiceOrderId    :: Maybe (Key ServiceOrder)
  , plPackagePurchaseId :: Maybe (Key PackagePurchase)
  , plSubtotal          :: Int
  , plTax               :: Int
  , plTotal             :: Int
  }

maxInvoiceLineItems :: Int
maxInvoiceLineItems = 100

validateInvoiceLineItemCount :: [CreateInvoiceLineReq] -> Either Text ()
validateInvoiceLineItemCount lineItems
  | null lineItems =
      Left "Invoice requires at least one line item"
  | length lineItems > maxInvoiceLineItems =
      Left $
        "Invoice supports at most "
          <> T.pack (show maxInvoiceLineItems)
          <> " line items"
  | otherwise =
      Right ()

validateOptionalInvoiceNumber :: Maybe Text -> Either Text (Maybe Text)
validateOptionalInvoiceNumber Nothing = Right Nothing
validateOptionalInvoiceNumber (Just rawNumber) =
  case normalizeOptionalText (Just rawNumber) of
    Nothing -> Right Nothing
    Just number
      | T.length number > 64 ->
          Left "Invoice number must be 64 characters or fewer"
      | T.any isControl number ->
          Left "Invoice number must not contain control characters"
      | T.any isHiddenInvoiceNumberChar number ->
          Left "Invoice number must not contain control characters or Unicode formatting marks"
      | otherwise ->
          Right (Just number)

isHiddenInvoiceNumberChar :: Char -> Bool
isHiddenInvoiceNumberChar ch =
  generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

prepareLine :: CreateInvoiceLineReq -> Either Text PreparedLine
prepareLine CreateInvoiceLineReq{..} = do
  let desc = T.strip cilDescription
  if T.null desc then Left "Line item description is required" else pure ()
  when (T.any isUnsafeInvoiceLineDescriptionChar desc) $
    Left "Line item description must not contain control characters or Unicode formatting marks"
  when (cilQuantity <= 0) $ Left "Line item quantity must be greater than zero"
  when (cilUnitCents < 0) $ Left "Line item unit amount must be zero or greater"
  let taxBpsVal = fromMaybe 0 cilTaxBps
  when (taxBpsVal < 0) $ Left "Line item tax basis points must be zero or greater"
  when (taxBpsVal > 10000) $ Left "Line item tax basis points must be 10000 or less"
  when (isJust cilServiceOrderId && isJust cilPackagePurchaseId) $
    Left "Line item may reference either serviceOrderId or packagePurchaseId, not both"
  serviceOrderKey <- case cilServiceOrderId of
    Nothing -> Right Nothing
    Just rawRef
      | rawRef > 0 -> Right (Just (toSqlKey rawRef :: Key ServiceOrder))
      | otherwise -> Left "serviceOrderId must be a positive integer"
  packagePurchaseKey <- case cilPackagePurchaseId of
    Nothing -> Right Nothing
    Just rawRef
      | rawRef > 0 -> Right (Just (toSqlKey rawRef :: Key PackagePurchase))
      | otherwise -> Left "packagePurchaseId must be a positive integer"
  let subtotalInteger = toInteger cilQuantity * toInteger cilUnitCents
      taxInteger      = (subtotalInteger * toInteger taxBpsVal) `div` 10000
      totalInteger    = subtotalInteger + taxInteger
  subtotal <- validatePreparedCents "Line item subtotal" subtotalInteger
  tax      <- validatePreparedCents "Line item tax" taxInteger
  total    <- validatePreparedCents "Line item total" totalInteger
  pure PreparedLine
    { plDescription       = desc
    , plQuantity          = cilQuantity
    , plUnitCents         = cilUnitCents
    , plTaxBps            = taxBpsVal
    , plServiceOrderId    = serviceOrderKey
    , plPackagePurchaseId = packagePurchaseKey
    , plSubtotal          = subtotal
    , plTax               = tax
    , plTotal             = total
    }

isUnsafeInvoiceLineDescriptionChar :: Char -> Bool
isUnsafeInvoiceLineDescriptionChar ch =
  isControl ch || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

validatePreparedCents :: Text -> Integer -> Either Text Int
validatePreparedCents fieldName value
  | value > toInteger (maxBound :: Int) =
      Left (fieldName <> " exceeds supported invoice amount")
  | otherwise = Right (fromInteger value)

invoiceLineFromPrepared :: Key Invoice -> PreparedLine -> InvoiceLine
invoiceLineFromPrepared iid PreparedLine{..} = InvoiceLine
  { invoiceLineInvoiceId         = iid
  , invoiceLineServiceOrderId    = plServiceOrderId
  , invoiceLinePackagePurchaseId = plPackagePurchaseId
  , invoiceLineDescription       = plDescription
  , invoiceLineQuantity          = plQuantity
  , invoiceLineUnitCents         = plUnitCents
  , invoiceLineTaxBps            = plTaxBps
  , invoiceLineTotalCents        = plTotal
  }

normalizeCurrency :: Maybe Text -> Text
normalizeCurrency mCur =
  case fmap T.strip mCur of
    Just cur | not (T.null cur) -> T.toUpper cur
    _                           -> ""

normalizeOptionalText :: Maybe Text -> Maybe Text
normalizeOptionalText =
  let clean t =
        let trimmed = T.strip t
        in if T.null trimmed then Nothing else Just trimmed
  in (>>= clean)

validateSessionPathId :: Text -> Either ServerError (Key ME.Session)
validateSessionPathId raw =
  let normalized = T.strip raw
      invalid = Left err400 { errBody = "Invalid session identifier" }
  in if T.null normalized || normalized /= raw
       then invalid
       else
         case fromPathPiece normalized of
           Just key | toPathPiece key == normalized -> Right key
           _ -> invalid

parseSessionKey :: Text -> AppM (Key ME.Session)
parseSessionKey raw =
  either throwError pure (validateSessionPathId raw)

resolveSessionInvoiceCustomer :: Entity ME.Session -> GenerateSessionInvoiceReq -> AppM (Key Party)
resolveSessionInvoiceCustomer (Entity _ session) req =
  case gsiCustomerId req of
    Just cid -> pure (toSqlKey cid)
    Nothing ->
      case ME.sessionClientPartyRef session >>= readMaybe . T.unpack of
        Just cid -> pure (toSqlKey cid)
        Nothing ->
          throwBadRequest
            "Session clientPartyRef is not a numeric party id; provide customerId explicitly."

toCreateInvoiceReq :: Key Party -> GenerateSessionInvoiceReq -> CreateInvoiceReq
toCreateInvoiceReq customerKey req =
  CreateInvoiceReq
    { ciCustomerId = fromSqlKey customerKey
    , ciCurrency = gsiCurrency req
    , ciNumber = gsiNumber req
    , ciNotes = gsiNotes req
    , ciLineItems = map toLineItem (gsiLineItems req)
    , ciGenerateReceipt = gsiGenerateReceipt req
    }
  where
    toLineItem GenerateSessionInvoiceLineReq{..} =
      CreateInvoiceLineReq
        { cilDescription = gsilDescription
        , cilQuantity = gsilQuantity
        , cilUnitCents = gsilUnitCents
        , cilTaxBps = gsilTaxBps
        , cilServiceOrderId = gsilServiceOrderId
        , cilPackagePurchaseId = gsilPackagePurchaseId
        }

loadCustomerForSri :: Key Party -> AppM Sri.SriScriptCustomer
loadCustomerForSri partyKey = do
  Env pool _ <- ask
  mParty <- liftIO $ flip runSqlPool pool $ get partyKey
  case mParty of
    Nothing -> throwError err404 { errBody = "Customer not found" }
    Just party ->
      case normalizeOptionalText (partyTaxId party) of
        Nothing -> throwBadRequest "Customer taxId/RUC is required for SRI emission"
        Just taxIdVal ->
          pure Sri.SriScriptCustomer
            { Sri.ruc = taxIdVal
            , Sri.legalName =
                fromMaybe (M.partyDisplayName party) (normalizeOptionalText (partyLegalName party))
            , Sri.email = normalizeOptionalText (partyPrimaryEmail party)
            , Sri.phone = normalizeOptionalText (partyPrimaryPhone party)
            }

toSriScriptRequest :: Sri.SriScriptCustomer -> GenerateSessionInvoiceReq -> Sri.SriScriptRequest
toSriScriptRequest customer req =
  Sri.SriScriptRequest
    { Sri.customer = customer
    , Sri.lines = map toSriLine (gsiLineItems req)
    , Sri.establishment = "001"
    , Sri.emissionPoint = "100"
    , Sri.paymentMode = "cash"
    , Sri.signAndSend = fromMaybe True (gsiIssueSri req)
    , Sri.certificatePassword = normalizeOptionalText (gsiCertificatePassword req)
    }
  where
    toSriLine GenerateSessionInvoiceLineReq{..} =
      Sri.SriScriptLine
        { Sri.code = normalizeOptionalText gsilSriCode
        , Sri.auxiliaryCode = normalizeOptionalText gsilSriAuxiliaryCode
        , Sri.description = gsilDescription
        , Sri.quantity = gsilQuantity
        , Sri.unitCents = gsilUnitCents
        , Sri.taxBps = gsilTaxBps
        , Sri.sriAdditionalInfo = normalizeOptionalText gsilSriAdditionalInfo
        , Sri.sriIvaCode = normalizeOptionalText gsilSriIvaCode
        }

loadInvoiceDTOOr404 :: Key Invoice -> AppM InvoiceDTO
loadInvoiceDTOOr404 invoiceKey = do
  Env pool _ <- ask
  mDto <- liftIO $ flip runSqlPool pool (loadInvoiceDTO invoiceKey)
  maybe (throwError err404 { errBody = "Invoice not found" }) pure mDto

loadInvoiceDTO :: Key Invoice -> SqlPersistT IO (Maybe InvoiceDTO)
loadInvoiceDTO invoiceKey = do
  mInvoice <- getEntity invoiceKey
  case mInvoice of
    Nothing -> pure Nothing
    Just invEnt -> do
      invLines <- selectList [InvoiceLineInvoiceId ==. invoiceKey] [Asc InvoiceLineId]
      mReceipt <- selectFirst [ReceiptInvoiceId ==. invoiceKey] []
      pure (Just (invoiceToDTO invEnt invLines (entityKey <$> mReceipt)))

loadInvoiceDTOs :: [Key Invoice] -> SqlPersistT IO [InvoiceDTO]
loadInvoiceDTOs invoiceKeys = do
  let orderedKeys = nub invoiceKeys
  if null orderedKeys
    then pure []
    else do
      invoices <- selectList [InvoiceId <-. orderedKeys] []
      invLines <- selectList [InvoiceLineInvoiceId <-. orderedKeys] [Asc InvoiceLineId]
      receipts <- selectList [ReceiptInvoiceId <-. orderedKeys] []
      let invoiceMap = Map.fromList [(entityKey ent, ent) | ent <- invoices]
          lineMap = Map.fromListWith (++)
            [(invoiceLineInvoiceId (entityVal ent), [ent]) | ent <- invLines]
          receiptMap = Map.fromList
            [(receiptInvoiceId (entityVal ent), entityKey ent) | ent <- receipts]
      pure
        [ invoiceToDTO invEnt (Map.findWithDefault [] key lineMap) (Map.lookup key receiptMap)
        | key <- orderedKeys
        , Just invEnt <- [Map.lookup key invoiceMap]
        ]

invoiceToDTO :: Entity Invoice -> [Entity InvoiceLine] -> Maybe (Key Receipt) -> InvoiceDTO
invoiceToDTO (Entity iid inv) invLines mReceiptKey = InvoiceDTO
  { invId      = fromSqlKey iid
  , number     = invoiceNumber inv
  , statusI    = T.pack (show (invoiceStatus inv))
  , subtotalC  = invoiceSubtotalCents inv
  , taxC       = invoiceTaxCents inv
  , totalC     = invoiceTotalCents inv
  , currency   = invoiceCurrency inv
  , customerId = Just (fromSqlKey (invoiceCustomerId inv))
  , sriDocumentId = invoiceSriDocumentId inv
  , notes      = invoiceNotes inv
  , receiptId  = fmap fromSqlKey mReceiptKey
  , lineItems  = map invoiceLineToDTO invLines
  }

invoiceLineToDTO :: Entity InvoiceLine -> InvoiceLineDTO
invoiceLineToDTO (Entity lid line) = InvoiceLineDTO
  { lineId            = fromSqlKey lid
  , description       = invoiceLineDescription line
  , quantity          = invoiceLineQuantity line
  , unitCents         = invoiceLineUnitCents line
  , taxBps            = invoiceLineTaxBps line
  , totalCents        = invoiceLineTotalCents line
  , serviceOrderId    = fromSqlKey <$> invoiceLineServiceOrderId line
  , packagePurchaseId = fromSqlKey <$> invoiceLinePackagePurchaseId line
  }

receiptToDTO :: Entity Receipt -> [Entity ReceiptLine] -> ReceiptDTO
receiptToDTO (Entity rid rec) receiptLines = ReceiptDTO
  { receiptId     = fromSqlKey rid
  , receiptNumber = M.receiptNumber rec
  , issuedAt      = M.receiptIssuedAt rec
  , issueDate     = M.receiptIssueDate rec
  , buyerName     = M.receiptBuyerName rec
  , buyerEmail    = M.receiptBuyerEmail rec
  , currency      = M.receiptCurrency rec
  , subtotalCents = M.receiptSubtotalCents rec
  , taxCents      = M.receiptTaxCents rec
  , totalCents    = M.receiptTotalCents rec
  , notes         = M.receiptNotes rec
  , invoiceId     = fromSqlKey (M.receiptInvoiceId rec)
  , lineItems     = map receiptLineToDTO receiptLines
  }

receiptLineToDTO :: Entity ReceiptLine -> ReceiptLineDTO
receiptLineToDTO (Entity lid line) = ReceiptLineDTO
  { receiptLineId = fromSqlKey lid
  , rlDescription = receiptLineDescription line
  , rlQuantity    = receiptLineQuantity line
  , rlUnitCents   = receiptLineUnitCents line
  , rlTaxBps      = receiptLineTaxBps line
  , rlTotalCents  = receiptLineTotalCents line
  }

issueReceipt
  :: UTCTime
  -> Maybe Text
  -> Maybe Text
  -> Maybe Text
  -> Maybe Text
  -> Entity Invoice
  -> [Entity InvoiceLine]
  -> SqlPersistT IO (Entity Receipt, [Entity ReceiptLine])
issueReceipt now mBuyerName mBuyerEmail mNotes mCurrency (Entity iid inv) lineEntities = do
  let customerId = invoiceCustomerId inv
  party <- get customerId
  let defaultName  = maybe "Cliente" M.partyDisplayName party
      defaultEmail = party >>= partyPrimaryEmail
      buyerName    = fromMaybe defaultName mBuyerName
      buyerEmail   = mBuyerEmail <|> defaultEmail
      currency     = invoiceCurrency inv
      notes        = mNotes <|> invoiceNotes inv
  when (maybe False (/= currency) mCurrency) $
    rejectInvoiceTransaction err422 { errBody = "Receipt currency must match invoice currency" }
  (subtotal, taxTotal, total) <- either
    (\message -> rejectInvoiceTransaction err422 { errBody = BL.fromStrict (TE.encodeUtf8 message) })
    pure $ validateReceiptSnapshot
      (invoiceSubtotalCents inv, invoiceTaxCents inv, invoiceTotalCents inv)
      [ (invoiceLineQuantity line, invoiceLineUnitCents line,
         invoiceLineTaxBps line, invoiceLineTotalCents line)
      | Entity _ line <- lineEntities ]
  number <- generateReceiptNumber (utctDay now)
  let receiptRecord = Receipt
        { receiptInvoiceId    = iid
        , receiptNumber       = number
        , receiptIssueDate    = utctDay now
        , receiptIssuedAt     = now
        , receiptBuyerPartyId = Just customerId
        , receiptBuyerName    = buyerName
        , receiptBuyerEmail   = buyerEmail
        , receiptCurrency     = currency
        , receiptSubtotalCents = subtotal
        , receiptTaxCents     = taxTotal
        , receiptTotalCents   = total
        , receiptNotes        = notes
        , receiptCreatedAt    = now
        }
  rid <- insert receiptRecord
  forM_ lineEntities $ \(Entity _ line) -> do
    let lineRecord = ReceiptLine
          { receiptLineReceiptId = rid
          , receiptLineDescription = invoiceLineDescription line
          , receiptLineQuantity    = invoiceLineQuantity line
          , receiptLineUnitCents   = invoiceLineUnitCents line
          , receiptLineTaxBps      = Just (invoiceLineTaxBps line)
          , receiptLineTotalCents  = invoiceLineTotalCents line
          }
    insert_ lineRecord
  -- PostgreSQL normalizes timestamps to its storage precision. Return the
  -- persisted representation on first issuance as well as every replay.
  persistedReceipt <- getJust rid
  persistedLines <- selectList [ReceiptLineReceiptId ==. rid] [Asc ReceiptLineId]
  pure (Entity rid persistedReceipt, persistedLines)

generateReceiptNumber :: Day -> SqlPersistT IO Text
generateReceiptNumber day = do
  let (year, _, _) = toGregorian day
  allocated <- rawSql
    "INSERT INTO receipt_number_counter(receipt_year,last_number) VALUES (?,1) ON CONFLICT (receipt_year) DO UPDATE SET last_number=receipt_number_counter.last_number+1 RETURNING last_number"
    [PersistInt64 (fromInteger year)] :: SqlPersistT IO [Single Int64]
  case allocated of
    [Single sequenceNumber] -> pure (T.pack (printf "R-%04d-%04d" year sequenceNumber))
    _ -> rejectInvoiceTransaction err409 { errBody = "Receipt number allocation failed" }

throwBadRequest :: Text -> AppM a
throwBadRequest msg = throwError err400 { errBody = BL.fromStrict (TE.encodeUtf8 msg) }

hasRole :: RoleEnum -> AuthedUser -> Bool
hasRole roleTag AuthedUser{..} = roleTag `elem` auRoles


requireModule :: AuthedUser -> ModuleAccess -> AppM ()
requireModule user moduleTag =
  either throwError pure (validateModuleAccess moduleTag user)

requireStrictAdmin :: AuthedUser -> AppM ()
requireStrictAdmin user =
  either throwError pure (validateStrictAdminAccess user)

validateStrictAdminAccess :: AuthedUser -> Either ServerError ()
validateStrictAdminAccess AuthedUser{..}
  | Admin `notElem` auRoles =
      Left err403 { errBody = BL.fromStrict (TE.encodeUtf8 "Admin role required") }
  | fromSqlKey auPartyId <= 0 =
      Left err403 { errBody = "Valid admin party required" }
  | length auRoles /= length (nub auRoles) =
      Left err403 { errBody = "Admin role grants must be unique" }
  | any (not . isStrictAdminRoleScope) auRoles =
      Left err403
        { errBody = "Strict Admin access cannot be combined with non-baseline roles" }
  | otherwise =
      Right ()
  where
    isStrictAdminRoleScope role =
      role `elem` [Admin, Fan, Customer]
-- User roles API
userRolesServer :: AuthedUser -> ServerT UserRolesAPI AppM
userRolesServer user = do
  requireStrictAdmin user
  Env pool _ <- ask
  liftIO $ flip runSqlPool pool loadUserRoleSummaries

loadUserRoleSummaries :: SqlPersistT IO [UserRoleSummaryDTO]
loadUserRoleSummaries = do
  creds <- selectList [] [Asc UserCredentialId]
  mapM summarize creds
  where
    summarize (Entity credId cred) = do
      party <- getJustEntity (userCredentialPartyId cred)
      rolesResult <- loadCanonicalPartyRoles (userCredentialPartyId cred)
      roleValues <- either
        (liftIO . ioError . userError . T.unpack)
        pure
        rolesResult
      pure UserRoleSummaryDTO
        { id        = fromSqlKey credId
        , partyId   = fromSqlKey (userCredentialPartyId cred)
        , name      = M.partyDisplayName (entityVal party)
        , email     = M.partyPrimaryEmail (entityVal party)
        , phone     = M.partyPrimaryPhone (entityVal party)
        , roles     = roleValues
        , status    = if userCredentialActive cred then AccountStatusActive else AccountStatusInactive
        , createdAt = M.partyCreatedAt (entityVal party)
        }

adsPublicServer :: ServerT AdsPublicAPI AppM
adsPublicServer = adsInquiryPublic

validateAdsInquiry :: AdsInquiry -> Either ServerError AdsInquiry
validateAdsInquiry AdsInquiry{..} = do
  nameClean <- validateOptionalCourseRegistrationTextField "name" 160 aiName
  emailClean <- validateCourseRegistrationEmail aiEmail
  phoneClean <- validateAdsInquiryPhone aiPhone
  validateAdsInquiryContactChannels emailClean phoneClean
  courseClean <- validateOptionalCourseRegistrationTextField "course" 160 aiCourse
  channelClean <- validateAdsInquiryChannel aiChannel
  messageClean <- validateAdsInquiryMessage aiMessage
  pure AdsInquiry
    { aiName = nameClean
    , aiEmail = emailClean
    , aiPhone = phoneClean
    , aiCourse = courseClean
    , aiMessage = messageClean
    , aiChannel = channelClean
    }

adsInquiryPublic :: Maybe Text -> AdsInquiry -> AppM AdsInquiryOut
adsInquiryPublic maybeKey rawInquiry = do
  inquiry <- either throwError pure (validateAdsInquiry rawInquiry)
  requestKey <- either throwError pure (validateAdsInquiryRequestKey maybeKey)
  env <- ask
  now <- liftIO getCurrentTime
  (fresh, response) <- runDB (createAdsInquiryDb requestKey inquiry now) >>= either throwError pure
  if not fresh then pure response else do
    -- The committed receipt reserves notification dispatch exactly once. A
    -- crash or ambiguous external response is reviewed; retries never resend.
    (_, courseLabel) <- runDB $ resolveSubject (aiCourse inquiry)
    attempted <- liftIO $ (try (sendAutoReplies (envPool env) (toSqlKey (fromIntegral (aioPartyId response))) (envConfig env) inquiry courseLabel) :: IO (Either SomeException [Text]))
    case attempted of
      Left _ -> do
        runDB $ rawExecute "UPDATE identity_ads_request SET notification_state='review' WHERE request_key=?" [PersistText requestKey]
        pure response
      Right channels -> do
        let completed = response { aioRepliedVia = channels }
        runDB $ rawExecute "UPDATE identity_ads_request SET notification_state=?, response_payload=?::jsonb WHERE request_key=?"
          [PersistText (if null channels then "review" else "completed"), PersistText (TE.decodeUtf8 (BL.toStrict (encode completed))), PersistText requestKey]
        pure completed

validateAdsInquiryRequestKey :: Maybe Text -> Either ServerError Text
validateAdsInquiryRequestKey (Just key)
  | T.length key >= 16 && T.length key <= 128
  , T.all (\ch -> ch <= '\x7f' && (isAlphaNum ch || ch == '-' || ch == '_')) key = Right key
validateAdsInquiryRequestKey _ = Left err400 { errBody = "Refresh the form before submitting: a valid Idempotency-Key is required." }

createAdsInquiryDb :: Text -> AdsInquiry -> UTCTime -> SqlPersistT IO (Either ServerError (Bool, AdsInquiryOut))
createAdsInquiryDb requestKey inquiry now = do
  let payload = TE.decodeUtf8 (BL.toStrict (encode inquiry))
  _ <- (rawSql "SELECT 1::bigint FROM pg_advisory_xact_lock(hashtextextended('public-ads:' || ?, 0))" [PersistText requestKey] :: SqlPersistT IO [Single Int64])
  saved <- (rawSql "SELECT request_payload=?::jsonb, response_payload::text FROM identity_ads_request WHERE request_key=?" [PersistText payload,PersistText requestKey] :: SqlPersistT IO [(Single Bool, Single Text)])
  case saved of
    [(Single True, Single response)] -> pure $ case eitherDecodeStrict' (TE.encodeUtf8 response) of
      Left _ -> Left err500 { errBody = "Saved inquiry requires review" }
      Right accepted -> Right (False, accepted)
    [_] -> pure $ Left err409 { errBody = "This inquiry was already saved with different details." }
    [] -> do
      partyResult <- ensurePartyForInquiry inquiry now
      case partyResult of
        Left err -> pure (Left err)
        Right partyId -> do
          (subjectKey, _) <- resolveSubject (aiCourse inquiry)
          inquiryId <- insert (Trials.LeadInterest
            { Trials.leadInterestPartyId = partyId
            , Trials.leadInterestInterestType = "ad_inquiry"
            , Trials.leadInterestSubjectId = subjectKey
            , Trials.leadInterestDetails = fmap T.strip (aiMessage inquiry)
            , Trials.leadInterestSource = T.toLower (fromMaybe "ads" (aiChannel inquiry))
            , Trials.leadInterestDriveLink = Nothing
            , Trials.leadInterestStatus = "Open"
            , Trials.leadInterestCreatedAt = now
            })
          let response = AdsInquiryOut True (entityKeyInt inquiryId) (entityKeyInt partyId) []
          rawExecute "INSERT INTO identity_ads_request(request_key,party_id,lead_interest_id,request_payload,response_payload,notification_state) VALUES (?,?,?,?::jsonb,?::jsonb,'dispatching')"
            [PersistText requestKey,toPersistValue partyId,toPersistValue inquiryId,PersistText payload,PersistText (TE.decodeUtf8 (BL.toStrict (encode response)))]
          pure $ Right (True,response)
    _ -> pure $ Left err500 { errBody = "Inquiry identity requires review" }

validateAdsAssistRequest
  :: AdsAssistRequest
  -> Either ServerError (Text, Maybe ME.AdCreativeId, Maybe ME.CampaignId, Maybe Text)
validateAdsAssistRequest
  AdsAssistRequest{aarAdId, aarCampaignId, aarMessage, aarChannel, aarPartyId} = do
  validatePublicAdsAssistPartyId aarPartyId
  body <- validateMessage
  adKey <- fmap toSqlKey <$> validateOptionalPositiveIdField "adId" aarAdId
  campaignKey <- fmap toSqlKey <$> validateOptionalPositiveIdField "campaignId" aarCampaignId
  channel <- validateAdsAssistRequestChannel aarChannel
  pure (body, adKey, campaignKey, channel)
  where
    validateMessage =
      let body = T.strip aarMessage
      in if T.null body
           then Left err400 { errBody = "Mensaje vacío" }
           else
             if T.length body > 2000
               then Left err400 { errBody = "Mensaje demasiado largo (max 2000 caracteres)" }
               else
                 if T.any isUnsupportedAdsAssistMessageChar body
                   then Left err400 { errBody = "Mensaje no debe contener caracteres de control o formato oculto" }
                   else Right body
    isUnsupportedAdsAssistMessageChar ch =
      (isControl ch && ch /= '\n' && ch /= '\r' && ch /= '\t')
        || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

validatePublicAdsAssistPartyId :: Maybe Int64 -> Either ServerError ()
validatePublicAdsAssistPartyId Nothing = Right ()
validatePublicAdsAssistPartyId (Just _) =
  Left err400 { errBody = "partyId is not allowed on public ads assist requests" }

validateAdsAssistChannel :: Maybe Text -> Either ServerError (Maybe Text)
validateAdsAssistChannel Nothing = Right Nothing
validateAdsAssistChannel (Just rawChannel)
  | T.null (T.strip rawChannel) =
      Left err400 { errBody = "channel must be omitted instead of blank" }
validateAdsAssistChannel (Just rawChannel) =
  case T.toLower <$> normalizeOptionalInput (Just rawChannel) of
    Nothing -> Right Nothing
    Just "instagram" -> Right (Just "instagram")
    Just "facebook" -> Right (Just "facebook")
    Just "whatsapp" -> Right (Just "whatsapp")
    _ -> Left err400 { errBody = "channel inválido (instagram|facebook|whatsapp)" }

validateAdsAssistRequestChannel :: Maybe Text -> Either ServerError (Maybe Text)
validateAdsAssistRequestChannel (Just rawChannel)
  | T.null (T.strip rawChannel) = Right Nothing
validateAdsAssistRequestChannel rawChannel =
  validateAdsAssistChannel rawChannel

validateAdCreativeLandingUrl :: Maybe Text -> Either ServerError (Maybe Text)
validateAdCreativeLandingUrl = validateCoursePublicUrlField "landingUrl"

validateAdCreativeExternalId :: Maybe Text -> Either ServerError (Maybe Text)
validateAdCreativeExternalId Nothing = Right Nothing
validateAdCreativeExternalId (Just rawExternalId) =
  case normalizeOptionalInput (Just rawExternalId) of
    Nothing -> Right Nothing
    Just externalId
      | T.length externalId > maxAdCreativeExternalIdChars ->
          Left err400
            { errBody =
                BL.fromStrict $
                  TE.encodeUtf8 $
                    "externalId must be "
                      <> T.pack (show maxAdCreativeExternalIdChars)
                      <> " characters or fewer"
            }
      | T.any isSpace externalId ->
          Left err400 { errBody = "externalId must not contain whitespace" }
      | T.any isControl externalId ->
          Left err400 { errBody = "externalId must not contain control characters" }
      | T.any isHiddenAdsAdminTextChar externalId ->
          Left err400
            { errBody = "externalId must not contain hidden formatting characters" }
      | not (T.any isAdCreativeExternalIdAtom externalId)
          || not (T.all isAdCreativeExternalIdChar externalId) ->
          Left err400
            { errBody =
                "externalId must be an ASCII token using letters, numbers, "
                  <> "hyphens, underscores, dots, or colons"
            }
      | otherwise ->
          Right (Just externalId)

maxAdCreativeExternalIdChars :: Int
maxAdCreativeExternalIdChars = 256

isAdCreativeExternalIdAtom :: Char -> Bool
isAdCreativeExternalIdAtom ch =
  isDigit ch || isAsciiLower ch || isAsciiUpper ch

isAdCreativeExternalIdChar :: Char -> Bool
isAdCreativeExternalIdChar ch =
  isAdCreativeExternalIdAtom ch || ch `elem` ("-_.:" :: String)

isHiddenAdsAdminTextChar :: Char -> Bool
isHiddenAdsAdminTextChar ch =
  generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

validateAdsAdminName :: Text -> Text -> Either ServerError Text
validateAdsAdminName fieldName =
  validateRequiredCourseTextField fieldName 160

validateCampaignBudgetCents :: Maybe Int -> Either ServerError (Maybe Int)
validateCampaignBudgetCents Nothing = Right Nothing
validateCampaignBudgetCents (Just amount)
  | amount < 0 = Left err400 { errBody = "budgetCents must be non-negative" }
  | otherwise = Right (Just amount)

validateCampaignDateRange :: Maybe Day -> Maybe Day -> Either ServerError ()
validateCampaignDateRange (Just startDate) (Just endDate)
  | endDate < startDate =
      Left err400 { errBody = "campaign endDate must be on or after startDate" }
validateCampaignDateRange _ _ = Right ()

validateCampaignStatus :: Maybe Text -> Either ServerError Text
validateCampaignStatus =
  validateAdsAdminStatus "campaign status"

validateAdCreativeStatus :: Maybe Text -> Either ServerError Text
validateAdCreativeStatus =
  validateAdsAdminStatus "ad status"

validateAdsAdminStatus :: Text -> Maybe Text -> Either ServerError Text
validateAdsAdminStatus _ Nothing = Right "active"
validateAdsAdminStatus fieldName (Just rawStatus) =
  let statusVal = T.toLower (T.strip rawStatus)
  in if T.null statusVal
       then Right "active"
       else
         if validAdsAdminStatus statusVal
           then Right statusVal
           else
             Left err400
               { errBody =
                   BL.fromStrict $
                     TE.encodeUtf8 $
                       fieldName
                         <> " must be an ASCII keyword using letters, numbers, underscores, "
                         <> "or hyphens (64 chars max)"
               }

validAdsAdminStatus :: Text -> Bool
validAdsAdminStatus statusVal =
  not (T.null statusVal)
    && T.length statusVal <= 64
    && T.all isStatusChar statusVal
    && isStatusAtom (T.head statusVal)
    && isStatusAtom (T.last statusVal)
    && not (hasAdjacentSeparators statusVal)
  where
    isStatusAtom ch = isAsciiLower ch || isDigit ch
    isStatusSeparator ch = ch == '_' || ch == '-'
    isStatusChar ch = isStatusAtom ch || isStatusSeparator ch
    hasAdjacentSeparators txt =
      any
        (\(left, right) -> isStatusSeparator left && isStatusSeparator right)
        (T.zip txt (T.drop 1 txt))

adsAssistStaff :: AuthedUser -> AdsAssistRequest -> AppM AdsAssistResponse
adsAssistStaff user req = do
  unless (hasSocialInboxAccess user) $
    throwError err403 { errBody = "Missing required module access" }
  (body, adKey, campaignKey, channel) <- either throwError pure (validateAdsAssistRequest req)
  env <- ask
  let hasScope = isJust adKey || isJust campaignKey
  campaignAdKeys <- runDB $
    case campaignKey of
      Nothing -> pure []
      Just ck -> selectKeysList [ME.AdCreativeCampaignId ==. Just ck] []
  candidateAds <- either throwError pure $
    resolveAdsAssistExampleScope adKey campaignKey campaignAdKeys
  examples <- runDB $ loadAdExamples hasScope candidateAds
  kb <- liftIO $ retrieveRagContext (envConfig env) (envPool env) body
  reply <- liftIO $ runRagChatWithStatus (envConfig env) kb examples body channel
  finalReply <-
    case resolveAdsAssistFinalReply (envConfig env) reply of
      Right txt -> do
        case reply of
          Left err | shouldUseAdsAssistNoAiFallback err ->
            liftIO $
              hPutStrLn stderr
                ("[ads/assist] AI generation unavailable, using fallback. Error: " <> T.unpack err)
          _ -> pure ()
        pure txt
      Left serverErr -> do
        liftIO $ hPutStrLn stderr "[ads/assist] AI generation failed without fallback."
        throwError serverErr
  pure AdsAssistResponse
    { aasReply = finalReply
    , aasUsedExamples = map adExampleToDTO examples
    , aasKnowledgeUsed = kb
    }

resolveAdsAssistFinalReply :: AppConfig -> Either Text Text -> Either ServerError Text
resolveAdsAssistFinalReply _ (Right reply) =
  case nonEmptyText reply of
    Just cleanReply -> Right cleanReply
    Nothing ->
      Left err502 { errBody = "Ads assist model returned an empty reply" }
resolveAdsAssistFinalReply cfg (Left err)
  | shouldUseAdsAssistNoAiFallback err =
      Right (adsAssistNoAiFallback cfg)
  | otherwise =
      let safeMessage = fromMaybe "upstream AI error" (sanitizeApiErrorMessage err)
      in Left err502
          { errBody =
              BL.fromStrict $
                TE.encodeUtf8 ("Ads assist upstream error: " <> safeMessage)
          }

shouldUseAdsAssistNoAiFallback :: Text -> Bool
shouldUseAdsAssistNoAiFallback rawError =
  errorMessage == "openai_api_key no configurada"
    || errorMessage == "no pude generar una respuesta automática en este momento."
    || shouldRetryWithFallbackModel 404 rawError
  where
    errorMessage = T.toLower (T.strip rawError)

adsAssistNoAiFallback :: AppConfig -> Text
adsAssistNoAiFallback cfg =
  let courseUrl = resolveConfiguredAppBase cfg <> "/curso/" <> courseSlugFallback cfg
  in T.intercalate " "
       [ "Gracias por escribirnos."
       , "Ahora mismo el asistente automático no está disponible,"
       , "pero te comparto lo principal:"
       , "el Curso de Producción Musical es presencial,"
       , "dura cuatro sábados (16 horas en total), cuesta $150 USD y tiene cupos limitados."
       , "Más info e inscripción aquí:"
       , courseUrl
       ]

adsAdminServer :: AuthedUser -> ServerT AdsAdminAPI AppM
adsAdminServer user =
       adsAssistStaff user
  :<|> adsListInquiries user
  :<|> adsListCampaigns user
  :<|> adsUpsertCampaign user
  :<|> adsGetCampaign user
  :<|> adsUpsertAd user
  :<|> adsListAdsForCampaign user
  :<|> adsListExamples user
  :<|> adsCreateExample user
  :<|> adsListAutomationTemplates user
  :<|> adsListAutomations user
  :<|> adsInstallAutomation user
  :<|> adsEnrollAutomation user
  :<|> adsListAutomationEnrollments user
  :<|> adsPreviewAutomation user
  :<|> adsUpdateAutomationStatus user
  :<|> adsUpdateAutomationEnrollmentStatus user

adsListInquiries :: AuthedUser -> AppM [AdsInquiryDTO]
adsListInquiries user = do
  requireModule user ModuleAdmin
  rows <- runDB $ selectList [Trials.LeadInterestInterestType ==. "ad_inquiry"] [Desc Trials.LeadInterestCreatedAt, LimitTo 200]
  let partyIds = map (Trials.leadInterestPartyId . entityVal) rows
      subjectIds = mapMaybe (Trials.leadInterestSubjectId . entityVal) rows
  parties <- if null partyIds then pure [] else runDB (selectList [M.PartyId <-. partyIds] [])
  subjects <- if null subjectIds then pure [] else runDB (selectList [Trials.SubjectId <-. subjectIds] [])
  let partyMap = Map.fromList [ (entityKey p, entityVal p) | p <- parties ]
      subjectMap = Map.fromList [ (entityKey s, Trials.subjectName (entityVal s)) | s <- subjects ]
  pure
    [ AdsInquiryDTO
        { aidInquiryId = entityKeyInt iid
        , aidCreatedAt = Trials.leadInterestCreatedAt li
        , aidName      = M.partyDisplayName <$> Map.lookup (Trials.leadInterestPartyId li) partyMap
        , aidEmail     = M.partyPrimaryEmail =<< Map.lookup (Trials.leadInterestPartyId li) partyMap
        , aidPhone     = M.partyPrimaryPhone =<< Map.lookup (Trials.leadInterestPartyId li) partyMap
        , aidCourse    = (Trials.leadInterestSubjectId li >>= (`Map.lookup` subjectMap)) <|> Trials.leadInterestDetails li
        , aidMessage   = Trials.leadInterestDetails li
        , aidChannel   = Just (Trials.leadInterestSource li)
        , aidStatus    = Trials.leadInterestStatus li
        }
    | Entity iid li <- rows
    ]

adsListCampaigns :: AuthedUser -> AppM [CampaignDTO]
adsListCampaigns user = do
  requireModule user ModuleAdmin
  rows <- runDB $ selectList [] [Desc ME.CampaignUpdatedAt, LimitTo 200]
  pure (map campaignToDTO rows)

adsGetCampaign :: AuthedUser -> Int64 -> AppM CampaignDTO
adsGetCampaign user cid = do
  requireModule user ModuleAdmin
  campaignId <- either throwError pure (validatePositiveIdField "campaignId" cid)
  let key = toSqlKey campaignId :: ME.CampaignId
  mRow <- runDB $ get key
  case mRow of
    Nothing -> throwError err404
    Just row -> pure (campaignToDTO (Entity key row))

adsUpsertCampaign :: AuthedUser -> CampaignUpsert -> AppM CampaignDTO
adsUpsertCampaign user CampaignUpsert{..} = do
  requireModule user ModuleAdmin
  budgetCentsVal <- either throwError pure (validateCampaignBudgetCents cuBudgetCents)
  either throwError pure (validateCampaignDateRange cuStartDate cuEndDate)
  campaignIdUpdate <- either throwError pure (validateOptionalPositiveIdField "campaignId" cuId)
  statusVal <- either throwError pure (validateCampaignStatus cuStatus)
  nameClean <- either throwError pure (validateAdsAdminName "campaign name" cuName)
  now <- liftIO getCurrentTime
  cid <- case campaignIdUpdate of
    Nothing -> runDB $ insert ME.Campaign
      { ME.campaignName = nameClean
      , ME.campaignObjective = T.strip <$> cuObjective
      , ME.campaignPlatform = T.strip <$> cuPlatform
      , ME.campaignStatus = statusVal
      , ME.campaignBudgetCents = budgetCentsVal
      , ME.campaignStartDate = cuStartDate
      , ME.campaignEndDate = cuEndDate
      , ME.campaignCreatedAt = now
      , ME.campaignUpdatedAt = now
      }
    Just campaignId -> do
      let key = toSqlKey campaignId :: ME.CampaignId
      mCampaign <- runDB $ get key
      when (isNothing mCampaign) $ throwError err404
      runDB $ update key
        [ ME.CampaignName =. nameClean
        , ME.CampaignObjective =. (T.strip <$> cuObjective)
        , ME.CampaignPlatform =. (T.strip <$> cuPlatform)
        , ME.CampaignStatus =. statusVal
        , ME.CampaignBudgetCents =. budgetCentsVal
        , ME.CampaignStartDate =. cuStartDate
        , ME.CampaignEndDate =. cuEndDate
        , ME.CampaignUpdatedAt =. now
        ]
      pure key
  row <- runDB $ getJust cid
  pure (campaignToDTO (Entity cid row))

adsUpsertAd :: AuthedUser -> AdCreativeUpsert -> AppM AdCreativeDTO
adsUpsertAd user AdCreativeUpsert{..} = do
  requireModule user ModuleAdmin
  landingUrlVal <- either throwError pure (validateAdCreativeLandingUrl acuLandingUrl)
  externalIdVal <- either throwError pure (validateAdCreativeExternalId acuExternalId)
  adIdUpdate <- either throwError pure (validateOptionalPositiveIdField "adId" acuId)
  campaignIdRef <- either throwError pure (validateOptionalPositiveIdField "campaignId" acuCampaignId)
  statusVal <- either throwError pure (validateAdCreativeStatus acuStatus)
  nameClean <- either throwError pure (validateAdsAdminName "ad name" acuName)
  let mCampaign = fmap toSqlKey campaignIdRef :: Maybe ME.CampaignId
  case mCampaign of
    Nothing -> pure ()
    Just key -> do
      mExisting <- runDB $ get key
      when (isNothing mExisting) $ throwError err404 { errBody = "Campaign not found" }
  now <- liftIO getCurrentTime
  adId <- case adIdUpdate of
    Nothing -> runDB $ insert ME.AdCreative
      { ME.adCreativeCampaignId = mCampaign
      , ME.adCreativeExternalId = externalIdVal
      , ME.adCreativeName = nameClean
      , ME.adCreativeChannel = T.strip <$> acuChannel
      , ME.adCreativeAudience = T.strip <$> acuAudience
      , ME.adCreativeLandingUrl = landingUrlVal
      , ME.adCreativeCta = T.strip <$> acuCta
      , ME.adCreativeStatus = statusVal
      , ME.adCreativeNotes = T.strip <$> acuNotes
      , ME.adCreativeCreatedAt = now
      , ME.adCreativeUpdatedAt = now
      }
    Just adIdRaw -> do
      let key = toSqlKey adIdRaw :: ME.AdCreativeId
      mAd <- runDB $ get key
      when (isNothing mAd) $ throwError err404
      runDB $ update key
        [ ME.AdCreativeCampaignId =. mCampaign
        , ME.AdCreativeExternalId =. externalIdVal
        , ME.AdCreativeName =. nameClean
        , ME.AdCreativeChannel =. (T.strip <$> acuChannel)
        , ME.AdCreativeAudience =. (T.strip <$> acuAudience)
        , ME.AdCreativeLandingUrl =. landingUrlVal
        , ME.AdCreativeCta =. (T.strip <$> acuCta)
        , ME.AdCreativeStatus =. statusVal
        , ME.AdCreativeNotes =. (T.strip <$> acuNotes)
        , ME.AdCreativeUpdatedAt =. now
        ]
      pure key
  row <- runDB $ getJust adId
  pure (adToDTO (Entity adId row))

adsListAdsForCampaign :: AuthedUser -> Int64 -> AppM [AdCreativeDTO]
adsListAdsForCampaign user cid = do
  requireModule user ModuleAdmin
  campaignId <- either throwError pure (validatePositiveIdField "campaignId" cid)
  let key = toSqlKey campaignId :: ME.CampaignId
  rows <- runDB $ selectList [ME.AdCreativeCampaignId ==. Just key] [Desc ME.AdCreativeUpdatedAt, LimitTo 200]
  pure (map adToDTO rows)

adsListExamples :: AuthedUser -> Int64 -> AppM [AdConversationExampleDTO]
adsListExamples user adId = do
  requireModule user ModuleAdmin
  adIdValid <- either throwError pure (validatePositiveIdField "adId" adId)
  let key = toSqlKey adIdValid :: ME.AdCreativeId
  rows <- runDB $ selectList [ME.AdConversationExampleAdId ==. key] [Desc ME.AdConversationExampleUpdatedAt, LimitTo 200]
  pure (map adExampleToDTO rows)

adsCreateExample :: AuthedUser -> Int64 -> AdConversationExampleCreate -> AppM AdConversationExampleDTO
adsCreateExample user adId AdConversationExampleCreate{..} = do
  requireModule user ModuleAdmin
  adIdValid <- either throwError pure (validatePositiveIdField "adId" adId)
  let userMsg = T.strip aecUserMessage
      assistantMsg = T.strip aecAssistantMessage
      key = toSqlKey adIdValid :: ME.AdCreativeId
  when (T.null userMsg) $ throwBadRequest "Ejemplo sin pregunta"
  when (T.null assistantMsg) $ throwBadRequest "Ejemplo sin respuesta"
  mAd <- runDB $ get key
  when (isNothing mAd) $ throwError err404
  now <- liftIO getCurrentTime
  exId <- runDB $ insert ME.AdConversationExample
    { ME.adConversationExampleAdId = key
    , ME.adConversationExampleUserMessage = userMsg
    , ME.adConversationExampleAssistantMessage = assistantMsg
    , ME.adConversationExampleTags = aecTags
    , ME.adConversationExampleCreatedAt = now
    , ME.adConversationExampleUpdatedAt = now
    }
  row <- runDB $ getJust exId
  pure (adExampleToDTO (Entity exId row))

adsListAutomationTemplates
  :: AuthedUser
  -> AppM [CampaignAutomationTemplateDTO]
adsListAutomationTemplates user = do
  requireModule user ModuleAdmin
  pure CampaignAutomation.campaignAutomationTemplatesDTO

adsListAutomations
  :: AuthedUser
  -> AppM [CampaignAutomationDTO]
adsListAutomations user = do
  requireModule user ModuleAdmin
  runDB CampaignAutomation.listCampaignAutomations

adsInstallAutomation
  :: AuthedUser
  -> CampaignAutomationInstall
  -> AppM CampaignAutomationDTO
adsInstallAutomation user request = do
  requireModule user ModuleAdmin
  now <- liftIO getCurrentTime
  result <- runDB (CampaignAutomation.installCampaignAutomation now request)
  either throwBadRequest pure result

adsEnrollAutomation
  :: AuthedUser
  -> Int64
  -> CampaignAutomationEnroll
  -> AppM CampaignAutomationEnrollResultDTO
adsEnrollAutomation user rawAutomationId request = do
  requireModule user ModuleAdmin
  automationId <-
    either throwError pure
      (validatePositiveIdField "automationId" rawAutomationId)
  now <- liftIO getCurrentTime
  result <-
    runDB
      (CampaignAutomation.enrollCampaignParties now automationId request)
  either throwBadRequest pure result

adsListAutomationEnrollments
  :: AuthedUser
  -> Int64
  -> AppM [CampaignEnrollmentDTO]
adsListAutomationEnrollments user rawAutomationId = do
  requireModule user ModuleAdmin
  automationId <-
    either throwError pure
      (validatePositiveIdField "automationId" rawAutomationId)
  result <-
    runDB (CampaignAutomation.listCampaignEnrollments automationId)
  either throwBadRequest pure result

adsPreviewAutomation
  :: AuthedUser
  -> Int64
  -> AppM [CampaignPreviewDTO]
adsPreviewAutomation user rawAutomationId = do
  requireModule user ModuleAdmin
  automationId <-
    either throwError pure
      (validatePositiveIdField "automationId" rawAutomationId)
  Env{envConfig} <- ask
  result <-
    runDB
      (CampaignAutomation.previewCampaignAutomation envConfig automationId)
  either throwBadRequest pure result

adsUpdateAutomationStatus
  :: AuthedUser
  -> Int64
  -> CampaignAutomationStatusUpdate
  -> AppM CampaignAutomationDTO
adsUpdateAutomationStatus user rawAutomationId request = do
  requireModule user ModuleAdmin
  automationId <-
    either throwError pure
      (validatePositiveIdField "automationId" rawAutomationId)
  now <- liftIO getCurrentTime
  result <-
    runDB
      (CampaignAutomation.updateCampaignAutomationStatus now automationId request)
  either throwBadRequest pure result

adsUpdateAutomationEnrollmentStatus
  :: AuthedUser
  -> Int64
  -> Int64
  -> CampaignEnrollmentStatusUpdate
  -> AppM CampaignEnrollmentDTO
adsUpdateAutomationEnrollmentStatus
  user
  rawAutomationId
  rawEnrollmentId
  request = do
    requireModule user ModuleAdmin
    automationId <-
      either throwError pure
        (validatePositiveIdField "automationId" rawAutomationId)
    enrollmentId <-
      either throwError pure
        (validatePositiveIdField "enrollmentId" rawEnrollmentId)
    now <- liftIO getCurrentTime
    result <-
      runDB
        ( CampaignAutomation.updateCampaignEnrollmentStatus
            now
            automationId
            enrollmentId
            request
        )
    either throwBadRequest pure result

loadAdExamples :: Bool -> [ME.AdCreativeId] -> SqlPersistT IO [Entity ME.AdConversationExample]
loadAdExamples hasScope adIds
  | hasScope && null adIds = pure []
  | null adIds = selectList [] [Desc ME.AdConversationExampleUpdatedAt, LimitTo 6]
  | otherwise = selectList [ME.AdConversationExampleAdId <-. adIds] [Desc ME.AdConversationExampleUpdatedAt, LimitTo 6]

resolveAdsAssistExampleScope
  :: Maybe ME.AdCreativeId
  -> Maybe ME.CampaignId
  -> [ME.AdCreativeId]
  -> Either ServerError [ME.AdCreativeId]
resolveAdsAssistExampleScope Nothing Nothing _ =
  Right []
resolveAdsAssistExampleScope (Just adKey) Nothing _ =
  Right [adKey]
resolveAdsAssistExampleScope Nothing (Just _) campaignAdKeys =
  Right (nub campaignAdKeys)
resolveAdsAssistExampleScope (Just adKey) (Just _) campaignAdKeys
  | adKey `elem` campaignAdKeys =
      Right (adKey : filter (/= adKey) (nub campaignAdKeys))
  | otherwise =
      Left err400 { errBody = "adId must belong to campaignId" }

adExampleToDTO :: Entity ME.AdConversationExample -> AdConversationExampleDTO
adExampleToDTO (Entity eid ex) =
  AdConversationExampleDTO
    { aceId = fromSqlKey eid
    , aceAdId = fromSqlKey (ME.adConversationExampleAdId ex)
    , aceUserMessage = ME.adConversationExampleUserMessage ex
    , aceAssistantMessage = ME.adConversationExampleAssistantMessage ex
    , aceTags = ME.adConversationExampleTags ex
    }

campaignToDTO :: Entity ME.Campaign -> CampaignDTO
campaignToDTO (Entity cid c) =
  CampaignDTO
    { campId = fromSqlKey cid
    , campName = ME.campaignName c
    , campObjective = ME.campaignObjective c
    , campPlatform = ME.campaignPlatform c
    , campStatus = ME.campaignStatus c
    , campBudgetCents = ME.campaignBudgetCents c
    , campStartDate = ME.campaignStartDate c
    , campEndDate = ME.campaignEndDate c
    }

adToDTO :: Entity ME.AdCreative -> AdCreativeDTO
adToDTO (Entity aid a) =
  AdCreativeDTO
    { adId = fromSqlKey aid
    , adCampaignId = fmap fromSqlKey (ME.adCreativeCampaignId a)
    , adExternalId = ME.adCreativeExternalId a
    , adName = ME.adCreativeName a
    , adChannel = ME.adCreativeChannel a
    , adAudience = ME.adCreativeAudience a
    , adLandingUrl = ME.adCreativeLandingUrl a
    , adCta = ME.adCreativeCta a
    , adStatus = ME.adCreativeStatus a
    , adNotes = ME.adCreativeNotes a
    }

data OpenAIChatMessage = OpenAIChatMessage
  { role :: Text
  , content :: Text
  } deriving (Show, Generic)

instance ToJSON OpenAIChatMessage where
  toJSON = genericToJSON defaultOptions { fieldLabelModifier = camelTo2 '_' }
instance FromJSON OpenAIChatMessage where
  parseJSON = genericParseJSON defaultOptions { fieldLabelModifier = camelTo2 '_' }

data ChatCompletionReq = ChatCompletionReq
  { model :: Text
  , messages :: [OpenAIChatMessage]
  , temperature :: Maybe Double
  } deriving (Show, Generic)

instance ToJSON ChatCompletionReq where
  toJSON = genericToJSON defaultOptions { fieldLabelModifier = camelTo2 '_' }

data ChatChoice = ChatChoice
  { message :: OpenAIChatMessage
  } deriving (Show, Generic)
instance FromJSON ChatChoice where
  parseJSON = genericParseJSON defaultOptions { fieldLabelModifier = camelTo2 '_' }

data ChatCompletionResp = ChatCompletionResp
  { choices :: [ChatChoice]
  } deriving (Show, Generic)
instance FromJSON ChatCompletionResp where
  parseJSON = genericParseJSON defaultOptions { fieldLabelModifier = camelTo2 '_' }

runRagChat :: AppConfig -> [Text] -> [Entity ME.AdConversationExample] -> Text -> Maybe Text -> IO Text
runRagChat cfg kb examples userMsg mChannel = do
  res <- runRagChatWithStatus cfg kb examples userMsg mChannel
  pure $
    case res of
      Right txt | not (T.null (T.strip txt)) -> T.strip txt
      _ -> "No pude generar una respuesta automática en este momento."

runRagChatWithStatus
  :: AppConfig
  -> [Text]
  -> [Entity ME.AdConversationExample]
  -> Text
  -> Maybe Text
  -> IO (Either Text Text)
runRagChatWithStatus cfg kb examples userMsg mChannel =
  callOpenAIChat cfg (buildRagMessages kb examples userMsg mChannel)

buildRagMessages
  :: [Text]
  -> [Entity ME.AdConversationExample]
  -> Text
  -> Maybe Text
  -> [OpenAIChatMessage]
buildRagMessages kb examples userMsg mChannel =
  let contextBlock = if null kb then "No hay contexto" else T.intercalate "\n\n" kb
      exampleMsgs = concatMap exampleToMessages examples
      channelNote = maybe "" (\ch -> "[Canal: " <> T.strip ch <> "] ") mChannel
      systemIntro = T.intercalate "\n"
        [ "Eres un asistente de marketing de TDF Records."
        , "Responde en el idioma del usuario con un tono cálido y conciso."
        , "Tu objetivo es ayudar al usuario y, cuando sea relevante, promocionar el Curso de Producción Musical (presencial, cuatro sábados, 16 horas en total, $150 USD, cupos limitados) con link: https://www.tdfrecords.net/curso/produccion-musical-jun-2026"
        , "REGLA CRÍTICA DE FORMATO: responde SOLO con una de estas dos formas:"
        , "1) SEND: <tu respuesta final para enviar al usuario>"
        , "2) HOLD: <por qué no puedes responder todavía>\\nNEED: <lista corta de datos que faltan>"
        , "No incluyas nada fuera de ese formato."
        ]
  in [ mkMsg "system" systemIntro
     , mkMsg "system" ("Contexto de negocio:\n" <> contextBlock)
     ] ++ exampleMsgs ++ [mkMsg "user" (channelNote <> userMsg)]
  where
    mkMsg r c = OpenAIChatMessage { role = r, content = c }
    exampleToMessages (Entity _ ex) =
      [ mkMsg "user" (ME.adConversationExampleUserMessage ex)
      , mkMsg "assistant" (ME.adConversationExampleAssistantMessage ex)
      ]

callOpenAIChat :: AppConfig -> [OpenAIChatMessage] -> IO (Either Text Text)
callOpenAIChat cfg messages =
  case openAiApiKey cfg of
    Nothing -> pure (Left "OPENAI_API_KEY no configurada")
    Just key -> do
      manager <- pure sharedTlsManager
      let apiBase = normalizeLlmApiBase (chatKitApiBase cfg)
      reqBase <- parseRequest (T.unpack (apiBase <> "/v1/chat/completions"))
      let models = llmChatModelCandidates (openAiModel cfg)
      tryModels manager reqBase key models Nothing
  where
    tryModels :: Manager -> Request -> Text -> [Text] -> Maybe Text -> IO (Either Text Text)
    tryModels _ _ _ [] lastErr =
      pure (Left (fromMaybe "No pude generar una respuesta automática en este momento." lastErr))
    tryModels manager reqBase key (modelName:remaining) _ = do
      attempt <- requestOpenAIChat manager reqBase key modelName messages
      case attempt of
        Right reply -> pure (Right reply)
        Left (status, msg)
          | shouldRetryWithFallbackModel status msg && not (null remaining) -> do
              hPutStrLn stderr
                ("[openai] Modelo " <> T.unpack modelName <> " no disponible (" <> show status <> "). Intentando fallback.")
              tryModels manager reqBase key remaining (Just msg)
          | otherwise ->
              pure (Left msg)

requestOpenAIChat
  :: Manager
  -> Request
  -> Text
  -> Text
  -> [OpenAIChatMessage]
  -> IO (Either (Int, Text) Text)
requestOpenAIChat manager reqBase key modelName messages = do
  let body = encode ChatCompletionReq
        { model = modelName
        , messages = messages
        , temperature = Just 1.0
        }
      req =
        reqBase
          { method = "POST"
          , requestHeaders =
              [ ("Content-Type", "application/json")
              , ("Authorization", "Bearer " <> TE.encodeUtf8 key)
              ]
          , requestBody = RequestBodyLBS body
          }
  respResult <- try (httpLbs req manager) :: IO (Either SomeException (Response BL.ByteString))
  case respResult of
    Left err ->
      pure (Left (0, openAIChatRequestErrorMessage err))
    Right resp -> do
      let status = statusCode (responseStatus resp)
          raw = responseBody resp
      if status >= 200 && status < 300
        then case (eitherDecode raw :: Either String Value) of
          Left err ->
            pure (Left (status, T.pack err))
          Right payload ->
            case extractModelReplyText payload of
              Just reply -> pure (Right reply)
              Nothing ->
                pure (Left (status, fromMaybe "Sin respuesta de modelo" (extractApiErrorMessage payload)))
        else do
          let baseMsg = "Error al generar respuesta (HTTP " <> T.pack (show status) <> ")"
              msg = case (eitherDecode raw :: Either String Value) of
                Right payload -> fromMaybe baseMsg (extractApiErrorMessage payload)
                Left _ -> baseMsg
          pure (Left (status, msg))

openAIChatRequestErrorMessage :: SomeException -> Text
openAIChatRequestErrorMessage err =
  fromMaybe "OpenAI chat request failed" $
    sanitizeApiErrorMessage ("OpenAI chat request failed: " <> T.pack (displayException err))

shouldRetryWithFallbackModel :: Int -> Text -> Bool
shouldRetryWithFallbackModel status rawMessage =
  statusAllowsFallback && hasMarker && not hasNonFallbackMarker
  where
    msg = T.toLower (T.strip rawMessage)
    statusAllowsFallback = status == 400 || status == 403 || status == 404
    hasMarker = any (`T.isInfixOf` msg) markers || hasMissingModelMarker
    hasNonFallbackMarker = any (`T.isInfixOf` msg) nonFallbackMarkers
    hasMissingModelMarker =
      "does not exist" `T.isInfixOf` msg
        && any (`T.isInfixOf` msg)
          [ "the requested model "
          , "requested model "
          , "the model `"
          , "the model '"
          , "the model \""
          ]
    markers =
      [ "does not have access to model"
      , "doesn't have access to model"
      , "do not have access to model"
      , "don't have access to model"
      , "no access to model"
      , "does not exist or you do not have access"
      , "model not found"
      , "unknown model"
      , "invalid model id"
      , "invalid model name"
      , "not a valid model"
      , "model_not_found"
      , "temperature is not supported"
      , "invalid temperature"
      ]
    nonFallbackMarkers =
      [ "rate limit"
      , "too many requests"
      , "quota"
      , "connection"
      , "connecting"
      , "network"
      , "timeout"
      , "timed out"
      , "dns"
      , "tls"
      , "certificate"
      , "model response"
      , "response format"
      , "authentication_error"
      , "invalid_api_key"
      , "invalid api key"
      , "incorrect api key"
      , "unauthorized"
      , "unauthorised"
      , "permission_denied"
      , "permission denied"
      , "forbidden"
      , "billing"
      , "billing_hard_limit"
      , "billing issue"
      , "payment_required"
      , "payment required"
      , "payment method"
      ]

tidalSystemPrompt :: Text
tidalSystemPrompt = T.intercalate "\n"
  [ "You are a TidalCycles code generator."
  , "- Reply ONLY with TidalCycles code, no prose or markdown."
  , "- Keep patterns short, loopable, and safe to evaluate."
  , "- Use d1/d2/d3/d4, stack, sound, n, note, cps/bps, hush. Avoid file I/O or shell commands."
  , "- Prefer concise percussive or melodic patterns; avoid very long sequences."
  ]

tidalAgentServer :: AuthedUser -> TidalAgentRequest -> AppM TidalAgentResponse
tidalAgentServer user TidalAgentRequest{..} = do
  unless (hasAiToolingAccess user) $
    throwError err403 { errBody = "Missing required module access" }
  Env{..} <- ask
  let prompt = T.strip taPrompt
  when (T.null prompt) $ throwBadRequest "Prompt requerido"
  when (T.length prompt > maxTidalAgentPromptChars) $
    throwBadRequest "Prompt demasiado largo (max 2000 caracteres)"
  when (T.any isUnsupportedTidalAgentPromptChar prompt) $
    throwBadRequest "Prompt contiene caracteres de control o formato no soportados"
  apiKey <- case openAiApiKey envConfig of
    Nothing -> throwError err503 { errBody = "OPENAI_API_KEY no configurada" }
    Just key -> pure key
  let model = fromMaybe (openAiModel envConfig) (taModel >>= nonEmptyText)
      apiBase = normalizeLlmApiBase (chatKitApiBase envConfig)
  manager <- pure sharedTlsManager
  reqBase <- liftIO $ parseRequest (T.unpack (apiBase <> "/v1/chat/completions"))
  let body = encode $ object
        [ "model" .= model
        , "messages" .=
            [ object ["role" .= ("system" :: Text), "content" .= tidalSystemPrompt]
            , object ["role" .= ("user" :: Text), "content" .= prompt]
            ]
        , "max_tokens" .= (300 :: Int)
        ]
      req =
        reqBase
          { method = "POST"
          , requestHeaders =
              [ ("Content-Type", "application/json")
              , ("Authorization", "Bearer " <> TE.encodeUtf8 apiKey)
              ]
          , requestBody = RequestBodyLBS body
          }
  resp <- liftIO $ httpLbs req manager
  let status = statusCode (responseStatus resp)
      raw = responseBody resp
  if status >= 200 && status < 300
    then case (eitherDecode raw :: Either String Value) of
      Left err ->
        throwError err502 { errBody = BL.fromStrict (TE.encodeUtf8 (T.pack err)) }
      Right payload ->
        case extractModelReplyText payload of
          Just reply ->
            pure (TidalAgentResponse reply)
          Nothing -> do
            let msg = fromMaybe "Sin respuesta de modelo" (extractApiErrorMessage payload)
            throwError err502 { errBody = BL.fromStrict (TE.encodeUtf8 msg) }
    else do
      let baseMsg = "Error al generar respuesta (HTTP " <> T.pack (show status) <> ")"
          msg = case (eitherDecode raw :: Either String Value) of
            Right payload -> fromMaybe baseMsg (extractApiErrorMessage payload)
            Left _ -> baseMsg
      throwError err502 { errBody = BL.fromStrict (TE.encodeUtf8 msg) }

chatkitSessionServer :: AuthedUser -> ChatKitSessionRequest -> AppM ChatKitSessionResponse
chatkitSessionServer user ChatKitSessionRequest{..} = do
  unless (hasAiToolingAccess user) $
    throwError err403 { errBody = "Missing required module access" }
  Env{..} <- ask
  let cfg = envConfig
  workflowId <- either throwError pure (resolveWorkflowId cksWorkflowId (chatKitWorkflowId cfg))
  apiKey <- case openAiApiKey cfg of
    Nothing -> throwError err503 { errBody = "OPENAI_API_KEY no configurada" }
    Just key -> pure key
  let userId = T.pack (show (fromSqlKey (auPartyId user)))
      apiBase = normalizeLlmApiBase (chatKitApiBase cfg)
  manager <- pure sharedTlsManager
  reqBase <- liftIO $ parseRequest (T.unpack (apiBase <> "/v1/chatkit/sessions"))
  let body = encode $ object
        [ "workflow" .= object ["id" .= workflowId]
        , "user" .= userId
        ]
      req =
        reqBase
          { method = "POST"
          , requestHeaders =
              [ ("Content-Type", "application/json")
              , ("Authorization", "Bearer " <> TE.encodeUtf8 apiKey)
              , ("OpenAI-Beta", "chatkit_beta=v1")
              ]
          , requestBody = RequestBodyLBS body
          }
  resp <- liftIO $ httpLbs req manager
  let status = statusCode (responseStatus resp)
      raw = responseBody resp
  if status >= 200 && status < 300
    then case (eitherDecode raw :: Either String Value) of
      Left err ->
        throwError err502 { errBody = BL.fromStrict (TE.encodeUtf8 (T.pack err)) }
      Right payload ->
        case validateChatKitSessionPayload payload of
          Right (secret, expiresAfter) ->
            pure ChatKitSessionResponse
              { ckrClientSecret = secret
              , ckrExpiresAfter = expiresAfter
              }
          Left msg ->
            throwError err502 { errBody = BL.fromStrict (TE.encodeUtf8 msg) }
    else do
      let msg = chatKitSessionErrorMessage status raw
      throwError err502 { errBody = BL.fromStrict (TE.encodeUtf8 msg) }

chatKitSessionErrorMessage :: Int -> BL.ByteString -> Text
chatKitSessionErrorMessage status raw =
  case (eitherDecode raw :: Either String Value) of
    Right payload -> fromMaybe baseMsg (extractApiErrorMessage payload)
    Left _ -> baseMsg
  where
    baseMsg = "Error al crear sesión ChatKit (HTTP " <> T.pack (show status) <> ")"

resolveWorkflowId :: Maybe Text -> Maybe Text -> Either ServerError Text
resolveWorkflowId primary fallback =
  case primary of
    Just rawWorkflowId ->
      toServerError err400 (normalizeChatKitWorkflowId "workflowId" rawWorkflowId)
    Nothing ->
      case fallback of
        Just rawWorkflowId ->
          toServerError err500 (normalizeChatKitWorkflowId "CHATKIT_WORKFLOW_ID" rawWorkflowId)
        Nothing ->
          Left err400 { errBody = "workflowId requerido" }
  where
    toServerError status result =
      case result of
        Right workflowId -> Right workflowId
        Left msg ->
          Left status { errBody = BL.fromStrict (TE.encodeUtf8 msg) }

nonEmptyText :: Text -> Maybe Text
nonEmptyText txt =
  let trimmed = T.strip txt
  in if T.null trimmed then Nothing else Just trimmed

extractChatKitSession :: Value -> Maybe (Text, Maybe Value)
extractChatKitSession =
  either (const Nothing) Just . validateChatKitSessionPayload

validateChatKitSessionPayload :: Value -> Either Text (Text, Maybe Value)
validateChatKitSessionPayload payload =
  case parseEither parsePayload payload of
    Left err -> Left (T.pack err)
    Right session -> Right session
  where
    parsePayload = withObject "ChatKitSession" $ \o -> do
      rawSecret <- o .:? "client_secret"
      secret <-
        maybe
          (fail "ChatKit response client_secret is required or malformed")
          pure
          (rawSecret >>= validateChatKitClientSecret)
      expiresAfter <- o .:? "expires_after"
      validatedExpiresAfter <- traverse validateExpiresAfter expiresAfter
      pure (secret, validatedExpiresAfter)

    validateExpiresAfter value =
      case value of
        Object expiresAfter -> do
          rejectUnexpectedObjectFields
            "ChatKit response expires_after"
            ["anchor", "seconds"]
            expiresAfter
          rejectNullChatKitExpiryField "anchor" expiresAfter
          rejectNullChatKitExpiryField "seconds" expiresAfter
          mAnchor <- expiresAfter .:? "anchor"
          mSeconds <- expiresAfter .:? "seconds"
          when (isNothing mAnchor && isNothing mSeconds) $
            fail "ChatKit response expires_after must include anchor or seconds"
          for_ mAnchor validateChatKitExpiryAnchor
          for_ mSeconds validateChatKitExpirySeconds
          pure value
        _ -> fail "ChatKit response expires_after must be an object"

validateChatKitClientSecret :: Text -> Maybe Text
validateChatKitClientSecret rawSecret = do
  secret <- nonEmptyText rawSecret
  if T.length secret <= maxChatKitClientSecretChars
      && not (T.any invalidChatKitClientSecretChar secret)
    then Just secret
    else Nothing

maxChatKitClientSecretChars :: Int
maxChatKitClientSecretChars = 4096

invalidChatKitClientSecretChar :: Char -> Bool
invalidChatKitClientSecretChar ch =
  isSpace ch
    || isControl ch
    || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

validateChatKitExpiryAnchor :: Text -> Parser ()
validateChatKitExpiryAnchor rawAnchor = do
  let anchor = T.strip rawAnchor
  when (T.null anchor) $
    fail "ChatKit response expires_after.anchor is required when present"
  when (rawAnchor /= anchor) $
    fail "ChatKit response expires_after.anchor must not include surrounding whitespace"
  when (T.length anchor > maxChatKitExpiryAnchorChars) $
    fail "ChatKit response expires_after.anchor must be 64 characters or fewer"
  when (T.any (not . isChatKitExpiryAnchorChar) anchor) $
    fail "ChatKit response expires_after.anchor must use only ASCII letters, digits, '_' or '-'"

maxChatKitExpiryAnchorChars :: Int
maxChatKitExpiryAnchorChars = 64

isChatKitExpiryAnchorChar :: Char -> Bool
isChatKitExpiryAnchorChar ch =
  ch <= '\x7f' && (isAlphaNum ch || ch `elem` ("_-" :: String))

rejectNullChatKitExpiryField :: Text -> Object -> Parser ()
rejectNullChatKitExpiryField fieldName expiresAfter =
  case AKeyMap.lookup (AKey.fromText fieldName) expiresAfter of
    Just Null ->
      fail $
        T.unpack $
          "ChatKit response expires_after."
            <> fieldName
            <> " must be omitted instead of null"
    _ -> pure ()

validateChatKitExpirySeconds :: Int -> Parser ()
validateChatKitExpirySeconds secondsValue =
  when (secondsValue <= 0) $
    fail "ChatKit response expires_after.seconds must be positive"

extractApiErrorMessage :: Value -> Maybe Text
extractApiErrorMessage = parseMaybe $ withObject "ApiError" $ \o -> do
  mErr <- o .:? "error"
  candidates <- case mErr of
    Just (String msg) ->
      pure [msg]
    Just (Object errObj) -> do
      let mType = lookupText "type" errObj
          mCode = lookupText "code" errObj
          mStatus = lookupText "status" errObj
          mMessage = lookupText "message" errObj
      pure (catMaybes [mType, mCode, mStatus, mMessage])
    _ -> do
      let mType = lookupText "type" o
          mCode = lookupText "code" o
          mStatus = lookupText "status" o
          mMessage = lookupText "message" o
      pure (catMaybes [mType, mCode, mStatus, mMessage])
  requireSanitizedText candidates
  where
    lookupText fieldName obj =
      case AKeyMap.lookup (AKey.fromText fieldName) obj of
        Just (String txt) -> Just txt
        _ -> Nothing

    requireSanitizedText values =
      case nonEmptyText (T.intercalate ": " (map T.strip values)) of
        Just txt ->
          maybe (fail "message missing") pure (sanitizeApiErrorMessage txt)
        Nothing -> fail "message missing"

maxApiErrorMessageChars :: Int
maxApiErrorMessageChars = 500

sanitizeApiErrorMessage :: Text -> Maybe Text
sanitizeApiErrorMessage raw =
  nonEmptyText $
    if T.length redacted > maxApiErrorMessageChars
      then T.take maxApiErrorMessageChars redacted <> " [truncated]"
      else redacted
  where
    redacted =
      redactApiErrorSecrets $
        T.unwords $
          T.words $
            T.map normalizeErrorChar raw
    normalizeErrorChar ch
      | isControl ch = ' '
      | generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator] = ' '
      | otherwise = ch

redactApiErrorSecrets :: Text -> Text
redactApiErrorSecrets =
  redactSensitiveApiErrorFields . redactBearerTokens

redactBearerTokens :: Text -> Text
redactBearerTokens = go Nothing
  where
    go _ textValue
      | T.null textValue = ""
    go previous textValue =
      case matchBearerToken previous textValue of
        Just (prefix, rest) ->
          prefix <> "[redacted]" <> go Nothing rest
        Nothing ->
          let ch = T.head textValue
          in T.singleton ch <> go (Just ch) (T.tail textValue)

matchBearerToken :: Maybe Char -> Text -> Maybe (Text, Text)
matchBearerToken previous textValue
  | not (isApiErrorSecretBoundary previous) = Nothing
  | not ("bearer" `T.isPrefixOf` T.toLower textValue) = Nothing
  | otherwise =
      let bearerText = T.take 6 textValue
          afterBearer = T.drop 6 textValue
          (between, tokenStart) = T.span isSpace afterBearer
          (openingQuote, tokenText, isValueEnd) = consumeApiErrorValueOpeningQuote tokenStart
          (tokenValue, rest) = T.break isValueEnd tokenText
      in if T.null between || T.null tokenValue || not (T.any isApiErrorSecretAtom tokenValue)
           then Nothing
           else Just (bearerText <> between <> openingQuote, rest)

redactSensitiveApiErrorFields :: Text -> Text
redactSensitiveApiErrorFields = go Nothing
  where
    go _ textValue
      | T.null textValue = ""
    go previous textValue =
      case matchSensitiveApiErrorField previous textValue of
        Just (prefix, rest) ->
          prefix <> "[redacted]" <> go Nothing rest
        Nothing ->
          let ch = T.head textValue
          in T.singleton ch <> go (Just ch) (T.tail textValue)

matchSensitiveApiErrorField :: Maybe Char -> Text -> Maybe (Text, Text)
matchSensitiveApiErrorField previous textValue
  | not (isApiErrorSecretBoundary previous) = Nothing
  | otherwise = firstMatch sensitiveApiErrorFields
  where
    lowered = T.toLower textValue

    firstMatch [] = Nothing
    firstMatch (fieldName:rest) =
      case parseSensitiveApiErrorField fieldName lowered textValue of
        Just match -> Just match
        Nothing -> firstMatch rest

sensitiveApiErrorFields :: [Text]
sensitiveApiErrorFields =
  [ "access_token"
  , "accesstoken"
  , "api_key"
  , "api-key"
  , "apikey"
  , "authorization"
  , "bearertoken"
  , "client_secret"
  , "clientsecret"
  , "id_token"
  , "refresh_token"
  , "refreshtoken"
  , "x-api-key"
  ]

parseSensitiveApiErrorField :: Text -> Text -> Text -> Maybe (Text, Text)
parseSensitiveApiErrorField fieldName lowered textValue
  | not (fieldName `T.isPrefixOf` lowered) = Nothing
  | otherwise = do
      let fieldLength = T.length fieldName
          fieldText = T.take fieldLength textValue
          afterField = T.drop fieldLength textValue
          (closingQuote, afterClosingQuote) = consumeApiErrorOptionalQuote afterField
          (beforeSeparator, separatorCandidate) = T.span isSpace afterClosingQuote
      (separator, afterSeparator) <- T.uncons separatorCandidate
      if separator == '=' || separator == ':'
        then
          let (afterSeparatorSpace, valueStart) = T.span isSpace afterSeparator
              (openingQuote, valueText, isValueEnd) = consumeApiErrorValueOpeningQuote valueStart
              (_, rest) = T.break isValueEnd valueText
              prefix =
                fieldText
                  <> closingQuote
                  <> beforeSeparator
                  <> T.singleton separator
                  <> afterSeparatorSpace
                  <> openingQuote
          in Just (prefix, rest)
        else Nothing

isApiErrorSecretBoundary :: Maybe Char -> Bool
isApiErrorSecretBoundary Nothing = True
isApiErrorSecretBoundary (Just ch) =
  not (isAlphaNum ch || ch == '_' || ch == '-')

isApiErrorSecretAtom :: Char -> Bool
isApiErrorSecretAtom ch =
  isAlphaNum ch || ch `elem` (".-_~+/=" :: String)

consumeApiErrorOptionalQuote :: Text -> (Text, Text)
consumeApiErrorOptionalQuote textValue =
  case T.uncons textValue of
    Just ('"', rest) -> ("\"", rest)
    Just ('\'', rest) -> ("'", rest)
    _ -> ("", textValue)

consumeApiErrorValueOpeningQuote :: Text -> (Text, Text, Char -> Bool)
consumeApiErrorValueOpeningQuote textValue =
  case T.uncons textValue of
    Just ('"', rest) -> ("\"", rest, (== '"'))
    Just ('\'', rest) -> ("'", rest, (== '\''))
    _ -> ("", textValue, isUnquotedApiErrorSecretValueEnd)

isUnquotedApiErrorSecretValueEnd :: Char -> Bool
isUnquotedApiErrorSecretValueEnd ch =
  isSpace ch || ch `elem` ("&,;}]" :: String)

extractModelReplyText :: Value -> Maybe Text
extractModelReplyText payload =
  extractChatCompletionText payload
    <|> extractResponsesOutputText payload

extractChatCompletionText :: Value -> Maybe Text
extractChatCompletionText payload = do
  ChatCompletionResp
    { choices = (ChatChoice OpenAIChatMessage{role = replyRole, content = reply} : _)
    } <- parseMaybe parseJSON payload
  if replyRole == "assistant"
    then validateModelReplyText reply
    else Nothing

extractResponsesOutputText :: Value -> Maybe Text
extractResponsesOutputText payload = parseMaybe parsePayload payload
  where
    parsePayload = withObject "ResponsesPayload" $ \o -> do
      mOutputText <- o .:? "output_text"
      case mOutputText >>= validateModelReplyText of
        Just txt -> pure txt
        Nothing -> do
          outputs <- o .:? "output" .!= ([] :: [Value])
          let fragments = concatMap extractOutputFragments outputs
          case validateModelReplyText (T.intercalate "\n" fragments) of
            Just txt -> pure txt
            Nothing -> fail "output text missing"

maxModelReplyTextChars :: Int
maxModelReplyTextChars = 8192

validateModelReplyText :: Text -> Maybe Text
validateModelReplyText rawReply = do
  reply <- nonEmptyText rawReply
  if T.length reply <= maxModelReplyTextChars
      && not (T.any invalidModelReplyChar reply)
    then Just reply
    else Nothing

invalidModelReplyChar :: Char -> Bool
invalidModelReplyChar ch =
  (isControl ch && ch /= '\n' && ch /= '\r' && ch /= '\t')
    || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

extractOutputFragments :: Value -> [Text]
extractOutputFragments value =
  let directText =
        catMaybes
          [ join (parseMaybe (withObject "OutputItemText" (\o -> o .:? "text")) value) >>= nonEmptyText
          , join (parseMaybe (withObject "OutputItemContentText" (\o -> o .:? "content")) value) >>= nonEmptyText
          ]
      contentParts =
        fromMaybe []
          (parseMaybe (withObject "OutputItemContent" (\o -> o .:? "content" .!= ([] :: [Value]))) value)
      partText =
        concatMap
          (\part ->
            catMaybes
              [ join (parseMaybe (withObject "OutputPartText" (\o -> o .:? "text")) part) >>= nonEmptyText
              , join (parseMaybe (withObject "OutputPartContentText" (\o -> o .:? "content")) part) >>= nonEmptyText
              ]
          )
          contentParts
  in directText <> partText

ensurePartyForInquiry :: AdsInquiry -> UTCTime -> SqlPersistT IO (Either ServerError PartyId)
ensurePartyForInquiry AdsInquiry{..} now = fmap Right $ insert M.Party
  { M.partyLegalName = Nothing
  , M.partyDisplayName = fromMaybe "Contacto Ads" (T.strip <$> aiName)
  , M.partyIsOrg = False
  , M.partyTaxId = Nothing
  , M.partyPrimaryEmail = T.strip <$> aiEmail
  , M.partyPrimaryPhone = aiPhone >>= normalizePhone
  , M.partyWhatsapp = Nothing
  , M.partyInstagram = Nothing
  , M.partyEmergencyContact = Nothing
  , M.partyNotes = Nothing
  , M.partyStripeCustomerId = Nothing
  , M.partyCountryCode = Nothing
  , M.partyCountryId = Nothing
  , M.partyCreatedAt = now
  }

resolveSubject :: Maybe Text -> SqlPersistT IO (Maybe (Key Trials.Subject), Maybe Text)
resolveSubject mCourse =
  case fmap (T.toLower . T.strip) mCourse of
    Nothing -> pure (Nothing, Nothing)
    Just raw -> do
      mSubject <- selectFirst [Trials.SubjectName ==. canonicalCourse raw] []
      pure (entityKey <$> mSubject, Just (canonicalCourse raw))
  where
    canonicalCourse txt
      | "dj" `T.isInfixOf` txt = "DJ"
      | "ableton" `T.isInfixOf` txt = "Producción Música Electrónica (Ableton Live)"
      | "logic" `T.isInfixOf` txt || "luna" `T.isInfixOf` txt = "Producción Musical (Logic/Luna)"
      | "bajo" `T.isInfixOf` txt = "Bajo"
      | "guitarra" `T.isInfixOf` txt = "Guitarra"
      | "teclado" `T.isInfixOf` txt || "piano" `T.isInfixOf` txt = "Teclado"
      | "bateria" `T.isInfixOf` txt = "Batería"
      | "sint" `T.isInfixOf` txt = "Síntesis Modular"
      | otherwise = txt

sendAutoReplies :: ConnectionPool -> PartyId -> AppConfig -> AdsInquiry -> Maybe Text -> IO [Text]
sendAutoReplies pool partyId cfg AdsInquiry{..} mCourse = do
  wa <- loadWhatsAppEnv
  now <- getCurrentTime
  let ctaBase = resolveConfiguredAppBase cfg
      cta = ctaBase <> "/trials"
      courseLanding = buildLandingUrl cfg
      courseLabel = fromMaybe "las clases 1:1" mCourse
      body = T.intercalate "\n"
        [ "Hola " <> fromMaybe "" aiName <> " 🙌"
        , "Gracias por tu interés en " <> courseLabel <> "."
        , "Paquete 1:1 (16 horas): $480."
        , "Grupo pequeño: más info y fechas en " <> courseLanding
        , "¿Te agendo una clase de prueba gratis para ver horarios y profesor ideal?"
        , "Confírmame tu disponibilidad y ciudad. Agendamos aquí: " <> cta
        ]
  channels <- fmap catMaybes . sequence $
    [ case aiPhone >>= normalizePhone of
        Just ph -> do
          res <- sendWhatsAppTextIO wa ph body
          _ <- runSqlPool
            (recordOutgoingWhatsAppMessage now OutgoingWhatsAppRecord
              { owrRecipientPhone = ph
              , owrRecipientPartyId = Just partyId
              , owrRecipientName = aiName
              , owrRecipientEmail = aiEmail
              , owrActorPartyId = Nothing
              , owrBody = body
              , owrSource = Just "ads_auto_reply"
              , owrReplyToMessageId = Nothing
              , owrReplyToExternalId = Nothing
              , owrResendOfMessageId = Nothing
              , owrMetadata = Nothing
              }
              res)
            pool
          pure (either (const Nothing) (const (Just "whatsapp")) res)
        _ -> pure Nothing
    , case aiEmail of
        Just e -> do
          let svc = EmailSvc.mkEmailService cfg
          emailResult <- (try $
            EmailSvc.sendTestEmail svc (fromMaybe "Amigo TDF" aiName) e "Gracias por tu interés en TDF"
              [ "Paquete 1:1 (16 horas): $480."
              , "Grupo pequeño: detalles y fechas en " <> courseLanding
              , "Agenda tu clase de prueba gratis aquí: " <> cta <> "/trials"
              ] (Just (cta <> "/trials"))) :: IO (Either SomeException ())
          case emailResult of
            Left err -> do
              let msg = "[AdsInquiry] Failed to send follow-up email to " <> e <> ": " <> T.pack (displayException err)
              hPutStrLn stderr (T.unpack msg)
              LogBuf.addLog LogBuf.LogWarning msg
              pure Nothing
            Right () -> pure (Just "email")
        Nothing -> pure Nothing
    ]
  pure channels

resolveAuthoredContentIdBySlug :: Text -> AppM (Maybe UUID.UUID)
resolveAuthoredContentIdBySlug slug = do
  current <- runDB $ selectFirst
    [ Catalog.AuthoredContentCurrentSlug ==. slug
    , Catalog.AuthoredContentActive ==. True
    ]
    []
  candidate <- case current of
    Just entity -> pure (Just entity)
    Nothing -> do
      alias <- runDB $ selectFirst
        [ Catalog.CatalogSlugAliasEntityKind ==. "authored_content"
        , Catalog.CatalogSlugAliasScope ==. "cms-public"
        , Catalog.CatalogSlugAliasSlug ==. slug
        , Catalog.CatalogSlugAliasRetiredAt ==. Nothing
        ]
        []
      case alias of
        Nothing -> pure Nothing
        Just (Entity _ aliasValue) -> runDB $ getEntity
          (Catalog.AuthoredContentKey (Catalog.catalogSlugAliasEntityId aliasValue))
  case candidate of
    Nothing -> pure Nothing
    Just (Entity (Catalog.AuthoredContentKey contentId) value)
      | not (Catalog.authoredContentActive value) -> pure Nothing
      | otherwise -> do
          workflowState <- runDB (get (Catalog.authoredContentWorkflowStateId value))
          pure $ case workflowState of
            Just state | Catalog.workflowStateCode state == "published" -> Just contentId
            _ -> Nothing

cmsPublicServer :: ServerT CmsPublicAPI AppM
cmsPublicServer = cmsGet :<|> cmsList
  where
    fallbackContent slug locale = do
      now <- liftIO getCurrentTime
      pure CmsContentDTO
        { ccdId          = 0
        , ccdContentId   = Nothing
        , ccdSlug        = slug
        , ccdLocale      = locale
        , ccdVersion     = 0
        , ccdStatus      = "missing"
        , ccdTitle       = Nothing
        , ccdPayload     = Nothing
        , ccdCreatedAt   = now
        , ccdPublishedAt = Nothing
        }

    cmsGet mSlug mLocale = do
      slug <-
        maybe (throwError err400 { errBody = "slug requerido" })
          (either throwError pure . validateRequiredCmsSlug)
          mSlug
      locale <- either throwError pure (validateCmsLocaleFilter mLocale)
      mAuthoredContentId <- resolveAuthoredContentIdBySlug slug
      mPublished <- case mAuthoredContentId of
        Nothing -> pure Nothing
        Just authoredContentId -> runDB $ selectFirst
          [ CMS.CmsContentAuthoredContentId ==. Just authoredContentId
          , CMS.CmsContentLocale ==. locale
          , CMS.CmsContentStatus ==. "published"
          ] [Desc CMS.CmsContentVersion]
      maybe (fallbackContent slug locale) (pure . toCmsDTO) mPublished

    cmsList mLocale mPrefix = do
      locale <- either throwError pure (validateCmsLocaleFilter mLocale)
      mSlugPrefix <- either throwError pure (validateOptionalCmsSlugPrefix mPrefix)
      entries <- runDB $
        selectList
          [ CMS.CmsContentLocale ==. locale
          , CMS.CmsContentStatus ==. "published"
          , CMS.CmsContentAuthoredContentId !=. Nothing
          ]
          [ Desc CMS.CmsContentPublishedAt
          , Desc CMS.CmsContentVersion
          ]
      let filtered = case mSlugPrefix of
            Nothing -> entries
            Just prefix -> filter (\(Entity _ c) -> prefix `T.isPrefixOf` CMS.cmsContentSlug c) entries
      pure (map toCmsDTO filtered)

marketplacePublicServer :: ServerT MarketplaceAPI AppM
marketplacePublicServer =
       listMarketplace
  :<|> getMarketplaceItem
  :<|> createCart
  :<|> getCart
  :<|> upsertCartItem
  :<|> checkoutCart
  :<|> createMarketplaceStripePaymentIntent
  :<|> createDatafastCheckout
  :<|> confirmDatafastPayment
  :<|> createPaypalOrder
  :<|> capturePaypalOrder
  :<|> getOrder
  :<|> submitMarketplaceManualEvidence
  :<|> listMarketplaceCustomerRequestsPublic
  :<|> submitMarketplaceCustomerRequest

marketplaceAdminServer :: AuthedUser -> ServerT MarketplaceAdminAPI AppM
marketplaceAdminServer user =
       updateMarketplaceRentalTerms user
  :<|> listMarketplaceOrders user
  :<|> getMarketplaceCommerce user
  :<|> reviewMarketplaceManualPayment user
  :<|> updateMarketplaceOrder user
  :<|> updateMarketplaceFulfillment user
  :<|> updateMarketplaceRental user
  :<|> listMarketplaceCustomerRequestsAdmin user
  :<|> reviewMarketplaceCustomerRequest user
  :<|> listMarketplaceDepositSettlements user
  :<|> submitMarketplaceDepositSettlement user
  :<|> reviewMarketplaceDepositSettlement user

labelServer :: AuthedUser -> ServerT LabelAPI AppM
labelServer user =
       listLabelTracks user
  :<|> createLabelTrack user
  :<|> updateLabelTrack user
  :<|> deleteLabelTrack user
  :<|> listLabelProjectNotes user
  :<|> createLabelProjectNote user
  :<|> updateLabelProjectNote user
  :<|> deactivateLabelProjectNote user

validateContractsAccess :: AuthedUser -> Either ServerError ()
validateContractsAccess user
  | hasOperationsAccess user = Right ()
  | otherwise =
      Left err403
        { errBody = "Contracts access requires operations role"
        }

contractsServer :: AuthedUser -> ServerT ContractsAPI AppM
contractsServer user =
       (\body -> guardContracts (createH body))
  :<|> (\contractId -> guardContracts (pdfH contractId))
  :<|> (\contractId body -> guardContracts (sendH contractId body))
  where
    createH :<|> pdfH :<|> sendH = Contracts.server

    guardContracts :: Handler a -> AppM a
    guardContracts action = do
      either throwError pure (validateContractsAccess user)
      lift action

listMarketplace :: AppM [MarketplaceItemDTO]
listMarketplace = do
  Env{..} <- ask
  let assetsBase = resolveConfiguredAssetsBase envConfig
  let loadListings = do
        listings <-
          selectList
            [ME.MarketplaceListingActive ==. True]
            [Asc ME.MarketplaceListingTitle]
        if null listings
          then pure ([], Map.empty)
          else do
            assets <- getMany (map (ME.marketplaceListingAssetId . entityVal) listings)
            rentalTerms <- loadPublicMarketplaceRentalTerms (map entityKey listings)
            pure
              ( [ (lid, listing, Map.lookup (ME.marketplaceListingAssetId listing) assets)
                | Entity lid listing <- listings
                ]
              , rentalTerms
              )
      renderListings (rows, rentalTerms) =
        fmap catMaybes $ forM rows $ \row@(lid, _, _) ->
          toMarketplaceDTOWithTerms assetsBase (Map.lookup (toPathPiece lid) rentalTerms) row
  loaded@(rows, _) <- liftIO $ flip runSqlPool envPool loadListings
  if not (null rows)
    then renderListings loaded
    else if seedDatabase envConfig
    then do
      -- Auto-publish demo inventory so the public marketplace is never empty.
      liftIO $ flip runSqlPool envPool $ do
        seedInventoryAssets
        seedMarketplaceListings
      seeded <- liftIO $ flip runSqlPool envPool loadListings
      renderListings seeded
    else
      pure []

getMarketplaceItem :: Text -> AppM MarketplaceItemDTO
getMarketplaceItem rawId = do
  listingKey <- parseListingId rawId
  Env{..} <- ask
  let assetsBase = resolveConfiguredAssetsBase envConfig
  mRow <- liftIO $ flip runSqlPool envPool $ do
    mListing <- get listingKey
    case mListing of
      Nothing -> pure Nothing
      Just listing -> do
        mAsset <- get (ME.marketplaceListingAssetId listing)
        pure (Just (listingKey, listing, mAsset))
  case mRow of
    Nothing -> throwError marketplaceListingNotFound
    Just row@(_, listing, _) -> do
      either throwError pure $
        validateMarketplacePublicListingActive (ME.marketplaceListingActive listing)
      mDto <- toMarketplaceDTO assetsBase row
      maybe (throwError marketplaceListingNotFound) pure mDto

updateMarketplaceRentalTerms
  :: AuthedUser
  -> Text
  -> MarketplaceRentalTermsUpdate
  -> AppM MarketplaceItemDTO
updateMarketplaceRentalTerms user rawId MarketplaceRentalTermsUpdate{..} = do
  requireMarketplaceAccess user
  listingKey <- parseListingId rawId
  let upperMinorBound = 2147483647
      termsVersion = T.strip mrtuTermsVersion
      termsSummary = T.strip mrtuTermsSummary
      timezone = T.strip mrtuTimezone
      inMinorBounds amount = amount >= 0 && amount <= upperMinorBound
  unless (mrtuDailyRateUsdCents >= 1 && mrtuDailyRateUsdCents <= upperMinorBound) $
    throwError err400 { errBody = "Rental daily rate is outside the supported minor-unit range" }
  unless (maybe True (\amount -> amount >= 1 && amount <= upperMinorBound) mrtuWeeklyRateUsdCents) $
    throwError err400 { errBody = "Rental weekly rate is outside the supported minor-unit range" }
  unless (inMinorBounds mrtuSecurityDepositUsdCents && inMinorBounds mrtuLateFeeUsdCents) $
    throwError err400 { errBody = "Rental deposit or late fee is outside the supported minor-unit range" }
  unless (mrtuMinDays >= 1 && mrtuMaxDays >= mrtuMinDays && mrtuMaxDays <= 366) $
    throwError err400 { errBody = "Rental duration limits are invalid" }
  unless (mrtuCancellationWindowHours >= 0 && mrtuCancellationWindowHours <= 8760) $
    throwError err400 { errBody = "Rental cancellation window is invalid" }
  unless (timezone == "America/Guayaquil") $
    throwError err400 { errBody = "Marketplace rentals currently require America/Guayaquil" }
  unless (not (T.null termsVersion) && T.length termsVersion <= 80) $
    throwError err400 { errBody = "Rental terms version must contain 1 to 80 characters" }
  unless (not (T.null termsSummary) && T.length termsSummary <= 1000) $
    throwError err400 { errBody = "Rental terms summary must contain 1 to 1000 characters" }
  void . either (throwError . marketplaceCheckoutBadRequest) pure $
    MarketplaceRentals.calculateRentalPrice
      mrtuDailyRateUsdCents
      mrtuWeeklyRateUsdCents
      mrtuSecurityDepositUsdCents
      mrtuMinDays
      mrtuMaxDays
      mrtuMinDays
  Env{ envPool } <- ask
  let actor = "party:" <> T.pack (show (fromSqlKey (auPartyId user)))
  result <- liftIO $ flip runSqlPool envPool $ do
    mListing <- get listingKey
    case mListing of
      Nothing -> pure (Left marketplaceListingNotFound)
      Just listing
        | T.toLower (T.strip (ME.marketplaceListingPurpose listing)) /= "rent" ->
            pure (Left err409 { errBody = "Rental terms can only be configured for a rent listing" })
        | not (ME.marketplaceListingActive listing) ->
            pure (Left err409 { errBody = "Activate the marketplace listing before enabling rental terms" })
        | otherwise -> do
            _ <- (rawSql "SELECT set_config('tdf.actor_id', ?, TRUE)"
              [PersistText actor] :: SqlPersistT IO [Single Text])
            rawExecute
              "INSERT INTO marketplace_rental_listing_terms(\
              \ listing_id, daily_rate_usd_cents, weekly_rate_usd_cents,\
              \ security_deposit_usd_cents, late_fee_usd_cents, min_days, max_days,\
              \ cancellation_window_hours, timezone, terms_version, terms_summary, active,\
              \ approved_at, approved_by\
              \) VALUES (?::uuid, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,\
              \ CASE WHEN ? THEN NOW() ELSE NULL END, CASE WHEN ? THEN ? ELSE NULL END)\
              \ ON CONFLICT (listing_id) DO UPDATE SET\
              \ daily_rate_usd_cents=EXCLUDED.daily_rate_usd_cents,\
              \ weekly_rate_usd_cents=EXCLUDED.weekly_rate_usd_cents,\
              \ security_deposit_usd_cents=EXCLUDED.security_deposit_usd_cents,\
              \ late_fee_usd_cents=EXCLUDED.late_fee_usd_cents, min_days=EXCLUDED.min_days,\
              \ max_days=EXCLUDED.max_days, cancellation_window_hours=EXCLUDED.cancellation_window_hours,\
              \ timezone=EXCLUDED.timezone, terms_version=EXCLUDED.terms_version,\
              \ terms_summary=EXCLUDED.terms_summary, active=EXCLUDED.active,\
              \ approved_at=EXCLUDED.approved_at, approved_by=EXCLUDED.approved_by, updated_at=NOW()"
              [ PersistText (toPathPiece listingKey)
              , PersistInt64 (fromIntegral mrtuDailyRateUsdCents)
              , maybe PersistNull (PersistInt64 . fromIntegral) mrtuWeeklyRateUsdCents
              , PersistInt64 (fromIntegral mrtuSecurityDepositUsdCents)
              , PersistInt64 (fromIntegral mrtuLateFeeUsdCents)
              , PersistInt64 (fromIntegral mrtuMinDays)
              , PersistInt64 (fromIntegral mrtuMaxDays)
              , PersistInt64 (fromIntegral mrtuCancellationWindowHours)
              , PersistText timezone
              , PersistText termsVersion
              , PersistText termsSummary
              , PersistBool mrtuActive
              , PersistBool mrtuActive
              , PersistBool mrtuActive
              , PersistText actor
              ]
            pure (Right ())
  either throwError pure result
  getMarketplaceItem rawId

toMarketplaceDTO
  :: Text
  -> (Key ME.MarketplaceListing, ME.MarketplaceListing, Maybe ME.Asset)
  -> AppM (Maybe MarketplaceItemDTO)
toMarketplaceDTO _ (_, _, Nothing) = pure Nothing
toMarketplaceDTO assetsBase row@(lid, _, _) = do
  Env{ envPool } <- ask
  mRentalTerms <- liftIO $ flip runSqlPool envPool $ loadActiveMarketplaceRentalTerms lid
  toMarketplaceDTOWithTerms assetsBase mRentalTerms row

-- The public collection loads these inputs in bulk; item/checkout callers retain
-- the same authoritative per-listing terms query and DTO construction.
toMarketplaceDTOWithTerms
  :: Text
  -> Maybe MarketplaceRentalTerms
  -> (Key ME.MarketplaceListing, ME.MarketplaceListing, Maybe ME.Asset)
  -> AppM (Maybe MarketplaceItemDTO)
toMarketplaceDTOWithTerms _ _ (_, _, Nothing) = pure Nothing
toMarketplaceDTOWithTerms assetsBase mRentalTerms (lid, listing, Just asset) = do
  mPhoto <- liftIO $ resolveMarketplacePhotoUrl assetsBase (ME.assetPhotoUrl asset)
  let listedPrice = maybe
        (ME.marketplaceListingPriceUsdCents listing)
        mrtDailyRateCents
        mRentalTerms
      currency = ME.marketplaceListingCurrency listing
  pure $ Just MarketplaceItemDTO
    { miListingId      = toPathPiece lid
    , miAssetId        = toPathPiece (ME.marketplaceListingAssetId listing)
    , miTitle          = ME.marketplaceListingTitle listing
    , miPurpose        = ME.marketplaceListingPurpose listing
    , miCategory       = ME.assetCategory asset
    , miBrand          = ME.assetBrand asset
    , miModel          = ME.assetModel asset
    , miPhotoUrl       = mPhoto
    , miStatus         = Just (assetStatusLabel (ME.assetStatus asset))
    , miCondition      = Just (assetConditionLabel (ME.assetCondition asset))
    , miPriceUsdCents  = listedPrice
    , miPriceDisplay   =
        formatUsd
          listedPrice
          currency
    , miMarkupPct      = ME.marketplaceListingMarkupPct listing
    , miCurrency       = currency
    , miRentalWeeklyPriceUsdCents = mrtWeeklyRateCents =<< mRentalTerms
    , miRentalWeeklyPriceDisplay =
        (\amount -> formatUsd amount currency) <$> (mrtWeeklyRateCents =<< mRentalTerms)
    , miRentalSecurityDepositUsdCents = mrtSecurityDepositCents <$> mRentalTerms
    , miRentalSecurityDepositDisplay =
        (\terms -> formatUsd (mrtSecurityDepositCents terms) currency) <$> mRentalTerms
    , miRentalMinDays = mrtMinDays <$> mRentalTerms
    , miRentalMaxDays = mrtMaxDays <$> mRentalTerms
    , miRentalLateFeeUsdCents = mrtLateFeeCents <$> mRentalTerms
    , miRentalLateFeeDisplay =
        (\terms -> formatUsd (mrtLateFeeCents terms) currency) <$> mRentalTerms
    , miRentalCancellationWindowHours = mrtCancellationWindowHours <$> mRentalTerms
    , miRentalTermsVersion = mrtTermsVersion <$> mRentalTerms
    , miRentalTermsSummary = mrtTermsSummary <$> mRentalTerms
    , miRentalTimezone = mrtTimezone <$> mRentalTerms
    }

data MarketplaceRentalTerms = MarketplaceRentalTerms
  { mrtDailyRateCents :: Int
  , mrtWeeklyRateCents :: Maybe Int
  , mrtSecurityDepositCents :: Int
  , mrtLateFeeCents :: Int
  , mrtMinDays :: Int
  , mrtMaxDays :: Int
  , mrtCancellationWindowHours :: Int
  , mrtTimezone :: Text
  , mrtTermsVersion :: Text
  , mrtTermsSummary :: Text
  } deriving (Eq, Show)

-- Bind the already selected listing IDs. Re-reading listing.active under READ
-- COMMITTED could remove approved terms after concurrent fulfillment deactivates
-- an asset, causing a selected rental to fall back to its base price.
loadPublicMarketplaceRentalTerms :: [Key ME.MarketplaceListing] -> SqlPersistT IO (Map.Map Text MarketplaceRentalTerms)
loadPublicMarketplaceRentalTerms [] = pure Map.empty
loadPublicMarketplaceRentalTerms listingIds = do
  let placeholders = T.intercalate "," (replicate (length listingIds) "?::uuid")
  rows <- (rawSql
    ("SELECT CAST(t.listing_id AS TEXT), t.daily_rate_usd_cents, t.weekly_rate_usd_cents, t.security_deposit_usd_cents," <>
     " t.late_fee_usd_cents, t.min_days, t.max_days, t.cancellation_window_hours, t.timezone, t.terms_version, t.terms_summary" <>
     " FROM marketplace_rental_listing_terms t" <>
     " WHERE t.listing_id IN (" <> placeholders <> ") AND t.active AND t.approved_at IS NOT NULL")
    (map (PersistText . toPathPiece) listingIds)
    :: SqlPersistT IO
      [( Single Text, Single Int64, Single (Maybe Int64), Single Int64, Single Int64
       , Single Int, Single Int, Single Int, Single Text, Single Text, Single Text
       )])
  pure $ Map.fromList
    [ (listingId, MarketplaceRentalTerms
        { mrtDailyRateCents = fromIntegral dailyRate
        , mrtWeeklyRateCents = fromIntegral <$> weeklyRate
        , mrtSecurityDepositCents = fromIntegral securityDeposit
        , mrtLateFeeCents = fromIntegral lateFee
        , mrtMinDays = minDays
        , mrtMaxDays = maxDays
        , mrtCancellationWindowHours = cancellationWindowHours
        , mrtTimezone = timezone
        , mrtTermsVersion = termsVersion
        , mrtTermsSummary = termsSummary
        })
    | ( Single listingId, Single dailyRate, Single weeklyRate, Single securityDeposit, Single lateFee
      , Single minDays, Single maxDays, Single cancellationWindowHours, Single timezone, Single termsVersion
      , Single termsSummary
      ) <- rows
    ]

loadActiveMarketplaceRentalTerms
  :: Key ME.MarketplaceListing
  -> SqlPersistT IO (Maybe MarketplaceRentalTerms)
loadActiveMarketplaceRentalTerms listingKey = do
  rows <- (rawSql
    "SELECT daily_rate_usd_cents, weekly_rate_usd_cents, security_deposit_usd_cents,\
    \ late_fee_usd_cents, min_days, max_days, cancellation_window_hours, timezone, terms_version, terms_summary\
    \ FROM marketplace_rental_listing_terms\
    \ WHERE listing_id = ?::uuid AND active AND approved_at IS NOT NULL"
    [PersistText (toPathPiece listingKey)]
    :: SqlPersistT IO
      [( Single Int64, Single (Maybe Int64), Single Int64, Single Int64
       , Single Int, Single Int, Single Int, Single Text, Single Text, Single Text
       )])
  pure $ case rows of
    [( Single dailyRate, Single weeklyRate, Single securityDeposit, Single lateFee
     , Single minDays, Single maxDays, Single cancellationWindowHours, Single timezone, Single termsVersion
     , Single termsSummary
     )] -> Just MarketplaceRentalTerms
        { mrtDailyRateCents = fromIntegral dailyRate
        , mrtWeeklyRateCents = fromIntegral <$> weeklyRate
        , mrtSecurityDepositCents = fromIntegral securityDeposit
        , mrtLateFeeCents = fromIntegral lateFee
        , mrtMinDays = minDays
        , mrtMaxDays = maxDays
        , mrtCancellationWindowHours = cancellationWindowHours
        , mrtTimezone = timezone
        , mrtTermsVersion = termsVersion
        , mrtTermsSummary = termsSummary
        }
    _ -> Nothing

resolveMarketplacePhotoUrl :: Text -> Maybe Text -> IO (Maybe Text)
resolveMarketplacePhotoUrl _ Nothing = pure Nothing
resolveMarketplacePhotoUrl assetsBase (Just raw0) =
  case ServerExtra.validateAssetPhotoUrl (Just raw0) of
    Left _ -> pure Nothing
    Right Nothing -> pure Nothing
    Right (Just photoUrl) -> pure (Just (normalizePhoto assetsBase photoUrl))

normalizePhoto :: Text -> Text -> Text
normalizePhoto assetsBase raw =
  let trimmed = T.strip raw
      base    = T.dropWhileEnd (== '/') assetsBase
  in if "http://" `T.isPrefixOf` trimmed || "https://" `T.isPrefixOf` trimmed
        then trimmed
        else
          let path0 = T.dropWhile (== '/') trimmed
              path
                | "assets/serve/" `T.isPrefixOf` path0 = T.drop (T.length ("assets/serve/" :: Text)) path0
                | "assets/inventory/" `T.isPrefixOf` path0 = T.drop (T.length ("assets/" :: Text)) path0
                | otherwise = path0
          in base <> "/" <> path

createCart :: AppM MarketplaceCartDTO
createCart = do
  now <- liftIO getCurrentTime
  Env{..} <- ask
  cartId <- liftIO $ flip runSqlPool envPool $ insert $ ME.MarketplaceCart now now
  cartDto <- liftIO $ flip runSqlPool envPool $ loadCartDTO (defaultCurrency envConfig) cartId
  either throwError pure (cartDto >>= requireLoadedMarketplaceWriteResult "Marketplace cart")

getCart :: Text -> AppM MarketplaceCartDTO
getCart rawId = do
  cartKey <- parseCartId rawId
  Env{..} <- ask
  mCart <- liftIO $ flip runSqlPool envPool $ loadCartDTO (defaultCurrency envConfig) cartKey
  either throwError (maybe (throwError marketplaceCartNotFound) pure) mCart

upsertCartItem :: Text -> MarketplaceCartItemUpdate -> AppM MarketplaceCartDTO
upsertCartItem rawId MarketplaceCartItemUpdate{..} = do
  cartKey <- parseCartId rawId
  listingKey <- parseListingId mciuListingId
  when (mciuQuantity < 0) $ throwBadRequest "quantity must be non-negative"
  when (mciuQuantity > maxMarketplaceCartItemQuantity) $
    throwBadRequest $
      "quantity must be "
        <> T.pack (show maxMarketplaceCartItemQuantity)
        <> " or fewer"
  now <- liftIO getCurrentTime
  Env{..} <- ask
  result <- liftIO $ flip runSqlPool envPool $ do
    mCart <- get cartKey
    mListing <- get listingKey
    case (mCart, mListing) of
      (Nothing, _) ->
        pure (Left marketplaceCartNotFound)
      (_, Nothing) ->
        pure (Left marketplaceListingNotFound)
      (Just _, Just listing) -> do
        let purpose = T.toLower (T.strip (ME.marketplaceListingPurpose listing))
        case validateMarketplacePublicListingActive (ME.marketplaceListingActive listing) of
          Left serverErr -> pure (Left serverErr)
          Right () | mciuQuantity > 1 ->
            pure (Left err409
              { errBody = "Each physical marketplace asset can only be added once"
              })
          Right () | purpose `notElem` ["sale", "rent"] ->
            pure (Left err409 { errBody = "Marketplace listing purpose is not supported" })
          Right () -> do
            existingCartItems <- selectList
              [ME.MarketplaceCartItemCartId ==. cartKey] [Asc ME.MarketplaceCartItemId]
            existingPurposes <- forM existingCartItems $ \(Entity itemId cartItem) -> do
              existingListing <- getJust (ME.marketplaceCartItemListingId cartItem)
              pure (itemId, T.toLower (T.strip (ME.marketplaceListingPurpose existingListing)))
            let otherPurposes =
                  [ existingPurpose
                  | (itemId, existingPurpose) <- existingPurposes
                  , Just (Entity currentItemId _) <-
                      [find (\(Entity _ item) -> ME.marketplaceCartItemListingId item == listingKey) existingCartItems]
                  , itemId /= currentItemId
                  ]
                  <> if any (\(Entity _ item) -> ME.marketplaceCartItemListingId item == listingKey) existingCartItems
                       then []
                       else map snd existingPurposes
                mixedPurpose = any (/= purpose) otherPurposes
                rentalHasOtherAsset = purpose == "rent" && not (null otherPurposes)
            if mciuQuantity > 0 && (mixedPurpose || rentalHasOtherAsset)
              then pure (Left err409
                { errBody = "Sales and rentals use separate carts; each rental checkout contains one asset"
                })
              else do
                selectionResult <- if mciuQuantity == 0
                  then pure (Right Nothing)
                  else validateMarketplaceCartSelection
                    (utctDay now) listingKey listing mciuRentalStartDate mciuRentalEndDate
                case selectionResult of
                  Left serverErr -> pure (Left serverErr)
                  Right selection -> do
                    let existing = find
                          (\(Entity _ item) -> ME.marketplaceCartItemListingId item == listingKey)
                          existingCartItems
                    storedItemId <- case existing of
                      Nothing ->
                        if mciuQuantity == 0
                          then pure Nothing
                          else Just <$> insert ME.MarketplaceCartItem
                                 { ME.marketplaceCartItemCartId = cartKey
                                 , ME.marketplaceCartItemListingId = listingKey
                                 , ME.marketplaceCartItemQuantity = mciuQuantity
                                 }
                      Just (Entity itemId _) ->
                        if mciuQuantity == 0
                          then delete itemId >> pure Nothing
                          else update itemId [ME.MarketplaceCartItemQuantity =. mciuQuantity]
                                >> pure (Just itemId)
                    case (storedItemId, selection) of
                      (Just itemId, Just (startDate, endDate, durationDays)) ->
                        rawExecute
                          "INSERT INTO marketplace_rental_cart_selection(\
                          \ cart_item_id, start_date, end_date, duration_days\
                          \) VALUES (?::uuid, ?, ?, ?)\
                          \ ON CONFLICT (cart_item_id) DO UPDATE SET\
                          \ start_date = EXCLUDED.start_date, end_date = EXCLUDED.end_date,\
                          \ duration_days = EXCLUDED.duration_days, updated_at = NOW()"
                          [ PersistText (toPathPiece itemId)
                          , PersistDay startDate
                          , PersistDay endDate
                          , PersistInt64 (fromIntegral durationDays)
                          ]
                      (Just itemId, Nothing) -> rawExecute
                        "DELETE FROM marketplace_rental_cart_selection WHERE cart_item_id = ?::uuid"
                        [PersistText (toPathPiece itemId)]
                      _ -> pure ()
                    update cartKey [ME.MarketplaceCartUpdatedAt =. now]
                    loaded <- loadCartDTO (defaultCurrency envConfig) cartKey
                    case loaded >>= maybe (Left marketplaceCartNotFound) Right of
                      Left serverErr -> transactionUndo >> pure (Left serverErr)
                      Right dto -> pure (Right dto)
  either throwError pure result

validateMarketplaceCartSelection
  :: Day
  -> Key ME.MarketplaceListing
  -> ME.MarketplaceListing
  -> Maybe Day
  -> Maybe Day
  -> SqlPersistT IO (Either ServerError (Maybe (Day, Day, Int)))
validateMarketplaceCartSelection today listingKey listing mStartDate mEndDate =
  case T.toLower (T.strip (ME.marketplaceListingPurpose listing)) of
    "sale" -> pure $ case (mStartDate, mEndDate) of
      (Nothing, Nothing) -> Right Nothing
      _ -> Left err400 { errBody = "Sale cart items must not include rental dates" }
    "rent" -> case (mStartDate, mEndDate) of
      (Just startDate, Just endDate)
        | startDate < today -> pure (Left err400
            { errBody = "Rental start date must not be in the past" })
        | otherwise -> case MarketplaceRentals.rentalDurationDays startDate endDate of
            Left message -> pure (Left (marketplaceCheckoutBadRequest message))
            Right durationDays -> do
              mTerms <- loadActiveMarketplaceRentalTerms listingKey
              case mTerms of
                Nothing -> pure (Left err409
                  { errBody = "This rental listing does not have approved active terms" })
                Just terms ->
                  case MarketplaceRentals.calculateRentalPrice
                    (mrtDailyRateCents terms)
                    (mrtWeeklyRateCents terms)
                    (mrtSecurityDepositCents terms)
                    (mrtMinDays terms)
                    (mrtMaxDays terms)
                    durationDays of
                      Left message -> pure (Left (marketplaceCheckoutBadRequest message))
                      Right _ -> do
                        overlap <- (rawSql
                          "SELECT 1::bigint FROM marketplace_rental_order_runtime\
                          \ WHERE listing_id = ?::uuid\
                          \ AND rental_status IN ('on_hold','confirmed','ready_for_handoff',\
                          \ 'checked_out','return_due','returned_pending_inspection','damage_review',\
                          \ 'deposit_refund_due','lost','disputed')\
                          \ AND daterange(start_date, end_date, '[]') && daterange(?::date, ?::date, '[]')\
                          \ LIMIT 1"
                          [ PersistText (toPathPiece listingKey)
                          , PersistDay startDate
                          , PersistDay endDate
                          ] :: SqlPersistT IO [Single Int64])
                        pure $ if null overlap
                          then Right (Just (startDate, endDate, durationDays))
                          else Left err409
                            { errBody = "The rental asset is not available for the selected dates" }
      _ -> pure (Left err400
        { errBody = "Rental cart items require both start and end dates" })
    _ -> pure (Left err409 { errBody = "Marketplace listing purpose is not supported" })

data MarketplaceSaleCheckoutContext = MarketplaceSaleCheckoutContext
  { msccOrderKey :: Key ME.MarketplaceOrder
  , msccCheckout :: Checkout.CheckoutReference
  , msccEnvironment :: Checkout.CheckoutEnvironment
  , msccLookupToken :: Text
  , msccIdempotencyKey :: Text
  , msccCreated :: Bool
  , msccTotalCents :: Int
  , msccCurrency :: Text
  , msccOrderKind :: Text
  }

checkoutCart :: Text -> Maybe Text -> MarketplaceCheckoutReq -> AppM MarketplaceOrderDTO
checkoutCart rawId mIdempotency payload = do
  -- Contact coordination creates an unpaid request, not a bank-transfer
  -- payment selection. It must remain available without online/custody capability
  -- approval and must not create a payment intent, attempt, evidence or receipt.
  context <- prepareMarketplaceSaleCheckout "contact" rawId mIdempotency payload
  orderDto <- loadMarketplaceOrderWithLookup context
  when (msccCreated context) $ sendMarketplaceOrderCreatedEmail orderDto
  pure orderDto

prepareMarketplaceSaleCheckout
  :: Text
  -> Text
  -> Maybe Text
  -> MarketplaceCheckoutReq
  -> AppM MarketplaceSaleCheckoutContext
prepareMarketplaceSaleCheckout provider rawCartId mIdempotency payload@MarketplaceCheckoutReq{..} = do
  idempotencyKey <- either (throwError . marketplaceCheckoutBadRequest) pure
    (ServiceStorefront.validateIdempotencyKey mIdempotency)
  buyerNameTxt <- either throwError pure (validateMarketplaceBuyerName mcrBuyerName)
  buyerEmailTxt <- either throwError pure (validateMarketplaceBuyerEmail mcrBuyerEmail)
  buyerPhoneTxt <- either throwError pure (validateMarketplaceBuyerPhone mcrBuyerPhone)
  cartKey <- parseCartId rawCartId
  method <- either (throwError . marketplaceCheckoutBadRequest) pure $
    MarketplaceSales.parseMarketplaceFulfillmentMethod
      (fromMaybe "pickup" mcrFulfillmentMethod)
  validateMarketplaceShippingAddress method mcrShippingAddress
  checkoutEnvironment <- loadMarketplaceCheckoutEnvironment
  now <- liftIO getCurrentTime
  let holdExpiresAt = addUTCTime (15 * 60) now
      cartIdText = toPathPiece cartKey
      methodText = MarketplaceSales.marketplaceFulfillmentMethodText method
      requestHash = marketplaceSha256Text . TE.decodeUtf8 . BL.toStrict . encode $ object
        [ "cart_id" .= cartIdText
        , "buyer_name" .= buyerNameTxt
        , "buyer_email" .= buyerEmailTxt
        , "buyer_phone" .= buyerPhoneTxt
        , "fulfillment_method" .= methodText
        , "shipping_address" .= mcrShippingAddress
        , "rental_terms_accepted" .= mcrRentalTermsAccepted
        , "identity_document_type" .= (T.toLower . T.strip <$> mcrIdentityDocumentType)
        -- The full document number is validated and then discarded.  Binding
        -- idempotency to the type and last four characters avoids retaining a
        -- cheaply reversible hash of a low-entropy government identifier.
        , "identity_document_last4" .=
            (T.takeEnd 4 . T.toUpper . T.filter isAlphaNum <$> mcrIdentityDocumentNumber)
        ]
      lookupToken = marketplaceSha256Text
        ("marketplace-order-lookup:" <> idempotencyKey <> ":" <> cartIdText)
      lookupHash = marketplaceSha256Text lookupToken
  Env{ envPool } <- ask
  result <- liftIO $ flip runSqlPool envPool $ do
    _ <- (rawSql
      "SELECT 1::bigint FROM (SELECT pg_advisory_xact_lock(hashtextextended(?, 0))) locked"
      [PersistText ("marketplace-sale:" <> idempotencyKey)]
      :: SqlPersistT IO [Single Int64])
    existingRows <- (rawSql
      "SELECT order_id::text, checkout_id::text, create_request_sha256, order_kind\
      \ FROM marketplace_order_checkout_runtime WHERE create_idempotency_key = ?"
      [PersistText idempotencyKey]
      :: SqlPersistT IO [(Single Text, Single Text, Single Text, Single Text)])
    case existingRows of
      [(Single orderIdText, Single checkoutId, Single storedRequestHash, Single orderKind)]
        | storedRequestHash /= requestHash ->
            pure (Left (marketplaceCheckoutConflict
              "Idempotency key was already used for a different marketplace checkout"))
        | otherwise ->
            case fromPathPiece orderIdText of
              Nothing -> pure (Left (marketplaceCheckoutInternal
                "Stored marketplace runtime has an invalid order reference"))
              Just orderKey -> do
                mOrder <- get orderKey
                storedEnvironment <- Checkout.loadCheckoutEnvironment
                  (Checkout.CheckoutReference checkoutId)
                case (mOrder, storedEnvironment) of
                  (_, Left _) -> pure (Left (marketplaceCheckoutInternal
                    "Stored marketplace checkout environment is invalid"))
                  (_, Right environment) | environment /= checkoutEnvironment ->
                    pure (Left (marketplaceCheckoutConflict
                      "Checkout environment changed; the existing order must be reconciled"))
                  (Nothing, _) -> pure (Left (marketplaceCheckoutInternal
                    "Stored marketplace runtime order is missing"))
                  (Just order, Right environment) -> pure (Right MarketplaceSaleCheckoutContext
                    { msccOrderKey = orderKey
                    , msccCheckout = Checkout.CheckoutReference checkoutId
                    , msccEnvironment = environment
                    , msccLookupToken = lookupToken
                    , msccIdempotencyKey = idempotencyKey
                    , msccCreated = False
                    , msccTotalCents = ME.marketplaceOrderTotalUsdCents order
                    , msccCurrency = ME.marketplaceOrderCurrency order
                    , msccOrderKind = orderKind
                    })
      [] -> createMarketplaceCheckout
        checkoutEnvironment
        now
        holdExpiresAt
        idempotencyKey
        requestHash
        lookupToken
        lookupHash
        methodText
        buyerNameTxt
        buyerEmailTxt
        buyerPhoneTxt
        cartKey
        payload
      _ -> pure (Left (marketplaceCheckoutInternal
        "Marketplace idempotency lookup was ambiguous"))
  context <- either throwError pure result
  ensureMarketplacePaymentRailAvailable provider context
  pure context

ensureMarketplacePaymentRailAvailable :: Text -> MarketplaceSaleCheckoutContext -> AppM ()
ensureMarketplacePaymentRailAvailable rawProvider context = do
  let provider = T.toLower (T.strip rawProvider)
      checkoutId = Checkout.checkoutReferenceId (msccCheckout context)
  conflicts <- runDB $ case provider of
    candidate | candidate `elem` ["bank_transfer", "contact"] -> rawSql
      "SELECT 1::bigint FROM commerce_payment_attempt\
      \ WHERE checkout_id = ?::uuid\
      \ AND provider IN ('datafast','paypal','stripe')\
      \ AND status IN ('requires_customer_action','processing') LIMIT 1"
      [PersistText checkoutId]
    "datafast" -> manualConflict checkoutId
    "paypal" -> manualConflict checkoutId
    _ -> pure []
  unless (null (conflicts :: [Single Int64])) $
    throwError err409
      { errBody = if provider `elem` ["bank_transfer", "contact"]
          then "An online payment is awaiting customer action or processing; verify it before requesting manual coordination"
          else "Manual payment evidence is under review; resolve it before starting an online payment"
      }
  where
    manualConflict checkoutId = rawSql
      "SELECT 1::bigint FROM commerce_manual_payment_evidence\
      \ WHERE checkout_id = ?::uuid\
      \ AND status IN ('submitted','under_review','approved') LIMIT 1"
      [PersistText checkoutId]

createMarketplaceCheckout
  :: Checkout.CheckoutEnvironment
  -> UTCTime
  -> UTCTime
  -> Text
  -> Text
  -> Text
  -> Text
  -> Text
  -> Text
  -> Text
  -> Maybe Text
  -> Key ME.MarketplaceCart
  -> MarketplaceCheckoutReq
  -> SqlPersistT IO (Either ServerError MarketplaceSaleCheckoutContext)
createMarketplaceCheckout checkoutEnvironment now holdExpiresAt idempotencyKey requestHash lookupToken lookupHash methodText buyerNameTxt buyerEmailTxt buyerPhoneTxt cartKey payload = do
      _ <- (rawSql "SELECT marketplace_expire_sale_holds(?)"
        [PersistUTCTime now] :: SqlPersistT IO [Single Int])
      _ <- (rawSql
        "SELECT asset.id::text FROM marketplace_cart cart\
        \ JOIN marketplace_cart_item item ON item.cart_id = cart.id\
        \ JOIN marketplace_listing listing ON listing.id = item.listing_id\
        \ JOIN asset ON asset.id = listing.asset_id\
        \ WHERE cart.id = ?::uuid FOR UPDATE OF cart, item, listing, asset"
        [PersistText (toPathPiece cartKey)] :: SqlPersistT IO [Single Text])
      cartTotalsState <- loadCartTotals cartKey
      case requireMarketplaceCartTotals cartTotalsState of
        Left serverErr -> pure (Left serverErr)
        Right (cartItems, totalCentsRaw, currency) -> do
          case resolveMarketplaceCartKind cartItems of
            Left serverErr -> pure (Left serverErr)
            Right orderKind -> do
              let domainFlag = case orderKind of
                    MarketplaceCartSale -> "marketplace_sales"
                    MarketplaceCartRental -> "marketplace_rentals"
                  domainType = case orderKind of
                    MarketplaceCartSale -> "marketplace_sale"
                    MarketplaceCartRental -> "marketplace_rental"
                  orderKindText = case orderKind of
                    MarketplaceCartSale -> "sale"
                    MarketplaceCartRental -> "rental"
              domainEnabled <- Checkout.domainEnabledForEnvironment checkoutEnvironment domainFlag
              if not domainEnabled
                then pure (Left err503
                  { errBody = BL.fromStrict . TE.encodeUtf8 $
                      "Marketplace " <> orderKindText <> " checkout is disabled in this environment"
                  })
                else case validateMarketplaceCartForCheckout (utctDay now) orderKind payload cartItems of
                  Left serverErr -> pure (Left serverErr)
                  Right () -> do
                    availability <- validateMarketplaceRentalAvailability orderKind cartItems
                    case availability of
                      Left serverErr -> pure (Left serverErr)
                      Right () -> do {
              case validateMarketplaceOnlinePaymentTotal totalCentsRaw of
                Left serverErr -> pure (Left serverErr)
                Right totalCents -> do
                  let orderRecord = ME.MarketplaceOrder
                        { ME.marketplaceOrderCartId = Just cartKey
                        , ME.marketplaceOrderBuyerName = buyerNameTxt
                        , ME.marketplaceOrderBuyerEmail = buyerEmailTxt
                        , ME.marketplaceOrderBuyerPhone = buyerPhoneTxt
                        , ME.marketplaceOrderTotalUsdCents = totalCents
                        , ME.marketplaceOrderCurrency = currency
                        , ME.marketplaceOrderStatus = "awaiting_payment"
                        , ME.marketplaceOrderPaymentProvider = Nothing
                        , ME.marketplaceOrderStripePaymentIntentId = Nothing
                        , ME.marketplaceOrderStripeIdempotencyKey = Nothing
                        , ME.marketplaceOrderPaypalOrderId = Nothing
                        , ME.marketplaceOrderPaypalPayerEmail = Nothing
                        , ME.marketplaceOrderDatafastCheckoutId = Nothing
                        , ME.marketplaceOrderDatafastResourcePath = Nothing
                        , ME.marketplaceOrderDatafastPaymentId = Nothing
                        , ME.marketplaceOrderDatafastResultCode = Nothing
                        , ME.marketplaceOrderDatafastResultDescription = Nothing
                        , ME.marketplaceOrderDatafastPaymentBrand = Nothing
                        , ME.marketplaceOrderDatafastAuthCode = Nothing
                        , ME.marketplaceOrderDatafastAcquirerCode = Nothing
                        , ME.marketplaceOrderPaidAt = Nothing
                        , ME.marketplaceOrderCreatedAt = now
                        , ME.marketplaceOrderUpdatedAt = now
                        }
                  orderKey <- insert orderRecord
                  forM_ cartItems $ \line -> do
                    let listingEnt = mclListing line
                        unitPrice = mclUnitPriceCents line
                    void $ insert ME.MarketplaceOrderItem
                      { ME.marketplaceOrderItemOrderId = orderKey
                      , ME.marketplaceOrderItemListingId = entityKey listingEnt
                      , ME.marketplaceOrderItemQuantity = mclQuantity line
                      , ME.marketplaceOrderItemUnitPriceUsdCents = unitPrice
                      , ME.marketplaceOrderItemSubtotalUsdCents = mclSubtotalCents line
                      }
                  let checkoutSnapshot = object
                        [ "domain" .= domainType
                        , "order_id" .= toPathPiece orderKey
                        , "cart_id" .= toPathPiece cartKey
                        , "currency" .= currency
                        , "total_minor" .= totalCents
                        , "fulfillment_method" .= methodText
                        , "shipping_address" .= mcrShippingAddress payload
                        ]
                      checkoutLines = map marketplaceCheckoutLine cartItems
                  checkout <- Checkout.createCheckoutWithLines Checkout.CheckoutCreation
                    { Checkout.ccDomainType = domainType
                    , Checkout.ccDomainOrderId = toPathPiece orderKey
                    , Checkout.ccEnvironment = checkoutEnvironment
                    , Checkout.ccCurrency = currency
                    , Checkout.ccAmountMinor = fromIntegral totalCents
                    , Checkout.ccCustomerEmail = buyerEmailTxt
                    , Checkout.ccLookupTokenHash = lookupHash
                    , Checkout.ccIdempotencyKey = idempotencyKey
                    , Checkout.ccExpiresAt = holdExpiresAt
                    , Checkout.ccProductType = "marketplace_cart"
                    , Checkout.ccProductId = toPathPiece cartKey
                    , Checkout.ccProductVersion = T.pack
                        (formatTime defaultTimeLocale "%Y-%m-%dT%H:%M:%S%QZ" now)
                    , Checkout.ccDescription = case orderKind of
                        MarketplaceCartSale -> "TDF equipment sale"
                        MarketplaceCartRental -> "TDF equipment rental"
                    , Checkout.ccSnapshot = checkoutSnapshot
                    , Checkout.ccCorrelationId = "marketplace-order:" <> toPathPiece orderKey
                    } checkoutLines
                  case orderKind of
                    MarketplaceCartSale -> insertMarketplaceRuntime
                      orderKey checkout lookupHash idempotencyKey requestHash methodText
                      buyerNameTxt buyerPhoneTxt holdExpiresAt (mcrShippingAddress payload)
                    MarketplaceCartRental -> insertMarketplaceRentalRuntime
                      orderKey checkout lookupHash idempotencyKey requestHash methodText
                      buyerNameTxt buyerPhoneTxt holdExpiresAt (mcrShippingAddress payload)
                      payload cartItems
                  forM_ cartItems $ \line ->
                    rawExecute
                      "INSERT INTO commerce_reservation_hold(\
                      \ checkout_id, resource_type, resource_id, quantity, status, expires_at\
                      \) VALUES (?::uuid, ?, ?, 1, 'active', ?)"
                      [ PersistText (Checkout.checkoutReferenceId checkout)
                      , PersistText (case orderKind of
                          MarketplaceCartSale -> "marketplace_asset_sale"
                          MarketplaceCartRental -> "marketplace_asset_rental")
                      , PersistText (toPathPiece (entityKey (mclAsset line)))
                      , PersistUTCTime holdExpiresAt
                      ]
                  pure (Right MarketplaceSaleCheckoutContext
                    { msccOrderKey = orderKey
                    , msccCheckout = checkout
                    , msccEnvironment = checkoutEnvironment
                    , msccLookupToken = lookupToken
                    , msccIdempotencyKey = idempotencyKey
                    , msccCreated = True
                    , msccTotalCents = totalCents
                    , msccCurrency = currency
                    , msccOrderKind = orderKindText
                    })
              }

marketplaceCheckoutLine
  :: MarketplaceCartLine
  -> Checkout.CheckoutLineCreation
marketplaceCheckoutLine line =
  let listing = entityVal listingEnt
      asset = entityVal assetEnt
      listingEnt = mclListing line
      assetEnt = mclAsset line
      quantity = mclQuantity line
      mBreakdown = mclRentalBreakdown line
      mTerms = mclRentalTerms line
  in Checkout.CheckoutLineCreation
      { Checkout.clProductType = if mclPurpose line == "rent"
          then "marketplace_rental_asset" else "marketplace_asset"
      , Checkout.clProductId = toPathPiece (entityKey assetEnt)
      , Checkout.clProductVersion = T.pack
          (formatTime defaultTimeLocale "%Y-%m-%dT%H:%M:%S%QZ"
            (ME.marketplaceListingUpdatedAt listing))
      , Checkout.clDescription = ME.marketplaceListingTitle listing
      , Checkout.clQuantity = quantity
      , Checkout.clUnitAmountMinor = fromIntegral (mclSubtotalCents line)
      , Checkout.clSnapshot = object
          [ "listing_id" .= toPathPiece (entityKey listingEnt)
          , "asset_id" .= toPathPiece (entityKey assetEnt)
          , "title" .= ME.marketplaceListingTitle listing
          , "purpose" .= ME.marketplaceListingPurpose listing
          , "asset_category" .= ME.assetCategory asset
          , "asset_brand" .= ME.assetBrand asset
          , "asset_model" .= ME.assetModel asset
          , "daily_rate_minor" .= mclUnitPriceCents line
          , "line_total_minor" .= mclSubtotalCents line
          , "currency" .= ME.marketplaceListingCurrency listing
          , "rental_start_date" .= mclRentalStartDate line
          , "rental_end_date" .= mclRentalEndDate line
          , "rental_duration_days" .= (MarketplaceRentals.rpbDurationDays <$> mBreakdown)
          , "rental_charge_minor" .= (MarketplaceRentals.rpbRentalChargeMinor <$> mBreakdown)
          , "security_deposit_minor" .= (MarketplaceRentals.rpbSecurityDepositMinor <$> mBreakdown)
          , "rental_terms_version" .= (mrtTermsVersion <$> mTerms)
          , "rental_timezone" .= (mrtTimezone <$> mTerms)
          ]
      }

insertMarketplaceRuntime
  :: Key ME.MarketplaceOrder
  -> Checkout.CheckoutReference
  -> Text
  -> Text
  -> Text
  -> Text
  -> Text
  -> Maybe Text
  -> UTCTime
  -> Maybe MarketplaceShippingAddress
  -> SqlPersistT IO ()
insertMarketplaceRuntime orderKey checkout lookupHash idempotencyKey requestHash methodText recipientName recipientPhone holdExpiresAt mAddress = do
  rawExecute
    "INSERT INTO marketplace_sale_order_runtime(\
    \ order_id, checkout_id, lookup_token_hash, create_idempotency_key,\
    \ create_request_sha256, fulfillment_method, fulfillment_status, recipient_name,\
    \ recipient_phone, address_line_1, address_line_2, city, province, postal_code,\
    \ country_code, hold_expires_at\
    \) VALUES (?::uuid, ?::uuid, ?, ?, ?, ?, 'on_hold', ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    [ PersistText (toPathPiece orderKey)
    , PersistText (Checkout.checkoutReferenceId checkout)
    , PersistText lookupHash
    , PersistText idempotencyKey
    , PersistText requestHash
    , PersistText methodText
    , PersistText recipientName
    , maybe PersistNull PersistText recipientPhone
    , maybe PersistNull (PersistText . msaAddressLine1) mAddress
    , maybe PersistNull (maybe PersistNull PersistText . msaAddressLine2) mAddress
    , maybe PersistNull (PersistText . msaCity) mAddress
    , maybe PersistNull (PersistText . msaProvince) mAddress
    , maybe PersistNull (maybe PersistNull PersistText . msaPostalCode) mAddress
    , maybe PersistNull (PersistText . msaCountryCode) mAddress
    , PersistUTCTime holdExpiresAt
    ]
  rawExecute
    "INSERT INTO marketplace_sale_fulfillment_event(\
    \ order_id, from_status, to_status, actor_type, reason_code, notes\
    \) VALUES (?::uuid, NULL, 'on_hold', 'system', 'checkout_created',\
    \ 'Asset hold created; payment and fulfillment remain separate')"
    [PersistText (toPathPiece orderKey)]

data MarketplaceCartKind = MarketplaceCartSale | MarketplaceCartRental
  deriving (Eq, Show)

resolveMarketplaceCartKind :: [MarketplaceCartLine] -> Either ServerError MarketplaceCartKind
resolveMarketplaceCartKind cartItems =
  case nub (map mclPurpose cartItems) of
    ["sale"] -> Right MarketplaceCartSale
    ["rent"]
      | length cartItems == 1 -> Right MarketplaceCartRental
      | otherwise -> Left err409
          { errBody = "Each rental checkout must contain exactly one physical asset" }
    [_] -> Left err409 { errBody = "Marketplace cart purpose is not supported" }
    _ -> Left err409 { errBody = "Sales and rentals must use separate carts" }

validateMarketplaceCartForCheckout
  :: Day
  -> MarketplaceCartKind
  -> MarketplaceCheckoutReq
  -> [MarketplaceCartLine]
  -> Either ServerError ()
validateMarketplaceCartForCheckout today orderKind payload cartItems = do
  forM_ cartItems $ \line -> do
    let listing = entityVal (mclListing line)
        asset = entityVal (mclAsset line)
    unless (ME.marketplaceListingActive listing) (Left marketplaceListingNotFound)
    unless (mclQuantity line == 1) $ Left err409
      { errBody = "Each physical marketplace asset can only appear once" }
    case orderKind of
      MarketplaceCartSale -> do
        unless (mclPurpose line == "sale") $ Left err409
          { errBody = "Rental listings require the dedicated dated rental checkout" }
        unless (ME.assetStatus asset == ME.Active) $ Left err409
          { errBody = "A marketplace asset is no longer available for sale" }
      MarketplaceCartRental -> do
        unless (mclPurpose line == "rent") $ Left err409
          { errBody = "A rental checkout cannot contain sale listings" }
        unless (ME.assetStatus asset `elem` [ME.Active, ME.Booked]) $ Left err409
          { errBody = "A marketplace asset is unavailable for rental" }
        startDate <- maybe
          (Left err409 { errBody = "Rental cart item is missing its start date" })
          Right
          (mclRentalStartDate line)
        when (startDate < today) $ Left err409
          { errBody = "Rental start date is now in the past; choose new dates" }
        unless (isJust (mclRentalEndDate line)
            && isJust (mclRentalBreakdown line)
            && isJust (mclRentalTerms line)) $
          Left err409 { errBody = "Rental price or approved terms are incomplete" }
  case orderKind of
    MarketplaceCartSale -> when
      (isJust (mcrRentalTermsAccepted payload)
        || isJust (mcrIdentityDocumentType payload)
        || isJust (mcrIdentityDocumentNumber payload)) $
      Left err400 { errBody = "Sale checkout must not include rental identity or terms fields" }
    MarketplaceCartRental -> do
      unless (mcrRentalTermsAccepted payload == Just True) $ Left err400
        { errBody = "Rental terms must be explicitly accepted" }
      when (isNothing (mcrBuyerPhone payload)) $ Left err400
        { errBody = "Rental checkout requires a verified-format contact phone" }
      void (validateMarketplaceRentalIdentity payload)

validateMarketplaceRentalIdentity
  :: MarketplaceCheckoutReq
  -> Either ServerError (Text, Text)
validateMarketplaceRentalIdentity MarketplaceCheckoutReq{..} = do
  documentType <- case T.toLower . T.strip <$> mcrIdentityDocumentType of
    Just value | value `elem` ["cedula", "passport", "ruc"] -> Right value
    _ -> Left err400 { errBody = "Rental identity document type must be cedula, passport, or ruc" }
  rawNumber <- maybe
    (Left err400 { errBody = "Rental identity document number is required" })
    Right
    mcrIdentityDocumentNumber
  let normalizedNumber = T.toUpper (T.strip rawNumber)
      canonicalNumber = T.filter isAlphaNum normalizedNumber
      validInputCharacter ch = isAlphaNum ch || ch `elem` ("- ." :: String)
  unless (T.length canonicalNumber >= 5
      && T.length canonicalNumber <= 32
      && T.all validInputCharacter normalizedNumber
      && T.all isAscii canonicalNumber) $
    Left err400 { errBody = "Rental identity document number is invalid" }
  pure (documentType, T.takeEnd 4 canonicalNumber)

validateMarketplaceRentalAvailability
  :: MarketplaceCartKind
  -> [MarketplaceCartLine]
  -> SqlPersistT IO (Either ServerError ())
validateMarketplaceRentalAvailability MarketplaceCartSale _ = pure (Right ())
validateMarketplaceRentalAvailability MarketplaceCartRental [line] =
  case (mclRentalStartDate line, mclRentalEndDate line) of
    (Just startDate, Just endDate) -> do
      overlaps <- (rawSql
        "SELECT 1::bigint FROM marketplace_rental_order_runtime\
        \ WHERE asset_id = ?::uuid\
        \ AND rental_status IN ('on_hold','confirmed','ready_for_handoff','checked_out',\
        \ 'return_due','returned_pending_inspection','damage_review','deposit_refund_due',\
        \ 'lost','disputed')\
        \ AND daterange(start_date, end_date, '[]') && daterange(?::date, ?::date, '[]')\
        \ LIMIT 1"
        [ PersistText (toPathPiece (entityKey (mclAsset line)))
        , PersistDay startDate
        , PersistDay endDate
        ] :: SqlPersistT IO [Single Int64])
      pure $ if null overlaps
        then Right ()
        else Left err409 { errBody = "The rental asset is already held for the selected dates" }
    _ -> pure (Left err409 { errBody = "Rental dates are missing" })
validateMarketplaceRentalAvailability MarketplaceCartRental _ =
  pure (Left err409 { errBody = "Each rental checkout must contain exactly one asset" })

insertMarketplaceRentalRuntime
  :: Key ME.MarketplaceOrder
  -> Checkout.CheckoutReference
  -> Text
  -> Text
  -> Text
  -> Text
  -> Text
  -> Maybe Text
  -> UTCTime
  -> Maybe MarketplaceShippingAddress
  -> MarketplaceCheckoutReq
  -> [MarketplaceCartLine]
  -> SqlPersistT IO ()
insertMarketplaceRentalRuntime orderKey checkout lookupHash idempotencyKey requestHash methodText recipientName recipientPhone holdExpiresAt mAddress payload [line] =
  case (mclRentalStartDate line, mclRentalEndDate line, mclRentalBreakdown line, mclRentalTerms line) of
    (Just startDate, Just endDate, Just breakdown, Just terms) -> do
      (documentType, last4) <-
        either (liftIO . throwIO) pure (validateMarketplaceRentalIdentity payload)
      rawExecute
        "INSERT INTO marketplace_rental_order_runtime(\
        \ order_id, checkout_id, listing_id, asset_id, lookup_token_hash,\
        \ create_idempotency_key, create_request_sha256, fulfillment_method,\
        \ rental_status, deposit_status, start_date, end_date, duration_days, timezone,\
        \ daily_rate_usd_cents, weekly_rate_usd_cents, rental_charge_usd_cents,\
        \ security_deposit_usd_cents, late_fee_usd_cents, terms_version, terms_accepted_at,\
        \ identity_document_type, identity_document_last4,\
        \ recipient_name, recipient_phone, address_line_1, address_line_2, city, province,\
        \ postal_code, country_code, hold_expires_at\
        \) VALUES (?::uuid, ?::uuid, ?::uuid, ?::uuid, ?, ?, ?, ?, 'on_hold',\
        \ 'awaiting_payment', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        [ PersistText (toPathPiece orderKey)
        , PersistText (Checkout.checkoutReferenceId checkout)
        , PersistText (toPathPiece (entityKey (mclListing line)))
        , PersistText (toPathPiece (entityKey (mclAsset line)))
        , PersistText lookupHash
        , PersistText idempotencyKey
        , PersistText requestHash
        , PersistText methodText
        , PersistDay startDate
        , PersistDay endDate
        , PersistInt64 (fromIntegral (MarketplaceRentals.rpbDurationDays breakdown))
        , PersistText (mrtTimezone terms)
        , PersistInt64 (fromIntegral (mrtDailyRateCents terms))
        , maybe PersistNull (PersistInt64 . fromIntegral) (mrtWeeklyRateCents terms)
        , PersistInt64 (fromIntegral (MarketplaceRentals.rpbRentalChargeMinor breakdown))
        , PersistInt64 (fromIntegral (MarketplaceRentals.rpbSecurityDepositMinor breakdown))
        , PersistInt64 (fromIntegral (mrtLateFeeCents terms))
        , PersistText (mrtTermsVersion terms)
        , PersistText documentType
        , PersistText last4
        , PersistText recipientName
        , maybe PersistNull PersistText recipientPhone
        , maybe PersistNull (PersistText . msaAddressLine1) mAddress
        , maybe PersistNull (maybe PersistNull PersistText . msaAddressLine2) mAddress
        , maybe PersistNull (PersistText . msaCity) mAddress
        , maybe PersistNull (PersistText . msaProvince) mAddress
        , maybe PersistNull (maybe PersistNull PersistText . msaPostalCode) mAddress
        , maybe PersistNull (PersistText . msaCountryCode) mAddress
        , PersistUTCTime holdExpiresAt
        ]
      rawExecute
        "INSERT INTO marketplace_rental_event(\
        \ order_id, from_status, to_status, actor_type, reason_code, notes\
        \) VALUES (?::uuid, NULL, 'on_hold', 'system', 'checkout_created',\
        \ 'Date-aware asset hold created; payment, custody, and deposit settlement remain separate')"
        [PersistText (toPathPiece orderKey)]
    _ -> liftIO $ throwIO (marketplaceCheckoutInternal "Rental checkout snapshot is incomplete")
insertMarketplaceRentalRuntime _ _ _ _ _ _ _ _ _ _ _ _ =
  liftIO $ throwIO (marketplaceCheckoutInternal "Rental checkout must contain exactly one asset")

validateMarketplaceShippingAddress
  :: MarketplaceSales.MarketplaceFulfillmentMethod
  -> Maybe MarketplaceShippingAddress
  -> AppM ()
validateMarketplaceShippingAddress MarketplaceSales.MarketplacePickup _ = pure ()
validateMarketplaceShippingAddress _ Nothing =
  throwError err400 { errBody = "Shipping address is required for delivery and shipping" }
validateMarketplaceShippingAddress _ (Just _) = pure ()

loadMarketplaceCheckoutEnvironment :: AppM Checkout.CheckoutEnvironment
loadMarketplaceCheckoutEnvironment = do
  rawEnvironment <- liftIO $ lookupEnv "COMMERCE_CHECKOUT_ENV"
  either (throwError . marketplaceCheckoutInternal) pure
    (Checkout.resolveCheckoutEnvironment rawEnvironment)

loadMarketplaceOrderWithLookup
  :: MarketplaceSaleCheckoutContext
  -> AppM MarketplaceOrderDTO
loadMarketplaceOrderWithLookup MarketplaceSaleCheckoutContext{..} = do
  Env{ envPool } <- ask
  mDto <- liftIO $ flip runSqlPool envPool $ loadOrderDTO msccOrderKey
  orderDto <- either throwError pure
    (requireLoadedMarketplaceWriteResult "Marketplace order" mDto)
  pure orderDto { moLookupToken = Just msccLookupToken }

sendMarketplaceOrderCreatedEmail :: MarketplaceOrderDTO -> AppM ()
sendMarketplaceOrderCreatedEmail orderDto = do
  env <- ask
  let emailSvc = EmailSvc.mkEmailService (envConfig env)
      itemsSummary = map
        (\oi -> T.pack (show (moiQuantity oi)) <> " × " <> moiTitle oi <> " — " <> moiSubtotalDisplay oi)
        (moItems orderDto)
  liftIO $ void $ forkIO $ do
    _ <- (try $
      EmailSvc.sendMarketplaceOrder
        emailSvc
        (moBuyerName orderDto)
        (moBuyerEmail orderDto)
        (moOrderId orderDto)
        (moTotalDisplay orderDto)
        itemsSummary) :: IO (Either SomeException ())
    pure ()

marketplaceSha256Text :: Text -> Text
marketplaceSha256Text value =
  TE.decodeUtf8
    (BAE.convertToBase BAE.Base16
      (hash (TE.encodeUtf8 value) :: Digest SHA256))

marketplaceCheckoutBadRequest :: Text -> ServerError
marketplaceCheckoutBadRequest message =
  err400 { errBody = BL.fromStrict (TE.encodeUtf8 message) }

marketplaceCheckoutConflict :: Text -> ServerError
marketplaceCheckoutConflict message =
  err409 { errBody = BL.fromStrict (TE.encodeUtf8 message) }

marketplaceCheckoutInternal :: Text -> ServerError
marketplaceCheckoutInternal message =
  err500 { errBody = BL.fromStrict (TE.encodeUtf8 message) }

createMarketplaceStripePaymentIntent :: Text -> Maybe Text -> MarketplaceCheckoutReq -> AppM StripePaymentIntentDTO
createMarketplaceStripePaymentIntent _ _ _ =
  throwError err503
    { errBody = "Stripe marketplace checkout is disabled until it uses the canonical verified-payment runtime; use Datafast or PayPal"
    }

createLegacyMarketplaceStripePaymentIntent :: Text -> Maybe Text -> MarketplaceCheckoutReq -> AppM StripePaymentIntentDTO
createLegacyMarketplaceStripePaymentIntent rawId _ payload = do
  nameTxt <- either throwError pure (validateMarketplaceBuyerName (mcrBuyerName payload))
  emailTxt <- either throwError pure (validateMarketplaceBuyerEmail (mcrBuyerEmail payload))
  phoneTxt <- either throwError pure (validateMarketplaceBuyerPhone (mcrBuyerPhone payload))
  cartKey <- parseCartId rawId
  now <- liftIO getCurrentTime
  Env{..} <- ask
  stripeCfg <- case (stripeSecretKey envConfig, stripeWebhookSecret envConfig) of
    (Just secretKey, Just webhookSecret) ->
      pure Stripe.StripeConfig
        { Stripe.stripeSecretKey = secretKey
        , Stripe.stripeWebhookSecret = webhookSecret
        , Stripe.stripeApiVersion = Stripe.defaultStripeApiVersion
        }
    _ -> throwError err500 { errBody = "Stripe is not configured" }
  existingPendingOrder <- liftIO $ flip runSqlPool envPool $
    selectFirst
      [ ME.MarketplaceOrderCartId ==. Just cartKey
      , ME.MarketplaceOrderStatus ==. "stripe_pending"
      ]
      [Desc ME.MarketplaceOrderCreatedAt]
  orderEntity <- case existingPendingOrder of
    Just pendingOrder -> pure pendingOrder
    Nothing -> do
      cartTotalsState <- liftIO $ flip runSqlPool envPool $ loadCartTotals cartKey
      (cartItems, totalCentsRaw, currency) <-
        either throwError pure (requireMarketplaceCartTotals cartTotalsState)
      totalCents <-
        either throwError pure (validateMarketplaceOnlinePaymentTotal totalCentsRaw)
      let orderRecord = ME.MarketplaceOrder
            { ME.marketplaceOrderCartId        = Just cartKey
            , ME.marketplaceOrderBuyerName     = nameTxt
            , ME.marketplaceOrderBuyerEmail    = emailTxt
            , ME.marketplaceOrderBuyerPhone    = phoneTxt
            , ME.marketplaceOrderTotalUsdCents = totalCents
            , ME.marketplaceOrderCurrency      = currency
            , ME.marketplaceOrderStatus        = "stripe_pending"
            , ME.marketplaceOrderPaymentProvider = Just "stripe"
            , ME.marketplaceOrderStripePaymentIntentId = Nothing
            , ME.marketplaceOrderStripeIdempotencyKey = Nothing
            , ME.marketplaceOrderPaypalOrderId = Nothing
            , ME.marketplaceOrderPaypalPayerEmail = Nothing
            , ME.marketplaceOrderDatafastCheckoutId = Nothing
            , ME.marketplaceOrderDatafastResourcePath = Nothing
            , ME.marketplaceOrderDatafastPaymentId = Nothing
            , ME.marketplaceOrderDatafastResultCode = Nothing
            , ME.marketplaceOrderDatafastResultDescription = Nothing
            , ME.marketplaceOrderDatafastPaymentBrand = Nothing
            , ME.marketplaceOrderDatafastAuthCode = Nothing
            , ME.marketplaceOrderDatafastAcquirerCode = Nothing
            , ME.marketplaceOrderPaidAt        = Nothing
            , ME.marketplaceOrderCreatedAt     = now
            , ME.marketplaceOrderUpdatedAt     = now
            }
          insertOrder = flip runSqlPool envPool $ do
            oid <- insert orderRecord
            let idempotencyKey = marketplaceStripeIdempotencyKey oid
                persistedOrder =
                  orderRecord
                    { ME.marketplaceOrderStripeIdempotencyKey = Just idempotencyKey
                    }
            update oid [ME.MarketplaceOrderStripeIdempotencyKey =. Just idempotencyKey]
            forM_ cartItems $ \line -> do
              let listingEnt = mclListing line
                  unitPrice = mclUnitPriceCents line
                  subtotal = mclSubtotalCents line
              void $ insert ME.MarketplaceOrderItem
                { ME.marketplaceOrderItemOrderId           = oid
                , ME.marketplaceOrderItemListingId         = entityKey listingEnt
                , ME.marketplaceOrderItemQuantity          = mclQuantity line
                , ME.marketplaceOrderItemUnitPriceUsdCents = unitPrice
                , ME.marketplaceOrderItemSubtotalUsdCents  = subtotal
                }
            pure (Entity oid persistedOrder)
      insertResult <- liftIO $
        (try insertOrder :: IO (Either SomeException (Entity ME.MarketplaceOrder)))
      case insertResult of
        Right insertedOrder -> pure insertedOrder
        Left insertErr -> do
          case fromException insertErr :: Maybe SomeAsyncException of
            Just _ -> liftIO (throwIO insertErr)
            Nothing
              | isMarketplaceActiveStripeOrderConflict insertErr -> do
                  concurrentWinner <- liftIO $ flip runSqlPool envPool $
                    selectFirst
                      [ ME.MarketplaceOrderCartId ==. Just cartKey
                      , ME.MarketplaceOrderStatus ==. "stripe_pending"
                      ]
                      [Desc ME.MarketplaceOrderCreatedAt]
                  maybe (liftIO (throwIO insertErr)) pure concurrentWinner
              | otherwise -> liftIO (throwIO insertErr)
  let orderKey = entityKey orderEntity
      order = entityVal orderEntity
  unless (ME.marketplaceOrderPaymentProvider order == Just "stripe") $
    throwError err409
      { errBody = "Active marketplace payment is not a Stripe payment"
      }
  unless
    ( ME.marketplaceOrderBuyerName order == nameTxt
        && ME.marketplaceOrderBuyerEmail order == emailTxt
        && ME.marketplaceOrderBuyerPhone order == phoneTxt
    ) $
      throwError err409
        { errBody = "A Stripe payment is already pending for different buyer details"
        }
  totalCents <- either throwError pure $
    validateMarketplaceOnlinePaymentTotal (ME.marketplaceOrderTotalUsdCents order)
  currency <- either throwError pure $
    validateStoredMarketplaceOrderCurrency (ME.marketplaceOrderCurrency order)
  let orderIdText = toPathPiece orderKey
      description = "Marketplace order " <> orderIdText
      metadata =
        object
          [ "purpose" .= ("marketplace_order" :: Text)
          , "marketplace_order_id" .= orderIdText
          , "cart_id" .= toPathPiece cartKey
          ]
      metadataJson = Just (TE.decodeUtf8 (BL.toStrict (encode metadata)))
      expectedIdempotencyKey = marketplaceStripeIdempotencyKey orderKey
      storedIdempotencyKey = ME.marketplaceOrderStripeIdempotencyKey order
      storedPaymentIntentId = ME.marketplaceOrderStripePaymentIntentId order
      stripeRequest =
        case storedPaymentIntentId of
          Just paymentIntentId ->
            Stripe.retrievePaymentIntent stripeCfg paymentIntentId
          Nothing ->
            Stripe.createPaymentIntentWithIdempotencyKey
              stripeCfg
              expectedIdempotencyKey
              totalCents
              currency
              description
              metadataJson
  when (isNothing storedPaymentIntentId) $
    unless
      ( canReplayMarketplaceStripePost
          now
          (ME.marketplaceOrderCreatedAt order)
          expectedIdempotencyKey
          storedIdempotencyKey
      ) $
      throwError err409
        { errBody = "Stripe payment attempt requires manual reconciliation"
        }
  requestResult <- liftIO $
    (try stripeRequest :: IO (Either SomeException (Either Text Value)))
  stripeResult <- case requestResult of
    Right result -> pure result
    Left requestErr ->
      case fromException requestErr :: Maybe SomeAsyncException of
        Just _ -> liftIO (throwIO requestErr)
        Nothing ->
          throwError err502
            { errBody = "Stripe marketplace request failed"
            }
  paymentIntent <- case stripeResult of
    Left err ->
      throwError err502
        { errBody = BL.fromStrict (TE.encodeUtf8 ("Stripe marketplace error: " <> err))
        }
    Right value -> pure value
  (piId, clientSecret) <-
    case parseStripePaymentIntentResponse paymentIntent of
      Left parseErr ->
        throwError err502
          { errBody = BL.fromStrict (TE.encodeUtf8 parseErr)
          }
      Right parsed -> pure parsed
  case storedPaymentIntentId of
    Just storedPiId ->
      unless (piId == storedPiId) $
        throwError err502
          { errBody = "Stripe returned an unexpected PaymentIntent"
          }
    Nothing -> do
      now2 <- liftIO getCurrentTime
      persistedOrder <- liftIO $
        flip runSqlPool envPool $ do
          updateWhere
            [ ME.MarketplaceOrderId ==. orderKey
            , ME.MarketplaceOrderStatus ==. "stripe_pending"
            , ME.MarketplaceOrderPaymentProvider ==. Just "stripe"
            , ME.MarketplaceOrderStripePaymentIntentId ==. Nothing
            ]
            [ ME.MarketplaceOrderStripePaymentIntentId =. Just piId
            , ME.MarketplaceOrderUpdatedAt =. now2
            ]
          get orderKey
      unless
        ((ME.marketplaceOrderStripePaymentIntentId <$> persistedOrder) == Just (Just piId)) $
          throwError err409
            { errBody = "Stripe payment state changed while creating the PaymentIntent"
            }
  pure StripePaymentIntentDTO
    { spiClientSecret = clientSecret
    , spiOrderId = orderIdText
    , spiAmountCents = totalCents
    , spiCurrency = currency
    , spiPaymentSheet = Nothing
    , spiLookupToken = Nothing
    }

isMarketplaceStripeRetryStale :: UTCTime -> UTCTime -> Bool
isMarketplaceStripeRetryStale currentTime createdAt =
  diffUTCTime currentTime createdAt >= 23 * 60 * 60

canReplayMarketplaceStripePost :: UTCTime -> UTCTime -> Text -> Maybe Text -> Bool
canReplayMarketplaceStripePost currentTime createdAt expectedKey storedKey =
  storedKey == Just expectedKey
    && not (isMarketplaceStripeRetryStale currentTime createdAt)

marketplaceStripeIdempotencyKey :: Key ME.MarketplaceOrder -> Text
marketplaceStripeIdempotencyKey orderKey =
  "tdf-marketplace-order-" <> toPathPiece orderKey

isMarketplaceActiveStripeOrderConflict :: SomeException -> Bool
isMarketplaceActiveStripeOrderConflict exception =
  case fromException exception of
    Just sqlErr ->
      sqlState sqlErr == "23505"
        && "uq_marketplace_cart_active_stripe_payment"
          `BS8.isInfixOf` (sqlErrorMsg sqlErr <> " " <> sqlErrorDetail sqlErr)
    Nothing -> False

createDatafastCheckout :: Text -> Maybe Text -> MarketplaceCheckoutReq -> AppM DatafastCheckoutDTO
createDatafastCheckout rawId mIdempotency payload = do
  context <- prepareMarketplaceSaleCheckout "datafast" rawId mIdempotency payload
  dfEnv <- loadDatafastEnv
  unless (dfEnvironment dfEnv == msccEnvironment context) $
    throwError err500
      { errBody = "DATAFAST_ENV must match COMMERCE_CHECKOUT_ENV for marketplace checkout"
      }
  now <- liftIO getCurrentTime
  Env{ envPool } <- ask
  providerEnabled <- liftIO $ flip runSqlPool envPool $
    Checkout.providerEnabledForEnvironment (msccEnvironment context) Checkout.ProviderDatafast
  unless providerEnabled $
    throwError err503 { errBody = "Datafast checkout is disabled in this environment" }
  attemptResult <- liftIO $ flip runSqlPool envPool $
    PaymentRuntime.beginPaymentAttempt Checkout.PaymentAttemptCreation
      { Checkout.pacCheckout = msccCheckout context
      , Checkout.pacProvider = Checkout.ProviderDatafast
      , Checkout.pacEnvironment = msccEnvironment context
      , Checkout.pacOperation = Checkout.OperationCreate
      , Checkout.pacAmountMinor = fromIntegral (msccTotalCents context)
      , Checkout.pacCurrency = msccCurrency context
      , Checkout.pacMerchantRef = dfEntityId dfEnv
      , Checkout.pacIdempotencyKey = msccIdempotencyKey context
      , Checkout.pacCreatedAt = now
      , Checkout.pacCorrelationId = "marketplace-datafast:" <> toPathPiece (msccOrderKey context)
      }
  attempt <- either (throwError . marketplaceCheckoutConflict) pure attemptResult
  mOrder <- liftIO $ flip runSqlPool envPool $ get (msccOrderKey context)
  order <- maybe (throwError marketplaceOrderNotFound) pure mOrder
  (checkoutId, widgetUrl) <- case ME.marketplaceOrderDatafastCheckoutId order of
    Just storedCheckoutId -> do
      validatedCheckoutId <- either throwError pure
        (validateStoredDatafastCheckoutId storedCheckoutId)
      pure
        ( validatedCheckoutId
        , normalizeBaseUrl (dfBaseUrl dfEnv)
            <> "/v1/paymentWidgets.js?checkoutId=" <> T.unpack validatedCheckoutId
        )
    Nothing ->
      requestDatafastCheckout
        (msccOrderKey context)
        (msccTotalCents context)
        (msccCurrency context)
        (ME.marketplaceOrderBuyerName order)
        (ME.marketplaceOrderBuyerEmail order)
        (ME.marketplaceOrderBuyerPhone order)
  bindingResult <- liftIO $ flip runSqlPool envPool $ do
    result <- Checkout.bindProviderResource Checkout.ProviderBindingCreation
      { Checkout.pbcAttempt = attempt
      , Checkout.pbcCheckout = msccCheckout context
      , Checkout.pbcProvider = Checkout.ProviderDatafast
      , Checkout.pbcEnvironment = msccEnvironment context
      , Checkout.pbcMerchantRef = dfEntityId dfEnv
      , Checkout.pbcResourceType = "checkout"
      , Checkout.pbcProviderResource = checkoutId
      , Checkout.pbcResourcePath = Just
          ("/v1/checkouts/" <> checkoutId <> "/payment")
      , Checkout.pbcOrderReference = toPathPiece (msccOrderKey context)
      , Checkout.pbcAmountMinor = fromIntegral (msccTotalCents context)
      , Checkout.pbcCurrency = msccCurrency context
      , Checkout.pbcStage = Checkout.AttemptRequiresCustomerAction
      , Checkout.pbcOccurredAt = now
      , Checkout.pbcCorrelationId = "marketplace-datafast:" <> toPathPiece (msccOrderKey context)
      }
    case result of
      Left err -> pure (Left err)
      Right () -> do
        update (msccOrderKey context)
          [ ME.MarketplaceOrderStatus =. "datafast_pending"
          , ME.MarketplaceOrderPaymentProvider =. Just "datafast"
          , ME.MarketplaceOrderDatafastCheckoutId =. Just checkoutId
          , ME.MarketplaceOrderUpdatedAt =. now
          ]
        pure (Right ())
  either (throwError . marketplaceCheckoutConflict) pure bindingResult
  pure DatafastCheckoutDTO
    { dcOrderId    = toPathPiece (msccOrderKey context)
    , dcCheckoutId = checkoutId
    , dcWidgetUrl  = T.pack widgetUrl
    , dcAmount     = Internationalization.formatMinorUnitsDecimal
        (msccCurrency context) (fromIntegral (msccTotalCents context))
    , dcCurrency   = msccCurrency context
    , dcLookupToken = Just (msccLookupToken context)
    }

confirmDatafastPayment :: Maybe Text -> Maybe Text -> Maybe Text -> AppM MarketplaceOrderDTO
confirmDatafastPayment mLookupToken mOrderId mResourcePath = do
  orderKey <- case mOrderId of
    Just oid -> parseOrderId oid
    Nothing  -> throwBadRequest "orderId requerido"
  requireMarketplaceOrderLookupToken orderKey mLookupToken
  Env{ envPool } <- ask
  mOrder <- liftIO $ flip runSqlPool envPool $ get orderKey
  order <- maybe (throwError err404) pure mOrder
  resourcePathTxt <-
    either throwError pure $
      validateDatafastOrderResourcePath
        (ME.marketplaceOrderDatafastCheckoutId order)
        mResourcePath
  dfEnv <- loadDatafastEnv
  statusResp <- datafastPaymentStatus dfEnv resourcePathTxt
  now <- liftIO getCurrentTime
  code <- either throwError pure (validateDatafastResultCodeField (dfrCode (dfpResult statusResp)))
  let success = ServiceStorefront.isDatafastPaymentSuccess (dfEnvironment dfEnv) code
      pending = isDfPaymentPending code
  when success $ do
    either throwError pure $
      validateDatafastSuccessfulPaymentAmountAndCurrency
        (ME.marketplaceOrderTotalUsdCents order)
        (ME.marketplaceOrderCurrency order)
        (dfpAmount statusResp)
        (dfpCurrency statusResp)
    unless (dfpMerchantTransactionId statusResp == Just (toPathPiece orderKey)) $
      throwError err502
        { errBody = "Datafast merchant transaction reference does not match this order"
        }
  paymentId <- either throwError pure (validateOptionalDatafastPaymentIdField (dfpId statusResp))
  resultDescription <- either throwError pure $
    validateOptionalDatafastMetadataField
      "Datafast result description"
      (dfrDescription (dfpResult statusResp))
  paymentBrand <- either throwError pure $
    validateOptionalDatafastMetadataField
      "Datafast payment brand"
      (dfpPaymentBrand statusResp)
  authCode <- either throwError pure $
    validateOptionalDatafastMetadataField
      "Datafast auth code"
      (dfpResultDetails statusResp >>= dfrdAuthCode)
  acquirerCode <- either throwError pure $
    validateOptionalDatafastMetadataField
      "Datafast acquirer code"
      (dfpResultDetails statusResp >>= dfrdAcquirerCode)
  runtimeRows <- liftIO $ flip runSqlPool envPool $
    (rawSql
      "SELECT checkout_id::text, create_idempotency_key\
      \ FROM marketplace_order_checkout_runtime WHERE order_id = ?::uuid"
      [PersistText (toPathPiece orderKey)]
      :: SqlPersistT IO [(Single Text, Single Text)])
  case runtimeRows of
    [(Single canonicalCheckoutId, Single createIdempotencyKey)] -> do
      let checkout = Checkout.CheckoutReference canonicalCheckoutId
      checkoutEnvironmentResult <- liftIO $ flip runSqlPool envPool $
        Checkout.loadCheckoutEnvironment checkout
      checkoutEnvironment <- either (throwError . marketplaceCheckoutInternal) pure
        checkoutEnvironmentResult
      unless (checkoutEnvironment == dfEnvironment dfEnv) $
        throwError err500
          { errBody = "DATAFAST_ENV does not match the stored checkout environment"
          }
      attemptResult <- liftIO $ flip runSqlPool envPool $
        PaymentRuntime.beginPaymentAttempt Checkout.PaymentAttemptCreation
          { Checkout.pacCheckout = checkout
          , Checkout.pacProvider = Checkout.ProviderDatafast
          , Checkout.pacEnvironment = checkoutEnvironment
          , Checkout.pacOperation = Checkout.OperationCreate
          , Checkout.pacAmountMinor = fromIntegral (ME.marketplaceOrderTotalUsdCents order)
          , Checkout.pacCurrency = ME.marketplaceOrderCurrency order
          , Checkout.pacMerchantRef = dfEntityId dfEnv
          , Checkout.pacIdempotencyKey = createIdempotencyKey
          , Checkout.pacCreatedAt = now
          , Checkout.pacCorrelationId = "marketplace-datafast:" <> toPathPiece orderKey
          }
      attempt <- either (throwError . marketplaceCheckoutConflict) pure attemptResult
      if success
        then do
          verified <- liftIO $ flip runSqlPool envPool $
            Checkout.recordVerifiedPayment Checkout.VerifiedPayment
              { Checkout.vpAttempt = attempt
              , Checkout.vpCheckout = checkout
              , Checkout.vpProvider = Checkout.ProviderDatafast
              , Checkout.vpEnvironment = checkoutEnvironment
              , Checkout.vpMerchantRef = dfEntityId dfEnv
              , Checkout.vpResourceType = "checkout"
              , Checkout.vpProviderResource = fromMaybe "" (ME.marketplaceOrderDatafastCheckoutId order)
              , Checkout.vpProviderResourcePath = Just resourcePathTxt
              , Checkout.vpOrderReference = toPathPiece orderKey
              , Checkout.vpProviderReference = toPathPiece orderKey
              , Checkout.vpAmountMinor = fromIntegral (ME.marketplaceOrderTotalUsdCents order)
              , Checkout.vpCurrency = ME.marketplaceOrderCurrency order
              , Checkout.vpEvidence = "server_to_server"
              , Checkout.vpOccurredAt = now
              , Checkout.vpCorrelationId = "marketplace-datafast:" <> toPathPiece orderKey
              }
          either (throwError . marketplaceCheckoutConflict) (const (pure ())) verified
        else liftIO $ flip runSqlPool envPool $
          if pending
            then Checkout.recordPaymentProcessing checkout attempt Checkout.ProviderDatafast
              ("marketplace-datafast:" <> toPathPiece orderKey) now
            else Checkout.recordPaymentFailure checkout attempt Checkout.ProviderDatafast code
              ("marketplace-datafast:" <> toPathPiece orderKey) now
    [] -> pure ()
    _ -> throwError (marketplaceCheckoutInternal
      "Marketplace Datafast runtime lookup was ambiguous")
  let nextStatus
        | success = "paid"
        | pending = "datafast_pending"
        | otherwise = "datafast_failed"
      legacyPaymentFields =
        if null runtimeRows
          then [ ME.MarketplaceOrderStatus =. nextStatus
               , ME.MarketplaceOrderPaidAt =.
                   (if success then Just now else ME.marketplaceOrderPaidAt order)
               ]
          else if success
            then []
            else [ME.MarketplaceOrderStatus =. nextStatus]
      updateFields = legacyPaymentFields <>
        [ ME.MarketplaceOrderPaymentProvider =. Just "datafast"
        , ME.MarketplaceOrderUpdatedAt =. now
        , ME.MarketplaceOrderDatafastResourcePath =. Just resourcePathTxt
        , ME.MarketplaceOrderDatafastPaymentId =. paymentId
        , ME.MarketplaceOrderDatafastResultCode =. Just code
        , ME.MarketplaceOrderDatafastResultDescription =. resultDescription
        , ME.MarketplaceOrderDatafastPaymentBrand =. paymentBrand
        , ME.MarketplaceOrderDatafastAuthCode =. authCode
        , ME.MarketplaceOrderDatafastAcquirerCode =. acquirerCode
        ]
  liftIO $ flip runSqlPool envPool $ update orderKey updateFields
  mDto <- liftIO $ flip runSqlPool envPool $ loadOrderDTO orderKey
  either throwError pure $
    requireLoadedMarketplacePublicOrderResponse "Marketplace order" mDto

createPaypalOrder :: Text -> Maybe Text -> MarketplaceCheckoutReq -> AppM PaypalCreateDTO
createPaypalOrder rawId mIdempotency payload = do
  context <- prepareMarketplaceSaleCheckout "paypal" rawId mIdempotency payload
  (cid, sec, baseUrl, paypalEnvironment, merchantRef) <-
    ServiceStorefront.loadPaypalEnvForService
  unless (paypalEnvironment == msccEnvironment context) $
    throwError err500
      { errBody = "PAYPAL_ENV must match COMMERCE_CHECKOUT_ENV for marketplace checkout"
      }
  now <- liftIO getCurrentTime
  Env{ envPool } <- ask
  providerEnabled <- liftIO $ flip runSqlPool envPool $
    Checkout.providerEnabledForEnvironment (msccEnvironment context) Checkout.ProviderPayPal
  unless providerEnabled $
    throwError err503 { errBody = "PayPal checkout is disabled in this environment" }
  attemptResult <- liftIO $ flip runSqlPool envPool $
    PaymentRuntime.beginPaymentAttempt Checkout.PaymentAttemptCreation
      { Checkout.pacCheckout = msccCheckout context
      , Checkout.pacProvider = Checkout.ProviderPayPal
      , Checkout.pacEnvironment = msccEnvironment context
      , Checkout.pacOperation = Checkout.OperationCreate
      , Checkout.pacAmountMinor = fromIntegral (msccTotalCents context)
      , Checkout.pacCurrency = msccCurrency context
      , Checkout.pacMerchantRef = merchantRef
      , Checkout.pacIdempotencyKey = msccIdempotencyKey context
      , Checkout.pacCreatedAt = now
      , Checkout.pacCorrelationId = "marketplace-paypal:" <> toPathPiece (msccOrderKey context)
      }
  attempt <- either (throwError . marketplaceCheckoutConflict) pure attemptResult
  mOrder <- liftIO $ flip runSqlPool envPool $ get (msccOrderKey context)
  order <- maybe (throwError marketplaceOrderNotFound) pure mOrder
  (ppOrderId, approvalUrl) <- case ME.marketplaceOrderPaypalOrderId order of
    Just storedOrderId -> pure (storedOrderId, Nothing)
    Nothing -> ServiceStorefront.createPaypalOrderRemoteForService
      sharedProviderManager cid sec baseUrl
      (toPathPiece (msccOrderKey context))
      (msccTotalCents context)
      (msccCurrency context)
      (ME.marketplaceOrderBuyerName order)
      (ME.marketplaceOrderBuyerEmail order)
  bindingResult <- liftIO $ flip runSqlPool envPool $ do
    result <- Checkout.bindProviderResource Checkout.ProviderBindingCreation
      { Checkout.pbcAttempt = attempt
      , Checkout.pbcCheckout = msccCheckout context
      , Checkout.pbcProvider = Checkout.ProviderPayPal
      , Checkout.pbcEnvironment = msccEnvironment context
      , Checkout.pbcMerchantRef = merchantRef
      , Checkout.pbcResourceType = "order"
      , Checkout.pbcProviderResource = ppOrderId
      , Checkout.pbcResourcePath = Just ("/v2/checkout/orders/" <> ppOrderId)
      , Checkout.pbcOrderReference = toPathPiece (msccOrderKey context)
      , Checkout.pbcAmountMinor = fromIntegral (msccTotalCents context)
      , Checkout.pbcCurrency = msccCurrency context
      , Checkout.pbcStage = Checkout.AttemptRequiresCustomerAction
      , Checkout.pbcOccurredAt = now
      , Checkout.pbcCorrelationId = "marketplace-paypal:" <> toPathPiece (msccOrderKey context)
      }
    case result of
      Left err -> pure (Left err)
      Right () -> do
        update (msccOrderKey context)
          [ ME.MarketplaceOrderStatus =. "paypal_pending"
          , ME.MarketplaceOrderPaymentProvider =. Just "paypal"
          , ME.MarketplaceOrderPaypalOrderId =. Just ppOrderId
          , ME.MarketplaceOrderUpdatedAt =. now
          ]
        pure (Right ())
  either (throwError . marketplaceCheckoutConflict) pure bindingResult
  pure PaypalCreateDTO
    { pcOrderId = toPathPiece (msccOrderKey context)
    , pcPaypalOrderId = ppOrderId
    , pcApprovalUrl = approvalUrl
    , pcLookupToken = Just (msccLookupToken context)
    }

capturePaypalOrder :: Maybe Text -> PaypalCaptureReq -> AppM MarketplaceOrderDTO
capturePaypalOrder mLookupToken PaypalCaptureReq{..} = do
  orderKey <- parseOrderId pcCaptureOrderId
  requireMarketplaceOrderLookupToken orderKey mLookupToken
  paypalOrderId <- either throwError pure (validatePayPalCaptureOrderId pcCapturePaypalId)
  Env{ envPool } <- ask
  mOrder <- liftIO $ flip runSqlPool envPool $ get orderKey
  order <- maybe (throwError marketplaceOrderNotFound) pure mOrder
  paypalOrderIdForCapture <- either throwError pure $
    validatePayPalCaptureOrderReference
      (ME.marketplaceOrderPaypalOrderId order)
      paypalOrderId
  runtimeRows <- liftIO $ flip runSqlPool envPool $
    (rawSql
      "SELECT runtime.checkout_id::text, runtime.create_idempotency_key, checkout.status\
      \ FROM marketplace_order_checkout_runtime runtime\
      \ JOIN commerce_checkout_session checkout ON checkout.id = runtime.checkout_id\
      \ WHERE runtime.order_id = ?::uuid"
      [PersistText (toPathPiece orderKey)]
      :: SqlPersistT IO [(Single Text, Single Text, Single Text)])
  case runtimeRows of
    [(Single canonicalCheckoutId, Single createIdempotencyKey, Single checkoutStatus)]
      | checkoutStatus == "paid" -> do
          mDto <- liftIO $ flip runSqlPool envPool $ loadOrderDTO orderKey
          either throwError pure $
            requireLoadedMarketplacePublicOrderResponse "Marketplace order" mDto
      | otherwise -> captureCanonicalPaypalOrder
          orderKey order canonicalCheckoutId createIdempotencyKey paypalOrderIdForCapture
    [] -> captureLegacyPaypalOrder orderKey order paypalOrderIdForCapture
    _ -> throwError (marketplaceCheckoutInternal
      "Marketplace PayPal runtime lookup was ambiguous")

captureCanonicalPaypalOrder
  :: Key ME.MarketplaceOrder
  -> ME.MarketplaceOrder
  -> Text
  -> Text
  -> Text
  -> AppM MarketplaceOrderDTO
captureCanonicalPaypalOrder orderKey order canonicalCheckoutId createIdempotencyKey paypalOrderId = do
  Env{ envPool } <- ask
  now <- liftIO getCurrentTime
  (cid, sec, baseUrl, paypalEnvironment, merchantRef) <-
    ServiceStorefront.loadPaypalEnvForService
  let checkout = Checkout.CheckoutReference canonicalCheckoutId
      captureIdempotencyKey = marketplaceSha256Text ("capture:" <> createIdempotencyKey)
      correlationId = "marketplace-paypal-capture:" <> toPathPiece orderKey
  storedEnvironmentResult <- liftIO $ flip runSqlPool envPool $
    Checkout.loadCheckoutEnvironment checkout
  storedEnvironment <- either (throwError . marketplaceCheckoutInternal) pure
    storedEnvironmentResult
  unless (storedEnvironment == paypalEnvironment) $
    throwError err500
      { errBody = "PAYPAL_ENV does not match the stored checkout environment"
      }
  attemptResult <- liftIO $ flip runSqlPool envPool $
    PaymentRuntime.beginPaymentAttempt Checkout.PaymentAttemptCreation
      { Checkout.pacCheckout = checkout
      , Checkout.pacProvider = Checkout.ProviderPayPal
      , Checkout.pacEnvironment = paypalEnvironment
      , Checkout.pacOperation = Checkout.OperationCapture
      , Checkout.pacAmountMinor = fromIntegral (ME.marketplaceOrderTotalUsdCents order)
      , Checkout.pacCurrency = ME.marketplaceOrderCurrency order
      , Checkout.pacMerchantRef = merchantRef
      , Checkout.pacIdempotencyKey = captureIdempotencyKey
      , Checkout.pacCreatedAt = now
      , Checkout.pacCorrelationId = correlationId
      }
  attempt <- either (throwError . marketplaceCheckoutConflict) pure attemptResult
  outcome <- ServiceStorefront.capturePaypalOrderRemoteForService
    sharedProviderManager cid sec baseUrl paypalOrderId
    `catchError` \serverErr -> do
      liftIO $ flip runSqlPool envPool $
        Checkout.recordPaymentFailure checkout attempt Checkout.ProviderPayPal
          "paypal_capture_request" correlationId now
      throwError serverErr
  let status = ServiceStorefront.spcoStatus outcome
  case status of
    "COMPLETED" -> do
      case ServiceStorefront.validatePaypalSuccessfulCapture
        (toPathPiece orderKey)
        (ME.marketplaceOrderTotalUsdCents order)
        (ME.marketplaceOrderCurrency order)
        merchantRef
        outcome of
          Left validationMessage -> do
            liftIO $ flip runSqlPool envPool $ do
              Checkout.recordReconciliationException
                Checkout.ProviderPayPal paypalEnvironment merchantRef
                "provider_binding_mismatch" (toPathPiece orderKey) paypalOrderId
                (fromIntegral (ME.marketplaceOrderTotalUsdCents order)) Nothing
                (ME.marketplaceOrderCurrency order) now
              Checkout.recordPaymentFailure checkout attempt Checkout.ProviderPayPal
                "provider_binding_mismatch" correlationId now
            throwError err502
              { errBody = BL.fromStrict (TE.encodeUtf8 validationMessage)
              }
          Right () -> pure ()
      captureId <- maybe
        (throwError err502 { errBody = "PayPal capture ID is missing" })
        pure
        (ServiceStorefront.spcoCaptureId outcome)
      result <- liftIO $ flip runSqlPool envPool $ do
        binding <- Checkout.bindProviderResource Checkout.ProviderBindingCreation
          { Checkout.pbcAttempt = attempt
          , Checkout.pbcCheckout = checkout
          , Checkout.pbcProvider = Checkout.ProviderPayPal
          , Checkout.pbcEnvironment = paypalEnvironment
          , Checkout.pbcMerchantRef = merchantRef
          , Checkout.pbcResourceType = "capture"
          , Checkout.pbcProviderResource = captureId
          , Checkout.pbcResourcePath = Just
              ("/v2/checkout/orders/" <> paypalOrderId <> "/capture")
          , Checkout.pbcOrderReference = toPathPiece orderKey
          , Checkout.pbcAmountMinor = fromIntegral (ME.marketplaceOrderTotalUsdCents order)
          , Checkout.pbcCurrency = ME.marketplaceOrderCurrency order
          , Checkout.pbcStage = Checkout.AttemptProcessing
          , Checkout.pbcOccurredAt = now
          , Checkout.pbcCorrelationId = correlationId
          }
        case binding of
          Left message -> pure (Left message)
          Right () -> do
            verified <- Checkout.recordVerifiedPayment Checkout.VerifiedPayment
              { Checkout.vpAttempt = attempt
              , Checkout.vpCheckout = checkout
              , Checkout.vpProvider = Checkout.ProviderPayPal
              , Checkout.vpEnvironment = paypalEnvironment
              , Checkout.vpMerchantRef = merchantRef
              , Checkout.vpResourceType = "capture"
              , Checkout.vpProviderResource = captureId
              , Checkout.vpProviderResourcePath = Just
                  ("/v2/checkout/orders/" <> paypalOrderId <> "/capture")
              , Checkout.vpOrderReference = toPathPiece orderKey
              , Checkout.vpProviderReference = toPathPiece orderKey
              , Checkout.vpAmountMinor = fromIntegral (ME.marketplaceOrderTotalUsdCents order)
              , Checkout.vpCurrency = ME.marketplaceOrderCurrency order
              , Checkout.vpEvidence = "server_to_server"
              , Checkout.vpOccurredAt = now
              , Checkout.vpCorrelationId = correlationId
              }
            case verified of
              Left message -> pure (Left message)
              Right _ -> do
                update orderKey
                  [ ME.MarketplaceOrderPaypalPayerEmail =.
                      (ServiceStorefront.spcoPayerEmail outcome <|>
                        ME.marketplaceOrderPaypalPayerEmail order)
                  , ME.MarketplaceOrderUpdatedAt =. now
                  ]
                pure (Right ())
      either (throwError . marketplaceCheckoutConflict) pure result
    "APPROVED" -> recordPendingPaypalCapture
      checkout attempt orderKey order outcome correlationId now
    "PENDING" -> recordPendingPaypalCapture
      checkout attempt orderKey order outcome correlationId now
    _ -> liftIO $ flip runSqlPool envPool $ do
      Checkout.recordPaymentFailure checkout attempt Checkout.ProviderPayPal
        ("paypal_" <> T.toLower status) correlationId now
      update orderKey
        [ ME.MarketplaceOrderStatus =. "paypal_failed"
        , ME.MarketplaceOrderUpdatedAt =. now
        ]
  mDto <- liftIO $ flip runSqlPool envPool $ loadOrderDTO orderKey
  either throwError pure $
    requireLoadedMarketplacePublicOrderResponse "Marketplace order" mDto

recordPendingPaypalCapture
  :: Checkout.CheckoutReference
  -> Checkout.PaymentAttemptReference
  -> Key ME.MarketplaceOrder
  -> ME.MarketplaceOrder
  -> ServiceStorefront.ServicePaypalCaptureOutcome
  -> Text
  -> UTCTime
  -> AppM ()
recordPendingPaypalCapture checkout attempt orderKey order outcome correlationId now = do
  Env{ envPool } <- ask
  liftIO $ flip runSqlPool envPool $ do
    Checkout.recordPaymentProcessing checkout attempt Checkout.ProviderPayPal correlationId now
    update orderKey
      [ ME.MarketplaceOrderStatus =. "paypal_pending"
      , ME.MarketplaceOrderPaypalPayerEmail =.
          (ServiceStorefront.spcoPayerEmail outcome <|>
            ME.marketplaceOrderPaypalPayerEmail order)
      , ME.MarketplaceOrderUpdatedAt =. now
      ]

captureLegacyPaypalOrder
  :: Key ME.MarketplaceOrder
  -> ME.MarketplaceOrder
  -> Text
  -> AppM MarketplaceOrderDTO
captureLegacyPaypalOrder orderKey order paypalOrderId = do
  Env{ envPool } <- ask
  (cid, sec, baseUrl, _, merchantRef) <- ServiceStorefront.loadPaypalEnvForService
  outcome <- ServiceStorefront.capturePaypalOrderRemoteForService
    sharedProviderManager cid sec baseUrl paypalOrderId
  now <- liftIO getCurrentTime
  let status = ServiceStorefront.spcoStatus outcome
      nextStatus
        | status == "COMPLETED" = "paid"
        | status `elem` ["APPROVED", "PENDING"] = "paypal_pending"
        | otherwise = "paypal_failed"
  when (status == "COMPLETED") $
    either (throwError . marketplaceCheckoutConflict) pure $
      ServiceStorefront.validatePaypalSuccessfulCapture
        (toPathPiece orderKey)
        (ME.marketplaceOrderTotalUsdCents order)
        (ME.marketplaceOrderCurrency order)
        merchantRef
        outcome
  liftIO $ flip runSqlPool envPool $ update orderKey
    [ ME.MarketplaceOrderStatus =. nextStatus
    , ME.MarketplaceOrderPaymentProvider =. Just "paypal"
    , ME.MarketplaceOrderPaypalPayerEmail =.
        (ServiceStorefront.spcoPayerEmail outcome <|>
          ME.marketplaceOrderPaypalPayerEmail order)
    , ME.MarketplaceOrderPaidAt =.
        (if status == "COMPLETED" then Just now else ME.marketplaceOrderPaidAt order)
    , ME.MarketplaceOrderUpdatedAt =. now
    ]
  mDto <- liftIO $ flip runSqlPool envPool $ loadOrderDTO orderKey
  either throwError pure $
    requireLoadedMarketplacePublicOrderResponse "Marketplace order" mDto

requestDatafastCheckout :: Key ME.MarketplaceOrder -> Int -> Text -> Text -> Text -> Maybe Text -> AppM (Text, String)
requestDatafastCheckout orderKey totalCents currency name email mPhone = do
  dfEnv <- loadDatafastEnv
  let manager = sharedProviderManager
  let amountTxt = Internationalization.formatMinorUnitsDecimal
        currency (fromIntegral totalCents)
      currencyTxt = T.toUpper (T.strip currency)
      (givenName, surname) = splitName name
      baseParams =
        [ ("entityId", TE.encodeUtf8 (dfEntityId dfEnv))
        , ("amount", TE.encodeUtf8 amountTxt)
        , ("currency", TE.encodeUtf8 currencyTxt)
        , ("paymentType", "DB")
        , ("merchantTransactionId", TE.encodeUtf8 (toPathPiece orderKey))
        , ("customer.givenName", TE.encodeUtf8 givenName)
        , ("customer.surname", TE.encodeUtf8 surname)
        , ("customer.email", TE.encodeUtf8 email)
        ]
      phoneParam = maybe [] (\p -> [("customer.phone", TE.encodeUtf8 p)]) mPhone
      testModeParam = maybe [] (\tm -> [("testMode", TE.encodeUtf8 tm)]) (dfTestMode dfEnv)
      allParams = baseParams <> phoneParam <> testModeParam <> dfExtraParams dfEnv
      body = RequestBodyBS (renderSimpleQuery False allParams)
      baseUrlClean = normalizeBaseUrl (dfBaseUrl dfEnv)
  req0 <- ServiceStorefront.providerRequest Checkout.ProviderDatafast (baseUrlClean ++ "/v1/checkouts")
  let req = req0
        { method = "POST"
        , requestBody = body
        , requestHeaders =
            [ ("Authorization", "Bearer " <> TE.encodeUtf8 (dfBearerToken dfEnv))
            , ("Content-Type", "application/x-www-form-urlencoded")
            ]
        }
  dfResp <- ServiceStorefront.providerResponse manager Checkout.ProviderDatafast req
  code <- either throwError pure (validateDatafastResultCodeField (dfrCode (dfcResult dfResp)))
  unless (isDfCheckoutSuccess code) $
    throwError err502 { errBody = "Datafast rechazó la solicitud de pago." }
  checkoutId <- either throwError pure (validateDatafastCheckoutId (dfcId dfResp))
  let widgetUrl =
        baseUrlClean ++ "/v1/paymentWidgets.js?checkoutId=" ++ T.unpack checkoutId
  pure (checkoutId, widgetUrl)

datafastPaymentStatus :: DatafastEnv -> Text -> AppM DFPaymentStatus
datafastPaymentStatus dfEnv resourcePathTxt = do
  resourcePath <- either throwError pure (validateDatafastResourcePath (Just resourcePathTxt))
  let manager = sharedProviderManager
  let rp = T.unpack resourcePath
      baseUrlClean = normalizeBaseUrl (dfBaseUrl dfEnv)
      basePath = baseUrlClean ++ rp
      sep = if '?' `elem` basePath then "&" else "?"
      fullUrl = basePath ++ sep ++ "entityId=" ++ T.unpack (dfEntityId dfEnv)
  req0 <- ServiceStorefront.providerRequest Checkout.ProviderDatafast fullUrl
  let req = req0
        { method = "GET"
        , requestHeaders = [("Authorization", "Bearer " <> TE.encodeUtf8 (dfBearerToken dfEnv))]
        }
  ServiceStorefront.providerResponse manager Checkout.ProviderDatafast req

validateDatafastResourcePath :: Maybe Text -> Either ServerError Text
validateDatafastResourcePath Nothing =
  Left err400 { errBody = "resourcePath requerido" }
validateDatafastResourcePath (Just rawResourcePath)
  | T.null resourcePath =
      Left err400 { errBody = "resourcePath requerido" }
  | not ("/" `T.isPrefixOf` resourcePath) =
      invalidDatafastResourcePath
  | T.length resourcePath > 512 =
      invalidDatafastResourcePath
  | T.isPrefixOf "http://" lowered
      || T.isPrefixOf "https://" lowered
      || T.isPrefixOf "//" resourcePath =
      invalidDatafastResourcePath
  | T.any (not . isDatafastResourcePathChar) resourcePath =
      invalidDatafastResourcePath
  | any invalidSegment segments =
      invalidDatafastResourcePath
  | Just checkoutId <- datafastCheckoutIdFromSegments segments
  , isValidDatafastCheckoutId checkoutId =
      Right resourcePath
  | otherwise =
      invalidDatafastResourcePath
  where
    resourcePath = T.strip rawResourcePath
    lowered = T.toLower resourcePath
    segments = T.splitOn "/" (T.drop 1 resourcePath)
    invalidSegment segment =
      T.null segment || segment == "." || segment == ".."

validateDatafastOrderResourcePath :: Maybe Text -> Maybe Text -> Either ServerError Text
validateDatafastOrderResourcePath mExpectedCheckoutId mRawResourcePath = do
  resourcePath <- validateDatafastResourcePath mRawResourcePath
  expectedCheckoutId <- case mExpectedCheckoutId of
    Just checkoutId -> validateStoredDatafastCheckoutId checkoutId
    Nothing ->
      Left err409
        { errBody =
            "Order does not have a Datafast checkout to confirm"
        }
  actualCheckoutId <-
    maybe invalidDatafastResourcePath Right (datafastCheckoutIdFromResourcePath resourcePath)
  if actualCheckoutId == expectedCheckoutId
    then Right resourcePath
    else
      Left err400
        { errBody =
            "resourcePath does not match this order's Datafast checkout"
        }

validateStoredDatafastCheckoutId :: Text -> Either ServerError Text
validateStoredDatafastCheckoutId rawCheckoutId
  | rawCheckoutId == checkoutId
      && isValidDatafastCheckoutId checkoutId =
      Right checkoutId
  | otherwise =
      Left err500
        { errBody =
            "Stored Datafast checkout id is invalid"
        }
  where
    checkoutId = T.strip rawCheckoutId

datafastCheckoutIdFromResourcePath :: Text -> Maybe Text
datafastCheckoutIdFromResourcePath resourcePath =
  datafastCheckoutIdFromSegments (T.splitOn "/" (T.drop 1 resourcePath))

datafastCheckoutIdFromSegments :: [Text] -> Maybe Text
datafastCheckoutIdFromSegments ["v1", "checkouts", checkoutId, "payment"]
  | not (T.null checkoutId) = Just checkoutId
datafastCheckoutIdFromSegments _ =
  Nothing

validateDatafastCheckoutId :: Text -> Either ServerError Text
validateDatafastCheckoutId rawCheckoutId
  | isValidDatafastCheckoutId checkoutId =
      Right checkoutId
  | otherwise =
      invalidDatafastCheckoutId
  where
    checkoutId = T.strip rawCheckoutId

validateOptionalDatafastPaymentIdField :: Maybe Text -> Either ServerError (Maybe Text)
validateOptionalDatafastPaymentIdField Nothing = Right Nothing
validateOptionalDatafastPaymentIdField (Just rawPaymentId)
  | isValidDatafastCheckoutId paymentId =
      Right (Just paymentId)
  | otherwise =
      Left err502
        { errBody =
            "Datafast returned an invalid payment id"
        }
  where
    paymentId = T.strip rawPaymentId

validateOptionalDatafastMetadataField :: Text -> Maybe Text -> Either ServerError (Maybe Text)
validateOptionalDatafastMetadataField _ Nothing =
  Right Nothing
validateOptionalDatafastMetadataField fieldName (Just rawValue)
  | T.null value =
      Right Nothing
  | T.length value > 512 =
      invalid
  | T.any isDatafastMetadataUnsafeChar value =
      invalid
  | otherwise =
      Right (Just value)
  where
    value = T.strip rawValue
    invalid =
      Left err502
        { errBody =
            BL.fromStrict . TE.encodeUtf8 $
              fieldName
                <> " must be 512 characters or fewer and must not contain control or formatting characters"
        }

isDatafastMetadataUnsafeChar :: Char -> Bool
isDatafastMetadataUnsafeChar ch =
  isControl ch || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

isValidDatafastCheckoutId :: Text -> Bool
isValidDatafastCheckoutId checkoutId =
  not (T.null checkoutId)
    && T.length checkoutId <= 256
    && checkoutId /= "."
    && checkoutId /= ".."
    && T.any isDatafastCheckoutIdAtom checkoutId
    && T.all isDatafastCheckoutIdChar checkoutId

isDatafastCheckoutIdAtom :: Char -> Bool
isDatafastCheckoutIdAtom c =
  isAsciiUpper c || isAsciiLower c || isDigit c

isDatafastCheckoutIdChar :: Char -> Bool
isDatafastCheckoutIdChar c =
  isAsciiUpper c || isAsciiLower c || isDigit c || c `elem` ("-_." :: String)

isDatafastResourcePathChar :: Char -> Bool
isDatafastResourcePathChar c =
  isAsciiUpper c || isAsciiLower c || isDigit c || c `elem` ("-_./" :: String)

invalidDatafastCheckoutId :: Either ServerError a
invalidDatafastCheckoutId =
  Left err502
    { errBody =
        "Datafast returned an invalid checkout id"
    }

invalidDatafastResourcePath :: Either ServerError a
invalidDatafastResourcePath =
  Left err400
    { errBody =
        "resourcePath must be a Datafast relative checkout payment path"
    }

splitName :: Text -> (Text, Text)
splitName raw =
  let parts = T.words raw
  in case parts of
    []       -> ("Cliente", "TDF")
    [x]      -> (x, x)
    (x:rest) -> (x, T.unwords rest)

normalizeBaseUrl :: String -> String
normalizeBaseUrl url =
  case reverse url of
    ('/':rest) -> reverse rest
    _          -> url

isDfCheckoutSuccess :: Text -> Bool
isDfCheckoutSuccess code = "000." `T.isPrefixOf` code

isDfPaymentSuccess :: Text -> Bool
isDfPaymentSuccess code =
  "000.000" `T.isPrefixOf` code || "000.100" `T.isPrefixOf` code

isDfPaymentPending :: Text -> Bool
isDfPaymentPending code = code == "000.200.000"

validateDatafastResultCodeField :: Text -> Either ServerError Text
validateDatafastResultCodeField rawCode
  | T.null code =
      invalidDatafastResultCode
  | T.length code > 64 =
      invalidDatafastResultCode
  | T.any (\ch -> isControl ch || isSpace ch) code =
      invalidDatafastResultCode
  | not (T.all isDatafastResultCodeChar code) =
      invalidDatafastResultCode
  | not (hasCanonicalDatafastResultCodeShape code) =
      invalidDatafastResultCode
  | otherwise =
      Right code
  where
    code = T.strip rawCode

hasCanonicalDatafastResultCodeShape :: Text -> Bool
hasCanonicalDatafastResultCodeShape code =
  case T.splitOn "." code of
    [major, minor, detail] ->
      all ((== 3) . T.length) [major, minor, detail]
    _ ->
      False

isDatafastResultCodeChar :: Char -> Bool
isDatafastResultCodeChar ch =
  isAsciiDecimalDigit ch || ch == '.'

invalidDatafastResultCode :: Either ServerError a
invalidDatafastResultCode =
  Left err502
    { errBody =
        "Datafast returned an invalid result code"
    }

validateDatafastSuccessfulPaymentAmountAndCurrency
  :: Int
  -> Text
  -> Maybe Text
  -> Maybe Text
  -> Either ServerError ()
validateDatafastSuccessfulPaymentAmountAndCurrency expectedCents storedCurrency mAmount mCurrency = do
  when (expectedCents <= 0) $
    Left err500 { errBody = "Stored marketplace order total is invalid" }
  expectedCurrency <- validateStoredMarketplaceOrderCurrency storedCurrency
  paidCents <- validateDatafastPaymentAmountField mAmount
  paidCurrency <- validateDatafastPaymentCurrencyField mCurrency
  unless (paidCents == expectedCents) $
    Left err502 { errBody = "Datafast payment amount does not match this order" }
  unless (paidCurrency == expectedCurrency) $
    Left err502 { errBody = "Datafast payment currency does not match this order" }

validateStoredMarketplaceOrderCurrency :: Text -> Either ServerError Text
validateStoredMarketplaceOrderCurrency rawCurrency =
  case normalizeCurrencyCodeText rawCurrency of
    Just currency -> Right currency
    Nothing -> Left err500 { errBody = "Stored marketplace order currency is invalid" }

validateDatafastPaymentAmountField :: Maybe Text -> Either ServerError Int
validateDatafastPaymentAmountField Nothing =
  Left err502 { errBody = "Datafast payment response did not include an amount" }
validateDatafastPaymentAmountField (Just rawAmount) =
  case parseDatafastAmountCents rawAmount of
    Just cents | cents > 0 -> Right cents
    Nothing -> Left err502 { errBody = "Datafast returned an invalid payment amount" }
    Just _ -> Left err502 { errBody = "Datafast returned an invalid payment amount" }

validateDatafastPaymentCurrencyField :: Maybe Text -> Either ServerError Text
validateDatafastPaymentCurrencyField Nothing =
  Left err502 { errBody = "Datafast payment response did not include a currency" }
validateDatafastPaymentCurrencyField (Just rawCurrency) =
  case normalizeCurrencyCodeText rawCurrency of
    Just currency -> Right currency
    Nothing -> Left err502 { errBody = "Datafast returned an invalid payment currency" }

parseDatafastAmountCents :: Text -> Maybe Int
parseDatafastAmountCents rawAmount =
  if T.length amount > maxDatafastAmountChars
    then Nothing
    else
      case T.splitOn "." amount of
        [whole] -> parseParts whole "0"
        [whole, fraction] -> parseParts whole fraction
        _ -> Nothing
  where
    amount = T.strip rawAmount
    maxDatafastAmountChars = 16

    parseParts whole fraction
      | T.null whole = Nothing
      | T.null fraction = Nothing
      | T.length fraction > 2 = Nothing
      | otherwise = do
          wholeValue <- parseDecimalDigits whole
          fractionValue <- parseDecimalDigits (T.take 2 (fraction <> "00"))
          let cents = wholeValue * 100 + fractionValue
          if cents <= fromIntegral (maxBound :: Int)
            then Just (fromIntegral cents)
            else Nothing

parseDecimalDigits :: Text -> Maybe Integer
parseDecimalDigits rawDigits =
  if T.null rawDigits
    then Nothing
    else T.foldl' step (Just 0) rawDigits
  where
    step Nothing _ = Nothing
    step (Just acc) ch
      | isAsciiDecimalDigit ch =
          Just (acc * 10 + fromIntegral (fromEnum ch - fromEnum '0'))
      | otherwise =
          Nothing

isAsciiDecimalDigit :: Char -> Bool
isAsciiDecimalDigit ch =
  ch >= '0' && ch <= '9'

data MarketplacePaymentContext = MarketplacePaymentContext
  { mpcxOrderKey      :: Key ME.MarketplaceOrder
  , mpcxCheckout      :: Checkout.CheckoutReference
  , mpcxCheckoutStatus :: Text
  , mpcxEnvironment   :: Checkout.CheckoutEnvironment
  , mpcxTotalMinor    :: Int64
  , mpcxCurrency      :: Text
  , mpcxHoldExpiresAt :: UTCTime
  , mpcxOrderKind     :: Text
  , mpcxBuyerName     :: Text
  , mpcxBuyerEmail    :: Text
  , mpcxBuyerPhone    :: Maybe Text
  }

type MarketplaceManualEvidenceRow =
  ( Single Text, Single Text, Single Text, Single (Maybe Text)
  , Single (Maybe Int64), Single (Maybe Text), Single (Maybe Int64)
  , Single (Maybe UTCTime), Single (Maybe Int64), Single (Maybe UTCTime)
  , Single (Maybe Text)
  )

loadMarketplacePaymentContext
  :: Key ME.MarketplaceOrder
  -> SqlPersistT IO (Either Text MarketplacePaymentContext)
loadMarketplacePaymentContext orderKey = do
  rows <- (rawSql
    "SELECT checkout.id::text, checkout.status, checkout.environment,\
    \ checkout.total_minor, checkout.currency, runtime.hold_expires_at,\
    \ runtime.order_kind, orders.buyer_name, orders.buyer_email, orders.buyer_phone\
    \ FROM marketplace_order_checkout_runtime runtime\
    \ JOIN commerce_checkout_session checkout ON checkout.id = runtime.checkout_id\
    \ JOIN marketplace_order orders ON orders.id = runtime.order_id\
    \ WHERE runtime.order_id = ?::uuid\
    \ AND checkout.domain_order_id = runtime.order_id::text\
    \ AND checkout.domain_type = CASE runtime.order_kind\
    \   WHEN 'sale' THEN 'marketplace_sale' ELSE 'marketplace_rental' END\
    \ AND checkout.total_minor = orders.total_usd_cents\
    \ AND checkout.currency = orders.currency"
    [PersistText (toPathPiece orderKey)]
    :: SqlPersistT IO
      [( Single Text, Single Text, Single Text, Single Int64, Single Text
       , Single UTCTime, Single Text, Single Text, Single Text, Single (Maybe Text)
       )])
  pure $ case rows of
    [( Single checkoutId, Single checkoutStatus, Single environmentText
     , Single totalMinor, Single currency, Single holdExpiresAt, Single orderKind
     , Single buyerName, Single buyerEmail, Single buyerPhone
     )]
      | totalMinor <= 0 -> Left "Marketplace checkout total is invalid"
      | environmentText `notElem` ["sandbox", "production"] ->
          Left "Marketplace checkout environment is invalid"
      | otherwise -> Right MarketplacePaymentContext
          { mpcxOrderKey = orderKey
          , mpcxCheckout = Checkout.CheckoutReference checkoutId
          , mpcxCheckoutStatus = checkoutStatus
          , mpcxEnvironment = if environmentText == "production"
              then Checkout.CheckoutProduction else Checkout.CheckoutSandbox
          , mpcxTotalMinor = totalMinor
          , mpcxCurrency = currency
          , mpcxHoldExpiresAt = holdExpiresAt
          , mpcxOrderKind = orderKind
          , mpcxBuyerName = buyerName
          , mpcxBuyerEmail = buyerEmail
          , mpcxBuyerPhone = buyerPhone
          }
    [] -> Left "Marketplace order is not linked to a canonical checkout"
    _ -> Left "Marketplace checkout context is ambiguous"

requireMarketplacePaymentContext
  :: Text
  -> Maybe Text
  -> AppM MarketplacePaymentContext
requireMarketplacePaymentContext rawOrderId mLookupToken = do
  orderKey <- parseOrderId rawOrderId
  requireMarketplaceOrderLookupToken orderKey mLookupToken
  context <- runDB (loadMarketplacePaymentContext orderKey)
    >>= either (throwError . marketplaceCheckoutConflict) pure
  now <- liftIO getCurrentTime
  when
      ( mpcxHoldExpiresAt context <= now
        && mpcxCheckoutStatus context `elem` ["holding", "awaiting_payment", "failed"]
      ) $ do
    _ <- runDB (rawSql "SELECT marketplace_expire_sale_holds(?)"
      [PersistUTCTime now] :: SqlPersistT IO [Single Int])
    throwError err409
      { errBody = "This marketplace checkout hold expired; start a new checkout before submitting payment evidence" }
  pure context

loadMarketplaceManualEvidenceRows
  :: Checkout.CheckoutReference
  -> SqlPersistT IO [MarketplaceManualEvidenceRow]
loadMarketplaceManualEvidenceRows checkout = rawSql
  "SELECT evidence.id::text, attempt.provider, evidence.status,\
  \ evidence.customer_reference, evidence.submitted_amount_minor, evidence.currency,\
  \ evidence.submitted_by, evidence.submitted_at, evidence.reviewed_by,\
  \ evidence.reviewed_at, evidence.review_notes\
  \ FROM commerce_manual_payment_evidence evidence\
  \ JOIN commerce_payment_attempt attempt ON attempt.id = evidence.payment_attempt_id\
  \ WHERE evidence.checkout_id = ?::uuid\
  \ AND attempt.checkout_id = evidence.checkout_id\
  \ AND attempt.provider IN ('bank_transfer','cash','pos')\
  \ AND attempt.operation = 'manual_verify'\
  \ ORDER BY attempt.updated_at DESC, evidence.id DESC LIMIT 2"
  [PersistText (Checkout.checkoutReferenceId checkout)]

marketplaceManualEvidenceDTO
  :: MarketplaceManualEvidenceRow
  -> MarketplaceManualEvidenceDTO
marketplaceManualEvidenceDTO
    ( Single evidenceId, Single provider, Single status, Single customerReference
    , Single submittedAmount, Single currency, Single submittedBy, Single submittedAt
    , Single reviewedBy, Single reviewedAt, Single reviewNotes
    ) = MarketplaceManualEvidenceDTO
      { mmeEvidenceId = evidenceId
      , mmePaymentMethod = provider
      , mmeStatus = status
      , mmeCustomerReference = customerReference
      , mmeSubmittedAmountMinor = submittedAmount
      , mmeCurrency = currency
      , mmeSubmittedBy = submittedBy
      , mmeSubmittedAt = submittedAt
      , mmeReviewedBy = reviewedBy
      , mmeReviewedAt = reviewedAt
      , mmeReviewNotes = reviewNotes
      }

loadMarketplaceCommerceDTO
  :: Key ME.MarketplaceOrder
  -> SqlPersistT IO (Either Text MarketplaceCommerceDTO)
loadMarketplaceCommerceDTO orderKey = do
  contextResult <- loadMarketplacePaymentContext orderKey
  case contextResult of
    Left message -> pure (Left message)
    Right context -> do
      evidenceRows <- loadMarketplaceManualEvidenceRows (mpcxCheckout context)
      pure $ case evidenceRows of
        [] -> Right (toCommerce context Nothing)
        [row] -> Right (toCommerce context (Just (marketplaceManualEvidenceDTO row)))
        _ -> Left "Marketplace manual payment evidence is ambiguous and requires reconciliation"
  where
    toCommerce context evidence = MarketplaceCommerceDTO
      { mpcOrderId = toPathPiece (mpcxOrderKey context)
      , mpcCheckoutId = Checkout.checkoutReferenceId (mpcxCheckout context)
      , mpcPaymentStatus = mpcxCheckoutStatus context
      , mpcHoldExpiresAt = mpcxHoldExpiresAt context
      , mpcOrderKind = mpcxOrderKind context
      , mpcManualEvidence = evidence
      }

getMarketplaceCommerce :: AuthedUser -> Text -> AppM MarketplaceCommerceDTO
getMarketplaceCommerce user rawOrderId = do
  requireModule user ModuleInvoicing
  orderKey <- parseOrderId rawOrderId
  runDB (loadMarketplaceCommerceDTO orderKey)
    >>= either (throwError . marketplaceCheckoutConflict) pure

submitMarketplaceManualEvidence
  :: Text
  -> Maybe Text
  -> MarketplaceManualEvidenceSubmit
  -> AppM MarketplaceOrderDTO
submitMarketplaceManualEvidence
    rawOrderId mLookupToken MarketplaceManualEvidenceSubmit{..} = do
  context <- requireMarketplacePaymentContext rawOrderId mLookupToken
  customerReference <- either throwError pure $
    validatePublicBookingManualReference mmesCustomerReference
  outcome <- runDB $ submitMarketplaceManualEvidenceDb context customerReference
  either (throwError . marketplaceCheckoutConflict) pure outcome
  runDB (loadOrderDTO (mpcxOrderKey context))
    >>= either throwError pure
      . requireLoadedMarketplacePublicOrderResponse "Marketplace order"

-- Called only after the order lookup-token access check. The transaction owns
-- every contact, checkout, evidence, and audit mutation for this submission.
submitMarketplaceManualEvidenceDb
  :: MarketplacePaymentContext -> Text -> SqlPersistT IO (Either Text ())
submitMarketplaceManualEvidenceDb context customerReference = do
  let checkoutId = Checkout.checkoutReferenceId (mpcxCheckout context)
  rows <- (rawSql
    "SELECT evidence.id::text, evidence.status, evidence.customer_reference,\
    \ evidence.submitted_by, attempt.id::text, checkout.status,\
    \ checkout.customer_party_id\
    \ FROM commerce_manual_payment_evidence evidence\
    \ JOIN commerce_payment_attempt attempt ON attempt.id = evidence.payment_attempt_id\
    \ JOIN commerce_checkout_session checkout ON checkout.id = evidence.checkout_id\
    \ JOIN marketplace_order_checkout_runtime runtime ON runtime.checkout_id = checkout.id\
    \ WHERE runtime.order_id = ?::uuid\
    \ AND checkout.id = ?::uuid\
    \ AND checkout.domain_order_id = runtime.order_id::text\
    \ AND checkout.total_minor = ? AND checkout.currency = ?\
    \ AND attempt.checkout_id = checkout.id\
    \ AND attempt.provider = 'bank_transfer'\
    \ AND attempt.operation = 'manual_verify'\
    \ AND attempt.environment = checkout.environment\
    \ AND attempt.amount_minor = checkout.total_minor\
    \ AND attempt.currency = checkout.currency\
    \ FOR UPDATE OF evidence, attempt, checkout"
    [ PersistText (toPathPiece (mpcxOrderKey context))
    , PersistText checkoutId
    , PersistInt64 (mpcxTotalMinor context)
    , PersistText (mpcxCurrency context)
    ] :: SqlPersistT IO
      [( Single Text, Single Text, Single (Maybe Text), Single (Maybe Int64)
       , Single Text, Single Text, Single (Maybe Int64)
       )])
  case rows of
    [( Single evidenceId, Single status, Single existingReference
     , Single existingSubmitter, Single attemptId, Single checkoutStatus
     , Single existingCustomer
     )]
      | Just customer <- existingCustomer, Just submitter <- existingSubmitter, customer /= submitter ->
          pure (Left "Marketplace evidence and checkout identities require review")
      | checkoutStatus == "paid" && status /= "approved" ->
          pure (Left "This checkout is already paid by another payment attempt")
      | status `elem` ["submitted", "under_review"]
          && existingReference == Just customerReference
          && isJust existingCustomer && existingSubmitter == existingCustomer -> pure (Right ())
      | status == "approved" -> pure (Right ())
      | status `elem` ["submitted", "under_review"] ->
          pure (Left "Different manual evidence is already under review")
      | status `elem` ["awaiting_evidence", "rejected"] -> do
          now <- liftIO getCurrentTime
          -- The locked checkout/evidence is the trusted operation identity.
          -- Create a new unverified contact only for its first submission, in
          -- this same transaction. Shared email never adopts another account.
          customerId <- case existingCustomer <|> existingSubmitter of
            Just existingId -> pure existingId
            Nothing -> do
              result <- ensurePartyRecordDb now
                (Just (mpcxBuyerName context)) (mpcxBuyerEmail context) (mpcxBuyerPhone context)
              fromSqlKey <$> either (liftIO . throwIO) pure result
          rawExecute
            "UPDATE commerce_checkout_session SET customer_party_id = COALESCE(customer_party_id, ?)\
            \ WHERE id = ?::uuid"
            [PersistInt64 customerId, PersistText checkoutId]
          when (status == "rejected") $
            Checkout.recordManualPaymentSelection
              (mpcxCheckout context)
              (Checkout.PaymentAttemptReference attemptId)
              Checkout.ProviderBankTransfer
              (marketplacePaymentCorrelationId context Checkout.ProviderBankTransfer "manual-resubmit")
              now
          rawExecute
            "UPDATE commerce_manual_payment_evidence\
            \ SET customer_reference = ?, submitted_amount_minor = ?, currency = ?,\
            \ submitted_at = ?, submitted_by = ?, status = 'submitted',\
            \ reviewed_by = NULL, reviewed_at = NULL, review_notes = NULL\
            \ WHERE id = ?::uuid"
            [ PersistText customerReference
            , PersistInt64 (mpcxTotalMinor context)
            , PersistText (mpcxCurrency context)
            , PersistUTCTime now
            , PersistInt64 customerId
            , PersistText evidenceId
            ]
          rawExecute
            "INSERT INTO commerce_checkout_audit_event(\
            \ checkout_id, event_type, actor_type, actor_id, correlation_id, metadata\
            \) VALUES (?::uuid, 'manual_payment_evidence_submitted', 'customer', ?, ?,\
            \ jsonb_build_object('attempt_id', ?))"
            [ PersistText checkoutId
            , PersistText (T.pack (show customerId))
            , PersistText (marketplacePaymentCorrelationId
                context Checkout.ProviderBankTransfer "manual-evidence")
            , PersistText attemptId
            ]
          pure (Right ())
      | otherwise -> pure (Left "Manual evidence cannot be submitted in its current state")
    [] -> pure (Left "Select bank transfer before submitting evidence")
    _ -> pure (Left "Marketplace manual payment evidence is ambiguous")

validateMarketplaceManualReview
  :: MarketplaceManualPaymentReview
  -> Either ServerError (Text, Text)
validateMarketplaceManualReview MarketplaceManualPaymentReview{..}
  | action `notElem` ["approve", "reject"] =
      Left err400 { errBody = "Manual payment review action must be approve or reject" }
  | T.length notes < 3 || T.length notes > 2000 =
      Left err400 { errBody = "Manual payment review notes must contain 3 to 2000 characters" }
  | T.any isUnsafeAccessRequestTextChar notes =
      Left err400 { errBody = "Manual payment review notes contain unsupported characters" }
  | otherwise = Right (action, notes)
  where
    action = T.toLower (T.strip mmprAction)
    notes = T.strip mmprReviewNotes

marketplacePaymentCorrelationId
  :: MarketplacePaymentContext
  -> Checkout.PaymentProvider
  -> Text
  -> Text
marketplacePaymentCorrelationId context provider stage =
  "marketplace-" <> mpcxOrderKind context <> ":"
    <> toPathPiece (mpcxOrderKey context) <> ":"
    <> Checkout.paymentProviderText provider <> ":" <> stage

insertMarketplaceManualReviewAudit
  :: MarketplacePaymentContext
  -> Checkout.PaymentProvider
  -> Int64
  -> Text
  -> Text
  -> Text
  -> SqlPersistT IO ()
insertMarketplaceManualReviewAudit context provider reviewerId attemptId evidenceId eventType =
  rawExecute
    "INSERT INTO commerce_checkout_audit_event(\
    \ checkout_id, event_type, actor_type, actor_id, correlation_id, metadata\
    \) VALUES (?::uuid, ?, 'staff', ?, ?,\
    \ jsonb_build_object('attempt_id', ?, 'evidence_id', ?))"
    [ PersistText (Checkout.checkoutReferenceId (mpcxCheckout context))
    , PersistText eventType
    , PersistText (T.pack (show reviewerId))
    , PersistText (marketplacePaymentCorrelationId context provider "manual-review")
    , PersistText attemptId
    , PersistText evidenceId
    ]

reviewMarketplaceManualPayment
  :: AuthedUser
  -> Text
  -> MarketplaceManualPaymentReview
  -> AppM MarketplaceCommerceDTO
reviewMarketplaceManualPayment user rawOrderId request = do
  requireModule user ModuleInvoicing
  orderKey <- parseOrderId rawOrderId
  context <- runDB (loadMarketplacePaymentContext orderKey)
    >>= either (throwError . marketplaceCheckoutConflict) pure
  (reviewAction, reviewNotes) <- either throwError pure $
    validateMarketplaceManualReview request
  now <- liftIO getCurrentTime
  let reviewerId = fromSqlKey (auPartyId user)
      checkoutId = Checkout.checkoutReferenceId (mpcxCheckout context)
  outcome <- runDB $ do
    rows <- (rawSql
      "SELECT checkout.status, attempt.id::text, attempt.provider,\
      \ attempt.merchant_account_ref, attempt.status, evidence.id::text,\
      \ evidence.status, evidence.submitted_by, evidence.reviewed_by,\
      \ EXISTS (SELECT 1 FROM commerce_reservation_hold hold\
      \   WHERE hold.checkout_id = checkout.id AND hold.status = 'active'\
      \   AND hold.expires_at > ?)\
      \ FROM marketplace_order_checkout_runtime runtime\
      \ JOIN commerce_checkout_session checkout ON checkout.id = runtime.checkout_id\
      \ JOIN commerce_payment_attempt attempt ON attempt.checkout_id = checkout.id\
      \ JOIN commerce_manual_payment_evidence evidence\
      \   ON evidence.checkout_id = checkout.id\
      \  AND evidence.payment_attempt_id = attempt.id\
      \ WHERE runtime.order_id = ?::uuid AND checkout.id = ?::uuid\
      \ AND checkout.domain_order_id = runtime.order_id::text\
      \ AND checkout.environment = ? AND checkout.total_minor = ?\
      \ AND checkout.currency = ? AND attempt.environment = checkout.environment\
      \ AND attempt.amount_minor = checkout.total_minor\
      \ AND attempt.currency = checkout.currency\
      \ AND attempt.provider IN ('bank_transfer','cash','pos')\
      \ AND attempt.operation = 'manual_verify'\
      \ ORDER BY (attempt.status = 'succeeded') DESC, attempt.updated_at DESC\
      \ FOR UPDATE OF checkout, attempt, evidence"
      [ PersistUTCTime now
      , PersistText (toPathPiece orderKey)
      , PersistText checkoutId
      , PersistText (Checkout.checkoutEnvironmentText (mpcxEnvironment context))
      , PersistInt64 (mpcxTotalMinor context)
      , PersistText (mpcxCurrency context)
      ] :: SqlPersistT IO
        [( Single Text, Single Text, Single Text, Single Text, Single Text
         , Single Text, Single Text, Single (Maybe Int64), Single (Maybe Int64)
         , Single Bool
         )])
    case rows of
      [] -> pure (Left "No submitted manual payment evidence exists for this marketplace order")
      [_first, _second] -> pure (Left "Marketplace manual payment evidence is ambiguous and requires reconciliation")
      (_:_:_) -> pure (Left "Marketplace manual payment evidence is ambiguous and requires reconciliation")
      [( Single checkoutStatus, Single attemptId, Single providerText, Single merchantRef
       , Single attemptStatus, Single evidenceId, Single evidenceStatus
       , Single mSubmittedBy, Single mReviewedBy, Single holdActive
       )] -> case (mSubmittedBy, manualPaymentProviderFromText providerText) of
        (Nothing, _) -> pure (Left "Manual payment evidence has no verified submitter")
        (_, Nothing) -> pure (Left "Manual payment evidence uses an unsupported provider")
        (Just submittedBy, Just provider)
          | submittedBy == reviewerId ->
              pure (Left "Manual payment evidence requires an independent reviewer")
          | evidenceStatus == "approved" && reviewAction == "approve"
              && checkoutStatus == "paid" && attemptStatus == "succeeded" -> pure (Right ())
          | evidenceStatus == "approved" ->
              pure (Left "Approved manual payment evidence cannot be changed")
          | evidenceStatus == "rejected" && reviewAction == "reject" -> pure (Right ())
          | evidenceStatus == "rejected" ->
              pure (Left "Rejected evidence must be resubmitted before approval")
          | evidenceStatus `notElem` ["submitted", "under_review"] ->
              pure (Left "Manual payment evidence is not ready for review")
          | evidenceStatus == "under_review" && mReviewedBy /= Just reviewerId ->
              pure (Left "Manual payment evidence is already under review by another staff member")
          | checkoutStatus == "paid" -> do
              Checkout.recordReconciliationException
                provider (mpcxEnvironment context) merchantRef
                "manual_evidence_after_other_payment"
                (toPathPiece orderKey) evidenceId
                (mpcxTotalMinor context) (Just (mpcxTotalMinor context))
                (mpcxCurrency context) now
              pure (Left "This checkout is already paid by another payment attempt")
          | reviewAction == "approve" && not holdActive -> do
              Checkout.recordReconciliationException
                provider (mpcxEnvironment context) merchantRef
                "manual_payment_after_marketplace_hold_expiry"
                (toPathPiece orderKey) evidenceId
                (mpcxTotalMinor context) (Just (mpcxTotalMinor context))
                (mpcxCurrency context) now
              pure (Left "The marketplace hold expired; payment requires reconciliation and cannot confirm this order")
          | reviewAction == "approve"
              && checkoutStatus `notElem` ["awaiting_payment", "failed", "processing"] ->
              pure (Left "This checkout no longer accepts manual payment approval")
          | otherwise -> do
              transactionSave
              when (evidenceStatus == "submitted") $
                rawExecute
                  "UPDATE commerce_manual_payment_evidence\
                  \ SET status = 'under_review', reviewed_by = ?, review_notes = ?\
                  \ WHERE id = ?::uuid"
                  [PersistInt64 reviewerId, PersistText reviewNotes, PersistText evidenceId]
              if reviewAction == "reject"
                then do
                  rawExecute
                    "UPDATE commerce_manual_payment_evidence\
                    \ SET status = 'rejected', reviewed_at = ?, review_notes = ?\
                    \ WHERE id = ?::uuid"
                    [PersistUTCTime now, PersistText reviewNotes, PersistText evidenceId]
                  Checkout.recordPaymentFailure
                    (mpcxCheckout context) (Checkout.PaymentAttemptReference attemptId)
                    provider "manual_evidence_rejected"
                    (marketplacePaymentCorrelationId context provider "manual-review") now
                  insertMarketplaceManualReviewAudit
                    context provider reviewerId attemptId evidenceId "manual_payment_rejected"
                  pure (Right ())
                else do
                  rawExecute
                    "UPDATE commerce_manual_payment_evidence\
                    \ SET status = 'approved', reviewed_at = ?, review_notes = ?\
                    \ WHERE id = ?::uuid"
                    [PersistUTCTime now, PersistText reviewNotes, PersistText evidenceId]
                  binding <- Checkout.bindProviderResource Checkout.ProviderBindingCreation
                    { Checkout.pbcAttempt = Checkout.PaymentAttemptReference attemptId
                    , Checkout.pbcCheckout = mpcxCheckout context
                    , Checkout.pbcProvider = provider
                    , Checkout.pbcEnvironment = mpcxEnvironment context
                    , Checkout.pbcMerchantRef = merchantRef
                    , Checkout.pbcResourceType = "manual_evidence"
                    , Checkout.pbcProviderResource = evidenceId
                    , Checkout.pbcResourcePath = Nothing
                    , Checkout.pbcOrderReference = toPathPiece orderKey
                    , Checkout.pbcAmountMinor = mpcxTotalMinor context
                    , Checkout.pbcCurrency = mpcxCurrency context
                    , Checkout.pbcStage = Checkout.AttemptProcessing
                    , Checkout.pbcOccurredAt = now
                    , Checkout.pbcCorrelationId = marketplacePaymentCorrelationId
                        context provider "manual-review"
                    }
                  case binding of
                    Left bindingError -> transactionUndo >> pure (Left bindingError)
                    Right () -> do
                      verified <- Checkout.recordApprovedManualPayment Checkout.VerifiedPayment
                        { Checkout.vpAttempt = Checkout.PaymentAttemptReference attemptId
                        , Checkout.vpCheckout = mpcxCheckout context
                        , Checkout.vpProvider = provider
                        , Checkout.vpEnvironment = mpcxEnvironment context
                        , Checkout.vpMerchantRef = merchantRef
                        , Checkout.vpResourceType = "manual_evidence"
                        , Checkout.vpProviderResource = evidenceId
                        , Checkout.vpProviderResourcePath = Nothing
                        , Checkout.vpOrderReference = toPathPiece orderKey
                        , Checkout.vpProviderReference = toPathPiece orderKey
                        , Checkout.vpAmountMinor = mpcxTotalMinor context
                        , Checkout.vpCurrency = mpcxCurrency context
                        , Checkout.vpEvidence = "staff_verified_manual"
                        , Checkout.vpOccurredAt = now
                        , Checkout.vpCorrelationId = marketplacePaymentCorrelationId
                            context provider "manual-review"
                        }
                      case verified of
                        Left verificationError -> transactionUndo >> pure (Left verificationError)
                        Right _ -> do
                          insertMarketplaceManualReviewAudit
                            context provider reviewerId attemptId evidenceId "manual_payment_approved"
                          pure (Right ())
  either (throwError . marketplaceCheckoutConflict) pure outcome
  runDB (loadMarketplaceCommerceDTO orderKey)
    >>= either (throwError . marketplaceCheckoutConflict) pure

data MarketplaceCustomerRequestContext = MarketplaceCustomerRequestContext
  { mcrcOrderKind    :: Text
  , mcrcDomainStatus :: Text
  , mcrcCurrentEnd   :: Maybe Day
  }

type MarketplaceCustomerRequestRow =
  ( Single Text, Single Text, Single Text, Single Text, Single Text, Single Text
  , Single (Maybe Day), Single (Maybe Text), Single UTCTime
  , Single (Maybe UTCTime), Single (Maybe Text)
  )

marketplaceCustomerRequestDTO
  :: MarketplaceCustomerRequestRow
  -> MarketplaceCustomerRequestDTO
marketplaceCustomerRequestDTO
    ( Single requestId, Single orderId, Single orderKind, Single requestType
    , Single status, Single reason, Single requestedEndDate, Single evidenceUrl
    , Single requestedAt, Single reviewedAt, Single reviewNotes
    ) = MarketplaceCustomerRequestDTO
      { mcrRequestId = requestId
      , mcrOrderId = orderId
      , mcrOrderKind = orderKind
      , mcrRequestType = requestType
      , mcrStatus = status
      , mcrReason = reason
      , mcrRequestedEndDate = requestedEndDate
      , mcrEvidenceUrl = evidenceUrl
      , mcrRequestedAt = requestedAt
      , mcrReviewedAt = reviewedAt
      , mcrReviewNotes = reviewNotes
      }

loadMarketplaceCustomerRequestContext
  :: Key ME.MarketplaceOrder
  -> SqlPersistT IO (Maybe MarketplaceCustomerRequestContext)
loadMarketplaceCustomerRequestContext orderKey = do
  rows <- (rawSql
    "SELECT runtime.order_kind, runtime.domain_status, rental.end_date\
    \ FROM marketplace_order_checkout_runtime runtime\
    \ LEFT JOIN marketplace_rental_order_runtime rental\
    \   ON rental.order_id = runtime.order_id AND runtime.order_kind = 'rental'\
    \ WHERE runtime.order_id = ?::uuid"
    [PersistText (toPathPiece orderKey)]
    :: SqlPersistT IO
      [(Single Text, Single Text, Single (Maybe Day))])
  pure $ case rows of
    [(Single orderKind, Single domainStatus, Single currentEnd)] ->
      Just MarketplaceCustomerRequestContext
        { mcrcOrderKind = orderKind
        , mcrcDomainStatus = domainStatus
        , mcrcCurrentEnd = currentEnd
        }
    _ -> Nothing

loadMarketplaceCustomerRequestDTO
  :: Key ME.MarketplaceOrder
  -> Text
  -> SqlPersistT IO (Maybe MarketplaceCustomerRequestDTO)
loadMarketplaceCustomerRequestDTO orderKey requestId = do
  rows <- (rawSql
    "SELECT id::text, order_id::text, order_kind, request_type, status, reason,\
    \ requested_end_date, evidence_url, requested_at, reviewed_at, review_notes\
    \ FROM marketplace_customer_request\
    \ WHERE order_id = ?::uuid AND id = ?::uuid"
    [PersistText (toPathPiece orderKey), PersistText requestId]
    :: SqlPersistT IO [MarketplaceCustomerRequestRow])
  pure (marketplaceCustomerRequestDTO <$> listToMaybe rows)

listMarketplaceCustomerRequestDTOs
  :: Key ME.MarketplaceOrder
  -> SqlPersistT IO [MarketplaceCustomerRequestDTO]
listMarketplaceCustomerRequestDTOs orderKey = do
  rows <- (rawSql
    "SELECT id::text, order_id::text, order_kind, request_type, status, reason,\
    \ requested_end_date, evidence_url, requested_at, reviewed_at, review_notes\
    \ FROM marketplace_customer_request WHERE order_id = ?::uuid\
    \ ORDER BY requested_at DESC, id DESC"
    [PersistText (toPathPiece orderKey)]
    :: SqlPersistT IO [MarketplaceCustomerRequestRow])
  pure (map marketplaceCustomerRequestDTO rows)

validateMarketplaceRequiredOperationText
  :: Text
  -> Int
  -> Text
  -> Either ServerError Text
validateMarketplaceRequiredOperationText fieldName maxLength rawValue
  | T.length value < 3 || T.length value > maxLength = Left invalid
  | T.any isUnsafeAccessRequestTextChar value = Left invalid
  | otherwise = Right value
  where
    value = T.strip rawValue
    invalid = err400
      { errBody = BL.fromStrict . TE.encodeUtf8 $
          fieldName <> " must contain 3 to " <> T.pack (show maxLength)
            <> " safe characters"
      }

tryMarketplaceOperationIO :: IO a -> IO (Either SomeException a)
tryMarketplaceOperationIO = try

runMarketplaceOperationWrite
  :: Text
  -> SqlPersistT IO a
  -> AppM a
runMarketplaceOperationWrite conflictMessage action = do
  Env{ envPool } <- ask
  result <- liftIO (tryMarketplaceOperationIO (flip runSqlPool envPool action))
  case result of
    Right value -> pure value
    Left exception -> case fromException exception :: Maybe SomeAsyncException of
      Just _ -> liftIO (throwIO exception)
      Nothing -> case fromException exception :: Maybe SqlError of
        Just sqlError
          | sqlState sqlError == "P0001"
              || "23" `BS8.isPrefixOf` sqlState sqlError ->
                  throwError (marketplaceCheckoutConflict conflictMessage)
        _ -> liftIO (throwIO exception)

listMarketplaceCustomerRequestsPublic
  :: Text
  -> Maybe Text
  -> AppM [MarketplaceCustomerRequestDTO]
listMarketplaceCustomerRequestsPublic rawOrderId mLookupToken = do
  orderKey <- parseOrderId rawOrderId
  requireMarketplaceOrderLookupToken orderKey mLookupToken
  runDB (listMarketplaceCustomerRequestDTOs orderKey)

submitMarketplaceCustomerRequest
  :: Text
  -> Maybe Text
  -> Maybe Text
  -> MarketplaceCustomerRequestSubmit
  -> AppM MarketplaceCustomerRequestDTO
submitMarketplaceCustomerRequest
    rawOrderId mLookupToken mIdempotency MarketplaceCustomerRequestSubmit{..} = do
  orderKey <- parseOrderId rawOrderId
  requireMarketplaceOrderLookupToken orderKey mLookupToken
  lookupToken <- case T.strip <$> mLookupToken of
    Just token | not (T.null token) -> pure token
    _ -> throwError marketplaceOrderNotFound
  idempotencyKey <- either (throwError . marketplaceCheckoutBadRequest) pure
    (ServiceStorefront.validateIdempotencyKey mIdempotency)
  requestKind <- either (throwError . marketplaceCheckoutBadRequest) pure
    (MarketplaceOperations.parseMarketplaceCustomerRequestKind mcrsRequestType)
  reason <- either throwError pure
    (validateMarketplaceRequiredOperationText "reason" 1000 mcrsReason)
  evidenceUrl <- either throwError pure
    (validateMarketplaceRentalEvidenceUrl mcrsEvidenceUrl)
  context <- runDB (loadMarketplaceCustomerRequestContext orderKey)
    >>= maybe (throwError err409
          { errBody = "This historical order does not support customer operations" }) pure
  either (throwError . marketplaceCheckoutConflict) pure $
    MarketplaceOperations.validateMarketplaceCustomerRequest
      requestKind (mcrcOrderKind context) (mcrcDomainStatus context)
      (mcrcCurrentEnd context) mcrsRequestedEndDate
  let orderId = toPathPiece orderKey
      requestType = MarketplaceOperations.marketplaceCustomerRequestKindText requestKind
      requestHash = marketplaceSha256Text . TE.decodeUtf8 . BL.toStrict . encode $ object
        [ "order_id" .= orderId
        , "request_type" .= requestType
        , "reason" .= reason
        , "requested_end_date" .= mcrsRequestedEndDate
        , "evidence_url" .= evidenceUrl
        ]
      customerActor = "lookup:" <> T.take 24 (marketplaceSha256Text lookupToken)
  created <- runMarketplaceOperationWrite
    "A request for this order is already pending or the order state changed" $ do
      _ <- (rawSql
        "SELECT 1::bigint FROM (\
        \ SELECT pg_advisory_xact_lock(hashtextextended(?, 0))\
        \) lock_acquired"
        [PersistText ("marketplace-customer-request:" <> orderId <> ":" <> idempotencyKey)]
        :: SqlPersistT IO [Single Int64])
      existing <- (rawSql
        "SELECT id::text, request_sha256 FROM marketplace_customer_request\
        \ WHERE order_id = ?::uuid AND idempotency_key = ?"
        [PersistText orderId, PersistText idempotencyKey]
        :: SqlPersistT IO [(Single Text, Single Text)])
      case existing of
        [(Single requestId, Single storedHash)]
          | storedHash == requestHash -> pure (Right requestId)
          | otherwise -> pure (Left
              "Idempotency key was already used for a different marketplace request")
        [] -> do
          _ <- (rawSql
            "SELECT set_config('tdf.actor_type', 'customer', true),\
            \ set_config('tdf.actor_id', ?, true)"
            [PersistText customerActor]
            :: SqlPersistT IO [(Single Text, Single Text)])
          inserted <- (rawSql
            "INSERT INTO marketplace_customer_request(\
            \ order_id, order_kind, request_type, reason, requested_end_date,\
            \ evidence_url, idempotency_key, request_sha256\
            \) VALUES (?::uuid, ?, ?, ?, ?, ?, ?, ?) RETURNING id::text"
            [ PersistText orderId
            , PersistText (mcrcOrderKind context)
            , PersistText requestType
            , PersistText reason
            , maybe PersistNull PersistDay mcrsRequestedEndDate
            , maybe PersistNull PersistText evidenceUrl
            , PersistText idempotencyKey
            , PersistText requestHash
            ] :: SqlPersistT IO [Single Text])
          pure $ case inserted of
            [Single requestId] -> Right requestId
            _ -> Left "Marketplace request could not be created"
        _ -> pure (Left "Marketplace request idempotency state is ambiguous")
  requestId <- either (throwError . marketplaceCheckoutConflict) pure created
  runDB (loadMarketplaceCustomerRequestDTO orderKey requestId)
    >>= either throwError pure
      . requireLoadedMarketplaceWriteResult "Marketplace customer request"

listMarketplaceCustomerRequestsAdmin
  :: AuthedUser
  -> Text
  -> AppM [MarketplaceCustomerRequestDTO]
listMarketplaceCustomerRequestsAdmin user rawOrderId = do
  requireMarketplaceAccess user
  orderKey <- parseOrderId rawOrderId
  runDB (listMarketplaceCustomerRequestDTOs orderKey)

reviewMarketplaceCustomerRequest
  :: AuthedUser
  -> Text
  -> Text
  -> MarketplaceCustomerRequestReview
  -> AppM MarketplaceCustomerRequestDTO
reviewMarketplaceCustomerRequest
    user rawOrderId rawRequestId MarketplaceCustomerRequestReview{..} = do
  requireMarketplaceAccess user
  orderKey <- parseOrderId rawOrderId
  requestId <- either throwError pure
    (validateMarketplacePathId "request" rawRequestId)
  reviewAction <- either (throwError . marketplaceCheckoutBadRequest) pure
    (MarketplaceOperations.parseMarketplaceCustomerReviewAction mcrrAction)
  reviewNotes <- either throwError pure
    (validateMarketplaceRequiredOperationText "reviewNotes" 1000 mcrrReviewNotes)
  requestRows <- runDB (rawSql
    "SELECT request_type, status FROM marketplace_customer_request\
    \ WHERE id = ?::uuid AND order_id = ?::uuid"
    [PersistText requestId, PersistText (toPathPiece orderKey)]
    :: SqlPersistT IO [(Single Text, Single Text)])
  (requestKind, currentStatus) <- case requestRows of
    [(Single requestType, Single status)] -> do
      kind <- either (throwError . marketplaceCheckoutInternal) pure
        (MarketplaceOperations.parseMarketplaceCustomerRequestKind requestType)
      parsedStatus <- either (throwError . marketplaceCheckoutInternal) pure
        (MarketplaceOperations.parseMarketplaceCustomerRequestStatus status)
      pure (kind, parsedStatus)
    [] -> throwError marketplaceOrderNotFound
    _ -> throwError (marketplaceCheckoutInternal
      "Marketplace customer request lookup was ambiguous")
  nextStatus <- either (throwError . marketplaceCheckoutConflict) pure
    (MarketplaceOperations.validateMarketplaceCustomerReview
      requestKind currentStatus reviewAction)
  now <- liftIO getCurrentTime
  let reviewerId = fromSqlKey (auPartyId user)
      currentStatusText = MarketplaceOperations.marketplaceCustomerRequestStatusText currentStatus
      nextStatusText = MarketplaceOperations.marketplaceCustomerRequestStatusText nextStatus
  updated <- runMarketplaceOperationWrite
    "Marketplace request or order state changed before review" $
      (rawSql
        "WITH actor_context AS MATERIALIZED (\
        \ SELECT set_config('tdf.actor_type', 'operator', true),\
        \ set_config('tdf.actor_id', ?, true)\
        \) UPDATE marketplace_customer_request SET status = ?, reviewed_by = ?,\
        \ reviewed_at = ?, review_notes = ? FROM actor_context\
        \ WHERE id = ?::uuid AND order_id = ?::uuid AND status = ?\
        \ RETURNING marketplace_customer_request.id::text"
        [ PersistText (T.pack (show reviewerId))
        , PersistText nextStatusText
        , PersistInt64 reviewerId
        , PersistUTCTime now
        , PersistText reviewNotes
        , PersistText requestId
        , PersistText (toPathPiece orderKey)
        , PersistText currentStatusText
        ] :: SqlPersistT IO [Single Text])
  when (null updated) $
    throwError (marketplaceCheckoutConflict
      "Marketplace request changed concurrently; reload before retrying")
  runDB (loadMarketplaceCustomerRequestDTO orderKey requestId)
    >>= either throwError pure
      . requireLoadedMarketplaceWriteResult "Marketplace customer request"

type MarketplaceDepositSettlementRow =
  ( Single Text, Single Text, Single Text, Single Text, Single Int64, Single Int64
  , Single Int64, Single Text, Single Text, Single Text, Single Text, Single Int64
  , Single UTCTime, Single (Maybe Int64), Single (Maybe UTCTime), Single (Maybe Text)
  )

marketplaceDepositSettlementDTO
  :: MarketplaceDepositSettlementRow
  -> MarketplaceDepositSettlementDTO
marketplaceDepositSettlementDTO
    ( Single settlementId, Single orderId, Single checkoutId, Single currency
    , Single depositAmount, Single deductionAmount, Single refundAmount
    , Single settlementMethod, Single externalReference, Single evidenceUrl
    , Single status, Single submittedBy, Single submittedAt, Single reviewedBy
    , Single reviewedAt, Single reviewNotes
    ) = MarketplaceDepositSettlementDTO
      { mdsSettlementId = settlementId
      , mdsOrderId = orderId
      , mdsCheckoutId = checkoutId
      , mdsCurrency = currency
      , mdsDepositAmountMinor = depositAmount
      , mdsDeductionAmountMinor = deductionAmount
      , mdsRefundAmountMinor = refundAmount
      , mdsSettlementMethod = settlementMethod
      , mdsExternalReference = externalReference
      , mdsEvidenceUrl = evidenceUrl
      , mdsStatus = status
      , mdsSubmittedBy = submittedBy
      , mdsSubmittedAt = submittedAt
      , mdsReviewedBy = reviewedBy
      , mdsReviewedAt = reviewedAt
      , mdsReviewNotes = reviewNotes
      }

marketplaceDepositSettlementSelect :: Text
marketplaceDepositSettlementSelect =
  "SELECT id::text, order_id::text, checkout_id::text, currency,\
  \ deposit_amount_minor, deduction_amount_minor, refund_amount_minor,\
  \ settlement_method, external_reference, evidence_url, status, submitted_by,\
  \ submitted_at, reviewed_by, reviewed_at, review_notes\
  \ FROM marketplace_rental_deposit_settlement"

loadMarketplaceDepositSettlementDTO
  :: Key ME.MarketplaceOrder
  -> Text
  -> SqlPersistT IO (Maybe MarketplaceDepositSettlementDTO)
loadMarketplaceDepositSettlementDTO orderKey settlementId = do
  rows <- (rawSql
    (marketplaceDepositSettlementSelect
      <> " WHERE order_id = ?::uuid AND id = ?::uuid")
    [PersistText (toPathPiece orderKey), PersistText settlementId]
    :: SqlPersistT IO [MarketplaceDepositSettlementRow])
  pure (marketplaceDepositSettlementDTO <$> listToMaybe rows)

listMarketplaceDepositSettlementDTOs
  :: Key ME.MarketplaceOrder
  -> SqlPersistT IO [MarketplaceDepositSettlementDTO]
listMarketplaceDepositSettlementDTOs orderKey = do
  rows <- (rawSql
    (marketplaceDepositSettlementSelect
      <> " WHERE order_id = ?::uuid ORDER BY submitted_at DESC, id DESC")
    [PersistText (toPathPiece orderKey)]
    :: SqlPersistT IO [MarketplaceDepositSettlementRow])
  pure (map marketplaceDepositSettlementDTO rows)

listMarketplaceDepositSettlements
  :: AuthedUser
  -> Text
  -> AppM [MarketplaceDepositSettlementDTO]
listMarketplaceDepositSettlements user rawOrderId = do
  requireMarketplaceAccess user
  requireModule user ModuleInvoicing
  orderKey <- parseOrderId rawOrderId
  runDB (listMarketplaceDepositSettlementDTOs orderKey)

submitMarketplaceDepositSettlement
  :: AuthedUser
  -> Text
  -> Maybe Text
  -> MarketplaceDepositSettlementSubmit
  -> AppM MarketplaceDepositSettlementDTO
submitMarketplaceDepositSettlement
    user rawOrderId mIdempotency MarketplaceDepositSettlementSubmit{..} = do
  requireMarketplaceAccess user
  requireModule user ModuleInvoicing
  orderKey <- parseOrderId rawOrderId
  idempotencyKey <- either (throwError . marketplaceCheckoutBadRequest) pure
    (ServiceStorefront.validateIdempotencyKey mIdempotency)
  method <- either (throwError . marketplaceCheckoutBadRequest) pure
    (MarketplaceOperations.parseMarketplaceDepositSettlementMethod mdssSettlementMethod)
  externalReference <- either throwError pure
    (validateMarketplaceRequiredOperationText
      "externalReference" 160 mdssExternalReference)
  evidenceUrl <- either throwError pure
    (validateMarketplaceRentalEvidenceUrl (Just mdssEvidenceUrl))
      >>= maybe (throwError err400 { errBody = "evidenceUrl is required" }) pure
  runtimeRows <- runDB (rawSql
    "SELECT runtime.checkout_id::text, checkout.currency,\
    \ runtime.security_deposit_usd_cents, runtime.deposit_deduction_usd_cents,\
    \ runtime.security_deposit_usd_cents - runtime.deposit_deduction_usd_cents,\
    \ runtime.rental_status, runtime.deposit_status\
    \ FROM marketplace_rental_order_runtime runtime\
    \ JOIN commerce_checkout_session checkout ON checkout.id = runtime.checkout_id\
    \ WHERE runtime.order_id = ?::uuid"
    [PersistText (toPathPiece orderKey)]
    :: SqlPersistT IO
      [( Single Text, Single Text, Single Int64, Single Int64, Single Int64
       , Single Text, Single Text
       )])
  (checkoutId, currency, depositAmount, deductionAmount, refundAmount) <-
    case runtimeRows of
      [( Single storedCheckoutId, Single storedCurrency, Single deposit
       , Single deduction, Single refund, Single rentalStatus, Single depositStatus
       )]
        | rentalStatus /= "deposit_refund_due"
            || depositStatus `notElem` ["refund_due", "partial_refund_due"] ->
                throwError (marketplaceCheckoutConflict
                  "Rental deposit is not due for settlement")
        | otherwise -> pure
            (storedCheckoutId, storedCurrency, deposit, deduction, refund)
      [] -> throwError err409
        { errBody = "This order is not a canonical marketplace rental" }
      _ -> throwError (marketplaceCheckoutInternal
        "Marketplace rental deposit context is ambiguous")
  either (throwError . marketplaceCheckoutBadRequest) pure
    (MarketplaceOperations.validateMarketplaceDepositSettlement
      method depositAmount deductionAmount refundAmount)
  environment <- runDB
    (Checkout.loadCheckoutEnvironment (Checkout.CheckoutReference checkoutId))
    >>= either (throwError . marketplaceCheckoutInternal) pure
  capabilityEnabled <- runDB $
    Checkout.capabilityEnabledForEnvironment environment
      "commerce.marketplace_manual_deposit_settlement"
  unless capabilityEnabled $
    throwError err503
      { errBody = "Manual marketplace deposit settlement is disabled in this environment" }
  let orderId = toPathPiece orderKey
      methodText = MarketplaceOperations.marketplaceDepositSettlementMethodText method
      submittedBy = fromSqlKey (auPartyId user)
      requestHash = marketplaceSha256Text . TE.decodeUtf8 . BL.toStrict . encode $ object
        [ "order_id" .= orderId
        , "checkout_id" .= checkoutId
        , "currency" .= currency
        , "deposit_amount_minor" .= depositAmount
        , "deduction_amount_minor" .= deductionAmount
        , "refund_amount_minor" .= refundAmount
        , "settlement_method" .= methodText
        , "external_reference" .= externalReference
        , "evidence_url" .= evidenceUrl
        ]
  created <- runMarketplaceOperationWrite
    "Deposit settlement evidence conflicts with existing or changed rental state" $ do
      _ <- (rawSql
        "SELECT 1::bigint FROM (\
        \ SELECT pg_advisory_xact_lock(hashtextextended(?, 0))\
        \) lock_acquired"
        [PersistText ("marketplace-deposit-settlement:" <> orderId <> ":" <> idempotencyKey)]
        :: SqlPersistT IO [Single Int64])
      existing <- (rawSql
        "SELECT id::text, request_sha256\
        \ FROM marketplace_rental_deposit_settlement\
        \ WHERE order_id = ?::uuid AND idempotency_key = ?"
        [PersistText orderId, PersistText idempotencyKey]
        :: SqlPersistT IO [(Single Text, Single Text)])
      case existing of
        [(Single settlementId, Single storedHash)]
          | storedHash == requestHash -> pure (Right settlementId)
          | otherwise -> pure (Left
              "Idempotency key was already used for different deposit evidence")
        [] -> do
          inserted <- (rawSql
            "INSERT INTO marketplace_rental_deposit_settlement(\
            \ order_id, checkout_id, currency, deposit_amount_minor,\
            \ deduction_amount_minor, refund_amount_minor, settlement_method,\
            \ external_reference, evidence_url, idempotency_key, request_sha256, submitted_by\
            \) VALUES (?::uuid, ?::uuid, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)\
            \ RETURNING id::text"
            [ PersistText orderId
            , PersistText checkoutId
            , PersistText currency
            , PersistInt64 depositAmount
            , PersistInt64 deductionAmount
            , PersistInt64 refundAmount
            , PersistText methodText
            , PersistText externalReference
            , PersistText evidenceUrl
            , PersistText idempotencyKey
            , PersistText requestHash
            , PersistInt64 submittedBy
            ] :: SqlPersistT IO [Single Text])
          pure $ case inserted of
            [Single settlementId] -> Right settlementId
            _ -> Left "Deposit settlement evidence could not be created"
        _ -> pure (Left "Deposit settlement idempotency state is ambiguous")
  settlementId <- either (throwError . marketplaceCheckoutConflict) pure created
  runDB (loadMarketplaceDepositSettlementDTO orderKey settlementId)
    >>= either throwError pure
      . requireLoadedMarketplaceWriteResult "Marketplace deposit settlement"

reviewMarketplaceDepositSettlement
  :: AuthedUser
  -> Text
  -> Text
  -> MarketplaceDepositSettlementReview
  -> AppM MarketplaceDepositSettlementDTO
reviewMarketplaceDepositSettlement
    user rawOrderId rawSettlementId MarketplaceDepositSettlementReview{..} = do
  requireMarketplaceAccess user
  requireModule user ModuleInvoicing
  orderKey <- parseOrderId rawOrderId
  settlementId <- either throwError pure
    (validateMarketplacePathId "settlement" rawSettlementId)
  action <- either (throwError . marketplaceCheckoutBadRequest) pure
    (MarketplaceOperations.parseMarketplaceCustomerReviewAction mdsrAction)
  nextStatus <- case action of
    MarketplaceOperations.CustomerRequestApprove -> pure "verified"
    MarketplaceOperations.CustomerRequestReject -> pure "rejected"
    MarketplaceOperations.CustomerRequestRequireReconciliation ->
      pure "requires_reconciliation"
    MarketplaceOperations.CustomerRequestNeedsQuoteAction ->
      throwError err400
        { errBody = "Deposit settlement review action must be approve, reject, or requires_reconciliation" }
  reviewNotes <- either throwError pure
    (validateMarketplaceRequiredOperationText "reviewNotes" 1000 mdsrReviewNotes)
  settlementRows <- runDB (rawSql
    "SELECT status, submitted_by FROM marketplace_rental_deposit_settlement\
    \ WHERE id = ?::uuid AND order_id = ?::uuid"
    [PersistText settlementId, PersistText (toPathPiece orderKey)]
    :: SqlPersistT IO [(Single Text, Single Int64)])
  (currentStatus, submittedBy) <- case settlementRows of
    [(Single status, Single submitter)] -> pure (status, submitter)
    [] -> throwError marketplaceOrderNotFound
    _ -> throwError (marketplaceCheckoutInternal
      "Marketplace deposit settlement lookup was ambiguous")
  let reviewerId = fromSqlKey (auPartyId user)
  either (throwError . marketplaceCheckoutConflict) pure
    (MarketplaceOperations.validateIndependentDepositReviewer submittedBy reviewerId)
  if currentStatus == nextStatus
    then runDB (loadMarketplaceDepositSettlementDTO orderKey settlementId)
      >>= either throwError pure
        . requireLoadedMarketplaceWriteResult "Marketplace deposit settlement"
    else do
      when (currentStatus /= "submitted") $
        throwError (marketplaceCheckoutConflict
          "Reviewed deposit settlement evidence cannot be changed")
      now <- liftIO getCurrentTime
      updated <- runMarketplaceOperationWrite
        "Rental or checkout state changed before deposit settlement review" $
          (rawSql
            "UPDATE marketplace_rental_deposit_settlement SET status = ?, reviewed_by = ?,\
            \ reviewed_at = ?, review_notes = ?\
            \ WHERE id = ?::uuid AND order_id = ?::uuid AND status = 'submitted'\
            \ RETURNING id::text"
            [ PersistText nextStatus
            , PersistInt64 reviewerId
            , PersistUTCTime now
            , PersistText reviewNotes
            , PersistText settlementId
            , PersistText (toPathPiece orderKey)
            ] :: SqlPersistT IO [Single Text])
      when (null updated) $
        throwError (marketplaceCheckoutConflict
          "Deposit settlement changed concurrently; reload before retrying")
      runDB (loadMarketplaceDepositSettlementDTO orderKey settlementId)
        >>= either throwError pure
          . requireLoadedMarketplaceWriteResult "Marketplace deposit settlement"

listMarketplaceOrders :: AuthedUser -> Maybe Text -> Maybe Int -> Maybe Int -> AppM [MarketplaceOrderDTO]
listMarketplaceOrders user mStatus mLimit mOffset = do
  requireMarketplaceAccess user
  limitCount <- either throwError pure (validateMarketplaceOrderListLimit mLimit)
  offsetCount <- either throwError pure (validateMarketplaceOrderListOffset mOffset)
  normalizedStatus <- either throwError pure (validateOptionalMarketplaceOrderStatus mStatus)
  let filters = maybe [] (\st -> [ME.MarketplaceOrderStatus ==. st]) normalizedStatus
  Env{..} <- ask
  liftIO $ flip runSqlPool envPool $ do
    orders <- selectList filters [Desc ME.MarketplaceOrderCreatedAt, OffsetBy offsetCount, LimitTo limitCount]
    catMaybes <$> mapM (loadOrderDTO . entityKey) orders

updateMarketplaceOrder :: AuthedUser -> Text -> MarketplaceOrderUpdate -> AppM MarketplaceOrderDTO
updateMarketplaceOrder user rawId MarketplaceOrderUpdate{..} = do
  requireMarketplaceAccess user
  orderKey <- parseOrderId rawId
  nextStatus <- either throwError pure (validateMarketplaceOrderUpdateStatus mouStatus)
  nextProvider <- either throwError pure (validateOptionalMarketplacePaymentProviderUpdate mouPaymentProvider)
  now <- liftIO getCurrentTime
  paidAtInput <- either throwError pure (validateMarketplaceOrderPaidAtUpdate now mouPaidAt)
  Env{..} <- ask
  when (nextStatus == Just "paid") $ do
    canonicalRuntime <- liftIO $ flip runSqlPool envPool $
      (rawSql
        "SELECT 1::bigint FROM marketplace_order_checkout_runtime WHERE order_id = ?::uuid"
        [PersistText (toPathPiece orderKey)] :: SqlPersistT IO [Single Int64])
    unless (null canonicalRuntime) $
      throwError err409
        { errBody = "Canonical marketplace payments can only become paid from verified provider evidence"
        }
  mDto <- liftIO $ flip runSqlPool envPool $ do
    mOrder <- get orderKey
    case mOrder of
      Nothing -> pure Nothing
      Just order -> do
        case validateMarketplaceStripeAdminUpdate
          (ME.marketplaceOrderStatus order)
          (ME.marketplaceOrderPaymentProvider order)
          nextStatus
          nextProvider of
            Left err -> liftIO $ throwIO err
            Right () -> pure ()
        paidAtFinal <-
          case resolveMarketplaceOrderPaidAtForStatus
            now
            (ME.marketplaceOrderStatus order)
            nextStatus
            (ME.marketplaceOrderPaidAt order)
            paidAtInput of
              Left err -> liftIO $ throwIO err
              Right value -> pure value
        let updates = catMaybes
              [ fmap (ME.MarketplaceOrderStatus =.) nextStatus
              , fmap (ME.MarketplaceOrderPaymentProvider =.) nextProvider
              , if paidAtFinal /= ME.marketplaceOrderPaidAt order
                  then Just (ME.MarketplaceOrderPaidAt =. paidAtFinal)
                  else Nothing
              ]
            updatesWithTimestamp =
              if null updates
                then []
                else updates ++ [ME.MarketplaceOrderUpdatedAt =. now]
        unless (null updatesWithTimestamp) $ update orderKey updatesWithTimestamp
        loadOrderDTO orderKey
  either throwError pure (requireMarketplaceOrderLookupResult mDto)

updateMarketplaceFulfillment
  :: AuthedUser
  -> Text
  -> MarketplaceFulfillmentUpdate
  -> AppM MarketplaceOrderDTO
updateMarketplaceFulfillment user rawId MarketplaceFulfillmentUpdate{..} = do
  requireMarketplaceAccess user
  orderKey <- parseOrderId rawId
  nextState <- either (throwError . marketplaceCheckoutBadRequest) pure
    (MarketplaceSales.parseMarketplaceFulfillmentState mfuStatus)
  carrier <- either throwError pure
    (normalizeMarketplaceFulfillmentField "carrier" 120 mfuCarrier)
  trackingReference <- either throwError pure
    (normalizeMarketplaceFulfillmentField "trackingReference" 160 mfuTrackingReference)
  reasonCode <- either throwError pure
    (normalizeMarketplaceFulfillmentField "reasonCode" 80 mfuReasonCode)
  notes <- either throwError pure
    (normalizeMarketplaceFulfillmentField "notes" 500 mfuNotes)
  Env{ envPool } <- ask
  runtimeRows <- liftIO $ flip runSqlPool envPool $
    (rawSql
      "SELECT fulfillment_method, fulfillment_status, tracking_reference\
      \ FROM marketplace_sale_order_runtime WHERE order_id = ?::uuid"
      [PersistText (toPathPiece orderKey)]
      :: SqlPersistT IO [(Single Text, Single Text, Single (Maybe Text))])
  (methodText, currentStateText, storedTracking) <- case runtimeRows of
    [(Single methodValue, Single statusValue, Single trackingValue)] ->
      pure (methodValue, statusValue, trackingValue)
    [] -> throwError err409
      { errBody = "This historical order is not linked to the marketplace fulfillment runtime"
      }
    _ -> throwError (marketplaceCheckoutInternal
      "Marketplace fulfillment runtime lookup was ambiguous")
  method <- either (throwError . marketplaceCheckoutInternal) pure
    (MarketplaceSales.parseMarketplaceFulfillmentMethod methodText)
  currentState <- either (throwError . marketplaceCheckoutInternal) pure
    (MarketplaceSales.parseMarketplaceFulfillmentState currentStateText)
  either (throwError . marketplaceCheckoutConflict) pure
    (MarketplaceSales.validateMarketplaceFulfillmentTransition method currentState nextState)
  when (nextState == MarketplaceSales.MarketplaceShipped
      && isNothing (trackingReference <|> storedTracking)) $
    throwError err400 { errBody = "Tracking reference is required before an order is shipped" }
  let nextStateText = MarketplaceSales.marketplaceFulfillmentStateText nextState
      actorId = toPathPiece (auPartyId user)
  updatedRows <- liftIO $ flip runSqlPool envPool $
    (rawSql
      "WITH actor_context AS MATERIALIZED (\
      \ SELECT set_config('tdf.actor_type', 'operator', true),\
      \ set_config('tdf.actor_id', ?, true),\
      \ set_config('tdf.reason_code', ?, true),\
      \ set_config('tdf.notes', ?, true)\
      \) UPDATE marketplace_sale_order_runtime SET fulfillment_status = ?,\
      \ carrier = COALESCE(?, carrier),\
      \ tracking_reference = COALESCE(?, tracking_reference)\
      \ FROM actor_context WHERE order_id = ?::uuid AND fulfillment_status = ?\
      \ RETURNING marketplace_sale_order_runtime.fulfillment_status"
      [ PersistText actorId
      , PersistText (fromMaybe "" reasonCode)
      , PersistText (fromMaybe "" notes)
      , PersistText nextStateText
      , maybe PersistNull PersistText carrier
      , maybe PersistNull PersistText trackingReference
      , PersistText (toPathPiece orderKey)
      , PersistText currentStateText
      ] :: SqlPersistT IO [Single Text])
  when (null updatedRows) $
    throwError (marketplaceCheckoutConflict
      "Marketplace fulfillment state changed concurrently; reload the order before retrying")
  mDto <- liftIO $ flip runSqlPool envPool $ loadOrderDTO orderKey
  either throwError pure (requireLoadedMarketplaceWriteResult "Marketplace order" mDto)

updateMarketplaceRental
  :: AuthedUser
  -> Text
  -> MarketplaceRentalUpdate
  -> AppM MarketplaceOrderDTO
updateMarketplaceRental user rawId MarketplaceRentalUpdate{..} = do
  requireMarketplaceAccess user
  orderKey <- parseOrderId rawId
  nextState <- either (throwError . marketplaceCheckoutBadRequest) pure
    (MarketplaceRentals.parseMarketplaceRentalState mruStatus)
  conditionOut <- either throwError pure
    (normalizeMarketplaceFulfillmentField "conditionOut" 1000 mruConditionOut)
  conditionIn <- either throwError pure
    (normalizeMarketplaceFulfillmentField "conditionIn" 1000 mruConditionIn)
  evidenceUrl <- either throwError pure (validateMarketplaceRentalEvidenceUrl mruEvidenceUrl)
  reasonCode <- either throwError pure
    (normalizeMarketplaceFulfillmentField "reasonCode" 80 mruReasonCode)
  notes <- either throwError pure
    (normalizeMarketplaceFulfillmentField "notes" 1000 mruNotes)
  deduction <- case mruDepositDeductionUsdCents of
    Nothing -> pure Nothing
    Just amount | amount >= 0 -> pure (Just amount)
    Just _ -> throwError err400 { errBody = "Deposit deduction cannot be negative" }
  Env{ envPool } <- ask
  runtimeRows <- liftIO $ flip runSqlPool envPool $
    (rawSql
      "SELECT rental_status, deposit_status, security_deposit_usd_cents,\
      \ deposit_deduction_usd_cents, condition_out, condition_in\
      \ FROM marketplace_rental_order_runtime WHERE order_id = ?::uuid"
      [PersistText (toPathPiece orderKey)]
      :: SqlPersistT IO
        [( Single Text, Single Text, Single Int64, Single Int64
         , Single (Maybe Text), Single (Maybe Text)
         )])
  (currentStateText, depositStatus, securityDeposit, currentDeduction, storedConditionOut, storedConditionIn) <-
    case runtimeRows of
      [( Single stateValue, Single depositValue, Single depositAmount, Single deductionAmount
       , Single outboundCondition, Single inboundCondition
       )] -> pure
          ( stateValue, depositValue, fromIntegral depositAmount, fromIntegral deductionAmount
          , outboundCondition, inboundCondition
          )
      [] -> throwError err409 { errBody = "This order is not a canonical marketplace rental" }
      _ -> throwError (marketplaceCheckoutInternal "Marketplace rental runtime lookup was ambiguous")
  currentState <- either (throwError . marketplaceCheckoutInternal) pure
    (MarketplaceRentals.parseMarketplaceRentalState currentStateText)
  either (throwError . marketplaceCheckoutConflict) pure
    (MarketplaceRentals.validateMarketplaceRentalTransition currentState nextState)
  let finalDeduction = fromMaybe currentDeduction deduction
      finalConditionOut = conditionOut <|> storedConditionOut
      finalConditionIn = conditionIn <|> storedConditionIn
  when (finalDeduction > securityDeposit) $
    throwError err400 { errBody = "Deposit deduction cannot exceed the collected security deposit" }
  when (isJust deduction && nextState `notElem`
      [ MarketplaceRentals.RentalDamageReview
      , MarketplaceRentals.RentalDepositRefundDue
      , MarketplaceRentals.RentalDisputed
      ]) $
    throwError err400 { errBody = "Deposit deductions require damage review, refund due, or dispute state" }
  when (nextState == MarketplaceRentals.RentalCheckedOut && isNothing finalConditionOut) $
    throwError err400 { errBody = "Rental handoff requires an outbound condition report" }
  when (nextState == MarketplaceRentals.RentalReturnedPendingInspection && isNothing finalConditionIn) $
    throwError err400 { errBody = "Rental return requires an inbound condition report" }
  when (nextState == MarketplaceRentals.RentalClosed
      && securityDeposit > 0
      && depositStatus `notElem` ["refunded", "partially_refunded", "forfeited"]) $
    throwError err409
      { errBody = "Rental cannot close until deposit settlement has verified terminal evidence" }
  let nextStateText = MarketplaceRentals.marketplaceRentalStateText nextState
      actorId = toPathPiece (auPartyId user)
  updatedRows <- liftIO $ flip runSqlPool envPool $
    (rawSql
      "WITH actor_context AS MATERIALIZED (\
      \ SELECT set_config('tdf.actor_type', 'operator', true),\
      \ set_config('tdf.actor_id', ?, true), set_config('tdf.reason_code', ?, true),\
      \ set_config('tdf.notes', ?, true)\
      \) UPDATE marketplace_rental_order_runtime SET rental_status = ?,\
      \ condition_out = COALESCE(?, condition_out), condition_in = COALESCE(?, condition_in),\
      \ evidence_url = COALESCE(?, evidence_url),\
      \ deposit_deduction_usd_cents = COALESCE(?, deposit_deduction_usd_cents),\
      \ checked_out_at = CASE WHEN ? = 'checked_out' THEN COALESCE(checked_out_at, NOW()) ELSE checked_out_at END,\
      \ returned_at = CASE WHEN ? = 'returned_pending_inspection' THEN COALESCE(returned_at, NOW()) ELSE returned_at END\
      \ FROM actor_context WHERE order_id = ?::uuid AND rental_status = ?\
      \ RETURNING marketplace_rental_order_runtime.rental_status"
      [ PersistText actorId
      , PersistText (fromMaybe "" reasonCode)
      , PersistText (fromMaybe "" notes)
      , PersistText nextStateText
      , maybe PersistNull PersistText conditionOut
      , maybe PersistNull PersistText conditionIn
      , maybe PersistNull PersistText evidenceUrl
      , maybe PersistNull (PersistInt64 . fromIntegral) deduction
      , PersistText nextStateText
      , PersistText nextStateText
      , PersistText (toPathPiece orderKey)
      , PersistText currentStateText
      ] :: SqlPersistT IO [Single Text])
  when (null updatedRows) $
    throwError (marketplaceCheckoutConflict
      "Marketplace rental state changed concurrently; reload the order before retrying")
  mDto <- liftIO $ flip runSqlPool envPool $ loadOrderDTO orderKey
  either throwError pure (requireLoadedMarketplaceWriteResult "Marketplace rental" mDto)

validateMarketplaceRentalEvidenceUrl :: Maybe Text -> Either ServerError (Maybe Text)
validateMarketplaceRentalEvidenceUrl Nothing = Right Nothing
validateMarketplaceRentalEvidenceUrl (Just rawValue)
  | T.null value || T.length value > 2048 = Left invalid
  | T.any (\ch -> isControl ch || generalCategory ch == Format || isSpace ch) value = Left invalid
  | "https://" `T.isPrefixOf` T.toLower value = Right (Just value)
  | "/assets/" `T.isPrefixOf` value = Right (Just value)
  | otherwise = Left invalid
  where
    value = T.strip rawValue
    invalid = err400
      { errBody = "evidenceUrl must be an HTTPS or private application asset reference" }

normalizeMarketplaceFulfillmentField
  :: Text
  -> Int
  -> Maybe Text
  -> Either ServerError (Maybe Text)
normalizeMarketplaceFulfillmentField _ _ Nothing = Right Nothing
normalizeMarketplaceFulfillmentField fieldName maxLength (Just rawValue)
  | T.null value = Left invalid
  | T.length value > maxLength = Left invalid
  | T.any (\ch -> isControl ch || generalCategory ch == Format) value = Left invalid
  | otherwise = Right (Just value)
  where
    value = T.strip rawValue
    invalid = err400
      { errBody = BL.fromStrict . TE.encodeUtf8 $
          fieldName <> " must contain 1 to " <> T.pack (show maxLength) <> " safe characters"
      }

validateMarketplaceStripeAdminUpdate
  :: Text
  -> Maybe Text
  -> Maybe Text
  -> Maybe (Maybe Text)
  -> Either ServerError ()
validateMarketplaceStripeAdminUpdate currentStatus currentProvider nextStatus nextProvider
  | finalStatus /= "stripe_pending" = Right ()
  | currentStatus /= "stripe_pending" =
      Left err409
        { errBody = "stripe_pending is managed by the Stripe checkout flow"
        }
  | finalProvider /= Just "stripe" =
      Left err409
        { errBody = "stripe_pending orders must keep the Stripe payment provider"
        }
  | otherwise = Right ()
  where
    finalStatus = fromMaybe currentStatus nextStatus
    finalProvider = fromMaybe currentProvider nextProvider

getOrder :: Text -> Maybe Text -> AppM MarketplaceOrderDTO
getOrder rawId mLookupToken = do
  orderKey <- parseOrderId rawId
  requireMarketplaceOrderLookupToken orderKey mLookupToken
  Env{..} <- ask
  mDto <- liftIO $ flip runSqlPool envPool $ loadOrderDTO orderKey
  orderDto <- either throwError pure (requireMarketplaceOrderLookupResult mDto)
  pure (redactMarketplaceOrderForPublicLookup orderDto)

redactMarketplaceOrderForPublicLookup :: MarketplaceOrderDTO -> MarketplaceOrderDTO
redactMarketplaceOrderForPublicLookup orderDto =
  orderDto
    { moCartId = Nothing
    , moBuyerName = ""
    , moBuyerEmail = ""
    , moBuyerPhone = Nothing
    , moPaypalOrderId = Nothing
    , moPaypalPayerEmail = Nothing
    , moLookupToken = Nothing
    }

requireMarketplaceOrderLookupToken
  :: Key ME.MarketplaceOrder
  -> Maybe Text
  -> AppM ()
requireMarketplaceOrderLookupToken orderKey mRawToken = do
  Env{ envPool } <- ask
  storedHashes <- liftIO $ flip runSqlPool envPool $
    (rawSql
      "SELECT lookup_token_hash FROM marketplace_order_checkout_runtime WHERE order_id = ?::uuid"
      [PersistText (toPathPiece orderKey)] :: SqlPersistT IO [Single Text])
  case storedHashes of
    [] -> throwError marketplaceOrderNotFound
    [Single expectedHash]
      | Just rawToken <- T.strip <$> mRawToken
      , not (T.null rawToken)
      , TE.encodeUtf8 expectedHash `constEq`
          TE.encodeUtf8 (marketplaceSha256Text rawToken) -> pure ()
    _ -> throwError marketplaceOrderNotFound

parseOrderId :: Text -> AppM (Key ME.MarketplaceOrder)
parseOrderId rawId = do
  normalizedId <- either throwError pure (validateMarketplacePathId "order" rawId)
  case fromPathPiece normalizedId of
    Nothing -> throwBadRequest "Invalid order id"
    Just k -> pure k

parseCartId :: Text -> AppM (Key ME.MarketplaceCart)
parseCartId rawId = do
  normalizedId <- either throwError pure (validateMarketplacePathId "cart" rawId)
  case fromPathPiece normalizedId of
    Nothing -> throwBadRequest "Invalid cart id"
    Just k -> pure k

parseListingId :: Text -> AppM (Key ME.MarketplaceListing)
parseListingId rawId = do
  normalizedId <- either throwError pure (validateMarketplacePathId "listing" rawId)
  case fromPathPiece normalizedId of
    Nothing -> throwBadRequest "Invalid listing id"
    Just k -> pure k

validateMarketplacePathId :: Text -> Text -> Either ServerError Text
validateMarketplacePathId label rawId =
  let normalized = T.strip rawId
      invalid =
        Left err400
          { errBody =
              BL.fromStrict (TE.encodeUtf8 ("Invalid " <> label <> " id"))
          }
  in
    case UUID.fromText normalized of
      Nothing -> invalid
      Just pathId -> Right (UUID.toText pathId)

marketplaceCartNotFound :: ServerError
marketplaceCartNotFound =
  err404 { errBody = "Marketplace cart not found" }

marketplaceListingNotFound :: ServerError
marketplaceListingNotFound =
  err404 { errBody = "Marketplace listing not found" }

marketplaceOrderNotFound :: ServerError
marketplaceOrderNotFound =
  err404 { errBody = "Marketplace order not found" }

requireMarketplaceOrderLookupResult :: Maybe a -> Either ServerError a
requireMarketplaceOrderLookupResult (Just value) =
  Right value
requireMarketplaceOrderLookupResult Nothing =
  Left marketplaceOrderNotFound

requireLoadedMarketplaceWriteResult :: Text -> Maybe a -> Either ServerError a
requireLoadedMarketplaceWriteResult _ (Just value) =
  Right value
requireLoadedMarketplaceWriteResult entityLabel Nothing =
  Left err500
    { errBody =
        BL.fromStrict . TE.encodeUtf8 $
          entityLabel <> " could not be loaded after write"
    }

requireLoadedMarketplacePublicOrderResponse
  :: Text
  -> Maybe MarketplaceOrderDTO
  -> Either ServerError MarketplaceOrderDTO
requireLoadedMarketplacePublicOrderResponse entityLabel mDto =
  redactMarketplaceOrderForPublicLookup
    <$> requireLoadedMarketplaceWriteResult entityLabel mDto

validateMarketplacePublicListingActive :: Bool -> Either ServerError ()
validateMarketplacePublicListingActive True = Right ()
validateMarketplacePublicListingActive False =
  Left marketplaceListingNotFound

requireMarketplaceAccess :: AuthedUser -> AppM ()
requireMarketplaceAccess user =
  unless (hasOperationsAccess user) $
    throwError err403

data MarketplaceCartTotalsState a
  = MarketplaceCartMissing
  | MarketplaceCartEmpty
  | MarketplaceCartInvalidQuantity Int
  | MarketplaceCartInvalidRental Text
  | MarketplaceCartInvalidAmount Text
  | MarketplaceCartInvalidCurrency Text
  | MarketplaceCartMixedCurrencies [Text]
  | MarketplaceCartTotalsReady a
  deriving (Eq, Show)

loadCartDTO :: Text -> Key ME.MarketplaceCart -> SqlPersistT IO (Either ServerError (Maybe MarketplaceCartDTO))
loadCartDTO configuredDefault cartId = do
  mCart <- get cartId
  case mCart of
    Nothing -> pure (Right Nothing)
    Just _ -> do
      items <- loadCartLines cartId
      pure $ case cartToDTO configuredDefault cartId items of
        Left message -> Left err409 { errBody = BL.fromStrict (TE.encodeUtf8 message) }
        Right dto -> Right (Just dto)

data MarketplaceCartLine = MarketplaceCartLine
  { mclCartItem :: Entity ME.MarketplaceCartItem
  , mclListing :: Entity ME.MarketplaceListing
  , mclAsset :: Entity ME.Asset
  , mclQuantity :: Int
  , mclPurpose :: Text
  , mclUnitPriceCents :: Int
  , mclSubtotalCents :: Int
  , mclRentalStartDate :: Maybe Day
  , mclRentalEndDate :: Maybe Day
  , mclRentalBreakdown :: Maybe MarketplaceRentals.RentalPriceBreakdown
  , mclRentalTerms :: Maybe MarketplaceRentalTerms
  , mclPricingError :: Maybe Text
  } deriving (Show)

loadCartTotals
  :: Key ME.MarketplaceCart
  -> SqlPersistT IO (MarketplaceCartTotalsState ([MarketplaceCartLine], Int, Text))
loadCartTotals cartId = do
  mCart <- get cartId
  case mCart of
    Nothing -> pure MarketplaceCartMissing
    Just _ -> do
      items <- loadCartLines cartId
      if null items
        then pure MarketplaceCartEmpty
        else do
          let pricingErrors = mapMaybe mclPricingError items
              quantities = map mclQuantity items
          case find isInvalidMarketplaceCartLineQuantity quantities of
            Just invalidQuantity ->
              pure (MarketplaceCartInvalidQuantity invalidQuantity)
            Nothing | pricingError : _ <- pricingErrors ->
              pure (MarketplaceCartInvalidRental pricingError)
            Nothing -> do
              let rawCurrencies =
                    map (ME.marketplaceListingCurrency . entityVal . mclListing) items
              case CommerceMoney.checkedCartTotal (map mclSubtotalCents items) of
                Left message -> pure (MarketplaceCartInvalidAmount message)
                Right totalCents -> case resolveMarketplaceCartCurrency rawCurrencies of
                  Left invalidCurrencyState -> pure invalidCurrencyState
                  Right currency ->
                    pure (MarketplaceCartTotalsReady (items, totalCents, currency))

requireMarketplaceCartTotals :: MarketplaceCartTotalsState a -> Either ServerError a
requireMarketplaceCartTotals MarketplaceCartMissing =
  Left marketplaceCartNotFound
requireMarketplaceCartTotals MarketplaceCartEmpty =
  Left err400 { errBody = "El carrito esta vacio." }
requireMarketplaceCartTotals (MarketplaceCartInvalidQuantity rawQuantity) =
  Left (marketplaceCartInvalidQuantityError rawQuantity)
requireMarketplaceCartTotals (MarketplaceCartInvalidAmount message) =
  Left err409 { errBody = BL.fromStrict (TE.encodeUtf8 message) }
requireMarketplaceCartTotals (MarketplaceCartInvalidRental message) =
  Left err409 { errBody = BL.fromStrict (TE.encodeUtf8 message) }
requireMarketplaceCartTotals (MarketplaceCartInvalidCurrency _) =
  Left err500 { errBody = "Stored marketplace listing currency is invalid" }
requireMarketplaceCartTotals (MarketplaceCartMixedCurrencies currencies) =
  Left err400
    { errBody =
        BL.fromStrict . TE.encodeUtf8 $
          "El carrito no puede mezclar monedas: " <> T.intercalate ", " currencies
    }
requireMarketplaceCartTotals (MarketplaceCartTotalsReady totals) =
  Right totals

resolveMarketplaceCartCurrency :: [Text] -> Either (MarketplaceCartTotalsState a) Text
resolveMarketplaceCartCurrency rawCurrencies =
  case find (isNothing . normalizeCurrencyCodeText) rawCurrencies of
    Just rawCurrency -> Left (MarketplaceCartInvalidCurrency rawCurrency)
    Nothing ->
      case nub (mapMaybe normalizeCurrencyCodeText rawCurrencies) of
        [] -> Left (MarketplaceCartInvalidCurrency "")
        [currency] -> Right currency
        mixed -> Left (MarketplaceCartMixedCurrencies mixed)

validateMarketplaceCartLineQuantity :: Int -> Either ServerError Int
validateMarketplaceCartLineQuantity rawQuantity
  | isInvalidMarketplaceCartLineQuantity rawQuantity =
      Left (marketplaceCartInvalidQuantityError rawQuantity)
  | otherwise =
      Right rawQuantity

isInvalidMarketplaceCartLineQuantity :: Int -> Bool
isInvalidMarketplaceCartLineQuantity rawQuantity =
  rawQuantity < 1 || rawQuantity > maxMarketplaceCartItemQuantity

marketplaceCartInvalidQuantityError :: Int -> ServerError
marketplaceCartInvalidQuantityError _ =
  err409
    { errBody =
        BL.fromStrict . TE.encodeUtf8 $
          "El carrito contiene una cantidad invalida; actualiza las cantidades entre 1 y "
            <> T.pack (show maxMarketplaceCartItemQuantity)
            <> "."
    }

validateMarketplaceOnlinePaymentTotal :: Int -> Either ServerError Int
validateMarketplaceOnlinePaymentTotal totalCents
  | totalCents > 0 = Right totalCents
  | otherwise =
      Left err400 { errBody = "El carrito debe tener un total mayor a 0 para pagar en linea." }

validateMarketplaceOrderPaidAtUpdate
  :: UTCTime
  -> Maybe (Maybe UTCTime)
  -> Either ServerError (Maybe (Maybe UTCTime))
validateMarketplaceOrderPaidAtUpdate _ Nothing = Right Nothing
validateMarketplaceOrderPaidAtUpdate _ (Just Nothing) = Right (Just Nothing)
validateMarketplaceOrderPaidAtUpdate now (Just (Just paidAt))
  | paidAt <= now = Right (Just (Just paidAt))
  | otherwise = Left err400 { errBody = "paidAt must not be in the future" }

resolveMarketplaceOrderPaidAtForStatus
  :: UTCTime
  -> Text
  -> Maybe Text
  -> Maybe UTCTime
  -> Maybe (Maybe UTCTime)
  -> Either ServerError (Maybe UTCTime)
resolveMarketplaceOrderPaidAtForStatus now currentStatus mNextStatus currentPaidAt paidAtInput = do
  storedStatus <- validateStoredMarketplaceOrderStatus currentStatus
  let statusFinal = fromMaybe storedStatus mNextStatus
      isExplicitPaidAtForNonPaidStatus =
        not (isPaidMarketplaceOrderStatus statusFinal)
          && maybe False isJust paidAtInput
      paidAtBase =
        case paidAtInput of
          Nothing -> currentPaidAt
          Just value -> value
      paidAtFinal =
        if isNothing paidAtInput
            && maybe False isPaidMarketplaceOrderStatus mNextStatus
            && isNothing currentPaidAt
          then Just now
          else paidAtBase
  if isExplicitPaidAtForNonPaidStatus
    then Left err400 { errBody = "paidAt can only be set when status is paid" }
    else
      if isPaidMarketplaceOrderStatus statusFinal && isNothing paidAtFinal
        then Left err400 { errBody = "paidAt is required when status is paid" }
        else Right paidAtFinal

validateStoredMarketplaceOrderStatus :: Text -> Either ServerError Text
validateStoredMarketplaceOrderStatus rawStatus =
  case normalizeMarketplaceOrderStatus rawStatus of
    Just normalized -> Right normalized
    Nothing ->
      Left err500 { errBody = "Stored marketplace order status is invalid" }

isPaidMarketplaceOrderStatus :: Text -> Bool
isPaidMarketplaceOrderStatus rawStatus =
  T.toLower (T.strip rawStatus) == "paid"

loadCartLines
  :: Key ME.MarketplaceCart
  -> SqlPersistT IO [MarketplaceCartLine]
loadCartLines cartId = do
  cartItems <- selectList [ME.MarketplaceCartItemCartId ==. cartId] [Asc ME.MarketplaceCartItemId]
  forM cartItems $ \ent@(Entity _ ci) -> do
    listing <- getJustEntity (ME.marketplaceCartItemListingId ci)
    asset   <- getJustEntity (ME.marketplaceListingAssetId (entityVal listing))
    let checkedSubtotal = CommerceMoney.checkedCartSubtotal
          (ME.marketplaceCartItemQuantity ci) (ME.marketplaceListingPriceUsdCents (entityVal listing))
        subtotal = either (const 0) (\amount -> amount) checkedSubtotal
        qty = ME.marketplaceCartItemQuantity ci
        purpose = T.toLower (T.strip (ME.marketplaceListingPurpose (entityVal listing)))
        saleLine = MarketplaceCartLine
          { mclCartItem = ent
          , mclListing = listing
          , mclAsset = asset
          , mclQuantity = qty
          , mclPurpose = purpose
          , mclUnitPriceCents = ME.marketplaceListingPriceUsdCents (entityVal listing)
          , mclSubtotalCents = subtotal
          , mclRentalStartDate = Nothing
          , mclRentalEndDate = Nothing
          , mclRentalBreakdown = Nothing
          , mclRentalTerms = Nothing
          , mclPricingError = case checkedSubtotal of
              Left message -> Just message
              Right _ -> if purpose == "sale" then Nothing else Just "Unsupported marketplace cart line"
          }
    if purpose /= "rent"
      then pure saleLine
      else do
        selectionRows <- (rawSql
          "SELECT start_date, end_date, duration_days\
          \ FROM marketplace_rental_cart_selection WHERE cart_item_id = ?::uuid"
          [PersistText (toPathPiece (entityKey ent))]
          :: SqlPersistT IO [(Single Day, Single Day, Single Int)])
        mTerms <- loadActiveMarketplaceRentalTerms (entityKey listing)
        pure $ case (selectionRows, mTerms) of
          ([(Single startDate, Single endDate, Single durationDays)], Just terms) ->
            case MarketplaceRentals.calculateRentalPrice
              (mrtDailyRateCents terms)
              (mrtWeeklyRateCents terms)
              (mrtSecurityDepositCents terms)
              (mrtMinDays terms)
              (mrtMaxDays terms)
              durationDays of
                Left message -> saleLine
                  { mclPurpose = "rent"
                  , mclRentalStartDate = Just startDate
                  , mclRentalEndDate = Just endDate
                  , mclRentalTerms = Just terms
                  , mclPricingError = Just message
                  }
                Right breakdown -> saleLine
                  { mclPurpose = "rent"
                  , mclUnitPriceCents = mrtDailyRateCents terms
                  , mclSubtotalCents = MarketplaceRentals.rpbCheckoutTotalMinor breakdown
                  , mclRentalStartDate = Just startDate
                  , mclRentalEndDate = Just endDate
                  , mclRentalBreakdown = Just breakdown
                  , mclRentalTerms = Just terms
                  , mclPricingError = Nothing
                  }
          ([], _) -> saleLine
            { mclPurpose = "rent"
            , mclPricingError = Just "Rental cart item is missing its date selection"
            }
          (_, Nothing) -> saleLine
            { mclPurpose = "rent"
            , mclPricingError = Just "Rental listing terms are no longer active"
            }
          _ -> saleLine
            { mclPurpose = "rent"
            , mclPricingError = Just "Rental cart date selection is ambiguous"
            }

cartToDTO
  :: Text
  -> Key ME.MarketplaceCart
  -> [MarketplaceCartLine]
  -> Either Text MarketplaceCartDTO
cartToDTO configuredDefault cartId items = do
  -- A failed line calculation uses a placeholder only inside the loader; never
  -- expose it as a successful zero-price cart or use it for payment admission.
  mapM_ (\line -> CommerceMoney.checkedCartSubtotal (mclQuantity line) (mclUnitPriceCents line)) items
  subtotal <- CommerceMoney.checkedCartTotal (map mclSubtotalCents items)
  let currency = maybe configuredDefault
        (ME.marketplaceListingCurrency . entityVal . mclListing) (listToMaybe items)
      itemDtos = flip map items $ \line ->
        let listingEnt = mclListing line
            assetEnt = mclAsset line
            listing = entityVal listingEnt
            asset = entityVal assetEnt
            unitPrice = mclUnitPriceCents line
            subtotalC = mclSubtotalCents line
            mBreakdown = mclRentalBreakdown line
        in MarketplaceCartItemDTO
            { mciListingId         = toPathPiece (entityKey listingEnt)
            , mciTitle             = ME.marketplaceListingTitle listing
            , mciCategory          = ME.assetCategory asset
            , mciBrand             = ME.assetBrand asset
            , mciModel             = ME.assetModel asset
            , mciQuantity          = mclQuantity line
            , mciUnitPriceUsdCents = unitPrice
            , mciSubtotalCents     = subtotalC
            , mciUnitPriceDisplay  = formatUsd unitPrice currency
            , mciSubtotalDisplay   = formatUsd subtotalC currency
            , mciPurpose           = mclPurpose line
            , mciRentalStartDate   = mclRentalStartDate line
            , mciRentalEndDate     = mclRentalEndDate line
            , mciRentalDurationDays = MarketplaceRentals.rpbDurationDays <$> mBreakdown
            , mciRentalChargeCents = MarketplaceRentals.rpbRentalChargeMinor <$> mBreakdown
            , mciRentalChargeDisplay =
                (\breakdown -> formatUsd (MarketplaceRentals.rpbRentalChargeMinor breakdown) currency)
                  <$> mBreakdown
            , mciSecurityDepositCents = MarketplaceRentals.rpbSecurityDepositMinor <$> mBreakdown
            , mciSecurityDepositDisplay =
                (\breakdown -> formatUsd (MarketplaceRentals.rpbSecurityDepositMinor breakdown) currency)
                  <$> mBreakdown
            }
  pure MarketplaceCartDTO
      { mcCartId          = toPathPiece cartId
      , mcItems           = itemDtos
      , mcCurrency        = currency
      , mcSubtotalCents   = subtotal
      , mcSubtotalDisplay = formatUsd subtotal currency
      }

loadOrderDTO :: Key ME.MarketplaceOrder -> SqlPersistT IO (Maybe MarketplaceOrderDTO)
loadOrderDTO orderId = do
  mOrder <- getEntity orderId
  case mOrder of
    Nothing -> pure Nothing
    Just orderEnt -> do
      orderItems <- selectList [ME.MarketplaceOrderItemOrderId ==. orderId] [Asc ME.MarketplaceOrderItemId]
      listings <- forM orderItems $ \(Entity _ oi) -> do
        mListing <- get (ME.marketplaceOrderItemListingId oi)
        pure (oi, mListing)
      runtimeRows <- (rawSql
        "SELECT checkout.status, runtime.order_kind, runtime.fulfillment_method, runtime.domain_status,\
        \ runtime.hold_expires_at, runtime.tracking_reference\
        \ FROM marketplace_order_checkout_runtime runtime\
        \ JOIN commerce_checkout_session checkout ON checkout.id = runtime.checkout_id\
        \ WHERE runtime.order_id = ?::uuid"
        [PersistText (toPathPiece orderId)]
        :: SqlPersistT IO
          [( Single Text, Single Text, Single Text, Single Text
           , Single UTCTime, Single (Maybe Text)
           )])
      rentalRows <- (rawSql
        "SELECT start_date, end_date, duration_days, rental_charge_usd_cents,\
        \ security_deposit_usd_cents, deposit_status, deposit_deduction_usd_cents,\
        \ terms_version, timezone, condition_out, condition_in\
        \ FROM marketplace_rental_order_runtime WHERE order_id = ?::uuid"
        [PersistText (toPathPiece orderId)]
        :: SqlPersistT IO
          [( Single Day, Single Day, Single Int, Single Int64, Single Int64
           , Single Text, Single Int64, Single Text, Single Text
           , Single (Maybe Text), Single (Maybe Text)
           )])
      manualRows <- (rawSql
        "SELECT evidence.status, evidence.submitted_at\
        \ FROM marketplace_order_checkout_runtime runtime\
        \ JOIN commerce_manual_payment_evidence evidence ON evidence.checkout_id = runtime.checkout_id\
        \ JOIN commerce_payment_attempt attempt ON attempt.id = evidence.payment_attempt_id\
        \ WHERE runtime.order_id = ?::uuid\
        \ AND attempt.checkout_id = runtime.checkout_id\
        \ AND attempt.provider IN ('bank_transfer','cash','pos')\
        \ AND attempt.operation = 'manual_verify'\
        \ ORDER BY attempt.updated_at DESC, evidence.id DESC LIMIT 2"
        [PersistText (toPathPiece orderId)]
        :: SqlPersistT IO [(Single Text, Single (Maybe UTCTime))])
      fulfillmentHistory <- case runtimeRows of
        [(Single _, Single "rental", _, _, _, _)] -> (rawSql
          "SELECT to_status, created_at FROM marketplace_rental_event\
          \ WHERE order_id = ?::uuid ORDER BY created_at, id"
          [PersistText (toPathPiece orderId)]
          :: SqlPersistT IO [(Single Text, Single UTCTime)])
        _ -> (rawSql
          "SELECT to_status, created_at FROM marketplace_sale_fulfillment_event\
          \ WHERE order_id = ?::uuid ORDER BY created_at, id"
          [PersistText (toPathPiece orderId)]
          :: SqlPersistT IO [(Single Text, Single UTCTime)])
      let baseDto = orderToDTO orderEnt listings
          history = [(status, occurredAt) | (Single status, Single occurredAt) <- fulfillmentHistory]
          withRuntime = case runtimeRows of
            [( Single checkoutStatus, Single orderKind, Single method, Single domainStatus
             , Single holdExpiresAt, Single trackingReference
             )] -> baseDto
              { moCheckoutStatus = Just checkoutStatus
            , moOrderKind = Just orderKind
            , moFulfillmentMethod = Just method
            , moFulfillmentStatus = Just domainStatus
            , moHoldExpiresAt = Just holdExpiresAt
            , moTrackingReference = trackingReference
            , moFulfillmentHistory = history
              }
            _ -> baseDto
          withManual = case manualRows of
            [(Single manualStatus, Single submittedAt)] -> withRuntime
              { moManualPaymentStatus = Just manualStatus
              , moManualPaymentSubmittedAt = submittedAt
              }
            [] -> withRuntime
            _ -> withRuntime
              { moManualPaymentStatus = Just "requires_reconciliation"
              , moManualPaymentSubmittedAt = Nothing
              }
      pure . Just $ case rentalRows of
        [( Single startDate, Single endDate, Single durationDays, Single rentalCharge
         , Single securityDeposit, Single depositStatus, Single depositDeduction
         , Single termsVersion, Single timezone, Single conditionOut, Single conditionIn
         )] -> withManual
            { moRentalStartDate = Just startDate
            , moRentalEndDate = Just endDate
            , moRentalDurationDays = Just durationDays
            , moRentalChargeUsdCents = Just (fromIntegral rentalCharge)
            , moSecurityDepositUsdCents = Just (fromIntegral securityDeposit)
            , moDepositStatus = Just depositStatus
            , moDepositDeductionUsdCents = Just (fromIntegral depositDeduction)
            , moRentalTermsVersion = Just termsVersion
            , moRentalTimezone = Just timezone
            , moConditionOut = conditionOut
            , moConditionIn = conditionIn
            }
        _ -> withManual

orderToDTO
  :: Entity ME.MarketplaceOrder
  -> [(ME.MarketplaceOrderItem, Maybe ME.MarketplaceListing)]
  -> MarketplaceOrderDTO
orderToDTO (Entity oid order) items =
  let currency = ME.marketplaceOrderCurrency order
      itemDtos = flip map items $ \(oi, mListing) ->
        let titleTxt = maybe "Listado" ME.marketplaceListingTitle mListing
        in MarketplaceOrderItemDTO
              { moiListingId         = toPathPiece (ME.marketplaceOrderItemListingId oi)
              , moiTitle             = titleTxt
              , moiQuantity          = ME.marketplaceOrderItemQuantity oi
              , moiUnitPriceUsdCents = ME.marketplaceOrderItemUnitPriceUsdCents oi
              , moiSubtotalCents     = ME.marketplaceOrderItemSubtotalUsdCents oi
              , moiUnitPriceDisplay  = formatUsd (ME.marketplaceOrderItemUnitPriceUsdCents oi) currency
              , moiSubtotalDisplay   = formatUsd (ME.marketplaceOrderItemSubtotalUsdCents oi) currency
              }
  in MarketplaceOrderDTO
      { moOrderId         = toPathPiece oid
      , moCartId          = toPathPiece <$> ME.marketplaceOrderCartId order
      , moCurrency        = currency
      , moTotalUsdCents   = ME.marketplaceOrderTotalUsdCents order
      , moTotalDisplay    = formatUsd (ME.marketplaceOrderTotalUsdCents order) currency
      , moStatus          = ME.marketplaceOrderStatus order
      , moStatusHistory   = [ (ME.marketplaceOrderStatus order, ME.marketplaceOrderUpdatedAt order) ]
      , moBuyerName       = ME.marketplaceOrderBuyerName order
    , moBuyerEmail      = ME.marketplaceOrderBuyerEmail order
    , moBuyerPhone      = ME.marketplaceOrderBuyerPhone order
    , moPaymentProvider = ME.marketplaceOrderPaymentProvider order
    , moPaypalOrderId   = ME.marketplaceOrderPaypalOrderId order
    , moPaypalPayerEmail = ME.marketplaceOrderPaypalPayerEmail order
    , moPaidAt          = ME.marketplaceOrderPaidAt order
    , moLookupToken     = Nothing
    , moCheckoutStatus  = Nothing
    , moManualPaymentStatus = Nothing
    , moManualPaymentSubmittedAt = Nothing
    , moFulfillmentMethod = Nothing
    , moFulfillmentStatus = Nothing
    , moHoldExpiresAt   = Nothing
    , moTrackingReference = Nothing
    , moFulfillmentHistory = []
    , moOrderKind       = Nothing
    , moRentalStartDate = Nothing
    , moRentalEndDate   = Nothing
    , moRentalDurationDays = Nothing
    , moRentalChargeUsdCents = Nothing
    , moSecurityDepositUsdCents = Nothing
    , moDepositStatus = Nothing
    , moDepositDeductionUsdCents = Nothing
    , moRentalTermsVersion = Nothing
    , moRentalTimezone = Nothing
    , moConditionOut = Nothing
    , moConditionIn = Nothing
    , moCreatedAt       = ME.marketplaceOrderCreatedAt order
    , moUpdatedAt       = ME.marketplaceOrderUpdatedAt order
    , moItems           = itemDtos
    }

formatUsd :: Int -> Text -> Text
formatUsd cents currency =
  let wholeUnits = cents `div` 100
      fractionalUnits = cents `mod` 100
      fractionText
        | fractionalUnits < 10 = "0" <> T.pack (show fractionalUnits)
        | otherwise = T.pack (show fractionalUnits)
  in T.toUpper currency <> " $" <> T.pack (show wholeUnits) <> "." <> fractionText

-- Datafast / OPPWA types and helpers
data DFResult = DFResult
  { dfrCode        :: Text
  , dfrDescription :: Maybe Text
  } deriving (Show, Generic)
instance FromJSON DFResult where
  parseJSON = withObject "DFResult" $ \o ->
    DFResult <$> o .: "code" <*> o .:? "description"

data DFCheckoutRes = DFCheckoutRes
  { dfcId     :: Text
  , dfcResult :: DFResult
  } deriving (Show, Generic)
instance FromJSON DFCheckoutRes where
  parseJSON = withObject "DFCheckoutRes" $ \o ->
    DFCheckoutRes <$> o .: "id" <*> o .: "result"

data DFResultDetails = DFResultDetails
  { dfrdAuthCode     :: Maybe Text
  , dfrdAcquirerCode :: Maybe Text
  } deriving (Show, Generic)
instance FromJSON DFResultDetails where
  parseJSON = withObject "DFResultDetails" $ \o ->
    DFResultDetails
      <$> o .:? "AuthCode"
      <*> o .:? "AcquirerCode"

data DFPaymentStatus = DFPaymentStatus
  { dfpId            :: Maybe Text
  , dfpPaymentType   :: Maybe Text
  , dfpPaymentBrand  :: Maybe Text
  , dfpAmount        :: Maybe Text
  , dfpCurrency      :: Maybe Text
  , dfpMerchantTransactionId :: Maybe Text
  , dfpResult        :: DFResult
  , dfpResultDetails :: Maybe DFResultDetails
  } deriving (Show, Generic)
instance FromJSON DFPaymentStatus where
  parseJSON = withObject "DFPaymentStatus" $ \o ->
    DFPaymentStatus
      <$> o .:? "id"
      <*> o .:? "paymentType"
      <*> o .:? "paymentBrand"
      <*> o .:? "amount"
      <*> o .:? "currency"
      <*> o .:? "merchantTransactionId"
      <*> o .:  "result"
      <*> o .:? "resultDetails"

data DatafastEnv = DatafastEnv
  { dfEntityId     :: Text
  , dfBearerToken  :: Text
  , dfBaseUrl      :: String
  , dfTestMode     :: Maybe Text
  , dfExtraParams  :: [(ByteString, ByteString)]
  , dfEnvironment  :: Checkout.CheckoutEnvironment
  }

instance Show DatafastEnv where
  show environment =
    "DatafastEnv {dfEntityId = <redacted>, dfBearerToken = <redacted>, "
      <> "dfBaseUrl = " <> show (dfBaseUrl environment)
      <> ", dfTestMode = " <> show (dfTestMode environment)
      <> ", dfExtraParams = <redacted>, dfEnvironment = "
      <> show (dfEnvironment environment) <> "}"

loadDatafastEnv :: AppM DatafastEnv
loadDatafastEnv = do
  mEntity <- liftIO $ lookupEnv "DATAFAST_ENTITY_ID"
  mBearer <- liftIO $ lookupEnv "DATAFAST_BEARER_TOKEN"
  mBase   <- liftIO $ lookupEnv "DATAFAST_BASE_URL"
  mTest   <- liftIO $ lookupEnv "DATAFAST_TEST_MODE"
  mEnvironment <- liftIO $ lookupEnv "DATAFAST_ENV"
  mMid    <- liftIO $ lookupEnv "DATAFAST_MID"
  mTid    <- liftIO $ lookupEnv "DATAFAST_TID"
  mPserv  <- liftIO $ lookupEnv "DATAFAST_PSERV"
  mUserData2 <- liftIO $ lookupEnv "DATAFAST_USER_DATA2"
  mVersionDf <- liftIO $ lookupEnv "DATAFAST_VERSIONDF"
  baseUrl <- either throwError pure (validateDatafastBaseUrl mBase)
  entityId <- either throwError pure (validateDatafastEntityId mEntity)
  bearer <- either throwError pure (validateDatafastCredential "DATAFAST_BEARER_TOKEN" mBearer)
  testModeVal <-
    either throwError pure (validateOptionalDatafastCredential "DATAFAST_TEST_MODE" mTest)
  midVal <- either throwError pure (validateOptionalDatafastCredential "DATAFAST_MID" mMid)
  tidVal <- either throwError pure (validateOptionalDatafastCredential "DATAFAST_TID" mTid)
  pservVal <- either throwError pure (validateOptionalDatafastCredential "DATAFAST_PSERV" mPserv)
  userData2Val <-
    either throwError pure (validateOptionalDatafastCredential "DATAFAST_USER_DATA2" mUserData2)
  versionDf <- either throwError pure (validateOptionalDatafastVersionDf mVersionDf)
  environment <- either (throwError . marketplaceCheckoutInternal) pure
    (Checkout.resolveCheckoutEnvironment mEnvironment)
  either (throwError . marketplaceCheckoutInternal) pure
    (ServiceStorefront.validateDatafastEnvironmentBase environment baseUrl)
  when (environment == Checkout.CheckoutProduction && isJust testModeVal) $
    throwError (marketplaceCheckoutInternal
      "DATAFAST_TEST_MODE must be unset when DATAFAST_ENV=production")
  let
      optPair k mv = (\v -> (k, TE.encodeUtf8 v)) <$> mv
      extras =
        catMaybes
          [ optPair "customParameters[SHOPPER_MID]" midVal
          , optPair "customParameters[SHOPPER_TID]" tidVal
          , optPair "customParameters[SHOPPER_PSERV]" pservVal
          , optPair "risk.parameters[USER_DATA2]" userData2Val
          , optPair "customParameters[SHOPPER_VERSIONDF]" (Just versionDf)
          ]
  pure DatafastEnv
    { dfEntityId = entityId
    , dfBearerToken = bearer
    , dfBaseUrl = baseUrl
    , dfTestMode = testModeVal
    , dfExtraParams = extras
    , dfEnvironment = environment
    }

validateDatafastCredential :: Text -> Maybe String -> Either ServerError Text
validateDatafastCredential = validateRequiredGatewayCredential

validateOptionalDatafastCredential :: Text -> Maybe String -> Either ServerError (Maybe Text)
validateOptionalDatafastCredential envName mRawCredential =
  case normalizeOptionalInput (T.pack <$> mRawCredential) of
    Nothing -> Right Nothing
    Just credential
      | T.any isGatewayAuthHeaderUnsafeChar credential ->
          Left err500
            { errBody =
                BL.fromStrict . TE.encodeUtf8 $
                  gatewayAuthHeaderUnsafeMessage envName
            }
      | T.length credential > maxGatewayCredentialChars ->
          Left err500
            { errBody =
                BL.fromStrict . TE.encodeUtf8 $
                  gatewayCredentialTooLongMessage envName
            }
      | otherwise ->
          Right (Just credential)

validateOptionalDatafastVersionDf :: Maybe String -> Either ServerError Text
validateOptionalDatafastVersionDf Nothing = Right defaultDatafastVersionDf
validateOptionalDatafastVersionDf (Just rawVersion)
  | T.null versionDf = Right defaultDatafastVersionDf
  | T.length versionDf > 4 = invalidDatafastVersionDf
  | not (T.all isAsciiDigitText versionDf) = invalidDatafastVersionDf
  | T.isPrefixOf "0" versionDf = invalidDatafastVersionDf
  | otherwise = Right versionDf
  where
    versionDf = T.strip (T.pack rawVersion)

defaultDatafastVersionDf :: Text
defaultDatafastVersionDf = "2"

isAsciiDigitText :: Char -> Bool
isAsciiDigitText ch = ch >= '0' && ch <= '9'

invalidDatafastVersionDf :: Either ServerError a
invalidDatafastVersionDf =
  Left err500
    { errBody = "DATAFAST_VERSIONDF must be 1 to 4 ASCII digits without leading zeros"
    }

validateDatafastEntityId :: Maybe String -> Either ServerError Text
validateDatafastEntityId mRawEntityId = do
  entityId <- validateDatafastCredential "DATAFAST_ENTITY_ID" mRawEntityId
  validateDatafastEntityIdShape entityId
  where
    validateDatafastEntityIdShape entityId
      | not (T.any isDatafastGatewayIdAtom entityId) =
          Left err500
            { errBody =
                "DATAFAST_ENTITY_ID must contain at least one ASCII letter or digit"
            }
      | not (T.all isDatafastGatewayIdChar entityId) =
          Left err500
            { errBody =
                "DATAFAST_ENTITY_ID must contain only ASCII letters, digits, hyphen, underscore, or dot"
            }
      | otherwise =
          Right entityId

    isDatafastGatewayIdAtom c =
      isDigit c || isAsciiLower c || isAsciiUpper c

    isDatafastGatewayIdChar c =
      isDigit c || isAsciiLower c || isAsciiUpper c || c == '-' || c == '_' || c == '.'

validateDatafastBaseUrl :: Maybe String -> Either ServerError String
validateDatafastBaseUrl mRawBase
  | T.null cleanBase =
      invalidDatafastBaseUrl
  | not ("https://" `T.isPrefixOf` T.toLower cleanBase) =
      invalidDatafastBaseUrl
  | not (TrialsServer.isValidHttpUrl cleanBase) =
      invalidDatafastBaseUrl
  | not (isHttpsOrigin cleanBase) =
      invalidDatafastBaseUrl
  | not (isApprovedDatafastOrigin cleanBase) =
      invalidDatafastBaseUrl
  | otherwise =
      Right (T.unpack (canonicalDatafastBaseUrl cleanBase))
  where
    rawBase = maybe "https://test.oppwa.com" T.pack mRawBase
    strippedBase = T.strip rawBase
    cleanBase
      | T.isSuffixOf "/" strippedBase && not (T.isSuffixOf "//" strippedBase) =
          T.dropEnd 1 strippedBase
      | otherwise =
          strippedBase

    isHttpsOrigin rawUrl =
      T.all (\c -> c /= '/' && c /= '?' && c /= '#') (T.drop 8 rawUrl)

    isApprovedDatafastOrigin rawUrl =
      case datafastOriginParts rawUrl of
        Just (host, portSuffix) ->
          (host == "oppwa.com" || ".oppwa.com" `T.isSuffixOf` host)
            && T.null portSuffix
        Nothing ->
          False

    canonicalDatafastBaseUrl rawUrl =
      case datafastOriginParts rawUrl of
        Just (host, portSuffix) -> "https://" <> host <> portSuffix
        Nothing -> rawUrl

    datafastOriginParts rawUrl =
      let authority = T.drop 8 rawUrl
          (host, portSuffix) = T.breakOn ":" authority
          normalizedHost = T.toLower host
      in if T.null normalizedHost
           then Nothing
           else Just (normalizedHost, portSuffix)

invalidDatafastBaseUrl :: Either ServerError a
invalidDatafastBaseUrl =
  Left err500
    { errBody =
        "DATAFAST_BASE_URL must be an absolute https origin on oppwa.com "
          <> "using the default HTTPS port and without path, query, or fragment"
    }

data PayPalLink = PayPalLink
  { pplRel  :: Text
  , pplHref :: Text
  } deriving (Show, Generic)
instance FromJSON PayPalLink where
  parseJSON = withObject "PayPalLink" $ \o ->
    PayPalLink <$> o .: "rel" <*> o .: "href"

data PayPalCreateResponse = PayPalCreateResponse
  { pcrId    :: Text
  , pcrLinks :: [PayPalLink]
  } deriving (Show, Generic)
instance FromJSON PayPalCreateResponse where
  parseJSON = withObject "PayPalCreateResponse" $ \o ->
    PayPalCreateResponse
      <$> o .: "id"
      <*> o .:? "links" .!= []

data PayPalToken = PayPalToken
  { payPalAccessToken :: Maybe Text
  , payPalTokenType :: Maybe Text
  } deriving (Generic)

instance Show PayPalToken where
  show token =
    "PayPalToken {payPalAccessToken = <redacted>, payPalTokenType = "
      <> show (payPalTokenType token) <> "}"
instance FromJSON PayPalToken where
  parseJSON = withObject "PayPalToken" $ \o ->
    PayPalToken
      <$> o .:? "access_token"
      <*> o .:? "token_type"

data PayPalCaptureOutcome = PayPalCaptureOutcome
  { pcoStatus :: Text
  , pcoPayerEmail :: Maybe Text
  } deriving (Show, Generic)

loadPaypalEnv :: AppM (Text, Text, String)
loadPaypalEnv = do
  mCid <- liftIO $ lookupEnv "PAYPAL_CLIENT_ID"
  mSecret <- liftIO $ lookupEnv "PAYPAL_CLIENT_SECRET"
  mEnv <- liftIO $ lookupEnv "PAYPAL_ENV"
  baseUrl <- either throwError pure (resolvePaypalBaseUrl mEnv)
  cid <- either throwError pure (validatePayPalCredential "PAYPAL_CLIENT_ID" mCid)
  secret <- either throwError pure (validatePayPalCredential "PAYPAL_CLIENT_SECRET" mSecret)
  pure (cid, secret, baseUrl)

validatePayPalCredential :: Text -> Maybe String -> Either ServerError Text
validatePayPalCredential envName mRawCredential = do
  credential <- validateRequiredGatewayCredential envName mRawCredential
  if envName == "PAYPAL_CLIENT_ID" && T.any (== ':') credential
    then
      Left err500
        { errBody =
            "PAYPAL_CLIENT_ID must not contain ':' because PayPal Basic auth uses it as a delimiter"
        }
    else Right credential

validateRequiredGatewayCredential :: Text -> Maybe String -> Either ServerError Text
validateRequiredGatewayCredential envName mRawCredential =
  case normalizeOptionalInput (T.pack <$> mRawCredential) of
    Nothing ->
      Left err500
        { errBody =
            BL.fromStrict . TE.encodeUtf8 $
              envName <> " must be configured"
        }
    Just credential
      | T.any isGatewayAuthHeaderUnsafeChar credential ->
          Left err500
            { errBody =
                BL.fromStrict . TE.encodeUtf8 $
                  gatewayAuthHeaderUnsafeMessage envName
            }
      | T.length credential > maxGatewayCredentialChars ->
          Left err500
            { errBody =
                BL.fromStrict . TE.encodeUtf8 $
                  gatewayCredentialTooLongMessage envName
            }
      | otherwise ->
          Right credential

gatewayAuthHeaderUnsafeMessage :: Text -> Text
gatewayAuthHeaderUnsafeMessage fieldName =
  fieldName
    <> " must not contain control characters or whitespace, "
    <> "hidden formatting characters, or non-ASCII characters"

gatewayCredentialTooLongMessage :: Text -> Text
gatewayCredentialTooLongMessage fieldName =
  fieldName <> " must be 4096 characters or fewer"

maxGatewayCredentialChars :: Int
maxGatewayCredentialChars = 4096

isGatewayAuthHeaderUnsafeChar :: Char -> Bool
isGatewayAuthHeaderUnsafeChar ch =
  isControl ch || isSpace ch || generalCategory ch == Format || not (isAscii ch)

resolvePaypalBaseUrl :: Maybe String -> Either ServerError String
resolvePaypalBaseUrl mEnv =
  case fmap (T.toLower . T.strip . T.pack) mEnv of
    Nothing -> Right sandboxBase
    Just "" ->
      Left err500
        { errBody =
            "PAYPAL_ENV is configured but blank; unset it to use sandbox"
        }
    Just envTxt
      | envTxt `elem` ["sandbox", "test"] -> Right sandboxBase
      | envTxt `elem` ["live", "prod", "production"] -> Right liveBase
      | otherwise ->
          Left err500
            { errBody =
                "PAYPAL_ENV must be one of: sandbox, test, live, prod, production"
            }
  where
    sandboxBase = "https://api-m.sandbox.paypal.com"
    liveBase = "https://api-m.paypal.com"

validatePayPalTokenResponse :: PayPalToken -> Either ServerError Text
validatePayPalTokenResponse PayPalToken{..} = do
  accessToken <- validatePayPalAccessTokenField payPalAccessToken
  validatePayPalTokenTypeField payPalTokenType
  pure accessToken

validatePayPalAccessTokenField :: Maybe Text -> Either ServerError Text
validatePayPalAccessTokenField Nothing =
  Left err502 { errBody = "PayPal token response did not include an access token" }
validatePayPalAccessTokenField (Just rawToken) =
  case normalizeOptionalInput (Just rawToken) of
    Nothing ->
      Left err502 { errBody = "PayPal token response access token cannot be blank" }
    Just token
      | T.length token > 4096 ->
          Left err502
            { errBody =
                "PayPal token response access token must be 4096 characters or fewer"
            }
      | T.any isGatewayAuthHeaderUnsafeChar token ->
          Left err502
            { errBody =
                BL.fromStrict . TE.encodeUtf8 $
                  gatewayAuthHeaderUnsafeMessage "PayPal token response access token"
            }
      | otherwise ->
          Right token

validatePayPalTokenTypeField :: Maybe Text -> Either ServerError ()
validatePayPalTokenTypeField mRawTokenType =
  case normalizeOptionalInput mRawTokenType of
    Just tokenType | T.toLower tokenType == "bearer" ->
      Right ()
    _ ->
      Left err502
        { errBody = "PayPal token response token_type must be Bearer"
        }

resolvePayPalApprovalUrl :: [PayPalLink] -> Either ServerError Text
resolvePayPalApprovalUrl links =
  case [ pplHref lnk
       | lnk <- links
       , T.toLower (T.strip (pplRel lnk)) == "approve"
       ] of
    [approvalUrl] -> validatePayPalApprovalUrl (Just approvalUrl)
    [] -> validatePayPalApprovalUrl Nothing
    _ ->
      Left err502
        { errBody = "PayPal response included multiple approval URLs"
        }

resolvePayPalApprovalUrlForBase :: String -> [PayPalLink] -> Either ServerError Text
resolvePayPalApprovalUrlForBase baseUrl links = do
  approvalUrl <- resolvePayPalApprovalUrl links
  validatePayPalApprovalUrlEnvironment baseUrl approvalUrl

validatePayPalApprovalUrlEnvironment :: String -> Text -> Either ServerError Text
validatePayPalApprovalUrlEnvironment baseUrl approvalUrl =
  case expectedPayPalApprovalHost (T.pack baseUrl) of
    Nothing ->
      Left err500
        { errBody = "Configured PayPal API base URL is invalid"
        }
    Just expectedHost
      | payPalApprovalHost approvalUrl == Just expectedHost ->
          Right approvalUrl
      | otherwise ->
          Left err502
            { errBody =
                "PayPal approval URL host does not match configured PayPal environment"
            }

expectedPayPalApprovalHost :: Text -> Maybe Text
expectedPayPalApprovalHost baseUrl
  | baseUrl == "https://api-m.sandbox.paypal.com" =
      Just "www.sandbox.paypal.com"
  | baseUrl == "https://api-m.paypal.com" =
      Just "www.paypal.com"
  | otherwise =
      Nothing

payPalApprovalHost :: Text -> Maybe Text
payPalApprovalHost rawApprovalUrl =
  case payPalApprovalUrlParts rawApprovalUrl of
    Just (host, portSuffix, _)
      | T.null portSuffix -> Just host
    _ -> Nothing

validatePayPalApprovalUrl :: Maybe Text -> Either ServerError Text
validatePayPalApprovalUrl Nothing =
  Left err502 { errBody = "PayPal response did not include an approval URL" }
validatePayPalApprovalUrl (Just rawUrl)
  | T.null url =
      invalidPayPalApprovalUrl
  | not ("https://" `T.isPrefixOf` T.toLower url) =
      invalidPayPalApprovalUrl
  | not (TrialsServer.isValidHttpUrl url) =
      invalidPayPalApprovalUrl
  | not (isPayPalCheckoutApprovalUrl url) =
      invalidPayPalApprovalUrl
  | otherwise =
      Right url
  where
    url = T.strip rawUrl

    isPayPalCheckoutApprovalUrl rawApprovalUrl =
      case payPalApprovalUrlParts rawApprovalUrl of
        Just (host, portSuffix, pathAndQuery) ->
          host `elem` ["www.paypal.com", "www.sandbox.paypal.com"]
            && T.null portSuffix
            && "/checkoutnow?" `T.isPrefixOf` pathAndQuery
            && not ("#" `T.isInfixOf` pathAndQuery)
            && isJust (payPalApprovalUrlToken rawApprovalUrl)
        Nothing ->
          False

invalidPayPalApprovalUrl :: Either ServerError a
invalidPayPalApprovalUrl =
  Left err502 { errBody = "PayPal returned an invalid approval URL" }

validatePayPalApprovalUrlOrderToken :: Text -> Text -> Either ServerError Text
validatePayPalApprovalUrlOrderToken expectedOrderId rawApprovalUrl = do
  approvalUrl <- validatePayPalApprovalUrl (Just rawApprovalUrl)
  case payPalApprovalUrlToken approvalUrl of
    Just token | token == expectedOrderId -> Right approvalUrl
    _ ->
      Left err502
        { errBody = "PayPal approval URL token does not match created order id"
        }

payPalApprovalUrlParts :: Text -> Maybe (Text, Text, Text)
payPalApprovalUrlParts rawApprovalUrl
  | "https://" `T.isPrefixOf` T.toLower url =
      let afterScheme = T.drop 8 url
          authority =
            T.takeWhile
              (\c -> c /= '/' && c /= '?' && c /= '#')
              afterScheme
          pathAndQuery = T.drop (T.length authority) afterScheme
          (host, portSuffix) = T.breakOn ":" authority
          normalizedHost = T.toLower host
      in if T.null normalizedHost
           then Nothing
           else Just (normalizedHost, portSuffix, pathAndQuery)
  | otherwise =
      Nothing
  where
    url = T.strip rawApprovalUrl

payPalApprovalUrlToken :: Text -> Maybe Text
payPalApprovalUrlToken rawApprovalUrl = do
  (_, _, pathAndQuery) <- payPalApprovalUrlParts rawApprovalUrl
  query <- T.stripPrefix "/checkoutnow?" pathAndQuery
  collectPayPalApprovalUrlToken
    (T.splitOn "&" query)
    []
    False

collectPayPalApprovalUrlToken :: [Text] -> [Text] -> Bool -> Maybe Text
collectPayPalApprovalUrlToken [] [token] _ = Just token
collectPayPalApprovalUrlToken [] _ _ = Nothing
collectPayPalApprovalUrlToken (rawParam:remaining) tokens seenUserAction =
  case T.breakOn "=" rawParam of
    ("token", rawValue)
      | "=" `T.isPrefixOf` rawValue
      , let token = T.drop 1 rawValue
      , isValidPayPalOrderId token ->
          collectPayPalApprovalUrlToken remaining (token : tokens) seenUserAction
    ("useraction", "=commit")
      | not seenUserAction ->
          collectPayPalApprovalUrlToken remaining tokens True
    _ ->
      Nothing

extractPayPalCaptureStatus :: Value -> Either ServerError Text
extractPayPalCaptureStatus (Object o) =
  case AKeyMap.lookup "status" o of
    Nothing ->
      validatePayPalCaptureStatusField Nothing
    Just Null ->
      Left err502 { errBody = "PayPal capture response status cannot be null" }
    Just (String rawStatus) ->
      validatePayPalCaptureStatusField (Just rawStatus)
    Just _ ->
      Left err502 { errBody = "PayPal capture response status must be a string" }
extractPayPalCaptureStatus _ =
  Left err502 { errBody = "PayPal capture response must be a JSON object" }

validatePayPalCaptureStatusField :: Maybe Text -> Either ServerError Text
validatePayPalCaptureStatusField Nothing =
  Left err502 { errBody = "PayPal capture response did not include a status" }
validatePayPalCaptureStatusField (Just rawStatus)
  | T.null statusTxt =
      Left err502 { errBody = "PayPal capture response status cannot be blank" }
  | T.length statusTxt > 64 =
      Left err502
        { errBody =
            "PayPal capture response status must be 64 characters or fewer"
        }
  | T.any (\ch -> isControl ch || isSpace ch) statusTxt =
      Left err502
        { errBody =
            "PayPal capture response status must not contain control characters or whitespace"
        }
  | not (T.any isPayPalCaptureStatusAtom statusTxt) =
      Left err502
        { errBody =
            "PayPal capture response status must contain at least one ASCII letter"
        }
  | not (T.all isPayPalCaptureStatusChar statusTxt) =
      Left err502
        { errBody =
            "PayPal capture response status must contain only ASCII letters or underscore"
        }
  | otherwise =
      Right statusTxt
  where
    statusTxt = T.strip rawStatus

isPayPalCaptureStatusAtom :: Char -> Bool
isPayPalCaptureStatusAtom ch =
  isAsciiLower ch || isAsciiUpper ch

isPayPalCaptureStatusChar :: Char -> Bool
isPayPalCaptureStatusChar ch =
  isPayPalCaptureStatusAtom ch || ch == '_'

extractPayPalPayerEmail :: Value -> Either ServerError (Maybe Text)
extractPayPalPayerEmail (Object o) =
  case AKeyMap.lookup "payer" o of
    Nothing ->
      Right Nothing
    Just Null ->
      Left err502 { errBody = "PayPal capture response payer cannot be null" }
    Just (Object payerObj) ->
      case AKeyMap.lookup "email_address" payerObj of
        Nothing ->
          Right Nothing
        Just Null ->
          Left err502 { errBody = "PayPal payer email cannot be null" }
        Just (String rawEmail) ->
          validatePayPalPayerEmailField (Just rawEmail)
        Just _ ->
          Left err502 { errBody = "PayPal payer email must be a string when present" }
    Just _ ->
      Left err502 { errBody = "PayPal capture response payer must be an object" }
extractPayPalPayerEmail _ =
  Left err502 { errBody = "PayPal capture response must be a JSON object" }

validatePayPalPayerEmailField :: Maybe Text -> Either ServerError (Maybe Text)
validatePayPalPayerEmailField Nothing = Right Nothing
validatePayPalPayerEmailField (Just rawEmail) =
  case validateCourseRegistrationEmail (Just rawEmail) of
    Right (Just emailVal) ->
      Right (Just emailVal)
    Right Nothing ->
      Left err502 { errBody = "PayPal payer email cannot be blank" }
    Left _ ->
      Left err502 { errBody = "PayPal returned an invalid payer email" }

assetStatusLabel :: ME.AssetStatus -> Text
assetStatusLabel st =
  case st of
    ME.Active            -> "En stock"
    ME.Booked            -> "Reservado"
    ME.OutForMaintenance -> "Mantenimiento"
    ME.Retired           -> "No disponible"
    ME.Sold              -> "Vendido"

assetConditionLabel :: ME.AssetCondition -> Text
assetConditionLabel cond =
  case cond of
    ME.NewC -> "Nuevo"
    ME.Good -> "Bueno"
    ME.Fair -> "Regular"
    ME.Poor -> "Usado"

data TrackScope = TrackScope
  { tsOwner    :: Maybe PartyId
  , tsAllowAny :: Bool
  }

resolveTrackScope :: AuthedUser -> Maybe Int64 -> AppM TrackScope
resolveTrackScope user mOwnerId = do
  let isAdmin  = hasRole Admin user
      isArtist = hasRole Artist user || hasRole Artista user
  unless (isAdmin || isArtist) $
    throwError err403
      { errBody =
          BL.fromStrict (TE.encodeUtf8 "Solo artistas o admins pueden gestionar operaciones.")
      }
  ownerId <- either throwError pure (validateLabelTrackOwnerIdFilter mOwnerId)
  owner <- either throwError pure (resolveLabelTrackOwnerScope user isAdmin ownerId)
  pure TrackScope { tsOwner = owner, tsAllowAny = isAdmin }

resolveLabelTrackOwnerScope
  :: AuthedUser
  -> Bool
  -> Maybe Int64
  -> Either ServerError (Maybe PartyId)
resolveLabelTrackOwnerScope user isAdmin mOwnerId
  | isAdmin = Right (fmap toSqlKey mOwnerId)
  | otherwise =
      case mOwnerId of
        Nothing ->
          Right (Just (auPartyId user))
        Just requestedOwnerId
          | toSqlKey requestedOwnerId == auPartyId user ->
              Right (Just (auPartyId user))
          | otherwise ->
              Left err403
                { errBody =
                    "Only admins can select another label track owner"
                }

ownerFilter :: TrackScope -> [Filter ME.LabelTrack]
ownerFilter TrackScope{..} =
  case tsOwner of
    Nothing    -> [ME.LabelTrackOwnerPartyId ==. Nothing]
    Just owner -> [ME.LabelTrackOwnerPartyId ==. Just owner]

canManageTrack :: TrackScope -> ME.LabelTrack -> Bool
canManageTrack TrackScope{..} track =
  tsAllowAny || ME.labelTrackOwnerPartyId track == tsOwner

ensureTrackAccess :: TrackScope -> ME.LabelTrack -> AppM ()
ensureTrackAccess scope track =
  unless (canManageTrack scope track) $
    throwError err403 { errBody = BL.fromStrict (TE.encodeUtf8 "No puedes modificar operaciones de otro artista.") }

loadTrackOwnerNames :: [Entity ME.LabelTrack] -> AppM (Map.Map PartyId Text)
loadTrackOwnerNames rows = do
  let owners = mapMaybe (ME.labelTrackOwnerPartyId . entityVal) rows
  if null owners
    then pure Map.empty
    else runDB (fetchPartyNameMap owners)

validateLabelTrackTitle :: Text -> Either ServerError Text
validateLabelTrackTitle rawTitle =
  let title = T.strip rawTitle
  in if T.null title
       then Left err400 { errBody = "Título requerido" }
       else if T.length title > labelTrackTitleMaxLength
         then Left err400 { errBody = "Título debe tener 160 caracteres o menos" }
         else if T.any isUnsafePublicBookingLabelChar title
           then Left err400 { errBody = "Título no debe contener caracteres de control o formato" }
           else Right title

labelTrackTitleMaxLength :: Int
labelTrackTitleMaxLength = 160

validateOptionalLabelTrackNote :: Maybe Text -> Either ServerError (Maybe Text)
validateOptionalLabelTrackNote Nothing = Right Nothing
validateOptionalLabelTrackNote (Just rawNote) =
  validateLabelTrackNote rawNote

validateLabelTrackNote :: Text -> Either ServerError (Maybe Text)
validateLabelTrackNote rawNote =
  case normalizeOptionalInput (Just rawNote) of
    Nothing -> Right Nothing
    Just note
      | T.length note > labelTrackNoteMaxLength ->
          Left err400 { errBody = "note must be 1000 characters or fewer" }
      | T.any isUnsafeLabelTrackNoteChar note ->
          Left err400
            { errBody =
                "note must not contain unsafe control or Unicode separator/format characters"
            }
      | otherwise ->
          Right (Just note)
  where
    isUnsafeLabelTrackNoteChar ch =
      (isControl ch && ch /= '\n' && ch /= '\r' && ch /= '\t')
        || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

labelTrackNoteMaxLength :: Int
labelTrackNoteMaxLength = 1000

validateOptionalLabelTrackStatus :: Maybe Text -> Either ServerError (Maybe Text)
validateOptionalLabelTrackStatus Nothing = Right Nothing
validateOptionalLabelTrackStatus (Just rawStatus) =
  case T.toLower <$> normalizeOptionalInput (Just rawStatus) of
    Just "open" -> Right (Just "open")
    Just "done" -> Right (Just "done")
    _ -> Left err400 { errBody = "status must be one of: open, done" }

validateLabelTrackUpdateHasChanges :: LabelTrackUpdate -> Either ServerError ()
validateLabelTrackUpdateHasChanges LabelTrackUpdate{..}
  | isJust ltuTitle || isJust ltuNote || isJust ltuStatus = Right ()
  | otherwise =
      Left err400 { errBody = "Label track update must include at least one field" }

validateLabelTrackOwnerIdFilter :: Maybe Int64 -> Either ServerError (Maybe Int64)
validateLabelTrackOwnerIdFilter = validateOptionalPositiveIdField "ownerId"

validateLabelTrackPathId :: Text -> Either ServerError (Key ME.LabelTrack)
validateLabelTrackPathId rawId =
  let normalized = T.strip rawId
      invalid = Left err400 { errBody = "Invalid track id" }
  in if T.null normalized
       then invalid
       else
         case fromPathPiece normalized of
           Just key | toPathPiece key == normalized -> Right key
           _ -> invalid

parseLabelTrackId :: Text -> AppM (Key ME.LabelTrack)
parseLabelTrackId =
  either throwError pure . validateLabelTrackPathId

listLabelTracks :: AuthedUser -> Maybe Int64 -> AppM [LabelTrackDTO]
listLabelTracks user mOwnerId = do
  scope <- resolveTrackScope user mOwnerId
  rows <- runDB $ selectList (ownerFilter scope) [Desc ME.LabelTrackCreatedAt]
  nameMap <- loadTrackOwnerNames rows
  pure (map (toLabelTrackDTO nameMap) rows)

createLabelTrack :: AuthedUser -> LabelTrackCreate -> AppM LabelTrackDTO
createLabelTrack user LabelTrackCreate{..} = do
  scope <- resolveTrackScope user ltcOwnerId
  title <- either throwError pure (validateLabelTrackTitle ltcTitle)
  note <- either throwError pure (validateOptionalLabelTrackNote ltcNote)
  now <- liftIO getCurrentTime
  let record = ME.LabelTrack
        { ME.labelTrackTitle      = title
        , ME.labelTrackNote       = note
        , ME.labelTrackStatus     = "open"
        , ME.labelTrackOwnerPartyId = tsOwner scope
        , ME.labelTrackCreatedAt  = now
        , ME.labelTrackUpdatedAt  = now
        }
  entity <- runDB $ do
    key <- insert record
    pure (Entity key record)
  nameMap <- loadTrackOwnerNames [entity]
  pure (toLabelTrackDTO nameMap entity)

updateLabelTrack :: AuthedUser -> Text -> LabelTrackUpdate -> AppM LabelTrackDTO
updateLabelTrack user rawId updatePayload@LabelTrackUpdate{..} = do
  key <- parseLabelTrackId rawId
  scope <- resolveTrackScope user Nothing
  either throwError pure (validateLabelTrackUpdateHasChanges updatePayload)
  titleUpdate <- traverse (either throwError pure . validateLabelTrackTitle) ltuTitle
  noteUpdate <- traverse (either throwError pure . validateLabelTrackNote) ltuNote
  statusUpdate <- either throwError pure (validateOptionalLabelTrackStatus ltuStatus)
  now <- liftIO getCurrentTime
  mTrack <- runDB $ getEntity key
  case mTrack of
    Nothing -> throwError err404
    Just (Entity _ track) -> do
      ensureTrackAccess scope track
      let updates = catMaybes
            [ (ME.LabelTrackTitle =.) <$> titleUpdate
            , (ME.LabelTrackNote =.) <$> noteUpdate
            , (ME.LabelTrackStatus =.) <$> statusUpdate
            , Just (ME.LabelTrackUpdatedAt =. now)
            ]
      unless (null updates) (runDB $ update key updates)
      updated <- runDB $ getJustEntity key
      nameMap <- loadTrackOwnerNames [updated]
      pure (toLabelTrackDTO nameMap updated)

deleteLabelTrack :: AuthedUser -> Text -> AppM NoContent
deleteLabelTrack user rawId = do
  key <- parseLabelTrackId rawId
  scope <- resolveTrackScope user Nothing
  mTrack <- runDB $ getEntity key
  case mTrack of
    Nothing -> throwError err404
    Just (Entity _ track) -> do
      ensureTrackAccess scope track
      runDB $ delete key
      pure NoContent

toLabelTrackDTO :: Map.Map PartyId Text -> Entity ME.LabelTrack -> LabelTrackDTO
toLabelTrackDTO nameMap (Entity key t) =
  LabelTrackDTO
    { ltId        = toPathPiece key
    , ltTitle     = ME.labelTrackTitle t
    , ltNote      = ME.labelTrackNote t
    , ltStatus    = ME.labelTrackStatus t
    , ltOwnerId   = fromSqlKey <$> ME.labelTrackOwnerPartyId t
    , ltOwnerName = ME.labelTrackOwnerPartyId t >>= (`Map.lookup` nameMap)
    , ltCreatedAt = ME.labelTrackCreatedAt t
    , ltUpdatedAt = ME.labelTrackUpdatedAt t
    }

requireLabelProjectNotesAccess :: AuthedUser -> AppM ()
requireLabelProjectNotesAccess user =
  unless (hasRole Admin user || hasRole Webmaster user) $
    throwError err403
      { errBody = "Label project notes require an administrator or webmaster role"
      }

validateLabelProjectNoteText :: Text -> Either ServerError Text
validateLabelProjectNoteText rawText =
  case validateLabelTrackNote rawText of
    Right (Just noteText) -> Right noteText
    Right Nothing -> Left err400 { errBody = "Project note text is required" }
    Left validationError -> Left validationError

validateLabelProjectNotePathId :: Text -> Either ServerError (Key ME.LabelProjectNote)
validateLabelProjectNotePathId rawId =
  let normalized = T.strip rawId
      invalid = Left err400 { errBody = "Invalid project note id" }
  in if T.null normalized
       then invalid
       else case fromPathPiece normalized of
         Just key | toPathPiece key == normalized -> Right key
         _ -> invalid

listLabelProjectNotes :: AuthedUser -> AppM [LabelProjectNoteDTO]
listLabelProjectNotes user = do
  requireLabelProjectNotesAccess user
  rows <- runDB $ selectList
    [ME.LabelProjectNoteActive ==. True]
    [Asc ME.LabelProjectNoteCompleted, Desc ME.LabelProjectNoteUpdatedAt]
  pure (map toLabelProjectNoteDTO rows)

createLabelProjectNote :: AuthedUser -> LabelProjectNoteCreate -> AppM LabelProjectNoteDTO
createLabelProjectNote user LabelProjectNoteCreate{..} = do
  requireLabelProjectNotesAccess user
  noteText <- either throwError pure (validateLabelProjectNoteText lpncText)
  now <- liftIO getCurrentTime
  let record = ME.LabelProjectNote
        { ME.labelProjectNoteText = noteText
        , ME.labelProjectNoteCompleted = False
        , ME.labelProjectNoteActive = True
        , ME.labelProjectNoteCreatedBy = Just (auPartyId user)
        , ME.labelProjectNoteUpdatedBy = Just (auPartyId user)
        , ME.labelProjectNoteCreatedAt = now
        , ME.labelProjectNoteUpdatedAt = now
        , ME.labelProjectNoteVersion = 1
        , ME.labelProjectNoteSourceCmsContentId = Nothing
        , ME.labelProjectNoteSourceItemId = Nothing
        }
  key <- runDB (insert record)
  pure (toLabelProjectNoteDTO (Entity key record))

updateLabelProjectNote :: AuthedUser -> Text -> LabelProjectNoteUpdate -> AppM LabelProjectNoteDTO
updateLabelProjectNote user rawId LabelProjectNoteUpdate{..} = do
  requireLabelProjectNotesAccess user
  key <- either throwError pure (validateLabelProjectNotePathId rawId)
  when (lpnuExpectedVersion <= 0) $
    throwError err400 { errBody = "expectedVersion must be a positive integer" }
  textUpdate <- traverse (either throwError pure . validateLabelProjectNoteText) lpnuText
  when (isNothing textUpdate && isNothing lpnuCompleted) $
    throwError err400 { errBody = "Project note update must include text or completed" }
  existing <- runDB (get key)
  case existing of
    Nothing -> throwError err404
    Just note | not (ME.labelProjectNoteActive note) -> throwError err410
    Just _ -> pure ()
  now <- liftIO getCurrentTime
  let updates = catMaybes
        [ (ME.LabelProjectNoteText =.) <$> textUpdate
        , (ME.LabelProjectNoteCompleted =.) <$> lpnuCompleted
        ] <>
        [ ME.LabelProjectNoteUpdatedBy =. Just (auPartyId user)
        , ME.LabelProjectNoteUpdatedAt =. now
        , ME.LabelProjectNoteVersion +=. 1
        ]
  updatedRows <- runDB $ updateWhereCount
    [ ME.LabelProjectNoteId ==. key
    , ME.LabelProjectNoteActive ==. True
    , ME.LabelProjectNoteVersion ==. lpnuExpectedVersion
    ]
    updates
  when (updatedRows /= 1) $
    throwError err409 { errBody = "Project note changed; reload before saving" }
  toLabelProjectNoteDTO <$> runDB (getJustEntity key)

deactivateLabelProjectNote :: AuthedUser -> Text -> AppM NoContent
deactivateLabelProjectNote user rawId = do
  requireLabelProjectNotesAccess user
  key <- either throwError pure (validateLabelProjectNotePathId rawId)
  existing <- runDB (get key)
  case existing of
    Nothing -> throwError err404
    Just note | not (ME.labelProjectNoteActive note) -> throwError err410
    Just _ -> do
      now <- liftIO getCurrentTime
      runDB $ update key
        [ ME.LabelProjectNoteActive =. False
        , ME.LabelProjectNoteUpdatedBy =. Just (auPartyId user)
        , ME.LabelProjectNoteUpdatedAt =. now
        , ME.LabelProjectNoteVersion +=. 1
        ]
      pure NoContent

toLabelProjectNoteDTO :: Entity ME.LabelProjectNote -> LabelProjectNoteDTO
toLabelProjectNoteDTO (Entity key note) =
  LabelProjectNoteDTO
    { lpnId = toPathPiece key
    , lpnText = ME.labelProjectNoteText note
    , lpnCompleted = ME.labelProjectNoteCompleted note
    , lpnCreatedAt = ME.labelProjectNoteCreatedAt note
    , lpnUpdatedAt = ME.labelProjectNoteUpdatedAt note
    , lpnVersion = ME.labelProjectNoteVersion note
    }

cmsAdminServer :: AuthedUser -> ServerT CmsAdminAPI AppM
cmsAdminServer user =
       cmsListH
  :<|> cmsCreateH
  :<|> cmsPublishH
  :<|> cmsDeleteH
  where
    requireWebmaster = unless (hasRole Admin user || hasRole Webmaster user) $
      throwError err403

    cmsListH mContentId mLocale = do
      requireWebmaster
      contentIdFilter <- either throwError pure (validateOptionalCmsContentIdFilter mContentId)
      localeFilter <- either throwError pure (validateOptionalCmsLocaleFilter mLocale)
      let filters = catMaybes
            [ (CMS.CmsContentAuthoredContentId ==.) . Just <$> contentIdFilter
            , (CMS.CmsContentLocale ==.) <$> localeFilter
            ]
      rows <- runDB $ selectList filters [Desc CMS.CmsContentCreatedAt]
      pure (map toCmsDTO rows)

    cmsCreateH CmsContentIn{..} = do
      requireWebmaster
      now <- liftIO getCurrentTime
      statusVal <- either throwError pure (validateCmsContentStatus cciStatus)
      when (statusVal /= "draft") $
        throwError err409
          { errBody = "CMS changes must be created as drafts and published through review" }
      (authoredContentUuid, authoredContent, contentType) <- loadAuthoredCmsTarget cciContentId
      let slug = Catalog.authoredContentCurrentSlug authoredContent
      locale <- either throwError pure (validateRequiredCmsLocale cciLocale)
      title <- either throwError pure (validateOptionalCmsTitle cciTitle)
      payload <- either throwError pure (validateOptionalCmsPayload cciPayload)
      either throwError pure (validateCmsPayloadSchema contentType payload)
      nextVersion <- runDB $ do
        mLatest <- selectFirst
          [ CMS.CmsContentAuthoredContentId ==. Just authoredContentUuid
          , CMS.CmsContentLocale ==. locale
          ]
          [Desc CMS.CmsContentVersion]
        pure $ maybe 1 ((+1) . CMS.cmsContentVersion . entityVal) mLatest
      cid <- runDB $ do
        insert CMS.CmsContent
          { CMS.cmsContentAuthoredContentId = Just authoredContentUuid
          , CMS.cmsContentSlug = slug
          , CMS.cmsContentLocale = locale
          , CMS.cmsContentVersion = nextVersion
          , CMS.cmsContentStatus = statusVal
          , CMS.cmsContentTitle = title
          , CMS.cmsContentPayload = fmap CMS.AesonValue payload
          , CMS.cmsContentCreatedBy = Just (auPartyId user)
          , CMS.cmsContentCreatedAt = now
          , CMS.cmsContentUpdatedAt = now
          , CMS.cmsContentPublishedAt = Nothing
          }
      ent <- runDB $ getJustEntity cid
      pure (toCmsDTO ent)

    cmsPublishH cid = do
      requireWebmaster
      contentKey <- either throwError pure (validateCmsContentPathId cid)
      now <- liftIO getCurrentTime
      mEnt <- runDB $ get contentKey
      case mEnt of
        Nothing -> throwError err404
        Just ent -> do
          when (CMS.cmsContentAuthoredContentId ent == Nothing) $
            throwError err409 { errBody = "Legacy CMS content has no canonical authored content ID" }
          when (CMS.cmsContentCreatedBy ent == Just (auPartyId user)) $
            throwError err403 { errBody = "CMS draft authors cannot approve their own changes" }
          runDB $ do
            updateWhere
              [ CMS.CmsContentAuthoredContentId ==. CMS.cmsContentAuthoredContentId ent
              , CMS.CmsContentLocale ==. CMS.cmsContentLocale ent
              , CMS.CmsContentStatus ==. "published"
              ]
              [ CMS.CmsContentStatus =. "archived"
              , CMS.CmsContentUpdatedAt =. now
              ]
            update contentKey
              [ CMS.CmsContentStatus =. "published"
              , CMS.CmsContentPublishedAt =. Just now
              , CMS.CmsContentUpdatedAt =. now
              ]
          ent' <- runDB $ getJustEntity contentKey
          pure (toCmsDTO ent')

    cmsDeleteH cid = do
      requireWebmaster
      contentKey <- either throwError pure (validateCmsContentPathId cid)
      mEnt <- runDB $ get contentKey
      case mEnt of
        Nothing -> throwError err404
        Just ent -> do
          when (CMS.cmsContentAuthoredContentId ent == Nothing) $
            throwError err409 { errBody = "Legacy CMS content has no canonical authored content ID" }
          when (CMS.cmsContentStatus ent == "published") $
            throwError err409 { errBody = "Published CMS content cannot be deleted; publish a replacement revision" }
          now <- liftIO getCurrentTime
          runDB $ update contentKey
            [ CMS.CmsContentStatus =. "archived"
            , CMS.CmsContentUpdatedAt =. now
            ]
          pure NoContent

toCmsDTO :: Entity CMS.CmsContent -> CmsContentDTO
toCmsDTO (Entity cid c) =
  CmsContentDTO
    { ccdId = entityKeyInt cid
    , ccdContentId = UUID.toText <$> CMS.cmsContentAuthoredContentId c
    , ccdSlug = CMS.cmsContentSlug c
    , ccdLocale = CMS.cmsContentLocale c
    , ccdVersion = CMS.cmsContentVersion c
    , ccdStatus = CMS.cmsContentStatus c
    , ccdTitle = CMS.cmsContentTitle c
    , ccdPayload = CMS.unAesonValue <$> CMS.cmsContentPayload c
    , ccdCreatedAt = CMS.cmsContentCreatedAt c
    , ccdPublishedAt = CMS.cmsContentPublishedAt c
    }

loadAuthoredCmsTarget :: Text -> AppM (UUID.UUID, Catalog.AuthoredContent, Catalog.ContentType)
loadAuthoredCmsTarget rawContentId = do
  contentId <- either throwError pure (validateRequiredCmsContentId rawContentId)
  authoredContent <- runDB (get (Catalog.AuthoredContentKey contentId)) >>= maybe
    (throwError err404 { errBody = "Authored content not found" })
    pure
  unless (Catalog.authoredContentActive authoredContent) $
    throwError err409 { errBody = "Authored content is inactive" }
  contentType <- runDB (get (Catalog.authoredContentContentTypeId authoredContent)) >>= maybe
    (throwError err503 { errBody = "Authored content type is unavailable" })
    pure
  unless (Catalog.contentTypeActive contentType && Catalog.contentTypeEntityKind contentType == "authored_page") $
    throwError err409 { errBody = "Only active authored-page content types may use the CMS" }
  authoredState <- runDB (get (Catalog.authoredContentWorkflowStateId authoredContent)) >>= maybe
    (throwError err503 { errBody = "Authored content workflow state is unavailable" })
    pure
  typeState <- runDB (get (Catalog.contentTypeWorkflowStateId contentType)) >>= maybe
    (throwError err503 { errBody = "Content type workflow state is unavailable" })
    pure
  unless (Catalog.workflowStateCode authoredState == "published" && Catalog.workflowStateCode typeState == "published") $
    throwError err409 { errBody = "Authored content and its content type must be published" }
  pure (contentId, authoredContent, contentType)

validateRequiredCmsContentId :: Text -> Either ServerError UUID.UUID
validateRequiredCmsContentId rawContentId =
  case UUID.fromText (T.strip rawContentId) of
    Just contentId -> Right contentId
    Nothing -> Left err400 { errBody = "contentId must be a canonical UUID" }

validateCmsPayloadSchema :: Catalog.ContentType -> Maybe Value -> Either ServerError ()
validateCmsPayloadSchema contentType payload =
  case CMS.unAesonValue (Catalog.contentTypeSchemaJson contentType) of
    Object schemaObject ->
      case AKeyMap.lookup "required" schemaObject of
        Nothing -> Right ()
        Just (Array requiredValues) -> do
          requiredFields <- traverse requiredFieldName (toList requiredValues)
          case payload of
            Just (Object payloadObject) ->
              case filter (\field -> not (AKeyMap.member (AKey.fromText field) payloadObject)) requiredFields of
                [] -> Right ()
                missing -> Left err400
                  { errBody = BL.fromStrict . TE.encodeUtf8 $
                      "payload is missing required content-type fields: " <> T.intercalate ", " missing
                  }
            _ -> Left err400 { errBody = "payload is required by the persisted content type schema" }
        Just _ -> Left err503 { errBody = "Persisted content type schema has an invalid required field" }
    _ -> Left err503 { errBody = "Persisted content type schema must be a JSON object" }
  where
    requiredFieldName (String fieldName)
      | not (T.null (T.strip fieldName)) = Right (T.strip fieldName)
    requiredFieldName _ = Left err503
      { errBody = "Persisted content type schema contains a non-string required field" }

entityKeyInt :: ToBackendKey SqlBackend record => Key record -> Int
entityKeyInt = fromIntegral . fromSqlKey

-- Google Drive upload (proxied)
data DriveApiResp = DriveApiResp
  { darId             :: Text
  , darWebViewLink    :: Maybe Text
  , darWebContentLink :: Maybe Text
  , darResourceKey    :: Maybe Text
  , darRequestFingerprint :: Maybe Text
  } deriving (Show, Generic)

instance FromJSON DriveApiResp where
  parseJSON = withObject "DriveApiResp" $ \o -> do
    rejectUnexpectedDriveResponseKeys
      "Drive upload response"
      ["id", "webViewLink", "webContentLink", "resourceKey", "appProperties"]
      o
    darId <- (o .: "id") >>= parseDriveApiFileId
    darWebViewLink <-
      (o .:? "webViewLink") >>=
        parseDriveApiLink
          "webViewLink"
          darId
          sanitizeDriveWebContentLink
          "must be a Google Drive https link for the uploaded file"
    darWebContentLink <-
      (o .:? "webContentLink") >>=
        parseDriveApiLink
          "webContentLink"
          darId
          sanitizeDriveDownloadLink
          "must be a Google Drive download https link for the uploaded file"
    darResourceKey <-
      (o .:? "resourceKey") >>= traverse (parseDriveApiResourceKey "resourceKey")
    properties <- o .:? "appProperties"
    darRequestFingerprint <- case properties of
      Nothing -> pure Nothing
      Just value -> withObject "Drive appProperties" (.:? "tdfRequestFingerprint") value
    validateDriveResponseResourceKeyConsistency
      darWebViewLink
      darWebContentLink
      darResourceKey
    pure DriveApiResp{..}

newtype DriveListResp = DriveListResp { dlrFiles :: [DriveApiResp] }
  deriving (Show, Generic)

instance FromJSON DriveListResp where
  parseJSON = withObject "DriveListResp" $ \o -> do
    rejectUnexpectedDriveResponseKeys "Drive list response" ["files"] o
    DriveListResp <$> (o .:? "files" .!= [])

validateDriveResponseResourceKeyConsistency :: Maybe Text -> Maybe Text -> Maybe Text -> Parser ()
validateDriveResponseResourceKeyConsistency mWebViewLink mWebContentLink mResourceKey =
  case dedupeStable resourceKeys of
    _ : _ : _ ->
      fail "Drive upload response has conflicting resource keys"
    _ ->
      pure ()
  where
    resourceKeys =
      catMaybes
        [ mWebViewLink >>= singleValidResourceKeyParam
        , mWebContentLink >>= singleValidResourceKeyParam
        , mResourceKey
        ]

parseDriveApiFileId :: Text -> Parser Text
parseDriveApiFileId rawFileId
  | T.null fileId =
      fail "Drive file id is required"
  | T.length fileId > 256
      || not (T.any isDriveFolderIdAtom fileId)
      || not (T.all isDriveFolderIdChar fileId) =
      fail $
        "Drive file id must be 1-256 ASCII letters, digits, '-' or '_' "
          <> "with at least one letter or digit"
  | otherwise =
      pure fileId
  where
    fileId = T.strip rawFileId

parseDriveApiLink
  :: Text
  -> Text
  -> (Text -> Maybe Text -> Maybe Text)
  -> String
  -> Maybe Text
  -> Parser (Maybe Text)
parseDriveApiLink _ _ _ _ Nothing = pure Nothing
parseDriveApiLink fieldName fileId sanitizeLink shapeMessage (Just rawLink) =
  case cleanOptional (Just rawLink) of
    Nothing ->
      fail (T.unpack fieldName <> " must not be blank")
    Just _ ->
      case sanitizeLink fileId (Just rawLink) of
        Just link -> pure (Just link)
        Nothing ->
          fail (T.unpack fieldName <> " " <> shapeMessage)

parseDriveApiResourceKey :: Text -> Text -> Parser Text
parseDriveApiResourceKey fieldName rawResourceKey =
  case sanitizeDriveResourceKey (Just rawResourceKey) of
    Just resourceKey -> pure resourceKey
    Nothing ->
      fail
        ( T.unpack fieldName
            <> " must be 1-256 ASCII letters, digits, '-' or '_'"
            <> " with at least one letter or digit"
        )

data DriveMetaResp = DriveMetaResp
  { dmrResourceKey :: Maybe Text
  } deriving (Show, Generic)

instance FromJSON DriveMetaResp where
  parseJSON = withObject "DriveMetaResp" $ \o -> do
    rejectUnexpectedDriveResponseKeys
      "Drive metadata response"
      ["resourceKey"]
      o
    DriveMetaResp <$>
      ((o .:? "resourceKey") >>= traverse (parseDriveApiResourceKey "resourceKey"))

decodeDriveMetaResourceKeyIfSuccessful :: Int -> BL.ByteString -> Maybe Text
decodeDriveMetaResourceKeyIfSuccessful responseStatus responseBodyBytes
  | responseStatus /= 200 = Nothing
  | otherwise =
      case eitherDecode responseBodyBytes of
        Right (DriveMetaResp key) -> key
        Left _ -> Nothing

rejectUnexpectedDriveResponseKeys :: String -> [Text] -> AKeyMap.KeyMap Value -> Parser ()
rejectUnexpectedDriveResponseKeys responseLabel allowedKeys o =
  case filter (`Set.notMember` allowedKeySet) (AKeyMap.keys o) of
    [] -> pure ()
    unexpectedKey : _ ->
      fail $
        responseLabel <> " contains unexpected field: "
          <> T.unpack (AKey.toText unexpectedKey)
  where
    allowedKeySet = Set.fromList (map AKey.fromText allowedKeys)

-- Actor and exact request binding; a caller key is not ownership evidence.
-- Provider lookup/create is not atomic, so this is not an exactly-once guarantee.
driveUploadFingerprint :: PartyId -> Text -> Text -> Maybe Text -> BL.ByteString -> Text
driveUploadFingerprint actor name mime folder bytes =
  digest $ BL.toStrict $ encode
    ((1 :: Int), fromSqlKey actor, name, mime, folder, digest (BL.toStrict bytes))
  where
    digest value = T.pack (show (hash value :: Digest SHA256))

uploadToDrive
  :: Manager
  -> PartyId         -- ^ Current authenticated principal, never caller-supplied ownership
  -> Text            -- ^ Google access token (user or service)
  -> FileData Tmp    -- ^ Uploaded file from client
  -> Text            -- ^ Normalized file MIME type
  -> Maybe Text      -- ^ Optional override name
  -> Maybe Text      -- ^ Optional folder id
  -> Maybe Text      -- ^ Optional deterministic idempotency key
  -> IO DriveUploadDTO
uploadToDrive manager actor accessToken file mimeTypeTxt mName mFolder mIdempotencyKey = do
  fileBytes <- BL.readFile (fdPayload file)
  uuid <- nextRandom
  let boundary = "tdf-boundary-" <> T.replace "-" "" (toText uuid)
      dashBoundary = "--" <> boundary
      fileName = fromMaybe (fdFileName file) mName
      mimeTypeBS = TE.encodeUtf8 mimeTypeTxt
      fingerprint = driveUploadFingerprint actor fileName mimeTypeTxt mFolder fileBytes
      meta = object $
        [ "name" .= fileName
        , "mimeType" .= mimeTypeTxt
        ] <> maybe [] (\f -> ["parents" .= [f]]) mFolder
          <> maybe [] (\key -> ["appProperties" .= object
              ["tdfIdempotencyKey" .= key, "tdfRequestFingerprint" .= fingerprint]]) mIdempotencyKey

  let metaPart = BL.intercalate "\r\n"
        [ BL.fromStrict (TE.encodeUtf8 dashBoundary)
        , "Content-Type: application/json; charset=UTF-8"
        , ""
        , encode meta
        ]
      filePart = BL.intercalate "\r\n"
        [ BL.fromStrict (TE.encodeUtf8 dashBoundary)
        , BL.fromStrict $ "Content-Type: " <> mimeTypeBS
        , ""
        , fileBytes
        ]
      closing = BL.fromStrict (TE.encodeUtf8 (dashBoundary <> "--"))
      body = BL.intercalate "\r\n" [metaPart, filePart, closing, ""]

  req0 <- parseRequest $
    "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart" <>
    "&fields=id,webViewLink,webContentLink,resourceKey&supportsAllDrives=true"
  let bearer = "Bearer " <> TE.encodeUtf8 accessToken
      req = req0
        { method = "POST"
        , requestHeaders =
            [ ("Authorization", bearer)
            , ("Content-Type", BS8.pack ("multipart/related; boundary=" <> T.unpack boundary))
            ]
        , requestBody = RequestBodyLBS body
        }
  existing <- case mIdempotencyKey of
    Nothing -> pure Nothing
    Just key -> findDriveUploadByIdempotencyKey manager accessToken key mFolder
  driveResp <- case existing of
    Just found -> do
      unless (darRequestFingerprint found == Just fingerprint) $
        throwIO err409 { errBody = "Drive idempotency key is bound to a different or legacy unverified request" }
      pure found
    Nothing -> do
      resp <- httpLbs req manager
      let uploadStatus = statusCode (responseStatus resp)
      when (uploadStatus >= 400) $ do
        fail (formatDriveUploadFailure uploadStatus (responseBody resp))
      case eitherDecode (responseBody resp) of
        Left err -> fail ("No pudimos interpretar la respuesta de Drive: " <> err)
        Right ok -> pure (ok :: DriveApiResp)

  -- Best-effort: make the file public.
  let permBody = encode (object ["role" .= ("reader" :: Text), "type" .= ("anyone" :: Text)])
  permReq0 <- parseRequest $
    "https://www.googleapis.com/drive/v3/files/" <>
    T.unpack (darId driveResp) <>
    "/permissions?supportsAllDrives=true"
  let permReq = permReq0
        { method = "POST"
        , requestHeaders =
            [ ("Authorization", bearer)
            , ("Content-Type", "application/json")
            ]
        , requestBody = RequestBodyLBS permBody
        }
  permResp <- (try (httpLbs permReq manager) :: IO (Either SomeException (Response BL.ByteString)))

  metaReq0 <- parseRequest $
    "https://www.googleapis.com/drive/v3/files/" <>
    T.unpack (darId driveResp) <>
    "?fields=resourceKey&supportsAllDrives=true"
  let metaReq = metaReq0
        { requestHeaders =
            [ ("Authorization", bearer)
            ]
        }
  metaResp <- (try (httpLbs metaReq manager) :: IO (Either SomeException (Response BL.ByteString)))
  let metaResourceKey =
        case metaResp of
          Right respMeta ->
            decodeDriveMetaResourceKeyIfSuccessful
              (statusCode (responseStatus respMeta))
              (responseBody respMeta)
          Left _ -> Nothing
      publicUrl =
        case permResp of
          Right permissionResponse ->
            resolveDrivePublicUrlAfterPermission
              (statusCode (responseStatus permissionResponse))
              (darId driveResp)
              (darWebContentLink driveResp)
              (darResourceKey driveResp)
              metaResourceKey
          Left _ ->
            Nothing
  pure DriveUploadDTO
    { duFileId = darId driveResp
    , duWebViewLink = darWebViewLink driveResp
    , duWebContentLink = darWebContentLink driveResp
    , duPublicUrl = publicUrl
    }

findDriveUploadByIdempotencyKey
  :: Manager -> Text -> Text -> Maybe Text -> IO (Maybe DriveApiResp)
findDriveUploadByIdempotencyKey manager accessToken key mFolder = do
  let baseQuery = "appProperties has { key='tdfIdempotencyKey' and value='" <> key <> "' } and trashed=false"
      scopedQuery = maybe baseQuery (\folder -> baseQuery <> " and '" <> folder <> "' in parents") mFolder
      query = renderQuery True
        [ ("q", Just (TE.encodeUtf8 scopedQuery))
        , ("fields", Just "files(id,webViewLink,webContentLink,resourceKey,appProperties)")
        , ("pageSize", Just "2")
        ]
  req0 <- parseRequest ("https://www.googleapis.com/drive/v3/files" <> BS8.unpack query)
  let req = req0 { requestHeaders = [("Authorization", "Bearer " <> TE.encodeUtf8 accessToken)] }
  resp <- httpLbs req manager
  let responseStatusCode = statusCode (responseStatus resp)
  when (responseStatusCode >= 400) $
    fail (formatDriveUploadFailure responseStatusCode (responseBody resp))
  DriveListResp files <- case eitherDecode (responseBody resp) of
    Left err -> fail ("No pudimos interpretar la búsqueda idempotente de Drive: " <> err)
    Right parsed -> pure parsed
  case files of
    [] -> pure Nothing
    [found] -> pure (Just found)
    _ -> fail "Drive contains multiple files for one TDF idempotency key"

formatDriveUploadFailure :: Int -> BL.ByteString -> String
formatDriveUploadFailure uploadStatus responseBodyBytes =
  "Drive upload failed with status " <> show uploadStatus <> "." <> suffix
  where
    rawSnippet =
      T.take 2000 (TE.decodeUtf8With TEE.lenientDecode (BL.toStrict responseBodyBytes))
    suffix =
      maybe "" ((" " <>) . T.unpack) $
        structuredErrorMessage <|> sanitizeApiErrorMessage rawSnippet
    structuredErrorMessage =
      case eitherDecode responseBodyBytes :: Either String Value of
        Right payload -> extractApiErrorMessage payload
        Left _ -> Nothing

formatDriveUploadException :: Text -> String
formatDriveUploadException rawMessage =
  "Google Drive upload falló." <> suffix
  where
    suffix =
      maybe "" ((" " <>) . T.unpack) (sanitizeApiErrorMessage rawMessage)

resolveDrivePublicUrl :: Text -> Maybe Text -> Maybe Text -> Maybe Text -> Text
resolveDrivePublicUrl fileId mWebContentLink mUploadResourceKey mMetaResourceKey =
  appendDriveResourceKey resolvedResourceKey baseUrl
  where
    fallbackPublicUrl = "https://drive.google.com/uc?export=download&id=" <> encodeQueryValue fileId
    mContentLink = sanitizeDriveDownloadLink fileId mWebContentLink
    baseUrlCandidate = fromMaybe fallbackPublicUrl mContentLink
    baseUrl =
      if explicitResourceKeysConflict
        then dropNamedQueryParam "resourcekey" baseUrlCandidate
        else baseUrlCandidate
    explicitResourceKeyCandidates =
      [ sanitizeDriveResourceKey mUploadResourceKey
      , sanitizeDriveResourceKey mMetaResourceKey
      ]
    explicitResourceKeysConflict =
      hasConflictingDriveResourceKeys explicitResourceKeyCandidates
    resolvedResourceKey =
      if explicitResourceKeysConflict
        then Nothing
        else
          resolveDriveResourceKey explicitResourceKeyCandidates
            <|> (mContentLink >>= singleValidResourceKeyParam)

resolveDrivePublicUrlAfterPermission
  :: Int
  -> Text
  -> Maybe Text
  -> Maybe Text
  -> Maybe Text
  -> Maybe Text
resolveDrivePublicUrlAfterPermission
  permissionStatus
  fileId
  mWebContentLink
  mUploadResourceKey
  mMetaResourceKey
  | hasConflictingDriveResourceKeys
      [ sanitizeDriveResourceKey mUploadResourceKey
      , sanitizeDriveResourceKey mMetaResourceKey
      ] =
      Nothing
  | permissionStatus >= 200 && permissionStatus < 300 =
      Just (resolveDrivePublicUrl fileId mWebContentLink mUploadResourceKey mMetaResourceKey)
  | otherwise =
      Nothing

resolveDriveResourceKey :: [Maybe Text] -> Maybe Text
resolveDriveResourceKey resourceKeyCandidates =
  case dedupeStable (catMaybes resourceKeyCandidates) of
    [resourceKey] -> Just resourceKey
    _ -> Nothing

hasConflictingDriveResourceKeys :: [Maybe Text] -> Bool
hasConflictingDriveResourceKeys resourceKeyCandidates =
  case dedupeStable (catMaybes resourceKeyCandidates) of
    _ : _ : _ -> True
    _ -> False

sanitizeDriveResourceKey :: Maybe Text -> Maybe Text
sanitizeDriveResourceKey mResourceKey = do
  resourceKey <- cleanOptional mResourceKey
  if isValidDriveResourceKey resourceKey
    then Just resourceKey
    else Nothing

sanitizeDriveWebContentLink :: Text -> Maybe Text -> Maybe Text
sanitizeDriveWebContentLink expectedFileId mWebContentLink = do
  url <- cleanOptional mWebContentLink
  if "https://" `T.isPrefixOf` T.toLower url
      && TrialsServer.isValidHttpUrl url
      && isGoogleDriveDownloadHost url
      && not ("#" `T.isInfixOf` url)
      && not (hasAmbiguousDrivePathSegments url)
      && extractDriveContentFileId url == Just expectedFileId
    then Just (normalizeDriveResourceKeyParams url)
    else Nothing

sanitizeDriveDownloadLink :: Text -> Maybe Text -> Maybe Text
sanitizeDriveDownloadLink expectedFileId mWebContentLink = do
  url <- sanitizeDriveWebContentLink expectedFileId mWebContentLink
  if extractDriveDownloadFileId url == Just expectedFileId
    then Just url
    else Nothing

extractDriveContentFileId :: Text -> Maybe Text
extractDriveContentFileId rawUrl =
  case drivePathSegments rawUrl of
    ["uc"] ->
      singleDriveIdQueryParam rawUrl
    ["download"] ->
      singleDriveIdQueryParam rawUrl
    ["download", fileId]
      | isValidDriveFileId fileId
      , not (hasNamedQueryParam "id" rawUrl) ->
          Just fileId
    ["u", userSegment, "uc"]
      | T.all isDigit userSegment ->
          singleDriveIdQueryParam rawUrl
    ["file", "d", fileId]
      | isValidDriveFileId fileId
      , not (hasNamedQueryParam "id" rawUrl) ->
          Just fileId
    ["file", "d", fileId, suffix]
      | isValidDriveFileId fileId
      , not (hasNamedQueryParam "id" rawUrl)
      , suffix `elem` ["view", "preview", "edit"] ->
          Just fileId
    _ ->
      Nothing

hasAmbiguousDrivePathSegments :: Text -> Bool
hasAmbiguousDrivePathSegments rawUrl =
  any (\segment -> T.null segment || segment == "." || segment == "..") pathSegments
  where
    remainder = T.drop 8 rawUrl
    afterAuthority =
      T.dropWhile
        (\c -> c /= '/' && c /= '?' && c /= '#')
        remainder
    path = T.takeWhile (\c -> c /= '?' && c /= '#') afterAuthority
    pathSegments =
      if T.null path
        then []
        else T.splitOn "/" (T.drop 1 path)

extractDriveDownloadFileId :: Text -> Maybe Text
extractDriveDownloadFileId rawUrl =
  case drivePathSegments rawUrl of
    ["uc"] ->
      singleDriveIdQueryParam rawUrl
    ["download"] ->
      singleDriveIdQueryParam rawUrl
    ["download", fileId]
      | isValidDriveFileId fileId
      , not (hasNamedQueryParam "id" rawUrl) ->
          Just fileId
    ["u", userSegment, "uc"]
      | T.all isDigit userSegment ->
          singleDriveIdQueryParam rawUrl
    _ ->
      Nothing

isValidDriveFileId :: Text -> Bool
isValidDriveFileId fileId =
  T.length fileId <= 256 && T.all isDriveFolderIdChar fileId

singleDriveIdQueryParam :: Text -> Maybe Text
singleDriveIdQueryParam rawUrl =
  case [ queryParamValue rawParam
       | rawParam <- queryParams rawUrl
       , isNamedQueryParam "id" rawParam
       ] of
    [Just rawFileId]
      | let fileId = T.strip rawFileId
      , not (T.null fileId)
      , isValidDriveFileId fileId ->
          Just fileId
    _ ->
      Nothing

drivePathSegments :: Text -> [Text]
drivePathSegments rawUrl =
  filter (not . T.null) (T.splitOn "/" path)
  where
    remainder = T.drop 8 rawUrl
    afterAuthority =
      T.dropWhile
        (\c -> c /= '/' && c /= '?' && c /= '#')
        remainder
    path = T.takeWhile (\c -> c /= '?' && c /= '#') afterAuthority

queryParams :: Text -> [Text]
queryParams url =
  filter (not . T.null) (T.splitOn "&" query)
  where
    (withoutFragment, _) = T.breakOn "#" url
    queryWithMarker = snd (T.breakOn "?" withoutFragment)
    query = T.drop 1 queryWithMarker

hasNamedQueryParam :: Text -> Text -> Bool
hasNamedQueryParam paramName url =
  any (isNamedQueryParam paramName) (queryParams url)

isGoogleDriveDownloadHost :: Text -> Bool
isGoogleDriveDownloadHost rawUrl =
  case httpsUrlAuthority rawUrl of
    Just (host, portSuffix) ->
      host `elem` ["drive.google.com", "drive.usercontent.google.com"]
        && (T.null portSuffix || portSuffix == ":443")
    Nothing ->
      False

httpsUrlAuthority :: Text -> Maybe (Text, Text)
httpsUrlAuthority rawUrl
  | "https://" `T.isPrefixOf` T.toLower rawUrl =
      let remainder = T.drop 8 rawUrl
          authority =
            T.takeWhile
              (\c -> c /= '/' && c /= '?' && c /= '#')
              remainder
          (host, portSuffix) = T.breakOn ":" authority
          normalizedHost = T.toLower host
      in if T.null normalizedHost then Nothing else Just (normalizedHost, portSuffix)
  | otherwise =
      Nothing

appendDriveResourceKey :: Maybe Text -> Text -> Text
appendDriveResourceKey mResourceKey url =
  case cleanOptional mResourceKey of
    Nothing -> url
    Just resourceKey
      | singleValidResourceKeyParam url == Just resourceKey -> url
      | otherwise ->
          appendQueryParam "resourcekey" resourceKey (dropNamedQueryParam "resourcekey" url)

normalizeDriveResourceKeyParams :: Text -> Text
normalizeDriveResourceKeyParams url
  | null resourceKeyParams = url
  | hasSingleValidResourceKeyParam url = url
  | otherwise = dropNamedQueryParam "resourcekey" url
  where
    resourceKeyParams =
      filter (isNamedQueryParam "resourcekey") (queryParams url)

hasSingleValidResourceKeyParam :: Text -> Bool
hasSingleValidResourceKeyParam url =
  isJust (singleValidResourceKeyParam url)

singleValidResourceKeyParam :: Text -> Maybe Text
singleValidResourceKeyParam url =
  case [ rawParam
       | rawParam <- queryParams url
       , isNamedQueryParam "resourcekey" rawParam
       ] of
    [rawParam] ->
      queryParamValue rawParam >>= \value ->
        if isValidDriveResourceKey value
          then Just (T.strip value)
          else Nothing
    _ -> Nothing

isValidDriveResourceKey :: Text -> Bool
isValidDriveResourceKey rawValue =
  let value = T.strip rawValue
  in not (T.null value)
      && T.length value <= 256
      && T.any isDriveFolderIdAtom value
      && T.all isDriveFolderIdChar value

queryParamValue :: Text -> Maybe Text
queryParamValue rawParam =
  case T.breakOn "=" rawParam of
    (_, "") -> Nothing
    (_, rawValueWithEquals) -> Just (T.drop 1 rawValueWithEquals)

dropNamedQueryParam :: Text -> Text -> Text
dropNamedQueryParam paramName url =
  case T.breakOn "?" withoutFragment of
    (_, "") -> url
    (base, queryWithMarker) ->
      let params = filter (not . T.null) (T.splitOn "&" (T.drop 1 queryWithMarker))
          filtered = filter (not . isNamedQueryParam paramName) params
          rebuilt =
            if null filtered
              then base
              else base <> "?" <> T.intercalate "&" filtered
      in rebuilt <> fragment
  where
    (withoutFragment, fragment) = T.breakOn "#" url

isNamedQueryParam :: Text -> Text -> Bool
isNamedQueryParam paramName rawParam =
  let rawName = fst (T.breakOn "=" rawParam)
      expectedName = T.toLower paramName
  in T.toLower rawName == expectedName
      || T.toLower (decodeQueryParamName rawName) == expectedName

decodeQueryParamName :: Text -> Text
decodeQueryParamName =
  TE.decodeUtf8With TEE.lenientDecode . urlDecode True . TE.encodeUtf8

appendQueryParam :: Text -> Text -> Text -> Text
appendQueryParam paramName paramValue url =
  withoutFragment <> separator <> paramName <> "=" <> encodeQueryValue paramValue <> fragment
  where
    (withoutFragment, fragment) = T.breakOn "#" url
    separator
      | "?" `T.isInfixOf` withoutFragment =
          if T.isSuffixOf "?" withoutFragment || T.isSuffixOf "&" withoutFragment
            then ""
            else "&"
      | otherwise = "?"

encodeQueryValue :: Text -> Text
encodeQueryValue =
  TE.decodeUtf8 . urlEncode True . TE.encodeUtf8
