{-# LANGUAGE OverloadedStrings #-}
module Main where
import Control.Exception (bracket)
import Control.Monad.IO.Class (liftIO)
import Control.Monad.Logger (runNoLoggingT)
import Control.Monad.Reader (runReaderT)
import Data.Pool (destroyAllResources)
import Data.Time (getCurrentTime)
import Database.Persist
import Database.Persist.Sql
import Database.Persist.Sqlite (createSqlitePool)
import Servant (NoContent(..))
import Servant.Server.Internal.Handler (runHandler)
import Test.Hspec
import TDF.Auth (AuthedUser(..), modulesForRoles)
import TDF.DB (Env(..))
import qualified TDF.Models as M
import qualified TDF.DTO as DTO
import qualified TDF.Server as Server

main :: IO ()
main = hspec $ describe "package purchase expiry baseline probe" $ do
  it "keeps a configured positive validity finite" $ do
    rows <- purchase (Just 120)
    case rows of
      [Entity _ row] -> M.packagePurchaseExpiresAt row `shouldSatisfy` (/= Nothing)
      _ -> expectationFailure "Handler must persist exactly one purchase"
  it "preserves an explicitly nonexpiring product" $ do
    rows <- purchase Nothing
    case rows of
      [Entity _ row] -> M.packagePurchaseExpiresAt row `shouldBe` Nothing
      _ -> expectationFailure "Handler must persist exactly one purchase"

purchase :: Maybe Int -> IO [Entity M.PackagePurchase]
purchase days = bracket (runNoLoggingT (createSqlitePool ":memory:" 1)) destroyAllResources $ \pool -> do
  now <- getCurrentTime
  let run action = runSqlPool action pool
  product <- run $ do
    initialize
    rawExecute "INSERT INTO party(id,display_name,is_org,created_at) VALUES (1,'Synthetic expiry probe',0,?)" [PersistUTCTime now]
    insert (M.PackageProduct "Synthetic120" M.Classes M.Hours 24 50000 days False M.CreditOnly True)
  let user = AuthedUser (toSqlKey 1) [M.Admin] (modulesForRoles [M.Admin]) Nothing Nothing
      env = Env pool (error "This handler must not evaluate provider configuration")
  response <- runHandler (runReaderT (Server.createPurchase user (DTO.PackagePurchaseReq 1 (fromSqlKey product))) env)
  case response of
    Left err -> expectationFailure ("Unexpected handler error: " <> show err)
    Right NoContent -> pure ()
  run (selectList [] [] )

initialize :: SqlPersistT IO ()
initialize = do
    rawExecute "PRAGMA foreign_keys = ON" []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"package_product\" (\
        \\"id\" INTEGER PRIMARY KEY,\
        \\"name\" VARCHAR NOT NULL,\
        \\"service_kind\" VARCHAR NOT NULL,\
        \\"units_kind\" VARCHAR NOT NULL,\
        \\"units_qty\" INTEGER NOT NULL,\
        \\"price_cents\" INTEGER NOT NULL,\
        \\"expires_days\" INTEGER NULL,\
        \\"transferable\" BOOLEAN NOT NULL,\
        \\"refund_policy\" VARCHAR NOT NULL,\
        \\"active\" BOOLEAN NOT NULL\
        \)"
        []

    rawExecute "CREATE TABLE package_purchase(id INTEGER PRIMARY KEY,buyer_id INTEGER NOT NULL REFERENCES party(id),product_id INTEGER NOT NULL REFERENCES package_product(id),purchased_at TIMESTAMP NOT NULL,price_cents INTEGER NOT NULL,expires_at TIMESTAMP NULL,remaining_units INTEGER NOT NULL,status TEXT NOT NULL)" []
