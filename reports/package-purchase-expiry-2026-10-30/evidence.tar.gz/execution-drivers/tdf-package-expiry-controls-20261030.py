from pathlib import Path
import subprocess, os, signal, hashlib, json, re, datetime
w = Path('/private/tmp/tdf-package-purchase-expiry-20261030')
o = Path('/private/tmp/tdf-package-purchase-expiry-qualification-20261030')
p = w/'tdf-hq/src/TDF/Server.hs'
fixed = p.read_bytes()
repair = json.loads((o/'repair-applied.json').read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()
assert sha(fixed) == repair['correctedHandlerSha256']
test = w/'tdf-hq/test/TDF/ServerSpec.hs'
assert sha(test.read_bytes()) == repair['testSha256']
env = {k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']}
env['PATH'] = '/Users/macpro/.ghcup/bin:/usr/local/bin:/usr/bin:/bin'
env['STACK_ROOT'] = '/Users/macpro/.stack'
binary = w/'tdf-hq/.stack-work/dist/x86_64-osx/ghc-9.10.3/build/tdf-hq-test/tdf-hq-test'
state = {'phase':'CORRECTED_NATIVE_BUILD','sourceContext':repair,'results':[]}
def save():
    (o/'control-state.json').write_text(json.dumps(state, indent=2)+'\n')
def interrupted(signum, frame):
    raise KeyboardInterrupt('Owned control interrupted')
signal.signal(signal.SIGTERM, interrupted)
def run(cmd, log, label):
    with log.open('w') as stream:
        child = subprocess.Popen(cmd, cwd=w/'tdf-hq', env=env, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        state['activePID'] = child.pid
        state['activeOperation'] = label
        save()
        try:
            return child.wait(timeout=3600)
        except BaseException:
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGTERM)
                try: child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait(timeout=10)
            raise
def check(label, failures):
    state['phase'] = label
    save()
    build = run(['/Users/macpro/.ghcup/bin/stack','test','tdf-hq:tdf-hq-test','--no-run-tests'],o/(label+'-build.log'),label+'-build')
    assert build == 0, 'Compilation failure is not an accepted control'
    code = run([str(binary),'--match','createPurchase expiry'],o/(label+'-tests.log'),label+'-tests')
    raw = (o/(label+'-tests.log')).read_text()
    assert code == (1 if failures else 0)
    assert re.search(r'11 examples, '+str(failures)+r' failures?',raw), raw[-2500:]
    if label == 'wrong-unit':
        assert raw.count('expected: Just') == 3 and 'but got: Just' in raw
    if label == 'write-before-refuse':
        assert raw.count('expected: 0') == 2 and raw.count('but got: 1') == 2
        assert 'Unexpected successful package purchase' not in raw
    assert sha(test.read_bytes()) == repair['testSha256']
    result = {'label':label,'buildExit':build,'testExit':code,'examples':11,'assertionFailures':failures,'handlerSha256':sha(p.read_bytes()),'testSha256':sha(test.read_bytes()),'binarySha256':sha(binary.read_bytes()),'logSha256':sha((o/(label+'-tests.log')).read_bytes())}
    state['results'].append(result)
    save()
    print(json.dumps(result), flush=True)
try:
    check('corrected',0)
    s = fixed.decode()
    assert s.count('fromIntegral days * 86400') == 1
    p.write_text(s.replace('fromIntegral days * 86400','fromIntegral days'))
    check('wrong-unit',3)
    s = fixed.decode()
    guard = '                | maybe False (<= 0) (packageProductExpiresDays productRecord) ->\n                    Left err409 { errBody = "Package product validity must be positive when configured" }\n'
    assert s.count(guard) == 1
    s = s.replace(guard,'')
    start = s.index('createPurchase ::')
    end = s.index('\nresolvePackagePurchaseRefs\n',start)
    body = s[start:end]
    assert body.count('        pure (Right ())') == 1
    body = body.replace('        pure (Right ())','        if maybe False (<= 0) (packageProductExpiresDays productRecord)\n          then pure (Left err409 { errBody = "Package product validity must be positive when configured" })\n          else pure (Right ())')
    p.write_text(s[:start]+body+s[end:])
    check('write-before-refuse',2)
finally:
    p.write_bytes(fixed)
    assert p.read_bytes() == fixed
    state['sourceRestoredSha256'] = sha(fixed)
    save()
check('restored',0)
state.update(phase='TWO_NATIVE_FAULTS_DETECTED_RESTORED',actualVariants=2,intendedAssertionFailures=5,completedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat())
save()
(o/'controls.json').write_text(json.dumps(state,indent=2)+'\n')
print('Two native module faults detected by five assertions; restored 11/0',flush=True)

