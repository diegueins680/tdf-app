from pathlib import Path
import subprocess, json, hashlib
w=Path('/private/tmp/tdf-package-purchase-expiry-20261030')
o=Path('/private/tmp/tdf-package-purchase-expiry-qualification-20261030')
base='e1cec5b59723c2ff9828ac4fce45abb930d73055'
controls=json.loads((o/'controls.json').read_text())
assert controls['phase']=='TWO_NATIVE_FAULTS_DETECTED_RESTORED'
assert controls['actualVariants']==2 and controls['intendedAssertionFailures']==5
p=w/'tdf-hq/src/TDF/Server.hs'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(p.read_bytes())==controls['sourceRestoredSha256']
assert sha((w/'tdf-hq/test/TDF/ServerSpec.hs').read_bytes())==controls['sourceContext']['testSha256']
s=p.read_text()
s=s.replace('              , packagePurchaseExpiresAt      =\n                  (\\days -> addUTCTime (fromIntegral days * 86400) now)\n                    <$> packageProductExpiresDays productRecord','              , packagePurchaseExpiresAt      = Nothing')
s=s.replace('                | maybe False (<= 0) (packageProductExpiresDays productRecord) ->\n                    Left err409 { errBody = "Package product validity must be positive when configured" }\n','')
assert s.encode()==subprocess.check_output(['git','show',base+':tdf-hq/src/TDF/Server.hs'],cwd=w)
state={'phase':'CANONICAL_METADATA'}
def save():(o/'preparation-state.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,cmd):
    with (o/(label+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=w,stdout=log,stderr=subprocess.STDOUT)
    state[label+'Exit']=r.returncode
    save()
    print(label+' actualexit '+str(r.returncode),flush=True)
    assert r.returncode==0,label
save()
run('metadata',['python3','/private/tmp/tdf-package-expiry-metadata-20261030.py'])
paths=['tdf-hq/src/TDF/Server.hs','tdf-hq/test/TDF/ServerSpec.hs','formal/system/package-purchase-expiry.md','formal/system/requirements.json','formal/system/inventory.json','formal/system/traceability.json','docs/catalog-persistence/reports/static-list-inventory.json','docs/catalog-persistence/reports/list-consumer-matrix.csv']
changed={line[3:] for line in subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).splitlines()}
assert changed==set(paths),changed
run('diff-check',['git','diff','--check'])
run('stage-source',['git','add','--',*paths])
run('commit-source',['git','commit','-m','fix(packages): preserve configured validity on new purchases'])
state['sourceCommit']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
state['phase']='CLEAN_SOURCE_COMMITTED'
save()

