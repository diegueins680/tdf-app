from pathlib import Path
import json, subprocess, hashlib
w=Path('/private/tmp/tdf-package-purchase-expiry-20261030')
o=Path('/private/tmp/tdf-package-purchase-expiry-qualification-20261030')
base='e1cec5b59723c2ff9828ac4fce45abb930d73055'
m=json.loads((o/'preparation-state.json').read_text())['sourceCommit']
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args,cwd=w):return subprocess.check_output(['git',*args],cwd=cwd)
assert git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip()
q=json.loads((o/'native-quality.json').read_text())
root=json.loads((o/'root-quality-result.json').read_text())
c=json.loads((o/'controls.json').read_text())
f=json.loads((o/'assurance-committed/report.json').read_text())
s=json.loads((o/'assurance-committed/sources.json').read_text())
assert q['sourceCommit']==root['sourceCommit']==s['revision']==m
assert all(v==0 for v in q['actualExits'].values()) and all(v==0 for v in root['actualExits'].values())
assert q['targeted']=={'examples':11,'failures':0,'pending':0}
assert q['full']['failures']==0 and q['full']['examples']>11
assert f['execution']['passed'] and f['provenance']['revision']==m and not s['worktreeDirty']
assert s['digest']==sha(json.dumps(s['files'],sort_keys=True).encode())
mobile=git('rev-parse',m+':tdf-mobile').decode().strip()
assert git('rev-parse','HEAD',cwd=w/'tdf-mobile').decode().strip()==mobile
for isMobile in [False,True]:
    pairs=[(p,h) for p,h in s['files'].items() if p.startswith('tdf-mobile/')==isMobile]
    cwd=w/'tdf-mobile' if isMobile else w
    rev=mobile if isMobile else m
    refs=[rev+':'+(p.removeprefix('tdf-mobile/') if isMobile else p) for p,h in pairs]
    assert all('\n' not in x for x in refs)
    raw=subprocess.check_output(['git','cat-file','--batch'],cwd=cwd,input=('\n'.join(refs)+'\n').encode())
    pos=0
    for p,h in pairs:
        end=raw.index(b'\n',pos);header=raw[pos:end].split()
        assert header[1]==b'blob'
        n=int(header[2])
        assert sha(raw[end+1:end+1+n])==h==sha((w/p).read_bytes()),p
        pos=end+1+n+1
    assert pos==len(raw)
old=json.loads(git('show',base+':formal/system/requirements.json'))['requirements']
new=json.loads((w/'formal/system/requirements.json').read_text())['requirements']
by={x['id']:x for x in new}
assert len(new)==len(old)+1==159 and all(by[x['id']]==x for x in old)
assert 'PKG-PURCHASE-EXPIRY-001' in by
prod='tdf-hq/src/TDF/Server.hs'
source=(w/prod).read_bytes()
assert source==(o/'corrected-handler.hs').read_bytes()
assert sha(source)==c['sourceRestoredSha256']==sha(git('show',m+':'+prod))
reversedSource=source.decode().replace('              , packagePurchaseExpiresAt      =\n                  (\\days -> addUTCTime (fromIntegral days * 86400) now)\n                    <$> packageProductExpiresDays productRecord','              , packagePurchaseExpiresAt      = Nothing')
reversedSource=reversedSource.replace('                | maybe False (<= 0) (packageProductExpiresDays productRecord) ->\n                    Left err409 { errBody = "Package product validity must be positive when configured" }\n','')
assert reversedSource.encode()==git('show',base+':'+prod)==(o/'baseline-handler.hs').read_bytes()
test='tdf-hq/test/TDF/ServerSpec.hs'
assert sha((w/test).read_bytes())==c['sourceContext']['testSha256']==sha((o/'baseline-ServerSpec.hs').read_bytes())==sha(git('show',m+':'+test))
assert c['actualVariants']==2 and c['intendedAssertionFailures']==5
assert [v['label'] for v in c['results']]==['corrected','wrong-unit','write-before-refuse','restored']
for result in c['results']:
    expected=(o/('expected-'+result['label']+'-handler.hs')).read_bytes() if result['label'] in ['wrong-unit','write-before-refuse'] else source
    assert result['handlerSha256']==sha(expected)
    assert result['buildExit']==0 and result['examples']==11
    assert result['logSha256']==sha((o/(result['label']+'-tests.log')).read_bytes())
for p in ['tdf-hq-ui','tdf-mobile','.github','tdf-hq/tdf-hq.cabal','tdf-hq/stack.yaml','tdf-hq/stack.yaml.lock','formal/system/auth-predicates.json','formal/system/recovery-expiry-arithmetic.json','docs/catalog-persistence/catalog-list-decisions.json']:
    assert git('rev-parse',m+':'+p)==git('rev-parse',base+':'+p),p
changes=git('diff','--name-only',base,m,'--','tdf-hq').decode().splitlines()
assert set(changes)=={prod,test},changes
contracts={p:sha((w/p).read_bytes()) for p in ['formal/system/package-purchase-expiry.md','docs/Manual_Usuario_TDF.md','tdf-hq/src/TDF/Seed.hs','tdf-hq/sql/2026-08-09_admin_operations_control_center.sql']}
for p,h in contracts.items():assert sha(git('show',m+':'+p))==h
assert Path(q['binary']).exists() and sha(Path(q['binary']).read_bytes())==q['binarySha256']
inputs=json.loads((o/'native-qualified-inputs.json').read_text())['allBackendTrackedGitSha256']
record={'baseline':base,'sourceCommit':m,'registeredGitFilesystemMobileHashesVerified':len(s['files']),'sourceDigest':s['digest'],'all158IncomingRequirementsExact':True,'requirementsTotal':len(new),'contractAndAuthorityGitSha256':contracts,'allQualifiedBackendInputsGitExact':q['allBackendInputsUnchangedAndGitExact'],'qualifiedBackendInputCount':len(inputs),'nativeTargeted':q['targeted'],'nativeFull':q['full'],'nativeTestBinarySha256':q['binarySha256'],'precommitControls':c,'unchangedTestBytesBaselineControlsQualifiedSource':True,'reversingOnlyTwoProductionEditsReconstructsMain':True,'uiMobileWorkflowCabalStackModelContractsExactMain':True,'backendChangesOnly':changes,'freshAssuranceMetrics':f['metrics'],'formalRelease':f['release']['decision'],'newCompleteProofs':0,'sourceCleanAfter':True,'limits':['Finite typed Handler/SQLite tests; no authenticatedHTTP, production PostgreSQL trigger or serving executable/deployment guarantee.','Very large configured durations/database timestamp range and concurrent product-edit snapshot policy remain separate.','No actor/payment/gift/redemption policy or historical record change.','Source controls execute native actual Server module before clean-source commit; source/test bytes bound separately to final qualified native test artifact.']}
force=json.loads((o/'native-force-dirty-confirmed.json').read_text())
assert force['sourceCommit']==m and force['canonicalForceDirty'] and force['qualifiedCommitLiteralInVersionObjectAndTestBinary'] and force['binarySha256']==q['binarySha256']
record['canonicalForceDirtyConfirmed']=force
(o/'source-correspondence.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k in ['sourceCommit','registeredGitFilesystemMobileHashesVerified','qualifiedBackendInputCount','nativeTargeted','nativeFull','formalRelease']},indent=2))

