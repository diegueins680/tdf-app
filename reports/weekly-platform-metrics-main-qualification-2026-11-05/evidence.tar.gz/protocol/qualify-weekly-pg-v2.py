#!/usr/bin/env python3
"""Disposable PG16 execution of exact weekly query against extracted actual schemas."""
import pathlib,subprocess,json,hashlib,importlib.util,datetime,os,re
repo=pathlib.Path('/private/tmp/tdf-pr681-prep-20261105');out=pathlib.Path(__file__).resolve().parent/'pr681-postgres-v2';out.mkdir(exist_ok=True)
cluster=pathlib.Path('/private/tmp/tdf-weekly-pg16-v2-20261105');sock=pathlib.Path('/private/tmp/tdf-weekly-pg16-sock-v2-20261105');sock.mkdir(exist_ok=True)
pg=pathlib.Path('/usr/local/opt/postgresql@16/bin');records=[]
def run(name,args,sql=None,ok=True):
 r=subprocess.run([str(x) for x in args],input=sql,text=True,capture_output=True)
 (out/(name+'.stdout')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
 records.append({'name':name,'argv':[str(x) for x in args],'exit':r.returncode,'stdoutSHA256':hashlib.sha256(r.stdout.encode()).hexdigest(),'stderrSHA256':hashlib.sha256(r.stderr.encode()).hexdigest()})
 if ok and r.returncode:raise RuntimeError(name+': '+r.stderr)
 return r
if cluster.exists():raise RuntimeError('Own cluster path already exists; refuse adoption')
run('initdb',[pg/'initdb','-D',cluster,'-A','trust','--no-locale','-E','UTF8'])
started=False
try:
 run('start',[pg/'pg_ctl','-D',cluster,'-l',out/'server.log','-o',f"-h '' -k {sock} -p 55489",'-w','start']);started=True
 conn=[pg/'psql','-X','-h',sock,'-p','55489','-d','postgres','-v','ON_ERROR_STOP=1','-v','VERBOSITY=verbose','-qAt']
 init=(repo/'tdf-hq/sql/init_schema.sql').read_text();schema=''
 for table in ['party','artist_profile']:
  schema+=re.search(r'CREATE TABLE IF NOT EXISTS '+table+r' \([\s\S]*?\n\);',init).group(0)+'\n'
 schema+=(repo/'tdf-hq/sql/2026-09-06_user_onboarding_progress.sql').read_text()
 (out/'schema.sql').write_text(schema);run('schema',conn,sql=schema)
 setup="""INSERT INTO party(id,display_name) SELECT x,'Synthetic fixture '||x FROM generate_series(1,10)x;
INSERT INTO user_onboarding_progress(party_id,signup_completed_at,completed_at,first_value,first_value_completed_at) VALUES
(1,'2026-10-25T00:00Z','2026-10-25T00:00Z','artist_followed','2026-10-25T00:00Z'),
(2,'2026-11-01T00:00Z','2026-11-01T00:00Z','event_saved','2026-11-01T00:00Z'),
(3,'2026-10-18T00:00Z','2026-10-18T00:00Z','event_saved','2026-10-18T00:00Z'),
(4,'2026-10-24T23:59:59.999999Z','2026-10-24T23:59:59.999999Z','event_saved','2026-10-24T23:59:59.999999Z'),
(5,NULL,'2026-10-26T00:00Z','event_saved','2026-10-26T00:00Z'),
(6,'2026-10-17T00:00Z','2026-10-17T00:00Z','event_saved','2026-10-27T00:00Z'),
(7,'2026-10-27T00:00Z','2026-10-27T00:00Z','event_saved','2026-10-27T00:00Z'),
(8,'2026-10-31T23:59:59.999999Z',NULL,NULL,NULL),
(9,'2026-10-17T23:59:59.999999Z','2026-10-17T23:59:59.999999Z','event_saved','2026-10-17T23:59:59.999999Z');
INSERT INTO artist_profile(artist_party_id,created_at) VALUES
(1,'2026-10-25T00:00Z'),(2,'2026-11-01T00:00Z'),(3,'2026-10-18T00:00Z'),(4,'2026-10-24T23:59:59.999999Z'),(8,'2026-10-31T23:59:59.999999Z'),(9,'2026-10-17T23:59:59.999999Z');
CREATE ROLE tdf_weekly_readonly LOGIN NOINHERIT NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION;
REVOKE CREATE ON SCHEMA public FROM PUBLIC;
GRANT CONNECT ON DATABASE postgres TO tdf_weekly_readonly;
GRANT USAGE ON SCHEMA public TO tdf_weekly_readonly;
GRANT SELECT ON public.user_onboarding_progress,public.artist_profile TO tdf_weekly_readonly;
"""
 (out/'fixture.sql').write_text(setup);run('fixture',conn,sql=setup)
 spec=importlib.util.spec_from_file_location('weekly',repo/'scripts/weekly-platform-metrics.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 query=mod.query('2026-11-01T00:00:00Z');(out/'query.sql').write_text(query)
 roconn=conn+['-U','tdf_weekly_readonly'];result=json.loads(run('actual-query-readonly-role',roconn,sql=query).stdout)
 expected={'current':{'recorded_signups':3,'recorded_first_values':3,'artist_profiles_all_origins':2},'previous':{'recorded_signups':2,'recorded_first_values':2,'artist_profiles_all_origins':2}}
 assert result['periods']==expected,(result,expected)
 assert json.loads(run('equivalent-offset',roconn,sql=mod.query('2026-10-31T19:00:00-05:00')).stdout)['periods']==expected
 summary=mod.summarize(result,'2026-11-01T00:00Z');assert summary['metrics']['recorded_signups']['percent_change']==50.0;assert all(v is None for v in summary['unavailable'].values())
 # Actual transaction settings and SELECT-only least-privilege role are checked separately.
 settings=run('transaction-settings',roconn,sql=query.replace('COMMIT;',"SHOW transaction_read_only; SHOW transaction_isolation; SHOW statement_timeout; SHOW lock_timeout; COMMIT;"))
 assert settings.stdout.splitlines()[-4:]==['on','repeatable read','15s','2s']
 denied=run('least-privilege-write-control',roconn,sql="INSERT INTO public.artist_profile(artist_party_id) VALUES(10);",ok=False);assert denied.returncode!=0 and '42501' in denied.stderr
 denied2=run('readonly-transaction-write-control',conn,sql="BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY; INSERT INTO public.artist_profile(artist_party_id) VALUES(10); COMMIT;",ok=False);assert denied2.returncode!=0 and '25006' in denied2.stderr
 denied3=run('private-identity-read-control',roconn,sql='SELECT display_name FROM public.party;',ok=False);assert denied3.returncode!=0 and '42501' in denied3.stderr
 run('unchanged-row-counts',conn,sql="SELECT (SELECT count(*) FROM artist_profile)=6 AND (SELECT count(*) FROM user_onboarding_progress)=9;")
 assert (out/'unchanged-row-counts.stdout').read_text().strip()=='t'
 receipt={'status':'PASS','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'postgresVersion':run('postgres-version',[pg/'postgres','--version']).stdout.strip(),'querySHA256':hashlib.sha256(query.encode()).hexdigest(),'expectedPeriods':expected,'actual':result,'summary':summary,'scope':'Actual PostgreSQL16 parsing/aggregation, half-open boundaries, equivalent offsets, all-cohort milestone and unknown coverage, generated transaction settings, SELECT-only least privilege on extracted exact actual table DDL. Synthetic local rows only; not full canonical migration replay or production data/grants.','productionDatabaseContacted':False,'productionPermissionsChanged':False,'sources':{f:hashlib.sha256((repo/f).read_bytes()).hexdigest() for f in ['scripts/weekly-platform-metrics.py','tdf-hq/sql/init_schema.sql','tdf-hq/sql/2026-09-06_user_onboarding_progress.sql']}}
finally:
 if started:run('stop',[pg/'pg_ctl','-D',cluster,'-m','fast','-w','stop'])
 (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
if 'receipt' in locals():
 receipt['clusterStopped']=not (cluster/'postmaster.pid').exists();assert receipt['clusterStopped'];(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
