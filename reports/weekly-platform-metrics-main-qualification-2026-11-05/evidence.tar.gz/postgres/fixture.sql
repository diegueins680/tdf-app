INSERT INTO party(id,display_name) SELECT x,'Synthetic fixture '||x FROM generate_series(1,10)x;
INSERT INTO user_onboarding_progress(party_id,signup_completed_at,completed_at,first_value,first_value_completed_at) VALUES
(1,'2026-10-25T00:00Z','2026-10-25T00:00Z','artist_followed','2026-10-25T00:00Z'),
(2,'2026-11-01T00:00Z','2026-11-01T00:00Z','event_saved','2026-11-01T00:00Z'),
(3,'2026-10-18T00:00Z','2026-10-18T00:00Z','event_saved','2026-10-18T00:00Z'),
(4,'2026-10-24T23:59:59.999999Z','2026-10-24T23:59:59.999999Z','event_saved','2026-10-24T23:59:59.999999Z'),
(5,NULL,'2026-10-26T00:00Z','event_saved','2026-10-26T00:00Z'),
(6,'2026-10-17T00:00Z','2026-10-17T00:00Z','event_saved','2026-10-27T00:00Z'),
(7,'2026-10-27T00:00Z','2026-10-27T00:00Z','event_saved','2026-10-27T00:00Z'),
(8,'2026-10-31T23:59:59.999999Z',NULL,NULL,NULL),
(9,'2026-10-17T23:59:59.999999Z','2026-10-17T23:59:59.999999Z','event_saved','2026-10-17T23:59:59.999999Z');
INSERT INTO artist_profile(artist_party_id,created_at) VALUES
(1,'2026-10-25T00:00Z'),(2,'2026-11-01T00:00Z'),(3,'2026-10-18T00:00Z'),(4,'2026-10-24T23:59:59.999999Z'),(8,'2026-10-31T23:59:59.999999Z'),(9,'2026-10-17T23:59:59.999999Z');
CREATE ROLE tdf_weekly_readonly LOGIN NOINHERIT NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION;
REVOKE CREATE ON SCHEMA public FROM PUBLIC;
GRANT CONNECT ON DATABASE postgres TO tdf_weekly_readonly;
GRANT USAGE ON SCHEMA public TO tdf_weekly_readonly;
GRANT SELECT ON public.user_onboarding_progress,public.artist_profile TO tdf_weekly_readonly;
