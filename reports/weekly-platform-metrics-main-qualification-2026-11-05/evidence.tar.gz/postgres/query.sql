BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout = '15s';
SET LOCAL lock_timeout = '2s';
SET LOCAL search_path = pg_catalog, public;
WITH windows AS (
  SELECT 'current' AS period, TIMESTAMPTZ '2026-10-25T00:00:00+00:00' AS start_at, TIMESTAMPTZ '2026-11-01T00:00:00+00:00' AS end_at
  UNION ALL SELECT 'previous', TIMESTAMPTZ '2026-10-18T00:00:00+00:00', TIMESTAMPTZ '2026-10-25T00:00:00+00:00'
), counts AS (
  SELECT period, jsonb_build_object(
    'recorded_signups', (SELECT count(*) FROM public.user_onboarding_progress p
      WHERE p.signup_completed_at >= start_at AND p.signup_completed_at < end_at),
    'recorded_first_values', (SELECT count(*) FROM public.user_onboarding_progress p
      WHERE p.first_value_completed_at >= start_at AND p.first_value_completed_at < end_at
        AND p.signup_completed_at IS NOT NULL AND p.first_value IS NOT NULL),
    'artist_profiles_all_origins', (SELECT count(*) FROM public.artist_profile a
      WHERE a.created_at >= start_at AND a.created_at < end_at)
  ) AS values FROM windows
)
SELECT jsonb_build_object('schema_version', 1, 'cutoff_utc', '2026-11-01T00:00:00+00:00',
  'collected_at', CURRENT_TIMESTAMP, 'source', 'postgresql-read-only-aggregate',
  'periods', (SELECT jsonb_object_agg(period, values) FROM counts));
COMMIT;
