from pathlib import Path
import os,subprocess,json,shutil,re,hashlib
w=Path('/private/tmp/tdf-event-finance-browser-precision-fix-20261030');o=Path('/private/tmp/tdf-event-finance-browser-precision-qualification-20261030');base=Path('/private/tmp/tdf-browser-precision-controls-20261030');cache=Path('/private/tmp/tdf-correctness-cycle-20261028');assert not base.exists();base.mkdir()
e={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','LANG','LC_ALL']};e.update(PATH='/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin',NODE_OPTIONS='--experimental-vm-modules')
files=['src/utils/eventFinanceMoney.ts','src/utils/eventFinanceCsv.ts','src/api/socialEvents.ts'];hashes={p:hashlib.sha256((w/'tdf-hq-ui'/p).read_bytes()).hexdigest() for p in files};results=[]
for variant in ['unchecked-api','unchecked-csv','floating-money','restored']:
 v=base/variant;v.mkdir();ui=v/'tdf-hq-ui';shutil.copytree(w/'tdf-hq-ui',ui,ignore=shutil.ignore_patterns('node_modules','dist','.git'))
 shutil.copy2(w/'package.json',v/'package.json');shutil.copy2(w/'package-lock.json',v/'package-lock.json')
 if variant=='unchecked-api':
  p=ui/'src/api/socialEvents.ts';s=p.read_text();s=s.replace("import { assertSafeEventFinanceMoney } from '../utils/eventFinanceMoney';",'const assertSafeEventFinanceMoney = <T extends object>(value: T): T => value;');p.write_text(s)
 elif variant=='unchecked-csv':
  p=ui/'src/utils/eventFinanceCsv.ts';s=p.read_text();s=s.replace("import { assertSafeEventFinanceMoney } from './eventFinanceMoney';\n",'');s=s.replace('  if (financeSummary) assertSafeEventFinanceMoney(financeSummary);\n  budgetLines.forEach(assertSafeEventFinanceMoney);\n  financeEntries.forEach(assertSafeEventFinanceMoney);\n','');p.write_text(s)
 elif variant=='floating-money':
  p=ui/'src/utils/eventFinanceMoney.ts';s=p.read_text();a=s.index('  const locale =');s=s[:a]+'''  return new Intl.NumberFormat(resolveRuntimeFormatOptions().locale, {
    style: 'currency', currency: (currency ?? resolveRuntimeCurrency()).toUpperCase(),
  }).format(amountCents / 100);
};
''';p.write_text(s)
 made=[]
 try:
  for name in ['node_modules','tdf-hq-ui/node_modules']:
   p,t=v/name,cache/name;p.symlink_to(t,target_is_directory=True);made.append((p,t))
  with (o/('control-'+variant+'.log')).open('w') as log:r=subprocess.run(['npm','test','--','--runTestsByPath','src/utils/eventFinanceMoney.test.ts','src/utils/eventFinanceCsv.test.ts','src/api/socialEvents.test.ts'],cwd=ui,env=e,stdout=log,stderr=subprocess.STDOUT,timeout=240)
 finally:
  for p,t in reversed(made):assert p.is_symlink() and p.resolve()==t.resolve();p.unlink()
 text=(o/('control-'+variant+'.log')).read_text();m=re.findall(r'Tests:\s+(?:(\d+) failed, )?(\d+) passed, (\d+) total',text);assert m and 'TS230' not in text and 'Test suite failed to run' not in text,text[-1500:]
 failed,passed,total=m[-1];row={'variant':variant,'actualExit':r.returncode,'failed':int(failed or 0),'passed':int(passed),'total':int(total),'isolatedCopy':str(v),'aliasesRemoved':True};results.append(row);print(json.dumps(row),flush=True)
 assert (r.returncode==0 and not row['failed']) if variant=='restored' else (r.returncode!=0 and row['failed']>0)
assert all(hashlib.sha256((w/'tdf-hq-ui'/p).read_bytes()).hexdigest()==h for p,h in hashes.items())
(o/'source-controls.json').write_text(json.dumps({'originalSourceInputsSha256':hashes,'actualResults':results,'qualifiedCheckoutNeverMutated':True,'scope':'Actual independent API, cached CSV admission and floating-division faults; finite Jest assertions, not a full proof.'},indent=2)+'\n')
