import { formatEventMoney as formatMoney } from '../utils/eventFinanceMoney';
import { buildEventFinanceCsvRows } from '../utils/eventFinanceCsv';
import { useEffect, useMemo, useState } from 'react';
import { useTicketFunnel } from '../analytics/useTicketFunnel';
import { useMutation, useQuery, useQueryClient, useQueries } from '@tanstack/react-query';
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Divider,
  Grid,
  MenuItem,
  Stack,
  TextField,
  Typography,
} from '@mui/material';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import AddIcon from '@mui/icons-material/Add';
import PersonAddAltIcon from '@mui/icons-material/PersonAddAlt';
import RefreshIcon from '@mui/icons-material/Refresh';
import ConfirmationNumberIcon from '@mui/icons-material/ConfirmationNumber';
import SellIcon from '@mui/icons-material/Sell';
import QrCodeScannerIcon from '@mui/icons-material/QrCodeScanner';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import { DateCalendar } from '@mui/x-date-pickers/DateCalendar';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterLuxon } from '@mui/x-date-pickers/AdapterLuxon';
import { useDocumentTitle } from '../hooks/useDocumentTitle';
import { DateTime } from 'luxon';
import { Link as RouterLink } from 'react-router-dom';
import {
  SocialEventsAPI,
  type SocialEventDTO,
  type SocialEventBudgetLineDTO,
  type SocialEventFinanceEntryDTO,
  type SocialEventFinanceSummaryDTO,
  type SocialInvitationDTO,
  type SocialTicketOrderDTO,
  type SocialTicketTierDTO,
} from '../api/socialEvents';
import { ContractsAPI } from '../api/contracts';
import { Catalogs } from '../api/catalogs';
import { useSession } from '../session/SessionContext';
import { useLocalePreferences } from '../contexts/LocalePreferencesContext';
import { parseUnsignedSafeInt } from '../utils/ids';
import {
  getSocialEventCardActionUiState,
  getSocialEventsCreateUiState,
  getSocialEventsFinanceSummaryUiState,
  getSocialEventsOverviewUiState,
  removeDeletedSocialEventQueries,
} from './socialEventsPageState';
import { StripeCheckoutModal } from '../components/StripeCheckoutModal';
import { UserSelector } from '../components/party-selector/PartySelector';
import type { PartySelectorOption } from '../api/partySelector';
import { formatDateForUser, resolveRuntimeCurrency } from '../utils/formatters';
import { hasStrictAdminAccess } from '../utils/accessControl';
import EventRsvpControls from '../components/events/EventRsvpControls';
import EventManualPaymentsPanel from '../components/events/EventManualPaymentsPanel';
import EventTaxDocumentsPanel from '../components/events/EventTaxDocumentsPanel';
import { RefundManagementPanel } from '../components/RefundManagementPanel';

interface InvitationState {
  party: PartySelectorOption | null;
  message: string;
}

interface TicketPurchaseState {
  tierId: string;
}

interface TicketCheckoutState {
  eventId: string;
  eventTitle: string;
  tier: SocialTicketTierDTO;
}

interface PendingEventDeletion {
  eventId: string;
  eventTitle: string;
}

interface TicketTierFormState {
  code: string;
  name: string;
  price: string;
  quantity: string;
  currency: string;
}

interface BudgetLineFormState {
  code: string;
  name: string;
  type: 'income' | 'expense';
  category: string;
  plannedCents: string;
  notes: string;
}

interface FinanceEntryFormState {
  budgetLineId: string;
  direction: 'income' | 'expense';
  source: string;
  category: string;
  concept: string;
  amountCents: string;
  currency: string;
  status: 'draft' | 'posted' | 'pending' | 'void';
  externalRef: string;
  notes: string;
  occurredAt: string;
}

interface ContractDraftState {
  kind: string;
  counterparty: string;
  concept: string;
  amountCents: string;
  currency: string;
  status: 'draft' | 'pending' | 'posted';
  notes: string;
}

const BUDGET_CATEGORY_OPTIONS = [
  'tickets',
  'sponsorship',
  'talent',
  'production',
  'marketing',
  'operations',
  'logistics',
  'permits',
  'security',
  'hospitality',
  'procurement',
  'contracting',
  'assets',
  'liabilities',
  'general',
] as const;

const FINANCE_SOURCE_OPTIONS: {
  value: string;
  label: string;
  direction: 'income' | 'expense';
  category: string;
}[] = [
  { value: 'ticket_sale', label: 'Venta de tickets', direction: 'income', category: 'tickets' },
  { value: 'ticket_refund', label: 'Reembolso de tickets', direction: 'expense', category: 'tickets' },
  { value: 'sponsorship', label: 'Patrocinio', direction: 'income', category: 'sponsorship' },
  { value: 'contract_commitment', label: 'Contrato (compromiso)', direction: 'expense', category: 'contracting' },
  { value: 'contract_payment', label: 'Contrato (pago)', direction: 'expense', category: 'contracting' },
  { value: 'purchase_order', label: 'Compra (orden)', direction: 'expense', category: 'procurement' },
  { value: 'purchase_payment', label: 'Compra (pago)', direction: 'expense', category: 'procurement' },
  { value: 'asset_purchase', label: 'Activo (adquisición)', direction: 'expense', category: 'assets' },
  { value: 'liability_loan', label: 'Pasivo (financiamiento)', direction: 'income', category: 'liabilities' },
  { value: 'liability_payment', label: 'Pasivo (pago)', direction: 'expense', category: 'liabilities' },
  { value: 'accounts_receivable', label: 'Cuenta por cobrar', direction: 'income', category: 'operations' },
  { value: 'accounts_receivable_collection', label: 'Cobro de CxC', direction: 'income', category: 'operations' },
  { value: 'vendor_payment', label: 'Pago a proveedor', direction: 'expense', category: 'operations' },
  { value: 'merchandise', label: 'Merchandising', direction: 'income', category: 'operations' },
  { value: 'operations', label: 'Operación', direction: 'expense', category: 'operations' },
  { value: 'manual', label: 'Manual', direction: 'expense', category: 'general' },
  { value: 'other', label: 'Otro', direction: 'expense', category: 'general' },
];

const FINANCE_STATUS_OPTIONS: {
  value: FinanceEntryFormState['status'];
  label: string;
}[] = [
  { value: 'posted', label: 'Publicado' },
  { value: 'pending', label: 'Pendiente' },
  { value: 'draft', label: 'Borrador' },
  { value: 'void', label: 'Anulado' },
];

const PROJECT_BUDGET_TEMPLATE: {
  code: string;
  name: string;
  type: 'income' | 'expense';
  category: string;
}[] = [
  { code: 'INC-TICKETS', name: 'Venta de tickets', type: 'income', category: 'tickets' },
  { code: 'INC-SPONSORS', name: 'Patrocinios', type: 'income', category: 'sponsorship' },
  { code: 'EXP-TALENT', name: 'Contratación de talento', type: 'expense', category: 'contracting' },
  { code: 'EXP-PROD', name: 'Producción técnica', type: 'expense', category: 'production' },
  { code: 'EXP-MKT', name: 'Marketing y pauta', type: 'expense', category: 'marketing' },
  { code: 'EXP-LOG', name: 'Logística y operación', type: 'expense', category: 'logistics' },
  { code: 'EXP-PERMITS', name: 'Permisos y legales', type: 'expense', category: 'operations' },
  { code: 'EXP-SECURITY', name: 'Seguridad', type: 'expense', category: 'security' },
];

const formatDate = (iso: string) => formatDateForUser(iso, {
  weekday: 'short',
  day: 'numeric',
  month: 'short',
  hour: '2-digit',
  minute: '2-digit',
});


const ticketCheckoutTotal = (faceValueCents: number) => {
  const platformFee = Math.max(0, Math.floor((faceValueCents * 400) / 10000));
  return faceValueCents + Math.ceil(platformFee / 2);
};

const formatPercent = (value?: number | null) => {
  if (typeof value !== 'number' || Number.isNaN(value)) return 'n/a';
  return `${value.toFixed(1)}%`;
};

const tierAvailability = (tier: SocialTicketTierDTO) =>
  Math.max(0, tier.ticketTierQuantityTotal - tier.ticketTierQuantitySold);

const toDateTimeInputValue = (iso?: string | null) => {
  if (!iso) return DateTime.local().toFormat("yyyy-LL-dd'T'HH:mm");
  const dt = DateTime.fromISO(iso);
  if (!dt.isValid) return DateTime.local().toFormat("yyyy-LL-dd'T'HH:mm");
  return dt.toLocal().toFormat("yyyy-LL-dd'T'HH:mm");
};

const toUtcIso = (dateTimeInput: string) => {
  const dt = DateTime.fromISO(dateTimeInput, { zone: 'local' });
  return dt.isValid ? (dt.toUTC().toISO() ?? new Date().toISOString()) : new Date().toISOString();
};

const parseOptionalUnsignedInt = (value: string): number | null => {
  const trimmed = value.trim();
  if (!trimmed) return null;
  return parseUnsignedSafeInt(trimmed);
};

const dateKeyFromIso = (iso: string) => DateTime.fromISO(iso).toISODate() ?? '';

const csvEscape = (value: string | number | boolean | null | undefined) =>
  `"${String(value ?? '').replace(/"/g, '""')}"`;

const downloadCsvFile = (filename: string, rows: (string | number | boolean | null | undefined)[][]) => {
  const csv = rows.map((row) => row.map(csvEscape).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
};


export default function SocialEventsPage() {
  const trackFunnel = useTicketFunnel();
  useDocumentTitle('Social / Eventos');
  const qc = useQueryClient();
  const { session } = useSession();
  const { locale } = useLocalePreferences();
  const preferredCurrency = resolveRuntimeCurrency();
  const [city, setCity] = useState('');
  const [eventTypeFilter, setEventTypeFilter] = useState('');
  const [eventWorkflowStateFilter, setEventWorkflowStateFilter] = useState('');
  const [feedback, setFeedback] = useState<{ kind: 'success' | 'error'; message: string } | null>(null);
  const [invites, setInvites] = useState<Record<string, InvitationState>>({});
  const [ticketPurchases, setTicketPurchases] = useState<Record<string, TicketPurchaseState>>({});
  const [ticketCheckout, setTicketCheckout] = useState<TicketCheckoutState | null>(null);
  const [ticketTierForms, setTicketTierForms] = useState<Record<string, TicketTierFormState>>({});
  const [budgetLineForms, setBudgetLineForms] = useState<Record<string, BudgetLineFormState>>({});
  const [financeEntryForms, setFinanceEntryForms] = useState<Record<string, FinanceEntryFormState>>({});
  const [contractDrafts, setContractDrafts] = useState<Record<string, ContractDraftState>>({});
  const [checkInCodes, setCheckInCodes] = useState<Record<string, string>>({});
  const [eventPosterFiles, setEventPosterFiles] = useState<Record<string, File | null>>({});
  const [pendingEventDeletion, setPendingEventDeletion] = useState<PendingEventDeletion | null>(null);
  const [selectedCalendarDate, setSelectedCalendarDate] = useState<string>(() => DateTime.local().toISODate() ?? '');
  const startAfter = useMemo(() => new Date().toISOString(), []);
  const sessionPartyId = session?.partyId != null ? String(session.partyId) : null;
  const hasSession = Boolean(sessionPartyId);
  const hasAdminAccess = hasStrictAdminAccess(session?.roles, session?.modules);
  const eventsQueryKey = ['social-events', city, eventTypeFilter, eventWorkflowStateFilter, startAfter] as const;

  const eventsQuery = useQuery({
    queryKey: eventsQueryKey,
    queryFn: () =>
      SocialEventsAPI.listEvents({
        city: city.trim() || undefined,
        eventTypeId: eventTypeFilter || undefined,
        workflowStateId: eventWorkflowStateFilter || undefined,
        startAfter,
      }),
    // This page already exposes an explicit refresh action. Retrying a failed
    // request with the app-wide defaults (up to three additional 30s requests)
    // leaves the page looking stuck for well over a minute when the API is
    // restarting or the user's connection briefly drops.
    retry: false,
  });

  const venuesQuery = useQuery({
    queryKey: ['social-venues', city],
    queryFn: () => SocialEventsAPI.listVenues({ city: city.trim() || undefined }),
    retry: false,
  });
  const eventTypesQuery = useQuery({
    queryKey: ['catalog', 'event-types', 'social-events', locale],
    queryFn: () => Catalogs.listItems('event-types', {
      locale,
      page: 1,
      pageSize: 500,
      includeInactive: true,
    }),
    staleTime: 5 * 60 * 1000,
  });
  const eventWorkflowStatesQuery = useQuery({
    queryKey: ['catalog', 'workflow-states', 'social-event-lifecycle', locale],
    queryFn: () => Catalogs.getPublicWorkflowStates('social-event-lifecycle', locale),
    staleTime: 5 * 60 * 1000,
  });
  const eventTypeById = useMemo(
    () => new Map((eventTypesQuery.data?.items ?? []).map((item) => [item.id, item])),
    [eventTypesQuery.data?.items],
  );
  const selectableEventTypes = useMemo(
    () => (eventTypesQuery.data?.items ?? []).filter(
      (item) => item.active && item.workflowState === 'published' && !item.deprecatedAt,
    ),
    [eventTypesQuery.data?.items],
  );

  const venueById = useMemo(() => {
    const map = new Map<string, string>();
    (venuesQuery.data ?? []).forEach((v) => {
      if (v.venueId) map.set(v.venueId, v.venueName);
    });
    return map;
  }, [venuesQuery.data]);

  const events = useMemo(() => eventsQuery.data ?? [], [eventsQuery.data]);
  const eventFiltersActive = city.trim().length > 0 || eventTypeFilter !== '' || eventWorkflowStateFilter !== '';
  const eventOverviewUiState = getSocialEventsOverviewUiState({
    canCreateEvent: hasSession,
    eventCount: events.length,
    filtersActive: eventFiltersActive,
  });
  const eventCreateUiState = getSocialEventsCreateUiState({
    canCreateEvent: hasSession,
    eventCount: events.length,
    filtersActive: eventFiltersActive,
    listLoadSucceeded: eventsQuery.isSuccess,
  });
  const showRefreshAction = eventOverviewUiState.showRefreshAction || eventsQuery.isError || venuesQuery.isError;

  const deleteEventMutation = useMutation({
    mutationFn: ({ eventId }: PendingEventDeletion) => SocialEventsAPI.deleteEvent(eventId),
    onSuccess: (_response, deletedEvent) => {
      qc.setQueryData<SocialEventDTO[]>(eventsQueryKey, (current) =>
        current?.filter((event) => String(event.eventId) !== deletedEvent.eventId),
      );
      removeDeletedSocialEventQueries(qc, deletedEvent.eventId);
      setPendingEventDeletion(null);
      setFeedback({ kind: 'success', message: `Evento eliminado: ${deletedEvent.eventTitle}.` });
      void qc.invalidateQueries({ queryKey: ['social-events'] });
      void qc.invalidateQueries({ queryKey: ['public-upcoming-events'] });
    },
  });

  const eventsByDate = useMemo(() => {
    const grouped = new Map<string, SocialEventDTO[]>();
    events.forEach((event) => {
      const key = dateKeyFromIso(event.eventStart);
      if (!key) return;
      if (!grouped.has(key)) grouped.set(key, []);
      grouped.get(key)?.push(event);
    });
    grouped.forEach((dayEvents) => {
      dayEvents.sort((a, b) => a.eventStart.localeCompare(b.eventStart));
    });
    return grouped;
  }, [events]);

  const calendarDateOptions = useMemo(
    () => Array.from(eventsByDate.keys()).sort((a, b) => a.localeCompare(b)),
    [eventsByDate],
  );

  const selectedCalendarEvents = useMemo(
    () => (selectedCalendarDate ? eventsByDate.get(selectedCalendarDate) ?? [] : []),
    [eventsByDate, selectedCalendarDate],
  );

  const selectedCalendarValue = useMemo(() => {
    const parsed = DateTime.fromISO(selectedCalendarDate);
    return parsed.isValid ? parsed : DateTime.local();
  }, [selectedCalendarDate]);

  const selectedCalendarLabel = useMemo(() => {
    const parsed = DateTime.fromISO(selectedCalendarDate);
    if (!parsed.isValid) return 'Selecciona una fecha';
    return parsed.setLocale('es').toFormat('cccc d LLL yyyy');
  }, [selectedCalendarDate]);

  useEffect(() => {
    if (selectedCalendarDate) return;
    if (calendarDateOptions.length > 0) {
      setSelectedCalendarDate(calendarDateOptions[0] ?? '');
      return;
    }
    setSelectedCalendarDate(DateTime.local().toISODate() ?? '');
  }, [calendarDateOptions, selectedCalendarDate]);

  const invitationQueries = useQueries({
    queries:
      hasSession && events.length > 0
        ? events.map((ev) => ({
            queryKey: ['social-invitations', ev.eventId],
            queryFn: () => SocialEventsAPI.listInvitations(String(ev.eventId)),
            enabled: Boolean(ev.eventId),
            select: (list: SocialInvitationDTO[]) =>
              list?.filter((inv) => String(inv.invitationToPartyId) === String(sessionPartyId ?? '')) ?? [],
          }))
        : [],
  });

  const ticketTierQueries = useQueries({
    queries:
      events.length > 0
        ? events.map((ev) => ({
            queryKey: ['social-ticket-tiers', ev.eventId],
            queryFn: () => SocialEventsAPI.listTicketTiers(String(ev.eventId)),
            enabled: Boolean(ev.eventId),
          }))
        : [],
  });

  const ticketOrderQueries = useQueries({
    queries:
      hasSession && events.length > 0
        ? events.map((ev) => {
            const organizer =
              sessionPartyId != null &&
              ev.eventOrganizerPartyId != null &&
              String(ev.eventOrganizerPartyId) === sessionPartyId;
            return {
              queryKey: ['social-ticket-orders', ev.eventId, organizer ? 'organizer' : sessionPartyId],
              queryFn: () =>
                SocialEventsAPI.listTicketOrders(String(ev.eventId), organizer ? undefined : { buyerPartyId: sessionPartyId ?? undefined }),
              enabled: Boolean(ev.eventId),
            };
          })
        : [],
  });

  const budgetLineQueries = useQueries({
    queries:
      hasSession && events.length > 0
        ? events.map((ev) => {
            const organizer =
              sessionPartyId != null &&
              ev.eventOrganizerPartyId != null &&
              String(ev.eventOrganizerPartyId) === sessionPartyId;
            return {
              queryKey: ['social-budget-lines', ev.eventId],
              queryFn: () => SocialEventsAPI.listBudgetLines(String(ev.eventId)),
              enabled: organizer && Boolean(ev.eventId),
            };
          })
        : [],
  });

  const financeEntryQueries = useQueries({
    queries:
      hasSession && events.length > 0
        ? events.map((ev) => {
            const organizer =
              sessionPartyId != null &&
              ev.eventOrganizerPartyId != null &&
              String(ev.eventOrganizerPartyId) === sessionPartyId;
            return {
              queryKey: ['social-finance-entries', ev.eventId],
              queryFn: () => SocialEventsAPI.listFinanceEntries(String(ev.eventId)),
              enabled: organizer && Boolean(ev.eventId),
            };
          })
        : [],
  });

  const financeSummaryQueries = useQueries({
    queries:
      hasSession && events.length > 0
        ? events.map((ev) => {
            const organizer =
              sessionPartyId != null &&
              ev.eventOrganizerPartyId != null &&
              String(ev.eventOrganizerPartyId) === sessionPartyId;
            return {
              queryKey: ['social-finance-summary', ev.eventId],
              queryFn: () => SocialEventsAPI.getFinanceSummary(String(ev.eventId)),
              enabled: organizer && Boolean(ev.eventId),
            };
          })
        : [],
  });

  const inviteMutation = useMutation({
    mutationFn: ({ eventId }: { eventId: string }) => {
      if (!sessionPartyId) throw new Error('Inicia sesión para enviar invitaciones.');
      const draft = invites[eventId] ?? { party: null, message: '' };
      const toId = draft.party?.partyId;
      if (!toId) throw new Error('Selecciona una persona para invitar.');
      return SocialEventsAPI.sendInvitation(eventId, {
        invitationToPartyId: String(toId),
        invitationMessage: draft.message.trim() || null,
      });
    },
    onSuccess: (_resp, { eventId }) => {
      setInvites((prev) => ({ ...prev, [eventId]: { party: null, message: '' } }));
      void qc.invalidateQueries({ queryKey: ['social-invitations', eventId] });
      setFeedback({ kind: 'success', message: 'Invitación enviada.' });
    },
    onError: (err: Error) => setFeedback({ kind: 'error', message: err.message }),
  });

  const respondInvitationMutation = useMutation({
    mutationFn: ({ eventId, invitationId, status }: { eventId: string; invitationId: string; status: string }) => {
      if (!sessionPartyId) throw new Error('Inicia sesión para responder invitaciones.');
      return SocialEventsAPI.respondInvitation(eventId, invitationId, status);
    },
    onMutate: async ({ eventId, invitationId, status }) => {
      await qc.cancelQueries({ queryKey: ['social-invitations', eventId] });
      const previousInvitations = qc.getQueryData<SocialInvitationDTO[]>(['social-invitations', eventId]);
      qc.setQueryData<SocialInvitationDTO[]>(['social-invitations', eventId], (old) =>
        (old ?? []).map((inv) =>
          inv.invitationId === invitationId ? { ...inv, invitationStatus: status } : inv,
        ),
      );
      return { previousInvitations };
    },
    onSuccess: () => {
      setFeedback({ kind: 'success', message: 'Respuesta enviada.' });
    },
    onError: (err: Error, _vars, context) => {
      const eventId = (_vars as { eventId: string })?.eventId;
      if (context?.previousInvitations !== undefined && eventId) {
        qc.setQueryData(['social-invitations', eventId], context.previousInvitations);
      }
      setFeedback({ kind: 'error', message: err.message });
    },
    onSettled: (_data, _err, { eventId }) => {
      void qc.invalidateQueries({ queryKey: ['social-invitations', eventId] });
    },
  });

  const createTierMutation = useMutation({
    mutationFn: ({ eventId }: { eventId: string }) => {
      const draft = ticketTierForms[eventId] ?? {
        code: '',
        name: '',
        price: '',
        quantity: '',
        currency: preferredCurrency,
      };
      const priceCents = parseOptionalUnsignedInt(draft.price);
      const quantity = parseOptionalUnsignedInt(draft.quantity);
      if (!draft.name.trim()) throw new Error('Nombre del ticket requerido.');
      if (priceCents === null) throw new Error('Precio inválido (usa centavos).');
      if (quantity === null || quantity <= 0) throw new Error('Cantidad inválida.');
      const payload: SocialTicketTierDTO = {
        ticketTierCode: draft.code.trim() || draft.name,
        ticketTierName: draft.name.trim(),
        ticketTierDescription: null,
        ticketTierPriceCents: priceCents,
        ticketTierCurrency: draft.currency.trim().toUpperCase() || preferredCurrency,
        ticketTierQuantityTotal: quantity,
        ticketTierQuantitySold: 0,
        ticketTierSalesStart: null,
        ticketTierSalesEnd: null,
        ticketTierActive: true,
        ticketTierPosition: null,
      };
      return SocialEventsAPI.createTicketTier(eventId, payload);
    },
    onSuccess: (_resp, { eventId }) => {
      setTicketTierForms((prev) => ({
        ...prev,
        [eventId]: { code: '', name: '', price: '', quantity: '', currency: preferredCurrency },
      }));
      void qc.invalidateQueries({ queryKey: ['social-ticket-tiers', eventId] });
      setFeedback({ kind: 'success', message: 'Tipo de ticket creado.' });
    },
    onError: (err: Error) => setFeedback({ kind: 'error', message: err.message }),
  });

  const updateOrderStatusMutation = useMutation({
    mutationFn: ({ eventId, orderId, status }: { eventId: string; orderId: string; status: 'cancelled' | 'refunded' }) =>
      SocialEventsAPI.updateTicketOrderStatus(eventId, orderId, status),
    onSuccess: (_resp, { eventId }) => {
      void qc.invalidateQueries({ queryKey: ['social-ticket-orders', eventId] });
      void qc.invalidateQueries({ queryKey: ['social-ticket-tiers', eventId] });
      setFeedback({ kind: 'success', message: 'Estado de orden actualizado.' });
    },
    onError: (err: Error) => setFeedback({ kind: 'error', message: err.message }),
  });

  const checkInMutation = useMutation({
    mutationFn: ({ eventId }: { eventId: string }) => {
      const code = (checkInCodes[eventId] ?? '').trim();
      if (!code) throw new Error('Ingresa el código del ticket para check-in.');
      return SocialEventsAPI.checkInTicket(eventId, { ticketCheckInTicketCode: code });
    },
    onSuccess: (_resp, { eventId }) => {
      setCheckInCodes((prev) => ({ ...prev, [eventId]: '' }));
      void qc.invalidateQueries({ queryKey: ['social-ticket-orders', eventId] });
      if (_resp.ticketId && _resp.ticketStatus === 'checked_in' && _resp.ticketCheckedInAt) {
        trackFunnel('check_in', { eventId: Number(eventId), quantity: 1, privateScope: `ticket:${_resp.ticketId}` });
      }
      setFeedback({ kind: 'success', message: 'Ticket marcado como check-in.' });
    },
    onError: (err: Error) => setFeedback({ kind: 'error', message: err.message }),
  });

  const uploadEventImageMutation = useMutation({
    mutationFn: ({ eventId, file }: { eventId: string; file: File }) =>
      SocialEventsAPI.uploadEventImage(eventId, file, file.name),
    onSuccess: (_resp, { eventId }) => {
      setEventPosterFiles((prev) => ({ ...prev, [eventId]: null }));
      void qc.invalidateQueries({ queryKey: ['social-events'] });
      setFeedback({ kind: 'success', message: 'Afiche subido y asociado al evento.' });
    },
    onError: (err: Error) => setFeedback({ kind: 'error', message: err.message }),
  });

  const createBudgetLineMutation = useMutation({
    mutationFn: ({ eventId }: { eventId: string }) => {
      const draft = budgetLineForms[eventId] ?? {
        code: '',
        name: '',
        type: 'expense',
        category: 'general',
        plannedCents: '',
        notes: '',
      };
      const plannedCents = parseOptionalUnsignedInt(draft.plannedCents);
      if (!draft.name.trim()) throw new Error('Nombre de línea presupuestaria requerido.');
      if (plannedCents === null) throw new Error('Presupuesto inválido (usa centavos).');
      const payload: SocialEventBudgetLineDTO = {
        eblCode: draft.code.trim() || draft.name,
        eblName: draft.name.trim(),
        eblType: draft.type,
        eblCategory: draft.category.trim() || 'general',
        eblPlannedCents: plannedCents,
        eblActualCents: null,
        eblNotes: draft.notes.trim() || null,
      };
      return SocialEventsAPI.createBudgetLine(eventId, payload);
    },
    onSuccess: (_line, { eventId }) => {
      setBudgetLineForms((prev) => ({
        ...prev,
        [eventId]: { code: '', name: '', type: 'expense', category: 'general', plannedCents: '', notes: '' },
      }));
      void qc.invalidateQueries({ queryKey: ['social-budget-lines', eventId] });
      void qc.invalidateQueries({ queryKey: ['social-finance-summary', eventId] });
      setFeedback({ kind: 'success', message: 'Línea presupuestaria creada.' });
    },
    onError: (err: Error) => setFeedback({ kind: 'error', message: err.message }),
  });

  const seedBudgetTemplateMutation = useMutation({
    mutationFn: async ({ eventId, existingLines }: { eventId: string; existingLines: SocialEventBudgetLineDTO[] }) => {
      const existingCodes = new Set(
        existingLines.map((line) => String(line.eblCode ?? '').trim().toUpperCase()).filter(Boolean),
      );
      const missingLines = PROJECT_BUDGET_TEMPLATE.filter((line) => !existingCodes.has(line.code));
      for (const line of missingLines) {
        await SocialEventsAPI.createBudgetLine(eventId, {
          eblCode: line.code,
          eblName: line.name,
          eblType: line.type,
          eblCategory: line.category,
          eblPlannedCents: 0,
          eblActualCents: null,
          eblNotes: 'Creado automáticamente desde plantilla PM.',
        });
      }
      return missingLines.length;
    },
    onSuccess: (createdCount, { eventId }) => {
      void qc.invalidateQueries({ queryKey: ['social-budget-lines', eventId] });
      void qc.invalidateQueries({ queryKey: ['social-finance-summary', eventId] });
      setFeedback({
        kind: 'success',
        message:
          createdCount > 0
            ? `Plantilla PM aplicada (${createdCount} líneas nuevas).`
            : 'La plantilla PM ya estaba aplicada.',
      });
    },
    onError: (err: Error) => setFeedback({ kind: 'error', message: err.message }),
  });

  const createContractCommitmentMutation = useMutation({
    mutationFn: async ({ eventId }: { eventId: string }) => {
      const draft = contractDrafts[eventId] ?? {
        kind: 'event_vendor_contract',
        counterparty: '',
        concept: '',
        amountCents: '',
        currency: preferredCurrency,
        status: 'pending' as const,
        notes: '',
      };
      const amountCents = parseOptionalUnsignedInt(draft.amountCents);
      if (!draft.concept.trim()) throw new Error('Concepto de contrato requerido.');
      if (amountCents === null || amountCents <= 0) throw new Error('Monto de contrato inválido (usa centavos).');
      const currency = draft.currency.trim().toUpperCase() || preferredCurrency;
      const contractResponse = await ContractsAPI.create({
        kind: draft.kind.trim() || 'event_vendor_contract',
        eventId,
        counterparty: draft.counterparty.trim() || null,
        concept: draft.concept.trim(),
        amountCents,
        currency,
        notes: draft.notes.trim() || null,
        metadata: {
          module: 'social_events',
          flow: 'project_contracting',
          createdAt: new Date().toISOString(),
        },
      });
      await SocialEventsAPI.createFinanceEntry(eventId, {
        efeBudgetLineId: null,
        efeDirection: 'expense',
        efeSource: 'contract_commitment',
        efeCategory: 'contracting',
        efeConcept: draft.concept.trim(),
        efeAmountCents: amountCents,
        efeCurrency: currency,
        efeStatus: draft.status,
        efeExternalRef: contractResponse.id,
        efeNotes: draft.notes.trim() || null,
        efeOccurredAt: new Date().toISOString(),
      });
      return contractResponse.id;
    },
    onSuccess: (contractId, { eventId }) => {
      setContractDrafts((prev) => ({
        ...prev,
        [eventId]: {
          kind: 'event_vendor_contract',
          counterparty: '',
          concept: '',
          amountCents: '',
          currency: preferredCurrency,
          status: 'pending',
          notes: '',
        },
      }));
      void qc.invalidateQueries({ queryKey: ['social-finance-entries', eventId] });
      void qc.invalidateQueries({ queryKey: ['social-budget-lines', eventId] });
      void qc.invalidateQueries({ queryKey: ['social-finance-summary', eventId] });
      setFeedback({
        kind: 'success',
        message: `Contrato creado y compromiso registrado (ID ${contractId}).`,
      });
    },
    onError: (err: Error) => setFeedback({ kind: 'error', message: err.message }),
  });

  const downloadContractPdfMutation = useMutation({
    mutationFn: ({ contractId }: { contractId: string }) => ContractsAPI.downloadPdf(contractId),
    onSuccess: (blob, { contractId }) => {
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `contrato-${contractId}.pdf`;
      link.click();
      URL.revokeObjectURL(url);
      setFeedback({ kind: 'success', message: `PDF de contrato ${contractId} descargado.` });
    },
    onError: (err: Error) => setFeedback({ kind: 'error', message: err.message }),
  });

  const createFinanceEntryMutation = useMutation({
    mutationFn: ({ eventId }: { eventId: string }) => {
      const draft = financeEntryForms[eventId] ?? {
        budgetLineId: '',
        direction: 'expense',
        source: 'manual',
        category: 'general',
        concept: '',
        amountCents: '',
        currency: preferredCurrency,
        status: 'posted',
        externalRef: '',
        notes: '',
        occurredAt: toDateTimeInputValue(),
      };
      const amountCents = parseOptionalUnsignedInt(draft.amountCents);
      if (!draft.concept.trim()) throw new Error('Concepto contable requerido.');
      if (amountCents === null || amountCents <= 0) throw new Error('Monto inválido (usa centavos).');
      const payload: SocialEventFinanceEntryDTO = {
        efeBudgetLineId: draft.budgetLineId.trim() || null,
        efeDirection: draft.direction,
        efeSource: draft.source.trim() || 'manual',
        efeCategory: draft.category.trim() || 'general',
        efeConcept: draft.concept.trim(),
        efeAmountCents: amountCents,
        efeCurrency: draft.currency.trim().toUpperCase() || preferredCurrency,
        efeStatus: draft.status,
        efeExternalRef: draft.externalRef.trim() || null,
        efeNotes: draft.notes.trim() || null,
        efeOccurredAt: toUtcIso(draft.occurredAt),
      };
      return SocialEventsAPI.createFinanceEntry(eventId, payload);
    },
    onSuccess: (_entry, { eventId }) => {
      setFinanceEntryForms((prev) => ({
        ...prev,
        [eventId]: {
          budgetLineId: '',
          direction: 'expense',
          source: 'manual',
          category: 'general',
          concept: '',
          amountCents: '',
          currency: preferredCurrency,
          status: 'posted',
          externalRef: '',
          notes: '',
          occurredAt: toDateTimeInputValue(),
        },
      }));
      void qc.invalidateQueries({ queryKey: ['social-finance-entries', eventId] });
      void qc.invalidateQueries({ queryKey: ['social-budget-lines', eventId] });
      void qc.invalidateQueries({ queryKey: ['social-finance-summary', eventId] });
      setFeedback({ kind: 'success', message: 'Asiento contable registrado.' });
    },
    onError: (err: Error) => setFeedback({ kind: 'error', message: err.message }),
  });

  const exportEventFinanceCsv = ({
    event,
    budgetLines,
    financeEntries,
    financeSummary,
  }: {
    event: SocialEventDTO;
    budgetLines: SocialEventBudgetLineDTO[];
    financeEntries: SocialEventFinanceEntryDTO[];
    financeSummary: SocialEventFinanceSummaryDTO | null;
  }) => {
    const eventId = event.eventId ? String(event.eventId) : '';
    if (!eventId) return;
    try {
      const rows = buildEventFinanceCsvRows(event, budgetLines, financeEntries, financeSummary);
      const safeTitle = event.eventTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
      const filename = `reporte-financiero-${safeTitle || 'evento'}-${eventId}-${Date.now()}.csv`;
      downloadCsvFile(filename, rows);
      setFeedback({ kind: 'success', message: `Reporte CSV exportado para ${event.eventTitle}.` });
    } catch (error) {
      setFeedback({ kind: 'error', message: error instanceof Error ? error.message : 'No se pudo exportar el reporte financiero.' });
    }
  };

  const renderOrders = (orders: SocialTicketOrderDTO[], eventId: string, isOrganizer: boolean) => {
    if (orders.length === 0) {
      return (
        <Typography variant="body2" color="text.secondary">
          Sin órdenes registradas.
        </Typography>
      );
    }
    return (
      <Stack spacing={1}>
        {orders.map((order) => {
          const oid = order.ticketOrderId ?? '';
          return (
            <Box key={oid || `${eventId}-${order.ticketOrderPurchasedAt}`} sx={{ border: '1px solid', borderColor: 'divider', borderRadius: 2, p: 1.25 }}>
              <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap">
                <Chip size="small" icon={<SellIcon />} label={`${order.ticketOrderQuantity} ticket(s)`} />
                <Chip size="small" label={order.ticketOrderStatusValue} color={order.ticketOrderStatusValue === 'paid' ? 'success' : 'default'} />
                <Typography variant="body2" color="text.secondary">
                  {formatMoney(order.ticketOrderAmountCents, order.ticketOrderCurrency)}
                </Typography>
                {order.ticketOrderBuyerPlatformFeeCents > 0 && (
                  <Typography variant="caption" color="text.secondary">
                    Tarifa TDF: {formatMoney(order.ticketOrderBuyerPlatformFeeCents + order.ticketOrderOrganizerPlatformFeeCents, order.ticketOrderCurrency)}
                  </Typography>
                )}
              </Stack>
              {order.ticketOrderTickets.length > 0 && (
                <Stack direction="row" spacing={0.75} flexWrap="wrap" sx={{ mt: 1 }}>
                  {order.ticketOrderTickets.map((ticket) => (
                    <Chip
                      key={ticket.ticketId ?? ticket.ticketCode}
                      size="small"
                      icon={<ConfirmationNumberIcon />}
                      label={`${ticket.ticketCode} · ${ticket.ticketStatus}`}
                      variant="outlined"
                    />
                  ))}
                </Stack>
              )}
              {isOrganizer && order.ticketOrderStatusValue === 'paid' && oid && (
                <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
                  <Button
                    size="small"
                    variant="outlined"
                    color="warning"
                    onClick={() => updateOrderStatusMutation.mutate({ eventId, orderId: oid, status: 'cancelled' })}
                    disabled={updateOrderStatusMutation.isPending}
                  >
                    Cancelar
                  </Button>
                  <Button
                    size="small"
                    variant="outlined"
                    color="error"
                    onClick={() => updateOrderStatusMutation.mutate({ eventId, orderId: oid, status: 'refunded' })}
                    disabled={updateOrderStatusMutation.isPending}
                  >
                    Reembolsar
                  </Button>
                </Stack>
              )}
            </Box>
          );
        })}
      </Stack>
    );
  };

  return (
    <Box>
      <Stack spacing={2} sx={{ mb: 3 }}>
        <Typography variant="h4" fontWeight={800}>Eventos</Typography>
        <Typography color="text.secondary">
          Descubre eventos, confirma asistencia y gestiona operación completa: tickets, presupuesto y contabilidad por evento.
        </Typography>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} alignItems={{ xs: 'stretch', sm: 'center' }}>
          {eventOverviewUiState.showFilters && (
            <>
              <TextField
                label="Filtrar por ciudad"
                size="small"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                sx={{ minWidth: 220 }}
              />
              <TextField
                select
                label="Tipo"
                size="small"
                value={eventTypeFilter}
                onChange={(e) => setEventTypeFilter(e.target.value)}
                sx={{ minWidth: 150 }}
              >
                <MenuItem value="">Todos</MenuItem>
                {selectableEventTypes.map((item) => (
                  <MenuItem key={item.id} value={item.id}>{item.name}</MenuItem>
                ))}
              </TextField>
              <TextField
                select
                label="Estado"
                size="small"
                value={eventWorkflowStateFilter}
                onChange={(e) => setEventWorkflowStateFilter(e.target.value)}
                sx={{ minWidth: 150 }}
              >
                <MenuItem value="">Todos</MenuItem>
                {(eventWorkflowStatesQuery.data?.states ?? []).map((state) => (
                  <MenuItem key={state.id} value={state.id}>{state.name}</MenuItem>
                ))}
              </TextField>
            </>
          )}
          {showRefreshAction && (
            <Button
              variant="outlined"
              startIcon={<RefreshIcon />}
              onClick={() => {
                void eventsQuery.refetch();
                void venuesQuery.refetch();
              }}
              disabled={eventsQuery.isFetching}
            >
              Refrescar
            </Button>
          )}
          {eventCreateUiState.showCreateToolbarAction && (
            <Button
              component={RouterLink}
              to="/social/eventos/nuevo"
              variant="contained"
              startIcon={<AddIcon />}
            >
              Nuevo evento
            </Button>
          )}
          {!hasSession && eventOverviewUiState.showFilters && (
            <Alert severity="info" sx={{ m: 0, py: 0.5 }}>
              Inicia sesión para RSVP, invitaciones, tickets y gestión financiera.
            </Alert>
          )}
        </Stack>
        {eventCreateUiState.showCreateWelcome && (
          <Card
            variant="outlined"
            sx={{
              borderColor: 'primary.main',
              background: (theme) =>
                `linear-gradient(135deg, ${theme.palette.primary.main}12, transparent 65%)`,
            }}
          >
            <CardContent>
              <Stack
                direction={{ xs: 'column', md: 'row' }}
                spacing={2}
                alignItems={{ md: 'center' }}
                justifyContent="space-between"
              >
                <Box>
                  <Typography variant="h5" fontWeight={800}>
                    Crea el primer evento con tu equipo
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
                    {eventCreateUiState.createWelcomeDescription}
                  </Typography>
                </Box>
                <Button
                  component={RouterLink}
                  to="/social/eventos/nuevo"
                  variant="contained"
                  startIcon={<AddIcon />}
                  sx={{ flexShrink: 0 }}
                >
                  Empezar
                </Button>
              </Stack>
            </CardContent>
          </Card>
        )}
        {!hasSession && (
          <Alert severity="info">Inicia sesión para crear eventos.</Alert>
        )}
        {eventOverviewUiState.showCalendar && (
        <Card variant="outlined">
          <CardContent>
            <Stack spacing={1.5}>
              <Stack direction="row" alignItems="center" spacing={1} justifyContent="space-between">
                <Typography variant="h6" fontWeight={700}>Calendario de eventos</Typography>
                <Chip size="small" label={`${events.length} evento${events.length === 1 ? '' : 's'}`} />
              </Stack>
              <Grid container spacing={2}>
                <Grid item xs={12} md={5}>
                  <LocalizationProvider dateAdapter={AdapterLuxon}>
                    <DateCalendar
                      value={selectedCalendarValue}
                      onChange={(value: DateTime | null) => {
                        const nextDate = value?.toISODate();
                        if (!nextDate) return;
                        setSelectedCalendarDate(nextDate);
                      }}
                    />
                  </LocalizationProvider>
                </Grid>
                <Grid item xs={12} md={7}>
                  <Stack spacing={1}>
                    <Typography variant="subtitle2" fontWeight={700}>
                      {selectedCalendarLabel}
                    </Typography>
                    {selectedCalendarEvents.length === 0 ? (
                      <Typography variant="body2" color="text.secondary">
                        Sin eventos programados para esta fecha.
                      </Typography>
                    ) : (
                      <Stack spacing={1}>
                        {selectedCalendarEvents.map((event) => (
                          <Box
                            key={event.eventId ?? `${event.eventTitle}-${event.eventStart}`}
                            sx={{
                              border: '1px solid',
                              borderColor: 'divider',
                              borderRadius: 2,
                              p: 1.25,
                            }}
                          >
                            <Typography variant="subtitle2" fontWeight={700}>
                              {event.eventTitle}
                            </Typography>
                            <Typography variant="caption" color="text.secondary">
                              {formatDate(event.eventStart)}
                              {event.eventEnd ? ` - ${formatDate(event.eventEnd)}` : ' · fin por confirmar'}
                            </Typography>
                            {event.eventVenueId && (
                              <Typography variant="caption" color="text.secondary" display="block">
                                {venueById.get(event.eventVenueId) ?? 'Venue por definir'}
                              </Typography>
                            )}
                          </Box>
                        ))}
                      </Stack>
                    )}
                    {calendarDateOptions.length === 0 && (
                      <Typography variant="caption" color="text.secondary">
                        Aún no hay eventos para mostrar en el calendario.
                      </Typography>
                    )}
                  </Stack>
                </Grid>
              </Grid>
            </Stack>
          </CardContent>
        </Card>
        )}
        {feedback && (
          <Alert severity={feedback.kind} onClose={() => setFeedback(null)}>
            {feedback.message}
          </Alert>
        )}
      </Stack>

      {eventsQuery.error ? (
        <Alert severity="error">No pudimos cargar los eventos. Intenta de nuevo.</Alert>
      ) : eventsQuery.isLoading ? (
        <Stack direction="row" spacing={1.5} alignItems="center">
          <CircularProgress size={18} />
          <Typography>Cargando eventos...</Typography>
        </Stack>
      ) : events.length === 0 ? (
        <Alert severity="info">{eventOverviewUiState.emptyEventsMessage}</Alert>
      ) : (
        <Grid container spacing={2}>
          {events.map((ev, index) => {
            const eventId = ev.eventId ? String(ev.eventId) : '';
            const isOrganizer =
              hasSession &&
              sessionPartyId != null &&
              ev.eventOrganizerPartyId != null &&
              String(ev.eventOrganizerPartyId) === sessionPartyId;
            const invitationForMe = invitationQueries[index]?.data?.[0] ?? null;
            const tiers = ticketTierQueries[index]?.data ?? [];
            const eventCardActionUiState = getSocialEventCardActionUiState({
              hasSession,
              hasAdminAccess,
              isOrganizer,
              ticketTierCount: tiers.length,
            });
            const orders = ticketOrderQueries[index]?.data ?? [];
            const budgetLines = budgetLineQueries[index]?.data ?? [];
            const financeEntries = financeEntryQueries[index]?.data ?? [];
            const financeSummary = financeSummaryQueries[index]?.data ?? null;
            const financeSummaryUiState = financeSummary
              ? getSocialEventsFinanceSummaryUiState(financeSummary)
              : null;
            const inviteDraft = invites[eventId] ?? { party: null, message: '' };
            const availableTiers = tiers.filter(
              (tier) => Boolean(tier.ticketTierId) && tier.ticketTierActive && tierAvailability(tier) > 0,
            );
            const purchaseDraft = ticketPurchases[eventId] ?? {
              tierId: availableTiers[0]?.ticketTierId ?? '',
            };
            const selectedPurchaseTier =
              availableTiers.find((tier) => String(tier.ticketTierId ?? '') === purchaseDraft.tierId)
              ?? availableTiers[0]
              ?? null;
            const tierDraft = ticketTierForms[eventId] ?? { code: '', name: '', price: '', quantity: '', currency: preferredCurrency };
            const budgetDraft = budgetLineForms[eventId] ?? {
              code: '',
              name: '',
              type: 'expense' as const,
              category: 'general',
              plannedCents: '',
              notes: '',
            };
            const financeDraft = financeEntryForms[eventId] ?? {
              budgetLineId: '',
              direction: 'expense' as const,
              source: 'manual',
              category: 'general',
              concept: '',
              amountCents: '',
              currency: ev.eventCurrency ?? preferredCurrency,
              status: 'posted' as const,
              externalRef: '',
              notes: '',
              occurredAt: toDateTimeInputValue(),
            };
            const contractDraft = contractDrafts[eventId] ?? {
              kind: 'event_vendor_contract',
              counterparty: '',
              concept: '',
              amountCents: '',
              currency: ev.eventCurrency ?? preferredCurrency,
              status: 'pending' as const,
              notes: '',
            };
            const contractRefs = Array.from(
              new Set(
                financeEntries
                  .filter(
                    (entry) =>
                      (entry.efeSource === 'contract_commitment' || entry.efeSource === 'contract_payment')
                      && Boolean(entry.efeExternalRef),
                  )
                  .map((entry) => String(entry.efeExternalRef)),
              ),
            );
            const checkInCode = checkInCodes[eventId] ?? '';
            const posterFile = eventPosterFiles[eventId] ?? null;

            return (
              <Grid key={eventId || `${ev.eventTitle}-${ev.eventStart}`} item xs={12} md={6}>
                <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column', borderRadius: 3 }}>
                  <CardContent sx={{ display: 'flex', flexDirection: 'column', gap: 1.5, flex: 1 }}>
                    <Stack direction="row" spacing={1} alignItems="center" justifyContent="space-between" flexWrap="wrap">
                      <Stack direction="row" spacing={1} alignItems="center">
                        <Chip icon={<CalendarMonthIcon />} label={formatDate(ev.eventStart)} size="small" />
                        <Typography variant="caption" color="text.secondary">
                          {ev.eventEnd ? `Termina ${formatDate(ev.eventEnd)}` : 'Fin por confirmar'}
                        </Typography>
                      </Stack>
                      <Stack direction="row" spacing={1} flexWrap="wrap">
                        {ev.eventCapacity ? <Chip label={`Cupo: ${ev.eventCapacity}`} size="small" /> : null}
                        {ev.eventTypeId ? (
                          <Chip
                            label={`Tipo: ${eventTypeById.get(ev.eventTypeId)?.name ?? 'Tipo histórico no disponible'}`}
                            size="small"
                            color="secondary"
                            variant="outlined"
                          />
                        ) : null}
                        {ev.eventWorkflowStateId ? (
                          <Chip
                            label={`Estado: ${locale.toLowerCase().startsWith('en') ? ev.eventWorkflowStateNameEn : ev.eventWorkflowStateNameEs}`}
                            size="small"
                            variant="outlined"
                          />
                        ) : null}
                      </Stack>
                    </Stack>

                    <Typography variant="h6" fontWeight={800}>{ev.eventTitle}</Typography>
                    {eventId && (
                      <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap sx={{ alignSelf: 'flex-start' }}>
                        <Button component={RouterLink} to={`/social/eventos/${eventId}`} size="small" variant="outlined">
                          Abrir página del evento
                        </Button>
                        {eventCardActionUiState.showDeleteAction && (
                          <Button
                            size="small"
                            variant="outlined"
                            color="error"
                            startIcon={<DeleteOutlineIcon />}
                            aria-label={`Eliminar evento ${ev.eventTitle}`}
                            onClick={() => {
                              deleteEventMutation.reset();
                              setPendingEventDeletion({ eventId, eventTitle: ev.eventTitle });
                            }}
                          >
                            Eliminar
                          </Button>
                        )}
                      </Stack>
                    )}
                    {ev.eventVenueId && (
                      <Typography variant="body2" color="text.secondary">
                        {venueById.get(ev.eventVenueId) ?? 'Venue por definir'}
                      </Typography>
                    )}
                    {ev.eventArtists?.length ? (
                      <Typography variant="body2" color="text.secondary">
                        Artistas: {ev.eventArtists.map((a) => a.artistName).join(', ')}
                      </Typography>
                    ) : null}
                    {typeof ev.eventPriceCents === 'number' && (
                      <Typography variant="body2" color="text.secondary">
                        Cover referencial: {formatMoney(ev.eventPriceCents, ev.eventCurrency ?? preferredCurrency)}
                      </Typography>
                    )}
                    {typeof ev.eventBudgetCents === 'number' && (
                      <Typography variant="body2" color="text.secondary">
                        Presupuesto general: {formatMoney(ev.eventBudgetCents, ev.eventCurrency ?? preferredCurrency)}
                      </Typography>
                    )}
                    {ev.eventDescription && (
                      <Typography variant="body2" color="text.secondary">
                        {ev.eventDescription}
                      </Typography>
                    )}
                    {ev.eventImageUrl && (
                      <Box
                        component="img"
                        src={ev.eventImageUrl}
                        alt={`Afiche de ${ev.eventTitle}`}
                        sx={{
                          width: '100%',
                          maxHeight: 280,
                          objectFit: 'cover',
                          borderRadius: 2,
                          border: '1px solid',
                          borderColor: 'divider',
                        }}
                      />
                    )}
                    {isOrganizer && eventId && (
                      <Stack spacing={1}>
                        <Typography variant="subtitle2" fontWeight={700}>Afiche</Typography>
                        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} alignItems={{ sm: 'center' }}>
                          <Button
                            component="label"
                            size="small"
                            variant="outlined"
                          >
                            Seleccionar imagen
                            <input
                              hidden
                              type="file"
                              accept="image/*"
                              onChange={(e) => {
                                const file = e.target.files?.[0] ?? null;
                                setEventPosterFiles((prev) => ({ ...prev, [eventId]: file }));
                                e.currentTarget.value = '';
                              }}
                            />
                          </Button>
                          <Typography variant="caption" color="text.secondary" sx={{ flex: 1 }}>
                            {posterFile ? posterFile.name : ev.eventImageUrl ? 'Afiche actual cargado' : 'Sin afiche cargado'}
                          </Typography>
                          <Button
                            size="small"
                            variant="contained"
                            onClick={() => {
                              if (!posterFile) return;
                              uploadEventImageMutation.mutate({ eventId, file: posterFile });
                            }}
                            disabled={!posterFile || uploadEventImageMutation.isPending}
                          >
                            Subir afiche
                          </Button>
                        </Stack>
                      </Stack>
                    )}

                    {eventCardActionUiState.showRsvpActions && invitationForMe?.invitationStatus && (
                      <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap">
                        <Chip label={`Invitación: ${invitationForMe.invitationStatus}`} size="small" color="secondary" sx={{ width: 'fit-content' }} />
                        {invitationForMe.invitationId && eventId && (
                          <>
                            <Button
                              variant="contained"
                              size="small"
                              onClick={() => respondInvitationMutation.mutate({ eventId, invitationId: invitationForMe.invitationId!, status: 'Accepted' })}
                              disabled={respondInvitationMutation.isPending}
                            >
                              Aceptar
                            </Button>
                            <Button
                              variant="text"
                              size="small"
                              onClick={() => respondInvitationMutation.mutate({ eventId, invitationId: invitationForMe.invitationId!, status: 'Declined' })}
                              disabled={respondInvitationMutation.isPending}
                            >
                              Rechazar
                            </Button>
                          </>
                        )}
                      </Stack>
                    )}

                    {eventCardActionUiState.showRsvpActions && eventId && (
                      <EventRsvpControls
                        eventId={eventId}
                        title={ev.eventTitle}
                        start={ev.eventStart}
                        timezone={ev.eventTimezone}
                        locale={locale}
                        eligible={ev.eventRsvpEligible === true}
                        cancelled={ev.eventWorkflowStateCode === 'cancelled'}
                        publicShareEligible={ev.eventIsPublic === true && ev.eventPublicListable === true}
                        compact
                        origin="event_card"
                      />
                    )}

                    {eventCardActionUiState.showInviteForm && (
                      <>
                        <Divider />

                        <Stack spacing={1}>
                          <Typography variant="subtitle2" fontWeight={700}>Invitar</Typography>
                          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}>
                            <Box sx={{ flex: 1 }}>
                              <UserSelector
                                field={{ label: 'Persona a invitar', helperText: 'Busca por nombre o @username.' }}
                                value={inviteDraft.party}
                                onChange={(party) => setInvites((prev) => ({ ...prev, [eventId]: { ...inviteDraft, party } }))}
                                search={{ context: 'event_invitation', excludedPartyIds: sessionPartyId ? [Number(sessionPartyId)] : [] }}
                              />
                            </Box>
                            <TextField
                              label="Mensaje (opcional)"
                              size="small"
                              value={inviteDraft.message}
                              onChange={(e) => setInvites((prev) => ({ ...prev, [eventId]: { ...inviteDraft, message: e.target.value } }))}
                              sx={{ flex: 2 }}
                            />
                            <Button
                              variant="contained"
                              size="small"
                              startIcon={<PersonAddAltIcon />}
                              onClick={() => eventId && inviteMutation.mutate({ eventId })}
                              disabled={inviteMutation.isPending || !eventId || !inviteDraft.party}
                            >
                              Enviar
                            </Button>
                          </Stack>
                        </Stack>
                      </>
                    )}

                    {eventCardActionUiState.showTicketSection && (
                      <>
                        <Divider />

                        <Stack spacing={1}>
                          <Typography variant="subtitle2" fontWeight={700}>Tickets</Typography>
                          {ticketTierQueries[index]?.error ? (
                            <Alert severity="warning">No se pudieron cargar los tipos de ticket.</Alert>
                          ) : tiers.length === 0 ? (
                            <Typography variant="body2" color="text.secondary">Aún no hay tipos de ticket para este evento.</Typography>
                          ) : (
                            <Stack direction="row" spacing={1} flexWrap="wrap">
                              {tiers.map((tier) => (
                                <Chip
                                  key={tier.ticketTierId ?? tier.ticketTierCode}
                                  icon={<ConfirmationNumberIcon />}
                                  label={`${tier.ticketTierName} · ${formatMoney(tier.ticketTierPriceCents, tier.ticketTierCurrency)} · Disp: ${tierAvailability(tier)}`}
                                  size="small"
                                  variant={tier.ticketTierActive ? 'filled' : 'outlined'}
                                />
                              ))}
                            </Stack>
                          )}

                          {eventCardActionUiState.showTicketPurchaseForm && (
                            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}>
                              <TextField
                                select
                                label="Tipo"
                                size="small"
                                value={selectedPurchaseTier?.ticketTierId ?? ''}
                                onChange={(e) => setTicketPurchases((prev) => ({
                                  ...prev,
                                  [eventId]: { ...purchaseDraft, tierId: e.target.value },
                                }))}
                                sx={{ minWidth: 180 }}
                              >
                                {availableTiers.length === 0 && (
                                  <MenuItem value="" disabled>
                                    Sin tickets disponibles
                                  </MenuItem>
                                )}
                                {tiers.map((tier) => (
                                  <MenuItem
                                    key={tier.ticketTierId ?? tier.ticketTierCode}
                                    value={tier.ticketTierId ?? ''}
                                    disabled={!tier.ticketTierActive || tierAvailability(tier) <= 0}
                                  >
                                    {tier.ticketTierName} ({formatMoney(ticketCheckoutTotal(tier.ticketTierPriceCents), tier.ticketTierCurrency)} final)
                                  </MenuItem>
                                ))}
                              </TextField>
                              <Button
                                variant="contained"
                                size="small"
                                startIcon={<SellIcon />}
                                onClick={() => {
                                  if (!sessionPartyId) {
                                    setFeedback({ kind: 'error', message: 'Inicia sesión para comprar tickets.' });
                                    return;
                                  }
                                  if (!eventId || !selectedPurchaseTier?.ticketTierId) {
                                    setFeedback({ kind: 'error', message: 'Selecciona un tipo de ticket disponible.' });
                                    return;
                                  }
                                  setTicketCheckout({ eventId, eventTitle: ev.eventTitle, tier: selectedPurchaseTier });
                                }}
                                disabled={!eventId || availableTiers.length === 0}
                              >
                                Comprar con tarjeta
                              </Button>
                            </Stack>
                          )}
                        </Stack>
                      </>
                    )}

                    {eventCardActionUiState.showTicketOrders && (
                      <>
                        <Divider />

                        <Stack spacing={1}>
                          <Typography variant="subtitle2" fontWeight={700}>
                            {isOrganizer ? 'Órdenes del evento' : 'Mis órdenes'}
                          </Typography>
                          {ticketOrderQueries[index]?.isLoading ? (
                            <Typography variant="body2" color="text.secondary">Cargando órdenes...</Typography>
                          ) : ticketOrderQueries[index]?.error ? (
                            <Alert severity="warning">No se pudieron cargar las órdenes de tickets.</Alert>
                          ) : (
                            renderOrders(orders, eventId, isOrganizer)
                          )}
                        </Stack>
                      </>
                    )}

                    {eventCardActionUiState.showOrganizerTools && (
                      <>
                        <Divider />
                        <Stack spacing={1}>
                          <Typography variant="subtitle2" fontWeight={700}>Gestión de tickets (organizador)</Typography>
                          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}>
                            <TextField
                              label="Nombre"
                              size="small"
                              value={tierDraft.name}
                              onChange={(e) => setTicketTierForms((prev) => ({
                                ...prev,
                                [eventId]: { ...tierDraft, name: e.target.value },
                              }))}
                              sx={{ flex: 1 }}
                            />
                            <TextField
                              label="Código"
                              size="small"
                              value={tierDraft.code}
                              onChange={(e) => setTicketTierForms((prev) => ({
                                ...prev,
                                [eventId]: { ...tierDraft, code: e.target.value },
                              }))}
                              sx={{ width: 140 }}
                            />
                            <TextField
                              label="Precio (centavos)"
                              size="small"
                              type="number"
                              value={tierDraft.price}
                              onChange={(e) => setTicketTierForms((prev) => ({
                                ...prev,
                                [eventId]: { ...tierDraft, price: e.target.value },
                              }))}
                              sx={{ width: 150 }}
                            />
                            <TextField
                              label="Cantidad"
                              size="small"
                              type="number"
                              value={tierDraft.quantity}
                              onChange={(e) => setTicketTierForms((prev) => ({
                                ...prev,
                                [eventId]: { ...tierDraft, quantity: e.target.value },
                              }))}
                              sx={{ width: 120 }}
                            />
                            <TextField
                              label="Moneda"
                              size="small"
                              value={tierDraft.currency}
                              onChange={(e) => setTicketTierForms((prev) => ({
                                ...prev,
                                [eventId]: { ...tierDraft, currency: e.target.value },
                              }))}
                              sx={{ width: 110 }}
                            />
                            <Button
                              variant="contained"
                              size="small"
                              startIcon={<ConfirmationNumberIcon />}
                              onClick={() => eventId && createTierMutation.mutate({ eventId })}
                              disabled={createTierMutation.isPending || !eventId}
                            >
                              Crear tier
                            </Button>
                          </Stack>

                          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}>
                            <TextField
                              label="Código ticket para check-in"
                              size="small"
                              value={checkInCode}
                              onChange={(e) => setCheckInCodes((prev) => ({ ...prev, [eventId]: e.target.value }))}
                              sx={{ flex: 1 }}
                            />
                            <Button
                              variant="outlined"
                              size="small"
                              startIcon={<QrCodeScannerIcon />}
                              onClick={() => eventId && checkInMutation.mutate({ eventId })}
                              disabled={checkInMutation.isPending || !eventId}
                            >
                              Check-in
                            </Button>
                          </Stack>

                          {eventId && (
                            <EventManualPaymentsPanel eventId={eventId} formatMoney={formatMoney} formatDate={formatDate} />
                          )}

                          {eventId && (
                            <EventTaxDocumentsPanel eventId={eventId} formatMoney={formatMoney} formatDate={formatDate} />
                          )}

                          {eventId && (
                            <Stack spacing={1}>
                              <Typography variant="subtitle2" fontWeight={700}>Reembolsos</Typography>
                              <RefundManagementPanel eventId={eventId} />
                            </Stack>
                          )}

                          <Divider />

                          <Stack spacing={1}>
                            <Typography variant="subtitle2" fontWeight={700}>Finanzas del evento</Typography>
                            {financeSummaryQueries[index]?.isLoading ? (
                              <Typography variant="body2" color="text.secondary">Calculando resumen financiero...</Typography>
                            ) : financeSummaryQueries[index]?.error ? (
                              <Alert severity="warning">No se pudo cargar el resumen financiero.</Alert>
                            ) : financeSummary ? (
                              <Stack spacing={1}>
                                <Stack direction="row" spacing={1} flexWrap="wrap">
                                  {financeSummaryUiState?.metrics.map((metric) => (
                                    <Chip
                                      key={metric.key}
                                      size="small"
                                      label={`${metric.label}: ${
                                        metric.valueType === 'percent'
                                          ? formatPercent(metric.value)
                                          : formatMoney(metric.value, financeSummary.efsCurrency)
                                      }`}
                                      color={metric.color}
                                      variant={metric.variant}
                                    />
                                  ))}
                                </Stack>
                                {financeSummaryUiState?.omittedEmptyDetailSummary && (
                                  <Typography variant="caption" color="text.secondary">
                                    {financeSummaryUiState.omittedEmptyDetailSummary}
                                  </Typography>
                                )}
                                <Stack direction="row" spacing={1}>
                                  <Button
                                    size="small"
                                    variant="outlined"
                                    disabled={
                                      budgetLineQueries[index]?.data == null ||
                                      financeEntryQueries[index]?.data == null ||
                                      Boolean(budgetLineQueries[index]?.error) ||
                                      Boolean(financeEntryQueries[index]?.error)
                                    }
                                    onClick={() =>
                                      exportEventFinanceCsv({
                                        event: ev,
                                        budgetLines,
                                        financeEntries,
                                        financeSummary,
                                      })
                                    }
                                  >
                                    Exportar CSV
                                  </Button>
                                </Stack>
                              </Stack>
                            ) : null}

                            <Typography variant="body2" fontWeight={700}>Líneas de presupuesto</Typography>
                            {budgetLineQueries[index]?.error ? (
                              <Alert severity="warning">No se pudieron cargar las líneas presupuestarias.</Alert>
                            ) : budgetLines.length === 0 ? (
                              <Typography variant="body2" color="text.secondary">Aún no hay líneas de presupuesto.</Typography>
                            ) : (
                              <Stack spacing={0.75}>
                                {budgetLines.map((line) => (
                                  <Stack key={line.eblId ?? line.eblCode} direction="row" spacing={1} alignItems="center" flexWrap="wrap">
                                    <Chip size="small" label={`${line.eblCode} · ${line.eblType}`} />
                                    <Typography variant="caption" color="text.secondary">
                                      Plan: {formatMoney(line.eblPlannedCents, ev.eventCurrency ?? preferredCurrency)} · Real: {formatMoney(line.eblActualCents ?? 0, ev.eventCurrency ?? preferredCurrency)}
                                    </Typography>
                                  </Stack>
                                ))}
                              </Stack>
                            )}

                            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}>
                              <TextField
                                label="Nombre línea"
                                size="small"
                                value={budgetDraft.name}
                                onChange={(e) => setBudgetLineForms((prev) => ({
                                  ...prev,
                                  [eventId]: { ...budgetDraft, name: e.target.value },
                                }))}
                                sx={{ flex: 1 }}
                              />
                              <TextField
                                label="Código"
                                size="small"
                                value={budgetDraft.code}
                                onChange={(e) => setBudgetLineForms((prev) => ({
                                  ...prev,
                                  [eventId]: { ...budgetDraft, code: e.target.value },
                                }))}
                                sx={{ width: 130 }}
                              />
                              <TextField
                                select
                                label="Tipo"
                                size="small"
                                value={budgetDraft.type}
                                onChange={(e) => setBudgetLineForms((prev) => ({
                                  ...prev,
                                  [eventId]: { ...budgetDraft, type: e.target.value as 'income' | 'expense' },
                                }))}
                                sx={{ width: 120 }}
                              >
                                <MenuItem value="expense">Gasto</MenuItem>
                                <MenuItem value="income">Ingreso</MenuItem>
                              </TextField>
                              <TextField
                                label="Categoría"
                                select
                                size="small"
                                value={budgetDraft.category}
                                onChange={(e) => setBudgetLineForms((prev) => ({
                                  ...prev,
                                  [eventId]: { ...budgetDraft, category: e.target.value },
                                }))}
                                sx={{ width: 140 }}
                              >
                                {BUDGET_CATEGORY_OPTIONS.map((option) => (
                                  <MenuItem key={option} value={option}>
                                    {option}
                                  </MenuItem>
                                ))}
                              </TextField>
                              <TextField
                                label="Plan (centavos)"
                                size="small"
                                type="number"
                                value={budgetDraft.plannedCents}
                                onChange={(e) => setBudgetLineForms((prev) => ({
                                  ...prev,
                                  [eventId]: { ...budgetDraft, plannedCents: e.target.value },
                                }))}
                                sx={{ width: 150 }}
                              />
                              <Button
                                variant="outlined"
                                size="small"
                                onClick={() => eventId && createBudgetLineMutation.mutate({ eventId })}
                                disabled={createBudgetLineMutation.isPending || !eventId}
                              >
                                Agregar línea
                              </Button>
                              <Button
                                variant="text"
                                size="small"
                                onClick={() => eventId && seedBudgetTemplateMutation.mutate({ eventId, existingLines: budgetLines })}
                                disabled={seedBudgetTemplateMutation.isPending || !eventId}
                              >
                                Plantilla PM
                              </Button>
                            </Stack>

                            <Divider />

                            <Typography variant="body2" fontWeight={700}>Contratos y compromisos</Typography>
                            {contractRefs.length === 0 ? (
                              <Typography variant="body2" color="text.secondary">
                                Aún no hay contratos vinculados.
                              </Typography>
                            ) : (
                              <Stack spacing={0.75}>
                                {contractRefs.map((contractId) => (
                                  <Stack key={contractId} direction="row" spacing={1} alignItems="center" flexWrap="wrap">
                                    <Chip size="small" label={`Contrato ${contractId}`} />
                                    <Button
                                      size="small"
                                      variant="outlined"
                                      onClick={() => downloadContractPdfMutation.mutate({ contractId })}
                                      disabled={downloadContractPdfMutation.isPending}
                                    >
                                      PDF
                                    </Button>
                                    <Button
                                      size="small"
                                      variant="text"
                                      onClick={() =>
                                        setFinanceEntryForms((prev) => ({
                                          ...prev,
                                          [eventId]: {
                                            ...financeDraft,
                                            source: 'contract_payment',
                                            direction: 'expense',
                                            category: 'contracting',
                                            externalRef: contractId,
                                            concept: financeDraft.concept || `Pago contrato ${contractId}`,
                                          },
                                        }))
                                      }
                                    >
                                      Registrar pago
                                    </Button>
                                  </Stack>
                                ))}
                              </Stack>
                            )}

                            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}>
                              <TextField
                                label="Tipo de contrato"
                                size="small"
                                value={contractDraft.kind}
                                onChange={(e) =>
                                  setContractDrafts((prev) => ({
                                    ...prev,
                                    [eventId]: { ...contractDraft, kind: e.target.value },
                                  }))
                                }
                                sx={{ minWidth: 180 }}
                              />
                              <TextField
                                label="Contraparte"
                                size="small"
                                value={contractDraft.counterparty}
                                onChange={(e) =>
                                  setContractDrafts((prev) => ({
                                    ...prev,
                                    [eventId]: { ...contractDraft, counterparty: e.target.value },
                                  }))
                                }
                                sx={{ flex: 1 }}
                              />
                              <TextField
                                label="Concepto"
                                size="small"
                                value={contractDraft.concept}
                                onChange={(e) =>
                                  setContractDrafts((prev) => ({
                                    ...prev,
                                    [eventId]: { ...contractDraft, concept: e.target.value },
                                  }))
                                }
                                sx={{ flex: 1 }}
                              />
                            </Stack>

                            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}>
                              <TextField
                                label="Monto (centavos)"
                                size="small"
                                type="number"
                                value={contractDraft.amountCents}
                                onChange={(e) =>
                                  setContractDrafts((prev) => ({
                                    ...prev,
                                    [eventId]: { ...contractDraft, amountCents: e.target.value },
                                  }))
                                }
                                sx={{ width: 170 }}
                              />
                              <TextField
                                label="Moneda"
                                size="small"
                                value={contractDraft.currency}
                                onChange={(e) =>
                                  setContractDrafts((prev) => ({
                                    ...prev,
                                    [eventId]: { ...contractDraft, currency: e.target.value.toUpperCase() },
                                  }))
                                }
                                sx={{ width: 110 }}
                              />
                              <TextField
                                select
                                label="Estado compromiso"
                                size="small"
                                value={contractDraft.status}
                                onChange={(e) =>
                                  setContractDrafts((prev) => ({
                                    ...prev,
                                    [eventId]: {
                                      ...contractDraft,
                                      status: e.target.value as ContractDraftState['status'],
                                    },
                                  }))
                                }
                                sx={{ width: 180 }}
                              >
                                <MenuItem value="pending">Pendiente</MenuItem>
                                <MenuItem value="draft">Borrador</MenuItem>
                                <MenuItem value="posted">Publicado</MenuItem>
                              </TextField>
                              <TextField
                                label="Notas"
                                size="small"
                                value={contractDraft.notes}
                                onChange={(e) =>
                                  setContractDrafts((prev) => ({
                                    ...prev,
                                    [eventId]: { ...contractDraft, notes: e.target.value },
                                  }))
                                }
                                sx={{ flex: 1 }}
                              />
                              <Button
                                variant="contained"
                                size="small"
                                onClick={() => eventId && createContractCommitmentMutation.mutate({ eventId })}
                                disabled={createContractCommitmentMutation.isPending || !eventId}
                              >
                                Crear contrato
                              </Button>
                            </Stack>

                            <Typography variant="body2" fontWeight={700}>Asientos contables</Typography>
                            {financeEntryQueries[index]?.error ? (
                              <Alert severity="warning">No se pudieron cargar los asientos contables.</Alert>
                            ) : financeEntries.length === 0 ? (
                              <Typography variant="body2" color="text.secondary">Sin movimientos aún.</Typography>
                            ) : (
                              <Stack spacing={0.75}>
                                {financeEntries.slice(0, 8).map((entry) => (
                                  <Stack key={entry.efeId ?? `${entry.efeConcept}-${entry.efeOccurredAt}`} direction="row" spacing={1} alignItems="center" flexWrap="wrap">
                                    <Chip size="small" label={`${entry.efeDirection} · ${entry.efeSource}`} variant="outlined" />
                                    <Typography variant="caption" color="text.secondary">
                                      {formatDate(entry.efeOccurredAt)} · {entry.efeConcept} · {formatMoney(entry.efeAmountCents, entry.efeCurrency)} · {entry.efeStatus}
                                      {entry.efeExternalRef ? ` · Ref: ${entry.efeExternalRef}` : ''}
                                    </Typography>
                                  </Stack>
                                ))}
                              </Stack>
                            )}

                            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}>
                              <TextField
                                select
                                label="Línea presupuesto"
                                size="small"
                                value={financeDraft.budgetLineId}
                                onChange={(e) => setFinanceEntryForms((prev) => ({
                                  ...prev,
                                  [eventId]: { ...financeDraft, budgetLineId: e.target.value },
                                }))}
                                sx={{ minWidth: 180 }}
                              >
                                <MenuItem value="">Sin línea</MenuItem>
                                {budgetLines.map((line) => (
                                  <MenuItem key={line.eblId ?? line.eblCode} value={line.eblId ?? ''}>
                                    {line.eblCode} · {line.eblName}
                                  </MenuItem>
                                ))}
                              </TextField>
                              <TextField
                                select
                                label="Fuente"
                                size="small"
                                value={financeDraft.source}
                                onChange={(e) => setFinanceEntryForms((prev) => ({
                                  ...prev,
                                  [eventId]: {
                                    ...financeDraft,
                                    source: e.target.value,
                                    direction:
                                      FINANCE_SOURCE_OPTIONS.find((opt) => opt.value === e.target.value)?.direction ?? financeDraft.direction,
                                    category:
                                      FINANCE_SOURCE_OPTIONS.find((opt) => opt.value === e.target.value)?.category ?? financeDraft.category,
                                  },
                                }))}
                                sx={{ minWidth: 210 }}
                              >
                                {FINANCE_SOURCE_OPTIONS.map((option) => (
                                  <MenuItem key={option.value} value={option.value}>
                                    {option.label}
                                  </MenuItem>
                                ))}
                              </TextField>
                              <TextField
                                select
                                label="Dirección"
                                size="small"
                                value={financeDraft.direction}
                                onChange={(e) => setFinanceEntryForms((prev) => ({
                                  ...prev,
                                  [eventId]: { ...financeDraft, direction: e.target.value as 'income' | 'expense' },
                                }))}
                                sx={{ width: 130 }}
                              >
                                <MenuItem value="expense">Gasto</MenuItem>
                                <MenuItem value="income">Ingreso</MenuItem>
                              </TextField>
                              <TextField
                                select
                                label="Estado"
                                size="small"
                                value={financeDraft.status}
                                onChange={(e) => setFinanceEntryForms((prev) => ({
                                  ...prev,
                                  [eventId]: {
                                    ...financeDraft,
                                    status: e.target.value as FinanceEntryFormState['status'],
                                  },
                                }))}
                                sx={{ width: 130 }}
                              >
                                {FINANCE_STATUS_OPTIONS.map((option) => (
                                  <MenuItem key={option.value} value={option.value}>
                                    {option.label}
                                  </MenuItem>
                                ))}
                              </TextField>
                            </Stack>
                            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}>
                              <TextField
                                select
                                label="Categoría"
                                size="small"
                                value={financeDraft.category}
                                onChange={(e) => setFinanceEntryForms((prev) => ({
                                  ...prev,
                                  [eventId]: { ...financeDraft, category: e.target.value },
                                }))}
                                sx={{ minWidth: 150 }}
                              >
                                {BUDGET_CATEGORY_OPTIONS.map((option) => (
                                  <MenuItem key={option} value={option}>
                                    {option}
                                  </MenuItem>
                                ))}
                              </TextField>
                              <TextField
                                label="Concepto"
                                size="small"
                                value={financeDraft.concept}
                                onChange={(e) => setFinanceEntryForms((prev) => ({
                                  ...prev,
                                  [eventId]: { ...financeDraft, concept: e.target.value },
                                }))}
                                sx={{ flex: 1 }}
                              />
                              <TextField
                                label="Referencia externa"
                                size="small"
                                value={financeDraft.externalRef}
                                onChange={(e) => setFinanceEntryForms((prev) => ({
                                  ...prev,
                                  [eventId]: { ...financeDraft, externalRef: e.target.value },
                                }))}
                                sx={{ flex: 1 }}
                              />
                            </Stack>
                            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}>
                              <TextField
                                label="Monto (centavos)"
                                size="small"
                                type="number"
                                value={financeDraft.amountCents}
                                onChange={(e) => setFinanceEntryForms((prev) => ({
                                  ...prev,
                                  [eventId]: { ...financeDraft, amountCents: e.target.value },
                                }))}
                                sx={{ width: 160 }}
                              />
                              <TextField
                                label="Moneda"
                                size="small"
                                value={financeDraft.currency}
                                onChange={(e) => setFinanceEntryForms((prev) => ({
                                  ...prev,
                                  [eventId]: { ...financeDraft, currency: e.target.value.toUpperCase() },
                                }))}
                                sx={{ width: 110 }}
                              />
                              <TextField
                                label="Ocurrió en"
                                size="small"
                                type="datetime-local"
                                value={financeDraft.occurredAt}
                                onChange={(e) => setFinanceEntryForms((prev) => ({
                                  ...prev,
                                  [eventId]: { ...financeDraft, occurredAt: e.target.value },
                                }))}
                                InputLabelProps={{ shrink: true }}
                                sx={{ minWidth: 210 }}
                              />
                              <TextField
                                label="Notas"
                                size="small"
                                value={financeDraft.notes}
                                onChange={(e) => setFinanceEntryForms((prev) => ({
                                  ...prev,
                                  [eventId]: { ...financeDraft, notes: e.target.value },
                                }))}
                                sx={{ flex: 1 }}
                              />
                              <Button
                                variant="contained"
                                size="small"
                                onClick={() => eventId && createFinanceEntryMutation.mutate({ eventId })}
                                disabled={createFinanceEntryMutation.isPending || !eventId}
                              >
                                Registrar
                              </Button>
                            </Stack>
                          </Stack>
                        </Stack>
                      </>
                    )}
                  </CardContent>
                </Card>
              </Grid>
            );
          })}
        </Grid>
      )}
      <Dialog
        open={pendingEventDeletion !== null}
        onClose={() => {
          if (!deleteEventMutation.isPending) setPendingEventDeletion(null);
        }}
        aria-labelledby="delete-event-dialog-title"
        aria-describedby="delete-event-dialog-description"
      >
        <DialogTitle id="delete-event-dialog-title">Eliminar evento</DialogTitle>
        <DialogContent>
          <DialogContentText id="delete-event-dialog-description">
            {pendingEventDeletion
              ? `¿Eliminar “${pendingEventDeletion.eventTitle}”? El evento dejará de estar disponible para nuevas ventas. Según su origen, sus datos se eliminarán permanentemente o se conservarán ocultos para impedir que una importación vuelva a publicarlo. Esta acción no se puede deshacer desde aquí.`
              : ''}
          </DialogContentText>
          {deleteEventMutation.isError && (
            <Alert severity="error" sx={{ mt: 2 }}>
              {deleteEventMutation.error instanceof Error
                ? deleteEventMutation.error.message
                : 'No se pudo eliminar el evento.'}
            </Alert>
          )}
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setPendingEventDeletion(null)}
            disabled={deleteEventMutation.isPending}
          >
            Cancelar
          </Button>
          <Button
            color="error"
            variant="contained"
            startIcon={deleteEventMutation.isPending ? <CircularProgress size={18} color="inherit" /> : <DeleteOutlineIcon />}
            onClick={() => {
              if (pendingEventDeletion) deleteEventMutation.mutate(pendingEventDeletion);
            }}
            disabled={!pendingEventDeletion || deleteEventMutation.isPending}
          >
            {deleteEventMutation.isPending ? 'Eliminando…' : 'Eliminar evento'}
          </Button>
        </DialogActions>
      </Dialog>
      {ticketCheckout && (
        <StripeCheckoutModal
          open
          eventId={ticketCheckout.eventId}
          eventTitle={ticketCheckout.eventTitle}
          tier={ticketCheckout.tier}
          onClose={() => setTicketCheckout(null)}
          onSuccess={(orderId) => {
            void qc.invalidateQueries({ queryKey: ['social-ticket-tiers', ticketCheckout.eventId] });
            void qc.invalidateQueries({ queryKey: ['social-ticket-orders', ticketCheckout.eventId] });
            setFeedback({ kind: 'success', message: `Pago aprobado. Orden ${orderId}.` });
          }}
        />
      )}
    </Box>
  );
}
