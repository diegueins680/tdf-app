import { jest } from '@jest/globals';

const getMock = jest.fn<(path: string, init?: RequestInit) => Promise<unknown>>();
const postMock = jest.fn<(path: string, body: unknown) => Promise<unknown>>();
const postFormMock = jest.fn<(path: string, body: FormData) => Promise<unknown>>();
const putMock = jest.fn<(path: string, body: unknown) => Promise<unknown>>();
const delMock = jest.fn<(path: string) => Promise<unknown>>();

type RawPathSegment = string & { readonly __rawPathSegment: 'RawPathSegment' };
type EncodedPathSegment = string & { readonly __encodedPathSegment: 'EncodedPathSegment' };

const rawPathSegment = (value: string): RawPathSegment => {
  if (value.trim().length === 0) {
    throw new Error('Test path segment fixtures must be non-blank.');
  }
  if (value.includes('%')) {
    throw new Error('Test path segment fixtures must be raw, not pre-encoded.');
  }
  return value as RawPathSegment;
};

const encodeExpectedPathSegment = (value: RawPathSegment): EncodedPathSegment => {
  const encoded = encodeURIComponent(value);
  if (encoded.includes('/')) {
    throw new Error('Encoded path segment fixtures must not contain raw slashes.');
  }
  return encoded as EncodedPathSegment;
};

const WAITLIST_EVENT_ID_WITH_SPACE = rawPathSegment('event 7');
const WAITLIST_ENTRY_ID_WITH_SLASH = rawPathSegment('entry/a');
const WAITLIST_TIER_ID_WITH_SLASH = rawPathSegment('tier/3');
const PADDED_WAITLIST_TIER_ID_WITH_SLASH = ` ${WAITLIST_TIER_ID_WITH_SLASH} `;
const WAITLIST_EVENT_PATH = `/social-events/events/${encodeExpectedPathSegment(WAITLIST_EVENT_ID_WITH_SPACE)}/waitlist`;
const WAITLIST_ENTRY_PATH = `${WAITLIST_EVENT_PATH}/${encodeExpectedPathSegment(WAITLIST_ENTRY_ID_WITH_SLASH)}`;
const WAITLIST_TIER_QUERY_PATH = `${WAITLIST_EVENT_PATH}?tierId=${encodeExpectedPathSegment(WAITLIST_TIER_ID_WITH_SLASH)}`;

jest.unstable_mockModule('./client', () => ({
  del: delMock,
  get: getMock,
  post: postMock,
  postForm: postFormMock,
  put: putMock,
}));

const { SocialEventsAPI } = await import('./socialEvents');

describe('SocialEventsAPI', () => {
  const published = { emId: '77', emEventId: '141', emAuthorName: 'Synthetic', emCaption: 'Synthetic memory', emMediaUrl: '', emMediaType: 'text' };
  const textPayload = { emCreateCaption: 'Synthetic memory', emCreateMediaUrl: '', emCreateMediaType: 'text' as const };

  beforeEach(() => {
    getMock.mockReset();
    postMock.mockReset();
    postFormMock.mockReset();
    putMock.mockReset();
    delMock.mockReset();
    getMock.mockResolvedValue([]);
    postMock.mockResolvedValue({});
    postFormMock.mockResolvedValue({});
    putMock.mockResolvedValue({});
    delMock.mockResolvedValue({});
  });

  it('trims list query params and skips blank filters', async () => {
    await SocialEventsAPI.listEvents({
      city: '  Quito  ',
      startAfter: '   ',
      eventTypeId: '31000000-0000-4000-8000-000000000001',
      workflowStateId: ' 00000000-0000-4000-8000-000000000233 ',
      artistId: ' 42 ',
      venueId: '   ',
    });

    expect(getMock).toHaveBeenCalledWith('/social-events/events?city=Quito&event_type_id=31000000-0000-4000-8000-000000000001&workflow_state_id=00000000-0000-4000-8000-000000000233&artistId=42');
  });

  it('forwards cancellation for public upcoming event searches', async () => {
    const controller = new AbortController();

    await SocialEventsAPI.listPublicUpcomingEvents({
      city: ' Guayaquil ',
      startAfter: '2030-01-01T00:00:00.000Z',
      limit: 50,
      signal: controller.signal,
    });

    expect(getMock).toHaveBeenLastCalledWith(
      '/social-events/upcoming?city=Guayaquil&startAfter=2030-01-01T00%3A00%3A00.000Z&limit=50',
      { signal: controller.signal },
    );
  });

  it('deletes events through an encoded event path', async () => {
    await SocialEventsAPI.deleteEvent('event 7/quito');

    expect(delMock).toHaveBeenCalledWith('/social-events/events/event%207%2Fquito');
  });

  it('removes waitlist entries through the shared API client', async () => {
    await SocialEventsAPI.removeFromWaitlist(WAITLIST_EVENT_ID_WITH_SPACE, WAITLIST_ENTRY_ID_WITH_SLASH);

    expect(delMock).toHaveBeenCalledWith(WAITLIST_ENTRY_PATH);
  });

  it('lists waitlist entries with a trimmed tier filter', async () => {
    await SocialEventsAPI.listWaitlist(WAITLIST_EVENT_ID_WITH_SPACE, PADDED_WAITLIST_TIER_ID_WITH_SLASH);

    expect(getMock).toHaveBeenCalledWith(WAITLIST_TIER_QUERY_PATH);
  });

  it('uses encoded event and activity identifiers for logistics route verification', async () => {
    await SocialEventsAPI.verifyLogisticsRoute('event 7', 'travel/12');

    expect(postMock).toHaveBeenCalledWith(
      '/social-events/events/event%207/logistics/activities/travel%2F12/verify-route',
      {},
    );
  });

  it('uses the logistics aggregate and delete endpoints', async () => {
    await SocialEventsAPI.getLogisticsPlan('event 7');
    await SocialEventsAPI.deleteLogisticsPlace('event 7', 'place/3');

    expect(getMock).toHaveBeenCalledWith('/social-events/events/event%207/logistics');
    expect(delMock).toHaveBeenCalledWith('/social-events/events/event%207/logistics/places/place%2F3');
  });

  it('uses the authenticated self RSVP contract without client-controlled identity', async () => {
    await SocialEventsAPI.upsertMyRsvp(' event/7 ', {
      rsvpStatus: 'accepted',
      rsvpShowOnProfile: true,
    });

    expect(putMock).toHaveBeenCalledWith(
      '/social-events/events/%20event%2F7%20/rsvp',
      {
        rsvpStatus: 'accepted',
        rsvpShowOnProfile: true,
      },
    );
    expect(putMock.mock.calls[0]?.[1]).not.toHaveProperty('rsvpPartyId');
    expect(putMock.mock.calls[0]?.[1]).not.toHaveProperty('rsvpEventId');
  });

  it('keeps own RSVP, aggregate counts, deletion, and invitation endpoints distinct', async () => {
    await SocialEventsAPI.getMyRsvp('7');
    await SocialEventsAPI.getRsvpSummary('7');
    await SocialEventsAPI.deleteMyRsvp('7');

    expect(getMock).toHaveBeenNthCalledWith(1, '/social-events/events/7/rsvp');
    expect(getMock).toHaveBeenNthCalledWith(2, '/social-events/events/7/rsvp-summary');
    expect(delMock).toHaveBeenCalledWith('/social-events/events/7/rsvp');
    expect(getMock.mock.calls.map(([path]) => path).join(' ')).not.toContain('/invitations');
  });

  it('loads a directory RSVP feed by public slug without exposing a Party id', async () => {
    await SocialEventsAPI.listDirectoryProfileRsvpFeed('persona segura', 'cursor/value', 12);

    expect(getMock).toHaveBeenCalledWith(
      '/social-events/directory-profiles/persona%20segura/rsvp-feed?cursor=cursor%2Fvalue&limit=12',
    );
  });

  it('respondInvitation includes invitationToPartyId required by backend schema', async () => {
    getMock.mockResolvedValueOnce([
      {
        invitationId: ' 0012 ',
        invitationToPartyId: ' 99 ',
      },
    ]);

    await SocialEventsAPI.respondInvitation(' 7 ', ' 12 ', 'Accepted', 'Listo');

    expect(getMock).toHaveBeenCalledWith('/social-events/events/7/invitations');
    expect(putMock).toHaveBeenCalledWith(
      '/social-events/events/7/invitations/12',
      {
        invitationToPartyId: '99',
        invitationStatus: 'Accepted',
        invitationMessage: 'Listo',
      },
    );
  });

  it('respondInvitation sends a status-only reply without clearing the organizer message', async () => {
    getMock.mockResolvedValueOnce([
      {
        invitationId: '12',
        invitationToPartyId: '99',
      },
    ]);

    await SocialEventsAPI.respondInvitation('7', '0012', 'Accepted');

    expect(putMock).toHaveBeenCalledWith(
      '/social-events/events/7/invitations/12',
      {
        invitationToPartyId: '99',
        invitationStatus: 'Accepted',
      },
    );
  });

  it.each(['Accepted', 'Declined'])('omits message edits for a status-only %s response', async (status) => {
    getMock.mockResolvedValueOnce([{ invitationId: '12', invitationToPartyId: '99' }]);
    await SocialEventsAPI.respondInvitation('7', '12', status);
    expect(putMock).toHaveBeenCalledWith('/social-events/events/7/invitations/12', {
      invitationToPartyId: '99', invitationStatus: status,
    });
  });

  it('respondInvitation throws when invitation is not found', async () => {
    getMock.mockResolvedValueOnce([]);

    await expect(SocialEventsAPI.respondInvitation('7', '88', 'Declined')).rejects.toThrow(
      'Invitation 88 not found for event 7.',
    );
    expect(putMock).not.toHaveBeenCalled();
  });

  it('respondInvitation throws when invitationToPartyId is blank', async () => {
    getMock.mockResolvedValueOnce([
      {
        invitationId: '88',
        invitationToPartyId: '   ',
      },
    ]);

    await expect(SocialEventsAPI.respondInvitation('7', '88', 'Accepted')).rejects.toThrow(
      'Invitation 88 is missing invitationToPartyId.',
    );
    expect(putMock).not.toHaveBeenCalled();
  });

  it('respondInvitation throws when invitationToPartyId is missing', async () => {
    getMock.mockResolvedValueOnce([
      {
        invitationId: '88',
      },
    ]);

    await expect(SocialEventsAPI.respondInvitation('7', '88', 'Accepted')).rejects.toThrow(
      'Invitation 88 is missing invitationToPartyId.',
    );
    expect(putMock).not.toHaveBeenCalled();
  });

  it('respondInvitation validates required identifiers before requesting data', async () => {
    await expect(SocialEventsAPI.respondInvitation('   ', '88', 'Accepted')).rejects.toThrow(
      'eventId is required to respond to an invitation.',
    );
    await expect(SocialEventsAPI.respondInvitation('7', '   ', 'Accepted')).rejects.toThrow(
      'invitationId is required to respond to an invitation.',
    );

    expect(getMock).not.toHaveBeenCalled();
    expect(putMock).not.toHaveBeenCalled();
  });
  it.each(['<html>not a publication</html>', null, {}, { ...published, emId: null }, { ...published, emEventId: '142' }, { ...published, emCaption: null }])('keeps malformed or cross-event acknowledgements unconfirmed: %p', async (reply) => {
    postMock.mockResolvedValue(reply);
    await expect(SocialEventsAPI.createMoment('141', textPayload)).rejects.toThrow('No se pudo confirmar la publicación');
  });
  it('confirms a persisted moment and retains compatible legacy replies without eventId', async () => {
    postMock.mockResolvedValue(published);
    await expect(SocialEventsAPI.createMoment('141', textPayload)).resolves.toEqual(published);
    const { emEventId: _event, ...legacy } = published;
    postMock.mockResolvedValue(legacy);
    await expect(SocialEventsAPI.createMoment('141', textPayload)).resolves.toEqual(legacy);
  });
  it('does not confirm another source when editing or an HTML fallback when deleting', async () => {
    putMock.mockResolvedValue({ ...published, emId: '78' });
    await expect(SocialEventsAPI.editMoment('141', '77', 'Synthetic', '2026-10-25T00:00:00Z')).rejects.toThrow('No se pudo confirmar');
    putMock.mockResolvedValue(published);
    await expect(SocialEventsAPI.editMoment('141', '77', 'Synthetic', '2026-10-25T00:00:00Z')).resolves.toEqual(published);
    delMock.mockResolvedValue('<html>not a deletion</html>');
    await expect(SocialEventsAPI.deleteMoment('141', '77')).rejects.toThrow('No se pudo confirmar la eliminación');
    delMock.mockResolvedValue(undefined);
    await expect(SocialEventsAPI.deleteMoment('141', '77')).resolves.toBeUndefined();
  });

});

describe('event finance read precision', () => {
  it.each(['efsBudgetCents', 'efsPlannedIncomeCents', 'efsPlannedExpenseCents', 'efsActualIncomeCents', 'efsActualExpenseCents', 'efsNetCents', 'efsTicketPaidRevenueCents', 'efsTicketRefundedRevenueCents', 'efsTicketPendingRevenueCents', 'efsAccountsPayableCents', 'efsAccountsReceivableCents', 'efsContractCommittedCents', 'efsContractPaidCents', 'efsProcurementCommittedCents', 'efsProcurementPaidCents', 'efsAssetInvestmentCents', 'efsLiabilityBalanceCents', 'efsBudgetVarianceCents'])('refuses rounded JSON summary %s', async field => {
    getMock.mockResolvedValue(JSON.parse(`{"${field}":9007199254740993}`));
    await expect(SocialEventsAPI.getFinanceSummary('7')).rejects.toThrow('precisión');
  });
  it.each(['eblPlannedCents', 'eblActualCents'])('refuses unsafe independent budget field %s', async field => {
    getMock.mockResolvedValue([{ [field]: -9007199254740992 }]);
    await expect(SocialEventsAPI.listBudgetLines('7')).rejects.toThrow('precisión');
  });
  it('refuses unsafe independent finance entries', async () => {
    getMock.mockResolvedValue([{ efeAmountCents: 9007199254740992 }]);
    await expect(SocialEventsAPI.listFinanceEntries('7')).rejects.toThrow('precisión');
  });
  it('preserves exact signed cents, optional values and non-monetary percentages', async () => {
    const report = { efsNetCents: -9007199254740991, efsBudgetCents: null, efsBudgetUtilizationPct: 1.25 };
    getMock.mockResolvedValue(report);
    await expect(SocialEventsAPI.getFinanceSummary('7')).resolves.toBe(report);
  });
});
