import { resolveRuntimeCurrency, resolveRuntimeFormatOptions } from './formatters';

const PRECISION_ERROR = 'El importe excede la precisión admitida por el navegador o no contiene centavos enteros.';

// Finance DTO monetary fields share the Cents suffix. Percentages and IDs are not money.
export function assertSafeEventFinanceMoney<T extends object>(value: T): T {
  for (const [field, amount] of Object.entries(value)) {
    if (field.endsWith('Cents') && amount != null && !Number.isSafeInteger(amount)) {
      throw new Error(PRECISION_ERROR);
    }
  }
  return value;
}

export const formatEventMoney = (amountCents?: number | null, currency?: string | null): string => {
  if (typeof amountCents !== 'number') return 'Gratis';
  if (!Number.isSafeInteger(amountCents)) return 'Monto no disponible';
  return new Intl.NumberFormat(resolveRuntimeFormatOptions().locale, {
    style: 'currency', currency: (currency ?? resolveRuntimeCurrency()).toUpperCase(),
  }).format(amountCents / 100);
};
