const assertSafeEventFinanceMoney = <T extends object>(value: T): T => value;
import { del, get, post, postForm, put } from './client';

export interface SocialArtistDTO {
  artistId?: string | null;
  artistPartyId?: string | null;
  artistName: string;
  /** Canonical relationship identifiers used by writes and filters. */
  artistGenreIds?: string[];
  /** Localized presentation labels returned by the API; never submit as identity. */
  artistGenres?: string[];
  artistBio?: string | null;
  artistAvatarUrl?: string | null;
}

export interface SocialVenueDTO {
  venueId?: string | null;
  venueName: string;
  venueAddress?: string | null;
  venueCity?: string | null;
  venueCountry?: string | null;
  venueLat?: number | null;
  venueLng?: number | null;
  venueCapacity?: number | null;
  venueContact?: string | null;
  venuePhone?: string | null;
  venueWebsite?: string | null;
  venueState?: string | null;
  venueZipCode?: string | null;
  venueImageUrl?: string | null;
  venueCreatedAt?: string | null;
  venueUpdatedAt?: string | null;
}

export interface SocialEventDTO {
  eventId?: string | null;
  eventOrganizerPartyId?: string | null;
  eventTitle: string;
  eventDescription?: string | null;
  eventStart: string;
  eventEnd?: string | null;
  eventTimezone?: string | null;
  eventVenueId?: string | null;
  eventPriceCents?: number | null;
  eventCapacity?: number | null;
  eventTypeId?: string | null;
  eventWorkflowStateId?: string | null;
  eventWorkflowStateCode?: string | null;
  eventWorkflowStateNameEs?: string | null;
  eventWorkflowStateNameEn?: string | null;
  eventPublicListable?: boolean | null;
  eventRsvpEligible?: boolean | null;
  eventTicketPurchaseEnabled?: boolean | null;
  eventCurrency?: string | null;
  eventBudgetCents?: number | null;
  eventTicketUrl?: string | null;
  eventImageUrl?: string | null;
  eventIsPublic?: boolean | null;
  eventArtists: SocialArtistDTO[];
}

export interface PublicUpcomingEventDTO {
  publicUpcomingEventId: string;
  publicUpcomingEventTitle: string;
  publicUpcomingEventDescription?: string | null;
  publicUpcomingEventStart: string;
  publicUpcomingEventEnd?: string | null;
  publicUpcomingEventTimezone?: string | null;
  publicUpcomingEventVenueName?: string | null;
  publicUpcomingEventCity?: string | null;
  publicUpcomingEventPriceCents?: number | null;
  publicUpcomingEventCurrency?: string | null;
  publicUpcomingEventTicketUrl?: string | null;
  publicUpcomingEventImageUrl?: string | null;
  publicUpcomingEventWorkflowStateCode: string;
}

export interface SocialEventImageUploadDTO {
  eiuEventId: string;
  eiuFileName: string;
  eiuPath: string;
  eiuPublicUrl: string;
  eiuImageUrl: string;
}

export interface SocialEventMomentDTO {
  emId?: string | null;
  emEventId?: string | null;
  emAuthorPartyId?: string | null;
  emAuthorName: string;
  emCaption?: string | null;
  emMediaUrl: string;
  emMediaType: string;
  emMediaWidth?: number | null;
  emMediaHeight?: number | null;
  emMediaDurationMs?: number | null;
  emCreatedAt?: string | null;
  emUpdatedAt?: string | null;
}

export interface SocialEventMomentCreateDTO {
  emCreateAuthorName?: string;
  emCreateCaption?: string;
  emCreateMediaUrl: string;
  emCreateMediaType: 'image' | 'video' | 'audio' | 'text';
  emCreateMediaWidth?: number;
  emCreateMediaHeight?: number;
  emCreateMediaDurationMs?: number;
}

// An HTTP 200/HTML fallback is not a committed publication acknowledgement.
function confirmedMoment(value: unknown, eventId: string, momentId?: string): SocialEventMomentDTO {
  const row = value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : null;
  if (!row || typeof row['emId'] !== 'string' || !row['emId'].trim()
    || (momentId !== undefined && row['emId'] !== momentId)
    || (row['emEventId'] != null && row['emEventId'] !== eventId)
    || typeof row['emAuthorName'] !== 'string' || typeof row['emMediaUrl'] !== 'string'
    || typeof row['emMediaType'] !== 'string' || !['image', 'video', 'audio', 'text'].includes(row['emMediaType'])
    || (row['emCaption'] != null && typeof row['emCaption'] !== 'string')
    || (row['emMediaType'] === 'text' ? !String(row['emCaption'] ?? '').trim() : !row['emMediaUrl'].trim())) {
    throw new Error('No se pudo confirmar la publicación. Revisa el evento antes de reintentar; tu borrador se conserva.');
  }
  return value as SocialEventMomentDTO;
}

export interface SocialInvitationDTO {
  invitationId?: string | null;
  invitationEventId?: string | null;
  invitationFromPartyId?: string | null;
  invitationToPartyId: string;
  invitationStatus?: string | null;
  invitationMessage?: string | null;
  invitationCreatedAt?: string | null;
}

/** Canonical RSVP vocabulary. Normalize display labels only at the UI boundary. */
export type SocialRsvpStatus = 'accepted' | 'maybe' | 'declined';

export interface SocialRsvpDTO {
  rsvpEventId: string;
  rsvpStatus: SocialRsvpStatus;
  rsvpShowOnProfile: boolean;
  rsvpCreatedAt?: string | null;
  rsvpUpdatedAt?: string | null;
}

export interface SocialRsvpWriteDTO {
  rsvpStatus: SocialRsvpStatus;
  rsvpShowOnProfile: boolean;
}

export interface SocialRsvpSummaryDTO {
  rsvpAcceptedCount: number;
  rsvpMaybeCount: number;
}

export interface SocialRsvpFeedItemDTO {
  feedItemType: 'event_rsvp';
  feedEventId: string;
  feedStatus: Extract<SocialRsvpStatus, 'accepted' | 'maybe'>;
  feedShowOnProfile: true;
  feedEventTitle: string;
  feedEventStart: string;
  feedEventTimezone?: string | null;
  feedEventImageUrl?: string | null;
  feedVenueName?: string | null;
  feedCity?: string | null;
  feedWorkflowStateCode: string;
  feedActionAt: string;
  feedCanonicalUrl: string;
  feedCanEdit: boolean;
  feedCanShare: boolean;
}

export interface SocialRsvpFeedPageDTO {
  feedItems: SocialRsvpFeedItemDTO[];
  feedNextCursor?: string | null;
}

export interface SocialTicketTierDTO {
  ticketTierId?: string | null;
  ticketTierEventId?: string | null;
  ticketTierCode: string;
  ticketTierName: string;
  ticketTierDescription?: string | null;
  ticketTierPriceCents: number;
  ticketTierCurrency: string;
  ticketTierQuantityTotal: number;
  ticketTierQuantitySold: number;
  ticketTierSalesStart?: string | null;
  ticketTierSalesEnd?: string | null;
  ticketTierActive: boolean;
  ticketTierPosition?: number | null;
}

export interface SocialTicketPurchaseRequestDTO {
  ticketPurchaseTierId: string;
  ticketPurchaseQuantity: number;
  ticketPurchaseBuyerPartyId?: string | null;
  ticketPurchaseBuyerName?: string | null;
  ticketPurchaseBuyerEmail?: string | null;
}

export interface SocialTicketDTO {
  ticketId?: string | null;
  ticketEventId?: string | null;
  ticketTierId?: string | null;
  ticketOrderId?: string | null;
  ticketCode: string;
  ticketStatus: string;
  ticketHolderName?: string | null;
  ticketHolderEmail?: string | null;
  ticketCheckedInAt?: string | null;
  ticketCreatedAt?: string | null;
  ticketUpdatedAt?: string | null;
}

export interface SocialTicketOrderDTO {
  ticketOrderId?: string | null;
  ticketOrderEventId?: string | null;
  ticketOrderTierId?: string | null;
  ticketOrderBuyerPartyId?: string | null;
  ticketOrderBuyerName?: string | null;
  ticketOrderBuyerEmail?: string | null;
  ticketOrderQuantity: number;
  ticketOrderFaceValueCents: number;
  ticketOrderBuyerPlatformFeeCents: number;
  ticketOrderOrganizerPlatformFeeCents: number;
  ticketOrderAmountCents: number;
  ticketOrderCurrency: string;
  ticketOrderStatusValue: string;
  ticketOrderPurchasedAt?: string | null;
  ticketOrderCreatedAt?: string | null;
  ticketOrderUpdatedAt?: string | null;
  ticketOrderTickets: SocialTicketDTO[];
}

export interface SocialEventBudgetLineDTO {
  eblId?: string | null;
  eblEventId?: string | null;
  eblCode: string;
  eblName: string;
  eblType: string;
  eblCategory: string;
  eblPlannedCents: number;
  eblActualCents?: number | null;
  eblNotes?: string | null;
  eblCreatedAt?: string | null;
  eblUpdatedAt?: string | null;
}

export interface SocialEventFinanceEntryDTO {
  efeId?: string | null;
  efeEventId?: string | null;
  efeBudgetLineId?: string | null;
  efeDirection: string;
  efeSource: string;
  efeCategory: string;
  efeConcept: string;
  efeAmountCents: number;
  efeCurrency: string;
  efeStatus: string;
  efeExternalRef?: string | null;
  efeNotes?: string | null;
  efeOccurredAt: string;
  efeRecordedByPartyId?: string | null;
  efeCreatedAt?: string | null;
  efeUpdatedAt?: string | null;
}

export interface SocialEventFinanceSummaryDTO {
  efsEventId: string;
  efsCurrency: string;
  efsBudgetCents?: number | null;
  efsPlannedIncomeCents: number;
  efsPlannedExpenseCents: number;
  efsActualIncomeCents: number;
  efsActualExpenseCents: number;
  efsNetCents: number;
  efsTicketPaidRevenueCents: number;
  efsTicketRefundedRevenueCents: number;
  efsTicketPendingRevenueCents: number;
  efsAccountsPayableCents?: number;
  efsAccountsReceivableCents?: number;
  efsContractCommittedCents?: number;
  efsContractPaidCents?: number;
  efsProcurementCommittedCents?: number;
  efsProcurementPaidCents?: number;
  efsAssetInvestmentCents?: number;
  efsLiabilityBalanceCents?: number;
  efsBudgetVarianceCents?: number | null;
  efsBudgetUtilizationPct?: number | null;
  efsGeneratedAt: string;
}

export type LogisticsAccessRole = 'owner' | 'editor' | 'viewer';
export type LogisticsActivityType = 'task' | 'milestone' | 'wait' | 'travel';
export type LogisticsTravelMode = 'drive' | 'walk' | 'bicycle' | 'two_wheeler' | 'transit';

export interface EventLogisticsSettingsDTO {
  elsTimezone: string;
  elsDefaultTravelMode: LogisticsTravelMode;
}

export interface EventLogisticsMemberDTO {
  elmPartyId: string;
  elmDisplayName?: string | null;
  elmEmail?: string | null;
  elmRole: 'editor' | 'viewer';
  elmCreatedAt?: string | null;
}

export interface EventLogisticsPlaceDTO {
  elpId?: string | null;
  elpVenueId?: string | null;
  elpLabel: string;
  elpType: 'venue' | 'hotel' | 'airport' | 'pickup' | 'custom';
  elpAddress?: string | null;
  elpGooglePlaceId?: string | null;
  elpLatitude: number;
  elpLongitude: number;
  elpInstructions?: string | null;
  elpContactName?: string | null;
  elpContactPhone?: string | null;
  elpCreatedAt?: string | null;
  elpUpdatedAt?: string | null;
}

export interface EventLogisticsAssignmentDTO {
  elaPartyId?: string | null;
  elaDisplayName?: string | null;
  elaExternalName?: string | null;
  elaExternalPhone?: string | null;
  elaExternalEmail?: string | null;
}

export interface EventRouteVerificationDTO {
  ervId?: string | null;
  ervActivityVersion: number;
  ervProvider: string;
  ervTravelMode: LogisticsTravelMode;
  ervDepartureTime: string;
  ervDurationSeconds?: number | null;
  ervStaticDurationSeconds?: number | null;
  ervDistanceMeters?: number | null;
  ervBufferSeconds: number;
  ervAllocatedSeconds: number;
  ervVerdict: 'feasible' | 'tight' | 'infeasible' | 'provisional' | 'unavailable' | 'stale';
  ervEncodedPolyline?: string | null;
  ervErrorMessage?: string | null;
  ervCheckpoint?: string | null;
  ervVerifiedAt: string;
}

export interface EventLogisticsActivityDTO {
  eacId?: string | null;
  eacType: LogisticsActivityType;
  eacTitle: string;
  eacNotes?: string | null;
  eacStart: string;
  eacEnd?: string | null;
  eacPlaceId?: string | null;
  eacOriginPlaceId?: string | null;
  eacDestinationPlaceId?: string | null;
  eacTravelMode?: LogisticsTravelMode | null;
  eacBufferMinutes?: number | null;
  eacPriority: 'low' | 'normal' | 'high' | 'critical';
  eacStatus: 'planned' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled';
  eacVersion?: number | null;
  eacAssignments: EventLogisticsAssignmentDTO[];
  eacDependencyIds: string[];
  eacLatestVerification?: EventRouteVerificationDTO | null;
  eacCreatedAt?: string | null;
  eacUpdatedAt?: string | null;
}

export interface EventScheduleIssueDTO {
  esiCode: string;
  esiSeverity: 'warning' | 'error';
  esiActivityId?: string | null;
  esiMessage: string;
}

export interface EventLogisticsPlanDTO {
  elgEventId: string;
  elgAccessRole: LogisticsAccessRole;
  elgSettings: EventLogisticsSettingsDTO;
  elgMembers: EventLogisticsMemberDTO[];
  elgPlaces: EventLogisticsPlaceDTO[];
  elgActivities: EventLogisticsActivityDTO[];
  elgIssues: EventScheduleIssueDTO[];
}

// Promo Codes
export interface PromoCodeDTO {
  promoCodeId?: string | null;
  promoCodeEventId?: string | null;
  promoCodeCode: string;
  promoCodeDescription?: string | null;
  promoCodeDiscountType: 'percentage' | 'fixed';
  promoCodeDiscountValue: number;
  promoCodeCurrency: string;
  promoCodeMaxRedemptions?: number | null;
  promoCodeCurrentRedemptions: number;
  promoCodeValidFrom?: string | null;
  promoCodeValidUntil?: string | null;
  promoCodeTierIds?: string[] | null;
  promoCodeMinPurchaseAmountCents?: number | null;
  promoCodeIsActive: boolean;
  promoCodeCreatedAt?: string | null;
  promoCodeUpdatedAt?: string | null;
}

export interface TicketPurchaseWithPromoDTO {
  ticketPurchaseTierId: string;
  ticketPurchaseQuantity: number;
  ticketPurchaseBuyerPartyId?: string | null;
  ticketPurchaseBuyerName?: string | null;
  ticketPurchaseBuyerEmail?: string | null;
  ticketPurchasePromoCode?: string | null;
  ticketPurchaseMobileSdkStripeVersion?: string | null;
  /** Terms version of the event's approved ticket policy that the buyer accepted. */
  ticketPurchaseAcceptedTermsVersion?: string | null;
}

export interface StripePaymentIntentDTO {
  spiClientSecret: string;
  spiPaymentIntentId?: string | null;
  spiOrderId: string;
  spiAmountCents: number;
  spiCurrency: string;
}

// Manual bank transfer review
export interface TicketManualPaymentDTO {
  tmpOrderId: string;
  tmpPaymentReference: string;
  tmpBuyerName?: string | null;
  tmpBuyerEmail?: string | null;
  tmpQuantity: number;
  tmpAmountMinor: number;
  tmpCurrency: string;
  tmpEvidenceStatus: 'awaiting_evidence' | 'submitted' | 'under_review' | 'approved' | 'rejected';
  tmpCustomerReference?: string | null;
  tmpHasReceipt?: boolean;
  tmpSubmittedAt?: string | null;
  tmpReviewedAt?: string | null;
  tmpReviewNotes?: string | null;
  tmpCheckoutStatus: string;
  tmpHoldExpiresAt: string;
}

export interface TicketTaxDocumentDTO {
  ttdId: string;
  ttdKind: 'invoice' | 'credit_note';
  ttdOrderId: string;
  ttdNumber: string;
  ttdStatus: 'pending' | 'submitted' | 'authorized' | 'rejected' | 'uncertain' | 'failed';
  ttdAmountMinor: number;
  ttdAccessKey?: string | null;
  ttdAuthorizationNumber?: string | null;
  ttdAuthorizedAt?: string | null;
  ttdLastError?: string | null;
  ttdEnvironment: string;
  ttdCreatedAt: string;
}

export interface TicketManualPaymentReviewDTO {
  tmprAction: 'approve' | 'reject';
  tmprNotes: string;
}

// Refunds
export interface RefundRequestDTO {
  refundRequestReason?: string | null;
}

export interface RefundDTO {
  refundId?: string | null;
  refundOrderId?: string | null;
  refundRequestedByPartyId?: string | null;
  refundReason?: string | null;
  refundAmountCents: number;
  refundCurrency?: string | null;
  refundStatus: string;
  refundApprovedByPartyId?: string | null;
  refundApprovedAt?: string | null;
  refundRejectionReason?: string | null;
  refundStripeRefundId?: string | null;
  refundProcessedAt?: string | null;
  refundCreatedAt?: string | null;
  refundUpdatedAt?: string | null;
}

export interface RejectionReasonDTO {
  rrReason: string;
}

// Transfers
export interface TicketTransferCreateDTO {
  ttcToEmail: string;
  ttcToName?: string | null;
  ttcMessage?: string | null;
}

export interface TicketTransferDTO {
  ticketTransferId?: string | null;
  ticketTransferTicketId?: string | null;
  ticketTransferFromPartyId?: string | null;
  ticketTransferToEmail: string;
  ticketTransferToName?: string | null;
  ticketTransferMessage?: string | null;
  ticketTransferCode: string;
  ticketTransferStatus: string;
  ticketTransferAcceptedAt?: string | null;
  ticketTransferExpiresAt?: string | null;
  ticketTransferCreatedAt?: string | null;
  ticketTransferUpdatedAt?: string | null;
}

// Waitlist
export interface WaitlistJoinDTO {
  wjEmail: string;
  wjName?: string | null;
  wjTierId?: string | null;
  wjQuantity: number;
}

export interface WaitlistEntryDTO {
  waitlistId?: string | null;
  waitlistEventId?: string | null;
  waitlistEmail: string;
  waitlistName?: string | null;
  waitlistTierId?: string | null;
  waitlistQuantity: number;
  waitlistStatus: string;
  waitlistPriority: number;
  waitlistNotifiedAt?: string | null;
  waitlistExpiresAt?: string | null;
  waitlistCreatedAt?: string | null;
}

// QR Codes
export interface TicketWithQRDTO {
  twqTicket: SocialTicketDTO;
  twqQRData: string;
  twqQRImageUrl?: string | null;
}

type RequestWithoutBody = (path: string) => Promise<unknown>;
type GetRequest = (path: string, init?: RequestInit) => Promise<unknown>;
type RequestWithBody = (path: string, body: unknown) => Promise<unknown>;
type FormRequest = (path: string, form: FormData) => Promise<unknown>;

const getUnknown: GetRequest = get;
const delUnknown: RequestWithoutBody = del;
const postUnknown: RequestWithBody = post;
const putUnknown: RequestWithBody = put;
const postFormUnknown: FormRequest = postForm;

const normalizeComparableId = (value: string | null | undefined): string => {
  const trimmed = value?.trim() ?? '';
  if (!trimmed) return '';

  if (/^-?\d+$/.test(trimmed)) {
    const parsed = Number.parseInt(trimmed, 10);
    if (Number.isSafeInteger(parsed)) return String(parsed);
  }

  return trimmed;
};

type QueryParams = Record<string, string | number | null | undefined>;

interface SocialInvitationCreatePayload {
  invitationToPartyId: string;
  invitationMessage?: string | null;
}

const buildQuery = (params: QueryParams) => {
  const entries = Object.entries(params)
    .map((entry): [string, string | number] | null => {
      const [key, value] = entry;
      if (value == null) return null;
      if (typeof value === 'string') {
        const trimmed = value.trim();
        if (!trimmed) return null;
        return [key, trimmed];
      }
      return [key, value];
    })
    .filter((entry): entry is [string, string | number] => entry !== null);
  if (!entries.length) return '';
  const qs = entries.map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`).join('&');
  return `?${qs}`;
};

export const SocialEventsAPI = {
  listPublicUpcomingEvents: async (opts?: { city?: string; startAfter?: string; limit?: number; signal?: AbortSignal }) => {
    const qs = buildQuery({ city: opts?.city, startAfter: opts?.startAfter, limit: opts?.limit });
    const path = `/social-events/upcoming${qs}`;
    return await (opts?.signal ? getUnknown(path, { signal: opts.signal }) : getUnknown(path)) as PublicUpcomingEventDTO[];
  },
  listEvents: async (opts?: { city?: string; startAfter?: string; eventTypeId?: string; workflowStateId?: string; artistId?: string; venueId?: string }) => {
    const qs = buildQuery({
      city: opts?.city,
      start_after: opts?.startAfter,
      event_type_id: opts?.eventTypeId,
      workflow_state_id: opts?.workflowStateId,
      artistId: opts?.artistId,
      venueId: opts?.venueId,
    });
    return await getUnknown(`/social-events/events${qs}`) as SocialEventDTO[];
  },
  createEvent: async (payload: SocialEventDTO) =>
    await postUnknown('/social-events/events', payload) as SocialEventDTO,
  updateEvent: async (eventId: string, payload: SocialEventDTO) =>
    await putUnknown(`/social-events/events/${encodeURIComponent(eventId)}`, payload) as SocialEventDTO,
  deleteEvent: async (eventId: string) =>
    await delUnknown(`/social-events/events/${encodeURIComponent(eventId)}`),
  uploadEventImage: async (eventId: string, file: File, name?: string) => {
    const form = new FormData();
    form.append('file', file);
    const trimmed = name?.trim() ?? '';
    if (trimmed) form.append('name', trimmed);
    return await postFormUnknown(`/social-events/events/${encodeURIComponent(eventId)}/image`, form) as SocialEventImageUploadDTO;
  },
  editMoment: async (eventId: string, momentId: string, caption: string, expectedUpdatedAt: string) =>
    confirmedMoment(await put<unknown>(`/social-events/events/${encodeURIComponent(eventId)}/moments/${encodeURIComponent(momentId)}`, { emeCaption: caption, emeExpectedUpdatedAt: expectedUpdatedAt }), eventId, momentId),
  deleteMoment: async (eventId: string, momentId: string) => {
    const result = await del<unknown>(`/social-events/events/${encodeURIComponent(eventId)}/moments/${encodeURIComponent(momentId)}`);
    if (result !== undefined) throw new Error('No se pudo confirmar la eliminación. Actualiza el evento antes de reintentar.');
  },
  listMoments: async (eventId: string) =>
    await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/moments?extended`) as SocialEventMomentDTO[],
  createMoment: async (eventId: string, payload: SocialEventMomentCreateDTO) =>
    confirmedMoment(await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/moments`, payload), eventId),
  uploadMomentMedia: (eventId: string, file: File) => {
    const form = new FormData(); form.append('file', file);
    return postForm<SocialEventImageUploadDTO>(`/social-events/events/${encodeURIComponent(eventId)}/moments/media`, form);
  },
  uploadMomentImage: async (eventId: string, file: File, name?: string) => {
    const form = new FormData();
    form.append('file', file);
    const trimmed = name?.trim() ?? '';
    if (trimmed) form.append('name', trimmed);
    return await postFormUnknown(`/social-events/events/${encodeURIComponent(eventId)}/moments/image`, form) as SocialEventImageUploadDTO;
  },
  getEvent: async (eventId: string) =>
    await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}`) as SocialEventDTO,
  listVenues: async (opts?: { city?: string }) => {
    const qs = buildQuery({ city: opts?.city });
    return await getUnknown(`/social-events/venues${qs}`) as SocialVenueDTO[];
  },
  listInvitations: async (eventId: string) =>
    await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/invitations`) as SocialInvitationDTO[],
  sendInvitation: async (eventId: string, payload: SocialInvitationCreatePayload) =>
    await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/invitations`, {
      invitationEventId: eventId,
      invitationToPartyId: payload.invitationToPartyId,
      invitationMessage: payload.invitationMessage ?? null,
      invitationStatus: 'Pending',
    }) as SocialInvitationDTO,
  respondInvitation: async (eventId: string, invitationId: string, status: string, message?: string | null) => {
    const normalizedEventId = eventId.trim();
    const normalizedInvitationId = invitationId.trim();
    if (!normalizedEventId) {
      throw new Error('eventId is required to respond to an invitation.');
    }
    if (!normalizedInvitationId) {
      throw new Error('invitationId is required to respond to an invitation.');
    }

    const invitations = await getUnknown(
      `/social-events/events/${encodeURIComponent(normalizedEventId)}/invitations`,
    ) as SocialInvitationDTO[];
    const invitationKey = normalizeComparableId(normalizedInvitationId);
    const invitation = invitations.find(
      (candidate) => normalizeComparableId(candidate.invitationId) === invitationKey,
    );
    if (!invitation) {
      throw new Error(`Invitation ${normalizedInvitationId} not found for event ${normalizedEventId}.`);
    }
    const invitationToPartyId = invitation.invitationToPartyId?.trim() ?? '';
    if (!invitationToPartyId) {
      throw new Error(`Invitation ${normalizedInvitationId} is missing invitationToPartyId.`);
    }
    const invitationPathId = normalizeComparableId(invitation.invitationId) || invitationKey;

    return await putUnknown(
      `/social-events/events/${encodeURIComponent(normalizedEventId)}/invitations/${encodeURIComponent(invitationPathId)}`,
      {
        invitationToPartyId,
        invitationStatus: status,
        ...(message === undefined ? {} : { invitationMessage: message }),
      },
    ) as SocialInvitationDTO;
  },
  listTicketTiers: async (eventId: string) =>
    await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/ticket-tiers`) as SocialTicketTierDTO[],
  createTicketTier: async (eventId: string, payload: SocialTicketTierDTO) =>
    await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/ticket-tiers`, payload) as SocialTicketTierDTO,
  updateTicketTier: async (eventId: string, tierId: string, payload: SocialTicketTierDTO) =>
    await putUnknown(`/social-events/events/${encodeURIComponent(eventId)}/ticket-tiers/${encodeURIComponent(tierId)}`, payload) as SocialTicketTierDTO,
  listTicketOrders: async (eventId: string, opts?: { buyerPartyId?: string; status?: string }) => {
    const qs = buildQuery({ buyerPartyId: opts?.buyerPartyId, status: opts?.status });
    return await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/ticket-orders${qs}`) as SocialTicketOrderDTO[];
  },
  buyTickets: async (eventId: string, payload: SocialTicketPurchaseRequestDTO) =>
    await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/ticket-orders`, payload) as SocialTicketOrderDTO,
  updateTicketOrderStatus: async (eventId: string, orderId: string, status: string) =>
    await putUnknown(`/social-events/events/${encodeURIComponent(eventId)}/ticket-orders/${encodeURIComponent(orderId)}/status`, {
      ticketOrderStatus: status,
    }) as SocialTicketOrderDTO,
  listTickets: async (eventId: string, opts?: { orderId?: string; status?: string }) => {
    const qs = buildQuery({ orderId: opts?.orderId, status: opts?.status });
    return await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/tickets${qs}`) as SocialTicketDTO[];
  },
  checkInTicket: async (eventId: string, payload: { ticketCheckInTicketId?: string | null; ticketCheckInTicketCode?: string | null }) =>
    await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/tickets/check-in`, payload) as SocialTicketDTO,
  listBudgetLines: async (eventId: string) =>
    (await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/budget-lines`) as SocialEventBudgetLineDTO[]).map(assertSafeEventFinanceMoney),
  createBudgetLine: async (eventId: string, payload: SocialEventBudgetLineDTO) =>
    await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/budget-lines`, payload) as SocialEventBudgetLineDTO,
  updateBudgetLine: async (eventId: string, lineId: string, payload: SocialEventBudgetLineDTO) =>
    await putUnknown(`/social-events/events/${encodeURIComponent(eventId)}/budget-lines/${encodeURIComponent(lineId)}`, payload) as SocialEventBudgetLineDTO,
  listFinanceEntries: async (eventId: string, opts?: { direction?: string; source?: string; status?: string }) => {
    const qs = buildQuery({ direction: opts?.direction, source: opts?.source, status: opts?.status });
    return (await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/finance-entries${qs}`) as SocialEventFinanceEntryDTO[]).map(assertSafeEventFinanceMoney);
  },
  createFinanceEntry: async (eventId: string, payload: SocialEventFinanceEntryDTO) =>
    await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/finance-entries`, payload) as SocialEventFinanceEntryDTO,
  updateFinanceEntry: async (eventId: string, entryId: string, payload: SocialEventFinanceEntryDTO) =>
    await putUnknown(`/social-events/events/${encodeURIComponent(eventId)}/finance-entries/${encodeURIComponent(entryId)}`, payload) as SocialEventFinanceEntryDTO,
  getFinanceSummary: async (eventId: string) =>
    assertSafeEventFinanceMoney(await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/finance-summary`) as SocialEventFinanceSummaryDTO),
  getLogisticsPlan: async (eventId: string) =>
    await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/logistics`) as EventLogisticsPlanDTO,
  updateLogisticsSettings: async (eventId: string, payload: EventLogisticsSettingsDTO) =>
    await putUnknown(`/social-events/events/${encodeURIComponent(eventId)}/logistics/settings`, payload) as EventLogisticsSettingsDTO,
  createLogisticsMember: async (eventId: string, payload: EventLogisticsMemberDTO) =>
    await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/logistics/members`, payload) as EventLogisticsMemberDTO,
  updateLogisticsMember: async (eventId: string, partyId: string, payload: EventLogisticsMemberDTO) =>
    await putUnknown(`/social-events/events/${encodeURIComponent(eventId)}/logistics/members/${encodeURIComponent(partyId)}`, payload) as EventLogisticsMemberDTO,
  deleteLogisticsMember: async (eventId: string, partyId: string) =>
    await delUnknown(`/social-events/events/${encodeURIComponent(eventId)}/logistics/members/${encodeURIComponent(partyId)}`),
  createLogisticsPlace: async (eventId: string, payload: EventLogisticsPlaceDTO) =>
    await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/logistics/places`, payload) as EventLogisticsPlaceDTO,
  updateLogisticsPlace: async (eventId: string, placeId: string, payload: EventLogisticsPlaceDTO) =>
    await putUnknown(`/social-events/events/${encodeURIComponent(eventId)}/logistics/places/${encodeURIComponent(placeId)}`, payload) as EventLogisticsPlaceDTO,
  deleteLogisticsPlace: async (eventId: string, placeId: string) =>
    await delUnknown(`/social-events/events/${encodeURIComponent(eventId)}/logistics/places/${encodeURIComponent(placeId)}`),
  createLogisticsActivity: async (eventId: string, payload: EventLogisticsActivityDTO) =>
    await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/logistics/activities`, payload) as EventLogisticsActivityDTO,
  updateLogisticsActivity: async (eventId: string, activityId: string, payload: EventLogisticsActivityDTO) =>
    await putUnknown(`/social-events/events/${encodeURIComponent(eventId)}/logistics/activities/${encodeURIComponent(activityId)}`, payload) as EventLogisticsActivityDTO,
  deleteLogisticsActivity: async (eventId: string, activityId: string) =>
    await delUnknown(`/social-events/events/${encodeURIComponent(eventId)}/logistics/activities/${encodeURIComponent(activityId)}`),
  verifyLogisticsRoute: async (eventId: string, activityId: string) =>
    await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/logistics/activities/${encodeURIComponent(activityId)}/verify-route`, {}) as EventRouteVerificationDTO,
  verifyAllLogisticsRoutes: async (eventId: string) =>
    await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/logistics/verify-routes`, {}) as EventRouteVerificationDTO[],
  getMyRsvp: async (eventId: string) =>
    await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/rsvp`) as SocialRsvpDTO | null,
  getRsvpSummary: async (eventId: string) =>
    await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/rsvp-summary`) as SocialRsvpSummaryDTO,
  upsertMyRsvp: async (eventId: string, input: SocialRsvpWriteDTO) =>
    await putUnknown(`/social-events/events/${encodeURIComponent(eventId)}/rsvp`, input) as SocialRsvpDTO,
  deleteMyRsvp: async (eventId: string) =>
    await delUnknown(`/social-events/events/${encodeURIComponent(eventId)}/rsvp`),
  listRsvpFeed: async (partyId: string, cursor?: string, limit = 20) => {
    const query = buildQuery({ cursor, limit });
    return await getUnknown(`/social-events/profiles/${encodeURIComponent(partyId)}/rsvp-feed${query}`) as SocialRsvpFeedPageDTO;
  },
  listDirectoryProfileRsvpFeed: async (slug: string, cursor?: string, limit = 20) => {
    const query = buildQuery({ cursor, limit });
    return await getUnknown(`/social-events/directory-profiles/${encodeURIComponent(slug)}/rsvp-feed${query}`) as SocialRsvpFeedPageDTO;
  },
  // Promo Codes
  listPromoCodes: async (eventId: string) =>
    await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/promo-codes`) as PromoCodeDTO[],
  createPromoCode: async (eventId: string, data: PromoCodeDTO) =>
    await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/promo-codes`, data) as PromoCodeDTO,
  updatePromoCode: async (eventId: string, codeId: string, data: PromoCodeDTO) =>
    await putUnknown(`/social-events/events/${encodeURIComponent(eventId)}/promo-codes/${encodeURIComponent(codeId)}`, data) as PromoCodeDTO,
  validatePromoCode: async (eventId: string, codeId: string, code?: string, tierId?: string) => {
    const query = buildQuery({ code, tierId });
    return await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/promo-codes/${encodeURIComponent(codeId)}/validate${query}`) as PromoCodeDTO;
  },
  // Stripe Payment
  createPaymentIntent: async (data: TicketPurchaseWithPromoDTO) =>
    await postUnknown('/social-events/stripe/create-payment-intent', data) as StripePaymentIntentDTO,
  // Refunds
  requestRefund: async (eventId: string, orderId: string, data: RefundRequestDTO) =>
    await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/ticket-orders/${encodeURIComponent(orderId)}/refund`, data) as RefundDTO,
  listRefunds: async (eventId: string) =>
    await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/refunds`) as RefundDTO[],
  approveRefund: async (eventId: string, refundId: string) =>
    await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/refunds/${encodeURIComponent(refundId)}/approve`, {}) as RefundDTO,
  rejectRefund: async (eventId: string, refundId: string, data: RejectionReasonDTO) =>
    await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/refunds/${encodeURIComponent(refundId)}/reject`, data) as RefundDTO,
  // Manual bank transfer review
  listManualPayments: async (eventId: string) =>
    await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/manual-payments`) as TicketManualPaymentDTO[],
  getManualPaymentReceipt: async (eventId: string, orderId: string) =>
    await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/ticket-orders/${encodeURIComponent(orderId)}/manual-payment/receipt`) as { contentType: string; base64: string },
  reviewManualPayment: async (eventId: string, orderId: string, data: TicketManualPaymentReviewDTO) =>
    await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/ticket-orders/${encodeURIComponent(orderId)}/manual-payment/review`, data) as TicketManualPaymentDTO,
  completeBankTransferRefund: async (eventId: string, refundId: string, reference: string) =>
    await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/refunds/${encodeURIComponent(refundId)}/bank-transfer-complete`, { brcReference: reference }) as RefundDTO,
  // SRI electronic invoices
  listTaxDocuments: async (eventId: string) =>
    await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/tax-documents`) as TicketTaxDocumentDTO[],
  retryTaxDocument: async (eventId: string, documentId: string) =>
    await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/tax-documents/${encodeURIComponent(documentId)}/retry`, {}) as TicketTaxDocumentDTO[],
  // Transfers
  createTransfer: async (eventId: string, ticketId: string, data: TicketTransferCreateDTO) =>
    await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/tickets/${encodeURIComponent(ticketId)}/transfer`, data) as TicketTransferDTO,
  listTransfers: async (eventId: string, ticketId: string) =>
    await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/tickets/${encodeURIComponent(ticketId)}/transfers`) as TicketTransferDTO[],
  acceptTransfer: async (transferCode: string) =>
    await postUnknown(`/social-events/ticket-transfers/${encodeURIComponent(transferCode)}/accept`, {}) as SocialTicketDTO,
  cancelTransfer: async (transferCode: string) =>
    await postUnknown(`/social-events/ticket-transfers/${encodeURIComponent(transferCode)}/cancel`, {}) as TicketTransferDTO,
  // Waitlist
  joinWaitlist: async (eventId: string, data: WaitlistJoinDTO) =>
    await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/waitlist`, data) as WaitlistEntryDTO,
  listWaitlist: async (eventId: string, tierId?: string) => {
    const waitlistQuery = buildQuery({ tierId });
    return await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/waitlist${waitlistQuery}`) as WaitlistEntryDTO[];
  },
  notifyWaitlist: async (eventId: string, entryId: string) =>
    await postUnknown(`/social-events/events/${encodeURIComponent(eventId)}/waitlist/${encodeURIComponent(entryId)}/notify`, {}) as WaitlistEntryDTO,
  removeFromWaitlist: async (eventId: string, entryId: string) => {
    await delUnknown(`/social-events/events/${encodeURIComponent(eventId)}/waitlist/${encodeURIComponent(entryId)}`);
  },
  // QR Codes
  getTicketQR: async (eventId: string, ticketId: string) =>
    await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/tickets/${encodeURIComponent(ticketId)}/qr`) as TicketWithQRDTO,
};
