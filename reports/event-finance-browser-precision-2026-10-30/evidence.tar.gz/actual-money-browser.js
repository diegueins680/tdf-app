"use strict";
var EventFinanceMoney = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // ../../../../private/tmp/tdf-event-finance-browser-precision-fix-20261030/tdf-hq-ui/src/utils/eventFinanceMoney.ts
  var eventFinanceMoney_exports = {};
  __export(eventFinanceMoney_exports, {
    assertSafeEventFinanceMoney: () => assertSafeEventFinanceMoney,
    formatEventMoney: () => formatEventMoney
  });

  // <define:import.meta.env>
  var define_import_meta_env_default = {};

  // ../../../../private/tmp/tdf-event-finance-browser-precision-fix-20261030/tdf-hq-ui/src/utils/formatters.ts
  var LOCALE_PREFERENCES_STORAGE_KEY = "tdf-hq-ui/locale-preferences";
  function readStoredLocalePreferences() {
    if (typeof window === "undefined") return null;
    let rawPreferences;
    try {
      rawPreferences = window.localStorage.getItem(LOCALE_PREFERENCES_STORAGE_KEY);
    } catch {
      return null;
    }
    if (rawPreferences === null) return null;
    let parsedPreferences;
    try {
      parsedPreferences = JSON.parse(rawPreferences);
    } catch {
      return null;
    }
    if (parsedPreferences === null || typeof parsedPreferences !== "object" || Array.isArray(parsedPreferences)) {
      return null;
    }
    return parsedPreferences;
  }
  function browserFormatOptions() {
    const resolved = Intl.DateTimeFormat().resolvedOptions();
    const documentLocale = typeof document === "undefined" ? "" : document.documentElement.lang.trim();
    return {
      locale: documentLocale || resolved.locale || (typeof navigator === "undefined" ? "en" : navigator.language) || "en",
      timeZone: resolved.timeZone || "UTC"
    };
  }
  function resolveRuntimeFormatOptions() {
    const fallbackFormatOptions = browserFormatOptions();
    const storedFormatPreferences = readStoredLocalePreferences();
    if (!storedFormatPreferences) return fallbackFormatOptions;
    try {
      const locale = typeof storedFormatPreferences.locale === "string" && storedFormatPreferences.locale.trim() ? storedFormatPreferences.locale.trim() : fallbackFormatOptions.locale;
      const timeZone = typeof storedFormatPreferences.timezone === "string" && storedFormatPreferences.timezone.trim() ? storedFormatPreferences.timezone.trim() : fallbackFormatOptions.timeZone;
      new Intl.DateTimeFormat(locale, { timeZone }).format(0);
      return { locale, timeZone };
    } catch {
      return fallbackFormatOptions;
    }
  }
  function resolveRuntimeCurrency() {
    const fallbackCurrency = (define_import_meta_env_default?.VITE_DEFAULT_CURRENCY ?? "USD").trim().toUpperCase() || "USD";
    const storedCurrencyPreferences = readStoredLocalePreferences();
    return typeof storedCurrencyPreferences?.currency === "string" && /^[A-Za-z]{3}$/.test(storedCurrencyPreferences.currency.trim()) ? storedCurrencyPreferences.currency.trim().toUpperCase() : fallbackCurrency;
  }

  // ../../../../private/tmp/tdf-event-finance-browser-precision-fix-20261030/tdf-hq-ui/src/utils/eventFinanceMoney.ts
  var PRECISION_ERROR = "El importe excede la precisi\xF3n admitida por el navegador o no contiene centavos enteros.";
  function assertSafeEventFinanceMoney(value) {
    for (const [field, amount] of Object.entries(value)) {
      if (field.endsWith("Cents") && amount != null && !Number.isSafeInteger(amount)) {
        throw new Error(PRECISION_ERROR);
      }
    }
    return value;
  }
  var formatEventMoney = (amountCents, currency) => {
    if (typeof amountCents !== "number") return "Gratis";
    if (!Number.isSafeInteger(amountCents)) return "Monto no disponible";
    const locale = resolveRuntimeFormatOptions().locale;
    const formatter = new Intl.NumberFormat(locale, {
      style: "currency",
      currency: (currency ?? resolveRuntimeCurrency()).toUpperCase()
    });
    const digits = formatter.resolvedOptions().maximumFractionDigits ?? 0;
    const scale = 10n ** BigInt(digits);
    const cents = BigInt(amountCents);
    const negative = cents < 0n || Object.is(amountCents, -0);
    const magnitude = cents < 0n ? -cents : cents;
    const divisor = 10n ** BigInt(Math.max(0, 2 - digits));
    const units = digits >= 2 ? magnitude * 10n ** BigInt(digits - 2) : (magnitude + divisor / 2n) / divisor;
    const whole = units / scale;
    const signedWhole = negative ? whole === 0n ? -0 : -whole : whole;
    const fraction = digits > 0 ? new Intl.NumberFormat(locale, {
      useGrouping: false,
      minimumIntegerDigits: digits,
      maximumFractionDigits: 0
    }).format(units % scale) : "";
    return formatter.formatToParts(signedWhole).map((part) => part.type === "fraction" ? fraction : part.value).join("");
  };
  return __toCommonJS(eventFinanceMoney_exports);
})();
