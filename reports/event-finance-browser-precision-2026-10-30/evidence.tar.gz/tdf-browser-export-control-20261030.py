from pathlib import Path
import os,sys,subprocess,shutil,re,json
w=Path('/private/tmp/tdf-event-finance-browser-precision-fix-20261030');o=Path('/private/tmp/tdf-event-finance-browser-precision-qualification-20261030');label=sys.argv[1];v=Path('/private/tmp/tdf-browser-precision-controls-20261030')/label;assert not v.exists();v.mkdir();shutil.copytree(w/'tdf-hq-ui',v/'tdf-hq-ui',ignore=shutil.ignore_patterns('node_modules','dist','.git'))
(v/'tdf-hq/assets').mkdir(parents=True);shutil.copy2(w/'tdf-hq/assets/feature-registry.json',v/'tdf-hq/assets/feature-registry.json')
for name in ['package.json','package-lock.json']:shutil.copy2(w/name,v/name)
if label=='export-wiring-removed':
 p=v/'tdf-hq-ui/src/pages/SocialEventsPage.tsx';s=p.read_text();block='                                    disabled={\n                                      budgetLineQueries[index]?.data == null ||\n                                      financeEntryQueries[index]?.data == null ||\n                                      Boolean(budgetLineQueries[index]?.error) ||\n                                      Boolean(financeEntryQueries[index]?.error)\n                                    }\n';assert s.count(block)==1;p.write_text(s.replace(block,''))
e={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','LANG','LC_ALL']};e['PATH']='/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin';made=[]
try:
 for name in ['node_modules','tdf-hq-ui/node_modules']:
  p,t=v/name,Path('/private/tmp/tdf-correctness-cycle-20261028')/name;p.symlink_to(t,target_is_directory=True);made.append((p,t))
 with (o/(label+'.log')).open('w') as log:r=subprocess.run(['npm','test','--','--runTestsByPath','src/pages/SocialEventsPage.finance.test.tsx'],cwd=v/'tdf-hq-ui',env=e,stdout=log,stderr=subprocess.STDOUT,timeout=240)
finally:
 for p,t in reversed(made):assert p.is_symlink() and p.resolve()==t.resolve();p.unlink()
raw=(o/(label+'.log')).read_text();matches=re.findall(r'Tests:\s+(?:(\d+) failed, )?(\d+) passed, (\d+) total',raw);assert matches and 'Test suite failed to run' not in raw,raw[-1800:];f,p,t=matches[-1];row={'label':label,'actualExit':r.returncode,'failed':int(f or 0),'passed':int(p),'total':int(t),'actualPageMounted':True,'sourceCopy':str(v),'aliasesRemoved':True};(o/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row))
assert (r.returncode==1 and row['failed']==6 and row['passed']==2) if label=='export-wiring-removed' else (r.returncode==1 and row['failed']==6 and row['passed']==1) if label=='export-without-list-admission' else (r.returncode==0 and row['failed']==0 and row['passed']==8)
