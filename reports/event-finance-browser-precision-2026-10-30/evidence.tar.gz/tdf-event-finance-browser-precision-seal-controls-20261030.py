from pathlib import Path
import ast,json,hashlib,copy,subprocess,datetime
w=Path('/private/tmp/tdf-event-finance-browser-precision-fix-20261030');o=Path('/private/tmp/tdf-event-finance-browser-precision-qualification-20261030');p=Path('/private/tmp/tdf-event-finance-browser-precision-seal-20261030.py');sha=lambda b:hashlib.sha256(b).hexdigest();tree=ast.parse(p.read_text());defs=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='verify_ui_bindings'];assert len(defs)==1;ns={'sha':sha,'json':json};exec(compile(ast.Module(body=defs,type_ignores=[]),str(p),'exec'),ns);check=ns['verify_ui_bindings']
m=json.loads((o/'preparation-state.json').read_text())['sourceCommit'];q=json.loads((o/'ui-quality.json').read_text());f=json.loads((o/'assurance-committed/report.json').read_text());s=json.loads((o/'assurance-committed/sources.json').read_text());inputs=json.loads((o/'ui-qualified-inputs.json').read_text());actual={path:(w/path).read_bytes() for path in inputs['sourceFilesSha256']};eq=json.loads((o/'test-lint-fix-emission-equivalence.json').read_text());before=(o/'page-test-emission-before.js.txt').read_bytes();after=(o/'page-test-emission-after.js.txt').read_bytes();test=(w/'tdf-hq-ui/src/pages/SocialEventsPage.finance.test.tsx').read_bytes();expected=set(subprocess.check_output(['git','ls-tree','-r','-z','--name-only',m,'--','tdf-hq-ui','package.json','package-lock.json','tdf-hq/assets/feature-registry.json','scripts/quality-ui.sh','scripts/check-initial-bundle.mjs','formal/system/requirements.json'],cwd=w).decode().strip('\0').split('\0'))
check(m,q,f,s,inputs,expected,actual,eq,before,after,test);rows=[]
def control(label,mutate):
 v={'q':copy.deepcopy(q),'f':copy.deepcopy(f),'s':copy.deepcopy(s),'inputs':copy.deepcopy(inputs),'actual':dict(actual),'eq':copy.deepcopy(eq),'before':before,'after':after,'test':test};mutate(v)
 try:check(m,v['q'],v['f'],v['s'],v['inputs'],expected,v['actual'],v['eq'],v['before'],v['after'],v['test'])
 except AssertionError:rows.append({'label':label,'expectedRejection':True,'actual':'ASSERTION_REJECTED'});return
 raise RuntimeError('Invalid evidence accepted:'+label)
control('FailedLintPromotedAsPass',lambda v:v['q']['actualExits'].__setitem__('lint',1))
control('ReducedFullTestCount',lambda v:v['q'].__setitem__('fullTests',3810))
control('WrongQualifiedCommit',lambda v:v['q'].__setitem__('sourceCommit','0'*40))
control('AssuranceDigestMismatch',lambda v:v['f']['provenance'].__setitem__('digest','0'*64))
control('UnsupportedWholeRequirementProof',lambda v:v['f']['metrics']['requirements'].update(PROVEN=1,UNPROVEN=159))
control('UnsupportedExtraSMTClaim',lambda v:v['f']['metrics']['obligationsByCategory']['source-derived-SMT'].__setitem__('PROVEN',5))
control('UnexpectedReleasePermission',lambda v:v['f']['release'].__setitem__('executionAllowed',True))
def dirty(v):v['f']['provenance']['worktreeDirty']=True;v['s']['worktreeDirty']=True
control('ConsistentlyRelabeledDirtySource',dirty)
def corrupt_input(v):path=next(iter(v['actual']));v['actual'][path]+=b'CORRUPTED'
control('CorruptedCapturedUIBytes',corrupt_input)
def omit_input(v):path=next(iter(v['actual']));v['actual'].pop(path);v['inputs']['sourceFilesSha256'].pop(path)
control('OmittedInputWithMatchedReducedBytes',omit_input)
control('ChangedEmittedTestExecution',lambda v:v.__setitem__('after',v['after']+b'CORRUPTED'))
control('WrongCurrentPageTestSource',lambda v:v.__setitem__('test',v['test']+b'CORRUPTED'))
check(m,q,f,s,inputs,expected,actual,eq,before,after,test)
for path,b in actual.items():assert (w/path).read_bytes()==b,path
result={'sourceCommit':m,'sealScriptSha256':sha(p.read_bytes()),'method':'AST-extract actual seal binder; actualvalid artifacts before/after, onein-memorycorruptionpercase; canonical expectedinputpaths independentlyenumeratedfromGit. Disk/source nevermutated.','validBefore':True,'negativeControls':rows,'intendedAssertionRejections':len(rows),'restoredValidAfter':True,'diskArtifactsUnchanged':True,'scope':'Evidence binder controls, not full verification-system correctness or product-source mutants.','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/'seal-binding-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'validBefore':True,'controlsRejected':len(rows),'restoredValidAfter':True}))
