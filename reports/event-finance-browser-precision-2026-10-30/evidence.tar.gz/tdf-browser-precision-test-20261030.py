from pathlib import Path
import os,subprocess,json,sys
w=Path('/private/tmp/tdf-event-finance-browser-precision-fix-20261030');o=Path('/private/tmp/tdf-event-finance-browser-precision-qualification-20261030');c=Path('/private/tmp/tdf-correctness-cycle-20261028');phase=sys.argv[1]
e={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','LANG','LC_ALL']};e['PATH']='/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin';e['PYTHONDONTWRITEBYTECODE']='1'
assert (w/'package-lock.json').read_bytes()==(c/'package-lock.json').read_bytes()
assert json.loads((w/'tdf-hq-ui/package.json').read_text())==json.loads((c/'tdf-hq-ui/package.json').read_text())
made=[]
try:
 for name in ['node_modules','tdf-hq-ui/node_modules']:
  p,t=w/name,c/name;assert not(p.exists() or p.is_symlink());p.symlink_to(t,target_is_directory=True);made.append((p,t))
 tasks=[('targeted',['npm','test','--','--runTestsByPath','src/utils/eventFinanceMoney.test.ts','src/utils/eventFinanceCsv.test.ts','src/api/socialEvents.test.ts'])]
 if phase=='qualified':tasks += [('typecheck',['npm','run','typecheck']),('lint',['npm','run','lint']),('full',['npm','test']),('build',['npm','run','build'])]
 results={}
 for label,cmd in tasks:
  with (o/(phase+'-'+label+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=w/'tdf-hq-ui',env=e,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
  results[label]=r.returncode;print(label+' actualexit '+str(r.returncode),flush=True)
  if phase!='baseline':assert r.returncode==0,label
 (o/(phase+'-results.json')).write_text(json.dumps(results,indent=2)+'\n')
finally:
 for p,t in reversed(made):assert p.is_symlink() and p.resolve()==t.resolve();p.unlink()
