from pathlib import Path
w=Path('/private/tmp/tdf-event-finance-browser-precision-fix-20261030');u=w/'tdf-hq-ui/src'
(u/'utils/eventFinanceMoney.ts').write_text('''import { resolveRuntimeCurrency, resolveRuntimeFormatOptions } from './formatters';

const PRECISION_ERROR = 'El importe excede la precisión admitida por el navegador o no contiene centavos enteros.';

// Finance DTO monetary fields share the Cents suffix. Percentages and IDs are not money.
export function assertSafeEventFinanceMoney<T extends object>(value: T): T {
  for (const [field, amount] of Object.entries(value)) {
    if (field.endsWith('Cents') && amount != null && !Number.isSafeInteger(amount)) {
      throw new Error(PRECISION_ERROR);
    }
  }
  return value;
}

export const formatEventMoney = (amountCents?: number | null, currency?: string | null): string => {
  if (typeof amountCents !== 'number') return 'Gratis';
  if (!Number.isSafeInteger(amountCents)) return 'Monto no disponible';
  const locale = resolveRuntimeFormatOptions().locale;
  const formatter = new Intl.NumberFormat(locale, {
    style: 'currency', currency: (currency ?? resolveRuntimeCurrency()).toUpperCase(),
  });
  // Divide integer cents exactly, then apply the currency's default fraction rounding.
  // Passing a floating point amount / 100 loses cents even for safe integers.
  const digits = formatter.resolvedOptions().maximumFractionDigits ?? 0;
  const scale = 10n ** BigInt(digits);
  const cents = BigInt(amountCents);
  const negative = cents < 0n || Object.is(amountCents, -0);
  const magnitude = cents < 0n ? -cents : cents;
  const divisor = 10n ** BigInt(Math.max(0, 2 - digits));
  const units = digits >= 2
    ? magnitude * 10n ** BigInt(digits - 2)
    : (magnitude + divisor / 2n) / divisor;
  const whole = units / scale;
  const signedWhole = negative ? (whole === 0n ? -0 : -whole) : whole;
  const fraction = digits > 0 ? new Intl.NumberFormat(locale, {
    useGrouping: false, minimumIntegerDigits: digits, maximumFractionDigits: 0,
  }).format(units % scale) : '';
  return formatter.formatToParts(signedWhole)
    .map(part => part.type === 'fraction' ? fraction : part.value).join('');
};
''')
p=u/'api/socialEvents.ts';s=p.read_text();s="import { assertSafeEventFinanceMoney } from '../utils/eventFinanceMoney';\n"+s
s=s.replace('await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/budget-lines`) as SocialEventBudgetLineDTO[],','(await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/budget-lines`) as SocialEventBudgetLineDTO[]).map(assertSafeEventFinanceMoney),')
s=s.replace('return await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/finance-entries${qs}`) as SocialEventFinanceEntryDTO[];','return (await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/finance-entries${qs}`) as SocialEventFinanceEntryDTO[]).map(assertSafeEventFinanceMoney);')
s=s.replace('await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/finance-summary`) as SocialEventFinanceSummaryDTO,','assertSafeEventFinanceMoney(await getUnknown(`/social-events/events/${encodeURIComponent(eventId)}/finance-summary`) as SocialEventFinanceSummaryDTO),');p.write_text(s)
p=u/'utils/eventFinanceCsv.ts';s=p.read_text();s="import { assertSafeEventFinanceMoney } from './eventFinanceMoney';\n"+s;s=s.replace('  const rows:', '  if (financeSummary) assertSafeEventFinanceMoney(financeSummary);\n  budgetLines.forEach(assertSafeEventFinanceMoney);\n  financeEntries.forEach(assertSafeEventFinanceMoney);\n  const rows:',1);p.write_text(s)
p=u/'pages/SocialEventsPage.tsx';s=p.read_text();a=s.index('    const rows = buildEventFinanceCsvRows(');b=s.index('\n  };',a);body=s[a:b];s=s[:a]+"    try {\n"+'\n'.join('  '+line for line in body.splitlines())+"\n    } catch (error) {\n      setFeedback({ kind: 'error', message: error instanceof Error ? error.message : 'No se pudo exportar el reporte financiero.' });\n    }"+s[b:];p.write_text(s)
