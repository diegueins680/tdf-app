import fs from 'node:fs';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
const require = createRequire('/private/tmp/tdf-correctness-cycle-20261028/package.json');
const { build } = require('esbuild');
const { chromium, firefox } = require('playwright');
const work = '/private/tmp/tdf-event-finance-browser-precision-fix-20261030';
const out = '/private/tmp/tdf-event-finance-browser-precision-qualification-20261030';
const bundle = out + '/actual-money-browser.js';
await build({ entryPoints: [work + '/tdf-hq-ui/src/utils/eventFinanceMoney.ts'], bundle: true, format: 'iife', globalName: 'EventFinanceMoney', platform: 'browser', target: 'es2022', define: { 'import.meta.env': '{}' }, outfile: bundle });
const rows=[];
for (const [name, engine] of [['chromium',chromium], ['firefox',firefox]]) {
  const browser=await engine.launch({ headless: true });
  try {
    for (const locale of ['en-US','de-DE']) {
      const context=await browser.newContext({locale});
      try {
        const page=await context.newPage(); await page.addScriptTag({path:bundle});
        const result=await page.evaluate(({locale})=>{
          const f=window.EventFinanceMoney.formatEventMoney;
          const cases=locale==='en-US' ? [
            [9007199254740991,'USD','$90,071,992,547,409.91'],
            [7036874417766401,'USD','$70,368,744,177,664.01'],
            [-9007199254740991,'USD','-$90,071,992,547,409.91'],
            [-1,'USD','-$0.01'],[-1,'JPY','-¥0'],[150,'JPY','¥2'],[-150,'JPY','-¥2'],
            [101,'KWD','KWD\u00a01.010'],[9007199254740992,'USD','Monto no disponible'],
            [null,'USD','Gratis'],[250,'USD','$2.50']
          ] : [[9007199254740991,'EUR','90.071.992.547.409,91\u00a0€'],[-1,'EUR','-0,01\u00a0€']];
          return cases.map(([cents,currency,expected])=>({cents,currency,expected,actual:f(cents,currency)}));
        },{locale});
        if (result.some(x=>x.actual!==x.expected)) throw new Error(JSON.stringify({name,locale,result}));
        rows.push({engine:name,version:browser.version(),locale,cases:result.length,passed:result.length});
      } finally {await context.close();}
    }
  } finally {await browser.close();}
}
const inputs={};for(const p of ['tdf-hq-ui/src/utils/eventFinanceMoney.ts','tdf-hq-ui/src/utils/formatters.ts']) inputs[p]=crypto.createHash('sha256').update(fs.readFileSync(work+'/'+p)).digest('hex');
const receipt={status:'TESTED',scope:'Actual bundled TS money utility in real local Chromium/Firefox; no served-page/API/production/WebKit claim',playwright:require('playwright/package.json').version,sourceInputsSha256:inputs,bundleSha256:crypto.createHash('sha256').update(fs.readFileSync(bundle)).digest('hex'),actualResults:rows};
fs.writeFileSync(out+'/actual-browser-money.json',JSON.stringify(receipt,null,2)+'\n'); console.log(JSON.stringify(receipt));
