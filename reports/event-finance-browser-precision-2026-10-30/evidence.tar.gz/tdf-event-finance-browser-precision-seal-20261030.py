from pathlib import Path
import json,subprocess,hashlib,csv,datetime,re
w=Path('/private/tmp/tdf-event-finance-browser-precision-fix-20261030');o=Path('/private/tmp/tdf-event-finance-browser-precision-qualification-20261030');sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=w):return subprocess.check_output(['git',*a],cwd=cwd)
def blob(ref,p):return git('show',ref+':'+p)
def verify_ui_bindings(m,q,f,s,inputs,expected_input_paths,actual_input_bytes,equivalence,before_js,after_js,current_test_bytes):
 assert q['sourceCommit']==f['provenance']['revision']==s['revision']==inputs['sourceCommit']==m
 assert set(q['actualExits'])=={'targeted','typecheck','lint','full','build','root-quality','source-admission','catalog-unit'}
 assert all(x==0 for x in q['actualExits'].values()) and q['phase']=='QUALIFIED_FINAL_COMMITTED_SOURCE'
 assert q['targetedTests']==76 and q['targetedSuites']==4 and q['fullTests']==3811 and q['fullSuites']==327
 assert q['allInputsGitExactAndUnchanged'] and q['aliasesRemoved'] and q['sourceCleanAfter']
 for key in ['files','digest','revision','mobileGitlink','worktreeDirty']:assert f['provenance'][key]==s[key],key
 assert not s['worktreeDirty'] and s['digest']==sha(json.dumps(s['files'],sort_keys=True).encode())
 expected={'PROVEN':0,'REFUTED':0,'UNPROVEN':160,'NOT_APPLICABLE':0}
 assert f['metrics']['requirements']==expected
 for category in ['implementation','refinement']:assert f['metrics']['obligationsByCategory'][category]==expected
 for category,count in [('source-derived-SMT',4),('source-derived-authorization-SMT',3),('source-derived-recovery-SMT',4)]:assert f['metrics']['obligationsByCategory'][category]=={'PROVEN':count,'REFUTED':0,'UNPROVEN':0,'NOT_APPLICABLE':0}
 assert f['execution']['passed'] and f['release']['decision']=='BLOCKED' and f['release']['executionAllowed'] is False
 assert set(inputs['sourceFilesSha256'])==set(actual_input_bytes)==expected_input_paths
 for p,h in inputs['sourceFilesSha256'].items():assert sha(actual_input_bytes[p])==h,p
 assert before_js==after_js and sha(before_js)==equivalence['emittedJavascriptSha256']
 assert equivalence['emittedJavascriptByteExact'] and sha(current_test_bytes)==equivalence['afterSourceSha256']

p=json.loads((o/'preparation-state.json').read_text());m=p['sourceCommit'];main=p['mainSha'];q=json.loads((o/'ui-quality.json').read_text());f=json.loads((o/'assurance-committed/report.json').read_text());s=json.loads((o/'assurance-committed/sources.json').read_text());inputs=json.loads((o/'ui-qualified-inputs.json').read_text());eq=json.loads((o/'test-lint-fix-emission-equivalence.json').read_text())
assert git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip()
actual={path:(w/path).read_bytes() for path in inputs['sourceFilesSha256']};before=(o/'page-test-emission-before.js.txt').read_bytes();after=(o/'page-test-emission-after.js.txt').read_bytes();test='tdf-hq-ui/src/pages/SocialEventsPage.finance.test.tsx'
expected_input_paths=set(git('ls-tree','-r','-z','--name-only',m,'--','tdf-hq-ui','package.json','package-lock.json','tdf-hq/assets/feature-registry.json','scripts/quality-ui.sh','scripts/check-initial-bundle.mjs','formal/system/requirements.json').decode().strip('\0').split('\0'))
verify_ui_bindings(m,q,f,s,inputs,expected_input_paths,actual,eq,before,after,(w/test).read_bytes())
mobile=git('rev-parse',m+':tdf-mobile').decode().strip();assert git('rev-parse','HEAD',cwd=w/'tdf-mobile').decode().strip()==mobile
for table in [inputs['sourceFilesSha256'],s['files']]:
 for ism in [False,True]:
  pairs=[(path,h) for path,h in table.items() if path.startswith('tdf-mobile/')==ism]
  if not pairs:continue
  cwd=w/'tdf-mobile' if ism else w;ref=mobile if ism else m;refs=[ref+':'+(path.removeprefix('tdf-mobile/') if ism else path) for path,h in pairs];assert all('\n' not in x for x in refs)
  raw=subprocess.check_output(['git','cat-file','--batch'],cwd=cwd,input=('\n'.join(refs)+'\n').encode());pos=0
  for path,h in pairs:
   end=raw.index(b'\n',pos);header=raw[pos:end].split();assert header[1]==b'blob';n=int(header[2]);assert sha(raw[end+1:end+1+n])==h==sha((w/path).read_bytes()),path;pos=end+1+n+1
  assert pos==len(raw)
for path,h in f['evidenceHashes'].items():
 pp=Path(path);assert not pp.is_absolute() and '..' not in pp.parts;file=o/'assurance-committed'/pp;assert file.is_file() and not file.is_symlink() and sha(file.read_bytes())==h,path
for path in ['tdf-hq','.github','scripts','ops','tdf-mobile','package.json','package-lock.json']:
 assert git('rev-parse',m+':'+path)==git('rev-parse',main+':'+path),path
requirements=json.loads(blob(m,'formal/system/requirements.json'))['requirements'];prior=json.loads(blob(main,'formal/system/requirements.json'))['requirements'];by={r['id']:r for r in requirements};assert len(by)==len(requirements)==len(prior)+1==160 and all(by[r['id']]==r for r in prior)
path='docs/catalog-persistence/catalog-list-decisions.json';old=json.loads(blob(main,path));new=json.loads(blob(m,path));assert new['decisions'][:-1]==old['decisions'] and new['decisions'][-1]['id']=='caafb621f3c699640707' and new['decisions'][-1]['reviewed'];assert {k:v for k,v in new.items() if k!='decisions'}=={k:v for k,v in old.items() if k!='decisions'}
cat=json.loads(blob(m,'docs/catalog-persistence/reports/static-list-inventory.json'));assert cat['candidateCount']==1355 and all(x['decision']!='unreviewed' for x in cat['candidates']);assert (o/'current-catalog.json').read_bytes()==blob(m,'docs/catalog-persistence/reports/static-list-inventory.json')
with (o/'current-catalog.csv').open(newline='') as handle:rows=list(csv.DictReader(handle))
assert len(rows)==1355 and (o/'current-catalog.csv').read_bytes()==blob(m,'docs/catalog-persistence/reports/list-consumer-matrix.csv')
assert all(x==0 for x in p['metadataResults']['actualExits'].values()) and len(p['metadataResults']['actualExits'])==7 and all(x==0 for x in p['committedChecks'].values())
core=json.loads((o/'source-controls.json').read_text());assert core['qualifiedCheckoutNeverMutated'];assert [(x['variant'],x['failed'],x['passed']) for x in core['actualResults']]==[('unchecked-api',21,47),('unchecked-csv',3,65),('floating-money',4,64),('restored',0,68)]
assert [x['actualExit'] for x in core['actualResults']]==[1,1,1,0] and all(x['total']==68 and x['aliasesRemoved'] for x in core['actualResults'])
for path,h in core['originalSourceInputsSha256'].items():assert sha(blob(m,'tdf-hq-ui/'+path))==h,path
for label,failures,passes in [('export-wiring-removed',6,2),('export-restored-list-admission',0,8)]:
 row=json.loads((o/(label+'.json')).read_text());assert row['failed']==failures and row['passed']==passes and row['actualPageMounted'] and row['actualExit']==(1 if failures else 0)
oldtest=(o/'initial-source-b29-lint-history/SocialEventsPage.finance.test.before.tsx.txt').read_bytes();assert sha(oldtest)==eq['beforeSourceSha256'] and oldtest==blob(p['initialUnpublishedSource'],test)
browser=json.loads((o/'actual-browser-money.json').read_text());assert sum(x['passed'] for x in browser['actualResults'])==26 and all(x['passed']==x['cases'] for x in browser['actualResults']);assert sha((o/'actual-money-browser.js').read_bytes())==browser['bundleSha256']
for path,h in browser['sourceInputsSha256'].items():assert sha(blob(m,path))==h,path
fault_inputs=json.loads((o/'source-fault-inputs-manifest.json').read_text())['files'];assert len(fault_inputs)==36 and len({x['path'] for x in fault_inputs})==36
for row in fault_inputs:
 pp=Path(row['path']);assert not pp.is_absolute() and '..' not in pp.parts;file=o/pp;assert file.is_file() and not file.is_symlink() and file.stat().st_size==row['bytes'] and sha(file.read_bytes())==row['sha256']
for rel in ['src/utils/eventFinanceMoney.ts','src/utils/eventFinanceCsv.ts','src/api/socialEvents.ts','src/utils/eventFinanceMoney.test.ts','src/utils/eventFinanceCsv.test.ts','src/api/socialEvents.test.ts']:
 assert (o/'source-fault-inputs/restored'/rel).read_bytes()==blob(m,'tdf-hq-ui/'+rel)
for label in ['export-wiring-removed','export-restored-list-admission']:
 assert (o/'source-fault-inputs'/label/'src/pages/SocialEventsPage.finance.test.tsx').read_bytes()==oldtest
assert (o/'source-fault-inputs/export-restored-list-admission/src/pages/SocialEventsPage.tsx').read_bytes()==blob(m,'tdf-hq-ui/src/pages/SocialEventsPage.tsx')
reviews={}
for label,path in [('source','/private/tmp/tdf-event-finance-browser-precision-independent-review-20261030.txt'),('typeOnly','/private/tmp/tdf-event-finance-browser-precision-lint-addendum-20261030.txt'),('catalog','/private/tmp/tdf-event-finance-browser-precision-catalog-addendum-20261030.txt')]:
 file=Path(path);assert file.is_file() and not file.is_symlink();reviews[label]={'path':path,'sha256':sha(file.read_bytes())}
reviewed=(Path(reviews['source']['path'])).read_text()
for path in ['tdf-hq-ui/src/utils/eventFinanceMoney.ts','tdf-hq-ui/src/utils/eventFinanceCsv.ts','tdf-hq-ui/src/api/socialEvents.ts','tdf-hq-ui/src/pages/SocialEventsPage.tsx','tdf-hq-ui/src/utils/eventFinanceMoney.test.ts','tdf-hq-ui/src/utils/eventFinanceCsv.test.ts','tdf-hq-ui/src/api/socialEvents.test.ts','formal/system/event-finance-browser-precision.md']:
 assert '- '+path+': '+sha(blob(m,path)) in reviewed,path
assert '- '+test+': '+eq['beforeSourceSha256'] in reviewed
assert eq['afterSourceSha256'] in Path(reviews['typeOnly']['path']).read_text() and eq['emittedJavascriptSha256'] in Path(reviews['typeOnly']['path']).read_text()
assert sha(blob(m,'docs/catalog-persistence/catalog-list-decisions.json')) in Path(reviews['catalog']['path']).read_text()
for label,expected in [('source','123db48eef59cf78a7da3ef398a026db7fc8f2fde3d1385bab8733f30afe4959'),('typeOnly','ad461310b9b859d6705691df32ccd199e93f8f7da75d9a8fcdb2d9215631a28c'),('catalog','94ca8f0c8eb5770b262da43d5a288528b3e8009539a184ff32bb8c6a729b3d46')]:assert reviews[label]['sha256']==expected,label
result={'sourceCommit':m,'baselineMain':main,'initialUnpublishedSource':p['initialUnpublishedSource'],'sourceDigest':s['digest'],'registeredHashesVerified':len(s['files']),'uiInputHashesVerified':len(inputs['sourceFilesSha256']),'assuranceArtifactHashesVerified':len(f['evidenceHashes']),'all159MainRequirementsExactPlusPrecision160':True,'allBackendWorkflowsMobileOpsScriptsDependenciesExactMain':True,'allPriorCatalogDecisionsExactPlusOneReviewedSyntheticFixture':True,'strictCatalogCandidates':1355,'newProductSourceInputs':core['originalSourceInputsSha256'],'uiQuality':q,'actualFaultSourceAndTestSnapshotsVerified':36,'coreSourceFaultAssertions':[21,3,4],'actualPageWiringFaultAssertions':6,'restoredCoreCases':68,'restoredPageCases':8,'typeOnlyTestFixEmissionByteExact':True,'realBrowserFormatterCases':26,'realBrowserScope':browser['scope'],'assuranceMetrics':f['metrics'],'formalRelease':f['release']['decision'],'newCompleteProofs':0,'independentSourceReviewBindings':reviews,'sourceCleanAfter':True,'limitations':['TESTED finite source/component/browser scope; complete implementation/refinement remainsUNPROVEN.','Initialb29lint and1354unstagedcatalogpreparation are quarantined setuphistory, not passing finalsource evidence. Currentcatalog1355covers trackedfiles and explicitfixturedecision; noauditorwaiver.','Page tests mock query/session/ancillary components; browser26runs bundledmoneyutility, not servedPage/HTTP/WebKit/production.','Foreign-entryCSVcurrency attribution, snapshot/concurrency and othermoneyconsumers remain separate obligations.','UI runner owns childprocessgroups and SIGTERM entry but cancellation cleanup is not fault-tested; no universal interruption guarantee.'],'createdAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/'source-correspondence.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['sourceCommit','registeredHashesVerified','uiInputHashesVerified','strictCatalogCandidates','formalRelease']}))
