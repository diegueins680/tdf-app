from pathlib import Path
import subprocess,json,os,datetime,hashlib
w=Path('/private/tmp/tdf-event-finance-browser-precision-fix-20261030');o=Path('/private/tmp/tdf-event-finance-browser-precision-qualification-20261030');base='0bd8409f0b0bbeffdbee5cb6a0abdd09c07dafe5'
def git(*a):return subprocess.check_output(['git',*a],cwd=w)
assert git('rev-parse','HEAD').decode().strip()==base
md=json.loads((o/'metadata-results.json').read_text());assert md['ownedAliasRemoved'] and len(md['actualExits'])==7 and all(x==0 for x in md['actualExits'].values())
paths=['formal/system/requirements.json','formal/system/event-finance-browser-precision.md','tdf-hq-ui/src/api/socialEvents.ts','tdf-hq-ui/src/api/socialEvents.test.ts','tdf-hq-ui/src/pages/SocialEventsPage.tsx','tdf-hq-ui/src/pages/SocialEventsPage.finance.test.tsx','tdf-hq-ui/src/utils/eventFinanceMoney.ts','tdf-hq-ui/src/utils/eventFinanceMoney.test.ts','tdf-hq-ui/src/utils/eventFinanceCsv.ts','tdf-hq-ui/src/utils/eventFinanceCsv.test.ts','docs/catalog-persistence/reports/list-consumer-matrix.csv','docs/catalog-persistence/reports/static-list-inventory.json','formal/system/inventory.json','formal/system/traceability.json']
status=git('status','--porcelain','-z').decode().split('\0');changed={x[3:] for x in status if x};assert changed==set(paths),(changed-set(paths),set(paths)-changed)
old=json.loads(git('show',base+':formal/system/requirements.json'))['requirements'];new=json.loads((w/'formal/system/requirements.json').read_text())['requirements'];by={r['id']:r for r in new};assert len(new)==len(by)==len(old)+1==160 and all(by[r['id']]==r for r in old)
assert not git('diff','--name-only','--','tdf-hq','.github','scripts','ops','tdf-mobile','package.json','package-lock.json').strip()
subprocess.run(['git','diff','--check'],cwd=w,check=True);subprocess.run(['git','add',*paths],cwd=w,check=True)
r=subprocess.run(['git','commit','-m','fix(events): preserve exact browser finance cents and refuse incomplete exports'],cwd=w,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(o/'source-commit.log').write_text(r.stdout);assert r.returncode==0,r.stdout
m=git('rev-parse','HEAD').decode().strip();assert git('show','-s','--format=%P',m).decode().split()==[base] and not git('status','--porcelain').strip()
e={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','LANG','LC_ALL']};e.update(PATH='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/Users/macpro/.ghcup/bin:/usr/local/bin:/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1');checks={}
for label,cmd in [('inventory-check',['python3','scripts/specification-inventory.py','--check']),('conformance-check',['python3','scripts/specification-conformance.py','--check']),('source-admission',['python3','scripts/check-new-specification-surfaces.py','--base',base,'--head',m]),('source-ci-selection',['node','scripts/ci-change-scope.mjs','--base',base,'--head',m])]:
 with (o/('committed-'+label+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=w,env=e,stdout=f,stderr=subprocess.STDOUT,timeout=300)
 checks[label]=r.returncode;assert r.returncode==0,label
assert not git('status','--porcelain').strip()
result={'sourceCommit':m,'mainSha':base,'parents':[base],'sourceCleanAfter':True,'all159MainRequirementsExactPlusPrecision160':True,'allBackendWorkflowsMobileOpsScriptsDependenciesExactMain':True,'metadataResults':md,'committedChecks':checks,'noCheckpointOrAmendNeeded':'Mobile pin unchanged7586; first currentsource commit after generatedmetadata','createdAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/'preparation-state.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
