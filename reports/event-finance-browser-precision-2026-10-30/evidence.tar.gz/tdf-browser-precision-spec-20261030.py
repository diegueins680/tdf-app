from pathlib import Path
import json
w=Path('/private/tmp/tdf-event-finance-browser-precision-fix-20261030');p=w/'formal/system/requirements.json';data=json.loads(p.read_text());r={
'id':'UI-EVENT-FINANCE-PRECISION-001','title':'Exact browser event-finance cents or explicit refusal','domain':'PAY','critical':True,
'statement':'Event-finance summary, budget and entry reads and CSV exports refuse non-null monetary values that are not JavaScript safe-integer cents. Safe signed cents display without a floating-point division by100 while preserving locale and default ISO currency fraction rounding.',
'authority':'Owner financial-integrity mandate; existing cents DTO contracts, signed finance balances, locale formatter and CSV raw-cent columns. Existing UI authoring already requires safe integer inputs.',
'source':'formal/system/event-finance-browser-precision.md','contract':'formal/system/event-finance-browser-precision.md',
'property':'For every admitted non-null Cents field x, Number.isSafeInteger(x). For signed safe cents c, display is locale currency formatting of the exact rational c/100 rounded to the currency default fraction digits. No lossy monetary value reaches a successful finance read or CSV row.',
'actors':['Authorized event manager','Browser finance report reader'],
'preconditions':['Existing event API authorization and integer-cent backend contract','Modern supported browsers provide Intl.NumberFormat BigInt formatToParts','Finance DTO monetary fields retain their Cents suffix; optional null/undefined retain existing meanings'],
'inputs':['Decoded summary, budget and finance-entry DTO monetary fields','Signed safe integer cents, optional values, configured locale and ISO currency'],
'state':{'read':'Decoded transport or cached finance data','terminal':['Validated finance data / exact display / CSV rows','Query failure, unavailable amount or export error']},
'allowedTransitions':['Validate each finance read before exposing it','Validate cached monetary data before building CSV rows','Separate integer whole and fraction units before locale presentation'],
'forbiddenTransitions':['Display or export rounded unsafe decoded cents as valid monetary evidence','Divide safe cent magnitudes by100 in binary floating point before display','Export a partial CSV after monetary precision refusal'],
'effects':['Read-only report presentation and CSV export; no backend financial restriction or monetary wire migration'],
'authorization':'Existing event authorization unchanged; validation grants no additional access.',
'privacy':'Synthetic fixtures only; no provider or customer data in receipts.',
'concurrency':'Validate each returned/cached object independently; no serializable multi-query financial snapshot claim.',
'idempotency':'No provider calls or automatic mutation retries. Equal values and locale/currency inputs produce equal report formatting.',
'failure':'Unsafe finance data rejects the query or export; existing query warnings and explicit export feedback remain. Unrepresentable displayed prices show Monto no disponible. Missing prices retain Gratis.',
'recovery':'Correct source values through authorized workflows or implement an independently reviewed exact monetary wire/client migration. Never clamp or rewrite financial records to make the UI accept them.',
'observability':'Retain baseline assertion failures, targeted/full UI logs, independent source faults, source fingerprints and exact-commit evidence.',
'implementation':['tdf-hq-ui/src/utils/eventFinanceMoney.ts','tdf-hq-ui/src/utils/eventFinanceCsv.ts','tdf-hq-ui/src/api/socialEvents.ts','tdf-hq-ui/src/pages/SocialEventsPage.tsx'],
 'tests':['tdf-hq-ui/src/utils/eventFinanceMoney.test.ts','tdf-hq-ui/src/utils/eventFinanceCsv.test.ts','tdf-hq-ui/src/api/socialEvents.test.ts'],
'formalModels':[], 'verification':'Counterexample-driven Jest tests of actual API getters, extracted unchanged CSV builder and formatter; finite locale/currency differential checks, actual source-fault controls, UI type/lint/build and CI. TESTED, no complete refinement proof.',
'evidence':'formal/system/event-finance-browser-precision.md; exact-source execution reports remain separate.',
'status':'specified and implemented','confidence':'Scoped executable evidence; no complete implementation proof or deployed acceptance claim.',
'ambiguity':['Foreign currency attribution and backend aggregation/transaction consistency are independent obligations.','Safe values already rounded by an upstream producer cannot be detected without a wire migration.','Production exposure of extreme amounts and all browser/locale combinations remain unknown.'],
'conformance':{'classification':'PARTIAL','reason':'Finite implementation tests; complete refinement and deployed browser/API correspondence remain unproven.'}}
assert all(x['id']!=r['id'] for x in data['requirements']);data['requirements'].append(r);p.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
(w/'formal/system/event-finance-browser-precision.md').write_text('''# Event-finance browser monetary precision

Requirement: UI-EVENT-FINANCE-PRECISION-001. Assurance: TESTED where an exact-source execution receipt is present; implementation/refinement proof remains UNPROVEN.

## Contract and counterexamples

Financial DTO amounts and CSV columns are integer cents. The existing authoring parser refuses unsafe integers. Backend signed Int64 values can exceed JavaScript safe integers without violating that backend contract. Keep that wire contract; refuse a browser report that cannot represent its amounts.

The actual original API accepted JSON `9007199254740993` as `9007199254740992` and exported that changed cent. Independently, dividing the *safe* `9007199254740991` cents by100 displayed USD `$90,071,992,547,409.90` instead of `.91`. Safe `7036874417766401` displayed `.02` instead of `.01`; negative values are affected too. Two individually authorable safe inputs can yield an unsafe total. Input-only checks therefore do not protect reports.

For each non-null/undefined monetary field x in a finance summary, budget line or entry, admission requires `Number.isSafeInteger(x)`. These DTO fields use the `Cents` suffix; percentages/IDs are not monetary. Read getters validate before returning data. The CSV builder independently validates cached data before producing rows, including independent budget/entry queries when summary is absent. Export failure creates feedback before any download. Existing optional values and percentages retain their semantics. Rejected reads follow existing query error states.

For safe signed cents c, format the exact rational c/100 using the selected locale and currency's default fraction digits d. Convert the admitted integer to BigInt. For d>=2 scale its magnitude by10^(d-2); for d<2 round magnitude to the currency unit with integer half-expand arithmetic. Split integer whole/fraction units, preserve negative-zero sign for subunit negative amounts, and use Intl formatToParts only for presentation. USD/EUR retain2 digits, JPY retains0 and KWD retains3. Localized fraction digits replace the formatted fraction without a floating-point major-unit conversion. Null/undefined prices remain Gratis; unrepresentable numeric prices show Monto no disponible.

## Scope and verification limits

Regression tests exercise actual getters, CSV construction and formatting, including the original counterexamples, signed extrema, unsafe values, optional values, percentages, locale and ISO fraction conventions. A bounded small-cent differential check compares normal Intl formatting; it is testing, not a proof. Negative controls must restore the original floating division and remove each admission boundary to demonstrate detection. Existing UI quality CI discovers these Jest files automatically. Canonical traceability and exact-source receipts bind evidence to source fingerprints/SHAs; historical reports are not relabeled current.

No backend schema, monetary wire, production records, provider calls, new retry behavior, settlement semantics or multi-query snapshot guarantees are introduced. An upstream producer that already rounded an amount *into* the safe range cannot be detected by this boundary. Other application money formatters remain outside this correction. Full browser/locale coverage, physical device acceptance, financial currency attribution and implementation refinement remain separate obligations.
''')
p=w/'tdf-hq-ui/src/utils/eventFinanceMoney.test.ts';s=p.read_text();s=s.replace("  it('keeps the selected locale'",'''  it('matches normal currency rounding across small signed amounts and locale digit systems', () => {
    for (const locale of ['en-US', 'de-DE', 'ar-EG']) {
      window.localStorage.setItem('tdf-hq-ui/locale-preferences', JSON.stringify({ locale }));
      for (const currency of ['USD', 'JPY', 'KWD']) {
        const expected = new Intl.NumberFormat(locale, { style: 'currency', currency });
        for (let cents = -250; cents <= 250; cents++) {
          expect(formatEventMoney(cents, currency)).toBe(expected.format(cents / 100));
        }
      }
    }
  });
  it('preserves negative zero formatting', () => {
    expect(formatEventMoney(-0, 'USD')).toBe('-$0.00');
    expect(formatEventMoney(-1, 'JPY')).toBe('-¥0');
  });
  it('keeps the selected locale' ''');p.write_text(s)
