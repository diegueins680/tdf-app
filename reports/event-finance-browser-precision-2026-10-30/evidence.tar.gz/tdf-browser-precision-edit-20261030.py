from pathlib import Path
w=Path('/private/tmp/tdf-event-finance-browser-precision-fix-20261030');u=w/'tdf-hq-ui/src';p=u/'pages/SocialEventsPage.tsx';s=p.read_text()
a=s.index('const formatMoney =');b=s.index('\nconst ',a+1);money=s[a:b]
a=s.index('const buildEventFinanceCsvRows =');b=s.index('\nexport default function',a);csv=s[a:b]
(u/'utils/eventFinanceCsv.ts').write_text("import type { SocialEventDTO, SocialEventBudgetLineDTO, SocialEventFinanceEntryDTO, SocialEventFinanceSummaryDTO } from '../api/socialEvents';\nimport { resolveRuntimeCurrency } from './formatters';\n\n"+csv.replace('const buildEventFinanceCsvRows =','export const buildEventFinanceCsvRows =')+'\n')
(u/'utils/eventFinanceMoney.ts').write_text("import { formatCurrencyForUser, resolveRuntimeCurrency } from './formatters';\n\n"+money.replace('const formatMoney =','export const formatEventMoney =')+'\n')
s=s[:a]+s[b:];s=s.replace(money,'');s=s.replace('formatCurrencyForUser, formatDateForUser','formatDateForUser');s="import { formatEventMoney as formatMoney } from '../utils/eventFinanceMoney';\nimport { buildEventFinanceCsvRows } from '../utils/eventFinanceCsv';\n"+s;p.write_text(s)
(u/'utils/eventFinanceMoney.test.ts').write_text('''import { formatEventMoney } from './eventFinanceMoney';

describe('event finance cents', () => {
  beforeEach(() => window.localStorage.setItem('tdf-hq-ui/locale-preferences', JSON.stringify({ locale: 'en-US' })));
  afterEach(() => window.localStorage.clear());
  it.each([
    [9007199254740991, '$90,071,992,547,409.91'],
    [7036874417766401, '$70,368,744,177,664.01'],
    [-9007199254740991, '-$90,071,992,547,409.91'],
    [-1, '-$0.01'], [250, '$2.50'], [0, '$0.00'],
  ])('formats exact signed safe cents %s', (cents, expected) => {
    expect(formatEventMoney(cents, 'USD')).toBe(expected);
  });
  it.each([9007199254740992, -9007199254740992, NaN, Infinity, 1.5])('does not display unrepresentable cents %s', cents => {
    expect(formatEventMoney(cents, 'USD')).toBe('Monto no disponible');
  });
  it('keeps missing prices free', () => {
    expect(formatEventMoney(null, 'USD')).toBe('Gratis');
    expect(formatEventMoney(undefined, 'USD')).toBe('Gratis');
  });
  it('keeps currency fraction conventions', () => {
    expect(formatEventMoney(150, 'JPY')).toBe('¥2');
    expect(formatEventMoney(-150, 'JPY')).toBe('-¥2');
    expect(formatEventMoney(101, 'KWD')).toBe('KWD\\u00a01.010');
  });
  it('keeps the selected locale', () => {
    window.localStorage.setItem('tdf-hq-ui/locale-preferences', JSON.stringify({ locale: 'de-DE' }));
    expect(formatEventMoney(9007199254740991, 'EUR')).toBe('90.071.992.547.409,91\\u00a0€');
  });
});
''')
p=u/'api/socialEvents.test.ts';s=p.read_text();s+='''
describe('event finance read precision', () => {
  it.each(['efsBudgetCents', 'efsPlannedIncomeCents', 'efsPlannedExpenseCents', 'efsActualIncomeCents', 'efsActualExpenseCents', 'efsNetCents', 'efsTicketPaidRevenueCents', 'efsTicketRefundedRevenueCents', 'efsTicketPendingRevenueCents', 'efsAccountsPayableCents', 'efsAccountsReceivableCents', 'efsContractCommittedCents', 'efsContractPaidCents', 'efsProcurementCommittedCents', 'efsProcurementPaidCents', 'efsAssetInvestmentCents', 'efsLiabilityBalanceCents', 'efsBudgetVarianceCents'])('refuses rounded JSON summary %s', async field => {
    getMock.mockResolvedValue(JSON.parse(`{"${field}":9007199254740993}`));
    await expect(SocialEventsAPI.getFinanceSummary('7')).rejects.toThrow('precisión');
  });
  it.each(['eblPlannedCents', 'eblActualCents'])('refuses unsafe independent budget field %s', async field => {
    getMock.mockResolvedValue([{ [field]: -9007199254740992 }]);
    await expect(SocialEventsAPI.listBudgetLines('7')).rejects.toThrow('precisión');
  });
  it('refuses unsafe independent finance entries', async () => {
    getMock.mockResolvedValue([{ efeAmountCents: 9007199254740992 }]);
    await expect(SocialEventsAPI.listFinanceEntries('7')).rejects.toThrow('precisión');
  });
  it('preserves exact signed cents, optional values and non-monetary percentages', async () => {
    const report = { efsNetCents: -9007199254740991, efsBudgetCents: null, efsBudgetUtilizationPct: 1.25 };
    getMock.mockResolvedValue(report);
    await expect(SocialEventsAPI.getFinanceSummary('7')).resolves.toBe(report);
  });
});
''';p.write_text(s)
(u/'utils/eventFinanceCsv.test.ts').write_text('''import { buildEventFinanceCsvRows } from './eventFinanceCsv';
import type { SocialEventDTO, SocialEventBudgetLineDTO, SocialEventFinanceEntryDTO, SocialEventFinanceSummaryDTO } from '../api/socialEvents';
const event = { eventId: '7', eventTitle: 'Test', eventCurrency: 'USD' } as SocialEventDTO;

describe('event finance CSV precision', () => {
  it('refuses unsafe cached summary before producing rows', () => {
    const summary = JSON.parse('{"efsCurrency":"USD","efsNetCents":9007199254740993}') as SocialEventFinanceSummaryDTO;
    expect(() => buildEventFinanceCsvRows(event, [], [], summary)).toThrow('precisión');
  });
  it('refuses unsafe cached budget even without a summary', () => {
    const budget = { eblPlannedCents: 9007199254740992 } as SocialEventBudgetLineDTO;
    expect(() => buildEventFinanceCsvRows(event, [budget], [], null)).toThrow('precisión');
  });
  it('refuses unsafe cached entry even without a summary', () => {
    const entry = { efeAmountCents: -9007199254740992 } as SocialEventFinanceEntryDTO;
    expect(() => buildEventFinanceCsvRows(event, [], [entry], null)).toThrow('precisión');
  });
  it('exports exact safe cents and keeps percentages and absent values', () => {
    const summary = { efsCurrency: 'USD', efsNetCents: -9007199254740991, efsBudgetCents: null, efsBudgetUtilizationPct: 1.25 } as SocialEventFinanceSummaryDTO;
    const rows = buildEventFinanceCsvRows(event, [], [], summary);
    expect(rows.find(row => row[6] === 'net_cents')?.[7]).toBe(-9007199254740991);
    expect(rows.find(row => row[6] === 'budget_cents')?.[7]).toBeNull();
    expect(rows.find(row => row[6] === 'budget_utilization_pct')?.[7]).toBe(1.25);
  });
});
''')
