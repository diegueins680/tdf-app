from pathlib import Path,PurePosixPath
import subprocess,json,hashlib,tarfile,io,sys
w=Path(sys.argv[1]);reportpath=sys.argv[2];expectedSource=sys.argv[3];sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=w)
def blob(p):return git('show',head+':'+p)
head=git('rev-parse','HEAD').decode().strip();assert git('rev-parse','HEAD^').decode().strip()==expectedSource
assert not git('status','--porcelain').strip()
r=json.loads(blob(reportpath));assert r['sourceCommit']==expectedSource
archive=r['archive'];ap=archive['path'];mp=archive['manifest'];rd=PurePosixPath(ap).parent
expected={reportpath,ap,mp,str(rd/'independent-review.txt')};changed=set(git('diff','--name-only','-z',expectedSource,head).decode().strip('\0').split('\0'));assert changed==expected,(changed,expected)
for p in expected:assert blob(p)==(w/p).read_bytes(),p
raw=blob(ap);assert sha(raw)==archive['sha256'] and len(raw)==archive['bytes'];manifest=json.loads(blob(mp));assert manifest['sourceCommit']==expectedSource and manifest['archiveSha256']==sha(raw)
rows=manifest['files'];by={x['path']:x for x in rows};assert len(by)==len(rows)==archive['innerFiles'];seen=set()
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as t:
 for member in t:
  p=PurePosixPath(member.name);assert member.isfile() and not p.is_absolute() and '..' not in p.parts and str(p)==member.name and member.name not in seen
  seen.add(member.name);b=t.extractfile(member).read();row=by[member.name];assert len(b)==row['bytes'] and sha(b)==row['sha256'],member.name
assert seen==set(by)
print(json.dumps({'head':head,'sourceCommit':expectedSource,'reportOnlyChild':True,'fourGitBlobsVerified':True,'archiveMembersVerified':len(seen),'archiveSha256':sha(raw),'clean':True},indent=2))
