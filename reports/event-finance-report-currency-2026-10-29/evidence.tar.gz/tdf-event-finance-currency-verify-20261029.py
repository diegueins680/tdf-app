from pathlib import Path
import json,subprocess,time,os,concurrent.futures
w=Path('/private/tmp/tdf-event-finance-report-currency-20261029');o=Path('/private/tmp/tdf-event-finance-currency-qualification-20261029')
for _ in range(480):
 d=json.loads((o/'preparation-state.json').read_text())
 if d['phase']=='CLEAN_SOURCE_COMMITTED': break
 time.sleep(5)
else: raise RuntimeError('Clean source not completed; no qualification claim')
state={'sourceCommit':d['sourceCommit'],'phase':'ROOT_QUALITY'}
def save():(o/'verification-state.json').write_text(json.dumps(state,indent=2)+'\n')
env=os.environ.copy();env['PATH']='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/Users/macpro/.ghcup/bin:/usr/local/bin:/usr/bin:/bin'
def run(label,cmd):
 with (o/(label+'-driver.log')).open('w') as log:r=subprocess.run(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT)
 print(label+' actualexit '+str(r.returncode),flush=True);return r.returncode
save();state['rootQualityExit']=run('root-quality',['python3','/private/tmp/tdf-event-finance-currency-root-quality-20261029.py']);save();assert state['rootQualityExit']==0
state['phase']='NATIVE_AND_FRESH_ASSURANCE';save()
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 tasks={pool.submit(run,'native',['python3','/private/tmp/tdf-event-finance-currency-qualify-native-20261029.py']):'nativeExit',pool.submit(run,'assurance',['python3','scripts/verification-report.py','--output',str(o/'assurance-committed')]):'assuranceExit'}
 for fut in concurrent.futures.as_completed(tasks):state[tasks[fut]]=fut.result();save()
assert state['nativeExit']==0 and state['assuranceExit']==0
state['phase']='QUALIFIED_NATIVE_AND_ROOT_ASSURANCE';save()
