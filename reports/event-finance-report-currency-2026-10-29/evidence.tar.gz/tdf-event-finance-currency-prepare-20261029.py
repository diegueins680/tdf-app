from pathlib import Path
import subprocess, json, time, os
w=Path('/private/tmp/tdf-event-finance-report-currency-20261029');o=Path('/private/tmp/tdf-event-finance-currency-qualification-20261029')
state={'phase':'WAITING_FOR_ACTUAL_BASELINE'}
def save():(o/'preparation-state.json').write_text(json.dumps(state,indent=2)+'\n')
def run(cmd,label):
 with (o/(label+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=w,stdout=log,stderr=subprocess.STDOUT)
 state[label+'Exit']=r.returncode;save();print(label+' actualexit '+str(r.returncode),flush=True);assert r.returncode==0,label
save()
for _ in range(360):
 if (o/'baseline-confirmed.json').exists(): break
 time.sleep(5)
else: raise RuntimeError('No actual completed expected baseline; source remains unchanged')
b=json.loads((o/'baseline-confirmed.json').read_text());assert b['buildExit']==0 and b['testExit']==1 and b['actualFailures']==8 and b['examples']==13
state['phase']='APPLYING_REPAIR';save();run(['python3','/private/tmp/tdf-event-finance-currency-repair-20261029.py'],'apply-currency-repair')
p=w/'tdf-hq/test/TDF/Social/FollowHandlerSpec.hs';s=p.read_text();old='''        it "uses the explicit event currency rather than its configured default" $''';assert s.count(old)==1
s=s.replace(old,'''        it "does not require conversion for a zero historical budget actual" $
            withFinanceRangeEnv $ \\env -> do
                rangeBudget env 1 "expense" 1000
                rangeEntry env "expense" "manual" "posted" 0
                runSqlPool (rawExecute "UPDATE event_finance_entry SET currency='EUR' WHERE event_id=7" []) (envPool env)
                result <- rangeBudgetList env
                fmap (map eblActualCents) result `shouldBe` Right [Just 0]

'''+old);p.write_text(s)
state['newCurrencyCases']=14;state['phase']='REGISTERING_REQUIREMENT';save();run(['python3','/private/tmp/tdf-event-finance-currency-register-20261029.py'],'register')
run(['git','diff','--check'],'diff-check');run(['git','submodule','update','--init','--checkout','--','tdf-mobile'],'mobile-init')
state['phase']='REGENERATING_CANONICAL_METADATA';save();run(['python3','/private/tmp/tdf-event-finance-currency-metadata-20261029.py'],'metadata')
paths=['tdf-hq/src/TDF/Server/SocialEventsHandlers.hs','tdf-hq/test/TDF/Social/FollowHandlerSpec.hs','formal/system/event-finance-report-currency.md','formal/system/requirements.json','formal/system/inventory.json','formal/system/traceability.json','docs/catalog-persistence/reports/static-list-inventory.json','docs/catalog-persistence/reports/list-consumer-matrix.csv']
run(['git','diff','--check'],'final-diff-check');run(['git','add','--',*paths],'stage-focused-source');run(['git','commit','-m','fix(finance): refuse mixed-currency event totals'],'commit-source')
state['sourceCommit']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
state['phase']='CLEAN_SOURCE_COMMITTED';save();print('Clean source '+state['sourceCommit'],flush=True)
