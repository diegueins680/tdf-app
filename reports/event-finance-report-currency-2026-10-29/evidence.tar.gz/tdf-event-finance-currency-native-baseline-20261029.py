from pathlib import Path
import subprocess,os,json,hashlib,re,signal,datetime
w=Path('/private/tmp/tdf-event-finance-report-currency-20261029');o=Path('/private/tmp/tdf-event-finance-currency-qualification-20261029');base='a7ae597f7c111d6858561280cdf080d4e62b0d70';cache=Path('/private/tmp/tdf-event-finance-currency-native-cache-20261029')
assert not cache.exists();subprocess.run(['cp','-cR','/private/tmp/tdf-event-finance-native-mutation-cache-20261029',str(cache)],check=True)
main=Path('/private/tmp/tdf-event-finance-currency-spec-main-20261029.hs');main.write_text('module Main (main) where\nimport Test.Hspec (hspec)\nimport qualified TDF.Social.FollowHandlerSpec as Follow\nmain :: IO ()\nmain = hspec Follow.spec\n')
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env['PATH']='/Users/macpro/.ghcup/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin';env['STACK_ROOT']='/Users/macpro/.stack';env['PYTHONDONTWRITEBYTECODE']='1';sha=lambda b:hashlib.sha256(b).hexdigest()
handler='tdf-hq/src/TDF/Server/SocialEventsHandlers.hs';tests='tdf-hq/test/TDF/Social/FollowHandlerSpec.hs';assert (w/handler).read_bytes()==subprocess.check_output(['git','show',base+':'+handler],cwd=w)
inputs={p:sha((w/p).read_bytes()) for p in [handler,tests,'tdf-hq/stack.yaml','tdf-hq/stack.yaml.lock','tdf-hq/tdf-hq.cabal']};(o/'baseline-inputs.json').write_text(json.dumps({'sourceCommit':base,'productUnchanged':True,'onlyNewRegressionTestsDirty':True,'files':inputs,'ownerRule':'Refuse totalsuntilcontributingamountsmatcheventcurrency;preserveforeign-currencyauthoring'},indent=2)+'\n')
binary=cache/'currency-tests';command=['/Users/macpro/.ghcup/bin/stack','exec','--','ghc','--make','-O0','-threaded','-Wall','-isrc','-itest','-odir',str(cache),'-hidir',str(cache),'-stubdir',str(cache),'-o',str(binary),str(main)]
state={'sourceCommit':base,'phase':'BUILDING_BASELINE','compileCommand':command,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save():(o/'baseline-state.json').write_text(json.dumps(state,indent=2)+'\n')
def run(cmd,path,timeout):
 with path.open('w') as log:
  p=subprocess.Popen(cmd,cwd=w/'tdf-hq',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);state['activePID']=p.pid;save()
  try:return p.wait(timeout=timeout)
  except BaseException:
   if p.poll() is None:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   raise
save();state['buildExit']=run(command,o/'baseline-native-build.log',1800);save();print('baseline nativebuild actualexit'+str(state['buildExit']),flush=True);assert state['buildExit']==0,'Not abehavioralreduntilcompilepasses'
state['phase']='RUNNING_BASELINE';state['binarySha256']=sha(binary.read_bytes());save();state['testExit']=run([str(binary),'--match','event finance report currency'],o/'baseline-native-tests.log',120);save();raw=(o/'baseline-native-tests.log').read_text();assert state['testExit']==1 and '13 examples, 8 failures' in raw and raw.count('Expected currency refusal, got')==8,raw[-6000:]
assert all(sha((w/p).read_bytes())==h for p,h in inputs.items());state.update({'phase':'BASELINE_EIGHT_CONFIRMED_ASSERTION_FAILURES','examples':13,'actualFailures':8,'compatibilityPasses':5,'allInputsUnchanged':True});save();(o/'baseline-confirmed.json').write_text(json.dumps(state,indent=2)+'\n');print('13actualcases:8currency-refusalassertionfailures,5compatibilitypasses;productunmodified',flush=True)
