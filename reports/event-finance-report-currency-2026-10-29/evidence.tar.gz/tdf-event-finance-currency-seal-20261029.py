from pathlib import Path
import json,subprocess,hashlib
w=Path('/private/tmp/tdf-event-finance-report-currency-20261029');o=Path('/private/tmp/tdf-event-finance-currency-qualification-20261029');base='a7ae597f7c111d6858561280cdf080d4e62b0d70';m=json.loads((o/'preparation-state.json').read_text())['sourceCommit']
def git(*a,cwd=w):return subprocess.check_output(['git',*a],cwd=cwd)
def sha(b):return hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip()
q=json.loads((o/'native-quality.json').read_text());root=json.loads((o/'root-quality-result.json').read_text());mut=json.loads((o/'mutations.json').read_text());f=json.loads((o/'assurance-committed/report.json').read_text());s=json.loads((o/'assurance-committed/sources.json').read_text())
assert q['sourceCommit']==root['sourceCommit']==mut['sourceCommit']==s['revision']==m
assert all(v==0 for v in q['actualExits'].values()) and all(v==0 for v in root['actualExits'].values())
assert mut['phase']=='TWO_REAL_MUTANTS_DETECTED_AND_RESTORED' and f['execution']['passed'] and not s['worktreeDirty'] and f['provenance']['revision']==m
assert sha(json.dumps(s['files'],sort_keys=True).encode())==s['digest']
mobile=git('rev-parse',m+':tdf-mobile').decode().strip();assert git('rev-parse','HEAD',cwd=w/'tdf-mobile').decode().strip()==mobile
for is_mobile in [False,True]:
 pairs=[(p,h) for p,h in s['files'].items() if p.startswith('tdf-mobile/')==is_mobile]
 cwd=w/'tdf-mobile' if is_mobile else w;rev=mobile if is_mobile else m
 args=[rev+':'+(p.removeprefix('tdf-mobile/') if is_mobile else p) for p,h in pairs];assert all('\n' not in x for x in args)
 raw=subprocess.check_output(['git','cat-file','--batch'],cwd=cwd,input=('\n'.join(args)+'\n').encode());pos=0
 for p,h in pairs:
  e=raw.index(b'\n',pos);header=raw[pos:e].decode().split();assert header[1]=='blob',p;n=int(header[2]);blob=raw[e+1:e+1+n];assert sha(blob)==h and sha((w/p).read_bytes())==h,p;pos=e+1+n+1
 assert pos==len(raw)
old=json.loads(git('show',base+':formal/system/requirements.json'))['requirements'];new=json.loads((w/'formal/system/requirements.json').read_text())['requirements'];by={x['id']:x for x in new};assert len(new)==len(old)+1==159 and all(by[x['id']]==x for x in old)
contracts={p:sha((w/p).read_bytes()) for p in ['formal/system/event-finance-report-currency.md','formal/system/event-finance-report-range.md']}
for p,h in contracts.items(): assert sha(git('show',m+':'+p))==h
backend=git('diff','--name-only',base,m,'--','tdf-hq').decode().splitlines();assert backend==['tdf-hq/src/TDF/Server/SocialEventsHandlers.hs','tdf-hq/test/TDF/Social/FollowHandlerSpec.hs']
catalog='docs/catalog-persistence/catalog-list-decisions.json';assert (w/catalog).read_bytes()==git('show',base+':'+catalog)
record={'sourceCommit':m,'baseline':base,'sourceParents':git('show','-s','--format=%P',m).decode().strip().split(),'registeredFilesystemGitMobileHashesVerified':len(s['files']),'sourceDigest':s['digest'],'all158ParentRequirementsPreserved':True,'totalRequirements':len(new),'contractGitSha256':contracts,'backendChangesOnly':backend,'wholeBackendGitTree':git('rev-parse',m+':tdf-hq').decode().strip(),'all986BackendInputsQualifiedGitExact':q['allBackendInputsUnchangedAndGitExact'],'canonicalDecisionsWholeFileExactParent':True,'nativeQualifiedTestBinarySha256':q['binarySha256'],'nativeTargeted':q['targeted'],'nativeFull':q['full'],'actualControls':mut['results'],'assuranceMetrics':f['metrics'],'formalRelease':f['release']['decision'],'newCompleteImplementationProofs':0,'sourceCleanAfter':True,'limit':'Native qualification is the current clean-source test binary. Cached app server executable is not qualified. Report-only child Git identities require fresh hosted build; no deployment/production or new serialized snapshot guarantee.'}
(o/'source-correspondence.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k in ['sourceCommit','registeredFilesystemGitMobileHashesVerified','nativeTargeted','nativeFull','formalRelease','newCompleteImplementationProofs']},indent=2))
