from pathlib import Path
import os,subprocess,json,hashlib,re,datetime,signal
w=Path('/private/tmp/tdf-event-finance-report-currency-20261029');o=Path('/private/tmp/tdf-event-finance-currency-qualification-20261029');m=json.loads((o/'preparation-state.json').read_text())['sourceCommit']
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env['PATH']='/private/tmp/tdf-correctness-bin-20261028:/Users/macpro/.ghcup/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin';env['STACK_ROOT']='/Users/macpro/.stack';env['PYTHONDONTWRITEBYTECODE']='1'
def git(*args):return subprocess.check_output(['git',*args],cwd=w)
def sha(b):return hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip()
q=json.loads((o/'root-quality-result.json').read_text());assert q['sourceCommit']==m and all(v==0 for v in q['actualExits'].values())
paths=git('ls-tree','-r','-z','--name-only',m,'--','tdf-hq').decode().rstrip('\0').split('\0');inputs={p:sha((w/p).read_bytes()) for p in paths}
assert all('\n' not in p for p in paths)
raw=subprocess.check_output(['git','cat-file','--batch'],cwd=w,input=''.join(m+':'+p+'\n' for p in paths).encode());pos=0
for p in paths:
 end=raw.index(b'\n',pos);header=raw[pos:end].decode().split();assert header[1]=='blob';n=int(header[2]);assert sha(raw[end+1:end+1+n])==inputs[p],p;pos=end+1+n+1
assert pos==len(raw)
(o/'native-qualified-inputs.json').write_text(json.dumps({'sourceCommit':m,'allBackendTrackedGitSha256':inputs,'environment':'MinimalOS+canonicalPATH/STACK_ROOT; providercredentials/testDSNs absent; SQLiteunitfixtures only; no ownedPG started.'},indent=2)+'\n')
state={'sourceCommit':m,'phase':'BUILDING','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actualExits':{}}
def save():(o/'native-run-state.json').write_text(json.dumps(state,indent=2)+'\n')
def owned_run(cmd,log,label,timeout):
 p=subprocess.Popen(cmd,cwd=w/'tdf-hq',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);state[label+'PID']=p.pid;save()
 try:return p.wait(timeout=timeout)
 except BaseException:
  if p.poll() is None:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
  state['phase']='FAILED_OR_INTERRUPTED_'+label;save();raise
save()
cmd=['/Users/macpro/.ghcup/bin/stack','test','tdf-hq:tdf-hq-test','--no-run-tests']
with (o/'qualified-build.log').open('w') as log:
 code=owned_run(cmd,log,'build',3600)
state['actualExits']['build']=code;save();print('qualified build actualexit'+str(code),flush=True);assert code==0,'Build failure is not a behavioral pass'
binaries=list((w/'tdf-hq/.stack-work/dist').glob('**/build/tdf-hq-test/tdf-hq-test'));assert len(binaries)==1;binary=binaries[0];state['binary']=str(binary);state['binarySha256']=sha(binary.read_bytes())
for label,args in [('targeted',['--match','event finance report']),('full',[])]:
 state['phase']='RUNNING_'+label.upper();save()
 with (o/('qualified-'+label+'.log')).open('w') as log:code=owned_run([str(binary),*args],log,label,1200)
 state['actualExits'][label]=code;save();print(label+' actualexit'+str(code),flush=True);assert code==0,label
 raw=(o/('qualified-'+label+'.log')).read_text();raw=re.sub(r'\x1b\[[0-9;]*m','',raw);matches=re.findall(r'(\d+) examples?, (\d+) failures?(?:, (\d+) pending)?',raw);assert matches,raw[-2000:];examples,failures,pending=matches[-1];assert int(failures)==0
 state[label]={'examples':int(examples),'failures':int(failures),'pending':int(pending or 0)}
 if label=='targeted':assert int(examples)==29 and not pending
 save()
assert sha(binary.read_bytes())==state['binarySha256']
for p,h in inputs.items():assert sha((w/p).read_bytes())==h,p
assert not git('status','--porcelain').strip()
state.update({'phase':'QUALIFIED_TARGETED_AND_FULL','allBackendInputsUnchangedAndGitExact':True,'sourceCleanAfter':True,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()});save();(o/'native-quality.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(state,indent=2),flush=True)
