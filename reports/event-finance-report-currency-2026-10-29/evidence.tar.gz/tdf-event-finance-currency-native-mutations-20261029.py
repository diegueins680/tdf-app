from pathlib import Path
import subprocess,os,json,re,hashlib,signal,time
w=Path('/private/tmp/tdf-event-finance-report-currency-20261029');o=Path('/private/tmp/tdf-event-finance-currency-qualification-20261029')
for _ in range(720):
 if (o/'native-quality.json').exists():break
 time.sleep(5)
else:raise RuntimeError('No native qualification; source mutants not applied')
quality=json.loads((o/'native-quality.json').read_text());m=quality['sourceCommit'];source=w/'tdf-hq/src/TDF/Server/SocialEventsHandlers.hs';original=source.read_bytes();binary=Path(quality['binary'])
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=w)
assert all(v==0 for v in quality['actualExits'].values()) and original==git('show',m+':tdf-hq/src/TDF/Server/SocialEventsHandlers.hs') and not git('status','--porcelain').strip()
binaryHash=sha(binary.read_bytes());assert binaryHash==quality['binarySha256']
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env['PATH']='/Users/macpro/.ghcup/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin';env['STACK_ROOT']='/Users/macpro/.stack';env['PYTHONDONTWRITEBYTECODE']='1'
cache=Path('/private/tmp/tdf-event-finance-currency-native-cache-20261029');runner=cache/'currency-control-tests'
command=['/Users/macpro/.ghcup/bin/stack','exec','--','ghc','--make','-O0','-threaded','-Wall','-isrc','-itest','-odir',str(cache),'-hidir',str(cache),'-stubdir',str(cache),'-o',str(runner),'/private/tmp/tdf-event-finance-currency-spec-main-20261029.hs']
results=[];state={'sourceCommit':m,'phase':'INITIAL_CORRECT_NATIVE_CONTROL','results':results}
def save():(o/'mutation-progress.json').write_text(json.dumps(state,indent=2)+'\n')
def owned_run(cmd,path,timeout):
 with path.open('w') as log:
  p=subprocess.Popen(cmd,cwd=w/'tdf-hq',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);state['activePID']=p.pid;save()
  try:return p.wait(timeout=timeout)
  except BaseException:
   if p.poll() is None:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   raise

def run(label,expected,pattern='event finance report currency'):
 state['phase']=label;save();build=owned_run(command,o/('mutation-'+label+'-build.log'),1800);assert build==0,'A compile error is not an intended mutation failure'
 log=o/('mutation-'+label+'.log');code=owned_run([str(runner),'--match',pattern],log,120);raw=log.read_text();matches=re.findall(r'(\d+) examples?, (\d+) failures?(?:, (\d+) pending)?',raw);assert matches
 examples,failed,pending=matches[-1];assert int(examples)==(29 if pattern=='event finance report' else 14) and int(failed)==expected and not pending,(label,code,matches[-1]);assert code==(1 if expected else 0)
 if label=='currency-guard-bypass': assert raw.count('Expected currency refusal, got')==8
 if label=='late-budget-currency-check': assert 'expected: Just 7' in raw and 'but got: Just 99' in raw
 results.append({'label':label,'sourceSha256':sha(source.read_bytes()),'buildExit':build,'actualExit':code,'examples':int(examples),'assertionFailures':int(failed),'pending':0,'binarySha256':sha(runner.read_bytes()),'logSha256':sha(log.read_bytes())});save();print(label+' actualexit '+str(code)+' cases '+examples+' assertionfailures '+failed,flush=True)
try:
 run('correct-native-control',0,'event finance report')
 text=original.decode();a=text.index('validateEventFinanceReportCurrency eventCurrency rawCurrency =');b=text.index('\ncheckedEventBudgetActualCents ::',a)
 text=text[:a]+'validateEventFinanceReportCurrency _ _ = Right ()\n'+text[b:];source.write_text(text);run('currency-guard-bypass',8)
 text=original.decode();a=text.index('    updateBudgetLine ::');b=text.index('    -- Finance',a);part=text[a:b];guard='        actualCents <- checkedEventBudgetActualCents (defaultCurrency envConfig) eventRec contributingEntries\n';assert part.count(guard)==1;part=part.replace(guard,'');anchor='        mUpdated <- liftIO $ runSqlPool (getEntity lineKey) envPool\n';assert part.count(anchor)==1;part=part.replace(anchor,guard+anchor);source.write_text(text[:a]+part+text[b:]);run('late-budget-currency-check',1)
finally:
 source.write_bytes(original);assert source.read_bytes()==git('show',m+':tdf-hq/src/TDF/Server/SocialEventsHandlers.hs');assert sha(binary.read_bytes())==binaryHash;assert not git('status','--porcelain').strip()
run('restored-native-control',0,'event finance report')
code=owned_run([str(binary),'--match','event finance report'],o/'restored-qualified-targeted.log',120);assert code==0 and '29 examples, 0 failures' in (o/'restored-qualified-targeted.log').read_text();assert sha(binary.read_bytes())==binaryHash
state.update(phase='TWO_REAL_MUTANTS_DETECTED_AND_RESTORED',qualifiedBinarySha256Unchanged=binaryHash,qualifiedRestoredTargetedExit=code,sourceCleanAfter=True,scope='Finite native O0 source mutation sensitivity; not complete mutation coverage or proof. Canonical qualified full-suite binary unchanged.');save();(o/'mutations.json').write_text(json.dumps(state,indent=2)+'\n')
