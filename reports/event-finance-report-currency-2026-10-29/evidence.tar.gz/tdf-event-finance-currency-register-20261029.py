from pathlib import Path
import json, subprocess
w=Path('/private/tmp/tdf-event-finance-report-currency-20261029')
p=w/'formal/system/event-finance-report-currency.md'
p.write_text('''# Consistent event finance reporting currency — PAY-EVENT-REPORT-CURRENCY-001

Authority: explicit owner decision on 29 October 2026: “Refuse totals until
contributing amounts match the event currency.” Existing explicit foreign-currency
entry authoring is intentional and remains supported. Reports have one currency
and no exchange-rate data. Canonical captured-ticket revenue already enforces
its event reporting currency separately.

A successful event finance summary and every budget actual amount must use the
existing event finance metadata/default currency resolver. Every nonzero amount
that contributes must have a valid normalized currency equal to that currency.
A mismatch returns HTTP500; it must never relabel, silently omit or convert a
contributing amount. An unreportable budget edit must refuse before its first
write, preserving the existing row. Explicit event currency overrides the default.

Contributor boundaries retain the existing semantics: validated manual entries
other than void contribute to posted or pending/commitment totals; canonical
captured order identifiers are excluded before inspecting legacy orders; only
paid, refunded and pending nonzero legacy order amounts contribute. Cancelled
and zero-price legacy orders do not require a conversion. Budget actuals retain
their exact posted, event, budget-line and normalized-direction filters. Unlinked,
opposite-direction and zero budget amounts do not require a conversion.

Authoring and individual entry listing continue to use the entry currency. No
provider call, financial row correction, schema/API shape, rate or new currency
catalog is introduced. Existing range checks and supported negative balances
remain. Historical malformed manual dimensions still refuse under their existing
validation. A budget actual with any nonzero contributing entry now invokes the same
event metadata validator as a summary, including its existing budget metadata
validation, even when the selected amounts sum to zero.

Assumptions: trusted existing stored metadata resolver and dimension/status
validation, Persistent/database reads, canonical captured-revenue currency checks
and native compiler. Existing separate reads do not establish a serializable
financial snapshot; refusal-before-write concerns observed entries. PostgreSQL
concurrency, historical data remediation, provider settlement and browser numeric
precision remain separate obligations. No production data is changed by tests.

Verification obligations: real typed Servant handler executions for foreign
creation/persistence plus report refusal, summary liability, budget list/update,
legacy statuses, explicit/default currency, free/void/cancelled/unrelated rows and
zero historical budget amounts. Negative controls must distinguish assertion
failures from fixture/build errors and must observe the unchanged budget row.
Per-commit execution evidence is recorded separately. Passing finite executions
are TESTED, not a proof of every implementation or concurrency behavior. Complete
implementation and refinement proof obligations remain UNKNOWN.
''')
p=w/'formal/system/requirements.json';d=json.loads(p.read_text());before=d['requirements'];base=json.loads(subprocess.check_output(['git','show','a7ae597f7c111d6858561280cdf080d4e62b0d70:formal/system/requirements.json'],cwd=w))['requirements'];assert before==base
identity='PAY-EVENT-REPORT-CURRENCY-001'
r={'id':identity,'title':'Consistent event finance reporting currency','statement':'Refuse single-currency summary and budget totals until every contributing nonzero amount matches the resolved event currency. Refuse an unreportable budget edit before its first write; preserve intentional foreign-currency entry authoring.','domain':'PAY','authority':'Explicit owner decision 2026-10-29: Refuse totals until contributing amounts match the event currency. Existing authoring validator and compatibility tests permit explicit foreign currencies.','source':'formal/system/event-finance-report-currency.md','contract':'formal/system/event-finance-report-currency.md','property':'No successful total relabels, converts or discards a nonzero contributing currency mismatch. Existing contributor filters, canonical exclusion, free tickets and foreign void/cancelled/unrelated rows remain.','actors':['Authorized event manager','Event budget/finance report reader'],'preconditions':['Existing authorization and stored metadata/dimension validation','Existing observed contributor boundaries'],'inputs':['Resolved event reporting currency','Selected manual, legacy and canonical ticket amounts','Budget-line observed posted actual entries'],'state':{'initial':'Selected persisted report inputs','terminal':['Consistent single-currency response','HTTP500 currency refusal before budget edit writes']},'allowedTransitions':['Retain explicit foreign-currency entries for individual reporting','Report amounts matching explicit or default event currency','Ignore only rows already outside contribution filters and zero amounts'],'forbiddenTransitions':['Label foreign contributions with the event currency','Silently drop or convert a contributing foreign amount','Begin budget edit writes before refusing observed foreign actuals'],'effects':['Read-only monetary reporting','Existing authorized budget update after its actual is reportable'],'authorization':'No change to event management, provider, strict-admin or settlement authority.','privacy':'Synthetic native fixtures; no real customer/provider data.','concurrency':'Existing separate reads remain; no new serializable snapshot guarantee.','idempotency':'Same observed inputs produce same currency decision; no new provider calls or retry authority.','failure':'HTTP500 contributing-currency mismatch; range and existing stored metadata refusals retained.','recovery':'Authorized source correction or an explicitly specified future currency conversion design; do not modify financial rows to hide a mismatch.','observability':'Source-bound real handler baseline assertions, mutation controls and CI source selection.','implementation':['tdf-hq/src/TDF/Server/SocialEventsHandlers.hs'],'tests':['tdf-hq/test/TDF/Social/FollowHandlerSpec.hs'],'formalModels':[],'verification':'Real-handler regression and compatibility executions; source-bounded native receipts recorded separately. No complete refinement proof.','evidence':'formal/system/event-finance-report-currency.md; reports/event-finance-report-currency-2026-10-29.json','critical':True,'status':'specified and implemented','confidence':'Explicit owner policy and actual create/store/summary counterexample; runtime qualification bound to source commits.','ambiguity':['Historical mixed-currency rows may block reports until authorized reconciliation; no exchange rates are available.','Production PostgreSQL concurrency/provider/deployment correspondence remains unproven.'],'conformance':{'classification':'PARTIAL','reason':'Finite native real-handler verification; complete implementation and refinement proofs remain unknown.'}}
d['requirements'].append(r);p.write_text(json.dumps(d,indent=2)+'\n');assert len(d['requirements'])==159;print('159 requirements; all158 parent requirements preserved exactly')
