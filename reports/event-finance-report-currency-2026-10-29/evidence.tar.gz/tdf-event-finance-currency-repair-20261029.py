from pathlib import Path
import json
w=Path('/private/tmp/tdf-event-finance-report-currency-20261029')
o=Path('/private/tmp/tdf-event-finance-currency-qualification-20261029')
assert json.loads((o/'baseline-confirmed.json').read_text())['actualFailures']==8
p=w/'tdf-hq/src/TDF/Server/SocialEventsHandlers.hs';s=p.read_text()
def replace(old,new):
 global s
 assert s.count(old)==1, (old[:100],s.count(old))
 s=s.replace(old,new)
replace('''    listBudgetLines eventIdStr = do
        Env{..} <- ask
        (eventKey, _) <- requireManagedEvent eventIdStr''','''    listBudgetLines eventIdStr = do
        Env{..} <- ask
        (eventKey, eventRec) <- requireManagedEvent eventIdStr''')
replace('''                exactActualCents = sum
                    [ toInteger (eventFinanceEntryAmountCents entry)
                    | Entity _ entry <- postedEntries
                    , eventFinanceEntryBudgetLineId entry == Just lineKey
                    , normalizeFinanceDirection (Just (eventFinanceEntryDirection entry)) == lineTypeVal
                    ]
            actualCents <- checkedEventFinanceCents exactActualCents''','''                contributingEntries =
                    [ entryEnt
                    | entryEnt@(Entity _ entry) <- postedEntries
                    , eventFinanceEntryBudgetLineId entry == Just lineKey
                    , normalizeFinanceDirection (Just (eventFinanceEntryDirection entry)) == lineTypeVal
                    ]
            actualCents <- checkedEventBudgetActualCents (defaultCurrency envConfig) eventRec contributingEntries''')
replace('''    updateBudgetLine eventIdStr lineIdStr dto = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        (eventKey, _) <- requireManagedEvent eventIdStr''','''    updateBudgetLine eventIdStr lineIdStr dto = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        (eventKey, eventRec) <- requireManagedEvent eventIdStr''')
replace('''        let exactActualCents =
                sum
                    [ toInteger (eventFinanceEntryAmountCents entry)
                    | Entity _ entry <- postedEntries
                    , normalizeFinanceDirection (Just (eventFinanceEntryDirection entry)) == lineTypeVal
                    ]
        actualCents <- checkedEventFinanceCents exactActualCents''','''        let contributingEntries =
                [ entryEnt
                | entryEnt@(Entity _ entry) <- postedEntries
                , normalizeFinanceDirection (Just (eventFinanceEntryDirection entry)) == lineTypeVal
                ]
        actualCents <- checkedEventBudgetActualCents (defaultCurrency envConfig) eventRec contributingEntries''')
replace('(traverse storedFinanceEntrySummaryFields allFinanceRows)','(traverse (storedFinanceEntrySummaryFields eventCurrencyVal) allFinanceRows)')
replace('(traverse storedTicketOrderSummaryFields (filter','(traverse (storedTicketOrderSummaryFieldsInCurrency eventCurrencyVal) (filter')
replace('''storedFinanceEntrySummaryFields :: Entity EventFinanceEntry -> Either T.Text (Int, T.Text, T.Text, T.Text)
storedFinanceEntrySummaryFields (Entity _ entryRec) = do
    (directionVal, sourceVal, statusVal) <- validateStoredFinanceEntryDimensions entryRec
    pure (eventFinanceEntryAmountCents entryRec, directionVal, sourceVal, statusVal)''','''-- Authoring may retain other currencies; a single-currency report cannot
-- combine their contributing amounts without an established conversion.
validateEventFinanceReportCurrency :: T.Text -> T.Text -> Either T.Text ()
validateEventFinanceReportCurrency eventCurrency rawCurrency =
    case normalizeEventCurrencyCode rawCurrency of
        Just currency | currency == eventCurrency -> Right ()
        _ -> Left "Contributing amount currency does not match the event reporting currency"

checkedEventBudgetActualCents :: T.Text -> SocialEvent -> [Entity EventFinanceEntry] -> AppM Int
checkedEventBudgetActualCents reportDefault eventRec entries = do
    let contributingAmounts = filter ((/= 0) . eventFinanceEntryAmountCents . entityVal) entries
    unless (null contributingAmounts) $ do
        (eventCurrency, _) <-
            either (throwError . storedEventMetadataServerError) pure
                (validateStoredEventFinanceMetadata reportDefault eventRec)
        forM_ contributingAmounts $ \\(Entity _ entry) ->
            either (throwError . financeInvariantServerError) pure
                (validateEventFinanceReportCurrency eventCurrency (eventFinanceEntryCurrency entry))
    checkedEventFinanceCents (sum [toInteger (eventFinanceEntryAmountCents entry) | Entity _ entry <- entries])

storedFinanceEntrySummaryFields :: T.Text -> Entity EventFinanceEntry -> Either T.Text (Int, T.Text, T.Text, T.Text)
storedFinanceEntrySummaryFields eventCurrency (Entity _ entryRec) = do
    (directionVal, sourceVal, statusVal) <- validateStoredFinanceEntryDimensions entryRec
    when (statusVal /= "void") $
        validateEventFinanceReportCurrency eventCurrency (eventFinanceEntryCurrency entryRec)
    pure (eventFinanceEntryAmountCents entryRec, directionVal, sourceVal, statusVal)''')
anchor='''ticketOrderAccountingEntriesEither ::
'''
replace(anchor,'''storedTicketOrderSummaryFieldsInCurrency :: T.Text -> Entity EventTicketOrder -> Either T.Text (Int, T.Text)
storedTicketOrderSummaryFieldsInCurrency eventCurrency orderEnt@(Entity _ orderRec) = do
    fields@(amountCents, statusVal) <- storedTicketOrderSummaryFields orderEnt
    when (amountCents /= 0 && statusVal /= "cancelled") $
        validateEventFinanceReportCurrency eventCurrency (eventTicketOrderCurrency orderRec)
    pure fields

'''+anchor)
p.write_text(s)
print('Applied only currency report guards after confirmed eight baseline assertion failures')
