{-# LANGUAGE OverloadedStrings #-}

module TDF.Social.FollowHandlerSpec (spec) where

import Control.Concurrent (newEmptyMVar, putMVar, takeMVar, threadDelay, tryPutMVar)
import Control.Concurrent.Async (wait, withAsync)
import Control.Exception (bracket, finally)
import Control.Monad (forM_, void)
import qualified Data.ByteString.Char8 as BS8
import Database.Persist.Postgresql (createPostgresqlPool)
import System.Environment (lookupEnv)
import Control.Monad.IO.Class (liftIO)
import Control.Monad.Logger (runNoLoggingT, runStdoutLoggingT)
import Control.Monad.Trans.Reader (ReaderT, runReaderT)
import qualified Data.ByteString.Lazy.Char8 as BL8
import qualified Data.Aeson as Aeson
import qualified Data.Aeson.KeyMap as AesonKeyMap
import Data.Char (chr)
import Data.Int (Int64)
import Data.List (sort)
import Data.Pool (destroyAllResources)
import qualified Data.Text as T
import Data.Time (UTCTime (..), fromGregorian, secondsToDiffTime)
import Data.Time.Clock (getCurrentTime)
import qualified Data.UUID as UUID
import qualified Data.UUID.V4 as UUIDV4
import Database.Persist (Entity (..), count, get, insert, insertKey, selectList, toPersistValue, (==.))
import Database.Persist.Sql (Single (..), rawSql, SqlPersistT, fromSqlKey, rawExecute, runSqlPool, toSqlKey)
import Database.Persist.Sqlite (createSqlitePool)
import Servant (Handler, NoContent (..), ServerError (errBody, errHTTPCode), (:<|>) (..))
import Servant.Multipart
    ( FileData (..)
    , FromMultipart (fromMultipart)
    , Input (..)
    , MultipartData (..)
    , Tmp
    )
import Servant.Server.Internal.Handler (runHandler)
import System.Directory (createDirectoryIfMissing, doesDirectoryExist, doesFileExist, getTemporaryDirectory)
import System.FilePath ((</>))
import System.IO.Temp (withSystemTempDirectory)
import Test.Hspec

import TDF.API.SocialEventsAPI
    ( EventImageUploadDTO (..)
    , EventImageUploadForm (..)
    , validateEventImageUploadForm
    )
import TDF.DTO.SocialEventsDTO
    ( ArtistDTO
    , ArtistFollowerDTO (..)
    , EventBudgetLineDTO (..)
    , EventFinanceSummaryDTO (..)
    , EventFinanceEntryDTO (..)
    , EventDTO (..)
    , EventMetadataUpdateDTO (..)
    , EventMomentCreateDTO (..)
    , EventMomentDTO
    , EventSourceDTO (..)
    , EventUpdateDTO (..)
    , InvitationDTO (..)
    , InvitationUpdateDTO (..)
    , NullableFieldUpdate (..)
    , RefundDTO (..)
    , RefundRequestDTO (..)
    , RejectionReasonDTO (..)
    , RsvpCreateDTO (..)
    , RsvpDTO (RsvpDTO)
    , RsvpSummaryDTO (..)
    , StripePaymentIntentDTO
    , TicketDTO
    , TicketPurchaseRequestDTO (..)
    , TicketPurchaseWithPromoDTO (..)
    , TicketTransferDTO
    )
import TDF.Auth (AuthedUser (..), modulesForRoles)
import qualified TDF.Config as Config
import TDF.DB (Env (..))
import TDF.Models (Party (..), RoleEnum (Admin, Fan))
import TDF.Models.SocialEventsModels
import TDF.Server.SocialEventsHandlers
    ( assignMissingEventOrganizer
    , postgresVisibleImportedMetadataClause
    , decodeStoredPromoCodeTierIds
    , followArtistDb
    , removeSocialEventAssets
    , resolveExistingPartyIdText
    , resolveUniqueRsvpRow
    , socialEventsServer
    , suppressImportedEventMetadata
    , decodeRsvpCursor
    , validateRsvpPageLimit
    , validateEventImageUploadSize
    , validateEventDeleteAccess
    , validateEventDeletionCheckoutHistory
    , validateEventMetadataUpdate
    , validateEventMetadataUrlField
    , validateInvitationFromPartyId
    , validateInvitationUpdateAuthorization
    , validateSocialEventsListFilter
    , validateSocialEventsListOffset
    , validateStoredEventFinanceMetadata
    , validateTicketPurchaseBuyerEmail
    , validateTicketPurchaseBuyerName
    , validateVenueCreateUpdateFields
    )

mkEventImageUploadMultipart :: [(T.Text, T.Text)] -> [FileData Tmp] -> MultipartData Tmp
mkEventImageUploadMultipart fields uploads =
    MultipartData
        { inputs = map (uncurry Input) fields
        , files = uploads
        }

mkEventImageUploadFile :: T.Text -> FileData Tmp
mkEventImageUploadFile fileName =
    FileData
        { fdInputName = "file"
        , fdFileName = fileName
        , fdFileCType = "image/png"
        , fdPayload = "/tmp/mock-event-image-upload"
        }

spec :: Spec
spec = describe "social event handler helpers" $ do
    it "bounds RSVP feed pages and fails closed on malformed cursors" $ do
        validateRsvpPageLimit Nothing `shouldBe` Right 20
        validateRsvpPageLimit (Just 1) `shouldBe` Right 1
        validateRsvpPageLimit (Just 50) `shouldBe` Right 50
        mapM_ (\limit -> case validateRsvpPageLimit (Just limit) of
            Left err -> errHTTPCode err `shouldBe` 400
            Right value -> expectationFailure ("Expected invalid RSVP page limit, got " <> show value)) [0, 51]
        case decodeRsvpCursor "not-a-valid-cursor" of
            Left err -> do
                errHTTPCode err `shouldBe` 400
                BL8.unpack (errBody err) `shouldContain` "cursor is malformed"
            Right value -> expectationFailure ("Expected malformed RSVP cursor to fail, got " <> show value)

    it "rejects duplicate RSVP rows instead of updating an arbitrary existing match" $ do
        now <- getCurrentTime
        let rsvpRow rowId status =
                Entity
                    (toSqlKey rowId)
                    EventRsvp
                        { eventRsvpEventId = toSqlKey 7
                        , eventRsvpPartyId = "42"
                        , eventRsvpStatus = status
                        , eventRsvpShowOnProfile = False
                        , eventRsvpVisibilityDecidedAt = Nothing
                        , eventRsvpMetadata = Nothing
                        , eventRsvpCreatedAt = now
                        , eventRsvpUpdatedAt = now
                        }

        case resolveUniqueRsvpRow [rsvpRow 1 "accepted", rsvpRow 2 "maybe"] of
            Left err -> do
                errHTTPCode err `shouldBe` 409
                BL8.unpack (errBody err) `shouldContain` "Multiple RSVP rows exist"
            Right value ->
                expectationFailure ("Expected duplicate RSVP rows to be rejected, got: " <> show value)

    it "creates, updates, reads, summarizes, and idempotently deletes only the session Party RSVP" $ do
        pool <- runNoLoggingT $ createSqlitePool ":memory:" 1
        runSqlPool initializeSocialSchema pool
        now <- getCurrentTime
        let eventKey :: SocialEventId
            eventKey = toSqlKey 71
            user = socialEventUser 2
            (getMine, upsertMine, deleteMine, getSummary) = socialEventRsvpHandlersFor user
            env = Env { envPool = pool, envConfig = error "envConfig is unused by RSVP handlers" }
        runSqlPool
            (do
                rawExecute
                    "INSERT INTO workflow_state_capability(state_id,capability_code,enabled) VALUES (?, 'public-listable', 1), (?, 'rsvp', 1)"
                    [toPersistValue socialEventWorkflowStateFixtureId, toPersistValue socialEventWorkflowStateFixtureId]
                insertKey eventKey
                    ((seedSocialEvent "1" "RSVP integration event" now)
                        { socialEventMetadata = Just "{\"isPublic\":true}"
                        , socialEventWorkflowStateId = Just socialEventWorkflowStateFixtureId
                        })
            )
            pool

        first <- runHandler $ runReaderT (upsertMine "71" (RsvpCreateDTO "accepted" True)) env
        case first of
            Right (RsvpDTO _ actualStatus actualShowOnProfile _ _) -> do
                actualStatus `shouldBe` "accepted"
                actualShowOnProfile `shouldBe` True
            Left err -> expectationFailure ("Expected first RSVP upsert, got: " <> show err)

        second <- runHandler $ runReaderT (upsertMine "71" (RsvpCreateDTO "maybe" False)) env
        case second of
            Right (RsvpDTO _ actualStatus actualShowOnProfile _ _) -> do
                actualStatus `shouldBe` "maybe"
                actualShowOnProfile `shouldBe` False
            Left err -> expectationFailure ("Expected RSVP update, got: " <> show err)

        rows <- runSqlPool (selectList [EventRsvpEventId ==. eventKey] []) pool
        length rows `shouldBe` 1
        map (eventRsvpPartyId . entityVal) rows `shouldBe` ["2"]
        current <- runHandler $ runReaderT (getMine "71") env
        fmap (fmap (\(RsvpDTO _ statusValue _ _ _) -> statusValue)) current `shouldBe` Right (Just "maybe")
        totals <- runHandler $ runReaderT (getSummary "71") env
        totals `shouldBe` Right (RsvpSummaryDTO 0 1)

        declined <- runHandler $ runReaderT (upsertMine "71" (RsvpCreateDTO "declined" True)) env
        case declined of
            Right (RsvpDTO _ actualStatus actualShowOnProfile _ _) -> do
                actualStatus `shouldBe` "declined"
                actualShowOnProfile `shouldBe` False
            Left err -> expectationFailure ("Expected declined RSVP update, got: " <> show err)
        declinedTotals <- runHandler $ runReaderT (getSummary "71") env
        declinedTotals `shouldBe` Right (RsvpSummaryDTO 0 0)

        firstDelete <- runHandler $ runReaderT (deleteMine "71") env
        secondDelete <- runHandler $ runReaderT (deleteMine "71") env
        firstDelete `shouldBe` Right NoContent
        secondDelete `shouldBe` Right NoContent
        remaining <- runSqlPool (count [EventRsvpEventId ==. eventKey]) pool
        remaining `shouldBe` 0

    it "rejects empty or oversized event image uploads before copying files" $ do
        case validateEventImageUploadSize 1 of
            Right () -> pure ()
            Left err ->
                expectationFailure
                    ("Expected valid event image upload size, got: " <> show err)

        let assertInvalid expectedMessage size =
                case validateEventImageUploadSize size of
                    Left err -> do
                        errHTTPCode err `shouldBe` 400
                        BL8.unpack (errBody err) `shouldContain` expectedMessage
                    Right value ->
                        expectationFailure
                            ("Expected invalid event image upload size to be rejected, got: " <> show value)

        assertInvalid "event image upload size is invalid" (-1)
        assertInvalid "event image upload must not be empty" 0
        assertInvalid "event image upload must be 10 MB or smaller" (10 * 1024 * 1024 + 1)

    it "revalidates event image upload names before handler filename sanitization" $ do
        case fromMultipart
            ( mkEventImageUploadMultipart
                [("name", "  Poster.png  ")]
                [mkEventImageUploadFile "camera.png"]
            ) :: Either String EventImageUploadForm of
            Right form ->
                eiuName form `shouldBe` Just "Poster.png"
            Left err ->
                expectationFailure
                    ("Expected valid event image upload multipart data, got: " <> err)

        let assertInvalid expectedMessage form =
                case validateEventImageUploadForm form of
                    Left err -> T.unpack err `shouldContain` expectedMessage
                    Right value ->
                        expectationFailure
                            ( "Expected forged event image upload form to be rejected, got: "
                                <> show (eiuName value)
                            )

        assertInvalid
            "Uploaded browser file name must not contain path separators"
            EventImageUploadForm
                { eiuFile = mkEventImageUploadFile "events/poster.png"
                , eiuName = Just "poster.png"
                }
        assertInvalid
            "Uploaded image name must not contain leading, trailing, or repeated dots"
            EventImageUploadForm
                { eiuFile = mkEventImageUploadFile "camera.png"
                , eiuName = Just "poster..png"
                }
        assertInvalid
            "Uploaded browser file name must not contain leading, trailing, or repeated dots"
            EventImageUploadForm
                { eiuFile = mkEventImageUploadFile "poster..png"
                , eiuName = Nothing
                }
        assertInvalid
            "Uploaded image extension must match its MIME type"
            EventImageUploadForm
                { eiuFile = mkEventImageUploadFile "camera.jpg"
                , eiuName = Just "poster.png"
                }

    it "publishes event posters atomically and requires a real session for moment uploads" $
        withSystemTempDirectory "social-event-image-lock" $ \assetsRoot -> do
            cfg <- Config.loadConfig
            pool <- runNoLoggingT $ createSqlitePool ":memory:" 1
            runSqlPool initializeSocialSchema pool
            now <- getCurrentTime
            let visibleEventKey :: SocialEventId
                visibleEventKey = toSqlKey 29
                suppressedEventKey :: SocialEventId
                suppressedEventKey = toSqlKey 30
                uploadSource = assetsRoot </> "upload.png"
                uploadForm =
                    EventImageUploadForm
                        { eiuFile =
                            FileData
                                { fdInputName = "file"
                                , fdFileName = "upload.png"
                                , fdFileCType = "image/png"
                                , fdPayload = uploadSource
                                }
                        , eiuName = Just "poster.png"
                        }
                env =
                    Env
                        { envPool = pool
                        , envConfig = cfg{Config.assetsRootDir = assetsRoot}
                        }
            writeFile uploadSource "png"
            _ <- runSqlPool
                ( do
                    insertKey visibleEventKey ((seedSocialEvent "3" "Visible event" now)
                        { socialEventMetadata = Just "{\"isPublic\":true,\"imageUrl\":null,\"_discoveryOwned\":{\"title\":\"Visible event\",\"imageUrl\":null,\"isPublic\":true}}" })
                    insertKey
                        suppressedEventKey
                        (seedSocialEvent "3" "Suppressed event" now)
                            { socialEventMetadata =
                                Just "{\"ticketUrl\":null,\"imageUrl\":null,\"isPublic\":false,\"currency\":\"USD\"}"
                            }
                    insert
                        ExternalEventRef
                            { externalEventRefProvider = "ticketmaster"
                            , externalEventRefExternalId = "tm-upload-suppressed"
                            , externalEventRefEventId = suppressedEventKey
                            , externalEventRefCity = "Quito"
                            , externalEventRefCountryCode = Just "EC"
                            , externalEventRefSourceUrl = Nothing
                            , externalEventRefPriceCents = Nothing
                            , externalEventRefCurrency = Just "USD"
                            , externalEventRefLastSeenAt = now
                            , externalEventRefMissingRuns = 0
                            , externalEventRefSourceStatus = externalEventRefSuppressedStatus
                            }
                )
                pool

            let unownedEventKey = toSqlKey 31 :: SocialEventId
            runSqlPool
                (insertKey unownedEventKey (seedSocialEvent "3" "Unowned event" now){socialEventOrganizerPartyId = Nothing})
                pool
            unowned <-
                runHandler $
                    runReaderT
                        (socialEventImageUploadHandlerFor (socialEventUser 2) "31" uploadForm)
                        env
            case unowned of
                Left err -> do
                    errHTTPCode err `shouldBe` 403
                    BL8.unpack (errBody err) `shouldContain` "This event has no organizer"
                Right response ->
                    expectationFailure ("Expected the unowned event upload to fail, got: " <> show response)
            fmap socialEventOrganizerPartyId <$> runSqlPool (get unownedEventKey) pool
                `shouldReturn` Just Nothing
            doesDirectoryExist (assetsRoot </> "social-events" </> "events" </> "31")
                `shouldReturn` False

            uploaded <-
                runHandler $
                    runReaderT
                        (socialEventImageUploadHandlerFor (strictAdminSocialEventUser 3) "29" uploadForm)
                        env
            case uploaded of
                Left err -> expectationFailure ("Expected event image upload to succeed, got: " <> show err)
                Right response ->
                    doesFileExist (assetsRoot </> T.unpack (eiuPath response)) `shouldReturn` True

            storedAfterUpload <- runSqlPool (get visibleEventKey) pool
            case storedAfterUpload >>= socialEventMetadata >>= Aeson.decode . BL8.pack . T.unpack of
                Just (Aeson.Object fields) ->
                    AesonKeyMap.lookup "_discoveryOwned" fields `shouldBe`
                        Just (Aeson.object ["title" Aeson..= ("Visible event" :: T.Text), "isPublic" Aeson..= True])
                _ -> expectationFailure "Upload lost canonical ownership metadata"

            rejected <-
                runHandler $
                    runReaderT
                        (socialEventImageUploadHandlerFor (strictAdminSocialEventUser 3) "30" uploadForm)
                        env
            case rejected of
                Left err -> errHTTPCode err `shouldBe` 404
                Right response ->
                    expectationFailure
                        ("Expected tombstoned image upload to fail, got: " <> show response)
            doesDirectoryExist
                (assetsRoot </> "social-events" </> "events" </> "30")
                `shouldReturn` False

            uploadedMoment <-
                runHandler $
                    runReaderT
                        (socialEventMomentImageUploadHandlerFor (strictAdminSocialEventUser 3) "29" uploadForm)
                        env
            -- A synthetic SQLite actor has no real bearer witness. Positive
            -- moment upload/bytes/path/tombstone assertions now run through the
            -- real PostgreSQL/API lane in test-event-memories-http.py in CI.
            case uploadedMoment of
                Left err -> errHTTPCode err `shouldBe` 401
                Right response -> expectationFailure ("A synthetic actor must not upload moment media: " <> show response)
            doesDirectoryExist (assetsRoot </> "social-events" </> "events" </> "29" </> "moments")
                `shouldReturn` False

            rejectedMoment <-
                runHandler $
                    runReaderT
                        (socialEventMomentImageUploadHandlerFor (strictAdminSocialEventUser 3) "30" uploadForm)
                        env
            case rejectedMoment of
                Left err -> errHTTPCode err `shouldBe` 401
                Right response ->
                    expectationFailure
                        ("Expected tombstoned moment image upload to fail, got: " <> show response)
            doesDirectoryExist
                (assetsRoot </> "social-events" </> "events" </> "30")
                `shouldReturn` False

    it "rejects unsafe social event metadata URLs before storing public links" $ do
        validateEventMetadataUrlField
            "eventTicketUrl"
            (Just " https://tickets.example.com/event?id=42 ")
            `shouldBe` Right (Just "https://tickets.example.com/event?id=42")
        validateEventMetadataUrlField "eventImageUrl" (Just "   ")
            `shouldBe` Right Nothing

        let assertInvalid field raw expectedMessage =
                case validateEventMetadataUrlField field (Just raw) of
                    Left err -> do
                        errHTTPCode err `shouldBe` 400
                        BL8.unpack (errBody err) `shouldContain` expectedMessage
                    Right value ->
                        expectationFailure
                            ("Expected unsafe event metadata URL to be rejected, got: " <> show value)

        assertInvalid
            "eventTicketUrl"
            "http://tickets.example.com/event"
            "eventTicketUrl must be an absolute https URL"
        assertInvalid
            "eventImageUrl"
            "https://localhost/event.jpg"
            "eventImageUrl must be an absolute https URL"
        assertInvalid
            "eventTicketUrl"
            ("https://tickets.example.com/event/" <> T.replicate 2049 "a")
            "eventTicketUrl must be 2048 characters or fewer"

        case validateEventMetadataUpdate
            emptyEventMetadataUpdate
                { emuTicketUrl = FieldValue " https://tickets.example.com/event "
                , emuImageUrl = FieldValue "javascript:alert(1)"
                } of
            Left err -> do
                errHTTPCode err `shouldBe` 400
                BL8.unpack (errBody err)
                    `shouldContain` "eventImageUrl must be an absolute https URL"
            Right value ->
                expectationFailure
                    ("Expected metadata update with unsafe image URL to fail, got: " <> show value)

    it "rejects malformed stored event finance metadata instead of falling back to USD" $ do
        let eventWithMetadata rawMetadata =
                (seedSocialEvent "1" "Finance event" socialEventStartFixture)
                    { socialEventMetadata = rawMetadata
                    }
            assertInvalid rawMetadata expectedMessage =
                case validateStoredEventFinanceMetadata "USD" (eventWithMetadata rawMetadata) of
                    Left message ->
                        T.unpack message `shouldContain` expectedMessage
                    Right value ->
                        expectationFailure
                            ("Expected invalid stored event metadata to be rejected, got: " <> show value)

        validateStoredEventFinanceMetadata "USD" (eventWithMetadata Nothing)
            `shouldBe` Right ("USD", Nothing)
        validateStoredEventFinanceMetadata "USD"
            (eventWithMetadata (Just "{\"currency\":\"eur\",\"budgetCents\":2500}"))
            `shouldBe` Right ("EUR", Just 2500)
        assertInvalid (Just "not-json") "Stored event metadata is invalid JSON"
        assertInvalid
            (Just "{\"currency\":\"usd\",\"budgetCents\":2500,\"curency\":\"eur\"}")
            "Stored event metadata contains unknown fields: curency"
        assertInvalid (Just "{\"currency\":\"USDT\"}") "Stored event currency is invalid"
        assertInvalid (Just "{\"budgetCents\":-1}") "Stored event budget is invalid"

    describe "event finance report range" $ do
        it "rejects overflowing budget actuals rather than reporting a negative sum" $
            withFinanceRangeEnv $ \env -> do
                rangeBudget env 1 "expense" 0
                rangeEntry env "expense" "manual" "posted" maxBound
                rangeEntry env "expense" "manual" "posted" 1
                rangeReject =<< rangeBudgetList env

        it "refuses an overflowing budget update before changing stored fields" $
            withFinanceRangeEnv $ \env -> do
                rangeBudget env 1 "expense" 7
                rangeEntry env "expense" "manual" "posted" maxBound
                rangeEntry env "expense" "manual" "posted" 1
                rangeReject =<< rangeBudgetUpdate env (rangeBudgetPayload 99)
                stored <- runSqlPool (get (toSqlKey 1 :: EventBudgetLineId)) (envPool env)
                fmap eventBudgetLinePlannedCents stored `shouldBe` Just 7

        it "reports the exact supported budget boundary" $
            withFinanceRangeEnv $ \env -> do
                rangeBudget env 1 "expense" 0
                rangeEntry env "expense" "manual" "posted" (maxBound - 1)
                rangeEntry env "expense" "manual" "posted" 1
                result <- rangeBudgetList env
                fmap (map eblActualCents) result `shouldBe` Right [Just maxBound]

        forM_ ["income", "expense"] $ \direction -> do
            it ("rejects overflowing planned " <> T.unpack direction) $
                withFinanceRangeEnv $ \env -> do
                    rangeBudget env 1 direction maxBound
                    rangeBudget env 2 direction 1
                    rangeReject =<< rangeSummary env
            it ("rejects overflowing posted manual " <> T.unpack direction) $
                withFinanceRangeEnv $ \env -> do
                    rangeEntry env direction "manual" "posted" maxBound
                    rangeEntry env direction "manual" "posted" 1
                    rangeReject =<< rangeSummary env

        forM_ [("manual", "income"), ("manual", "expense"),
               ("contract_commitment", "expense"), ("purchase_order", "expense")] $ \(source, direction) ->
            it ("rejects overflowing draft " <> T.unpack source <> " " <> T.unpack direction) $
                withFinanceRangeEnv $ \env -> do
                    rangeEntry env direction source (if source `elem` ["contract_commitment", "purchase_order"] then "posted" else "draft") maxBound
                    rangeEntry env direction source "draft" 1
                    rangeReject =<< rangeSummary env

        it "checks combined canonical and legacy ticket revenue before narrowing" $
            withFinanceRangeEnv $ \env -> do
                rangeTicket env 1 "paid" maxBound
                rangeTicket env 2 "paid" 1
                runSqlPool (do
                    rawExecute "INSERT INTO commerce_checkout_session VALUES ('canonical',? ,0,'USD')" [toPersistValue (maxBound :: Int)]
                    rawExecute "INSERT INTO event_ticket_checkout_runtime VALUES (1,7,'canonical')" []) (envPool env)
                rangeReject =<< rangeSummary env

        it "checks combined manual and ticket receivables" $
            withFinanceRangeEnv $ \env -> do
                rangeEntry env "income" "manual" "draft" maxBound
                rangeTicket env 1 "pending" 1
                rangeReject =<< rangeSummary env

        it "preserves exact supported sums and legitimate negative balances" $
            withFinanceRangeEnv $ \env -> do
                rangeBudget env 1 "expense" 10
                rangeEntry env "income" "manual" "posted" 20
                rangeEntry env "expense" "liability_payment" "posted" 30
                result <- rangeSummary env
                fmap (\dto -> (efsActualIncomeCents dto, efsActualExpenseCents dto,
                    efsNetCents dto, efsLiabilityBalanceCents dto, efsBudgetVarianceCents dto,
                    efsBudgetUtilizationPct dto)) result `shouldBe` Right (20,30,-10,-30,Just (-20),Just 300)

        it "allows maxBound and keeps posted, draft and void filters separate" $
            withFinanceRangeEnv $ \env -> do
                rangeEntry env "income" "manual" "posted" (maxBound - 1)
                rangeEntry env "income" "manual" "posted" 1
                rangeEntry env "income" "manual" "void" maxBound
                rangeEntry env "expense" "manual" "draft" 3
                result <- rangeSummary env
                fmap (\dto -> (efsActualIncomeCents dto,efsAccountsPayableCents dto,
                    efsActualExpenseCents dto,efsBudgetCents dto)) result `shouldBe` Right (maxBound,3,0,Nothing)

    describe "event finance report currency" $ do
        it "keeps EUR authoring allowed but refuses to label its income as USD" $
            withFinanceRangeEnv $ \env -> do
                currencyEntry env "EUR" "income" "posted" 100 Nothing
                rows <- runSqlPool (selectList [EventFinanceEntryEventId ==. toSqlKey 7] []) (envPool env)
                [(eventFinanceEntryCurrency row,eventFinanceEntryAmountCents row) | Entity _ row <- rows]
                    `shouldBe` [("EUR",100)]
                currencyReject =<< rangeSummary env

        it "refuses a mismatched pending amount in accounts payable" $
            withFinanceRangeEnv $ \env -> do
                currencyEntry env "EUR" "expense" "pending" 20 Nothing
                currencyReject =<< rangeSummary env

        it "refuses a mismatched posted amount in budget actuals" $
            withFinanceRangeEnv $ \env -> do
                rangeBudget env 1 "expense" 1000
                currencyEntry env "EUR" "expense" "posted" 100 (Just "1")
                currencyReject =<< rangeBudgetList env

        it "refuses mismatched budget actuals before saving the requested edit" $
            withFinanceRangeEnv $ \env -> do
                rangeBudget env 1 "expense" 7
                currencyEntry env "EUR" "expense" "posted" 100 (Just "1")
                currencyReject =<< rangeBudgetUpdate env (rangeBudgetPayload 99)
                row <- runSqlPool (get (toSqlKey 1 :: EventBudgetLineId)) (envPool env)
                fmap eventBudgetLinePlannedCents row `shouldBe` Just 7

        forM_ ["paid", "refunded", "pending"] $ \status ->
            it ("refuses mismatched legacy ticket " <> T.unpack status <> " amounts") $
                withFinanceRangeEnv $ \env -> do
                    currencyTicket env "EUR" status 100
                    currencyReject =<< rangeSummary env

        it "ignores valid foreign void entries when computing USD totals" $
            withFinanceRangeEnv $ \env -> do
                currencyEntry env "EUR" "income" "void" 100 Nothing
                currencyEntry env "USD" "income" "posted" 30 Nothing
                result <- rangeSummary env
                fmap (\dto -> (efsCurrency dto,efsActualIncomeCents dto,efsNetCents dto)) result
                    `shouldBe` Right ("USD",30,30)

        it "ignores a cancelled foreign ticket that contributes no amount" $
            withFinanceRangeEnv $ \env -> do
                currencyTicket env "EUR" "cancelled" 100
                result <- rangeSummary env
                fmap (\dto -> (efsCurrency dto,efsTicketPaidRevenueCents dto,efsTicketPendingRevenueCents dto)) result
                    `shouldBe` Right ("USD",0,0)

        it "keeps a free foreign legacy ticket reportable without inventing FX" $
            withFinanceRangeEnv $ \env -> do
                currencyTicket env "EUR" "paid" 0
                result <- rangeSummary env
                fmap (\dto -> (efsCurrency dto,efsTicketPaidRevenueCents dto,efsActualIncomeCents dto)) result
                    `shouldBe` Right ("USD",0,0)

        it "ignores foreign entries outside a budget line's actual filters" $
            withFinanceRangeEnv $ \env -> do
                rangeBudget env 1 "expense" 1000
                currencyEntry env "USD" "expense" "posted" 30 (Just "1")
                currencyEntry env "EUR" "expense" "posted" 20 Nothing
                currencyEntry env "EUR" "income" "posted" 50 (Just "1")
                result <- rangeBudgetList env
                fmap (map eblActualCents) result `shouldBe` Right [Just 30]

        it "uses the explicit event currency rather than its configured default" $
            withFinanceRangeEnv $ \env -> do
                currencyEvent env "eur"
                currencyEntry env "EUR" "income" "posted" 100 Nothing
                result <- rangeSummary env
                fmap (\dto -> (efsCurrency dto,efsActualIncomeCents dto)) result `shouldBe` Right ("EUR",100)

        it "refuses USD contributions when the event explicitly reports EUR" $
            withFinanceRangeEnv $ \env -> do
                currencyEvent env "EUR"
                currencyEntry env "USD" "income" "posted" 100 Nothing
                currencyReject =<< rangeSummary env

    it "decodes stored promo-code tier ids only from JSON text arrays" $ do
        decodeStoredPromoCodeTierIds Nothing `shouldBe` Nothing
        decodeStoredPromoCodeTierIds (Just "[\"tier-vip\",\"tier-general\"]")
            `shouldBe` Just ["tier-vip", "tier-general"]
        decodeStoredPromoCodeTierIds (Just "not-json") `shouldBe` Nothing
        decodeStoredPromoCodeTierIds (Just "{\"tierIds\":[\"tier-vip\"]}")
            `shouldBe` Nothing
        decodeStoredPromoCodeTierIds (Just "[1,2]")
            `shouldBe` Nothing

    it "rejects hidden venue name markers before venue create/update persistence" $ do
        validateVenueCreateUpdateFields " Teatro TDF " Nothing Nothing (Just 250)
            `shouldBe` Right ()

        let hiddenFormat = T.singleton (chr 0x200D)
            assertInvalid rawName =
                case validateVenueCreateUpdateFields rawName Nothing Nothing Nothing of
                    Left err -> do
                        errHTTPCode err `shouldBe` 400
                        BL8.unpack (errBody err)
                            `shouldContain` "hidden formatting characters"
                    Right value ->
                        expectationFailure
                            ("Expected unsafe venue name to be rejected, got: " <> show value)

        assertInvalid ("Teatro" <> hiddenFormat <> "TDF")
        assertInvalid ("Teatro" <> T.singleton (chr 0x2028) <> "TDF")

    it "rejects deep social event list offsets before running list fallbacks" $ do
        validateSocialEventsListOffset Nothing `shouldBe` Right 0
        validateSocialEventsListOffset (Just 10000) `shouldBe` Right 10000

        let assertInvalid expectedMessage result =
                case result of
                    Left err -> do
                        errHTTPCode err `shouldBe` 400
                        BL8.unpack (errBody err) `shouldContain` expectedMessage
                    Right value ->
                        expectationFailure
                            ( "Expected social event offset to be rejected, got: "
                                <> show value
                            )

        assertInvalid
            "offset must be greater than or equal to 0"
            (validateSocialEventsListOffset (Just (-1)))
        assertInvalid
            "offset must be 10000 or fewer"
            (validateSocialEventsListOffset (Just 10001))

    it "rejects oversized or unsafe social event list filters before DB fallback scans" $ do
        validateSocialEventsListFilter "city" Nothing `shouldBe` Right Nothing
        validateSocialEventsListFilter "city" (Just "  Quito  ")
            `shouldBe` Right (Just "Quito")
        validateSocialEventsListFilter "q" (Just "   ")
            `shouldBe` Right Nothing

        let assertInvalid expectedMessage result =
                case result of
                    Left err -> do
                        errHTTPCode err `shouldBe` 400
                        BL8.unpack (errBody err) `shouldContain` expectedMessage
                    Right value ->
                        expectationFailure
                            ( "Expected social event list filter to be rejected, got: "
                                <> show value
                            )

        assertInvalid
            "city must be 120 characters or fewer"
            (validateSocialEventsListFilter "city" (Just (T.replicate 121 "x")))
        assertInvalid
            "q must not contain control characters or hidden formatting characters"
            (validateSocialEventsListFilter "q" (Just ("Quito" <> T.singleton '\n')))
        assertInvalid
            "name must not contain control characters or hidden formatting characters"
            (validateSocialEventsListFilter "name" (Just ("DJ" <> T.singleton (chr 0x202E))))

    it "uses canonical visibility for imported events across read and mutation routes" $ do
        cfg <- Config.loadConfig
        pool <- runNoLoggingT $ createSqlitePool ":memory:" 1
        runSqlPool initializeSocialSchema pool
        now <- getCurrentTime
        let hiddenEventKey :: SocialEventId
            hiddenEventKey = toSqlKey 13
            publicEventKey :: SocialEventId
            publicEventKey = toSqlKey 14
            malformedEventKey :: SocialEventId
            malformedEventKey = toSqlKey 15
            unsupportedMetadataEventKey :: SocialEventId
            unsupportedMetadataEventKey = toSqlKey 16
            decimalBudgetEventKey :: SocialEventId
            decimalBudgetEventKey = toSqlKey 17
            exponentBudgetEventKey :: SocialEventId
            exponentBudgetEventKey = toSqlKey 18
            fractionalBudgetEventKey :: SocialEventId
            fractionalBudgetEventKey = toSqlKey 19
            roundedFractionalBudgetEventKey :: SocialEventId
            roundedFractionalBudgetEventKey = toSqlKey 20
            maximumBudgetEventKey :: SocialEventId
            maximumBudgetEventKey = toSqlKey 21
            minimumBudgetEventKey :: SocialEventId
            minimumBudgetEventKey = toSqlKey 22
            duplicateVisibilityEventKey :: SocialEventId
            duplicateVisibilityEventKey = toSqlKey 23
            hiddenTierKey :: EventTicketTierId
            hiddenTierKey = toSqlKey 21
            publicTierKey :: EventTicketTierId
            publicTierKey = toSqlKey 22
            hiddenOrderKey :: EventTicketOrderId
            hiddenOrderKey = toSqlKey 51
            foreignOrderKey :: EventTicketOrderId
            foreignOrderKey = toSqlKey 52
            pendingHiddenOrderKey :: EventTicketOrderId
            pendingHiddenOrderKey = toSqlKey 53
            hiddenTicketKey :: EventTicketId
            hiddenTicketKey = toSqlKey 31
            hiddenTransferKey :: TicketTransferId
            hiddenTransferKey = toSqlKey 41
            sourceRef provider externalId eventKey sourceStatus sourceUrl =
                ExternalEventRef
                    { externalEventRefProvider = provider
                    , externalEventRefExternalId = externalId
                    , externalEventRefEventId = eventKey
                    , externalEventRefCity = "Quito"
                    , externalEventRefCountryCode = Just "EC"
                    , externalEventRefSourceUrl = Just sourceUrl
                    , externalEventRefPriceCents = Nothing
                    , externalEventRefCurrency = Just "USD"
                    , externalEventRefLastSeenAt = now
                    , externalEventRefMissingRuns = if sourceStatus == "missing" then 2 else 0
                    , externalEventRefSourceStatus = sourceStatus
                    }
            ticketTier eventKey code name =
                EventTicketTier
                    { eventTicketTierEventId = eventKey
                    , eventTicketTierCode = code
                    , eventTicketTierName = name
                    , eventTicketTierDescription = Nothing
                    , eventTicketTierPriceCents = 1000
                    , eventTicketTierCurrency = "USD"
                    , eventTicketTierCurrencyId = Nothing
                    , eventTicketTierQuantityTotal = 10
                    , eventTicketTierQuantitySold = 0
                    , eventTicketTierSalesStart = Nothing
                    , eventTicketTierSalesEnd = Nothing
                    , eventTicketTierIsActive = True
                    , eventTicketTierPosition = Nothing
                    , eventTicketTierEnableWaitlist = False
                    , eventTicketTierAllowTransfers = True
                    , eventTicketTierRefundPolicy = "full"
                    , eventTicketTierRefundDeadline = Nothing
                    , eventTicketTierCreatedAt = now
                    , eventTicketTierUpdatedAt = now
                    }
            ticketOrder eventKey tierKey buyerId buyerName buyerEmail status =
                EventTicketOrder
                    { eventTicketOrderEventId = eventKey
                    , eventTicketOrderTierId = tierKey
                    , eventTicketOrderBuyerPartyId = Just buyerId
                    , eventTicketOrderBuyerName = Just buyerName
                    , eventTicketOrderBuyerEmail = Just buyerEmail
                    , eventTicketOrderQuantity = 1
                    , eventTicketOrderAmountCents = 1000
                    , eventTicketOrderCurrency = "USD"
                    , eventTicketOrderStatus = status
                    , eventTicketOrderMetadata = Nothing
                    , eventTicketOrderCheckoutIdempotencyKey = Nothing
                    , eventTicketOrderPurchasedAt = now
                    , eventTicketOrderStripePaymentIntentId = Nothing
                    , eventTicketOrderPromoCodeId = Nothing
                    , eventTicketOrderOriginalAmountCents = Nothing
                    , eventTicketOrderPaymentMethod = Just "stripe"
                    , eventTicketOrderCreatedAt = now
                    , eventTicketOrderUpdatedAt = now
                    }
        runSqlPool
            ( do
                insertKey
                    hiddenEventKey
                    ( (seedSocialEvent "system:event-discovery" "Reconciled private pilot event" now)
                        { socialEventMetadata = Just "{\"isPublic\":false,\"currency\":\"USD\"}"
                        , socialEventWorkflowStateId = Just socialEventWorkflowStateFixtureId
                        }
                    )
                insertKey
                    publicEventKey
                    ( (seedSocialEvent "system:event-discovery" "Public canonical event" now)
                        { socialEventMetadata = Just "{\"isPublic\":true,\"currency\":\"USD\"}"
                        , socialEventWorkflowStateId = Just socialEventWorkflowStateFixtureId
                        }
                    )
                insertKey
                    malformedEventKey
                    ( (seedSocialEvent "system:event-discovery" "Malformed imported event" now)
                        { socialEventMetadata = Just "not-json"
                        , socialEventWorkflowStateId = Just socialEventWorkflowStateFixtureId
                        }
                    )
                insertKey
                    unsupportedMetadataEventKey
                    ( (seedSocialEvent "system:event-discovery" "Unsupported imported metadata" now)
                        { socialEventMetadata = Just "{\"isPublic\":true,\"unexpected\":1}"
                        , socialEventWorkflowStateId = Just socialEventWorkflowStateFixtureId
                        }
                    )
                insertKey
                    decimalBudgetEventKey
                    ( (seedSocialEvent "system:event-discovery" "Decimal integral budget" now)
                        { socialEventMetadata = Just "{\"isPublic\":true,\"budgetCents\":1.0}"
                        , socialEventWorkflowStateId = Just socialEventWorkflowStateFixtureId
                        }
                    )
                insertKey
                    exponentBudgetEventKey
                    ( (seedSocialEvent "system:event-discovery" "Exponent integral budget" now)
                        { socialEventMetadata = Just "{\"isPublic\":true,\"budgetCents\":1e0}"
                        , socialEventWorkflowStateId = Just socialEventWorkflowStateFixtureId
                        }
                    )
                insertKey
                    fractionalBudgetEventKey
                    ( (seedSocialEvent "system:event-discovery" "Fractional budget" now)
                        { socialEventMetadata = Just "{\"isPublic\":true,\"budgetCents\":1.5}"
                        , socialEventWorkflowStateId = Just socialEventWorkflowStateFixtureId
                        }
                    )
                insertKey
                    roundedFractionalBudgetEventKey
                    ( (seedSocialEvent "system:event-discovery" "Rounded fractional budget" now)
                        { socialEventMetadata = Just "{\"isPublic\":true,\"budgetCents\":9007199254740992.5}"
                        , socialEventWorkflowStateId = Just socialEventWorkflowStateFixtureId
                        }
                    )
                insertKey
                    maximumBudgetEventKey
                    ( (seedSocialEvent "system:event-discovery" "Maximum integral budget" now)
                        { socialEventMetadata = Just "{\"isPublic\":true,\"currency\":\"USD\",\"budgetCents\":9223372036854775807.0}"
                        , socialEventWorkflowStateId = Just socialEventWorkflowStateFixtureId
                        }
                    )
                insertKey
                    minimumBudgetEventKey
                    ( (seedSocialEvent "system:event-discovery" "Minimum integral budget" now)
                        { socialEventMetadata = Just "{\"isPublic\":true,\"currency\":\"USD\",\"budgetCents\":-9223372036854775808.0}"
                        , socialEventWorkflowStateId = Just socialEventWorkflowStateFixtureId
                        }
                    )
                insertKey
                    duplicateVisibilityEventKey
                    ( (seedSocialEvent "system:event-discovery" "Duplicate visibility metadata" now)
                        { socialEventMetadata = Just "{\"isPublic\":true,\"\\u0069sPublic\":false}"
                        , socialEventWorkflowStateId = Just socialEventWorkflowStateFixtureId
                        }
                    )
                _ <- insert (sourceRef "ticketmaster" "pilot-private-13" hiddenEventKey "missing" "https://tickets.example.com/private-pilot")
                _ <- insert (sourceRef "ticketmaster" "public-14" publicEventKey "on_sale" "https://tickets.example.com/public")
                _ <- insert (sourceRef "buenplan" "draft-merge-14" publicEventKey "draft:on_sale" "https://tickets.example.com/draft-option")
                _ <- insert (sourceRef "ticketmaster" "malformed-15" malformedEventKey "on_sale" "https://tickets.example.com/malformed")
                _ <- insert (sourceRef "ticketmaster" "unsupported-16" unsupportedMetadataEventKey "on_sale" "https://tickets.example.com/unsupported")
                _ <- insert (sourceRef "ticketmaster" "decimal-budget-17" decimalBudgetEventKey "on_sale" "https://tickets.example.com/decimal-budget")
                _ <- insert (sourceRef "ticketmaster" "exponent-budget-18" exponentBudgetEventKey "on_sale" "https://tickets.example.com/exponent-budget")
                _ <- insert (sourceRef "ticketmaster" "fractional-budget-19" fractionalBudgetEventKey "on_sale" "https://tickets.example.com/fractional-budget")
                _ <- insert (sourceRef "ticketmaster" "rounded-fractional-budget-20" roundedFractionalBudgetEventKey "on_sale" "https://tickets.example.com/rounded-fractional-budget")
                _ <- insert (sourceRef "ticketmaster" "maximum-budget-21" maximumBudgetEventKey "on_sale" "https://tickets.example.com/maximum-budget")
                _ <- insert (sourceRef "ticketmaster" "minimum-budget-22" minimumBudgetEventKey "on_sale" "https://tickets.example.com/minimum-budget")
                _ <- insert (sourceRef "ticketmaster" "duplicate-visibility-23" duplicateVisibilityEventKey "on_sale" "https://tickets.example.com/duplicate-visibility")
                forM_
                    [ (24, "{\"isPublic\":true,\"_discoveryOwned\":{\"title\":\"Provider title\",\"isPublic\":true}}")
                    , (25, "{\"isPublic\":true,\"_discoveryOwned\":null}")
                    , (26, "{\"isPublic\":true,\"_discoveryOwned\":false}")
                    , (27, "{\"isPublic\":true,\"_discoveryOwned\":{},\"unexpected\":1}")
                    , (28, "{\"isPublic\":true,\"_discoveryOwned\":{},\"_discoveryOwned\":{}}")
                    ]
                    $ \(rawKey, metadata) -> do
                        let eventKey = toSqlKey rawKey
                        insertKey eventKey
                            ((seedSocialEvent "system:event-discovery" "Ownership boundary" now)
                                { socialEventMetadata = Just metadata
                                , socialEventWorkflowStateId = Just socialEventWorkflowStateFixtureId
                                })
                        _ <- insert (sourceRef "ticketmaster" ("ownership-" <> T.pack (show rawKey)) eventKey "on_sale" "https://tickets.example.com/ownership")
                        pure ()
                insertKey hiddenTierKey (ticketTier hiddenEventKey "hidden-tier" "Hidden tier")
                insertKey publicTierKey (ticketTier publicEventKey "public-tier" "Public tier")
                insertKey
                    hiddenOrderKey
                    (ticketOrder hiddenEventKey hiddenTierKey "2" "Refund buyer" "refund-buyer@example.com" "paid")
                insertKey
                    foreignOrderKey
                    (ticketOrder publicEventKey publicTierKey "3" "Other buyer" "other-buyer@example.com" "paid")
                insertKey
                    pendingHiddenOrderKey
                    (ticketOrder hiddenEventKey hiddenTierKey "3" "Other buyer" "other-buyer@example.com" "pending")
                insertKey
                    hiddenTicketKey
                    EventTicket
                        { eventTicketEventId = hiddenEventKey
                        , eventTicketTierRefId = hiddenTierKey
                        , eventTicketOrderRefId = hiddenOrderKey
                        , eventTicketHolderName = Just "Original holder"
                        , eventTicketHolderEmail = Just "holder@example.com"
                        , eventTicketCode = "hidden-ticket"
                        , eventTicketStatus = "active"
                        , eventTicketCheckedInAt = Nothing
                        , eventTicketCurrentHolderPartyId = Just "2"
                        , eventTicketCurrentHolderEmail = Just "holder@example.com"
                        , eventTicketCurrentHolderName = Just "Original holder"
                        , eventTicketOriginalHolderPartyId = Just "2"
                        , eventTicketTransferHistory = Nothing
                        , eventTicketCreatedAt = now
                        , eventTicketUpdatedAt = now
                        }
                insertKey
                    hiddenTransferKey
                    TicketTransfer
                        { ticketTransferTicketId = hiddenTicketKey
                        , ticketTransferFromPartyId = Just "2"
                        , ticketTransferToPartyId = Nothing
                        , ticketTransferToEmail = Just "recipient@example.com"
                        , ticketTransferToName = Just "Recipient"
                        , ticketTransferStatus = "pending"
                        , ticketTransferTransferCode = "hidden-transfer-code"
                        , ticketTransferMessage = Nothing
                        , ticketTransferExpiresAt = Nothing
                        , ticketTransferAcceptedAt = Nothing
                        , ticketTransferCreatedAt = now
                        , ticketTransferUpdatedAt = now
                        }
                pure ()
            )
            pool

        let env =
                Env
                    { envPool = pool
                    , envConfig = cfg
                    }
            ordinaryUser = socialEventUser 2
        listResult <-
            runHandler $
                runReaderT
                    ( socialEventListHandlerFor
                        ordinaryUser
                        Nothing
                        Nothing
                        Nothing
                        Nothing
                        Nothing
                        Nothing
                        Nothing
                        Nothing
                        Nothing
                    )
                    env
        case listResult of
            Right events -> do
                map eventId events
                    `shouldMatchList` [Just "14", Just "17", Just "18", Just "21", Just "22", Just "24"]
                case filter ((== Just "14") . eventId) events of
                    [publicEvent] ->
                        map eventSourceProvider (maybe [] id (eventSources publicEvent))
                            `shouldMatchList` ["ticketmaster", "buenplan"]
                    matchingEvents ->
                        expectationFailure
                            ( "Expected one public canonical event projection, got: "
                                <> show matchingEvents
                            )
            Left err ->
                expectationFailure
                    ("Expected canonical public event list to succeed, got: " <> show err)

        paginatedListResult <-
            runHandler $
                runReaderT
                    ( socialEventListHandlerFor
                        ordinaryUser
                        Nothing
                        Nothing
                        (Just "2025-01-01T00:00:00Z")
                        Nothing
                        Nothing
                        Nothing
                        Nothing
                        (Just 1)
                        (Just 0)
                    )
                    env
        case paginatedListResult of
            Right [event] ->
                eventId event `shouldSatisfy` (`elem` [Just "14", Just "17", Just "18", Just "21", Just "22", Just "24"])
            Right events ->
                expectationFailure
                    ("Expected filtered and paginated list to contain only the public canonical event, got: " <> show events)
            Left err ->
                expectationFailure
                    ("Expected filtered and paginated pilot list to succeed, got: " <> show err)

        getResult <-
            runHandler $
                runReaderT
                    (socialEventGetHandlerFor ordinaryUser "13")
                    env
        case getResult of
            Left err -> do
                errHTTPCode err `shouldBe` 404
                BL8.unpack (errBody err) `shouldContain` "Event not found"
            Right event ->
                expectationFailure
                    ("Expected direct pilot draft access to be hidden, got: " <> show event)

        publicGetResult <-
            runHandler $
                runReaderT
                    (socialEventGetHandlerFor ordinaryUser "14")
                    env
        case publicGetResult of
            Right event -> eventId event `shouldBe` Just "14"
            Left err ->
                expectationFailure
                    ("Expected the canonical event with an active public source to remain visible, got: " <> show err)

        ownershipGetResult <- runHandler $ runReaderT (socialEventGetHandlerFor ordinaryUser "24") env
        case ownershipGetResult of
            Right event -> do
                eventId event `shouldBe` Just "24"
                BL8.unpack (Aeson.encode event) `shouldNotContain` "_discoveryOwned"
            Left err -> expectationFailure ("Expected private ownership evidence to permit a public projection: " <> show err)
        forM_ ["25", "26", "27", "28"] $ \rawKey -> do
            result <- runHandler $ runReaderT (socialEventGetHandlerFor ordinaryUser rawKey) env
            assertHiddenEventRoute "invalid internal ownership metadata" result

        malformedGetResult <-
            runHandler $
                runReaderT
                    (socialEventGetHandlerFor ordinaryUser "15")
                    env
        assertHiddenEventRoute "malformed imported event" malformedGetResult

        unsupportedMetadataGetResult <-
            runHandler $
                runReaderT
                    (socialEventGetHandlerFor ordinaryUser "16")
                    env
        assertHiddenEventRoute "unsupported imported metadata" unsupportedMetadataGetResult

        mapM_
            ( \eventIdText -> do
                integralBudgetGetResult <-
                    runHandler $
                        runReaderT
                            (socialEventGetHandlerFor ordinaryUser eventIdText)
                            env
                case integralBudgetGetResult of
                    Right event -> eventId event `shouldBe` Just eventIdText
                    Left err ->
                        expectationFailure
                            ( "Expected integral JSON budget event "
                                <> T.unpack eventIdText
                                <> " to remain visible, got: "
                                <> show err
                            )
            )
            ["17", "18", "21", "22"]

        fractionalBudgetGetResult <-
            runHandler $
                runReaderT
                    (socialEventGetHandlerFor ordinaryUser "19")
                    env
        assertHiddenEventRoute "fractional imported budget metadata" fractionalBudgetGetResult

        roundedFractionalBudgetGetResult <-
            runHandler $
                runReaderT
                    (socialEventGetHandlerFor ordinaryUser "20")
                    env
        assertHiddenEventRoute "large fractional imported budget metadata" roundedFractionalBudgetGetResult

        duplicateVisibilityGetResult <-
            runHandler $
                runReaderT
                    (socialEventGetHandlerFor ordinaryUser "23")
                    env
        assertHiddenEventRoute "duplicate imported visibility metadata" duplicateVisibilityGetResult

        let ( stripeHandler
                , createRefundHandler
                , listRefundsHandler
                , rejectRefundHandler
                , acceptTransferHandler
                , cancelTransferHandler
                ) =
                socialEventIndirectTicketHandlersFor ordinaryUser
        refundResult <-
            runHandler $
                runReaderT
                    (createRefundHandler "13" "51" (RefundRequestDTO (Just "Provider cancellation") Nothing))
                    env
        createdRefundId <- case refundResult of
            Right refund -> do
                refundOrderId refund `shouldBe` "51"
                refundStatus refund `shouldBe` "pending"
                maybe
                    (expectationFailure "Expected created refund ID" >> pure "")
                    pure
                    (refundId refund)
            Left err ->
                expectationFailure
                    ("Expected the hidden-event buyer to retain refund access, got: " <> show err)
                    >> pure ""

        refundListResult <-
            runHandler $
                runReaderT
                    (listRefundsHandler "13")
                    env
        case refundListResult of
            Right [refund] -> refundOrderId refund `shouldBe` "51"
            Right refunds ->
                expectationFailure
                    ("Expected the buyer's hidden-event refund, got: " <> show refunds)
            Left err ->
                expectationFailure
                    ("Expected the hidden-event buyer to list refunds, got: " <> show err)

        let (_, otherBuyerCreateRefund, otherBuyerListRefunds, _, _, _) =
                socialEventIndirectTicketHandlersFor (socialEventUser 3)
        unauthorizedRefundResult <-
            runHandler $
                runReaderT
                    (otherBuyerCreateRefund "13" "51" (RefundRequestDTO Nothing Nothing))
                    env
        assertHiddenEventRoute "another buyer's refund" unauthorizedRefundResult
        missingOrderRefundResult <-
            runHandler $
                runReaderT
                    (otherBuyerCreateRefund "13" "999" (RefundRequestDTO Nothing Nothing))
                    env
        assertHiddenEventRoute "missing hidden-event order" missingOrderRefundResult
        foreignOrderRefundResult <-
            runHandler $
                runReaderT
                    (otherBuyerCreateRefund "13" "52" (RefundRequestDTO Nothing Nothing))
                    env
        assertHiddenEventRoute "another event's order" foreignOrderRefundResult
        pendingOrderRefundResult <-
            runHandler $
                runReaderT
                    (otherBuyerCreateRefund "13" "53" (RefundRequestDTO Nothing Nothing))
                    env
        assertHiddenEventRoute "pending hidden-event order" pendingOrderRefundResult
        unauthorizedRefundListResult <-
            runHandler $
                runReaderT
                    (otherBuyerListRefunds "13")
                    env
        assertHiddenEventRoute "another buyer's refund list" unauthorizedRefundListResult

        rsvpResult <-
            runHandler $
                runReaderT
                    (socialEventRsvpCreateHandlerFor ordinaryUser "13" (RsvpCreateDTO "accepted" True))
                    env
        assertHiddenEventRoute "RSVP" rsvpResult

        invitationResult <-
            runHandler $
                runReaderT
                    (socialEventInvitationCreateHandlerFor ordinaryUser "13" (invitationCreatePayload Nothing))
                    env
        assertHiddenEventRoute "invitation" invitationResult

        momentResult <-
            runHandler $
                runReaderT
                    ( socialEventMomentCreateHandlerFor
                        ordinaryUser
                        "13"
                        (EventMomentCreateDTO Nothing Nothing "https://cdn.example.com/moment.jpg" "image" (Just 800) (Just 600) Nothing)
                    )
                    env
        -- This SQLite actor has no live-session witness. Session rejection must
        -- precede source visibility; authenticated private/suppressed-parent
        -- publication is asserted through the real HTTP/PostgreSQL lane.
        case momentResult of
            Left err -> errHTTPCode err `shouldBe` 401
            Right response -> expectationFailure ("A synthetic actor must not publish a moment: " <> show response)

        stripeResult <-
            runHandler $
                runReaderT
                    ( stripeHandler
                        ( TicketPurchaseWithPromoDTO
                            (TicketPurchaseRequestDTO "21" 1 Nothing Nothing Nothing)
                            Nothing
                            Nothing
                            Nothing
                            Nothing
                        )
                    )
                    env
        assertHiddenEventRoute "Stripe payment intent" stripeResult

        acceptTransferResult <-
            runHandler $
                runReaderT
                    (acceptTransferHandler "hidden-transfer-code")
                    env
        assertHiddenEventRoute "transfer acceptance" acceptTransferResult

        cancelTransferResult <-
            runHandler $
                runReaderT
                    (cancelTransferHandler "41")
                    env
        assertHiddenEventRoute "transfer cancellation" cancelTransferResult

        ownerRejectResult <-
            runHandler $
                runReaderT
                    ( rejectRefundHandler
                        "13"
                        createdRefundId
                        (RejectionReasonDTO "Buyer cannot moderate refunds")
                    )
                    env
        assertHiddenEventRoute "buyer refund rejection" ownerRejectResult

        let (_, _, adminListRefundsHandler, adminRejectRefundHandler, _, _) =
                socialEventIndirectTicketHandlersFor (strictAdminSocialEventUser 1)
        adminListResult <-
            runHandler $
                runReaderT (adminListRefundsHandler "13") env
        case adminListResult of
            Right [refund] -> refundId refund `shouldBe` Just createdRefundId
            Right refunds ->
                expectationFailure
                    ("Expected strict admin to list hidden-event refund, got: " <> show refunds)
            Left err ->
                expectationFailure
                    ("Expected strict admin to list hidden-event refund, got: " <> show err)
        adminRejectResult <-
            runHandler $
                runReaderT
                    ( adminRejectRefundHandler
                        "13"
                        createdRefundId
                        (RejectionReasonDTO "Imported provider cancellation")
                    )
                    env
        case adminRejectResult of
            Right refund -> do
                refundStatus refund `shouldBe` "rejected"
                refundRejectionReason refund `shouldBe` Just "Imported provider cancellation"
            Left err ->
                expectationFailure
                    ("Expected strict admin to process hidden-event refund, got: " <> show err)
        (transferAfter, ticketAfter) <-
            runSqlPool
                ((,) <$> get hiddenTransferKey <*> get hiddenTicketKey)
                pool
        fmap ticketTransferStatus transferAfter `shouldBe` Just "pending"
        fmap eventTicketCurrentHolderPartyId ticketAfter `shouldBe` Just (Just "2")

    it "rejects punctuation-only ticket buyer names before creating ticket orders" $ do
        validateTicketPurchaseBuyerName Nothing `shouldBe` Right Nothing
        validateTicketPurchaseBuyerName (Just "  Diego Saa  ")
            `shouldBe` Right (Just "Diego Saa")

        case validateTicketPurchaseBuyerName (Just "  ***  ") of
            Left err -> do
                errHTTPCode err `shouldBe` 400
                BL8.unpack (errBody err)
                    `shouldContain` "ticketPurchaseBuyerName must include letters or numbers"
            Right value ->
                expectationFailure
                    ("Expected punctuation-only buyer name to be rejected, got: " <> show value)

    it "rejects ambiguous ticket buyer email final domains before creating ticket orders" $ do
        validateTicketPurchaseBuyerEmail (Just "  Fan+Ticket@Example.COM  ")
            `shouldBe` Right (Just "fan+ticket@example.com")

        let assertInvalid rawEmail =
                case validateTicketPurchaseBuyerEmail (Just rawEmail) of
                    Left err -> do
                        errHTTPCode err `shouldBe` 400
                        BL8.unpack (errBody err)
                            `shouldContain` "ticketPurchaseBuyerEmail must be a valid email address"
                    Right value ->
                        expectationFailure
                            ("Expected invalid buyer email to be rejected, got: " <> show value)

        assertInvalid "fan@example.123"
        assertInvalid "fan@example.c"

    it "rejects malformed stored event metadata before publishing event DTO fallbacks" $ do
        pool <- runNoLoggingT $ createSqlitePool ":memory:" 1
        runSqlPool initializeSocialSchema pool
        now <- getCurrentTime
        let eventKey :: SocialEventId
            eventKey = toSqlKey 11
        runSqlPool
            ( insertKey
                eventKey
                ( (seedSocialEvent "1" "Corrupt metadata event" now)
                    { socialEventMetadata = Just "not-json"
                    }
                )
            )
            pool

        let env =
                Env
                    { envPool = pool
                    , envConfig = error "envConfig should be unused by social event get tests"
                    }
        result <-
            runHandler $
                runReaderT
                    (socialEventGetHandlerFor (socialEventUser 1) "11")
                    env

        case result of
            Left err -> do
                errHTTPCode err `shouldBe` 500
                BL8.unpack (errBody err)
                    `shouldContain` "Stored event metadata is invalid JSON"
            Right value ->
                expectationFailure
                    ("Expected malformed stored event metadata to be rejected, got: " <> show value)

    it "rejects malformed stored artist social links before publishing artist DTO fallbacks" $ do
        pool <- runNoLoggingT $ createSqlitePool ":memory:" 1
        runSqlPool initializeSocialSchema pool
        now <- getCurrentTime
        let artistKey :: ArtistProfileId
            artistKey = toSqlKey 15
        runSqlPool
            ( insertKey
                artistKey
                ArtistProfile
                    { artistProfilePartyId = Nothing
                    , artistProfileName = "Corrupt Links"
                    , artistProfileBio = Nothing
                    , artistProfileAvatarUrl = Nothing
                    , artistProfileGenres = Nothing
                    , artistProfileSocialLinks = Just "{\"bandcamp\":\"https://artist.example\"}"
                    , artistProfileCountryCode = Nothing
                    , artistProfileCountryId = Nothing
                    , artistProfileCreatedAt = now
                    , artistProfileUpdatedAt = now
                    }
            )
            pool

        let env =
                Env
                    { envPool = pool
                    , envConfig = error "envConfig should be unused by artist get tests"
                    }
        result <-
            runHandler $
                runReaderT
                    (artistGetHandlerFor (socialEventUser 1) "15")
                    env

        case result of
            Left err -> do
                errHTTPCode err `shouldBe` 500
                BL8.unpack (errBody err)
                    `shouldContain` "Stored artist social links are invalid"
            Right value ->
                expectationFailure
                    ("Expected malformed stored artist social links to be rejected, got: " <> show value)

    it "rejects unknown follower party ids before the handler can create orphan follows or RSVPs" $ do
        pool <- runStdoutLoggingT $ createSqlitePool ":memory:" 1
        runSqlPool initializeSocialSchema pool

        unknownResult <- resolveExistingPartyIdText pool "followerPartyId" "42"
        case unknownResult of
            Left err -> do
                errHTTPCode err `shouldBe` 422
                BL8.unpack (errBody err) `shouldContain` "followerPartyId references an unknown party"
            Right value ->
                expectationFailure ("Expected missing follower party to be rejected, got: " <> show value)

        now <- liftIO getCurrentTime
        existingPartyId <-
            runSqlPool
                ( insert
                    Party
                        { partyLegalName = Nothing
                        , partyDisplayName = "Follower"
                        , partyIsOrg = False
                        , partyTaxId = Nothing
                        , partyPrimaryEmail = Just "follower@example.com"
                        , partyPrimaryPhone = Nothing
                        , partyWhatsapp = Nothing
                        , partyInstagram = Nothing
                        , partyEmergencyContact = Nothing
                        , partyNotes = Nothing
                        , partyStripeCustomerId = Nothing
                        , partyCountryCode = Nothing
                        , partyCountryId = Nothing
                        , partyCreatedAt = now
                        }
                )
                pool

        let existingPartyText = T.pack (show (fromSqlKey existingPartyId))
        resolveExistingPartyIdText pool "followerPartyId" (" 00" <> existingPartyText <> " ")
            `shouldReturn` Right existingPartyText

    it "requires the event organizer before updating event details" $ do
        pool <- runNoLoggingT $ createSqlitePool ":memory:" 1
        runSqlPool initializeSocialSchema pool
        now <- getCurrentTime
        let eventKey :: SocialEventId
            eventKey = toSqlKey 7
        runSqlPool
            ( insertKey
                eventKey
                (seedSocialEvent "1" "Original event" now)
            )
            pool

        let env =
                Env
                    { envPool = pool
                    , envConfig = error "envConfig should be unused by social event update auth tests"
                    }
        result <-
            runHandler $
                runReaderT
                    ( socialEventUpdateHandlerFor
                        (socialEventUser 2)
                        "7"
                        (socialEventUpdatePayload "Hijacked event")
                    )
                    env

        case result of
            Left err -> do
                errHTTPCode err `shouldBe` 403
                BL8.unpack (errBody err)
                    `shouldContain` "Only the event organizer can manage this event"
            Right updated ->
                expectationFailure
                    ("Expected non-organizer event update to fail, got: " <> show updated)

        stored <- runSqlPool (get eventKey) pool
        fmap socialEventTitle stored `shouldBe` Just "Original event"

    it "does not hand an event without an organizer to the first user who edits it" $ do
        pool <- runNoLoggingT $ createSqlitePool ":memory:" 1
        runSqlPool initializeSocialSchema pool
        now <- getCurrentTime
        let eventKey :: SocialEventId
            eventKey = toSqlKey 7
            env =
                Env
                    { envPool = pool
                    , envConfig = error "envConfig should be unused by social event update auth tests"
                    }
        runSqlPool
            ( insertKey
                eventKey
                (seedSocialEvent "1" "Unowned event" now){socialEventOrganizerPartyId = Nothing}
            )
            pool
        result <-
            runHandler $
                runReaderT
                    (socialEventUpdateHandlerFor (socialEventUser 2) "7" (socialEventUpdatePayload "Hijacked event"))
                    env
        case result of
            Left err -> do
                errHTTPCode err `shouldBe` 403
                BL8.unpack (errBody err) `shouldContain` "This event has no organizer"
            Right updated ->
                expectationFailure ("Expected the unowned event update to fail, got: " <> show updated)
        stored <- runSqlPool (get eventKey) pool
        fmap socialEventOrganizerPartyId stored `shouldBe` Just Nothing
        fmap socialEventTitle stored `shouldBe` Just "Unowned event"

        -- A strict administrator passes the gate, but an edit that is then
        -- refused assigns nobody.
        refusedEdit <-
            runHandler $
                runReaderT
                    (socialEventUpdateHandlerFor (strictAdminSocialEventUser 3) "7" (socialEventUpdatePayload "Admin edit"))
                    env
        either errHTTPCode (const 200) refusedEdit `shouldBe` 422
        afterRefusal <- runSqlPool (get eventKey) pool
        fmap socialEventOrganizerPartyId afterRefusal `shouldBe` Just Nothing

        -- The assignment itself happens once; a later party is refused by
        -- the stored organizer.
        assigned <- runSqlPool (assignMissingEventOrganizer "3" now eventKey) pool
        fmap socialEventOrganizerPartyId assigned `shouldSatisfy` either (const False) (== Just "3")
        late <- runSqlPool (assignMissingEventOrganizer "4" now eventKey) pool
        either errHTTPCode (const 200) late `shouldBe` 403
        afterwards <- runSqlPool (get eventKey) pool
        fmap socialEventOrganizerPartyId afterwards `shouldBe` Just (Just "3")

    it "allows strict admins, but not unrelated users, to delete another organizer's event" $ do
        now <- getCurrentTime
        let event = seedSocialEvent "1" "Admin-managed event" now
        case validateEventDeleteAccess (socialEventUser 2) "2" event of
            Left err -> do
                errHTTPCode err `shouldBe` 403
                BL8.unpack (errBody err)
                    `shouldContain` "Only the event organizer or an administrator"
            Right _ -> expectationFailure "Expected unrelated event deletion access to fail"
        case validateEventDeleteAccess (socialEventUser 1) "1" event of
            Left err -> expectationFailure ("Expected organizer deletion access, got: " <> show err)
            Right () -> pure ()
        case validateEventDeleteAccess (strictAdminSocialEventUser 3) "3" event of
            Left err -> expectationFailure ("Expected strict admin deletion access, got: " <> show err)
            Right () -> pure ()

    it "preserves ticket checkout history instead of hard-deleting its event" $ do
        validateEventDeletionCheckoutHistory False `shouldBe` Right ()
        case validateEventDeletionCheckoutHistory True of
            Left err -> do
                errHTTPCode err `shouldBe` 409
                BL8.unpack (errBody err) `shouldContain` "preserve checkout history"
            Right () -> expectationFailure "Expected ticket-order history to block event deletion"

    it "removes only the deleted event's uploaded media directory" $
        withSystemTempDirectory "social-event-delete-assets" $ \assetsRoot -> do
            let deletedEventKey :: SocialEventId
                deletedEventKey = toSqlKey 24
                deletedEventDir = assetsRoot </> "social-events" </> "events" </> "24"
                retainedPoster = assetsRoot </> "social-events" </> "events" </> "25" </> "poster.png"
            createDirectoryIfMissing True (deletedEventDir </> "moments")
            createDirectoryIfMissing True (assetsRoot </> "social-events" </> "events" </> "25")
            writeFile (deletedEventDir </> "poster.png") "poster"
            writeFile (deletedEventDir </> "moments" </> "moment.png") "moment"
            writeFile retainedPoster "retained"

            removeSocialEventAssets assetsRoot deletedEventKey

            doesDirectoryExist deletedEventDir `shouldReturn` False
            doesFileExist retainedPoster `shouldReturn` True
            removeSocialEventAssets assetsRoot deletedEventKey
            doesFileExist retainedPoster `shouldReturn` True

    it "makes committed event deletion retryable for orphaned media cleanup" $
        withSystemTempDirectory "social-event-delete-retry" $ \assetsRoot -> do
            cfg <- Config.loadConfig
            pool <- runNoLoggingT $ createSqlitePool ":memory:" 1
            runSqlPool initializeSocialSchema pool
            let orphanedEventDir = assetsRoot </> "social-events" </> "events" </> "28"
                env =
                    Env
                        { envPool = pool
                        , envConfig = cfg{Config.assetsRootDir = assetsRoot}
                        }
            createDirectoryIfMissing True orphanedEventDir
            writeFile (orphanedEventDir </> "poster.png") "orphaned"

            result <-
                runHandler $
                    runReaderT
                        (socialEventDeleteHandlerFor (strictAdminSocialEventUser 3) "28")
                        env

            case result of
                Right _ -> pure ()
                Left err ->
                    expectationFailure
                        ("Expected retry cleanup for a committed deletion, got: " <> show err)
            doesDirectoryExist orphanedEventDir `shouldReturn` False

    it "excludes suppressed imports inside strict-admin pagination" $ do
        cfg <- Config.loadConfig
        pool <- runNoLoggingT $ createSqlitePool ":memory:" 1
        runSqlPool initializeSocialSchema pool
        now <- getCurrentTime
        let suppressedEventKey :: SocialEventId
            suppressedEventKey = toSqlKey 26
            visibleEventKey :: SocialEventId
            visibleEventKey = toSqlKey 27
            eventRow owner title =
                (seedSocialEvent owner title now)
                    { socialEventWorkflowStateId = Just socialEventWorkflowStateFixtureId
                    }
        runSqlPool
            ( do
                insertKey suppressedEventKey (eventRow "system:event-discovery" "Suppressed import")
                insertKey visibleEventKey (eventRow "1" "Visible managed event")
                insert
                    ExternalEventRef
                        { externalEventRefProvider = "ticketmaster"
                        , externalEventRefExternalId = "tm-suppressed-admin-list"
                        , externalEventRefEventId = suppressedEventKey
                        , externalEventRefCity = "Quito"
                        , externalEventRefCountryCode = Just "EC"
                        , externalEventRefSourceUrl = Just "https://tickets.example/suppressed"
                        , externalEventRefPriceCents = Just 1000
                        , externalEventRefCurrency = Just "USD"
                        , externalEventRefLastSeenAt = now
                        , externalEventRefMissingRuns = 0
                        , externalEventRefSourceStatus = "  SuPpReSsEd  "
                        }
            )
            pool
        let env = Env{envPool = pool, envConfig = cfg}
        result <-
            runHandler $
                runReaderT
                    ( socialEventListHandlerFor
                        (strictAdminSocialEventUser 1)
                        Nothing
                        Nothing
                        Nothing
                        Nothing
                        Nothing
                        Nothing
                        Nothing
                        (Just 1)
                        (Just 0)
                    )
                    env

        case result of
            Right events -> map eventId events `shouldBe` [Just "27"]
            Left err ->
                expectationFailure
                    ("Expected strict-admin event list to succeed, got: " <> show err)

    it "reports RSVP eligibility in the event list exactly as the event detail does" $ do
        cfg <- Config.loadConfig
        pool <- runNoLoggingT $ createSqlitePool ":memory:" 1
        runSqlPool initializeSocialSchema pool
        now <- getCurrentTime
        let eventKey :: SocialEventId
            eventKey = toSqlKey 28
            user = strictAdminSocialEventUser 1
            env = Env{envPool = pool, envConfig = cfg}
        runSqlPool
            ( do
                rawExecute
                    "INSERT INTO workflow_state_capability(state_id,capability_code,enabled) VALUES (?, 'public-listable', 1), (?, 'rsvp', 1)"
                    [toPersistValue socialEventWorkflowStateFixtureId, toPersistValue socialEventWorkflowStateFixtureId]
                insertKey eventKey
                    ((seedSocialEvent "1" "Listed RSVP event" now)
                        { socialEventMetadata = Just "{\"isPublic\":true}"
                        , socialEventWorkflowStateId = Just socialEventWorkflowStateFixtureId
                        })
            )
            pool
        listed <-
            runHandler $
                runReaderT
                    ( socialEventListHandlerFor
                        user
                        Nothing
                        Nothing
                        Nothing
                        Nothing
                        Nothing
                        Nothing
                        Nothing
                        Nothing
                        Nothing
                    )
                    env
        detail <- runHandler $ runReaderT (socialEventGetHandlerFor user "28") env
        case (listed, detail) of
            (Right [listedEvent], Right detailEvent) -> do
                eventRsvpEligible detailEvent `shouldBe` Just True
                eventRsvpEligible listedEvent `shouldBe` Just True
                eventPublicListable listedEvent `shouldBe` eventPublicListable detailEvent
            other ->
                expectationFailure
                    ("Expected one listed event and its detail, got: " <> show other)

    it "turns an imported event deletion into a private tombstone" $ do
        let suppressed =
                suppressImportedEventMetadata
                    (Just "{\"ticketUrl\":\"https://tickets.example/event\",\"imageUrl\":\"https://cdn.example/poster.png\",\"isPublic\":true,\"currency\":\"USD\",\"budgetCents\":null}")
        suppressed `shouldSatisfy` maybe False (T.isInfixOf "\"isPublic\":false")
        suppressed `shouldSatisfy` maybe False (T.isInfixOf "\"ticketUrl\":null")
        suppressed `shouldSatisfy` maybe False (T.isInfixOf "\"imageUrl\":null")

    it "tombstones imported events while respecting lifecycle transitions" $ do
        cfg <- Config.loadConfig
        temporaryRoot <- getTemporaryDirectory
        testRunId <- UUIDV4.nextRandom
        pool <- runNoLoggingT $ createSqlitePool ":memory:" 1
        runSqlPool initializeSocialSchema pool
        now <- getCurrentTime
        let eventKey :: SocialEventId
            eventKey = toSqlKey 24
            tierKey :: EventTicketTierId
            tierKey = toSqlKey 62
            importedEvent =
                (seedSocialEvent "1" "Imported event" now)
                    { socialEventMetadata =
                        Just
                            "{\"ticketUrl\":\"https://tickets.example/event\",\"imageUrl\":null,\"isPublic\":true,\"currency\":\"USD\",\"budgetCents\":null}"
                    , socialEventWorkflowStateId = Just socialEventWorkflowStateFixtureId
                    }
        refKey <-
            runSqlPool
                ( do
                    insertKey eventKey importedEvent
                    insert
                        ExternalEventRef
                            { externalEventRefProvider = "ticketmaster"
                            , externalEventRefExternalId = "tm-delete-1"
                            , externalEventRefEventId = eventKey
                            , externalEventRefCity = "Quito"
                            , externalEventRefCountryCode = Just "EC"
                            , externalEventRefSourceUrl = Just "https://tickets.example/event"
                            , externalEventRefPriceCents = Just 1000
                            , externalEventRefCurrency = Just "USD"
                            , externalEventRefLastSeenAt = now
                            , externalEventRefMissingRuns = 1
                            , externalEventRefSourceStatus = "on_sale"
                            }
                )
                pool

        let env =
                Env
                    { envPool = pool
                    , envConfig =
                        cfg
                            { Config.assetsRootDir =
                                temporaryRoot
                                    </> ("tdf-imported-event-delete-" <> UUID.toString testRunId)
                            }
                    }
        runSqlPool
            ( rawExecute
                "INSERT INTO event_ticket_tier (id,event_id,code,name,price_cents,currency,quantity_total,quantity_sold,is_active,enable_waitlist,allow_transfers,refund_policy,created_at,updated_at) VALUES (62,24,'general','General',1000,'USD',100,0,1,0,1,'full',?,?)"
                (replicate 2 (toPersistValue now))
            )
            pool
        runSqlPool
            ( rawExecute
                "INSERT INTO event_ticket_order (id,event_id,tier_id,quantity,amount_cents,currency,status,purchased_at,created_at,updated_at) VALUES (61,24,62,1,1000,'USD','paid',?,?,?)"
                (replicate 3 (toPersistValue now))
            )
            pool
        blockedResult <-
            runHandler $
                runReaderT
                    (socialEventDeleteHandlerFor (strictAdminSocialEventUser 3) "24")
                    env
        case blockedResult of
            Left err -> do
                errHTTPCode err `shouldBe` 409
                BL8.unpack (errBody err) `shouldContain` "preserve checkout history"
            Right _ -> expectationFailure "Expected ticket history to block imported event deletion"
        storedBlockedRef <- runSqlPool (get refKey) pool
        fmap externalEventRefSourceStatus storedBlockedRef `shouldBe` Just "on_sale"
        runSqlPool
            (rawExecute "DELETE FROM event_ticket_order WHERE event_id = 24" [])
            pool

        result <-
            runHandler $
                runReaderT
                    (socialEventDeleteHandlerFor (strictAdminSocialEventUser 3) "24")
                    env

        case result of
            Left err ->
                expectationFailure
                    ("Expected imported event deletion to succeed, got: " <> show err)
            Right _ -> pure ()
        storedEvent <- runSqlPool (get eventKey) pool
        storedRef <- runSqlPool (get refKey) pool
        storedTier <- runSqlPool (get tierKey) pool
        fmap socialEventMetadata storedEvent
            `shouldSatisfy` maybe False (maybe False (T.isInfixOf "\"isPublic\":false"))
        fmap socialEventWorkflowStateId storedEvent
            `shouldBe` Just (Just socialEventCancelledWorkflowStateFixtureId)
        fmap externalEventRefSourceStatus storedRef `shouldBe` Just externalEventRefSuppressedStatus
        fmap externalEventRefMissingRuns storedRef `shouldBe` Just 0
        fmap eventTicketTierIsActive storedTier `shouldBe` Just False

        let unavailableEventKey :: SocialEventId
            unavailableEventKey = toSqlKey 25
            unavailableEvent =
                (seedSocialEvent "1" "Unavailable imported event" now)
                    { socialEventMetadata =
                        Just
                            "{\"ticketUrl\":\"https://tickets.example/unavailable\",\"imageUrl\":null,\"isPublic\":true,\"currency\":\"USD\",\"budgetCents\":null}"
                    , socialEventWorkflowStateId = Just socialEventUnavailableWorkflowStateFixtureId
                    }
        unavailableRefKey <-
            runSqlPool
                ( do
                    insertKey unavailableEventKey unavailableEvent
                    insert
                        ExternalEventRef
                            { externalEventRefProvider = "ticketmaster"
                            , externalEventRefExternalId = "tm-delete-unavailable"
                            , externalEventRefEventId = unavailableEventKey
                            , externalEventRefCity = "Quito"
                            , externalEventRefCountryCode = Just "EC"
                            , externalEventRefSourceUrl = Just "https://tickets.example/unavailable"
                            , externalEventRefPriceCents = Just 1000
                            , externalEventRefCurrency = Just "USD"
                            , externalEventRefLastSeenAt = now
                            , externalEventRefMissingRuns = 1
                            , externalEventRefSourceStatus = "unavailable"
                            }
                )
                pool

        unavailableResult <-
            runHandler $
                runReaderT
                    (socialEventDeleteHandlerFor (strictAdminSocialEventUser 3) "25")
                    env

        case unavailableResult of
            Left err ->
                expectationFailure
                    ("Expected unavailable imported event deletion to succeed, got: " <> show err)
            Right _ -> pure ()
        storedUnavailableEvent <- runSqlPool (get unavailableEventKey) pool
        storedUnavailableRef <- runSqlPool (get unavailableRefKey) pool
        fmap socialEventMetadata storedUnavailableEvent
            `shouldSatisfy` maybe False (maybe False (T.isInfixOf "\"isPublic\":false"))
        fmap socialEventWorkflowStateId storedUnavailableEvent
            `shouldBe` Just (Just socialEventUnavailableWorkflowStateFixtureId)
        fmap externalEventRefSourceStatus storedUnavailableRef `shouldBe` Just externalEventRefSuppressedStatus
        fmap externalEventRefMissingRuns storedUnavailableRef `shouldBe` Just 0

    it "rejects spoofed invitation senders before inserting social event invitations" $ do
        pool <- runNoLoggingT $ createSqlitePool ":memory:" 1
        runSqlPool initializeSocialSchema pool
        now <- getCurrentTime
        let eventKey :: SocialEventId
            eventKey = toSqlKey 9
        runSqlPool
            ( insertKey
                eventKey
                (seedSocialEvent "5" "Invitation event" now)
            )
            pool

        let env =
                Env
                    { envPool = pool
                    , envConfig = error "envConfig should be unused by invitation auth tests"
                    }

        validateInvitationFromPartyId "5" Nothing `shouldBe` Right "5"
        validateInvitationFromPartyId "5" (Just " 005 ") `shouldBe` Right "5"

        spoofed <-
            runHandler $
                runReaderT
                    ( socialEventInvitationCreateHandlerFor
                        (socialEventUser 5)
                        "9"
                        (invitationCreatePayload (Just "999"))
                    )
                    env
        case spoofed of
            Left err -> do
                errHTTPCode err `shouldBe` 403
                BL8.unpack (errBody err)
                    `shouldContain` "invitationFromPartyId must match the authenticated party"
            Right value ->
                expectationFailure
                    ("Expected spoofed invitation sender to be rejected, got: " <> show value)

    it "rejects invitation creation by a non-organizer even when the event is visible" $ do
        pool <- runNoLoggingT $ createSqlitePool ":memory:" 1
        runSqlPool initializeSocialSchema pool
        now <- getCurrentTime
        let eventKey :: SocialEventId
            eventKey = toSqlKey 10
        runSqlPool
            (insertKey eventKey (seedSocialEvent "1" "Organizer-only invitations" now))
            pool
        let env =
                Env
                    { envPool = pool
                    , envConfig = error "envConfig should be unused by invitation auth tests"
                    }
        result <-
            runHandler $
                runReaderT
                    ( socialEventInvitationCreateHandlerFor
                        (socialEventUser 5)
                        "10"
                        (invitationCreatePayload Nothing)
                    )
                    env
        case result of
            Left err -> do
                errHTTPCode err `shouldBe` 403
                BL8.unpack (errBody err) `shouldContain` "event organizer"
            Right value ->
                expectationFailure
                    ("Expected non-organizer invitation creation to fail, got: " <> show value)

    invitationDatabaseUrl <- runIO (lookupEnv "TDF_INVITATION_TEST_DATABASE_URL")
    forM_ invitationDatabaseUrl $ \databaseUrl ->
        it "validates internal ownership in the actual PostgreSQL visibility predicate" $ do
            pool <- runNoLoggingT $ createPostgresqlPool (BS8.pack databaseUrl) 1
            forM_
                [ ("{\"isPublic\":true,\"_discoveryOwned\":{\"title\":\"Source\",\"isPublic\":true}}", True)
                , ("{\"isPublic\":true,\"_discoveryOwned\":{}}", True)
                , ("{\"isPublic\":false,\"_discoveryOwned\":{}}", False)
                , ("{\"isPublic\":true,\"_discoveryOwned\":null}", False)
                , ("{\"isPublic\":true,\"_discoveryOwned\":false}", False)
                , ("{\"isPublic\":true,\"_discoveryOwned\":[]}", False)
                , ("{\"isPublic\":true,\"_discoveryOwned\":{},\"unexpected\":1}", False)
                , ("{\"isPublic\":true,\"_discoveryOwned\":{},\"_discoveryOwned\":{}}", False)
                , ("{\"isPublic\":true,\"budgetCents\":1.5,\"_discoveryOwned\":{}}", False)
                , ("{\"isPublic\":true,\"budgetCents\":9223372036854775807.0,\"_discoveryOwned\":{}}", True)
                ]
                $ \(metadata, expected) -> do
                    rows <- runSqlPool
                        (rawSql ("SELECT " <> postgresVisibleImportedMetadataClause "metadata"
                            <> " FROM (VALUES (?::text)) AS candidate(metadata)")
                            [toPersistValue (metadata :: T.Text)] :: SqlPersistT IO [Single Bool]) pool
                    map unSingle rows `shouldBe` [expected]
    case invitationDatabaseUrl of
        Nothing -> pure ()
        Just databaseUrl -> it "serializes a stale invitation response behind an organizer transfer in PostgreSQL" $ do
            pool <- runNoLoggingT $ createPostgresqlPool (BS8.pack databaseUrl) 3
            now <- getCurrentTime
            let eventKey = toSqlKey 43 :: SocialEventId
                env = Env {envPool = pool, envConfig = error "invitation update needs no config"}
                dto = InvitationUpdateDTO
                    ((invitationCreatePayload Nothing) {invitationStatus = Just "accepted"}) FieldMissing
            key <- runSqlPool (do
                rawExecute "CREATE TABLE social_event (id BIGINT PRIMARY KEY, organizer_party_id TEXT, title TEXT NOT NULL, description TEXT, venue_id BIGINT, event_type_id UUID, workflow_state_id UUID, timezone TEXT, start_time TIMESTAMPTZ NOT NULL, end_time TIMESTAMPTZ, price_cents BIGINT, currency_id UUID, capacity BIGINT, metadata TEXT, created_at TIMESTAMPTZ NOT NULL, updated_at TIMESTAMPTZ NOT NULL)" []
                -- The ordinary-user visibility guard also consults imported-event references.
                rawExecute "CREATE TABLE external_event_ref (event_id BIGINT NOT NULL)" []
                rawExecute "CREATE TABLE event_invitation (id BIGSERIAL PRIMARY KEY, event_id BIGINT NOT NULL, from_party_id TEXT, to_party_id TEXT, status TEXT, message TEXT, created_at TIMESTAMPTZ NOT NULL, updated_at TIMESTAMPTZ NOT NULL)" []
                insertKey eventKey (seedSocialEvent "1" "Concurrent invitation transfer" now)
                insert (EventInvitation eventKey (Just "1") (Just "2") (Just "pending") (Just "Join us") now now)) pool
            locked <- newEmptyMVar
            release <- newEmptyMVar
            let transfer = runSqlPool (do
                    rawExecute "UPDATE event_invitation SET to_party_id = '3' WHERE id = ?" [toPersistValue key]
                    liftIO (putMVar locked ())
                    liftIO (takeMVar release)) pool
                respond = runHandler $ runReaderT
                    (socialEventInvitationUpdateHandlerFor (socialEventUser 2) "43"
                        (T.pack (show (fromSqlKey key))) dto) env
                awaitBlocked :: Int -> IO ()
                awaitBlocked 0 = expectationFailure "Recipient did not wait on the invitation row lock"
                awaitBlocked attempts = do
                    rows <- runSqlPool (rawSql "SELECT count(*) FROM pg_stat_activity WHERE datname = current_database() AND wait_event_type = 'Lock' AND query LIKE '%event_invitation%'" [] :: SqlPersistT IO [Single Int64]) pool
                    case rows of
                        [Single n] | n > 0 -> pure ()
                        _ -> threadDelay 10000 >> awaitBlocked (attempts - 1)
            withAsync transfer $ \organizer ->
                (do
                    takeMVar locked
                    withAsync respond $ \recipient -> do
                        awaitBlocked 500
                        putMVar release ()
                        wait organizer
                        result <- wait recipient
                        case result of
                            Left err -> errHTTPCode err `shouldBe` 403
                            Right value -> expectationFailure ("Stale recipient regained access: " <> show value)
                    stored <- runSqlPool (get key) pool
                    fmap eventInvitationToPartyId stored `shouldBe` Just (Just "3")
                    fmap eventInvitationStatus stored `shouldBe` Just (Just "pending"))
                `finally` void (tryPutMVar release ())
            -- The same event lock must cover creation authority through insert,
            -- for both transfer and removal of the organizer.
            forM_ [Just "3", Nothing] $ \nextOrganizer -> do
                runSqlPool (rawExecute "UPDATE social_event SET organizer_party_id = '1' WHERE id = 43" []) pool
                before <- runSqlPool (count [EventInvitationEventId ==. eventKey]) pool
                ownerLocked <- newEmptyMVar
                releaseOwner <- newEmptyMVar
                let changeOwner = runSqlPool (do
                        rawExecute "UPDATE social_event SET organizer_party_id = ? WHERE id = 43"
                            [toPersistValue (nextOrganizer :: Maybe T.Text)]
                        liftIO (putMVar ownerLocked ())
                        liftIO (takeMVar releaseOwner)) pool
                    create = runHandler $ runReaderT
                        (socialEventInvitationCreateHandlerFor (socialEventUser 1) "43"
                            (invitationCreatePayload Nothing)) env
                    awaitEventLock :: Int -> IO ()
                    awaitEventLock 0 = expectationFailure "Invitation creator did not wait on event authority lock"
                    awaitEventLock attempts = do
                        rows <- runSqlPool (rawSql "SELECT count(*) FROM pg_stat_activity WHERE datname = current_database() AND wait_event_type = 'Lock' AND query LIKE '%social_event%'" [] :: SqlPersistT IO [Single Int64]) pool
                        case rows of
                            [Single n] | n > 0 -> pure ()
                            _ -> threadDelay 10000 >> awaitEventLock (attempts - 1)
                withAsync changeOwner $ \owner ->
                    (do
                        takeMVar ownerLocked
                        withAsync create $ \creator -> do
                            awaitEventLock 500
                            putMVar releaseOwner ()
                            wait owner
                            result <- wait creator
                            case result of
                                Left err -> errHTTPCode err `shouldBe` 403
                                Right value -> expectationFailure ("Former organizer created invitation: " <> show value)
                        after <- runSqlPool (count [EventInvitationEventId ==. eventKey]) pool
                        after `shouldBe` before)
                    `finally` void (tryPutMVar releaseOwner ())
            runSqlPool (rawExecute "UPDATE social_event SET organizer_party_id = '1' WHERE id = 43" []) pool
            accepted <- runHandler $ runReaderT
                (socialEventInvitationCreateHandlerFor (socialEventUser 1) "43"
                    (invitationCreatePayload Nothing)) env
            fmap invitationStatus accepted `shouldBe` Right (Just "pending")

            -- A former organizer must wait for the event lock and then be
            -- denied using the committed authority, not its pre-lock snapshot.
            ownerLocked <- newEmptyMVar
            ownerRelease <- newEmptyMVar
            let transferOwner = runSqlPool (do
                    rawExecute "UPDATE social_event SET organizer_party_id = NULL WHERE id = ?"
                        [toPersistValue eventKey]
                    liftIO (putMVar ownerLocked ())
                    liftIO (takeMVar ownerRelease)) pool
                createStale = runHandler $ runReaderT
                    (socialEventInvitationCreateHandlerFor (socialEventUser 1) "43"
                        (invitationCreatePayload Nothing)) env
                awaitEventLock :: Int -> IO ()
                awaitEventLock 0 = expectationFailure "Invitation creation did not wait on the event lock"
                awaitEventLock attempts = do
                    rows <- runSqlPool (rawSql "SELECT count(*) FROM pg_stat_activity WHERE datname = current_database() AND wait_event_type = 'Lock' AND query LIKE '%social_event%'" [] :: SqlPersistT IO [Single Int64]) pool
                    case rows of
                        [Single n] | n > 0 -> pure ()
                        _ -> threadDelay 10000 >> awaitEventLock (attempts - 1)
            beforeCount <- runSqlPool (count [EventInvitationEventId ==. eventKey]) pool
            withAsync transferOwner $ \owner ->
                (do
                    takeMVar ownerLocked
                    withAsync createStale $ \creator -> do
                        awaitEventLock 500
                        putMVar ownerRelease ()
                        wait owner
                        result <- wait creator
                        case result of
                            Left err -> errHTTPCode err `shouldBe` 403
                            Right value -> expectationFailure ("Former organizer created an invitation: " <> show value)
                    afterCount <- runSqlPool (count [EventInvitationEventId ==. eventKey]) pool
                    afterCount `shouldBe` beforeCount)
                `finally` void (tryPutMVar ownerRelease ())

    it "revalidates invitation recipients and terminal status at the update boundary" $ do
        now <- getCurrentTime
        pool <- runNoLoggingT $ createSqlitePool ":memory:" 1
        runSqlPool initializeSocialSchema pool
        let eventKey = toSqlKey 43 :: SocialEventId
            invitation = EventInvitation eventKey (Just "1") (Just "2") (Just "pending") (Just "Join us") now now
            env = Env {envPool = pool, envConfig = error "invitation update needs no config"}
            payload recipient status = InvitationUpdateDTO
                ((invitationCreatePayload Nothing) {invitationToPartyId = recipient, invitationStatus = Just status})
                FieldMissing
            invoke :: Int64 -> EventInvitationId -> T.Text -> T.Text -> IO (Either ServerError InvitationDTO)
            invoke actor key recipient status = runHandler $ runReaderT
                (socialEventInvitationUpdateHandlerFor (socialEventUser actor) "43"
                    (T.pack (show (fromSqlKey key))) (payload recipient status)) env
            assertForbidden result = case result of
                Left err -> errHTTPCode err `shouldBe` 403
                Right value -> expectationFailure ("Expected stale response denial, got " <> show value)
        key <- runSqlPool (do
            insertKey eventKey (seedSocialEvent "1" "Invitation transfer" now)
            insert invitation) pool
        transferred <- invoke 1 key "3" "pending"
        fmap invitationToPartyId transferred `shouldBe` Right "3"
        invoke 2 key "2" "accepted" >>= assertForbidden
        declined <- invoke 3 key "3" "declined"
        fmap invitationStatus declined `shouldBe` Right (Just "declined")
        invoke 3 key "3" "accepted" >>= assertForbidden
        stored <- runSqlPool (get key) pool
        fmap eventInvitationToPartyId stored `shouldBe` Just (Just "3")
        fmap eventInvitationStatus stored `shouldBe` Just (Just "declined")

    it "attenuates invitation updates for the intended recipient" $ do
        validateInvitationUpdateAuthorization
            False
            "2"
            (Just "2")
            (Just "pending")
            "2"
            (Just "accepted")
            FieldMissing
            `shouldBe` Right ()

        let assertForbidden result =
                case result of
                    Left err -> errHTTPCode err `shouldBe` 403
                    Right () -> expectationFailure "Expected invitation mutation to be forbidden"

        assertForbidden $
            validateInvitationUpdateAuthorization
                False
                "3"
                (Just "2")
                (Just "pending")
                "2"
                (Just "accepted")
                FieldMissing
        assertForbidden $
            validateInvitationUpdateAuthorization
                False
                "2"
                (Just "2")
                (Just "pending")
                "3"
                (Just "accepted")
                FieldMissing
        assertForbidden $
            validateInvitationUpdateAuthorization
                False
                "2"
                (Just "2")
                (Just "pending")
                "2"
                (Just "accepted")
                (FieldValue "rewritten")
        assertForbidden $
            validateInvitationUpdateAuthorization
                False
                "2"
                (Just "2")
                (Just "accepted")
                "2"
                (Just "declined")
                FieldMissing

    it "lists all event invitations only for the organizer and scopes recipients to their own" $ do
        pool <- runNoLoggingT $ createSqlitePool ":memory:" 1
        runSqlPool initializeSocialSchema pool
        now <- getCurrentTime
        let eventKey :: SocialEventId
            eventKey = toSqlKey 12
            invitationFor toParty =
                EventInvitation
                    { eventInvitationEventId = eventKey
                    , eventInvitationFromPartyId = Just "1"
                    , eventInvitationToPartyId = Just toParty
                    , eventInvitationStatus = Just "pending"
                    , eventInvitationMessage = Just "Scoped invitation"
                    , eventInvitationCreatedAt = now
                    , eventInvitationUpdatedAt = now
                    }
        runSqlPool
            ( do
                insertKey eventKey (seedSocialEvent "1" "Scoped invitation reads" now)
                _ <- insert (invitationFor "2")
                _ <- insert (invitationFor "3")
                pure ()
            )
            pool
        let env =
                Env
                    { envPool = pool
                    , envConfig = error "envConfig should be unused by invitation read tests"
                    }
        organizerResult <-
            runHandler $
                runReaderT (socialEventInvitationListHandlerFor (socialEventUser 1) "12") env
        recipientResult <-
            runHandler $
                runReaderT (socialEventInvitationListHandlerFor (socialEventUser 2) "12") env
        fmap (map invitationToPartyId) organizerResult
            `shouldSatisfy` either (const False) ((== ["2", "3"]) . sort)
        fmap (map invitationToPartyId) recipientResult `shouldBe` Right ["2"]

    it "creates a follow and is idempotent" $ do
        pool <- runStdoutLoggingT $ createSqlitePool ":memory:" 1
        runSqlPool initializeSocialSchema pool
        now <- liftIO getCurrentTime
        artistId <-
            runSqlPool
                ( insert
                    ArtistProfile
                        { artistProfilePartyId = Nothing
                        , artistProfileName = "Band X"
                        , artistProfileBio = Nothing
                        , artistProfileAvatarUrl = Nothing
                        , artistProfileGenres = Nothing
                        , artistProfileSocialLinks = Nothing
                        , artistProfileCountryCode = Nothing
                        , artistProfileCountryId = Nothing
                        , artistProfileCreatedAt = now
                        , artistProfileUpdatedAt = now
                        }
                )
                pool

        first <- followArtistDb pool artistId "carla"
        second <- followArtistDb pool artistId "carla"
        liftIO $ do
            (afFollowId first) `shouldSatisfy` (/= Nothing)
            (afFollowId second) `shouldSatisfy` (/= Nothing)

socialEventUpdateHandlerFor
    :: AuthedUser
    -> T.Text
    -> EventUpdateDTO
    -> ReaderT Env Handler EventDTO
socialEventUpdateHandlerFor user =
    case socialEventsServer user of
        eventsServer
            :<|> _cities
            :<|> _sources
            :<|> _research
            :<|> _venues
            :<|> _artists
            :<|> _rsvps
            :<|> _invitations
            :<|> _moments
            :<|> _tickets
            :<|> _budget
            :<|> _finance ->
            case eventsServer of
                _listEvents
                    :<|> _createEvent
                    :<|> _getEvent
                    :<|> updateEventHandler
                    :<|> _uploadEventImage
                    :<|> _deleteEvent ->
                    updateEventHandler

socialEventDeleteHandlerFor
    :: AuthedUser
    -> T.Text
    -> ReaderT Env Handler NoContent
socialEventDeleteHandlerFor user =
    case socialEventsServer user of
        eventsServer :<|> _ ->
            case eventsServer of
                _listEvents
                    :<|> _createEvent
                    :<|> _getEvent
                    :<|> _updateEvent
                    :<|> _uploadEventImage
                    :<|> deleteEventHandler ->
                    deleteEventHandler

socialEventImageUploadHandlerFor
    :: AuthedUser
    -> T.Text
    -> EventImageUploadForm
    -> ReaderT Env Handler EventImageUploadDTO
socialEventImageUploadHandlerFor user =
    case socialEventsServer user of
        eventsServer :<|> _ ->
            case eventsServer of
                _listEvents
                    :<|> _createEvent
                    :<|> _getEvent
                    :<|> _updateEvent
                    :<|> uploadEventImageHandler
                    :<|> _deleteEvent ->
                    uploadEventImageHandler

socialEventMomentImageUploadHandlerFor
    :: AuthedUser
    -> T.Text
    -> EventImageUploadForm
    -> ReaderT Env Handler EventImageUploadDTO
socialEventMomentImageUploadHandlerFor user =
    case socialEventsServer user of
        _events
            :<|> _cities
            :<|> _sources
            :<|> _research
            :<|> _venues
            :<|> _artists
            :<|> _rsvps
            :<|> _invitations
            :<|> momentsServer
            :<|> _ ->
            case momentsServer of
                _listMoments
                    :<|> _createMoment
                    :<|> uploadMomentImageHandler
                    :<|> _reactToMoment
                    :<|> _commentOnMoment ->
                    uploadMomentImageHandler

socialEventListHandlerFor
    :: AuthedUser
    -> Maybe T.Text
    -> Maybe T.Text
    -> Maybe T.Text
    -> Maybe T.Text
    -> Maybe T.Text
    -> Maybe T.Text
    -> Maybe T.Text
    -> Maybe Int
    -> Maybe Int
    -> ReaderT Env Handler [EventDTO]
socialEventListHandlerFor user =
    case socialEventsServer user of
        eventsServer :<|> _ ->
            case eventsServer of
                listEventsHandler :<|> _ -> listEventsHandler

socialEventGetHandlerFor
    :: AuthedUser
    -> T.Text
    -> ReaderT Env Handler EventDTO
socialEventGetHandlerFor user =
    case socialEventsServer user of
        eventsServer
            :<|> _cities
            :<|> _sources
            :<|> _research
            :<|> _venues
            :<|> _artists
            :<|> _rsvps
            :<|> _invitations
            :<|> _moments
            :<|> _tickets
            :<|> _budget
            :<|> _finance ->
            case eventsServer of
                _listEvents
                    :<|> _createEvent
                    :<|> getEventHandler
                    :<|> _updateEvent
                    :<|> _uploadEventImage
                    :<|> _deleteEvent ->
                    getEventHandler

socialEventRsvpCreateHandlerFor
    :: AuthedUser
    -> T.Text
    -> RsvpCreateDTO
    -> ReaderT Env Handler RsvpDTO
socialEventRsvpCreateHandlerFor user =
    let (_, createRsvpHandler, _, _) = socialEventRsvpHandlersFor user
     in createRsvpHandler

socialEventRsvpHandlersFor
    :: AuthedUser
    -> ( T.Text -> ReaderT Env Handler (Maybe RsvpDTO)
       , T.Text -> RsvpCreateDTO -> ReaderT Env Handler RsvpDTO
       , T.Text -> ReaderT Env Handler NoContent
       , T.Text -> ReaderT Env Handler RsvpSummaryDTO
       )
socialEventRsvpHandlersFor user =
    case socialEventsServer user of
        _events
            :<|> _cities
            :<|> _sources
            :<|> _research
            :<|> _venues
            :<|> _artists
            :<|> rsvpsServer
            :<|> _ ->
            case rsvpsServer of
                getMyRsvp
                    :<|> createRsvpHandler
                    :<|> deleteRsvp
                    :<|> summary
                    :<|> _adminList
                    :<|> _profileFeed
                    :<|> _directoryProfileFeed ->
                        (getMyRsvp, createRsvpHandler, deleteRsvp, summary)

socialEventMomentCreateHandlerFor
    :: AuthedUser
    -> T.Text
    -> EventMomentCreateDTO
    -> ReaderT Env Handler EventMomentDTO
socialEventMomentCreateHandlerFor user =
    case socialEventsServer user of
        _events
            :<|> _cities
            :<|> _sources
            :<|> _research
            :<|> _venues
            :<|> _artists
            :<|> _rsvps
            :<|> _invitations
            :<|> momentsServer
            :<|> _ ->
            case momentsServer of
                _listMoments
                    :<|> createMomentHandler
                    :<|> _uploadMomentImage
                    :<|> _reactToMoment
                    :<|> _commentOnMoment ->
                    createMomentHandler

socialEventIndirectTicketHandlersFor
    :: AuthedUser
    -> ( TicketPurchaseWithPromoDTO -> ReaderT Env Handler StripePaymentIntentDTO
       , T.Text -> T.Text -> RefundRequestDTO -> ReaderT Env Handler RefundDTO
       , T.Text -> ReaderT Env Handler [RefundDTO]
       , T.Text -> T.Text -> RejectionReasonDTO -> ReaderT Env Handler RefundDTO
       , T.Text -> ReaderT Env Handler TicketDTO
       , T.Text -> ReaderT Env Handler TicketTransferDTO
       )
socialEventIndirectTicketHandlersFor user =
    case socialEventsServer user of
        _events
            :<|> _cities
            :<|> _sources
            :<|> _research
            :<|> _venues
            :<|> _artists
            :<|> _rsvps
            :<|> _invitations
            :<|> _moments
            :<|> _liveBroadcasts
            :<|> ticketsServer
            :<|> _ -> case ticketsServer of
                _listTicketTiers
                    :<|> _createTicketTier
                    :<|> _updateTicketTier
                    :<|> _listMyTicketOrders
                    :<|> _listTicketOrders
                    :<|> _createTicketOrder
                    :<|> _updateTicketOrderStatus
                    :<|> _listTickets
                    :<|> _checkInTicket
                    :<|> _listPromoCodes
                    :<|> _createPromoCode
                    :<|> _updatePromoCode
                    :<|> _validatePromoCode
                    :<|> createStripePaymentIntentHandler
                    :<|> createRefundRequestHandler
                    :<|> listRefundsHandler
                    :<|> _approveRefund
                    :<|> rejectRefundHandler
                    :<|> _listManualPayments
                    :<|> _reviewManualPayment
                    :<|> _getManualPaymentReceipt
                    :<|> _listTaxDocuments
                    :<|> _retryTaxDocument
                    :<|> _completeBankTransferRefund
                    :<|> _createTransfer
                    :<|> _listTransfers
                    :<|> acceptTransferHandler
                    :<|> cancelTransferHandler
                    :<|> _remainingTicketHandlers ->
                        ( createStripePaymentIntentHandler
                        , createRefundRequestHandler
                        , listRefundsHandler
                        , rejectRefundHandler
                        , acceptTransferHandler
                        , cancelTransferHandler
                        )

artistGetHandlerFor
    :: AuthedUser
    -> T.Text
    -> ReaderT Env Handler ArtistDTO
artistGetHandlerFor user =
    case socialEventsServer user of
        _events
            :<|> _cities
            :<|> _sources
            :<|> _research
            :<|> _venues
            :<|> artistsServer
            :<|> _rsvps
            :<|> _invitations
            :<|> _moments
            :<|> _tickets
            :<|> _budget
            :<|> _finance ->
            case artistsServer of
                _listArtists
                    :<|> _createArtist
                    :<|> getArtistHandler
                    :<|> _updateArtist
                    :<|> _listArtistFollowers
                    :<|> _followArtist
                    :<|> _unfollowArtist ->
                    getArtistHandler

socialEventInvitationCreateHandlerFor
    :: AuthedUser
    -> T.Text
    -> InvitationDTO
    -> ReaderT Env Handler InvitationDTO
socialEventInvitationCreateHandlerFor user eventIdText =
    case socialEventsServer user of
        _events
            :<|> _cities
            :<|> _sources
            :<|> _research
            :<|> _venues
            :<|> _artists
            :<|> _rsvps
            :<|> invitationsServer
            :<|> _moments
            :<|> _tickets
            :<|> _budget
            :<|> _finance ->
            case invitationsServer eventIdText of
                _listInvitations :<|> createInvitationHandler :<|> _updateInvitation ->
                    createInvitationHandler

socialEventInvitationUpdateHandlerFor
    :: AuthedUser -> T.Text -> T.Text -> InvitationUpdateDTO -> ReaderT Env Handler InvitationDTO
socialEventInvitationUpdateHandlerFor user eventIdText =
    case socialEventsServer user of
        _events :<|> _cities :<|> _sources :<|> _research :<|> _venues
            :<|> _artists :<|> _rsvps :<|> invitationsServer :<|> _ ->
            case invitationsServer eventIdText of
                _list :<|> _create :<|> updateHandler -> updateHandler

socialEventInvitationListHandlerFor
    :: AuthedUser
    -> T.Text
    -> ReaderT Env Handler [InvitationDTO]
socialEventInvitationListHandlerFor user eventIdText =
    case socialEventsServer user of
        _events
            :<|> _cities
            :<|> _sources
            :<|> _research
            :<|> _venues
            :<|> _artists
            :<|> _rsvps
            :<|> invitationsServer
            :<|> _ ->
            case invitationsServer eventIdText of
                listInvitationsHandler :<|> _createInvitation :<|> _updateInvitation ->
                    listInvitationsHandler

assertHiddenEventRoute :: Show a => String -> Either ServerError a -> Expectation
assertHiddenEventRoute label result =
    case result of
        Left err -> do
            errHTTPCode err `shouldBe` 404
            BL8.unpack (errBody err) `shouldContain` "Event not found"
        Right value ->
            expectationFailure
                ("Expected hidden event " <> label <> " route to return 404, got: " <> show value)

socialEventUser :: Int64 -> AuthedUser
socialEventUser partyId =
    AuthedUser
        { auPartyId = toSqlKey partyId
        , auRoles = [Fan]
        , auModules = modulesForRoles [Fan]
        , auApiTokenId = Nothing
        , auSessionWitness = Nothing
        }

strictAdminSocialEventUser :: Int64 -> AuthedUser
strictAdminSocialEventUser partyId =
    AuthedUser
        { auPartyId = toSqlKey partyId
        , auRoles = [Admin]
        , auModules = modulesForRoles [Admin]
        , auApiTokenId = Nothing
        , auSessionWitness = Nothing
        }

socialEventStartFixture :: UTCTime
socialEventStartFixture =
    UTCTime (fromGregorian 2026 1 1) (secondsToDiffTime 0)

socialEventEndFixture :: UTCTime
socialEventEndFixture =
    UTCTime (fromGregorian 2026 1 1) (secondsToDiffTime 3600)

socialEventWorkflowStateFixtureId :: UUID.UUID
socialEventWorkflowStateFixtureId =
    case UUID.fromString "00000000-0000-4000-8000-000000000233" of
        Just workflowStateId -> workflowStateId
        Nothing -> error "Invalid social-event workflow-state fixture UUID"

socialEventCancelledWorkflowStateFixtureId :: UUID.UUID
socialEventCancelledWorkflowStateFixtureId =
    case UUID.fromString "00000000-0000-4000-8000-000000000239" of
        Just workflowStateId -> workflowStateId
        Nothing -> error "Invalid cancelled social-event workflow-state fixture UUID"

socialEventUnavailableWorkflowStateFixtureId :: UUID.UUID
socialEventUnavailableWorkflowStateFixtureId =
    case UUID.fromString "00000000-0000-4000-8000-000000000236" of
        Just workflowStateId -> workflowStateId
        Nothing -> error "Invalid unavailable social-event workflow-state fixture UUID"

seedSocialEvent :: T.Text -> T.Text -> UTCTime -> SocialEvent
seedSocialEvent owner title now =
    SocialEvent
        { socialEventOrganizerPartyId = Just owner
        , socialEventTitle = title
        , socialEventDescription = Nothing
        , socialEventVenueId = Nothing
        , socialEventStartTime = socialEventStartFixture
        , socialEventEndTime = Just socialEventEndFixture
        , socialEventPriceCents = Nothing
        , socialEventCapacity = Nothing
        , socialEventMetadata = Nothing
        , socialEventEventTypeId = Nothing
        , socialEventWorkflowStateId = Nothing
        , socialEventTimezone = Nothing
        , socialEventCurrencyId = Nothing
        , socialEventCreatedAt = now
        , socialEventUpdatedAt = now
        }

socialEventUpdatePayload :: T.Text -> EventUpdateDTO
socialEventUpdatePayload title =
    EventUpdateDTO
        { eudEvent =
            EventDTO
                { eventId = Just "7"
                , eventOrganizerPartyId = Nothing
                , eventTitle = title
                , eventDescription = Nothing
                , eventStart = socialEventStartFixture
                , eventEnd = Just socialEventEndFixture
                , eventTimezone = Just "America/Guayaquil"
                , eventVenueId = Nothing
                , eventPriceCents = Nothing
                , eventCapacity = Nothing
                , eventTicketUrl = Nothing
                , eventImageUrl = Nothing
                , eventIsPublic = Nothing
                , eventTypeId = Nothing
                , eventWorkflowStateId = Nothing
                , eventWorkflowStateCode = Nothing
                , eventWorkflowStateNameEs = Nothing
                , eventWorkflowStateNameEn = Nothing
                , eventPublicListable = Nothing
                , eventRsvpEligible = Nothing
                , eventTicketPurchaseEnabled = Nothing
                , eventCurrency = Nothing
                , eventBudgetCents = Nothing
                , eventSources = Nothing
                , eventCreatedAt = Nothing
                , eventUpdatedAt = Nothing
                , eventArtists = []
                }
        , eudWorkflowStateIdUpdate = FieldMissing
        , eudMetadataUpdate = emptyEventMetadataUpdate
        }

invitationCreatePayload :: Maybe T.Text -> InvitationDTO
invitationCreatePayload mFromPartyId =
    InvitationDTO
        { invitationId = Nothing
        , invitationEventId = Nothing
        , invitationFromPartyId = mFromPartyId
        , invitationToPartyId = "2"
        , invitationStatus = Just "pending"
        , invitationMessage = Just "Join us"
        , invitationCreatedAt = Nothing
        , invitationUpdatedAt = Nothing
        }

emptyEventMetadataUpdate :: EventMetadataUpdateDTO
emptyEventMetadataUpdate =
    EventMetadataUpdateDTO
        { emuTicketUrl = FieldMissing
        , emuImageUrl = FieldMissing
        , emuIsPublic = FieldMissing
        , emuCurrency = FieldMissing
        , emuBudgetCents = FieldMissing
        }

initializeSocialSchema :: SqlPersistT IO ()
initializeSocialSchema = do
    rawExecute "PRAGMA foreign_keys = ON" []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"party\" (\
        \\"id\" INTEGER PRIMARY KEY,\
        \\"legal_name\" VARCHAR NULL,\
        \\"display_name\" VARCHAR NOT NULL,\
        \\"is_org\" BOOLEAN NOT NULL,\
        \\"tax_id\" VARCHAR NULL,\
        \\"primary_email\" VARCHAR NULL,\
        \\"primary_phone\" VARCHAR NULL,\
        \\"whatsapp\" VARCHAR NULL,\
        \\"instagram\" VARCHAR NULL,\
        \\"emergency_contact\" VARCHAR NULL,\
        \\"notes\" VARCHAR NULL,\
        \\"stripe_customer_id\" VARCHAR NULL,\
        \\"country_code\" VARCHAR NULL,\
        \\"country_id\" VARCHAR NULL,\
        \\"created_at\" TIMESTAMP NOT NULL\
        \)"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"social_artist_profile\" (\
        \\"id\" INTEGER PRIMARY KEY,\
        \\"party_id\" VARCHAR NULL,\
        \\"name\" VARCHAR NOT NULL,\
        \\"bio\" VARCHAR NULL,\
        \\"avatar_url\" VARCHAR NULL,\
        \\"genres\" VARCHAR NULL,\
        \\"social_links\" VARCHAR NULL,\
        \\"country_code\" VARCHAR NULL,\
        \\"country_id\" VARCHAR NULL,\
        \\"created_at\" TIMESTAMP NOT NULL,\
        \\"updated_at\" TIMESTAMP NOT NULL\
        \)"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"artist_genre\" (\
        \\"artist_id\" INTEGER NOT NULL,\
        \\"genre\" VARCHAR NOT NULL,\
        \\"genre_id\" VARCHAR NULL,\
        \PRIMARY KEY (\"artist_id\", \"genre\"),\
        \FOREIGN KEY(\"artist_id\") REFERENCES \"social_artist_profile\"(\"id\") ON DELETE CASCADE\
        \)"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"artist_genre_membership\" (\
        \\"artist_id\" INTEGER NOT NULL,\
        \\"genre_id\" VARCHAR NOT NULL,\
        \\"sort_order\" INTEGER NOT NULL,\
        \\"created_at\" TIMESTAMP NOT NULL,\
        \PRIMARY KEY (\"artist_id\", \"genre_id\"),\
        \FOREIGN KEY(\"artist_id\") REFERENCES \"social_artist_profile\"(\"id\") ON DELETE CASCADE\
        \)"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"venue\" (\
        \\"id\" INTEGER PRIMARY KEY,\
        \\"name\" VARCHAR NOT NULL,\
        \\"address\" VARCHAR NULL,\
        \\"city\" VARCHAR NULL,\
        \\"country\" VARCHAR NULL,\
        \\"country_code\" VARCHAR NULL,\
        \\"country_id\" VARCHAR NULL,\
        \\"city_id\" VARCHAR NULL,\
        \\"timezone\" VARCHAR NULL,\
        \\"latitude\" REAL NULL,\
        \\"longitude\" REAL NULL,\
        \\"capacity\" INTEGER NULL,\
        \\"contact\" VARCHAR NULL,\
        \\"created_at\" TIMESTAMP NOT NULL,\
        \\"updated_at\" TIMESTAMP NOT NULL\
        \)"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"social_event\" (\
        \\"id\" INTEGER PRIMARY KEY,\
        \\"organizer_party_id\" VARCHAR NULL,\
        \\"title\" VARCHAR NOT NULL,\
        \\"description\" VARCHAR NULL,\
        \\"venue_id\" INTEGER NULL,\
        \\"event_type_id\" VARCHAR NULL,\
        \\"workflow_state_id\" VARCHAR NULL,\
        \\"timezone\" VARCHAR NULL,\
        \\"start_time\" TIMESTAMP NOT NULL,\
        \\"end_time\" TIMESTAMP NOT NULL,\
        \\"price_cents\" INTEGER NULL,\
        \\"currency_id\" VARCHAR NULL,\
        \\"capacity\" INTEGER NULL,\
        \\"metadata\" VARCHAR NULL,\
        \\"created_at\" TIMESTAMP NOT NULL,\
        \\"updated_at\" TIMESTAMP NOT NULL\
        \)"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"event_rsvp\" (\"id\" INTEGER PRIMARY KEY AUTOINCREMENT,\"event_id\" INTEGER NOT NULL,\"party_id\" VARCHAR NOT NULL,\"status\" VARCHAR NOT NULL,\"show_on_profile\" BOOLEAN NOT NULL DEFAULT 0,\"visibility_decided_at\" TIMESTAMP NULL,\"metadata\" VARCHAR NULL,\"created_at\" TIMESTAMP NOT NULL,\"updated_at\" TIMESTAMP NOT NULL,UNIQUE(\"event_id\",\"party_id\"))"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"event_rsvp_mutation_rate_limit\" (\"id\" INTEGER PRIMARY KEY AUTOINCREMENT,\"party_id\" VARCHAR NOT NULL,\"window_start\" TIMESTAMP NOT NULL,\"mutation_count\" INTEGER NOT NULL DEFAULT 1,\"updated_at\" TIMESTAMP NOT NULL,UNIQUE(\"party_id\",\"window_start\"))"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"event_invitation\" (\"id\" INTEGER PRIMARY KEY AUTOINCREMENT,\"event_id\" INTEGER NOT NULL,\"from_party_id\" VARCHAR NULL,\"to_party_id\" VARCHAR NULL,\"status\" VARCHAR NULL,\"message\" VARCHAR NULL,\"created_at\" TIMESTAMP NOT NULL,\"updated_at\" TIMESTAMP NOT NULL)"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"workflow_definition\" (\"id\" VARCHAR PRIMARY KEY,\"code\" VARCHAR NOT NULL UNIQUE,\"active\" BOOLEAN NOT NULL)"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"workflow_state\" (\"id\" VARCHAR PRIMARY KEY,\"workflow_id\" VARCHAR NOT NULL,\"code\" VARCHAR NOT NULL,\"name_es\" VARCHAR NOT NULL,\"name_en\" VARCHAR NOT NULL,\"active\" BOOLEAN NOT NULL)"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"workflow_transition\" (\"workflow_id\" VARCHAR NOT NULL,\"from_state_id\" VARCHAR NOT NULL,\"to_state_id\" VARCHAR NOT NULL,\"required_permission_id\" VARCHAR NULL,\"requires_review\" BOOLEAN NOT NULL,\"requires_distinct_approver\" BOOLEAN NOT NULL,\"effective_from\" TIMESTAMP NULL,\"effective_until\" TIMESTAMP NULL,\"active\" BOOLEAN NOT NULL)"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"workflow_state_capability\" (\"state_id\" VARCHAR NOT NULL,\"capability_code\" VARCHAR NOT NULL,\"enabled\" BOOLEAN NOT NULL,PRIMARY KEY (\"state_id\",\"capability_code\"))"
        []
    rawExecute
        "INSERT INTO \"workflow_definition\" (\"id\",\"code\",\"active\") VALUES ('00000000-0000-4000-8000-000000000104','social-event-lifecycle',1)"
        []
    rawExecute
        "INSERT INTO \"workflow_state\" (\"id\",\"workflow_id\",\"code\",\"name_es\",\"name_en\",\"active\") VALUES ('00000000-0000-4000-8000-000000000233','00000000-0000-4000-8000-000000000104','on_sale','En venta','On sale',1)"
        []
    rawExecute
        "INSERT INTO \"workflow_state\" (\"id\",\"workflow_id\",\"code\",\"name_es\",\"name_en\",\"active\") VALUES ('00000000-0000-4000-8000-000000000239','00000000-0000-4000-8000-000000000104','cancelled','Cancelado','Cancelled',1)"
        []
    rawExecute
        "INSERT INTO \"workflow_state\" (\"id\",\"workflow_id\",\"code\",\"name_es\",\"name_en\",\"active\") VALUES ('00000000-0000-4000-8000-000000000236','00000000-0000-4000-8000-000000000104','unavailable','No disponible','Unavailable',1)"
        []
    rawExecute
        "INSERT INTO \"workflow_transition\" (\"workflow_id\",\"from_state_id\",\"to_state_id\",\"required_permission_id\",\"requires_review\",\"requires_distinct_approver\",\"effective_from\",\"effective_until\",\"active\") VALUES ('00000000-0000-4000-8000-000000000104','00000000-0000-4000-8000-000000000233','00000000-0000-4000-8000-000000000239',NULL,0,0,NULL,NULL,1)"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"event_discovery_source\" (\"id\" INTEGER PRIMARY KEY,\"source_key\" VARCHAR NOT NULL,\"name\" VARCHAR NOT NULL,\"source_type\" VARCHAR NOT NULL,\"feed_url\" VARCHAR NULL,\"city_id\" INTEGER NULL,\"enabled\" BOOLEAN NOT NULL DEFAULT 1,\"priority\" INTEGER NOT NULL DEFAULT 100,\"configuration\" VARCHAR NULL,\"etag\" VARCHAR NULL,\"last_modified\" VARCHAR NULL,\"consecutive_failures\" INTEGER NOT NULL DEFAULT 0,\"last_success_at\" TIMESTAMP NULL,\"last_error\" VARCHAR NULL,\"created_at\" TIMESTAMP NOT NULL,\"updated_at\" TIMESTAMP NOT NULL,UNIQUE (\"source_key\"))"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"event_ticket_tier\" (\"id\" INTEGER PRIMARY KEY,\"event_id\" INTEGER NOT NULL,\"code\" VARCHAR NOT NULL,\"name\" VARCHAR NOT NULL,\"description\" VARCHAR NULL,\"price_cents\" INTEGER NOT NULL,\"currency\" VARCHAR NOT NULL,\"currency_id\" VARCHAR NULL,\"quantity_total\" INTEGER NOT NULL,\"quantity_sold\" INTEGER NOT NULL,\"sales_start\" TIMESTAMP NULL,\"sales_end\" TIMESTAMP NULL,\"is_active\" BOOLEAN NOT NULL,\"position\" INTEGER NULL,\"enable_waitlist\" BOOLEAN NOT NULL,\"allow_transfers\" BOOLEAN NOT NULL,\"refund_policy\" VARCHAR NOT NULL,\"refund_deadline\" TIMESTAMP NULL,\"created_at\" TIMESTAMP NOT NULL,\"updated_at\" TIMESTAMP NOT NULL,UNIQUE (\"event_id\",\"code\"))"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"event_ticket_order\" (\
        \\"id\" INTEGER PRIMARY KEY,\
        \\"event_id\" INTEGER NOT NULL,\
        \\"tier_id\" INTEGER NOT NULL,\
        \\"buyer_party_id\" VARCHAR NULL,\
        \\"buyer_name\" VARCHAR NULL,\
        \\"buyer_email\" VARCHAR NULL,\
        \\"quantity\" INTEGER NOT NULL,\
        \\"amount_cents\" INTEGER NOT NULL,\
        \\"currency\" VARCHAR NOT NULL,\
        \\"status\" VARCHAR NOT NULL,\
        \\"metadata\" VARCHAR NULL,\
        \\"checkout_idempotency_key\" VARCHAR NULL,\
        \\"purchased_at\" TIMESTAMP NOT NULL,\
        \\"stripe_payment_intent_id\" VARCHAR NULL,\
        \\"promo_code_id\" INTEGER NULL,\
        \\"original_amount_cents\" INTEGER NULL,\
        \\"payment_method\" VARCHAR NULL,\
        \\"created_at\" TIMESTAMP NOT NULL,\
        \\"updated_at\" TIMESTAMP NOT NULL,\
        \UNIQUE (\"buyer_party_id\", \"checkout_idempotency_key\")\
        \)"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"event_ticket\" (\"id\" INTEGER PRIMARY KEY,\"event_id\" INTEGER NOT NULL,\"tier_ref_id\" INTEGER NOT NULL,\"order_ref_id\" INTEGER NOT NULL,\"holder_name\" VARCHAR NULL,\"holder_email\" VARCHAR NULL,\"code\" VARCHAR NOT NULL,\"status\" VARCHAR NOT NULL,\"checked_in_at\" TIMESTAMP NULL,\"current_holder_party_id\" VARCHAR NULL,\"current_holder_email\" VARCHAR NULL,\"current_holder_name\" VARCHAR NULL,\"original_holder_party_id\" VARCHAR NULL,\"transfer_history\" VARCHAR NULL,\"created_at\" TIMESTAMP NOT NULL,\"updated_at\" TIMESTAMP NOT NULL,UNIQUE (\"code\"))"
        []
    -- Legacy visibility cases have no canonical checkout or refund binding.
    -- Keep these lookup tables empty; PostgreSQL tests separately exercise the
    -- canonical financial schema, transactions and immutable binding guards.
    rawExecute
        "CREATE TABLE IF NOT EXISTS event_ticket_checkout_runtime (order_id INTEGER PRIMARY KEY)"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS event_ticket_refund_request_binding (request_id INTEGER PRIMARY KEY, refund_id TEXT NOT NULL UNIQUE)"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"ticket_refund_request\" (\
        \\"id\" INTEGER PRIMARY KEY,\
        \\"order_id\" INTEGER NOT NULL,\
        \\"requested_by_party_id\" VARCHAR NULL,\
        \\"reason\" VARCHAR NULL,\
        \\"amount_cents\" INTEGER NOT NULL,\
        \\"status\" VARCHAR NOT NULL,\
        \\"approved_by_party_id\" VARCHAR NULL,\
        \\"approved_at\" TIMESTAMP NULL,\
        \\"rejection_reason\" VARCHAR NULL,\
        \\"stripe_refund_id\" VARCHAR NULL,\
        \\"processed_at\" TIMESTAMP NULL,\
        \\"created_at\" TIMESTAMP NOT NULL,\
        \\"updated_at\" TIMESTAMP NOT NULL\
        \)"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"ticket_transfer\" (\"id\" INTEGER PRIMARY KEY,\"ticket_id\" INTEGER NOT NULL,\"from_party_id\" VARCHAR NULL,\"to_party_id\" VARCHAR NULL,\"to_email\" VARCHAR NULL,\"to_name\" VARCHAR NULL,\"status\" VARCHAR NOT NULL,\"transfer_code\" VARCHAR NOT NULL,\"message\" VARCHAR NULL,\"expires_at\" TIMESTAMP NULL,\"accepted_at\" TIMESTAMP NULL,\"created_at\" TIMESTAMP NOT NULL,\"updated_at\" TIMESTAMP NOT NULL,UNIQUE (\"transfer_code\"))"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"external_event_ref\" (\
        \\"id\" INTEGER PRIMARY KEY,\
        \\"provider\" VARCHAR NOT NULL,\
        \\"external_id\" VARCHAR NOT NULL,\
        \\"event_id\" INTEGER NOT NULL,\
        \\"city\" VARCHAR NOT NULL,\
        \\"country_code\" VARCHAR NULL,\
        \\"source_url\" VARCHAR NULL,\
        \\"price_cents\" INTEGER NULL,\
        \\"currency\" VARCHAR NULL,\
        \\"last_seen_at\" TIMESTAMP NOT NULL,\
        \\"missing_runs\" INTEGER NOT NULL DEFAULT 0,\
        \\"source_status\" VARCHAR NOT NULL DEFAULT 'active',\
        \UNIQUE (\"provider\", \"external_id\"),\
        \FOREIGN KEY(\"event_id\") REFERENCES \"social_event\"(\"id\") ON DELETE CASCADE\
        \)"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"event_artist\" (\
        \\"event_id\" INTEGER NOT NULL,\
        \\"artist_id\" INTEGER NOT NULL,\
        \\"role\" VARCHAR NULL,\
        \PRIMARY KEY (\"event_id\", \"artist_id\"),\
        \FOREIGN KEY(\"event_id\") REFERENCES \"social_event\"(\"id\") ON DELETE CASCADE,\
        \FOREIGN KEY(\"artist_id\") REFERENCES \"social_artist_profile\"(\"id\") ON DELETE CASCADE\
        \)"
        []
    rawExecute
        "CREATE TABLE IF NOT EXISTS \"artist_follow\" (\
        \\"artist_id\" INTEGER NOT NULL,\
        \\"follower_party_id\" VARCHAR NOT NULL,\
        \\"created_at\" TIMESTAMP NOT NULL,\
        \PRIMARY KEY (\"artist_id\", \"follower_party_id\"),\
        \FOREIGN KEY(\"artist_id\") REFERENCES \"social_artist_profile\"(\"id\") ON DELETE CASCADE\
        \)"
        []

-- These SQLite fixtures exercise the real Servant handlers and Haskell Int
-- arithmetic. They do not attest production PostgreSQL DDL or provider behavior.
withFinanceRangeEnv :: (Env -> IO ()) -> IO ()
withFinanceRangeEnv action = do
    cfg <- Config.loadConfig
    bracket (runNoLoggingT $ createSqlitePool ":memory:" 1) destroyAllResources $ \pool -> do
        runSqlPool (do
            initializeSocialSchema
            rawExecute "CREATE TABLE event_budget_line (id INTEGER PRIMARY KEY,event_id INTEGER NOT NULL,code TEXT NOT NULL,name TEXT NOT NULL,line_type TEXT NOT NULL,category TEXT NOT NULL,planned_cents INTEGER NOT NULL,notes TEXT,created_at TIMESTAMP NOT NULL,updated_at TIMESTAMP NOT NULL,UNIQUE(event_id,code))" []
            rawExecute "CREATE TABLE event_finance_entry (id INTEGER PRIMARY KEY,event_id INTEGER NOT NULL,budget_line_id INTEGER,direction TEXT NOT NULL,source TEXT NOT NULL,category TEXT NOT NULL,concept TEXT NOT NULL,amount_cents INTEGER NOT NULL,currency TEXT NOT NULL,status TEXT NOT NULL,external_ref TEXT,notes TEXT,metadata TEXT,occurred_at TIMESTAMP NOT NULL,recorded_by_party_id TEXT,created_at TIMESTAMP NOT NULL,updated_at TIMESTAMP NOT NULL)" []
            rawExecute "ALTER TABLE event_ticket_checkout_runtime ADD COLUMN event_id INTEGER" []
            rawExecute "ALTER TABLE event_ticket_checkout_runtime ADD COLUMN checkout_id TEXT" []
            rawExecute "CREATE TABLE commerce_checkout_session (id TEXT PRIMARY KEY,paid_minor INTEGER NOT NULL,refunded_minor INTEGER NOT NULL,currency TEXT NOT NULL)" []
            insertKey (toSqlKey 7) (seedSocialEvent "1" "Finance range fixture" socialEventStartFixture)
            rawExecute "INSERT INTO event_ticket_tier (id,event_id,code,name,price_cents,currency,quantity_total,quantity_sold,is_active,enable_waitlist,allow_transfers,refund_policy,created_at,updated_at) VALUES (1,7,'range','Range',1,'USD',10,0,1,0,1,'full',?,?)" [toPersistValue socialEventStartFixture,toPersistValue socialEventStartFixture]

            ) pool
        action Env{envPool=pool,envConfig=cfg{Config.defaultCurrency="USD"}}

rangeBudget :: Env -> Int -> T.Text -> Int -> IO ()
rangeBudget env key direction amount = runSqlPool
    (rawExecute "INSERT INTO event_budget_line (id,event_id,code,name,line_type,category,planned_cents,created_at,updated_at) VALUES (?,7,?,'Range',?,'other',?,?,?)"
        [toPersistValue key,toPersistValue (T.pack (show key)),toPersistValue direction,toPersistValue amount,
         toPersistValue socialEventStartFixture,toPersistValue socialEventStartFixture]) (envPool env)

rangeEntry :: Env -> T.Text -> T.Text -> T.Text -> Int -> IO ()
rangeEntry env direction source status amount = runSqlPool
    (rawExecute "INSERT INTO event_finance_entry (event_id,budget_line_id,direction,source,category,concept,amount_cents,currency,status,occurred_at,created_at,updated_at) VALUES (7,(SELECT id FROM event_budget_line WHERE id=1),?,?,'other','Range',?,'USD',?,?,?,?)"
        [toPersistValue direction,toPersistValue source,toPersistValue amount,toPersistValue status,
         toPersistValue socialEventStartFixture,toPersistValue socialEventStartFixture,toPersistValue socialEventStartFixture]) (envPool env)

rangeTicket :: Env -> Int -> T.Text -> Int -> IO ()
rangeTicket env key status amount = runSqlPool
    (rawExecute "INSERT INTO event_ticket_order (id,event_id,tier_id,quantity,amount_cents,currency,status,purchased_at,created_at,updated_at) VALUES (?,7,1,1,?,'USD',?,?,?,?)"
        [toPersistValue key,toPersistValue amount,toPersistValue status,toPersistValue socialEventStartFixture,
         toPersistValue socialEventStartFixture,toPersistValue socialEventStartFixture]) (envPool env)

rangeBudgetPayload :: Int -> EventBudgetLineDTO
rangeBudgetPayload amount = EventBudgetLineDTO Nothing Nothing "1" "Range" "expense" "other" amount Nothing Nothing Nothing Nothing

rangeBudgetList :: Env -> IO (Either ServerError [EventBudgetLineDTO])
rangeBudgetList env = case socialEventsServer (strictAdminSocialEventUser 1) of
    _events :<|> _cities :<|> _discovery :<|> _research :<|> _venues
        :<|> _artists :<|> _rsvps :<|> _invitations :<|> _moments :<|> _broadcasts :<|> _tickets
        :<|> (listHandler :<|> _ :<|> _) :<|> _ ->
        runHandler $ runReaderT (listHandler "7") env

rangeBudgetUpdate :: Env -> EventBudgetLineDTO -> IO (Either ServerError EventBudgetLineDTO)
rangeBudgetUpdate env dto = case socialEventsServer (strictAdminSocialEventUser 1) of
    _events :<|> _cities :<|> _discovery :<|> _research :<|> _venues
        :<|> _artists :<|> _rsvps :<|> _invitations :<|> _moments :<|> _broadcasts :<|> _tickets
        :<|> (_ :<|> _ :<|> updateHandler) :<|> _ ->
        runHandler $ runReaderT (updateHandler "7" "1" dto) env

rangeSummary :: Env -> IO (Either ServerError EventFinanceSummaryDTO)
rangeSummary env = case socialEventsServer (strictAdminSocialEventUser 1) of
    _events :<|> _cities :<|> _discovery :<|> _research :<|> _venues
        :<|> _artists :<|> _rsvps :<|> _invitations :<|> _moments :<|> _broadcasts :<|> _tickets
        :<|> _budget :<|> (_ :<|> _ :<|> _ :<|> summaryHandler) :<|> _ ->
        runHandler $ runReaderT (summaryHandler "7") env

rangeReject :: Show a => Either ServerError a -> Expectation
rangeReject (Left err) = do
    errHTTPCode err `shouldBe` 500
    BL8.unpack (errBody err) `shouldContain` "supported reporting range"
rangeReject (Right value) = expectationFailure ("Expected range refusal, got " <> show value)

-- Foreign-currency authoring is intentional; reporting must check the rows
-- that actually contribute instead of relabelling or silently dropping them.
currencyEntry :: Env -> T.Text -> T.Text -> T.Text -> Int -> Maybe T.Text -> IO ()
currencyEntry env currency direction status amount budget = do
    let dto = EventFinanceEntryDTO
            { efeId=Nothing, efeEventId=Nothing, efeBudgetLineId=budget
            , efeDirection=direction, efeSource="manual", efeCategory="other"
            , efeConcept="Currency fixture", efeAmountCents=amount, efeCurrency=currency
            , efeStatus=status, efeExternalRef=Nothing, efeNotes=Nothing
            , efeOccurredAt=socialEventStartFixture, efeRecordedByPartyId=Nothing
            , efeCreatedAt=Nothing, efeUpdatedAt=Nothing }
    result <- case socialEventsServer (strictAdminSocialEventUser 1) of
        _events :<|> _cities :<|> _discovery :<|> _research :<|> _venues
            :<|> _artists :<|> _rsvps :<|> _invitations :<|> _moments :<|> _broadcasts :<|> _tickets
            :<|> _budget :<|> (_ :<|> createHandler :<|> _ :<|> _) :<|> _ ->
            runHandler $ runReaderT (createHandler "7" dto) env
    fmap (\row -> (efeCurrency row,efeAmountCents row,efeStatus row)) result
        `shouldBe` Right (currency,amount,status)

currencyTicket :: Env -> T.Text -> T.Text -> Int -> IO ()
currencyTicket env currency status amount = do
    -- Keep the ordinary legacy order and its tier currency/unit price coherent.
    runSqlPool (rawExecute "UPDATE event_ticket_tier SET currency=?,price_cents=? WHERE id=1"
        [toPersistValue currency,toPersistValue amount]) (envPool env)
    rangeTicket env 1 status amount
    runSqlPool (rawExecute "UPDATE event_ticket_order SET currency=? WHERE id=1"
        [toPersistValue currency]) (envPool env)

currencyEvent :: Env -> T.Text -> IO ()
currencyEvent env currency = runSqlPool
    (rawExecute "UPDATE social_event SET metadata=? WHERE id=7"
        [toPersistValue (T.pack (BL8.unpack (Aeson.encode (Aeson.object ["currency" Aeson..= currency]))))]) (envPool env)

currencyReject :: Show a => Either ServerError a -> Expectation
currencyReject (Left err) = do
    errHTTPCode err `shouldBe` 500
    BL8.unpack (errBody err) `shouldContain` "currency"
currencyReject (Right value) = expectationFailure ("Expected currency refusal, got " <> show value)
