from pathlib import Path
import ast,json,hashlib,copy,datetime
w=Path('/private/tmp/tdf-event-finance-range-main643-20261030T2302');o=Path('/private/tmp/tdf-event-finance-range-main643-qualification-20261030T2302');p=Path('/private/tmp/tdf-event-finance-range-main643-seal-20261030T2302.py')
sha=lambda b:hashlib.sha256(b).hexdigest();tree=ast.parse(p.read_text());functions=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='verify_current_artifact_bindings'];assert len(functions)==1
namespace={'sha':sha};exec(compile(ast.Module(body=functions,type_ignores=[]),str(p),'exec'),namespace);check=namespace['verify_current_artifact_bindings']
root=json.loads((o/'root-quality-result.json').read_text());m=json.loads((o/'preparation-state.json').read_text())['sourceCommit'];q=json.loads((o/'native-quality.json').read_text());f=json.loads((o/'assurance-committed/report.json').read_text());s=json.loads((o/'assurance-committed/sources.json').read_text());force=json.loads((o/'native-force-dirty-confirmed.json').read_text());binary=Path(q['binary']).read_bytes();paths=list((w/'tdf-hq/.stack-work/dist').glob('**/build/tdf-hq-test/tdf-hq-test-tmp/TDF/Version.o'));assert len(paths)==1;version=paths[0].read_bytes()
check(m,q,f,s,force,binary,version,160,root);results=[]
def control(label,mutate):
 qq,ff,ss,fo=copy.deepcopy(q),copy.deepcopy(f),copy.deepcopy(s),copy.deepcopy(force);bb,vv=binary,version
 changed=mutate(qq,ff,ss,fo,bb,vv)
 if changed is not None:bb,vv=changed
 try:check(m,qq,ff,ss,fo,bb,vv,160,root)
 except AssertionError:results.append({'label':label,'expectedRejection':True,'actual':'ASSERTION_REJECTED'});return
 raise RuntimeError('Invalid evidence accepted: '+label)
control('MissingAllNativeExitCodes',lambda qq,ff,ss,fo,bb,vv:qq.__setitem__('actualExits',{}))
control('MissingNativeFullExit',lambda qq,ff,ss,fo,bb,vv:(qq['actualExits'].pop('full'),None)[1])
control('IncompleteNativePhase',lambda qq,ff,ss,fo,bb,vv:qq.__setitem__('phase','BUILDING'))
control('VersionObjectBytesCorrupted',lambda qq,ff,ss,fo,bb,vv:(bb,vv+b'CORRUPTED'))
control('AssuranceProvenanceDigestMismatch',lambda qq,ff,ss,fo,bb,vv:ff['provenance'].__setitem__('digest','0'*64))
control('AssuranceProvenanceFileTableMismatch',lambda qq,ff,ss,fo,bb,vv:ff['provenance']['files'].__setitem__(next(iter(ff['provenance']['files'])),'0'*64))
control('AssuranceDirtyFlagMismatch',lambda qq,ff,ss,fo,bb,vv:ff['provenance'].__setitem__('worktreeDirty',True))
control('UnsupportedWholeRequirementProofPromotion',lambda qq,ff,ss,fo,bb,vv:ff['metrics']['requirements'].update(PROVEN=1,UNPROVEN=159))
control('UnsupportedRefinementProofPromotion',lambda qq,ff,ss,fo,bb,vv:ff['metrics']['obligationsByCategory']['refinement'].update(PROVEN=1,UNPROVEN=159))
control('UnsupportedExtraSMTClaim',lambda qq,ff,ss,fo,bb,vv:ff['metrics']['obligationsByCategory']['source-derived-SMT'].__setitem__('PROVEN',5))
control('UnexpectedReleasePermission',lambda qq,ff,ss,fo,bb,vv:ff['release'].__setitem__('executionAllowed',True))
def remove_literal(qq,ff,ss,fo,bb,vv):
 vv=vv.replace(m.encode(),b'X'*len(m));assert m.encode() not in vv;fo['versionObjectSha256']=sha(vv);qq['forceDirtyIdentity']=copy.deepcopy(fo);return bb,vv
control('MissingCurrentGitLiteralDespiteConsistentRewrittenObjectHash',remove_literal)
original_root=copy.deepcopy(root)
root['actualExits'].pop('root-quality')
try:check(m,q,f,s,force,binary,version,160,root)
except AssertionError:results.append({'label':'MissingRootQualityExit','expectedRejection':True,'actual':'ASSERTION_REJECTED'})
else:raise RuntimeError('Incomplete root evidence accepted')
root=original_root
check(m,q,f,s,force,binary,version,160,root)
assert sha(Path(q['binary']).read_bytes())==sha(binary) and paths[0].read_bytes()==version
r={'sourceCommit':m,'sealScriptSha256':sha(p.read_bytes()),'method':'AST-extract actual seal binding function; valid actual receipts/artifacts accepted, one in-memory evidence corruption per negative case; do not mutate bound disk artifacts or source.','validBefore':True,'negativeControls':results,'intendedAssertionRejections':len(results),'restoredValidAfter':True,'diskArtifactsUnchanged':True,'scope':'Temporary evidence seal controls, not production source mutants or complete proof of the verification pipeline','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/'seal-binding-controls.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'validBefore':True,'negativeControlsRejected':len(results),'restoredValidAfter':True,'diskArtifactsUnchanged':True},indent=2))
