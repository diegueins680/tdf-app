from pathlib import Path
import subprocess,json,time
w=Path('/private/tmp/tdf-campaign-tab-contrast-20261030');o=Path('/private/tmp/tdf-campaign-tab-contrast-qualification-20261030');cache=Path('/private/tmp/tdf-correctness-cycle-20261028');state={'phase':'WAITING_ACTUAL_CONTROLS'}
def save():(o/'preparation-state.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,cmd):
 with (o/(label+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=w,stdout=log,stderr=subprocess.STDOUT)
 state[label+'Exit']=r.returncode;save();print(label+' actualexit '+str(r.returncode),flush=True);assert r.returncode==0,label
save()
for _ in range(120):
 if (o/'controls.json').exists():break
 time.sleep(5)
else:raise RuntimeError('No completedcontrols')
c=json.loads((o/'controls.json').read_text());assert c['actualVariants']==2 and c['actualAssertionFailures']==4
for n in ['node_modules','tdf-hq-ui/node_modules']:
 p=w/n;t=cache/n;assert p.is_symlink() and p.resolve()==t.resolve();p.unlink()
run('mobile-init',['git','submodule','update','--init','--checkout','--','tdf-mobile']);state['phase']='CANONICAL_METADATA';save();run('metadata',['python3','/private/tmp/tdf-campaign-evidence-metadata-20261030.py']);run('diff-check',['git','diff','--check'])
paths=['e2e/web/campaign-accessibility.spec.mjs','e2e/web/helpers/campaign-accessibility.mjs','formal/system/campaign-accessibility-evidence.md','formal/system/requirements.json','formal/system/inventory.json','formal/system/traceability.json','docs/catalog-persistence/reports/static-list-inventory.json','docs/catalog-persistence/reports/list-consumer-matrix.csv']
run('stage-source',['git','add','--',*paths]);run('commit-source',['git','commit','-m','test(accessibility): retain campaign contrast counterexamples'])
state['sourceCommit']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip();state['phase']='CLEAN_SOURCE_COMMITTED';save();print(state['sourceCommit'],flush=True)
