from pathlib import Path
import subprocess,os,signal,time,json,urllib.request
w=Path('/private/tmp/tdf-campaign-tab-contrast-20261030');o=Path('/private/tmp/tdf-campaign-tab-contrast-qualification-20261030');node='/Users/macpro/.nvm/versions/node/v24.13.1/bin/node';env=os.environ.copy();env['PATH']='/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin'
with (o/'preview.log').open('w') as log:
 p=subprocess.Popen([node,str(w/'node_modules/vite/bin/vite.js'),'preview','--host','127.0.0.1','--port','4189','--strictPort'],cwd=w/'tdf-hq-ui',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:
  for _ in range(100):
   assert p.poll() is None,'Own preview failed'
   try:
    with urllib.request.urlopen('http://127.0.0.1:4189/inicio',timeout=1) as r:assert r.status==200
    break
   except OSError:time.sleep(.2)
  else:raise RuntimeError('Preview startup failed')
  env['CAMPAIGN_EVIDENCE_RUN_DIR']=str(o/'corrected');(o/'corrected').mkdir(exist_ok=True)
  with (o/'corrected-browser.log').open('w') as output:r=subprocess.run([node,str(w/'node_modules/@playwright/test/cli.js'),'test','--config','/private/tmp/tdf-campaign-evidence-local.config.mjs','campaign-accessibility.spec.mjs'],cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=300)
  (o/'corrected-browser-execution.json').write_text(json.dumps({'exit':r.returncode,'source':'cd091a3c81d5ab70e175d339860fa1921ca1f0c3','previewOwnedPID':p.pid,'scope':'Synthetic network fixtures only; full contrast details; finite MacChromium sample; WebKit unsupported onmac12; not LinuxWebKit parity'},indent=2)+'\n');assert r.returncode==0
 finally:
  if p.poll() is None:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=10)
print('Probe completed; own preview stopped',flush=True)
