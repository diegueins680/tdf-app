from pathlib import Path
import json,subprocess
w=Path('/private/tmp/tdf-campaign-tab-contrast-20261030');p=w/'formal/system/campaign-accessibility-evidence.md'
p.write_text('''# Campaign accessibility counterexamples — SYS-VERIFY-CAMPAIGN-001

Authority: the owner's mission to verify the verification system and preserve
counterexamples. Hosted range PR671 run40971456580 reported a campaign contrast
failure but its projection discarded axe node/check data. The target was the unselected Creativos tab; the retained post-failure
screenshot shows it clipped while Calendario is selected. That screenshot is
not an atomic record of geometry during the asynchronous axe scan. This is an
evidence-completeness gap; it does not establish the cause of that contrast result.

Given a successful axe execution, a live page that can be inspected and writable
Playwright artifact storage, a nonempty campaign audit must attach the complete
unfiltered axe violations before the unchanged all-violations assertion fails.
Preserve node targets, checks, colors/ratio and failure summary when axe supplies
them. Record before/after observations of tab rectangles, ancestor CSS, viewport,
scroll values and fonts. Every violation and the existing WCAG2A/2AA/21AA/22AA
rule scope remain; do not add a severity filter, retry or longer deadline.

Geometry samples are observations, not a paint-readiness guard or a single atomic
snapshot covering the asynchronous axe scan. The pre-scan read can affect layout
and timing. The rectangular clip intersection is an axis-aligned CSSOM estimate,
not hit testing, compositor state, visual-viewport, iframe/shadow traversal or a
complete model of transforms, rounded/path clips and overlays. WAAPI observations
do not cover MUI requestAnimationFrame scrolling. No waiting, animation disabling,
color change, clipping exclusion or contrast-threshold relaxation is introduced.
A page/attachment failure may still abort the assertion path; it must never turn
a failing audit into a pass, and guaranteed artifacts under teardown/IO faults
are not claimed.

The original WebKit contrast cause remains UNKNOWN.25 supported-Mac Chromium
baseline scans did not reproduce it. Pinned Playwright1.59.1 WebKit cannot run
on this mac12 host; supported-browser evidence is not WebKit qualification.
Independent review found the existing opacity guards unsuitable as a drop-in
scroll predicate. Parent671's failed gate stays failed. PR673's separately fresh
hosted quality passed; its successful sample does not invalidate prior failures.

Verification obligations: actual axe and Playwright attachment controls with a
known bad-contrast element and a genuinely clipped tab; preserved full rule
results; original320/1280 campaigns; sensitivity to the old lossy projection and
missing attachment; byte restoration and source-bound execution receipts.
Finite browser tests support TESTED evidence only. No new complete proof or
claim that the original contrast failure is repaired follows.
''')
p=w/'formal/system/requirements.json';d=json.loads(p.read_text());old=json.loads(subprocess.check_output(['git','show','cd091a3c81d5ab70e175d339860fa1921ca1f0c3:formal/system/requirements.json'],cwd=w))['requirements'];assert d['requirements']==old;identity='SYS-VERIFY-CAMPAIGN-001'
r={'id':identity,'title':'Retain campaign accessibility counterexample evidence','statement':'When a campaign axe audit returns violations on an inspectable page with writable artifact storage, attach the complete unfiltered violations and before/after tab observations before the unchanged all-violations assertion fails.','domain':'SYS','authority':'Owner mission sections2,6,7,8 require credible counterexamples and independently checked verification; hosted671 stripped the diagnostic fields needed to investigate a real failure.','source':'formal/system/campaign-accessibility-evidence.md','contract':'formal/system/campaign-accessibility-evidence.md','property':'Preserve all axe violation/node/check fields and rule scope; include observational tab/ancestor/viewport/scroll data. Never heal a failing audit, add retries or infer root cause from readiness assumptions.','actors':['CI reviewer','Verification engineer'],'preconditions':['Successful axe execution','Live inspectable page and writable Playwright artifact storage'],'inputs':['All campaign axe violations','Before/after tab geometry and computed ancestor styles'],'state':{'initial':'Campaign audit result','terminal':['Existing empty audit passes','Full evidence attached and existing nonempty assertion fails','Diagnostic IO/page failure remains a failure']},'allowedTransitions':['Attach unfiltered structured counterexamples','Record observational geometry without deciding readiness'],'forbiddenTransitions':['Discard axe colors/ratio/checks from the only structured failure record','Filter severity or relax the empty-violations assertion','Treat sampled geometry or successful rerun as proof of the original WebKit cause'],'effects':['Local synthetic browser artifacts only'],'authorization':'No production writes, provider calls, new permissions or integration-control changes.','privacy':'Synthetic campaign network fixtures and test DOM only.','concurrency':'Before and after are distinct CSSOM samples; no atomic snapshot across asynchronous axe or RAF scrolling is claimed.','idempotency':'No new retry or external effect; original assertion semantics retained.','failure':'Nonempty audits remain failures; diagnostic/page/storage errors are not converted into passes.','recovery':'Use full source-bound evidence to investigate the original unknown cause; preserve failed CI.','observability':'Actual Playwright JSON attachment with full violations plus tab/ancestor/scroll observations.','implementation':['e2e/web/helpers/campaign-accessibility.mjs'],'tests':['e2e/web/campaign-accessibility.spec.mjs'],'formalModels':[],'verification':'Actual supported-browser control cases and loss/attachment fault sensitivity; per-source execution receipts separate.','evidence':'formal/system/campaign-accessibility-evidence.md; reports/campaign-accessibility-evidence-2026-10-30.json','critical':False,'status':'specified and implemented','confidence':'Confirmed original information loss; original WebKit contrast cause remains unknown.','ambiguity':['Rectangular CSSOM clips are not complete visible-pixel or compositor evidence.','Pinned WebKit is unsupported on localmac12; hosted current-head verification remains separate.'],'conformance':{'classification':'PARTIAL','reason':'Finite browser counterexample-retention tests; original contrast cause and complete verification-pipeline refinement are not proven.'}}
d['requirements'].append(r);p.write_text(json.dumps(d,indent=2)+'\n');assert len(d['requirements'])==158;print('158requirements; all157incoming objects exact')
