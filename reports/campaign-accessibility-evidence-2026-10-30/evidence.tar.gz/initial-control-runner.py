from pathlib import Path
import subprocess,os,signal,time,json,urllib.request,hashlib,re
w=Path('/private/tmp/tdf-campaign-tab-contrast-20261030');o=Path('/private/tmp/tdf-campaign-tab-contrast-qualification-20261030');node='/Users/macpro/.nvm/versions/node/v24.13.1/bin/node';env=os.environ.copy();env['PATH']='/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin';source=w/'e2e/web/helpers/campaign-accessibility.mjs';original=source.read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest();results=[]
old=subprocess.check_output(['git','show','cd091a3c81d5ab70e175d339860fa1921ca1f0c3:e2e/web/campaign-accessibility.spec.mjs'],cwd=w,text=True);projection='({ id, nodes }) => ({ id, targets: nodes.map(({ target }) => target) })';assert projection in old
with (o/'controls-preview.log').open('w') as log:
 p=subprocess.Popen([node,str(w/'node_modules/vite/bin/vite.js'),'preview','--host','127.0.0.1','--port','4189','--strictPort'],cwd=w/'tdf-hq-ui',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 def run(label,expected,grep):
  out=o/label;out.mkdir();env['CAMPAIGN_EVIDENCE_RUN_DIR']=str(out)
  with (o/(label+'.log')).open('w') as output:r=subprocess.run([node,str(w/'node_modules/@playwright/test/cli.js'),'test','--config','/private/tmp/tdf-campaign-evidence-local.config.mjs','campaign-accessibility.spec.mjs','--grep',grep],cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=300)
  data=json.loads((out/'results.json').read_text());stats=data['stats'];assert stats['unexpected']==expected and stats['expected']==(6 if expected==0 else 0) and stats['flaky']==0 and stats['skipped']==0,stats;assert r.returncode==(1 if expected else 0)
  raw=(o/(label+'.log')).read_text();assert expected==0 or ('toEqual' in raw and 'TypeError' not in raw and 'TimeoutError' not in raw),raw[-1500:]
  results.append({'label':label,'sourceSha256':sha(source.read_bytes()),'actualExit':r.returncode,'stats':stats,'logSha256':sha(raw.encode())});(o/'controls-progress.json').write_text(json.dumps({'results':results},indent=2)+'\n');print(label+' actualexit '+str(r.returncode)+' expectedfailures '+str(expected),flush=True)
 try:
  for _ in range(100):
   assert p.poll() is None
   try:
    with urllib.request.urlopen('http://127.0.0.1:4189/inicio',timeout=1) as r:assert r.status==200
    break
   except OSError:time.sleep(.2)
  else:raise RuntimeError('Preview failed')
  s=original.decode();needle='{ tab, violations, before, after }';assert s.count(needle)==1;source.write_text(s.replace(needle,'{ tab, violations: violations.map('+projection+'), before, after }'));run('lossy-original-projection',2,'diagnostics retain')
  s=original.decode();needle='  if (violations.length === 0) return;';assert s.count(needle)==1;source.write_text(s.replace(needle,'  return;'));run('suppressed-evidence',2,'diagnostics retain')
 finally:
  source.write_bytes(original)
  if p.poll() is None:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=10)
assert source.read_bytes()==original
(o/'controls.json').write_text(json.dumps({'results':results,'actualVariants':2,'actualAssertionFailures':4,'sourceRestoredSha256':sha(original),'originalProjectionVerifiedAgainstGit':True,'limit':'Evidence-retention fault controls, not proof of the original WebKit contrast rootcause.'},indent=2)+'\n')
