import {createRequire} from 'node:module';
const require=createRequire('/private/tmp/tdf-correctness-cycle-20261028/package.json');
const {defineConfig,devices}=require('@playwright/test');
const out=process.env.CAMPAIGN_EVIDENCE_RUN_DIR;
export default defineConfig({testDir:'/private/tmp/tdf-campaign-tab-contrast-20261030/e2e/web',captureGitInfo:{diff:false},fullyParallel:false,retries:0,workers:1,timeout:30000,expect:{timeout:8000},outputDir:out+'/test-results',reporter:[['line'],['json',{outputFile:out+'/results.json'}]],use:{baseURL:'http://127.0.0.1:4189',locale:'es-EC',timezoneId:'America/Guayaquil',colorScheme:'dark',reducedMotion:'reduce',trace:'retain-on-failure',screenshot:'only-on-failure'},projects:[{name:'chromium-desktop',use:{...devices['Desktop Chrome']}},{name:'firefox-critical',use:{...devices['Desktop Firefox']}}]});
