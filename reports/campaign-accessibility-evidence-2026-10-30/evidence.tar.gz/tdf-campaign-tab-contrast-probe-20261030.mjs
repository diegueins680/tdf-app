import fs from 'node:fs';
import {createRequire} from 'node:module';
const require=createRequire('/private/tmp/tdf-correctness-cycle-20261028/package.json');
const {webkit,chromium,devices}=require('@playwright/test');const axe=require('axe-core');
const out='/private/tmp/tdf-campaign-tab-contrast-qualification-20261030';
const browser=await chromium.launch({headless:true});const results=[];
try {
 for(let run=0;run<5;run++){
 const context=await browser.newContext({...devices['Desktop Chrome'],deviceScaleFactor:2,viewport:{width:320,height:900},locale:'es-EC',timezoneId:'America/Guayaquil',colorScheme:'dark',reducedMotion:'reduce',serviceWorkers:'block'});
 const page=await context.newPage();const origin='http://127.0.0.1:4189';
 await page.route('**/*',async route=>{
 const req=route.request();const url=new URL(req.url());
 if(!['fetch','xhr'].includes(req.resourceType()))return url.origin===origin?route.continue():route.abort('blockedbyclient');
 const path=url.pathname.replace(/^\/api(?=\/)/,'');const preferences={locale:'es',currency:'USD',timezone:'America/Guayaquil'};
 if(path==='/session')return route.fulfill({json:{username:'campaign-audit',displayName:'Operador sintético',partyId:42,roles:['Admin'],modules:['scheduling'],featureFlags:[],preferences}});
 if(path==='/session/preferences')return route.fulfill({json:preferences});if(path==='/health')return route.fulfill({json:{status:'ok',db:'ok'}});
 if(path.startsWith('/catalogs/'))return route.fulfill({json:{catalogs:[],items:[]}});return route.fulfill({json:[]});
 });
 await page.goto(origin+'/estudio/campanas/tdf-sessions-domo');
 for(const tab of ['Control','Calendario','Creativos','Bandas','Copys']){
 await page.getByRole('tab',{name:tab,exact:true}).click();
 if(tab==='Calendario')await page.getByRole('progressbar',{name:'Avance del calendario de campaña'}).waitFor({state:'visible'});
 if(tab==='Creativos')await page.getByRole('progressbar',{name:'Videos de campaña publicados'}).waitFor({state:'visible'});
 await page.addScriptTag({content:axe.source});
 const data=await page.evaluate(async()=>{
 const snapshot=()=>Array.from(document.querySelectorAll('[role=tab]')).map(e=>{const s=getComputedStyle(e),r=e.getBoundingClientRect();return{text:e.textContent,color:s.color,background:s.backgroundColor,opacity:s.opacity,rect:{x:r.x,y:r.y,width:r.width,height:r.height},scrollLeft:e.parentElement.parentElement.scrollLeft,animations:e.getAnimations({subtree:true}).map(a=>({playState:a.playState,currentTime:a.currentTime}))}});
 const before=snapshot();const result=await globalThis.axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa','wcag22aa']}});
 return {before,after:snapshot(),violations:result.violations.map(v=>({id:v.id,nodes:v.nodes.map(n=>({target:n.target,html:n.html,any:n.any,all:n.all,none:n.none,failureSummary:n.failureSummary}))})),incomplete:result.incomplete.filter(v=>v.id==='color-contrast').map(v=>({id:v.id,nodes:v.nodes.map(n=>({target:n.target,any:n.any}))}))};
 });
 results.push({run,tab,...data});fs.writeFileSync(out+'/baseline-browser-observations.json',JSON.stringify({source:'cd091a3c81d5ab70e175d339860fa1921ca1f0c3',browser:browser.version(),results},null,2));console.log(JSON.stringify({run,tab,violations:data.violations.map(v=>({id:v.id,nodes:v.nodes.map(n=>({target:n.target,checks:n.any.map(x=>x.data)}))}))}));
 }
 await context.close();
 }
}finally{await browser.close();}
