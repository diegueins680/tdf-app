from pathlib import Path
import json,subprocess,hashlib
w=Path('/private/tmp/tdf-campaign-tab-contrast-20261030');o=Path('/private/tmp/tdf-campaign-tab-contrast-qualification-20261030');base='cd091a3c81d5ab70e175d339860fa1921ca1f0c3';m=json.loads((o/'preparation-state.json').read_text())['sourceCommit'];sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=w):return subprocess.check_output(['git',*a],cwd=cwd)
assert git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip()
v=json.loads((o/'verification-state.json').read_text());assert v['phase']=='ALL_LOCAL_CHECKS_PASSED' and all(x==0 for x in v['actualExits'].values())
q=json.loads((o/'qualified/results.json').read_text());assert q['stats']['expected']==6 and q['stats']['unexpected']==q['stats']['skipped']==q['stats']['flaky']==0
cases=[]
def walk(x):
 if isinstance(x,dict):
  if 'projectName' in x and 'results' in x:cases.append({'project':x['projectName'],'results':[(r['status'],r['retry']) for r in x['results']]})
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
walk(q);assert len(cases)==6 and all(c['results']==[('passed',0)] for c in cases)
attachments=[]
import base64
encoded=[]
def collect_attachments(x):
 if isinstance(x,dict):
  for attachment in x.get('attachments',[]):
   if attachment.get('name')=='campaign-accessibility-negative-control':encoded.append(attachment)
  for value in x.values():collect_attachments(value)
 elif isinstance(x,list):
  for value in x:collect_attachments(value)
collect_attachments(q)
for index,attachment in enumerate(encoded):
 assert attachment['contentType']=='application/json'
 raw=base64.b64decode(attachment['body'],validate=True);d=json.loads(raw);assert d['tab']=='negative-control'
 c=next(x for x in d['violations'] if x['id']=='color-contrast');node=next(x for x in c['nodes'] if '#contrast-control' in x['target']);data=next(x for x in node['any'] if x['id']=='color-contrast')['data'];assert data['contrastRatio']<4.5 and data['fgColor'] and data['bgColor'] and node['failureSummary'];assert all(next(t for t in sample['tabs'] if t['text']=='Creativos')['clipIntersection']['width']==0 for sample in [d['before'],d['after']])
 path=o/('qualified-decoded-attachment-'+str(index)+'.json');path.write_bytes(raw)
 attachments.append({'path':str(path.relative_to(o)),'sha256':sha(raw),'contrastData':data,'binding':'Exact decoded base64 body from real qualified Playwright results.json, not a standalone reporter attachment file.'})
assert len(attachments)==2
controls=json.loads((o/'controls.json').read_text());assert controls['actualVariants']==2 and controls['actualAssertionFailures']==4
helper='e2e/web/helpers/campaign-accessibility.mjs';assert sha((w/helper).read_bytes())==controls['sourceRestoredSha256']==sha(git('show',m+':'+helper))
source=json.loads((o/'assurance-committed/sources.json').read_text());formal=json.loads((o/'assurance-committed/report.json').read_text());assert source['revision']==formal['provenance']['revision']==m and not source['worktreeDirty'] and formal['execution']['passed'];assert source['digest']==sha(json.dumps(source['files'],sort_keys=True).encode())
mobile=git('rev-parse',m+':tdf-mobile').decode().strip();assert git('rev-parse','HEAD',cwd=w/'tdf-mobile').decode().strip()==mobile
for isMobile in [False,True]:
 pairs=[(p,h) for p,h in source['files'].items() if p.startswith('tdf-mobile/')==isMobile];cwd=w/'tdf-mobile' if isMobile else w;rev=mobile if isMobile else m;args=[rev+':'+(p.removeprefix('tdf-mobile/') if isMobile else p) for p,h in pairs];assert all('\n' not in x for x in args);raw=subprocess.check_output(['git','cat-file','--batch'],cwd=cwd,input=('\n'.join(args)+'\n').encode());pos=0
 for p,h in pairs:
  e=raw.index(b'\n',pos);header=raw[pos:e].split();assert header[1]==b'blob';n=int(header[2]);assert sha(raw[e+1:e+1+n])==h==sha((w/p).read_bytes()),p;pos=e+1+n+1
 assert pos==len(raw)
old=json.loads(git('show',base+':formal/system/requirements.json'))['requirements'];new=json.loads((w/'formal/system/requirements.json').read_text())['requirements'];by={x['id']:x for x in new};assert len(new)==len(old)+1==158 and all(by[x['id']]==x for x in old)
for path in ['tdf-hq-ui','tdf-hq','tdf-mobile']:assert git('rev-parse',m+':'+path)==git('rev-parse',base+':'+path)
p='docs/catalog-persistence/catalog-list-decisions.json';assert (w/p).read_bytes()==git('show',base+':'+p)
p='formal/system/campaign-accessibility-evidence.md';assert (w/p).read_bytes()==git('show',m+':'+p)
old=git('show',base+':e2e/web/campaign-accessibility.spec.mjs').decode();new=(w/'e2e/web/campaign-accessibility.spec.mjs').read_text();part=new[:new.index('\n// Exercise the real axe')];part=part.replace("import { readFile } from 'node:fs/promises';\n",'').replace("import { inspectCampaignTabs, recordCampaignAccessibilityFailure } from './helpers/campaign-accessibility.mjs';\n",'').replace('async ({ page, baseURL }, testInfo) => {','async ({ page, baseURL }) => {')
a=part.index('      const before = await page.evaluate(inspectCampaignTabs);');b=part.index('      expect(violations, tab).toEqual([]);',a);oa=old.index('      const violations = await page.evaluate');ob=old.index('      expect(violations, tab).toEqual([]);',oa);part=part[:a]+old[oa:ob]+part[b:];assert part==old,'Existing campaign source beyond declared capture changes differs'
d={'sourceCommit':m,'baseline':base,'registeredGitFilesystemMobileHashes':len(source['files']),'sourceDigest':source['digest'],'all157IncomingRequirementsExact':True,'wholeUIBackendMobileTreesExactBaseline':True,'historicalCatalogWholeFileExactBaseline':True,'existingCampaignSourceExactExceptDeclaredEvidenceCapture':True,'newContractGitSha256':sha((w/p).read_bytes()),'helperSourceRestoredSha256':controls['sourceRestoredSha256'],'browserMatrix':cases,'qualifiedBrowserStats':q['stats'],'actualAttachments':attachments,'realFaultVariants':2,'intendedAssertionFailures':4,'rootQuality':json.loads((o/'root-quality-result.json').read_text()),'freshAssuranceMetrics':formal['metrics'],'formalRelease':formal['release']['decision'],'newCompleteProofs':0,'sourceCleanAfter':True,'limits':['Original WebKit cause UNKNOWN and not repaired.','Local pinned WebKit unsupportedmac12; only Chromium/Firefox executed.','CompiledUI baselineCD component reused; no runtimeUI/backend/Mobile changes.','Before/after CSSOM observations are not paint or atomic scan-time proofs.']};(o/'source-correspondence.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k in ['sourceCommit','registeredGitFilesystemMobileHashes','qualifiedBrowserStats','formalRelease']},indent=2))
