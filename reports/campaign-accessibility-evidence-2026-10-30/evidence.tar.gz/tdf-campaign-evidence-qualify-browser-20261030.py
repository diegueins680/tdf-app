from pathlib import Path
import subprocess,os,signal,time,json,urllib.request
w=Path('/private/tmp/tdf-campaign-tab-contrast-20261030');o=Path('/private/tmp/tdf-campaign-tab-contrast-qualification-20261030');node='/Users/macpro/.nvm/versions/node/v24.13.1/bin/node';env=os.environ.copy();env['PATH']='/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin'
cache=Path('/private/tmp/tdf-correctness-cycle-20261028');made=[]
for n in ['node_modules','tdf-hq-ui/node_modules']:
 target=w/n;assert not target.exists();target.symlink_to(cache/n,target_is_directory=True);made.append((target,cache/n))
with (o/'qualified-preview.log').open('w') as log:
 p=subprocess.Popen([node,str(w/'node_modules/vite/bin/vite.js'),'preview','--host','127.0.0.1','--port','4189','--strictPort'],cwd=w/'tdf-hq-ui',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:
  for _ in range(100):
   assert p.poll() is None,'Own preview failed'
   try:
    with urllib.request.urlopen('http://127.0.0.1:4189/inicio',timeout=1) as r:assert r.status==200
    break
   except OSError:time.sleep(.2)
  else:raise RuntimeError('Preview startup failed')
  env['CAMPAIGN_EVIDENCE_RUN_DIR']=str(o/'qualified');(o/'qualified').mkdir(exist_ok=True)
  with (o/'qualified-browser.log').open('w') as output:r=subprocess.run([node,str(w/'node_modules/@playwright/test/cli.js'),'test','--config','/private/tmp/tdf-campaign-evidence-local.config.mjs','campaign-accessibility.spec.mjs'],cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=300)
  (o/'qualified-browser-execution.json').write_text(json.dumps({'exit':r.returncode,'source':json.loads((o/'preparation-state.json').read_text())['sourceCommit'],'previewOwnedPID':p.pid,'scope':'Six actual Chromium/Firefox cases on sourceM tests; exact mainCD UI component build reused; WebKit unsupported onmac12 and not claimed. Temporaryowneddependenciesaliases removed.'},indent=2)+'\n');assert r.returncode==0
 finally:
  if p.poll() is None:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=10)
  for target,expected in reversed(made):assert target.is_symlink() and target.resolve()==expected.resolve();target.unlink()
print('Probe completed; own preview stopped',flush=True)
