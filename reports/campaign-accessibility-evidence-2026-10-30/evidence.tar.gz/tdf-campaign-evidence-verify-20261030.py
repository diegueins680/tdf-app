from pathlib import Path
import subprocess,os,json,time
w=Path('/private/tmp/tdf-campaign-tab-contrast-20261030');o=Path('/private/tmp/tdf-campaign-tab-contrast-qualification-20261030');env=os.environ.copy();env['PATH']='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/Users/macpro/.ghcup/bin:/usr/local/bin:/usr/bin:/bin'
for _ in range(240):
 state=json.loads((o/'preparation-state.json').read_text())
 if state['phase']=='CLEAN_SOURCE_COMMITTED':break
 time.sleep(5)
else:raise RuntimeError('No committed source')
state={'sourceCommit':state['sourceCommit'],'actualExits':{},'phase':'ROOT_QUALITY'}
def save():(o/'verification-state.json').write_text(json.dumps(state,indent=2)+'\n')
save()
for label,cmd in [('root-quality',['python3','/private/tmp/tdf-campaign-evidence-root-quality-20261030.py']),('assurance',['python3','scripts/verification-report.py','--output',str(o/'assurance-committed')]),('browser',['python3','/private/tmp/tdf-campaign-evidence-qualify-browser-20261030.py'])]:
 state['phase']=label;save()
 with (o/(label+'-driver.log')).open('w') as log:r=subprocess.run(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT)
 state['actualExits'][label]=r.returncode;save();print(label+' actualexit '+str(r.returncode),flush=True);assert r.returncode==0,label
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip();state['phase']='ALL_LOCAL_CHECKS_PASSED';save()
