# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: campaign-accessibility.spec.mjs >> Campaign diagnostics retain contrast counterexamples and clipped-tab geometry @critical
- Location: e2e/web/campaign-accessibility.spec.mjs:80:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

Expected: Any<Array>
Received: undefined
```

# Page snapshot

```yaml
- main [ref=e2]:
  - paragraph [ref=e3]: Known bad contrast
  - tablist "Campaign control" [ref=e5]:
    - tab "Control" [selected] [ref=e6]
    - tab "Creativos" [ref=e7]
```

# Test source

```ts
  6   | // The campaign tracker is local-only. Shell responses are synthetic; no campaigns,
  7   | // invitations, budgets or provider settings are changed by this regression.
  8   | for (const width of [320, 1280]) {
  9   |   test(`Campaign controls expose row and column names at ${width}px @critical`, async ({ page, baseURL }, testInfo) => {
  10  |     await page.setViewportSize({ width, height: 900 });
  11  |     const origin = new URL(baseURL).origin;
  12  |     await page.route('**/*', async (route) => {
  13  |       const request = route.request();
  14  |       const url = new URL(request.url());
  15  |       if (!['fetch', 'xhr'].includes(request.resourceType())) {
  16  |         return url.origin === origin ? route.continue() : route.abort('blockedbyclient');
  17  |       }
  18  |       const path = url.pathname.replace(/^\/api(?=\/)/, '');
  19  |       const preferences = { locale: 'es', currency: 'USD', timezone: 'America/Guayaquil' };
  20  |       if (path === '/session') return route.fulfill({ json: {
  21  |         username: 'campaign-audit', displayName: 'Operador sintético', partyId: 42,
  22  |         roles: ['Admin'], modules: ['scheduling'], featureFlags: [], preferences,
  23  |       } });
  24  |       if (path === '/session/preferences') return route.fulfill({ json: preferences });
  25  |       if (path === '/health') return route.fulfill({ json: { status: 'ok', db: 'ok' } });
  26  |       if (path.startsWith('/catalogs/')) return route.fulfill({ json: { catalogs: [], items: [] } });
  27  |       return route.fulfill({ json: [] });
  28  |     });
  29  |     await page.goto('/estudio/campanas/tdf-sessions-domo');
  30  |     for (const tab of ['Control', 'Calendario', 'Creativos', 'Bandas', 'Copys']) {
  31  |       await page.getByRole('tab', { name: tab, exact: true }).click();
  32  |       if (tab === 'Calendario') {
  33  |         await expect(page.getByRole('progressbar', { name: 'Avance del calendario de campaña' })).toBeVisible();
  34  |       }
  35  |       if (tab === 'Creativos') {
  36  |         await expect(page.getByRole('progressbar', { name: 'Videos de campaña publicados' })).toBeVisible();
  37  |         const region = page.getByRole('region', { name: 'Seguimiento de creativos', exact: true });
  38  |         const rows = region.getByRole('row');
  39  |         expect(await rows.count()).toBeGreaterThan(1);
  40  |         for (const row of await rows.all()) {
  41  |           const status = row.getByRole('combobox');
  42  |           if (!(await status.count())) continue;
  43  |           const label = (await row.locator('[id$="-label"]').innerText()).replace(/\s+/g, ' ').trim();
  44  |           await expect(status).toHaveAccessibleName(`${label} Estado ${await status.innerText()}`);
  45  |           await expect(row.getByRole('textbox')).toHaveAccessibleName(`${label} Notas`);
  46  |         }
  47  |         await region.focus();
  48  |         await page.keyboard.press('Tab');
  49  |         await expect(region.getByRole('combobox').first()).toBeFocused();
  50  |         const focusIsVisible = () => page.evaluate(() => {
  51  |           const element = document.activeElement;
  52  |           const bounds = element.getBoundingClientRect();
  53  |           const hit = document.elementFromPoint(bounds.x + bounds.width / 2, bounds.y + bounds.height / 2);
  54  |           return hit === element || element.contains(hit);
  55  |         });
  56  |         await expect.poll(focusIsVisible).toBe(true);
  57  |         await page.keyboard.press('Enter');
  58  |         await expect(page.getByRole('listbox')).toBeVisible();
  59  |         await page.keyboard.press('Escape');
  60  |         await expect(region.getByRole('combobox').first()).toBeFocused();
  61  |         await page.keyboard.press('Tab');
  62  |         await expect(region.getByRole('textbox').first()).toBeFocused();
  63  |         await expect.poll(focusIsVisible).toBe(true);
  64  |       }
  65  |       await page.addScriptTag({ content: axe.source });
  66  |       const before = await page.evaluate(inspectCampaignTabs);
  67  |       const fullViolations = await page.evaluate(async () => (await globalThis.axe.run(document, {
  68  |         runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa'] },
  69  |       })).violations);
  70  |       await recordCampaignAccessibilityFailure(page, testInfo, tab, fullViolations, before);
  71  |       const violations = fullViolations.map(({ id, nodes }) => ({ id, targets: nodes.map(({ target }) => target) }));
  72  |       expect(violations, tab).toEqual([]);
  73  |       expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), tab).toBe(true);
  74  |     }
  75  |   });
  76  | }
  77  | 
  78  | // Exercise the real axe engine and Playwright attachment, including an actually
  79  | // clipped unselected tab. This control does not assert a cause for hosted WebKit.
  80  | test('Campaign diagnostics retain contrast counterexamples and clipped-tab geometry @critical', async ({ page }, testInfo) => {
  81  |   await page.setViewportSize({ width: 320, height: 900 });
  82  |   await page.setContent(`<!doctype html><html lang="es"><head><title>Campaign evidence control</title>
  83  |     <style>body { background: white; color: black; }
  84  |     .scroller { width: 120px; overflow: hidden; }
  85  |     [role=tablist] { display: flex; width: max-content; }
  86  |     [role=tab] { width: 200px; flex-shrink: 0; height: 40px; }
  87  |     #contrast-control { color: #eee; font-size: 16px; }</style></head>
  88  |     <body><main><p id="contrast-control">Known bad contrast</p>
  89  |     <div class="scroller"><div role="tablist" aria-label="Campaign control">
  90  |     <button role="tab" aria-selected="true">Control</button>
  91  |     <button role="tab" aria-selected="false">Creativos</button>
  92  |     </div></div></main></body></html>`);
  93  |   await page.addScriptTag({ content: axe.source });
  94  |   const before = await page.evaluate(inspectCampaignTabs);
  95  |   const violations = await page.evaluate(async () => (await globalThis.axe.run(document, {
  96  |     runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa'] },
  97  |   })).violations);
  98  |   expect(violations.some(({ id }) => id === 'color-contrast')).toBe(true);
  99  |   const attachmentCount = testInfo.attachments.length;
  100 |   await recordCampaignAccessibilityFailure(page, testInfo, 'negative-control', violations, before);
  101 |   expect(testInfo.attachments.length).toBe(attachmentCount + 1);
  102 |   const attachment = testInfo.attachments.at(-1);
  103 |   expect(attachment.contentType).toBe('application/json');
  104 |   const evidence = JSON.parse(attachment.body?.toString() ?? await readFile(attachment.path, 'utf8'));
  105 |   const contrast = evidence.violations.find(({ id }) => id === 'color-contrast');
> 106 |   expect(contrast.nodes).toEqual(expect.any(Array));
      |                          ^ Error: expect(received).toEqual(expected) // deep equality
  107 |   const node = contrast.nodes.find(({ target }) => target.includes('#contrast-control'));
  108 |   expect(node).toMatchObject({ any: expect.any(Array), failureSummary: expect.any(String) });
  109 |   const check = node.any.find(({ id }) => id === 'color-contrast');
  110 |   expect(check.data.contrastRatio).toBeLessThan(4.5);
  111 |   expect(check.data.fgColor).toBeTruthy();
  112 |   expect(check.data.bgColor).toBeTruthy();
  113 |   expect(node.failureSummary).toContain('contrast');
  114 |   expect(evidence.violations).toEqual(violations);
  115 |   for (const sample of [evidence.before, evidence.after]) {
  116 |     const clipped = sample.tabs.find(({ text }) => text === 'Creativos');
  117 |     expect(clipped.selected).toBe('false');
  118 |     expect(clipped.bounds.width).toBeGreaterThan(0);
  119 |     expect(clipped.clipIntersection.width).toBe(0);
  120 |     expect(clipped.ancestors.some(({ overflowX }) => overflowX === 'hidden')).toBe(true);
  121 |     expect(clipped.ancestors[0].color).toBeTruthy();
  122 |     expect(sample.sampledAt).toBeGreaterThan(0);
  123 |   }
  124 | });
  125 | 
```