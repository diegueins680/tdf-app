from pathlib import Path
import os,subprocess,json,hashlib,datetime
w=Path('/private/tmp/tdf-browser-precision-main643-20261030T2302');o=Path('/private/tmp/tdf-browser-precision-main643-qualification-20261030T2302');main='234ff6f7faf1aecf347c8e92a374228f4ec07aaa';old='ec7b43b9cf4c34144e5a7176e454a56f20ee73bb';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=w)
def blob(ref,path):return git('show',ref+':'+path)
md=json.loads((o/'metadata-results.json').read_text());assert md['ownedAliasRemoved'] and len(md['actualExits'])==7 and all(x==0 for x in md['actualExits'].values())
assert git('rev-parse','HEAD').decode().strip()==old and git('rev-parse','MERGE_HEAD').decode().strip()==main and not git('diff','--name-only','--diff-filter=U').strip()
req=json.loads((w/'formal/system/requirements.json').read_text())['requirements'];prev=json.loads(blob(main,'formal/system/requirements.json'))['requirements'];by={x['id']:x for x in req};assert len(req)==len(by)==160 and len(prev)==159 and all(by[x['id']]==x for x in prev)
assert by['UI-EVENT-FINANCE-PRECISION-001']=={x['id']:x for x in json.loads(blob(old,'formal/system/requirements.json'))['requirements']}['UI-EVENT-FINANCE-PRECISION-001']
cat=json.loads((w/'docs/catalog-persistence/reports/static-list-inventory.json').read_text());assert cat['candidateCount']==1355 and all(x['decision']!='unreviewed' for x in cat['candidates'])
assert (w/'docs/catalog-persistence/catalog-list-decisions.json').read_bytes()==blob(old,'docs/catalog-persistence/catalog-list-decisions.json')==blob(main,'docs/catalog-persistence/catalog-list-decisions.json')
paths=['formal/system/requirements.json','formal/system/inventory.json','formal/system/traceability.json','docs/catalog-persistence/reports/static-list-inventory.json','docs/catalog-persistence/reports/list-consumer-matrix.csv']
subprocess.run(['git','diff','--check'],cwd=w,check=True);subprocess.run(['git','add',*paths],cwd=w,check=True)
with(o/'source-commit.log').open('w') as f:r=subprocess.run(['git','commit','-m','Merge protected checkout-verifier main into browser finance precision'],cwd=w,stdout=f,stderr=subprocess.STDOUT)
assert r.returncode==0
m=git('rev-parse','HEAD').decode().strip();assert git('show','-s','--format=%P',m).decode().split()==[old,main] and not git('status','--porcelain').strip()
for path in ['tdf-hq-ui','tdf-mobile','package.json','package-lock.json']:assert git('rev-parse',m+':'+path)==git('rev-parse',old+':'+path),path
for path in ['tdf-hq','.github','scripts','ops','tdf-mobile','package.json','package-lock.json']:assert git('rev-parse',m+':'+path)==git('rev-parse',main+':'+path),path
# Incoming main adds its own historical report/evidence. No existing old-parent report/evidence may change or disappear.
for root in ['reports','formal/system/evidence']:
 for change in git('diff','--name-status','--no-renames',old,m,'--',root).decode().splitlines():assert change.startswith('A\t'),change
own_paths=git('ls-tree','-r','-z','--name-only',old,'--','reports/event-finance-browser-precision-2026-10-30.json','reports/event-finance-browser-precision-2026-10-30').decode().strip('\0').split('\0');assert len(own_paths)==4
bindings={path:sha(blob(old,path)) for path in own_paths}
for path,h in bindings.items():assert sha(blob(m,path))==h==sha((w/path).read_bytes()),path
tree_paths=set(git('ls-tree','-r','-z','--name-only',old,'--','formal/system').decode().strip('\0').split('\0'))
for path in ['formal/system/event-finance-browser-precision.md','formal/system/auth-predicates.json','formal/system/recovery-expiry-arithmetic.json']:
 if path in tree_paths:assert blob(m,path)==blob(old,path),path
checks={};env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','LANG','LC_ALL']};env.update(PATH='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1')
for label,cmd in [('inventory-check',['python3','scripts/specification-inventory.py','--check']),('conformance-check',['python3','scripts/specification-conformance.py','--check']),('source-admission',['python3','scripts/check-new-specification-surfaces.py','--base',main,'--head',m]),('source-ci-selection',['node','scripts/ci-change-scope.mjs','--base',main,'--head',m])]:
 with(o/('committed-'+label+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600)
 checks[label]=r.returncode;print(label+' actualexit '+str(r.returncode),flush=True);assert r.returncode==0,label
assert not git('status','--porcelain').strip()
changed=git('diff','--name-only','-z',main,m).decode().strip('\0').split('\0');backend=git('rev-parse',m+':tdf-hq').decode().strip()
state=json.loads((o/'preparation-state.json').read_text());state.update(phase='CLEAN_CURRENT_MAIN_SOURCE_PREPARED',sourceCommit=m,parents=[old,main],parentHead=old,mainSha=main,metadataResults=md,committedChecks=checks,all159MainNormativeObjectsExactPlusUnchangedPrecision160=True,allUiDependenciesMobileExactEC7=True,allBackendScriptsWorkflowsOpsDependenciesExactMain=True,allOldHistoricalReportsAndEvidencePreserved=True,parentFourReportBlobsSha256=bindings,strictCatalogCandidates=1355,wholeBackendGitTree=backend,changedFilesVersusMain=changed,sourceCleanAfter=True,fullUiCurrentSource='NOT_RUN; Root fresh scoped qualification and current-head hosted full UI CI remain required',historicalFullUi={'sourceCommit':'83533b3d980432aea6bab30361453311da4f3905','tests':3811,'suites':327,'scope':'Original parent source only; not current main composition execution'},completedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat());(o/'preparation-state.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps({k:state[k] for k in ['sourceCommit','parents','mainSha','committedChecks','strictCatalogCandidates','sourceCleanAfter']}),flush=True)
