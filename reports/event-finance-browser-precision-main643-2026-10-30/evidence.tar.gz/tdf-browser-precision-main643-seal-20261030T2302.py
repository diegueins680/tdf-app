from pathlib import Path
import json,subprocess,hashlib,datetime,csv
w=Path('/private/tmp/tdf-browser-precision-main643-20261030T2302');o=Path('/private/tmp/tdf-browser-precision-main643-qualification-20261030T2302');sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=w):return subprocess.check_output(['git',*a],cwd=cwd)
def verify_ui_bindings(m,q,f,s,inputs,expected,actual):
 assert q['sourceCommit']==f['provenance']['revision']==s['revision']==inputs['sourceCommit']==m
 assert set(q['actualExits'])=={'targeted','typecheck','lint','build','root-quality','source-admission','catalog-unit'}
 assert all(v==0 for v in q['actualExits'].values()) and q['phase']=='QUALIFIED_CURRENT_MAIN_UI_SOURCE'
 assert q['targetedTests']==76 and q['targetedSuites']==4 and q['fullUiCurrentSource']=='NOT_RUN_LOCAL; selected hosted UI quality remains required'
 assert q['allInputsGitExactAndUnchanged'] and q['aliasesRemoved'] and q['sourceCleanAfter']
 for k in ['files','digest','revision','mobileGitlink','worktreeDirty']:assert f['provenance'][k]==s[k],k
 assert not s['worktreeDirty'] and s['digest']==sha(json.dumps(s['files'],sort_keys=True).encode())
 expected_counts={'PROVEN':0,'REFUTED':0,'UNPROVEN':160,'NOT_APPLICABLE':0}
 assert f['metrics']['requirements']==expected_counts
 for c in ['implementation','refinement']:assert f['metrics']['obligationsByCategory'][c]==expected_counts
 for c,n in [('source-derived-SMT',4),('source-derived-authorization-SMT',3),('source-derived-recovery-SMT',4)]:assert f['metrics']['obligationsByCategory'][c]=={'PROVEN':n,'REFUTED':0,'UNPROVEN':0,'NOT_APPLICABLE':0}
 assert f['execution']['passed'] and f['release']['decision']=='BLOCKED' and f['release']['executionAllowed'] is False
 assert set(inputs['sourceFilesSha256'])==set(actual)==expected
 for p,h in inputs['sourceFilesSha256'].items():assert sha(actual[p])==h,p
p=json.loads((o/'preparation-state.json').read_text());m=p['sourceCommit'];old=p['baselineHead'];main=p['mainSha']
assert git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip()
assert git('show','-s','--format=%P',m).decode().split()==[old,main]
q=json.loads((o/'ui-quality.json').read_text());f=json.loads((o/'assurance-committed/report.json').read_text());s=json.loads((o/'assurance-committed/sources.json').read_text());inputs=json.loads((o/'ui-qualified-inputs.json').read_text())
expected=set(git('ls-tree','-r','-z','--name-only',m,'--','tdf-hq-ui','package.json','package-lock.json','tdf-hq/assets/feature-registry.json','scripts/quality-ui.sh','formal/system/requirements.json').decode().strip('\0').split('\0'))
actual={path:(w/path).read_bytes() for path in expected};verify_ui_bindings(m,q,f,s,inputs,expected,actual)
mobile=git('rev-parse',m+':tdf-mobile').decode().strip();assert git('rev-parse','HEAD',cwd=w/'tdf-mobile').decode().strip()==mobile
for table in [inputs['sourceFilesSha256'],s['files']]:
 for ism in [False,True]:
  pairs=[(path,h) for path,h in table.items() if path.startswith('tdf-mobile/')==ism]
  if not pairs:continue
  cwd=w/'tdf-mobile' if ism else w;ref=mobile if ism else m;refs=[ref+':'+(path.removeprefix('tdf-mobile/') if ism else path) for path,h in pairs];assert all('\n' not in x for x in refs)
  raw=subprocess.check_output(['git','cat-file','--batch'],cwd=cwd,input=('\n'.join(refs)+'\n').encode());pos=0
  for path,h in pairs:
   end=raw.index(b'\n',pos);header=raw[pos:end].split();assert header[1]==b'blob';n=int(header[2]);assert sha(raw[end+1:end+1+n])==h==sha((w/path).read_bytes()),path;pos=end+1+n+1
  assert pos==len(raw)
for path,h in f['evidenceHashes'].items():
 pp=Path(path);assert not pp.is_absolute() and '..' not in pp.parts;assert sha((o/'assurance-committed'/pp).read_bytes())==h,path
for path in ['tdf-hq-ui','package.json','package-lock.json','tdf-mobile']:assert git('rev-parse',m+':'+path)==git('rev-parse',old+':'+path),path
for path in ['tdf-hq','.github','scripts','ops','package.json','package-lock.json','tdf-mobile']:assert git('rev-parse',m+':'+path)==git('rev-parse',main+':'+path),path
req=json.loads(git('show',m+':formal/system/requirements.json'))['requirements'];base=json.loads(git('show',main+':formal/system/requirements.json'))['requirements'];prior=json.loads(git('show',old+':formal/system/requirements.json'))['requirements'];by={r['id']:r for r in req}
assert len(req)==len(by)==160 and len(base)==159 and all(by[r['id']]==r for r in base)
assert by['UI-EVENT-FINANCE-PRECISION-001']==next(r for r in prior if r['id']=='UI-EVENT-FINANCE-PRECISION-001')
path='docs/catalog-persistence/catalog-list-decisions.json';assert git('show',m+':'+path)==git('show',old+':'+path)
basecat=json.loads(git('show',main+':'+path));cat=json.loads(git('show',m+':'+path));assert cat['decisions'][:-1]==basecat['decisions'] and cat['decisions'][-1]['id']=='caafb621f3c699640707' and cat['decisions'][-1]['reviewed']
catinv=json.loads(git('show',m+':docs/catalog-persistence/reports/static-list-inventory.json'));assert catinv['candidateCount']==1355 and all(x['decision']!='unreviewed' for x in catinv['candidates']);assert (o/'current-catalog.json').read_bytes()==git('show',m+':docs/catalog-persistence/reports/static-list-inventory.json')
assert (o/'current-catalog.csv').read_bytes()==git('show',m+':docs/catalog-persistence/reports/list-consumer-matrix.csv')
for ref in [old,main]:
 rows=git('ls-tree','-r','-z',ref,'--','reports','formal/system/evidence').decode().strip('\0').split('\0')
 for row in rows:
  mode,kind,rest=row.split(' ',2);oid,path=rest.split('\t',1);assert kind=='blob' and git('rev-parse',m+':'+path).decode().strip()==oid,path
history={}
for path,h in p['parentFourReportBlobsSha256'].items():assert sha(git('show',m+':'+path))==h;history[path]=h
assert all(x==0 for x in p['metadataResults']['actualExits'].values()) and all(x==0 for x in p['committedChecks'].values())
result={'sourceCommit':m,'baselineMain':main,'previousPublishedHead':old,'normalParents':[old,main],'sourceDigest':s['digest'],'registeredHashesVerified':len(s['files']),'uiInputHashesVerified':len(inputs['sourceFilesSha256']),'assuranceArtifactHashesVerified':len(f['evidenceHashes']),'allUiInputsByteExactOldEC7':True,'backendScriptsWorkflowsOpsExactMain234':True,'all159NewMainRequirementsExactPlusUnchangedPrecision160':True,'strictCatalogCandidates':1355,'historicalFourReportBlobs':history,'allParentHistoricalEvidencePreserved':True,'currentUiQuality':q,'historicalFullUi':{'localSource':'83533b3d980432aea6bab30361453311da4f3905','hostedHead':old,'tests':3811,'suites':327,'scope':'Historical full executions only; current composition UI byte-identical. Current full local NOT_RUN, fresh published-head CI required.'},'historicalCounterexamplesAndFaults':'Retained exact in original four report blobs/archive: baseline66/33failures, sourcefault21/3/4, actualpagewiring6 assertions, restored76, bundledbrowser26. No new execution of these historical faults/browser runs claimed.','assuranceMetrics':f['metrics'],'formalRelease':f['release']['decision'],'newCompleteProofs':0,'sourceCleanAfter':True,'limitations':['TESTED finite UI scope; full implementation/refinement remains UNPROVEN.','Current local full UI NOT_RUN; new head must run hosted full CI and receive a fresh exact-head review.','No new browser/HTTP/WebKit/PostgreSQL/provider execution.','CSV unit correction684 remains separate; concurrency/snapshot consistency not established.','No production writes or deployment, no interruption-cleanup universal guarantee.'],'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(o/'source-correspondence.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['sourceCommit','registeredHashesVerified','uiInputHashesVerified','formalRelease']}))
