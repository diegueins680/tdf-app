from pathlib import Path
w=Path('/private/tmp/tdf-event-finance-report-range-20261029');p=w/'tdf-hq/src/TDF/Server/SocialEventsHandlers.hs';s=p.read_text()
a=s.index('        pure $\n            map\n',s.index('    listBudgetLines ::'));b=s.index('\n    createBudgetLine ::',a)
s=s[:a]+'''        forM budgetRows $ \\lineEnt@(Entity lineKey lineRec) -> do
            let lineTypeVal = normalizeBudgetLineType (Just (eventBudgetLineLineType lineRec))
                exactActualCents = sum
                    [ toInteger (eventFinanceEntryAmountCents entry)
                    | Entity _ entry <- postedEntries
                    , eventFinanceEntryBudgetLineId entry == Just lineKey
                    , normalizeFinanceDirection (Just (eventFinanceEntryDirection entry)) == lineTypeVal
                    ]
            actualCents <- checkedEventFinanceCents exactActualCents
            pure (budgetLineEntityToDTO eventKey (Just actualCents) lineEnt)
''' +s[b:]
a=s.index('        liftIO $\n            runSqlPool\n                ( update\n                    lineKey',s.index('    updateBudgetLine ::'));b=s.index('        maybe\n            (throwError err500{errBody = "Could not update budget line"})',a)
old=s[a:b];cut=old.index('        postedEntries <-');update=old[:cut];rest=old[cut:];ix=rest.index('        mUpdated <-');select=rest[:ix];math=rest[rest.index('        let actualCents ='):]
math=math.replace('let actualCents =','let exactActualCents =').replace('[ eventFinanceEntryAmountCents entry','[ toInteger (eventFinanceEntryAmountCents entry)')
check=math+'        actualCents <- checkedEventFinanceCents exactActualCents\n'
s=s[:a]+select+check+update+'        mUpdated <- liftIO $ runSqlPool (getEntity lineKey) envPool\n'+s[b:]
a=s.index('        let plannedIncomeCents =',s.index('    getFinanceSummary ::'));b=s.index('\n    -- Event logistics',a);part=s[a:b]
part=part.replace('[ plannedCents','[ toInteger plannedCents').replace('entryAmount (amountCents, _, _, _) = amountCents','entryAmount (amountCents, _, _, _) = toInteger amountCents').replace('fromInteger canonicalGross + sum','canonicalGross + sum').replace('fromInteger canonicalRefunded + sum','canonicalRefunded + sum').replace('[ amountCents','[ toInteger amountCents').replace('budgetCentsVal = budgetOverride <|> fallbackBudget plannedExpenseCents','budgetCentsVal = fmap toInteger budgetOverride <|> fallbackBudget plannedExpenseCents')
# The computation stays exact through every addition and subtraction; only the
# complete externally reported values are narrowed, never intermediate sums.
fields=['plannedIncomeCents','plannedExpenseCents','actualIncomeCents','actualExpenseCents','netCents','ticketPaidRevenueCents','ticketRefundedRevenueCents','ticketPendingRevenueCents','accountsPayableCents','accountsReceivableCents','contractCommittedCents','contractPaidCents','procurementCommittedCents','procurementPaidCents','assetInvestmentCents','liabilityBalanceCents']
insert='''        -- All sums and differences above are Integer. Validate every monetary
        -- output before constructing the bounded DTO; no wrapped value is sent.
        forM_ (
            ['''+', '.join(fields)+''']
            ++ maybe [] pure budgetCentsVal
            ++ maybe [] pure budgetVarianceCents
            ) checkedEventFinanceCents

'''
needle='        pure\n            EventFinanceSummaryDTO';assert needle in part;part=part.replace(needle,insert+needle)
for f in fields:part=part.replace('= '+f+'\n','= fromInteger '+f+'\n')
part=part.replace('= budgetCentsVal\n','= fmap fromInteger budgetCentsVal\n').replace('= budgetVarianceCents\n','= fmap fromInteger budgetVarianceCents\n')
s=s[:a]+part+s[b:]
s=s.replace('fallbackBudget :: Int -> Maybe Int','fallbackBudget :: Integer -> Maybe Integer')
needle='financeInvariantServerError :: T.Text -> ServerError'
helper='''-- Event DTO amounts use host Int. Arithmetic must be exact before checking
-- both bounds: negative net, liability and budget-variance values are valid.
checkedEventFinanceCents :: Integer -> AppM Int
checkedEventFinanceCents exact
    | exact < toInteger (minBound :: Int) || exact > toInteger (maxBound :: Int) =
        throwError (financeInvariantServerError "Event finance amount exceeds the supported reporting range")
    | otherwise = pure (fromInteger exact)

'''
assert needle in s;s=s.replace(needle,helper+needle,1);p.write_text(s);print('Applied exactInteger event reporting and prewrite budget range checks')
