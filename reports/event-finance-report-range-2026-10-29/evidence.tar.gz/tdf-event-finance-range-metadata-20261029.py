from pathlib import Path
import json,subprocess,os
w=Path('/private/tmp/tdf-event-finance-report-range-20261029');o=Path('/private/tmp/tdf-event-finance-range-qualification-20261029');c=Path('/private/tmp/tdf-correctness-cycle-20261028')
env=os.environ.copy();env['PATH']='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/Users/macpro/.ghcup/bin:/usr/local/bin:/usr/bin:/bin';env['PYTHONDONTWRITEBYTECODE']='1'
assert (w/'package-lock.json').read_bytes()==(c/'package-lock.json').read_bytes()
made=[];jobs=[]
def run(label,cmd):
 with (o/(label+'.txt')).open('w') as log:r=subprocess.run(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT)
 print(label+' actualexit'+str(r.returncode),flush=True);assert r.returncode==0,label
try:
 for name in ['node_modules','tdf-hq-ui/node_modules']:
  p,t=w/name,c/name;assert not(p.exists() or p.is_symlink());p.symlink_to(t,target_is_directory=True);made.append((p,t))
 for fmt in ['json','csv']:
  log=(o/('strict-catalog-'+fmt+'.txt')).open('w');proc=subprocess.Popen(['node','scripts/catalog-list-audit.mjs','--decisions','docs/catalog-persistence/catalog-list-decisions.json','--fail-on-unreviewed','--format',fmt,'--output',str(o/('current-catalog.'+fmt))],cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT);jobs.append((fmt,proc,log))
 codes=[]
 for fmt,proc,log in jobs:
  code=proc.wait();log.close();codes.append(code);print('strict'+fmt+' actualexit'+str(code),flush=True)
 assert codes==[0,0],codes
 for fmt,dest in [('json','static-list-inventory.json'),('csv','list-consumer-matrix.csv')]:(w/'docs/catalog-persistence/reports'/dest).write_bytes((o/('current-catalog.'+fmt)).read_bytes())
 for label,script in [('inventory','specification-inventory'),('conformance','specification-conformance')]:
  run(label,['python3','scripts/'+script+'.py']);run(label+'-check',['python3','scripts/'+script+'.py','--check'])
finally:
 for fmt,proc,log in jobs:
  if proc.poll() is None:proc.terminate();proc.wait(timeout=10)
  log.close()
 for p,t in reversed(made):assert p.is_symlink() and p.resolve()==t.resolve();p.unlink()
old=json.loads(subprocess.check_output(['git','show','6197b87326a437350dca239ee64902e78da6964c:formal/system/requirements.json'],cwd=w))['requirements'];new=json.loads((w/'formal/system/requirements.json').read_text())['requirements'];by={x['id']:x for x in new};assert len(new)==len(old)+1 and all(by[x['id']]==x for x in old)
print('Canonicalmetadata complete; allincomingrequirement objects exact; aliases removed',flush=True)
