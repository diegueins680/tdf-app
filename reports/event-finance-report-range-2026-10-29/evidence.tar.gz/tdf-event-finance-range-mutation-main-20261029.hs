module Main (main) where
import Test.Hspec (hspec)
import qualified TDF.Social.FollowHandlerSpec as Follow
main :: IO ()
main = hspec Follow.spec
