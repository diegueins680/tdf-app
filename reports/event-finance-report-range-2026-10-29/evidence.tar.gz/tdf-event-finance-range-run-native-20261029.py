from pathlib import Path
import subprocess,os,json
w=Path('/private/tmp/tdf-event-finance-report-range-20261029');o=Path('/private/tmp/tdf-event-finance-range-qualification-20261029')
env=os.environ.copy();env['PATH']='/private/tmp/tdf-correctness-bin-20261028:/Users/macpro/.ghcup/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin';env['STACK_ROOT']='/Users/macpro/.stack';env['PYTHONDONTWRITEBYTECODE']='1'
for k in ['ADMIN_TOKEN','SPOTIFY_CLIENT_ID','SPOTIFY_CLIENT_SECRET','YOUTUBE_API_KEY','DRIVE_CLIENT_ID','DRIVE_CLIENT_SECRET','DRIVE_REFRESH_TOKEN','DATABASE_URL','TDF_API_BASE','API_BASE','TESTOMATIO']:env.pop(k,None)
with (o/'baseline-build.log').open('w') as log:r=subprocess.run(['/Users/macpro/.ghcup/bin/stack','test','tdf-hq:tdf-hq-test','--no-run-tests'],cwd=w/'tdf-hq',env=env,stdout=log,stderr=subprocess.STDOUT)
print('baseline build actualexit'+str(r.returncode),flush=True)
assert r.returncode==0,'Build failure; not a behavioralcounterexample'
binaries=list((w/'tdf-hq/.stack-work/dist').glob('**/build/tdf-hq-test/tdf-hq-test'));assert len(binaries)==1,binaries
with (o/'baseline-handler-tests.log').open('w') as log:r=subprocess.run([str(binaries[0]),'--match','event finance report range'],cwd=w/'tdf-hq',env=env,stdout=log,stderr=subprocess.STDOUT)
(o/'baseline-execution.json').write_text(json.dumps({'buildExit':0,'handlerTestExit':r.returncode,'binary':str(binaries[0]),'scope':'Actual main6197 implementation plus new tests; nativeGHC9.10.3/Stacklts24.42,SQLitefixtures;notproductionPG.'},indent=2)+'\n')
print('baseline actualhandler tests exit'+str(r.returncode),flush=True)
