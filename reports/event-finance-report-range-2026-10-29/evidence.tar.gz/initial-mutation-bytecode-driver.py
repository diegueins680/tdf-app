from pathlib import Path
import subprocess,os,json,re,hashlib,signal,datetime
w=Path('/private/tmp/tdf-event-finance-report-range-20261029');o=Path('/private/tmp/tdf-event-finance-range-qualification-20261029');m='eab96f0c861ee7aeecf2855141dffed3fe7f60e6';source=w/'tdf-hq/src/TDF/Server/SocialEventsHandlers.hs'
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env['PATH']='/private/tmp/tdf-correctness-bin-20261028:/Users/macpro/.ghcup/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin';env['STACK_ROOT']='/Users/macpro/.stack';env['PYTHONDONTWRITEBYTECODE']='1'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=w)
quality=json.loads((o/'native-quality.json').read_text());assert quality['sourceCommit']==m and all(v==0 for v in quality['actualExits'].values());original=source.read_bytes();assert original==git('show',m+':tdf-hq/src/TDF/Server/SocialEventsHandlers.hs');binary=Path(quality['binary']);binaryHash=sha(binary.read_bytes());assert binaryHash==quality['binarySha256'] and not git('status','--porcelain').strip()
command=['/Users/macpro/.ghcup/bin/stack','exec','--','runghc','-Wall','-isrc','-itest','/private/tmp/tdf-event-finance-range-mutation-main-20261029.hs','--match','event finance report range'];results=[]
def run(label,expected):
 logpath=o/('mutation-'+label+'.log')
 with logpath.open('w') as log:
  p=subprocess.Popen(command,cwd=w/'tdf-hq',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=p.wait(timeout=1200)
  except BaseException:
   if p.poll() is None:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   raise
 raw=logpath.read_text();matches=re.findall(r'(\d+) examples?, (\d+) failures?(?:, (\d+) pending)?',raw);assert matches,'No real completedHspec summary; harness/compile failure is not intendedfailure';examples,failed,pending=matches[-1];assert int(examples)==15 and int(failed)==expected and not pending,(label,code,matches[-1]);assert code==(1 if expected else 0),(label,code)
 if expected:assert ('Expected range refusal, got' in raw if label=='omitted-source-aggregates' else 'expected: Just 7' in raw and 'but got: Just 99' in raw)
 row={'label':label,'sourceSha256':sha(source.read_bytes()),'actualExit':code,'examples':int(examples),'assertionFailures':int(failed),'pending':0,'logSha256':sha(logpath.read_bytes())};results.append(row);(o/'mutation-progress.json').write_text(json.dumps({'sourceCommit':m,'executionMode':'CanonicalStack/GHC9.10.3 runghc actualhandler; nativecompiledM binary unchanged','results':results},indent=2)+'\n');print(label+' actualexit'+str(code)+' failures'+failed,flush=True)
try:
 run('correct-interpreter',0)
 text=original.decode();old=', accountsReceivableCents, contractCommittedCents, contractPaidCents';assert text.count(old)==1;text=text.replace(old,', accountsReceivableCents, contractPaidCents');old=', procurementCommittedCents, procurementPaidCents, assetInvestmentCents, liabilityBalanceCents';assert text.count(old)==1;text=text.replace(old,', procurementPaidCents, assetInvestmentCents, liabilityBalanceCents');source.write_text(text);run('omitted-source-aggregates',2)
 text=original.decode();start=text.index('    updateBudgetLine ::');end=text.index('    -- Finance',start);part=text[start:end];guard='        actualCents <- checkedEventFinanceCents exactActualCents\n';assert part.count(guard)==1;part=part.replace(guard,'');needle='        mUpdated <- liftIO $ runSqlPool (getEntity lineKey) envPool\n';assert part.count(needle)==1;part=part.replace(needle,guard+needle);source.write_text(text[:start]+part+text[end:]);run('late-budget-check',1)
finally:
 source.write_bytes(original)
 assert source.read_bytes()==git('show',m+':tdf-hq/src/TDF/Server/SocialEventsHandlers.hs')
 assert sha(binary.read_bytes())==binaryHash,'Interpreted controls must not replace nativequalifiedbinary'
 assert not git('status','--porcelain').strip()
run('restored-interpreter',0)
with (o/'mutation-restored-native.log').open('w') as log:r=subprocess.run([str(binary),'--match','event finance report range'],cwd=w/'tdf-hq',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert r.returncode==0 and '15 examples, 0 failures' in (o/'mutation-restored-native.log').read_text();assert sha(binary.read_bytes())==binaryHash
receipt={'sourceCommit':m,'executionMode':'ActualGHC9.10.3interpretedhandlercontrols; nativecompiledMbinary independentlyqualifiedbeforeandunchangedafter','results':results,'realMutantsDetected':2,'intendedMutationAssertionFailures':3,'allOriginalSourceBytesRestored':True,'nativeQualifiedBinarySha256Unchanged':binaryHash,'restoredNativeActualExit':r.returncode,'sourceClean':not git('status','--porcelain').strip(),'scope':'Finite test sensitivity, not complete mutation coverage or proof. No new native compiled mutation/product binary claim.'};(o/'mutations.json').write_text(json.dumps(receipt,indent=2)+'\n');print('Two actual source mutants detected; originalsource/nativebinary preserved/restored; native15pass',flush=True)
