import hashlib, json, pathlib, subprocess, sys, tempfile

root = pathlib.Path('/private/tmp/tdf-ticket-final-amount-live-20261103-0208')
out = pathlib.Path(__file__).parent
checker = root / 'reports/legacy-ticket-final-amount-2026-10-28/check-arithmetic.py'
source_path = 'tdf-hq/src/TDF/Server/SocialEventsHandlers.hs'
source = (root / source_path).read_bytes()
old, new = b'ticketPlatformFeeBps = 400', b'ticketPlatformFeeBps = 401'
if source.count(old) != 1:
    raise RuntimeError('Expected one exact fee-policy source binding')
mutated = source.replace(old, new)
results = []
with tempfile.TemporaryDirectory(prefix='tdf-fee-envelope-mutant-') as directory:
    fixture = pathlib.Path(directory)
    target = fixture / source_path
    target.parent.mkdir(parents=True)
    target.write_bytes(mutated)
    for label, flags in [('normal', []), ('optimized', ['-O'])]:
        result = subprocess.run([sys.executable, *flags, str(checker), '--root', str(fixture)],
                                capture_output=True, stdin=subprocess.DEVNULL)
        (out / ('arithmetic-mutant-' + label + '.stderr.log')).write_bytes(result.stderr)
        if result.returncode == 0 or b'ValueError: Fee policy assumption changed' not in result.stderr:
            raise RuntimeError('Arithmetic verifier did not reject the changed fee policy: ' + label)
        results.append({'mode': label, 'exitCode': result.returncode,
                        'rejectedBy': 'Explicit fee-policy assumption check',
                        'stderrSHA256': hashlib.sha256(result.stderr).hexdigest()})
if (root / source_path).read_bytes() != source:
    raise RuntimeError('Original source unexpectedly changed')
print(json.dumps({'sourceSHA256': hashlib.sha256(source).hexdigest(),
                  'mutantSHA256': hashlib.sha256(mutated).hexdigest(),
                  'mutation': 'Fee policy400->401 in a separate temporary source tree',
                  'originalSourceUnchanged': True, 'results': results,
                  'scope': 'Negative control for conditional arithmetic assumptions; no implementation-refinement or provider proof.'}, indent=2))
