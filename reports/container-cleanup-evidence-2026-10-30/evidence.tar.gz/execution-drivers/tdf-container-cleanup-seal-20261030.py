from pathlib import Path
import json, subprocess, hashlib, re
w=Path('/private/tmp/tdf-container-cleanup-evidence-20261030')
o=Path('/private/tmp/tdf-container-cleanup-evidence-qualification-20261030')
base='e1cec5b59723c2ff9828ac4fce45abb930d73055'
m=json.loads((o/'preparation-state.json').read_text())['sourceCommit']
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args,cwd=w):return subprocess.check_output(['git',*args],cwd=cwd)
assert git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip()
root=json.loads((o/'root-quality-result.json').read_text())
f=json.loads((o/'assurance-committed/report.json').read_text())
s=json.loads((o/'assurance-committed/sources.json').read_text())
assert root['sourceCommit']==s['revision']==m and all(v==0 for v in root['actualExits'].values())
assert f['execution']['passed'] and f['provenance']['revision']==m and not s['worktreeDirty']
assert s['digest']==sha(json.dumps(s['files'],sort_keys=True).encode())
mobile=git('rev-parse',m+':tdf-mobile').decode().strip()
assert git('rev-parse','HEAD',cwd=w/'tdf-mobile').decode().strip()==mobile
for isMobile in [False,True]:
    pairs=[(p,h) for p,h in s['files'].items() if p.startswith('tdf-mobile/')==isMobile]
    cwd=w/'tdf-mobile' if isMobile else w
    rev=mobile if isMobile else m
    refs=[rev+':'+(p.removeprefix('tdf-mobile/') if isMobile else p) for p,h in pairs]
    assert all('\n' not in x for x in refs)
    raw=subprocess.check_output(['git','cat-file','--batch'],cwd=cwd,input=('\n'.join(refs)+'\n').encode())
    pos=0
    for p,h in pairs:
        end=raw.index(b'\n',pos);header=raw[pos:end].split()
        assert header[1]==b'blob'
        n=int(header[2])
        assert sha(raw[end+1:end+1+n])==h==sha((w/p).read_bytes()),p
        pos=end+1+n+1
    assert pos==len(raw)
old=json.loads(git('show',base+':formal/system/requirements.json'))['requirements']
new=json.loads((w/'formal/system/requirements.json').read_text())['requirements']
by={x['id']:x for x in new}
assert len(new)==len(old)+1==159 and all(by[x['id']]==x for x in old)
assert by['SYS-VERIFY-CONTAINER-CLEANUP-001']['critical'] is False
runner='scripts/test-persistent-uploads-container.py'
source=(w/runner).read_text()
a=source.index('DIAGNOSTIC_OUTPUT_LIMIT = 2000\n')
b=source.index('\n\ndef main():',a)
reversedSource=(source[:a]+source[b:]).replace('raise ContainerCleanupError(name, found, results)',"raise RuntimeError('Could not confirm synthetic container cleanup')")
assert reversedSource.encode()==git('show',base+':'+runner)
quality='scripts/quality-repo.sh'
source=(w/quality).read_text()
registration='PYTHONDONTWRITEBYTECODE=1 python3 "$ROOT/scripts/test-persistent-uploads-container-diagnostics.py"\n'
assert source.count(registration)==1 and source.replace(registration,'').encode()==git('show',base+':'+quality)
for p in ['tdf-hq','tdf-hq-ui','tdf-mobile','.github','package.json','package-lock.json','formal/system/auth-predicates.json','formal/system/recovery-expiry-arithmetic.json','docs/catalog-persistence/catalog-list-decisions.json']:
    assert git('rev-parse',m+':'+p)==git('rev-parse',base+':'+p),p
changes=git('diff','--name-only',base,m,'--','scripts').decode().splitlines()
test='scripts/test-persistent-uploads-container-diagnostics.py'
assert set(changes)=={runner,quality,test},changes
c=json.loads((o/'controls.json').read_text())
assert sha((w/runner).read_bytes())==c['runnerSha256']==sha(git('show',m+':'+runner))
assert sha((w/test).read_bytes())==c['testSha256']==sha(git('show',m+':'+test))
assert c['sourceRestored'] and len(c['variants'])==4 and c['restored']['exit']==0 and c['restored']['tests']==10
for v in c['variants']:
    log=(o/(v['variant']+'.log')).read_bytes()
    assert sha(log)==v['logSha256']
    text=log.decode()
    assert 'Ran 1 test' in text and 'FAILED (failures=1)' in text and 'ERROR:' not in text
    assert v['exit']==1 and v['assertionFailures']==1
unit=(o/'tdf-container-cleanup-independent-tests-20261030.log').read_text()
shell=(o/'tdf-container-cleanup-independent-shell-tests-qualified-20261030.log').read_text()
assert 'Ran 10 tests' in unit and unit.rstrip().endswith('OK')
assert 'tests 2' in shell and 'pass 2' in shell and 'fail 0' in shell
contract='formal/system/container-cleanup-evidence.md'
assert (w/contract).read_bytes()==git('show',m+':'+contract)
record={'baseline':base,'sourceCommit':m,'registeredGitFilesystemMobileHashesVerified':len(s['files']),'sourceDigest':s['digest'],'all158IncomingRequirementsExact':True,'requirementsTotal':len(new),'newRequirementCritical':False,'contractGitSha256':sha((w/contract).read_bytes()),'rootQuality':root,'independentSimulatedCases':10,'independentExistingShellCases':2,'sourceControlVariants':4,'intendedControlAssertionFailures':4,'runnerAndRegistrationDeclaredReversalExactMain':True,'uiBackendMobileWorkflowDependenciesModelContractsExactMain':True,'scriptChangesOnly':changes,'freshAssuranceMetrics':f['metrics'],'formalRelease':f['release']['decision'],'newCompleteProofs':0,'actualLocalDockerExecuted':False,'originalHostedResponseAndCause':'UNKNOWN','sourceCleanAfter':True,'limits':['Mocked actual-main runner flow and existing local shell guard cases are TESTED only.','The old hosted response/cause cannot be reconstructed; no Docker/storage repair or production/durability/deployment claim.','Existing absence classifier, command deadlines and cleanup safeguards are preserved rather than proved complete.']}
(o/'committed-source-correspondence.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k in ['sourceCommit','registeredGitFilesystemMobileHashesVerified','independentSimulatedCases','sourceControlVariants','formalRelease']},indent=2))

