from pathlib import Path
import subprocess, os, json, hashlib, datetime
w = Path('/private/tmp/tdf-container-cleanup-evidence-20261030')
r = Path('/private/tmp/tdf-container-cleanup-evidence-qualification-20261030')
p = w/'scripts/test-persistent-uploads-container.py'
t = w/'scripts/test-persistent-uploads-container-diagnostics.py'
correct = p.read_bytes()
correct_test = t.read_bytes()
(r/'correct-runner.py').write_bytes(correct)
(r/'correct-tests.py').write_bytes(correct_test)
sha = lambda b: hashlib.sha256(b).hexdigest()
def require(condition, message):
    if not condition: raise RuntimeError(message)
variants = [
 ('discard-context', 'raise ContainerCleanupError(name, found, results)',
  "raise RuntimeError('Could not confirm synthetic container cleanup')",
  'test_unexpected_inspect_retains_command_result_and_completed_cases'),
 ('omit-ownership-guard', "if row['Config']['Labels'].get('net.tdf.upload-test') != nonce:",
  'if False:', 'test_foreign_container_is_never_removed'),
 ('accept-unknown-as-absent', "elif 'No such' not in found.stderr:",
  'elif False:', 'test_empty_unexpected_response_does_not_become_absence'),
 ('suppress-primary-context', 'raise ContainerCleanupError(name, found, results)',
  'raise ContainerCleanupError(name, found, results) from None',
  'test_primary_failure_remains_chained_with_cleanup_failure'),
]
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
results = []
try:
    for label, before, after, test in variants:
        text = correct.decode()
        require(text.count(before) == 1, 'Nonunique source mutation')
        mutant = text.replace(before, after).encode()
        p.write_bytes(mutant)
        command = ['python3', 'scripts/test-persistent-uploads-container-diagnostics.py',
                   'CleanupDiagnosticsTest.' + test]
        run = subprocess.run(command, cwd=w, env=env, capture_output=True, text=True, timeout=30)
        output = run.stdout + run.stderr
        (r/(label+'.log')).write_text(output)
        require(run.returncode == 1, label + ': expected failing test exit1')
        require('Ran 1 test' in output and 'FAILED (failures=1)' in output, label + ': not one assertion failure')
        require('ERROR:' not in output, label + ': setup/error is not a detected assertion')
        require(t.read_bytes() == correct_test, 'Test source changed during controls')
        results.append({'variant':label, 'command':command, 'exit':run.returncode,
                        'tests':1, 'assertionFailures':1, 'mutantSha256':sha(mutant),
                        'logSha256':sha((r/(label+'.log')).read_bytes())})
finally:
    p.write_bytes(correct)
    require(p.read_bytes() == correct, 'Runner restoration failed')
    require(t.read_bytes() == correct_test, 'Test restoration failed')
run = subprocess.run(['python3','scripts/test-persistent-uploads-container-diagnostics.py'],
                     cwd=w, env=env, capture_output=True, text=True, timeout=30)
output = run.stdout + run.stderr
(r/'restored-tests.log').write_text(output)
require(run.returncode == 0 and 'Ran 10 tests' in output and output.rstrip().endswith('OK'),
        'Restored tests did not pass10/0')
result = {'scope':'Simulated subprocess responses, no Docker/daemon/provider execution',
          'baseline':'e1cec5b59723c2ff9828ac4fce45abb930d73055',
          'sourceRestored': p.read_bytes() == correct,
          'runnerSha256':sha(correct), 'testSha256':sha(correct_test),
          'variants':results, 'restored':{'exit':run.returncode,'tests':10,'failures':0,
                                       'logSha256':sha((r/'restored-tests.log').read_bytes())},
          'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(r/'controls.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
