from pathlib import Path
import subprocess,json,hashlib,tarfile,gzip,io,shutil,datetime,sys
kind=sys.argv[1];assert kind in ['currency','csv']
prefix='tdf-event-finance-currency' if kind=='currency' else 'tdf-csv-currency'
w=Path('/private/tmp/'+prefix+'-main643-20261030T2302');o=Path('/private/tmp/'+prefix+'-main643-qualification-20261030T2302')
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=w)
p=json.loads((o/'preparation-state.json').read_text());m=p['sourceCommit'];main=p['mainSha'];old=p['baselineHead'];parent=p['parentHead'];s=json.loads((o/'source-correspondence.json').read_text());c=json.loads((o/'seal-binding-controls.json').read_text());f=json.loads((o/'assurance-committed/report.json').read_text())
q=json.loads((o/('native-quality.json' if kind=='currency' else 'ui-quality.json')).read_text());review=Path('/private/tmp/'+prefix+'-main643-final-review-20261030T2302.txt')
assert git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip()
assert all(x['sourceCommit']==m for x in [s,c,q]) and all(x==0 for x in q['actualExits'].values())
assert c['intendedAssertionRejections']==(13 if kind=='currency' else 12) and c['validBefore'] and c['restoredValidAfter']
assert f['execution']['passed'] and f['provenance']['revision']==m and f['release']['decision']=='BLOCKED'
assert m in review.read_text() and main in review.read_text() and 'ACCEPT' in review.read_text()
files=[review,Path(__file__),Path('/private/tmp/tdf-verify-report-archive-20261030.py'),*Path('/private/tmp').glob(prefix+'-main643-*-20261030T2302.py'),*Path('/private/tmp').glob(prefix+'-main643-*-20261030T2302.txt')]
for file in files:
 assert file.is_file() and not file.is_symlink();shutil.copyfile(file,o/file.name)
manifest=[];buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.PAX_FORMAT) as archive:
 for file in sorted(o.rglob('*')):
  assert not file.is_symlink(),file
  if file.is_dir():continue
  assert file.is_file();body=file.read_bytes();name=str(file.relative_to(o));e=tarfile.TarInfo(name);e.size=len(body);e.mode=0o644;e.mtime=0;archive.addfile(e,io.BytesIO(body));manifest.append({'path':name,'sha256':sha(body),'bytes':len(body)})
name='event-finance-report-currency-main643-2026-10-30' if kind=='currency' else 'event-finance-csv-currency-main643-2026-10-30'
rd=w/'reports'/name;rd.mkdir(exist_ok=False);raw=gzip.compress(buf.getvalue(),mtime=0);ap=rd/'evidence.tar.gz';ap.write_bytes(raw);(rd/'manifest.json').write_text(json.dumps({'sourceCommit':m,'archiveSha256':sha(raw),'archiveBytes':len(raw),'files':manifest},indent=2)+'\n');shutil.copyfile(review,rd/'independent-review.txt')
prior='reports/event-finance-report-currency-parent1ffa-2026-10-30.json' if kind=='currency' else 'reports/event-finance-csv-currency-2026-10-30.json'
historical=json.loads(git('show',old+':'+prior));assert git('show',m+':'+prior)==git('show',old+':'+prior)
report={'schemaVersion':1,'dateUTC':'2026-10-30','baselineMain':main,'previousPublishedHead':old,'sourceCommit':m,'evidenceCommit':'Containing report-only child; exactly four new report paths and all archive members verified from committed Git after packaging.','scope':'Current-main reconciliation of an existing defect correction; no new application semantics introduced.','composition':{'normalParents':[old,parent],'qualifiedParent':parent,'all159NewMainNormativeObjectsPreserved':True,'ownedRequirementUnchanged':True,'totalRequirements':161,'all160QualifiedParentNormativeObjectsPreserved':True,'applicationComponentExactOldHead':True,'protectedMain643VerificationRulesPreserved':True,'allParentEvidencePreserved':True},'problem':historical['problem'],'correction':historical['correction'],'properties':[dict(x,sourceCommit=m,status='TESTED',method='Current targeted regression execution on byte-identical application component; exact current methods and limits below. Original counterexamples and fault executions retain historical identities.') for x in historical['properties']],'historicalEvidence':{'report':prior,'gitBlob':git('rev-parse',m+':'+prior).decode().strip(),'sha256':sha(git('show',m+':'+prior)),'scope':'Historical baseline failures, source faults, browser/full-suite evidence remain tied to original source identities; not relabeled as fresh executions.'},'verification':{'current':q,'sourceSeal':s,'bindingControls':c,'assuranceMetrics':f['metrics'],'formalRelease':f['release']['decision'],'newCompleteProofs':0,'independentReview':str((rd/'independent-review.txt').relative_to(w))},'regressionProtection':{'automaticExistingSuiteDiscovery':True,'currentTargetedExamples':29 if kind=='currency' else 78,'evidenceCorruptionsRejected':13 if kind=='currency' else 12,'dependenciesChanged':False},'limitations':s['limitations'],'integration':{'pullRequest':673 if kind=='currency' else 684,'merged':False,'currentHeadReviewAndCiRequired':True,'approvalOnOldHeadNotReused':True,'autoMergeUnchanged':True,'mainFifoAndProtectionMustBeRechecked':True,'productionWrites':False,'manualDeployment':False},'nextHighestValueTask':'Verify both changed parent/child heads in hosted CI and obtain fresh exact-head approvals; preserve protected main FIFO. Then reassess the legacy payment/refund correctness stack and worker failure diagnostics.','archive':{'path':str(ap.relative_to(w)),'sha256':sha(raw),'bytes':len(raw),'innerFiles':len(manifest),'manifest':str((rd/'manifest.json').relative_to(w))},'createdAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
if kind=='csv':
 report['orchestrationHistory']={'initialAssuranceActualExit':1,'reason':'Concurrent UI qualification created two temporary untracked dependency aliases after assurance fingerprint capture; verifier correctly marked all claims stale.','registeredContentMismatches':0,'correction':'Serialize assurance after all UI checks and exact-target alias cleanup; no source, spec, test or verifier-policy weakening.','failedArtifacts':'Complete failed receipts/logs retained underinitial-assurance-concurrent-aliases in archive.','diagnostic':json.loads((o/'assurance-concurrent-alias-diagnostic.json').read_text()),'freshSerializedExecution':json.loads((o/'assurance-ordering-correction.json').read_text()),'productFailureClaim':False}
if kind=='currency':
 report['openCrossLayerDefect']={'id':'UI-EVENT-FINANCE-PRECISION-001','status':'FAILED_IN_THIS_BRANCH','consequence':'Backend Int64 cents may exceed JavaScript safe integers; browser parsing, CSV admission and floating display can lose cents. Separate browser683 repair is unmerged and not imported.','scope':'Historical actual-source counterexamples retained in parent report; no new probe or production exposure claim.'}
(w/'reports'/(name+'.json')).write_text(json.dumps(report,indent=2)+'\n')
paths=['reports/'+name+'.json',*[str((rd/f).relative_to(w)) for f in ['evidence.tar.gz','manifest.json','independent-review.txt']]]
assert set(git('status','--porcelain','--untracked-files=all').decode().splitlines())==set('?? '+path for path in paths)
subprocess.run(['git','add','--',*paths],cwd=w,check=True);assert set(git('diff','--cached','--name-only').decode().splitlines())==set(paths)
subprocess.run(['git','commit','-m','docs: bind '+kind+' finance verification to protected main643'],cwd=w,check=True)
head=git('rev-parse','HEAD').decode().strip();assert git('show','-s','--format=%P',head).decode().split()==[m]
subprocess.run(['python3','/private/tmp/tdf-verify-report-archive-20261030.py',str(w),'reports/'+name+'.json',m],check=True)
(o/'packaged-head.json').write_text(json.dumps({'sourceCommit':m,'head':head,'report':'reports/'+name+'.json','archiveSha256':sha(raw),'archiveBytes':len(raw),'archiveMembers':len(manifest)},indent=2)+'\n');print(json.dumps({'head':head,'archiveMembers':len(manifest),'archiveBytes':len(raw)}),flush=True)
