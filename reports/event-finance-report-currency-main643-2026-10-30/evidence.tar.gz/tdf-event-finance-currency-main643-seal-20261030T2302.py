from pathlib import Path
import json, subprocess, hashlib, datetime
w=Path('/private/tmp/tdf-event-finance-currency-main643-20261030T2302')
o=Path('/private/tmp/tdf-event-finance-currency-main643-qualification-20261030T2302')
old='b08c92a37a8dcd734c4c890158e3b766ac44c55b'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args,cwd=w): return subprocess.check_output(['git',*args],cwd=cwd)
def blob(rev,path): return git('show',rev+':'+path)
def verify_current_artifact_bindings(m,q,f,s,force,binary_bytes,version_bytes,requirement_count,root):
 assert set(q['actualExits'])=={'build','targeted','full'} and all(v==0 for v in q['actualExits'].values())
 assert q['phase']=='QUALIFIED_TARGETED_AND_FULL'
 assert root['sourceCommit']==m and set(root['actualExits'])=={'root-quality','new-surface-admission','catalog-unit'}
 assert all(v==0 for v in root['actualExits'].values()) and root['catalogUnitCases']==8 and root['aliasesRemoved'] and root['sourceCleanAfter']
 assert sha(binary_bytes)==force['binarySha256']==q['binarySha256']
 assert sha(version_bytes)==force['versionObjectSha256']
 assert m.encode() in binary_bytes and m.encode() in version_bytes
 assert q['forceDirtyIdentity']==force
 for key in ['files','digest','revision','mobileGitlink','worktreeDirty']:
  assert f['provenance'][key]==s[key],key
 expected={'PROVEN':0,'REFUTED':0,'UNPROVEN':requirement_count,'NOT_APPLICABLE':0}
 assert f['metrics']['requirements']==expected
 for category in ['implementation','refinement']:
  assert f['metrics']['obligationsByCategory'][category]==expected,category
 for category,count in [('source-derived-SMT',4),('source-derived-authorization-SMT',3),('source-derived-recovery-SMT',4)]:
  assert f['metrics']['obligationsByCategory'][category]=={'PROVEN':count,'REFUTED':0,'UNPROVEN':0,'NOT_APPLICABLE':0},category
 assert f['release']['decision']=='BLOCKED' and f['release']['executionAllowed'] is False

prep=json.loads((o/'preparation-state.json').read_text());m=prep['sourceCommit'];main=prep['mainSha'];parent=prep['parentHead']
assert git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip()
assert git('show','-s','--format=%P',m).decode().split()==[old,parent]
for p in ['formal/system/auth-predicates.json','formal/system/recovery-expiry-arithmetic.json','formal/system/event-finance-report-range.md','formal/system/event-finance-report-currency.md']:
 assert git('rev-parse',m+':'+p)==git('rev-parse',old+':'+p),p
for p in ['.github','tdf-hq-ui','tdf-mobile','scripts','ops','tdf-hq/tdf-hq.cabal','tdf-hq/stack.yaml','tdf-hq/stack.yaml.lock','package.json','package-lock.json','docs/catalog-persistence/catalog-list-decisions.json']:
 assert git('rev-parse',m+':'+p)==git('rev-parse',main+':'+p),p
owned_backend={'tdf-hq/src/TDF/Server/SocialEventsHandlers.hs','tdf-hq/test/TDF/Social/FollowHandlerSpec.hs'}
assert set(git('diff','--name-only',main,m,'--','tdf-hq').decode().splitlines())==owned_backend
for p in owned_backend:assert blob(m,p)==blob(old,p)==(w/p).read_bytes(),p
incoming_backend=[]
assert git('rev-parse',m+':tdf-hq')==git('rev-parse',old+':tdf-hq')
historical=[p for p in git('ls-tree','-r','--name-only',old,'--','reports').decode().splitlines() if p.startswith('reports/event-finance-report-')]
assert len(historical)>12
historicalBindings={}
for p in historical:
 b=blob(old,p);assert blob(m,p)==b==(w/p).read_bytes();historicalBindings[p]=sha(b)
def history_table(ref):
 result={}
 for row in git('ls-tree','-r','-z',ref,'--','reports','formal/system/evidence').split(b'\0'):
  if not row:continue
  header,path=row.split(b'\t',1);mode,kind,oid=header.split();assert kind==b'blob';result[path]=oid
 return result
current_history=history_table(m)
for ref in [old,parent]:
 for path,oid in history_table(ref).items():assert current_history.get(path)==oid,path
mainreq=json.loads(blob(main,'formal/system/requirements.json'))['requirements']
priorreq=json.loads(blob(old,'formal/system/requirements.json'))['requirements']
req=json.loads((w/'formal/system/requirements.json').read_text())['requirements'];by={x['id']:x for x in req};oldby={x['id']:x for x in priorreq}
assert len(by)==len(req)==len(mainreq)+2
assert all(by[x['id']]==x for x in mainreq)
assert by['PAY-EVENT-REPORT-RANGE-001']==oldby['PAY-EVENT-REPORT-RANGE-001']
assert by['PAY-EVENT-REPORT-CURRENCY-001']==oldby['PAY-EVENT-REPORT-CURRENCY-001']
parentreq=json.loads(blob(parent,'formal/system/requirements.json'))['requirements'];assert len(parentreq)==160 and all(by[x['id']]==x for x in parentreq)
q=json.loads((o/'native-quality.json').read_text());r=json.loads((o/'root-quality-result.json').read_text());f=json.loads((o/'assurance-committed/report.json').read_text());s=json.loads((o/'assurance-committed/sources.json').read_text());force=json.loads((o/'native-force-dirty-confirmed.json').read_text())
assert q['sourceCommit']==r['sourceCommit']==s['revision']==f['provenance']['revision']==force['sourceCommit']==m
assert all(x==0 for x in q['actualExits'].values()) and all(x==0 for x in r['actualExits'].values())
assert q['targeted']=={'examples':29,'failures':0,'pending':0} and q['full']=={'examples':4074,'failures':0,'pending':21}
assert force['canonicalForceDirty'] and force['qualifiedCommitLiteralInVersionObjectAndTestBinary'] and '--force-dirty' in force['command'] and force['binarySha256']==q['binarySha256']
assert Path(q['binary']).exists() and sha(Path(q['binary']).read_bytes())==q['binarySha256']
version_objects=list((w/'tdf-hq/.stack-work/dist').glob('**/build/tdf-hq-test/tdf-hq-test-tmp/TDF/Version.o'));assert len(version_objects)==1
verify_current_artifact_bindings(m,q,f,s,force,Path(q['binary']).read_bytes(),version_objects[0].read_bytes(),len(req),r)
assert f['execution']['passed'] and not s['worktreeDirty'] and s['digest']==sha(json.dumps(s['files'],sort_keys=True).encode())
mobile=git('rev-parse',m+':tdf-mobile').decode().strip();assert git('rev-parse','HEAD',cwd=w/'tdf-mobile').decode().strip()==mobile
for ism in [False,True]:
 pairs=[(p,h) for p,h in s['files'].items() if p.startswith('tdf-mobile/')==ism];cwd=w/'tdf-mobile' if ism else w;rev=mobile if ism else m
 refs=[rev+':'+(p.removeprefix('tdf-mobile/') if ism else p) for p,h in pairs];assert all('\n' not in x for x in refs)
 raw=subprocess.check_output(['git','cat-file','--batch'],cwd=cwd,input=('\n'.join(refs)+'\n').encode());pos=0
 for p,h in pairs:
  end=raw.index(b'\n',pos);header=raw[pos:end].split();assert header[1]==b'blob';n=int(header[2]);assert sha(raw[end+1:end+1+n])==h==sha((w/p).read_bytes()),p;pos=end+1+n+1
 assert pos==len(raw)
inputs=json.loads((o/'native-qualified-inputs.json').read_text())['allBackendTrackedGitSha256']
backend_paths=set(git('ls-tree','-r','-z','--name-only',m,'--','tdf-hq').decode().rstrip('\0').split('\0'));assert set(inputs)==backend_paths
refs=[m+':'+p for p in inputs];assert all('\n' not in p for p in refs)
raw=subprocess.check_output(['git','cat-file','--batch'],cwd=w,input=('\n'.join(refs)+'\n').encode());pos=0
for p,h in inputs.items():
 end=raw.index(b'\n',pos);header=raw[pos:end].split();assert header[1]==b'blob';n=int(header[2]);assert sha(raw[end+1:end+1+n])==h==sha((w/p).read_bytes()),p;pos=end+1+n+1
assert pos==len(raw)
for p,h in f['evidenceHashes'].items():
 relative=Path(p);assert not relative.is_absolute() and '..' not in relative.parts
 assert sha((o/'assurance-committed'/relative).read_bytes())==h,p
result={'sourceCommit':m,'baselineMain':main,'previousPublishedHead':old,'normalMergeParents':[old,parent],'qualifiedParent':parent,'sourceDigest':s['digest'],'registeredHashesVerified':len(s['files']),'allBackendInputCount':len(inputs),'assuranceArtifactHashesVerified':len(f['evidenceHashes']),'ownedHandlerAndTestExactPreviousQualifiedHead':True,'entireBackendTreeExactPreviousQualifiedHead':True,'allNonOwnedBackendExactMain':True,'incomingMainBackendFilesPreserved':incoming_backend,'workflowUiMobileScriptDependencyTreesExactMain':True,'allMainNormativeRequirementsPreserved':len(mainreq),'rangeRequirementExactPrevious':True,'currencyRequirementExactPrevious':True,'all160ParentNormativeRequirementsPreserved':True,'totalRequirements':len(req),'historicalEvidenceGitSha256':historicalBindings,'historicalEvidenceScope':'Original foreign-unit Handler counterexamples andtwo sourcefaults/nine intendedassertions remain historical. Entirebackend exactoldB08; new qualifiedrange parentd4 preserves protectedmain234verification amendments. Fresh29target/4074full sourceidentity re-executed.','nativeTargeted':q['targeted'],'nativeFull':q['full'],'nativeForceDirtyIdentity':force,'assuranceMetrics':f['metrics'],'formalRelease':f['release']['decision'],'newCompleteProofs':0,'sourceCleanAfter':True,'recheckedVersionObjectAndAssuranceProvenance':True,'limitations':['Finite direct typed Handler/owned SQLite fixtures; no authenticatedHTTP, production PostgreSQL extreme reachability, serializable-snapshot or complete currency-normalization guarantee; no serving executable/deployment qualification.','OPEN/FAILED in this range branch: backend-safe cents can exceed JavaScript safe integer or display exactness. Separate unmerged browser precision683 corrects reads/display/export; CSV684 is not imported.',
'No new actual Docker or PostgreSQL runtime; required hosted lanes must execute on published current head.','Currency673 correction retained; no unmergedUI683/684 or677/679/682 import. Historicalcampaigncontrast andworker failures remainunknowncauses; passing samples are not repairproof.','Protected current-head review/checks/FIFO and later main advances must be re-evaluated before integration.','New native driver installs SIGTERM cleanup entry; interrupted-run/process-tree cleanup remains untested and no universal interruption guarantee is claimed. The old3900s outer orchestrator is not reused; native and assurance execute directly in separate owned sessions.'],'createdAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(o/'source-correspondence.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['sourceCommit','baselineMain','registeredHashesVerified','allBackendInputCount','totalRequirements','nativeTargeted','nativeFull','formalRelease']},indent=2))
