from pathlib import Path
import subprocess,json,datetime,hashlib
root=Path('/Users/macpro/GitHub/tdf-app');w=Path('/private/tmp/tdf-event-finance-currency-main643-20261030T2302');o=Path('/private/tmp/tdf-event-finance-currency-main643-qualification-20261030T2302');main='d4c00e935ebbd0d6b958bc2e908d0f4efbe7096c';actualmain='234ff6f7faf1aecf347c8e92a374228f4ec07aaa';old='b08c92a37a8dcd734c4c890158e3b766ac44c55b';branch='fix/event-finance-currency-main643-20261030T2302';o.mkdir();assert not w.exists()
def git(*a,cwd=w):return subprocess.check_output(['git',*a],cwd=cwd)
def run(label,cmd,cwd):
 r=subprocess.run(cmd,cwd=cwd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(o/(label+'.log')).write_text(r.stdout);return r
r=run('worktree-add',['git','worktree','add','-b',branch,str(w),old],root);assert r.returncode==0,r.stdout
r=run('merge-initial',['git','merge','--no-commit','--no-ff',main],w);assert r.returncode in [0,1],r.stdout
allowed={'formal/system/inventory.json','formal/system/traceability.json','docs/catalog-persistence/reports/static-list-inventory.json','docs/catalog-persistence/reports/list-consumer-matrix.csv','formal/system/requirements.json'};unmerged=set(git('diff','--name-only','--diff-filter=U','-z').decode().strip('\0').split('\0'))-{''};assert unmerged<=allowed,unmerged
for p in unmerged-{'formal/system/requirements.json'}:(w/p).write_bytes(git('show',main+':'+p))
new=json.loads(git('show',main+':formal/system/requirements.json'));prior=json.loads(git('show',old+':formal/system/requirements.json'));own=next(x for x in prior['requirements'] if x['id']=='PAY-EVENT-REPORT-CURRENCY-001');assert len(new['requirements'])==160 and all(x['id']!=own['id'] for x in new['requirements']);new['requirements'].append(own);(w/'formal/system/requirements.json').write_text(json.dumps(new,indent=2,ensure_ascii=False)+'\n');subprocess.run(['git','add',*sorted(allowed)],cwd=w,check=True);assert not git('diff','--name-only','--diff-filter=U').strip()
owned={'tdf-hq/src/TDF/Server/SocialEventsHandlers.hs','tdf-hq/test/TDF/Social/FollowHandlerSpec.hs'}
for p in owned:assert (w/p).read_bytes()==git('show',old+':'+p)
assert set(git('diff','--name-only','-z',main,'--','tdf-hq').decode().strip('\0').split('\0'))==owned
for p in ['tdf-hq-ui','.github','scripts','ops','package.json','package-lock.json','tdf-mobile']:
 assert not git('diff','--name-only',main,'--',p).strip(),p
mobile=w/'tdf-mobile';assert not any(mobile.iterdir());r=run('mobile-clone',['git','clone','--shared','--no-checkout','/private/tmp/tdf-event-finance-currency-parent1ffa-20261030/tdf-mobile',str(mobile)],w);assert r.returncode==0,r.stdout;pin=git('rev-parse',main+':tdf-mobile').decode().strip();r=run('mobile-checkout',['git','checkout','--detach',pin],mobile);assert r.returncode==0,r.stdout
prep={'phase':'NORMAL_MERGE_STAGED_FOR_METADATA','baselineHead':old,'mainSha':actualmain,'parentHead':main,'baseMain':actualmain,'parents':[old,main],'branch':branch,'worktree':str(w),'mergeHadDerivedConflicts':bool(unmerged),'preparationDriverExit':0,'ownCurrencyRequirementExactOld':True,'all160NewParentNormsPreserved':True,'totalRequirements':161,'wholeBackendExactPreviousQualifiedHead':True,'uiAndAllNonownedFunctionalTreesExactParent':True,'mobile':pin,'unmergedDerivedPathsResolved':sorted(unmerged),'allNewFilesTrackedBeforeAudit':True,'startedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/'preparation-state.json').write_text(json.dumps(prep,indent=2)+'\n');print(json.dumps(prep),flush=True)
