import { readFileSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { observeTestChild, completedTestChild } from '/private/tmp/tdf-refund-inventory-live-20261102-2215/scripts/lib/test-child-completion.mjs';

const source = readFileSync('/private/tmp/tdf-refund-inventory-live-20261102-2215/scripts/run-music-release-worker-once.sh', 'utf8');
const original = source.match(/^heartbeat\(\) \{[\s\S]*?^\}/m)?.[0];
const stop = source.match(/^stop_heartbeat\(\) \{[\s\S]*?^\}/m)?.[0];
if (!original || !stop) throw new Error('Actual helper extraction failed');
const proposal = `
request_heartbeat_stop() {
  heartbeat_stopping=true
  if [ -n "$heartbeat_child" ]; then kill -TERM "$heartbeat_child" 2>/dev/null || true; fi
}
run_heartbeat_child() {
  [ "$heartbeat_stopping" = false ] || return 143
  "$@" <&0 &
  heartbeat_child=$!
  local heartbeat_child_status=0
  if [ "$heartbeat_stopping" = true ]; then kill -TERM "$heartbeat_child" 2>/dev/null || true; fi
  wait "$heartbeat_child" || heartbeat_child_status=$?
  if [ "$heartbeat_stopping" = true ]; then
    wait "$heartbeat_child" 2>/dev/null || true
    heartbeat_child=''
    return 143
  fi
  heartbeat_child=''
  return "$heartbeat_child_status"
}
heartbeat() {
  set +m
  local heartbeat_stopping=false heartbeat_child=''
  trap - EXIT USR1
  trap request_heartbeat_stop TERM INT
  while kill -0 "$$" 2>/dev/null; do
    run_heartbeat_child sleep "$heartbeat_seconds" || { [ "$heartbeat_stopping" = true ] && return 0; return 1; }
    [ "$heartbeat_stopping" = false ] || return 0
    if ! psql_db -c 'SELECT 1;' >/dev/null; then
      [ "$heartbeat_stopping" = false ] || return 0
      touch "$working_dir/lease-lost"
      kill -USR1 "$$" 2>/dev/null || true
      return 1
    fi
  done
}`;
const runtime = mkdtempSync(join(tmpdir(), 'tdf-owned-heartbeat-control-'));
const quote = value => `'${value.replaceAll("'", "'\\''")}'`;
const results = [];
const killGroup = pid => { if (pid > 0) { try { process.kill(-pid, 'SIGKILL'); } catch (e) { if (e.code !== 'ESRCH') throw e; } } };
try {
  for (const [variant, heartbeat] of [['original', original], ['proposal', proposal]]) {
    const observed = observeTestChild(spawn('/bin/bash', ['-c', `
set -euo pipefail
set -m
exec 4>&2
working_dir=${quote(runtime)}
psql_db() { return 0; }
${heartbeat}
${stop}
heartbeat_pid=''
heartbeat_seconds=5
# Controlled fault: the first group delivery reaches its leader but misses its
# descriptor-holding sleep. This models the missing-delivery fork race; it is
# not a claim that the live CI descriptor holder has already been identified.
kill() {
  if [ "$#" = 3 ] && [ "$1" = -TERM ] && [ "$2" = -- ]; then
    builtin kill -TERM "$heartbeat_pid"
  else builtin kill "$@"; fi
}
heartbeat &
heartbeat_pid=$!
printf 'HEARTBEAT_PID=%s\\n' "$heartbeat_pid"
sleep 0.1
stop_heartbeat
printf 'WORKER_DONE\\n'
`], { stdio: ['ignore', 'pipe', 'pipe'], detached: true, env: { PATH: '/usr/bin:/bin' } }));
    try {
      const outcome = await completedTestChild(observed, { timeoutMs: 500 });
      results.push({ variant, closed: true, status: outcome.status });
    } catch (error) { results.push({ variant, closed: false, snapshot: error.workerSnapshot }); }
    finally {
      if (observed.snapshot().processState !== 'closed') {
        killGroup(Number(observed.snapshot().stdout.match(/HEARTBEAT_PID=(\d+)/)?.[1]));
        killGroup(observed.child.pid);
        await completedTestChild(observed, { timeoutMs: 1500 });
      }
    }
  }
  writeFileSync('/Users/macpro/GitHub/tdf-app/.private/correctness-execution-20261102-2215/heartbeat-controlled-probe-results.json', JSON.stringify({ scope: 'Controlled first-signal miss; no PostgreSQL/network, owned groups only. Proposal has not changed product source. Production psql supervision still needs implementation and verification.', results }, null, 2) + '\n');
  console.log(JSON.stringify(results));
} finally { rmSync(runtime, { recursive: true, force: true }); }
