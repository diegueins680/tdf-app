import { readFileSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { observeTestChild, completedTestChild } from '/private/tmp/tdf-refund-inventory-live-20261102-2215/scripts/lib/test-child-completion.mjs';

const source = readFileSync('/private/tmp/tdf-refund-inventory-live-20261102-2215/scripts/run-music-release-worker-once.sh', 'utf8');
const heartbeat = source.match(/^heartbeat\(\) \{[\s\S]*?^\}/m)?.[0];
const stop = source.match(/^stop_heartbeat\(\) \{[\s\S]*?^\}/m)?.[0];
if (!heartbeat || !stop) throw new Error('Actual helper extraction failed');
const runtime = mkdtempSync(join(tmpdir(), 'tdf-owned-heartbeat-probe-'));
const results = [];
const signalGroup = (pid, signal) => {
  if (!Number.isSafeInteger(pid) || pid <= 0) return;
  try { process.kill(-pid, signal); } catch (e) { if (e.code !== 'ESRCH') throw e; }
};
try {
  for (let i = 0; i < 100; i++) {
    const observed = observeTestChild(spawn('/bin/bash', ['-c', `
set -euo pipefail
set -m
exec 4>&2
working_dir=${JSON.stringify(runtime)}
psql_db() { return 0; }
${heartbeat}
${stop}
heartbeat_pid=''
heartbeat_seconds=2
heartbeat &
heartbeat_pid=$!
printf 'HEARTBEAT_PID=%s\\n' "$heartbeat_pid"
sleep 0.00${i % 10}
stop_heartbeat
printf 'WORKER_DONE\\n'
`], { stdio: ['ignore', 'pipe', 'pipe'], detached: true, env: { PATH: '/usr/bin:/bin' } }));
    let group;
    try {
      await completedTestChild(observed, { timeoutMs: 200 });
      results.push({ i, closed: true, status: observed.child.exitCode });
    } catch (error) {
      results.push({ i, closed: false, snapshot: error.workerSnapshot });
    } finally {
      const output = observed.snapshot().stdout;
      group = Number(output.match(/HEARTBEAT_PID=(\d+)/)?.[1]);
      if (observed.snapshot().processState !== 'closed') {
        signalGroup(group, 'SIGTERM');
        signalGroup(observed.child.pid, 'SIGTERM');
        try { await completedTestChild(observed, { timeoutMs: 1000 }); }
        catch { signalGroup(group, 'SIGKILL'); signalGroup(observed.child.pid, 'SIGKILL'); await completedTestChild(observed, { timeoutMs: 1000 }); }
      }
    }
  }
  writeFileSync('/Users/macpro/GitHub/tdf-app/.private/correctness-execution-20261102-2215/heartbeat-probe-results.json', JSON.stringify({ scope: 'Actual helper excerpts, synthetic SQL no-op, owned processes only; macOS Bash3.2, scaled2s heartbeat and200ms completion diagnostic', results }, null, 2) + '\n');
  console.log(JSON.stringify({ cases: results.length, closed: results.filter(x => x.closed).length, failed: results.filter(x => !x.closed).length, failures: results.filter(x => !x.closed).slice(0, 3) }));
} finally { rmSync(runtime, { recursive: true, force: true }); }
