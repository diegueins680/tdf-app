                                , TicketRefundRequestUpdatedAt =. now
                                ]) envPool
                        unless (claimed == 1) $
                            throwError err409{errBody = "Refund request was already claimed or changed"}
                        result <- liftIO $ issueStripeRefund stripeCfg piId (ticketRefundRequestAmountCents refund)
                        case result of
                            Left err -> throwError err500{errBody = BL.fromStrict (TE.encodeUtf8 ("Stripe refund error: " <> err))}
                            Right refundResponse -> do
                                refundId <-
                                    eitherStripeServerError $
                                        parseStripeRefundResponse refundResponse
                                liftIO $
                                    runSqlPool
                                        ( do
                                            update
                                                refundKey
                                                [ TicketRefundRequestStatus =. "approved"
                                                , TicketRefundRequestApprovedByPartyId =. Just currentPartyId
                                                , TicketRefundRequestApprovedAt =. Just now
                                                , TicketRefundRequestStripeRefundId =. Just refundId
                                                , TicketRefundRequestProcessedAt =. Just now
                                                , TicketRefundRequestUpdatedAt =. now
                                                ]
                                            update orderKey [EventTicketOrderStatus =. "refunded", EventTicketOrderUpdatedAt =. now]
                                            updateWhere
                                                [EventTicketOrderRefId ==. orderKey]
                                                [EventTicketStatus =. "refunded", EventTicketUpdatedAt =. now]
                                            update
                                                (eventTicketOrderTierId order)
                                                [EventTicketTierQuantitySold +=. (negate (eventTicketOrderQuantity order))]
                                        )
                                        envPool
                                mUpdated <- liftIO $ runSqlPool (getEntity refundKey) envPool
                                maybe
                                    (throwError err500{errBody = "Could not approve refund"})
                                    (pure . refundEntityToDTO (eventTicketOrderCurrency order))
                                    mUpdated
                    _ -> throwError err500{errBody = "Cannot process refund: Stripe not configured or order has no payment intent"}

    rejectRefund :: T.Text -> T.Text -> RejectionReasonDTO -> AppM RefundDTO
    rejectRefund eventIdStr refundIdStr RejectionReasonDTO{..} = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        (eventKey, _) <- requireRefundManagedEvent eventIdStr
        refundKey <- parseKeyOr400 "refund" refundIdStr
        mRefund <- liftIO $ runSqlPool (get refundKey) envPool
        refund <- maybe (throwError err404{errBody = "Refund request not found"}) pure mRefund
        let orderKey = ticketRefundRequestOrderId refund
        mOrder <- liftIO $ runSqlPool (get orderKey) envPool
        order <- maybe (throwError err404{errBody = "Ticket order not found"}) pure mOrder
        when (eventTicketOrderEventId order /= eventKey) $
            throwError err400{errBody = "Refund does not belong to this event"}
        when (ticketRefundRequestStatus refund /= "pending") $
            throwError err409{errBody = "Refund request is not pending"}
        when (T.null (T.strip rrReason)) $
            throwError err400{errBody = "Rejection reason is required"}
        rejected <- liftIO $ trySynchronous $
            runSqlPool
                ( do
                    binding <- TicketRefund.loadTicketRefundReference refundKey
                    forM_ binding $ \ref -> TicketRefund.cancelTicketRefundAs user ref now
                    -- Recheck after a competing approval's row lock. Raising on
                    -- loss also rolls back any canonical cancellation above.
                    changed <- updateWhereCount
                        [ TicketRefundRequestId ==. refundKey
                        , TicketRefundRequestOrderId ==. orderKey
                        , TicketRefundRequestStatus ==. "pending"
                        ]
                        [ TicketRefundRequestStatus =. "rejected"
                        , TicketRefundRequestRejectionReason =. Just rrReason
                        , TicketRefundRequestUpdatedAt =. now
                        ]
                    unless (changed == 1) $ fail "Refund request is no longer pending"
                )
                envPool
        either (const (throwError err409{errBody = "Refund request is no longer pending"})) pure rejected
        mUpdated <- liftIO $ runSqlPool (getEntity refundKey) envPool
        maybe
            (throwError err500{errBody = "Could not reject refund"})
            (pure . refundEntityToDTO (eventTicketOrderCurrency order))
            mUpdated

    -- Manual bank transfer review
    listManualPayments :: T.Text -> AppM [TicketManualPaymentDTO]
    listManualPayments eventIdStr = do
        Env{..} <- ask
        (eventKey, _) <- requireRefundManagedEvent eventIdStr
        liftIO $ runSqlPool (ManualPayments.listTicketManualPayments eventKey) envPool

    reviewManualPayment :: T.Text -> T.Text -> TicketManualPaymentReviewDTO -> AppM TicketManualPaymentDTO
    reviewManualPayment eventIdStr orderIdStr TicketManualPaymentReviewDTO{..} = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        (eventKey, _) <- requireRefundManagedEvent eventIdStr
        orderKey <- parseKeyOr400 "order" orderIdStr
        action <- either (\msg -> throwError err400{errBody = BL.fromStrict (TE.encodeUtf8 msg)}) pure $
            ManualPayments.parseManualReviewAction tmprAction
        notes <- either (\msg -> throwError err400{errBody = BL.fromStrict (TE.encodeUtf8 msg)}) pure $
            ManualPayments.validateManualReviewNotes tmprNotes
        let reviewer =
                ManualPayments.ManualReviewer
                    { ManualPayments.mrPartyId = fromSqlKey (auPartyId user)
                    , ManualPayments.mrStrictAdmin = hasStrictAdminAccess user
                    }
        -- Approval and the idempotent issuance commit together; a failed
        -- issuance leaves the transfer reviewable instead of paid without tickets.
        outcome <- liftIO $ trySynchronous $
            runSqlPool
                ( ManualPayments.reviewTicketManualPayment reviewer eventKey orderKey action notes now
                    (void (finalizePaidTicketOrder now orderKey))
