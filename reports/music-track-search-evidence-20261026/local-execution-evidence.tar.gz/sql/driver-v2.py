from pathlib import Path
from datetime import datetime, timezone
import getpass, hashlib, json, os, socket, subprocess, tempfile

root = Path('/private/tmp/tdf-universal-music-search-20261026')
out = Path(tempfile.mkdtemp(prefix='tdf-track-search-sql-', dir='/private/tmp'))
pg = Path('/usr/local/opt/postgresql@16/bin')
node = Path('/private/tmp/tdf-node22-20261026/node-v22.14.0-darwin-x64/bin/node')
port = 55584
with socket.socket() as probe:
    probe.bind(('127.0.0.1', port))
env = {'PATH': f'{pg}:{node.parent}:/usr/local/bin:/usr/bin:/bin',
       'HOME': os.environ['HOME'], 'USER': getpass.getuser(),
       'LANG': 'en_US.UTF-8', 'TMPDIR': str(out), 'PGHOST': '127.0.0.1',
       'PGPORT': str(port), 'PGUSER': getpass.getuser(),
       'PGPASSFILE': str(out / 'absent-passfile'),
       'TDF_MUSIC_WORKER_TEST_DATABASE_URL':
       f'postgresql://{getpass.getuser()}@127.0.0.1:{port}/tdf_track_search_test'}
report = {'startedAt': datetime.now(timezone.utc).isoformat(), 'status': 'RUNNING',
          'scope': 'Owned PostgreSQL16, selected fourteen historical migrations and actual shipped SQL/bindings; no compiled HTTP, storage, production, or SLO claim.',
          'cleanup': {'clusterStopped': False, 'ownedDatabasesRemoved': False}, 'steps': []}
started = False

def save():
    (out / 'results.json').write_text(json.dumps(report, indent=2) + '\n')

def run(label, args, timeout=180):
    with (out / f'{label}.log').open('wb') as log:
        result = subprocess.run(args, cwd=root, env=env, stdout=log,
                                stderr=subprocess.STDOUT, timeout=timeout)
    report['steps'].append({'label': label, 'exitCode': result.returncode})
    save()
    assert result.returncode == 0, label

print(out, flush=True)
save()
try:
    report['driverSha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    report['runnerSha256'] = hashlib.sha256((root / 'scripts/test-music-track-search.mjs').read_bytes()).hexdigest()
    report['sourceRevision'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
    report['nodeVersion'] = subprocess.check_output([str(node), '--version'], text=True).strip()
    report['postgresVersion'] = subprocess.check_output([str(pg / 'pg_ctl'), '--version'], text=True).strip()
    run('initdb', [str(pg / 'initdb'), '-D', str(out / 'data'), '--auth=trust', '--encoding=UTF8', '--locale=en_US.UTF-8'])
    (out / 'socket').mkdir()
    run('start', [str(pg / 'pg_ctl'), '-D', str(out / 'data'), '-l', str(out / 'postgres.log'), '-o', f'-p {port} -h 127.0.0.1 -k {out / "socket"}', 'start'])
    started = True
    run('track-search-regressions', [str(node), 'scripts/test-music-track-search.mjs'])
    databases = subprocess.check_output([str(pg / 'psql'), '-XAtq', '-d', 'postgres', '-c', "SELECT datname FROM pg_database WHERE datname NOT IN ('postgres','template0','template1')"], env=env, text=True).strip()
    assert not databases, 'Unexpected leftover database on this exclusively owned cluster'
    report['cleanup']['ownedDatabasesRemoved'] = True
except BaseException as error:
    report['error'] = str(error)
    raise
finally:
    if started:
        try:
            remaining = subprocess.check_output([str(pg / 'psql'), '-XAtq', '-d', 'postgres', '-c', "SELECT count(*) FROM pg_database WHERE datname NOT IN ('postgres','template0','template1')"], env=env, text=True).strip()
            report['cleanup']['ownedDatabasesRemoved'] = remaining == '0'
        finally:
            run('stop', [str(pg / 'pg_ctl'), '-D', str(out / 'data'), '-m', 'fast', 'stop'])
            report['cleanup']['clusterStopped'] = True
    report['finishedAt'] = datetime.now(timezone.utc).isoformat()
    report['status'] = 'PASS' if not report.get('error') and all(report['cleanup'].values()) else 'FAILED'
    save()
    print(json.dumps({'status': report['status'], 'out': str(out), 'cleanup': report['cleanup']}), flush=True)
