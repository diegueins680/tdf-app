import { createRequire } from 'node:module';
import { writeFileSync, readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const require = createRequire('/private/tmp/tdf-universal-music-search-20261026/package.json');
const { chromium, expect } = require('@playwright/test');
const output = '/private/tmp/tdf-track-search-hosted-518c-20261027';
const entry = readFileSync(`${output}/preview-entry.js`);
if (!entry.includes(Buffer.from('518c860f449912aa9eaf9d65d4e8698d870058d4'))) throw new Error('Preview commit missing');
const receipt = { observedAt: new Date().toISOString(), featureHead: '518c860f449912aa9eaf9d65d4e8698d870058d4',
  preview: 'https://591066b7.tdf-app.pages.dev', entrySha256: createHash('sha256').update(entry).digest('hex'),
  source: 'Cloudflare bot exact commit plus fetched entry embeds full candidate SHA; not a source-build attestation',
  networkPolicy: 'No credentials or API fixtures; abort every non-GET/HEAD request; no Play, upload, login or mutation',
  cases: [], status: 'RUNNING' };
let browser;
try {
  browser = await chromium.launch({ headless: true });
  for (const viewport of [{ width: 1440, height: 1000 }, { width: 390, height: 844 }]) {
    const context = await browser.newContext({ locale: 'es-EC', viewport, serviceWorkers: 'block' });
    const page = await context.newPage();
    const item = { viewport, blockedMethods: [], musicResponses: [], errors: [] };
    receipt.cases.push(item);
    await page.route('**/*', async route => {
      const request = route.request();
      if (!['GET', 'HEAD'].includes(request.method())) {
        item.blockedMethods.push({ method: request.method(), host: new URL(request.url()).hostname, path: new URL(request.url()).pathname });
        await route.abort('blockedbyclient');
      } else await route.continue();
    });
    page.on('pageerror', error => item.errors.push(error.name + ': ' + error.message));
    page.on('response', response => {
      const url = new URL(response.url());
      if (url.pathname.endsWith('/music/search')) item.musicResponses.push({ host: url.hostname, path: url.pathname, status: response.status(), type: response.headers()['content-type'] });
    });
    const response = await page.goto(`${receipt.preview}/buscar?q=rock`, { waitUntil: 'domcontentloaded', timeout: 30000 });
    expect(response.status()).toBe(200);
    await expect(page.getByRole('heading', { name: 'Resultados musicales', exact: true })).toBeVisible({ timeout: 30000 });
    await expect(page.getByRole('button', { name: 'Reintentar búsqueda musical', exact: true })).toBeVisible({ timeout: 30000 });
    await expect(page.locator('h1')).toBeVisible();
    expect(item.errors).toEqual([]);
    item.audioElements = await page.locator('audio').count();
    expect(item.audioElements).toBeLessThanOrEqual(1);
    item.activeAudio = await page.locator('audio').evaluateAll(elements => elements.filter(audio => !audio.paused).length);
    expect(item.activeAudio).toBe(0);
    item.result = 'PASS: real deployed preview renders music-only unavailable state and keeps directory heading; no autoplay';
    await page.screenshot({ path: `${output}/preview-${viewport.width}.png`, fullPage: false });
    await context.close();
  }
  receipt.status = 'PASS';
} catch (error) {
  receipt.status = 'FAILED'; receipt.error = String(error); process.exitCode = 1;
} finally {
  await browser?.close();
  receipt.browserClosed = true;
  receipt.limits = ['Read-only anonymous preview UI smoke, not production deployment or upload/playback acceptance.',
    'Backend availability and authorization are observed, never bypassed; unavailable search is expected while the music API is inactive.',
    'Desktop and phone viewport use Chromium; no physical phone or WebKit execution is claimed here.'];
  writeFileSync(`${output}/preview-smoke.json`, JSON.stringify(receipt, null, 2) + '\n');
  console.log(JSON.stringify(receipt, null, 2));
}
