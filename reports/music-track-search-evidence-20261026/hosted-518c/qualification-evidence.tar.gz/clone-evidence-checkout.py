import ctypes, hashlib, json, os, pathlib, subprocess, datetime

libc = ctypes.CDLL(None, use_errno=True)
clone = libc.clonefile
clone.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int]
clone.restype = ctypes.c_int
source = pathlib.Path('/private/tmp/tdf-universal-music-search-20261026')
target = pathlib.Path('/private/tmp/tdf-track-search-ci-evidence-20261027')
records = []

for subdir, revision in [('', '518c860f449912aa9eaf9d65d4e8698d870058d4'), ('tdf-mobile', '8d69b011bd6c0dc7b0a9751c20ff9610dcc8b7bd')]:
    src, dst = source / subdir, target / subdir
    def git(root, *args):
        return subprocess.check_output(['git', *args], cwd=root)
    assert git(src, 'rev-parse', 'HEAD').decode().strip() == revision
    assert git(dst, 'rev-parse', 'HEAD').decode().strip() == revision
    assert git(src, 'diff', '--name-only', 'HEAD') == b''
    entries = git(src, 'ls-tree', '-rz', '--full-tree', revision).split(b'\0')
    count = size = 0
    for entry in entries:
        if not entry:
            continue
        header, name = entry.split(b'\t', 1)
        mode, kind, oid = header.split(b' ')
        if kind == b'commit':
            continue
        rel = os.fsdecode(name)
        old, new = src / rel, dst / rel
        new.parent.mkdir(parents=True, exist_ok=True)
        if mode == b'120000':
            assert old.is_symlink()
            if new.is_symlink():
                assert os.readlink(new) == os.readlink(old)
            else:
                assert not new.exists(), rel
                new.symlink_to(os.readlink(old))
        else:
            assert mode in [b'100644', b'100755'] and old.is_file() and not old.is_symlink(), rel
            if new.exists():
                assert new.is_file() and not new.is_symlink() and new.stat().st_size == old.stat().st_size, rel
            elif clone(os.fsencode(old), os.fsencode(new), 0):
                raise OSError(ctypes.get_errno(), 'APFS clonefile failed', rel)
            size += old.stat().st_size
        count += 1
    subprocess.run(['git', 'read-tree', 'HEAD'], cwd=dst, check=True)
    assert git(dst, 'diff', '--ignore-submodules=all', '--name-only', 'HEAD') == b''
    records.append({'repository': subdir or 'root', 'revision': revision, 'trackedFilesCloned': count, 'logicalBytesShared': size})

dep = (source / 'node_modules').resolve()
assert dep.is_dir()
assert subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], cwd=target) == b''
(target / 'node_modules').symlink_to(dep, target_is_directory=True)
receipt = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'method': 'macOS APFS clonefile for exact tracked regular files, native symlinks; no source/cache/dependency installs', 'target': str(target), 'repositories': records, 'originalAttempt': 'Standard git worktree checkout exited128 on ENOSPC while expanding historical media; Git automatically removed failed checkout; no product test failure', 'harnessCorrection': 'First COW attempt asserted parent source cleanliness before the detached Mobile checkout was populated; exit1 retained in tool output. Resume checks each repository independently, then the complete parent after both are populated.', 'status': 'PASS_OWN_COW_CHECKOUT_SOURCE_EQUIVALENCE'}
(pathlib.Path('/private/tmp/tdf-track-search-hosted-518c-20261027') / 'evidence-checkout.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
