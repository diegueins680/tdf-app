import base from '/private/tmp/tdf-universal-music-search-20261026/playwright.config.mjs';
const root = '/private/tmp/tdf-universal-music-search-20261026';
const artifacts = '/private/tmp/tdf-directory-search-regression-20261026';
export default {
  ...base,
  testDir: `${root}/e2e/web`,
  testMatch: [/directory-(entry|language)\.spec\.mjs$/],
  grep: /city storage denies getter|complete search and favorite recovery/,
  projects: base.projects.filter(project => ['chromium-desktop', 'chromium-phone', 'firefox-critical'].includes(project.name)),
  outputDir: `${artifacts}/test-results`,
  reporter: [['line'], ['json', { outputFile: `${artifacts}/results.json` }], ['html', { outputFolder: `${artifacts}/html`, open: 'never' }]],
  use: { ...base.use, baseURL: 'http://127.0.0.1:4189', serviceWorkers: 'block' },
  webServer: {
    ...base.webServer,
    cwd: root,
    command: 'npm run build:e2e --workspace=tdf-hq-ui && npm run preview:e2e --workspace=tdf-hq-ui -- --port 4189',
    url: 'http://127.0.0.1:4189/inicio',
    reuseExistingServer: false,
    env: { ...base.webServer.env, VITE_API_BASE: 'http://127.0.0.1:4189', VITE_TZ: 'America/Guayaquil' },
  },
};
