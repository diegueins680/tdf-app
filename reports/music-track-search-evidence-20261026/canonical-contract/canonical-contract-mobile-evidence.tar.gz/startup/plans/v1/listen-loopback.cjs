// Test-only server listener isolation. Expo/Metro and application sources stay unchanged.
'use strict';
const net = require('node:net');
const originalListen = net.Server.prototype.listen;
net.Server.prototype.listen = function (...args) {
  const first = args[0];
  if ((typeof first === 'string' && !/^\d+$/.test(first)) ||
      (first && typeof first === 'object' && 'path' in first && !('port' in first))) {
    return Reflect.apply(originalListen, this, args); // Owned Unix IPC remains available.
  }
  const port = first && typeof first === 'object' ? Number(first.port) : Number(first);
  if (port !== 8091) throw new Error(`Isolated Expo startup forbids TCP listen port ${port}`);
  if (first && typeof first === 'object') {
    args[0] = { ...first, host: '127.0.0.1' };
  } else {
    const options = { port: 8091, host: '127.0.0.1' };
    if (typeof args[1] === 'number') options.backlog = args[1];
    const callback = args.find(value => typeof value === 'function');
    args = callback ? [options, callback] : [options];
  }
  process.stderr.write('[tdf-expo-startup-guard] TCP8091 listen request constrained to127.0.0.1\n');
  return Reflect.apply(originalListen, this, args);
};
