#!/usr/bin/env python3
"""Prepared only: owned offline Expo/Metro startup; no app bundle/device/API check."""
from pathlib import Path
import datetime
import getpass
import hashlib
import json
import os
import re
import signal
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT = Path('/private/tmp/tdf-universal-music-search-20261026/tdf-mobile')
PLAN = Path('/private/tmp/tdf-mobile-expo-startup-plan-20261026')
NODE = Path('/private/tmp/tdf-node20-20261026/node-v20.19.4-darwin-x64/bin')
PORT = 8091
URL = 'http://127.0.0.1:8091/status'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def source_snapshot():
    paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')
    paths += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=ROOT).decode().split('\0')
    return {name: digest(ROOT / name) for name in sorted(set(paths)) if name and (ROOT / name).is_file() and not (ROOT / name).is_symlink()}

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None

assert not sys.flags.optimize and sys.platform == 'darwin'
review = json.loads((PLAN / 'review-manifest.json').read_text())
assert review['status'] == 'PREPARED_NOT_EXECUTED'
for path, expected in review['planSha256'].items():
    assert digest(PLAN / path) == expected, path
for path, expected in review['installedInputSha256'].items():
    assert digest(ROOT / path) == expected, path
assert (ROOT / '.nvmrc').read_text().strip() == '20.19.4'
assert json.loads((ROOT / 'package.json').read_text())['scripts']['start'] == 'expo start'
assert not subprocess.run(['lsof', '-tiTCP:8091', '-sTCP:LISTEN'], capture_output=True).stdout.strip(), 'Port occupied; never reuse'
with socket.socket() as probe:
    probe.bind(('127.0.0.1', PORT))

OUT = Path(tempfile.mkdtemp(prefix='tdf-mobile-expo-startup-run-', dir='/private/tmp'))
os.chmod(OUT, 0o700)
for child in ['home', 'tmp', 'cache']:
    (OUT / child).mkdir(mode=0o700)
(OUT / 'empty-npmrc').write_text('')
env = {'PATH': str(NODE) + ':/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin',
       'HOME': str(OUT / 'home'), 'USER': getpass.getuser(), 'LOGNAME': getpass.getuser(),
       'SHELL': '/bin/sh', 'TMPDIR': str(OUT / 'tmp') + '/', 'XDG_CACHE_HOME': str(OUT / 'cache'),
       'LANG': 'en_US.UTF-8', 'LC_CTYPE': 'en_US.UTF-8', 'TZ': 'America/Guayaquil',
       'CI': '1', 'EXPO_OFFLINE': '1', 'EXPO_NO_DOTENV': '1', 'EXPO_NO_TELEMETRY': '1',
       'NODE_OPTIONS': '--require=' + str(PLAN / 'listen-loopback.cjs'),
       'NPM_CONFIG_USERCONFIG': str(OUT / 'empty-npmrc'), 'NPM_CONFIG_GLOBALCONFIG': str(OUT / 'empty-npmrc')}
assert subprocess.check_output(['node', '--version'], env=env, text=True).strip() == 'v20.19.4'
before = source_snapshot()
profile = '(version 1)(allow default)(deny network-outbound)(allow network-outbound (remote tcp "localhost:8091"))(deny network-inbound)(allow network-inbound (local ip "localhost:8091"))'
command = ['sandbox-exec', '-p', profile, str(NODE / 'npm'), 'run', 'start', '--', '--localhost', '--port', '8091']
report = {'status': 'RUNNING', 'sourceHead': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
          'scope': 'Actual npm start/Expo/Metro with test-only loopback listen-argument guard; GET/status only. No bundle, app execution, device, API, EAS, signing, deployment or production claim.',
          'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'command': command,
          'planManifestSha256': digest(PLAN / 'review-manifest.json'), 'environmentKeys': sorted(env),
          'sourceBefore': before, 'cleanup': {}}
process = None
log = None
def save():
    (OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
print(OUT, flush=True)
try:
    # Positive control uses only this machine's temporary listener, never a remote host.
    lan = None
    for interface in ['en1', 'en0']:
        result = subprocess.run(['ipconfig', 'getifaddr', interface], capture_output=True, text=True)
        if result.returncode == 0:
            lan = result.stdout.strip()
            break
    assert lan, 'Require a local LAN address for isolation control'
    with socket.socket() as control:
        control.bind(('0.0.0.0', 0))
        control.listen(2)
        control_port = control.getsockname()[1]
        with socket.create_connection((lan, control_port), timeout=1):
            pass
        probe = 'import socket,sys\ntry:socket.create_connection((sys.argv[1],int(sys.argv[2])),timeout=1)\nexcept PermissionError:sys.exit(0)\nexcept OSError:sys.exit(3)\nelse:sys.exit(2)'
        result = subprocess.run(['sandbox-exec', '-p', profile, sys.executable, '-c', probe, lan, str(control_port)], env=env, capture_output=True, timeout=5)
        assert result.returncode == 0, 'Sandbox nonloopback denial not established'
    report['nonLoopbackEgressDeniedPositiveControl'] = True
    log = (OUT / 'expo-start.log').open('wb')
    process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    report['ownedProcessGroup'] = process.pid
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    deadline = time.monotonic() + 90
    ready = False
    while time.monotonic() < deadline:
        assert process.poll() is None, 'npm/Expo exited before readiness; preserve log'
        try:
            with opener.open(urllib.request.Request(URL, method='GET'), timeout=min(2, max(.01, deadline - time.monotonic()))) as response:
                body = response.read(4096).decode()
                assert response.status == 200 and body == 'packager-status:running'
                assert urllib.parse.unquote(response.headers.get('X-React-Native-Project-Root', '')) == str(ROOT)
                report['statusResponse'] = {'url': URL, 'method': 'GET', 'status': response.status, 'body': body, 'projectRoot': str(ROOT)}
                ready = True
                break
        except (OSError, urllib.error.URLError):
            time.sleep(.25)
    assert ready, 'Expo startup deadline90seconds'
    listening = subprocess.check_output(['lsof', '-nP', '-iTCP:8091', '-sTCP:LISTEN'], text=True)
    assert '127.0.0.1:8091' in listening and '*:8091' not in listening and '[::' not in listening and ':::8091' not in listening
    listener_pids = subprocess.check_output(['lsof', '-tiTCP:8091', '-sTCP:LISTEN'], text=True).split()
    assert listener_pids and all(os.getpgid(int(pid)) == process.pid for pid in listener_pids), 'Listener not owned by launched process group'
    try:
        with socket.create_connection((lan, PORT), timeout=1):
            raise AssertionError('Expo listener accessible via LAN')
    except OSError:
        pass
    report['listenerSnapshot'] = listening
    report['loopbackAndOwnedListenerConfirmed'] = True
    report['lanConnectionDenied'] = True
    report['status'] = 'STARTUP_READY_CLEANUP_PENDING'
except BaseException as failure:
    report.update(status='FAILED', failureType=type(failure).__name__, failure=str(failure)[:1500])
    raise
finally:
    if process is not None:
        for sig in [signal.SIGTERM, signal.SIGKILL]:
            try:
                os.killpg(process.pid, sig)
            except ProcessLookupError:
                pass
            stop_deadline = time.monotonic() + 10
            group_exists = True
            while time.monotonic() < stop_deadline:
                process.poll()  # Reap the direct npm child without assuming all descendants stopped.
                try:
                    os.killpg(process.pid, 0)
                except ProcessLookupError:
                    group_exists = False
                    break
                time.sleep(.1)
            if not group_exists:
                break
        report['cleanup']['ownedNpmProcessExited'] = process.poll() is not None
        report['cleanup']['ownedProcessGroupStopped'] = not group_exists
    if log is not None:
        log.close()
    report['cleanup']['portClosed'] = not subprocess.run(['lsof', '-tiTCP:8091', '-sTCP:LISTEN'], capture_output=True).stdout.strip()
    report['sourceAfter'] = source_snapshot()
    report['cleanup']['trackedAndKnownUntrackedSourceUnchanged'] = report['sourceAfter'] == before
    report['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    if report['status'] == 'STARTUP_READY_CLEANUP_PENDING':
        if all(report['cleanup'].values()):
            report['status'] = 'PASS_STARTUP_ONLY_WITH_LISTENER_ISOLATION_ADAPTER'
        else:
            report['status'] = 'FAILED_CLEANUP_OR_SOURCE_CHANGE'
    save()
    print(json.dumps({'status': report['status'], 'receipt': str(OUT / 'receipt.json')}), flush=True)
    if report['status'] != 'PASS_STARTUP_ONLY_WITH_LISTENER_ISOLATION_ADAPTER':
        raise SystemExit(1)
