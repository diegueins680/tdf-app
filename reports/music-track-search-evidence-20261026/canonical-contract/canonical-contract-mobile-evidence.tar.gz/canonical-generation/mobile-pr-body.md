Expose the authorized track-search contract in generated Mobile types: GET /music/search, searchPublicMusicTracks and two minimal hit/source schemas. Add105 lines with no deletions; all1,543 prior declaration members and531 canonical operation records remain unchanged. No app behavior, UI, package graph or media-engine changes.

Generated with openapi-typescript7.10.1 from the canonical path reference in [tdf-app#640](https://github.com/diegueins680/tdf-app/pull/640). Web and Mobile generated outputs are byte-identical. The parent pairs this Mobile commit with its web contract update.

Stacked on [#167](https://github.com/diegueins680/TDF-mobile/pull/167) at the already-pinned d832bb3057dd03d44c0f35eea05be9f36320429d, which includes current Mobile main80d57fd70341e45f2a4f94dd2607f321ebfd0400. Keep draft and reconcile/retarget after the dependency's normal protected integration. Do not merge into the dependency branch.

Local validation at generated-file SHA36e46d7af5ad300b8cfa91786439facf1daeb92b903571ab5d88f4476101564e:

- Both generation/freshness checks, installed Redocly lint/bundle, isolated strict types and full web app typecheck passed.
- Node20.19.4 Mobile release:check passed: assets, lint, full typecheck, release guards and Expo public configuration.
- Jest passed627 tests/97 suites with a clean owned HOME, no dotenv and network denied.
- Actual npm start/Metro returned its real GET /status readiness response. EXPO_OFFLINE=1 and a disclosed test-only listener guard constrained TCP8091 to IPv4 loopback; actual listener/process ownership, LAN denial, source preservation and cleanup passed. No app bundle or device was exercised.
- The first startup harness failed before npm/Expo because user/global npmrc shared a path. That original failure is retained; the succeeding run used separate blank config files. No application source or startup budget changed.

Reproduce in the matching parent checkout, using Node20.19.4 for Mobile app checks:

```sh
npm run generate:api
npm run release:check
npm test -- --runInBand --watch=false
EXPO_OFFLINE=1 EXPO_NO_DOTENV=1 npm run start -- --localhost --port8091
```

Installed Expo rejects --offline and --localhost together; offline mode is supplied by environment. Stock --localhost alone does not establish loopback-only binding; the local qualification used separate listener isolation.

Exact-head hosted Mobile Validate, Expo Doctor and independent review remain required. Physical-device, production API/upload, signing, EAS build and deployment validation remain unverified. Hash-bound raw evidence is being appended to the parent's track-search report.
