from pathlib import Path
import subprocess,os,json,hashlib,datetime,signal,getpass
root=Path('/private/tmp/tdf-universal-music-search-20261026/tdf-mobile')
out=Path('/private/tmp/tdf-music-search-mobile-quality-20261026')
(out/'home').mkdir(exist_ok=True)
nodebin='/private/tmp/tdf-node20-20261026/node-v20.19.4-darwin-x64/bin'
env={'PATH':nodebin+':/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin','HOME':str(out/'home'),'USER':getpass.getuser(),'LANG':'en_US.UTF-8','CI':'1','EXPO_NO_DOTENV':'1','EXPO_OFFLINE':'1','EAS_BUILD_PROFILE':'production','EXPO_PUBLIC_API_BASE':'https://api.tdfrecords.net','EXPO_PUBLIC_UPLOAD_URL':'https://api.tdfrecords.net/drive/upload','npm_config_cache':str(out/'npm-cache')}
profile='(version 1)(allow default)(deny network-outbound)(deny network-inbound)'
paths=['package.json','package-lock.json','src/api/generated/types.ts','AGENTS.md','.nvmrc']
before={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
assert before['src/api/generated/types.ts']=='36e46d7af5ad300b8cfa91786439facf1daeb92b903571ab5d88f4476101564e'
r={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceBefore':before,'node':subprocess.check_output([nodebin+'/node','--version'],text=True).strip(),'steps':[],'scope':'Actual Mobile checks on exact package+lock COW dependency copy, clean owned HOME/no dotenv, no network permitted. No native device or deployment claim.'}
assert r['node']=='v20.19.4'
def save():(out/'results.json').write_text(json.dumps(r,indent=2)+'\n')
save()
for label,args in [('release-check',['npm','run','release:check']),('jest',['npm','test','--','--runInBand','--watch=false'])]:
 with (out/(label+'.log')).open('wb') as log:
  p=subprocess.Popen(['sandbox-exec','-p',profile,*args],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=p.wait(timeout=900)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   code=124
 r['steps'].append({'label':label,'exitCode':code});save();print(label,code,flush=True)
r['sourceAfter']={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
assert r['sourceAfter']==before
r['status']='PASS' if all(s['exitCode']==0 for s in r['steps']) else 'FAILED_OR_BLOCKED_RETAIN_RAW_LOGS'
r['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
raise SystemExit(0 if r['status']=='PASS' else 1)
