INSERT INTO party(display_name,is_org,created_at) VALUES ('Music publication spec',FALSE,NOW());
CREATE OR REPLACE FUNCTION music_track_search_publishable(slug TEXT, recording_title TEXT, mode TEXT, reuse UUID) RETURNS TABLE(release_id UUID, version_id UUID) LANGUAGE plpgsql AS $$
DECLARE actor BIGINT; rid UUID; vid UUID; rec UUID; mp UUID; mr UUID; cr UUID; master UUID; cover UUID; rec2 UUID; master2 UUID; mr2 UUID; cr2 UUID;
BEGIN
  SELECT id INTO actor FROM party WHERE display_name='Music publication spec' ORDER BY id LIMIT 1;
  INSERT INTO music_release(artist_party_id,canonical_slug,release_kind,created_by) VALUES (actor,'music-spec-'||slug||'-'||gen_random_uuid(),'single',actor) RETURNING id INTO rid;
  INSERT INTO music_release_version(release_id,version_number,title,display_artist,explicit_content,recording_copyright_text,work_copyright_text,primary_genre_id,created_by)
    VALUES (rid,1,'Spec '||slug,'Spec Artist','not_explicit','℗ 2026 Spec','© 2026 Spec','ea0ee25a-326a-4174-9682-72d063caf6f9',actor) RETURNING id INTO vid;
  IF reuse IS NULL THEN INSERT INTO music_recording(canonical_title,duration_ms,explicit_content,created_by) VALUES (recording_title,180000,'not_explicit',actor) RETURNING id INTO rec; ELSE rec := reuse; END IF;
  INSERT INTO music_party(tdf_party_id,display_name,created_by) VALUES (actor,'Spec Artist',actor) ON CONFLICT DO NOTHING;
  SELECT id INTO mp FROM music_party WHERE tdf_party_id=actor;
  INSERT INTO music_release_track(release_version_id,recording_id,track_number,display_artist) VALUES (vid,rec,1,'Spec Artist');
  INSERT INTO music_credit(release_version_id,recording_id,music_party_id,credit_role) VALUES (vid,rec,mp,'main_artist'),(vid,rec,mp,'composer');
  INSERT INTO music_terms_acceptance(release_version_id,terms_kind,terms_version,accepted_by,evidence) VALUES (vid,'publication_authority','publication-v1',actor,'{"source":"music-publication-spec"}');
  INSERT INTO music_rights_declaration(release_version_id,recording_id,rights_scope,authority_basis,territories,starts_on,declared_by) VALUES (vid,rec,'master','owned',ARRAY['Worldwide'],'2026-09-11',actor) RETURNING id INTO mr;
  INSERT INTO music_rights_declaration(release_version_id,recording_id,rights_scope,authority_basis,territories,starts_on,declared_by) VALUES (vid,rec,'composition','licensed',ARRAY['Worldwide'],'2026-09-11',actor) RETURNING id INTO cr;
  INSERT INTO music_rights_split(declaration_id,rights_holder_id,basis_points,territories,starts_on) VALUES (mr,mp,10000,ARRAY['Worldwide'],'2026-09-11'),(cr,mp,10000,ARRAY['Worldwide'],'2026-09-11');
  INSERT INTO music_asset(release_version_id,recording_id,asset_role,storage_provider,storage_class,bucket_name,object_key,original_filename,media_type,byte_size,sha256,processing_state,immutable,created_by,ready_at)
    VALUES (vid,rec,'master_audio','local_private','standard','music-private','masters/'||vid||'/master.wav','master.wav','audio/wav',123456,encode(sha256((vid||'m')::bytea),'hex'),'ready',TRUE,actor,NOW()) RETURNING id INTO master;
  INSERT INTO music_asset(release_version_id,recording_id,parent_asset_id,asset_role,storage_provider,storage_class,bucket_name,object_key,media_type,byte_size,sha256,processing_state,immutable,created_by,ready_at)
    VALUES (vid,rec,master,'stream_audio','local_private','standard','music-private','derivatives/'||vid||'/stream.m4a','audio/mp4',65432,encode(sha256((vid||'s')::bytea),'hex'),'ready',TRUE,actor,NOW());
  INSERT INTO music_asset(release_version_id,asset_role,storage_provider,storage_class,bucket_name,object_key,original_filename,media_type,byte_size,sha256,processing_state,immutable,created_by,ready_at)
    VALUES (vid,'cover_original','local_private','standard','music-private','art/'||vid||'/cover.png','cover.png','image/png',23456,encode(sha256((vid||'c')::bytea),'hex'),'ready',TRUE,actor,NOW()) RETURNING id INTO cover;
  INSERT INTO music_asset(release_version_id,parent_asset_id,asset_role,storage_provider,storage_class,bucket_name,object_key,media_type,byte_size,sha256,processing_state,immutable,created_by,ready_at)
    VALUES (vid,cover,'cover_display','local_private','standard','music-private','art/'||vid||'/cover.webp','image/webp',12345,encode(sha256((vid||'d')::bytea),'hex'),'ready',TRUE,actor,NOW());
  INSERT INTO music_availability_rule(release_version_id,territories,listening_policy,download_policy,purchasable) VALUES (vid,CASE WHEN mode='mixed' OR mode='us' THEN ARRAY['US'] ELSE ARRAY['Worldwide'] END,CASE WHEN mode='preview' THEN 'preview' WHEN mode='none' THEN 'none' ELSE 'full' END,'none',FALSE);
  INSERT INTO music_release_version_party(release_version_id,music_party_id,party_details,details_source)
    VALUES (vid,mp,jsonb_build_object('displayName','Spec Artist','partyKind','person','identifiers','[]'::jsonb),'user_provided');

  UPDATE music_asset SET technical_metadata='{"bitrate_kbps":192,"loudness_lufs":-14.5,"object_key":"never-public","uploader":"private","nested":{"secret":true}}' WHERE release_version_id=vid AND asset_role='stream_audio';
  INSERT INTO music_asset(release_version_id,recording_id,parent_asset_id,asset_role,storage_provider,storage_class,bucket_name,object_key,media_type,byte_size,sha256,processing_state,immutable,technical_metadata,created_by,ready_at)
    VALUES (vid,rec,master,'stream_audio','local_private','standard','music-private','derivatives/'||vid||'/low.m4a','audio/mp4',32000,encode(sha256((vid||'low')::bytea),'hex'),'ready',TRUE,'{"bitrate_kbps":"96","loudness_lufs":false,"sensitive":"excluded"}',actor,NOW());
  INSERT INTO music_asset(release_version_id,recording_id,parent_asset_id,asset_role,storage_provider,storage_class,bucket_name,object_key,media_type,byte_size,sha256,processing_state,immutable,technical_metadata,created_by,ready_at)
    VALUES (vid,rec,master,'preview_audio','local_private','standard','music-private','derivatives/'||vid||'/preview.m4a','audio/mp4',16000,encode(sha256((vid||'preview')::bytea),'hex'),'ready',TRUE,jsonb_build_object('preview',music_preview_spec(180000,NULL,NULL)),actor,NOW()),
      (vid,rec,master,'preview_audio','local_private','standard','music-private','derivatives/'||vid||'/stale.m4a','audio/mp4',8000,encode(sha256((vid||'stale')::bytea),'hex'),'ready',TRUE,'{"preview":{"startMs":0,"durationMs":1234,"selection":"explicit"}}',actor,NOW()),
      (vid,rec,master,'stream_audio','local_private','standard','music-private','derivatives/'||vid||'/pending.m4a','audio/mp4',8000,encode(sha256((vid||'pending')::bytea),'hex'),'processing',FALSE,'{}',actor,NULL);
  IF mode='album' OR mode='mixed' THEN
    UPDATE music_availability_rule SET release_track_id=(SELECT id FROM music_release_track WHERE release_version_id=vid AND recording_id=rec) WHERE release_version_id=vid;
    INSERT INTO music_recording(canonical_title,duration_ms,explicit_content,created_by) VALUES ('B Canción nocturna',180000,'not_explicit',actor) RETURNING id INTO rec2;
    INSERT INTO music_release_track(release_version_id,recording_id,track_number,display_artist) VALUES (vid,rec2,2,'Guest Artist');
    INSERT INTO music_credit(release_version_id,recording_id,music_party_id,credit_role) VALUES (vid,rec2,mp,'main_artist'),(vid,rec2,mp,'composer');
    INSERT INTO music_rights_declaration(release_version_id,recording_id,rights_scope,authority_basis,territories,starts_on,declared_by) VALUES (vid,rec2,'master','owned',ARRAY['Worldwide'],'2026-09-11',actor) RETURNING id INTO mr2;
    INSERT INTO music_rights_declaration(release_version_id,recording_id,rights_scope,authority_basis,territories,starts_on,declared_by) VALUES (vid,rec2,'composition','licensed',ARRAY['Worldwide'],'2026-09-11',actor) RETURNING id INTO cr2;
    INSERT INTO music_rights_split(declaration_id,rights_holder_id,basis_points,territories,starts_on) VALUES (mr2,mp,10000,ARRAY['Worldwide'],'2026-09-11'),(cr2,mp,10000,ARRAY['Worldwide'],'2026-09-11');
    INSERT INTO music_asset(release_version_id,recording_id,asset_role,storage_provider,storage_class,bucket_name,object_key,original_filename,media_type,byte_size,sha256,processing_state,immutable,created_by,ready_at)
      VALUES (vid,rec2,'master_audio','local_private','standard','music-private','masters/'||vid||'/companion.wav','companion.wav','audio/wav',123456,encode(sha256((vid||'cm')::bytea),'hex'),'ready',TRUE,actor,NOW()) RETURNING id INTO master2;
    INSERT INTO music_asset(release_version_id,recording_id,parent_asset_id,asset_role,storage_provider,storage_class,bucket_name,object_key,media_type,byte_size,sha256,processing_state,immutable,created_by,ready_at)
      VALUES (vid,rec2,master2,'stream_audio','local_private','standard','music-private','derivatives/'||vid||'/companion.m4a','audio/mp4',65432,encode(sha256((vid||'cs')::bytea),'hex'),'ready',TRUE,actor,NOW());
    INSERT INTO music_availability_rule(release_version_id,release_track_id,territories,listening_policy,download_policy,purchasable)
      SELECT vid,id,ARRAY['EC'],'full','none',FALSE FROM music_release_track WHERE release_version_id=vid AND recording_id=rec2;
  END IF;
  IF mode='blank' THEN UPDATE music_release_track SET display_artist='' WHERE release_version_id=vid; END IF;
  IF mode='missing' THEN
    UPDATE music_asset SET processing_state='processing',ready_at=NULL WHERE release_version_id=vid AND asset_role IN ('stream_audio','preview_audio');
    PERFORM music_refresh_validation_flags(vid);
    RETURN QUERY SELECT rid,vid;
    RETURN;
  END IF;
  PERFORM music_refresh_validation_flags(vid);
  UPDATE music_release_version SET immutable_snapshot=jsonb_build_object('version',vid), snapshot_sha256=encode(sha256(vid::text::bytea),'hex') WHERE id=vid;
  UPDATE music_release_version SET state='ready_for_review' WHERE id=vid;
  UPDATE music_release_version SET state='in_review' WHERE id=vid;
  UPDATE music_release_version SET state='approved',approved_by=actor,approved_at=NOW() WHERE id=vid;
  RETURN QUERY SELECT rid, vid;
END $$;
