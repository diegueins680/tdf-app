import base from '/private/tmp/tdf-universal-music-search-20261026/playwright.config.mjs';
const root = '/private/tmp/tdf-universal-music-search-20261026';
const artifacts = '/private/tmp/tdf-directory-legacy-fixed-results-20261027';
const welcome = /welcome and direct search stay accessible without overflow at 320 pixels/;
const both = /PW-PER-01-DISCOVERY completes public city discovery and preserves search state|welcome and direct search stay accessible without overflow at 320 pixels/;
export default {
  ...base,
  testDir: `${root}/e2e/web`,
  testMatch: [/persona-public\.spec\.mjs$/, /public-welcome\.spec\.mjs$/],
  projects: base.projects.map(project => ({ ...project, grep: ['chromium-desktop', 'chromium-phone', 'chromium-tablet'].includes(project.name) ? both : welcome })),
  outputDir: `${artifacts}/test-results`,
  reporter: [['line'], ['json', { outputFile: `${artifacts}/results.json` }], ['html', { outputFolder: `${artifacts}/html`, open: 'never' }]],
  use: { ...base.use, baseURL: 'http://127.0.0.1:4189', serviceWorkers: 'block' },
  webServer: {
    ...base.webServer,
    cwd: root,
    command: 'npm run build:e2e --workspace=tdf-hq-ui && npm run preview:e2e --workspace=tdf-hq-ui -- --port 4189',
    url: 'http://127.0.0.1:4189/inicio',
    reuseExistingServer: false,
    env: { ...base.webServer.env, VITE_API_BASE: 'http://127.0.0.1:4189', VITE_TZ: 'America/Guayaquil' },
  },
};
