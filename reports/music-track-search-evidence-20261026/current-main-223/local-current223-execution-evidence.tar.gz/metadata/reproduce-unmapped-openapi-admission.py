from pathlib import Path
import importlib.util,json,subprocess,sys
sys.path.insert(0,str(Path('scripts').resolve()))
s=importlib.util.spec_from_file_location('gate','scripts/check-new-specification-surfaces.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
b=json.loads(Path('/private/tmp/tdf-track-search-parent-refresh-20261026/before.json').read_text());req=json.loads(Path('formal/system/requirements.json').read_text())['requirements'];req=[b['unchangedOwnTrackRequirement']if r['id']=='MEDIA-MUSIC-TRACK-SEARCH-001'else r for r in req]
t=json.loads(Path('formal/system/traceability.json').read_text());target='tdf-hq/docs/openapi/music-search.yaml'
for row in t['surfaces']:
 if row['path']==target:row['requirements']=[]
paths=subprocess.check_output(['git','diff','--name-only','--diff-filter=AMT',b['refreshedParent'],'--']).decode().splitlines()
m.validate_changed_paths(paths,t,req,lambda p:Path(p).read_bytes())
