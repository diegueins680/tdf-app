{-# LANGUAGE DataKinds #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RecordWildCards #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TypeOperators #-}
{-# OPTIONS_GHC -Werror=incomplete-patterns #-}

module TDF.Server.SocialEventsHandlers (
    publicUpcomingEventsServer,
    collectMatchingRows,
    decodeTicketAcceptedTermsVersion,
    encodeTicketCheckoutMetadata,
    ticketPlatformFeeBreakdown,
    ticketTermsAcceptance,
    replaceLogisticsActivityDependencies,
    socialEventsServer,
    socialEventsServerWithStripeRefund,
    stripeWebhookServer,
    validateRsvpPageLimit,
    decodeRsvpCursor,
    validateInvitationToPartyId,
    validateInvitationFromPartyId,
    validateInvitationStatusInput,
    validateInvitationStatusUpdateInput,
    validateInvitationUpdateAuthorization,
    normalizeInvitationStatus,
    normalizeArtistGenres,
    parseInvitationIdsEither,
    parseVenueIdEither,
    parseFollowerQueryParamEither,
    parseNearQueryEither,
    followArtistDb,
    normalizeTicketOrderStatus,
    ticketOrderInventoryAdjustment,
    validateDirectTicketOrderPricing,
    validateTicketPurchaseEventEligibility,
    eventTicketPurchaseEnabledFor,
    isTicketTierSaleOpen,
    issueMissingTicketsForOrder,
    finalizePaidTicketOrder,
    sendTicketConfirmationForOrder,
    sendTicketConfirmationForOrderIO,
    normalizeTicketStatus,
    EventMetadataDTO (..),
    decodeStoredEventMetadata,
    validateEventMetadataUpdate,
    validateEventMetadataUrlField,
    validateBudgetLineTypeInput,
    normalizeBudgetLineType,
    normalizeFinanceDirection,
    normalizeFinanceSource,
    normalizeFinanceEntryStatus,
    validateFinanceEntryCurrencyInput,
    validateOptionalBudgetLineIdInput,
    validateStoredBudgetLineDimensions,
    validateStoredFinanceEntryDimensions,
    validateStoredEventFinanceMetadata,
    normalizePositivePartyIdText,
    resolveExistingPartyIdText,
    resolveUniqueRsvpRow,
    validateEventArtistIds,
    toggleMomentReactionDb,
    redactMomentReactionIdentity,
    normalizeMomentMediaType,
    normalizeMomentCaption,
    normalizeMomentCommentBody,
    normalizeLiveBroadcastTitle,
    normalizeLiveBroadcastDescription,
    normalizeLiveBroadcastQuality,
    validateMomentMediaDimension,
    validateMomentMediaDuration,
    validateEventCreateUpdateDimensions,
    validateSocialEventsListOffset,
    validateSocialEventsListFilter,
    validateArtistPartyIdFilter,
    postgresVisibleImportedMetadataClause,
    validateDiscoverySourceWrite,
    validateVenueCreateUpdateFields,
    validateEventCurrencyInput,
    TicketCheckInLookup (..),
    validateTicketCheckInLookup,
    validateStoredTicketOrderStatus,
    validateTicketCheckInOrderStatus,
    validateTicketCheckInTicketStatus,
    storedTicketOrderSummaryFields,
    ticketOrderAccountingEntriesEither,
    findTicketForCheckIn,
    validateOptionalTicketBuyerPartyId,
    validateTicketPurchaseBuyerName,
    validateTicketPurchaseBuyerEmail,
    validateTicketTierCodeInput,
    validateTicketTierCurrencyInput,
    encodePromoCodeTierIds,
    decodeStoredPromoCodeTierIds,
    validatePromoCodeDateWindow,
    validatePromoCodeRedemptionLimit,
    validatePromoCodeTierEligibility,
    validatePromoCodeMinimumPurchaseParam,
    validatePromoCodeMinimumPurchaseCents,
    promoCodeDiscountAmountEither,
    validateTicketCheckoutAmount,
    isImageUpload,
    validateEventImageUploadSize,
    validMomentMediaSignature,
    validateEventTitleInput,
    validateEventTimeRange,
    validateArtistName,
    validateSocialEventsFeatureAction,
    validateArtistProfileCreateParty,
    validateArtistProfileWriteAccess,
    validateAuthenticatedPartyReference,
    validateEventDeleteAccess,
    requireEventManager,
    assignMissingEventOrganizer,
    validateEventDeletionCheckoutHistory,
    removeSocialEventAssets,
    suppressImportedEventMetadata,
    parseStripePaymentIntentResponse,
    parseStripeWebhookEventEnvelope,
    verifyAndDecodeStripeWebhook,
    parseStripeWebhookPaymentIntentId,
    StripeTicketPaymentEvidence (..),
    parseStripeTicketPaymentEvidence,
    validateStripeTicketPaymentEvidence,
    parseStripeWebhookMarketplaceOrderId,
    canRecoverMarketplaceStripeOrder,
    parseCheckoutSessionCourseSubscription,
    parseSubscriptionEvent,
    parseStripeRefundResponse,
    parseStripeCustomerId,
    parseStripeEphemeralKeySecret,
    resolveStripeCustomerForBuyer,
    eitherStripeServerError,
) where

import Control.Applicative ((<|>))
import Control.Exception (IOException, SomeAsyncException, SomeException, fromException, throwIO, try)
import Control.Monad (filterM, forM, forM_, join, unless, void, when)
import Control.Monad.Except (catchError)
import Control.Monad.IO.Class (MonadIO, liftIO)
import Control.Monad.Reader (ReaderT, ask)
import qualified TDF.Interactions.Legacy as Interactions
import qualified TDF.Interactions.Server as Interactions
import qualified TDF.Services.EventDiscovery as EventDiscoveryOwnership
import qualified Data.Aeson as Aeson
import qualified Data.Aeson.Key as AesonKey
import qualified Data.Aeson.KeyMap as AesonKeyMap
import Data.Aeson.Types (Object, Parser, parseMaybe)
import qualified Data.ByteString.Char8 as BS8
import qualified Data.ByteString as BS
import qualified Data.ByteString.Lazy as BL
import qualified Data.ByteString.Base64.URL as B64URL
import Data.Char (
    GeneralCategory (Format, LineSeparator, ParagraphSeparator),
    generalCategory,
    isAlphaNum,
    isAscii,
    isAsciiLower,
    isAsciiUpper,
    isControl,
    isDigit,
    isHexDigit,
 )
import Data.Int (Int64)
import Data.List (nub, sortOn)
import qualified Data.Map.Strict as Map
import Data.Maybe (catMaybes, fromMaybe, isJust, isNothing, listToMaybe, mapMaybe)
import Data.Ord (Down (..))
import qualified Data.Set as Set
import qualified Data.Text as T
import qualified Data.Text.Encoding as TE
import Data.Time (UTCTime, diffUTCTime, getCurrentTime, utctDay)
import Data.Time.Format (defaultTimeLocale, formatTime)
import Data.Time.Format.ISO8601 (iso8601ParseM)
import qualified Data.UUID as UUID
import qualified Data.UUID.V4 as UUIDV4
import System.Directory (copyFile, createDirectoryIfMissing, doesDirectoryExist, getFileSize, removePathForcibly)
import System.Environment (lookupEnv)
import System.FilePath (takeExtension, takeFileName, (</>))
import System.IO (hPutStrLn, stderr)
import Text.Printf (printf)
import Text.Read (readMaybe)
import Web.PathPieces (fromPathPiece)

import Servant
import Servant.Multipart (FileData (..))

-- Pull in full Persistent surface so TH-generated field constructors
-- (EventRsvpEventId, SocialEventStartTime, etc.) are available.
import Database.Persist
import Database.Persist.Sql
    ( ConnectionPool
    , FilterTablePrefix (PrefixTableName)
    , IsolationLevel (ReadCommitted)
    , Single (..)
    , SqlBackend
    , SqlPersistT
    , filterClauseWithVals
    , fromSqlKey
    , orderClause
    , rawExecute
    , rawSql
    , runSqlPool
    , runSqlPoolWithIsolation
    , toSqlKey
    , updateWhereCount
    )
import Database.Persist.SqlBackend
    ( getConnLimitOffset
    , getEscapedRawName
    , getRDBMS
    )
import Database.PostgreSQL.Simple (SqlError (..))

import Data.Time.Clock (addUTCTime)
import TDF.API.SocialEventsAPI
import qualified TDF.Ticketing.Admission as Admission
import qualified TDF.Ticketing.Refund as TicketRefund
import qualified TDF.Server.TicketManualPayments as ManualPayments
import qualified TDF.Server.TicketPaymentReceipt as Receipt
import qualified TDF.Server.TicketTaxDocuments as TaxDocuments
import qualified TDF.Server.TicketRefunds as TicketRefunds
import qualified TDF.Ticketing.Transfer as Transfer
import qualified TDF.Server.EventResearch as EventResearch
import TDF.Auth (AuthedUser (..), hasStrictAdminAccess, moduleName, withCurrentAuthSession)
import qualified TDF.Catalog.Models as Catalog
import TDF.Config (AppConfig (..), EmailConfig, assetsRootDir, resolveConfiguredAssetsBase)
import TDF.Internationalization (normalizeCurrencyCode)
import TDF.DB (Env (..))
import TDF.FeatureRegistry (findRegistryFeature, registryFeatureAllows)
import TDF.DTO.SocialEventsDTO (
    ArtistDTO (..),
    ArtistFollowRequest (..),
    ArtistFollowerDTO (..),
    ArtistSocialLinksDTO (..),
    EventBudgetLineDTO (..),
    EventCityDTO (..),
    EventCityInputDTO (..),
    EventCitySubscriptionUpdateDTO (..),
    DiscoverySourceDTO (..),
    DiscoverySourceWriteDTO (..),
    EventDTO (..),
    PublicUpcomingEventDTO (..),
    EventFinanceEntryDTO (..),
    EventFinanceSummaryDTO (..),
    EventLogisticsActivityDTO (..),
    EventLogisticsAssignmentDTO (..),
    EventLogisticsMemberDTO (..),
    EventLogisticsPlaceDTO (..),
    EventLogisticsPlanDTO (..),
    EventLogisticsSettingsDTO (..),
    EventRouteVerificationDTO (..),
    EventScheduleIssueDTO (..),
    EventLiveBroadcastCreateDTO (..),
    EventLiveBroadcastDTO (..),
    EventLiveBroadcastEndDTO (..),
    EventLiveBroadcastHeartbeatDTO (..),
    EventMetadataUpdateDTO (..),
    EventMomentCommentCreateDTO (..),
    EventMomentCommentDTO (..),
    EventMomentCreateDTO (..),
    EventMomentEditDTO (..),
    EventMomentDTO (..),
    EventMomentReactionDTO (..),
    EventMomentReactionRequestDTO (..),
    EventSourceDTO (..),
    EventUpdateDTO (..),
    InvitationDTO (..),
    InvitationUpdateDTO (..),
    NullableFieldUpdate (..),
    PaymentSheetParamsDTO (..),
    PromoCodeDTO (..),
    RefundDTO (..),
    RefundRequestDTO (..),
    RejectionReasonDTO (..),
    TicketManualPaymentDTO (..),
    TicketManualPaymentReviewDTO (..),
    TicketTaxDocumentDTO (..),
    BankRefundCompletionDTO (..),
    RsvpCreateDTO (..),
    RsvpDTO (..),
    RsvpSummaryDTO (..),
    RsvpFeedItemDTO (..),
    RsvpFeedPageDTO (..),
    RsvpAdminDTO (..),
    RsvpAdminPageDTO (..),
    StripePaymentIntentDTO (..),
    TicketCheckInRequestDTO (..),
    TicketDTO (..),
    TicketOrderDTO (..),
    TicketOrderStatusUpdateDTO (..),
    TicketPurchaseRequestDTO (..),
    TicketPurchaseWithPromoDTO (..),
    TicketTierDTO (..),
    TicketTransferCreateDTO (..),
    TicketTransferDTO (..),
    TicketWithQRDTO (..),
    VenueContactUpdateDTO (..),
    VenueDTO (..),
    VenueUpdateDTO (..),
    WaitlistEntryDTO (..),
    WaitlistJoinDTO (..),
 )
import qualified TDF.Email as Email
import TDF.Models
    ( EngagementEvent (..)
    , EntityField
        ( PartyStripeCustomerId
        , EngagementEventActorPartyId
        , EngagementEventEntityType
        , EngagementEventEntityId
        , EngagementEventEventType
        , EngagementEventMetadata
        , EngagementEventCreatedAt
        )
    , Party (..)
    , PartyId
    )
import TDF.Models.SocialEventsModels hiding (venueAddress, venueCapacity, venueCity, venueContact, venueCountry, venueCreatedAt, venueName, venueUpdatedAt)
import qualified TDF.Models.SocialEventsModels as SM
import qualified TDF.Profiles.Artist as ArtistProfiles
import qualified TDF.ModelsExtra as ME
import qualified TDF.SocialEventLifecycle as EventLifecycle
import TDF.ServerRadio (nativeBroadcastUnavailable)
import qualified TDF.Services.Stripe as Stripe
import TDF.Services.EventLogisticsRoutes
    ( RouteEstimateInput (..)
    , RouteEstimateResult (..)
    , computeGoogleRoute
    )
import qualified TDF.Trials.Server as TrialsServer (isValidHttpUrl)

type AppM = ReaderT Env Handler

publicUpcomingEventsServer :: Maybe T.Text -> Maybe T.Text -> Maybe UTCTime -> Maybe Int -> AppM [PublicUpcomingEventDTO]
publicUpcomingEventsServer mCity mArtistPartyId mStartAfter mLimit = do
    Env{..} <- ask
    now <- liftIO getCurrentTime
    -- Artist profile carousels read through this public projection so every
    -- anonymous-listing predicate (public-listable state, public metadata and
    -- no suppressed external reference) applies to them as well.
    artistPartyFilter <- either throwError pure (validateArtistPartyIdFilter mArtistPartyId)
    let startAfter = fromMaybe now mStartAfter
        limit = min 200 (max 1 (fromMaybe 50 mLimit))
    liftIO $
        runSqlPool
            ( do
                rows <- selectPublicUpcomingSocialEvents mCity artistPartyFilter startAfter limit
                catMaybes
                    <$> mapM
                        (\(eventEntity, Single canonicalCity) ->
                            publicUpcomingEventRow canonicalCity eventEntity
                        )
                        rows
            )
            envPool

-- Apply every anonymous-listing predicate before LIMIT. In particular, city
-- and lifecycle eligibility must not be evaluated by recursively loading the
-- complete future-event table when a city has few or no matches.
selectPublicUpcomingSocialEvents ::
    Maybe T.Text ->
    Maybe T.Text ->
    UTCTime ->
    Int ->
    SqlPersistT IO [(Entity SocialEvent, Single (Maybe T.Text))]
selectPublicUpcomingSocialEvents mCity mArtistPartyId startAfter limit = do
    eventTable <- getEscapedRawName "social_event"
    eventIdField <- getEscapedRawName "id"
    eventStartField <- getEscapedRawName "start_time"
    eventMetadataField <- getEscapedRawName "metadata"
    publicEventView <- getEscapedRawName "directory_public_event"
    eventArtistTable <- getEscapedRawName "event_artist"
    artistProfileTable <- getEscapedRawName "social_artist_profile"
    backendName <- T.toCaseFold <$> getRDBMS
    let eventIdColumn = eventTable <> "." <> eventIdField
        -- Exact Party equality through the event/artist link; the view above
        -- already restricts the candidate events, so this only narrows them.
        (artistClause, artistValues) = case mArtistPartyId of
            Nothing -> ("", [])
            Just partyIdText ->
                ( " AND EXISTS (SELECT 1 FROM "
                    <> eventArtistTable
                    <> " AS artist_link INNER JOIN "
                    <> artistProfileTable
                    <> " AS artist_profile ON artist_profile.id=artist_link.artist_id WHERE artist_link.event_id="
                    <> eventIdColumn
                    <> " AND artist_profile.party_id=?)"
                , [PersistText partyIdText]
                )
        eventStartColumn = eventTable <> "." <> eventStartField
        eventMetadataColumn = eventTable <> "." <> eventMetadataField
        metadataClause = visibleImportedMetadataClause backendName eventMetadataColumn
        (cityClause, cityValues) = case mCity of
            Nothing -> ("", [])
            Just rawCity ->
                let matchClause
                        | "postgres" `T.isInfixOf` backendName =
                            "position(lower(?) in lower(directory_event.city_name))>0"
                        | "sqlite" `T.isInfixOf` backendName =
                            "instr(lower(directory_event.city_name),lower(?))>0"
                        | otherwise = "1=0"
                 in ( " AND directory_event.city_name IS NOT NULL AND " <> matchClause
                    , [PersistText (T.strip rawCity)]
                    )
        orderedQuery =
            "SELECT ??,directory_event.city_name FROM "
                <> eventTable
                <> " INNER JOIN "
                <> publicEventView
                <> " AS directory_event ON directory_event.id="
                <> eventIdColumn
                <> " WHERE "
                <> eventStartColumn
                <> ">=? AND "
                <> metadataClause
                <> cityClause
                <> artistClause
                <> " ORDER BY "
                <> eventStartColumn
                <> " ASC,"
                <> eventIdColumn
                <> " ASC"
    query <- getConnLimitOffset (limit, 0) orderedQuery
    rawSql query (toPersistValue startAfter : cityValues ++ artistValues)

collectMatchingRows ::
    Monad m =>
    Int ->
    Int ->
    (Int -> Int -> m [a]) ->
    (a -> m (Maybe b)) ->
    m [b]
collectMatchingRows requestedLimit requestedPageSize loadPage matchRow
    | requestedLimit <= 0 = pure []
    | otherwise = go 0 []
  where
    pageSize = max 1 requestedPageSize

    go offset matches
        | length matches >= requestedLimit = pure (take requestedLimit matches)
        | otherwise = do
            rows <- loadPage pageSize offset
            pageMatches <- catMaybes <$> mapM matchRow rows
            let nextMatches = matches <> pageMatches
            if length rows < pageSize
                then pure (take requestedLimit nextMatches)
                else go (offset + length rows) nextMatches

publicUpcomingEventRow :: Maybe T.Text -> Entity SocialEvent -> SqlPersistT IO (Maybe PublicUpcomingEventDTO)
publicUpcomingEventRow canonicalCity (Entity eventKey eventRow) = do
    metadataResult <- pure (decodeStoredEventMetadata (socialEventMetadata eventRow))
    venue <- maybe (pure Nothing) get (socialEventVenueId eventRow)
    case (metadataResult, socialEventWorkflowStateId eventRow) of
        (Right metadata, Just workflowStateId) -> do
            workflow <- EventLifecycle.loadActiveSocialEventState workflowStateId
            publicListable <- EventLifecycle.socialEventStateHasCapability workflowStateId "public-listable"
            let city = canonicalCity
            pure $
                if publicListable && emIsPublic metadata /= Just False
                    then do
                        (stateCode, _, _) <- workflow
                        Just PublicUpcomingEventDTO
                            { publicUpcomingEventId = renderKeyText eventKey
                            , publicUpcomingEventTitle = socialEventTitle eventRow
                            , publicUpcomingEventDescription = socialEventDescription eventRow
                            , publicUpcomingEventStart = socialEventStartTime eventRow
                            , publicUpcomingEventEnd = socialEventEndTime eventRow
                            , publicUpcomingEventTimezone = socialEventTimezone eventRow
                            , publicUpcomingEventVenueName = SM.venueName <$> venue
                            , publicUpcomingEventCity = city
                            , publicUpcomingEventPriceCents = socialEventPriceCents eventRow
                            , publicUpcomingEventCurrency = emCurrency metadata
                            , publicUpcomingEventTicketUrl = emTicketUrl metadata
                            , publicUpcomingEventImageUrl = emImageUrl metadata
                            , publicUpcomingEventWorkflowStateCode = stateCode
                            }
                    else Nothing
        _ -> pure Nothing

validateSocialEventsFeatureAction :: T.Text -> T.Text -> AuthedUser -> Either ServerError ()
validateSocialEventsFeatureAction featureId action user =
    let moduleNames = map moduleName (Set.toList (auModules user))
        allowed = maybe False
            (\feature -> registryFeatureAllows (auRoles user) moduleNames feature action)
            (findRegistryFeature featureId)
     in if allowed
            then Right ()
            else Left err403{errBody = "This feature action is not permitted"}

validateArtistProfileCreateParty :: AuthedUser -> Maybe T.Text -> Either ServerError T.Text
validateArtistProfileCreateParty user requestedPartyId
    | hasStrictAdminAccess user = Right (fromMaybe authenticatedParty cleanedRequest)
    | maybe True (== authenticatedParty) cleanedRequest = Right authenticatedParty
    | otherwise = Left err403{errBody = "Artist profiles can only be created for the authenticated party"}
  where
    authenticatedParty = renderPartyId user
    cleanedRequest = cleanMaybeText requestedPartyId

validateArtistProfileWriteAccess :: AuthedUser -> Maybe T.Text -> Either ServerError ()
validateArtistProfileWriteAccess user ownerPartyId
    | ownerPartyId == Just (renderPartyId user) || hasStrictAdminAccess user = Right ()
    | otherwise = Left err403{errBody = "Artist profile ownership is required"}

validateAuthenticatedPartyReference :: AuthedUser -> T.Text -> Either ServerError ()
validateAuthenticatedPartyReference user referencedPartyId
    | normalizePositivePartyIdText referencedPartyId == Just (renderPartyId user) = Right ()
    | otherwise = Left err403{errBody = "Followers can only be changed for the authenticated party"}

validateEventDeleteAccess :: AuthedUser -> T.Text -> SocialEvent -> Either ServerError ()
validateEventDeleteAccess user currentParty eventRow
    | hasStrictAdminAccess user || isEventManager currentParty eventRow = Right ()
    | otherwise =
        Left err403{errBody = "Only the event organizer or an administrator can delete this event"}

validateEventDeletionCheckoutHistory :: Bool -> Either ServerError ()
validateEventDeletionCheckoutHistory hasTicketOrders
    | hasTicketOrders =
        Left
            err409
                { errBody =
                    "Events with ticket orders cannot be deleted; unpublish the event instead to preserve checkout history"
                }
    | otherwise = Right ()

-- | Terms version of the event's approved, active ticket policy (same predicate as
-- the public storefront), or Nothing when the event has no such policy.
loadActiveTicketTermsVersion :: UTCTime -> SocialEventId -> SqlPersistT IO (Maybe T.Text)
loadActiveTicketTermsVersion = selectActiveTicketTermsVersion ""

-- | The same read, holding a share lock on the policy row until the transaction
-- ends: a writer that withdraws or replaces the policy waits for the order, and
-- one that got there first leaves no matching row (fail closed).
lockActiveTicketTermsVersion :: UTCTime -> SocialEventId -> SqlPersistT IO (Maybe T.Text)
lockActiveTicketTermsVersion = selectActiveTicketTermsVersion " FOR SHARE"

selectActiveTicketTermsVersion :: T.Text -> UTCTime -> SocialEventId -> SqlPersistT IO (Maybe T.Text)
selectActiveTicketTermsVersion lockClause now eventKey = do
    rows <-
        rawSql
            ( "SELECT terms_version FROM event_ticket_checkout_policy\
              \ WHERE event_id = ? AND active AND approval_status = 'approved'\
              \ AND approved_at IS NOT NULL AND approved_by IS NOT NULL\
              \ AND (effective_from IS NULL OR effective_from <= ?)\
              \ AND (effective_until IS NULL OR effective_until > ?)"
                <> lockClause
            )
            [toPersistValue eventKey, PersistUTCTime now, PersistUTCTime now]
    pure $ case rows of
        [Single version] -> Just version
        _ -> Nothing

removeSocialEventAssets :: FilePath -> SocialEventId -> IO ()
removeSocialEventAssets assetsRoot eventKey = do
    let eventAssetsDir =
            assetsRoot
                </> "social-events"
                </> "events"
                </> T.unpack (renderKeyText eventKey)
    exists <- doesDirectoryExist eventAssetsDir
    when exists (removePathForcibly eventAssetsDir)

suppressImportedEventMetadata :: Maybe T.Text -> Maybe T.Text
suppressImportedEventMetadata storedMetadata =
    encodeEventMetadata
        metadata
            { emTicketUrl = Nothing
            , emImageUrl = Nothing
            , emIsPublic = Just False
            }
  where
    metadata =
        either (const emptyEventMetadata) id (decodeStoredEventMetadata storedMetadata)

parseStripePaymentIntentResponse :: Aeson.Value -> Either T.Text (T.Text, T.Text)
parseStripePaymentIntentResponse paymentIntent =
    (,)
        <$> parseStripeRequiredText
            "Could not parse Stripe response"
            (Aeson.withObject "payment_intent" (Aeson..: "id"))
            paymentIntent
        <*> parseStripeRequiredText
            "Could not parse Stripe client secret"
            (Aeson.withObject "payment_intent" (Aeson..: "client_secret"))
            paymentIntent

parseStripeWebhookEventEnvelope :: Aeson.Value -> Either T.Text (T.Text, T.Text)
parseStripeWebhookEventEnvelope payload =
    (,)
        <$> parseStripeRequiredText
            "Invalid webhook payload"
            (Aeson.withObject "event" (Aeson..: "id"))
            payload
        <*> parseStripeRequiredText
            "Invalid webhook event type"
            (Aeson.withObject "event" (Aeson..: "type"))
            payload

{- | Verify the signature against the exact request bytes before decoding JSON.
Re-encoding an Aeson 'Value' changes insignificant whitespace and can make a
legitimate Stripe signature fail.
-}
verifyAndDecodeStripeWebhook ::
    UTCTime ->
    Stripe.StripeConfig ->
    Maybe T.Text ->
    BL.ByteString ->
    Either T.Text Aeson.Value
verifyAndDecodeStripeWebhook now stripeCfg mSignature rawBody = do
    signature <- maybe (Left "Missing Stripe-Signature header") Right mSignature
    unless (Stripe.verifyWebhookSignatureAt now stripeCfg signature (BL.toStrict rawBody)) $
        Left "Invalid webhook signature"
    case Aeson.eitherDecode rawBody of
        Left _ -> Left "Invalid webhook JSON"
        Right payload -> Right payload

parseStripeWebhookPaymentIntentId :: Aeson.Value -> Maybe T.Text
parseStripeWebhookPaymentIntentId =
    parseMaybe $
        Aeson.withObject "event" $ \eventObject -> do
            dataObject <- eventObject Aeson..: "data" :: Parser Object
            paymentIntentObject <- dataObject Aeson..: "object" :: Parser Object
            paymentIntentObject Aeson..: "id"

data StripeTicketPaymentEvidence = StripeTicketPaymentEvidence
    { stpePaymentIntentId :: T.Text
    , stpeStatus :: T.Text
    , stpeAmountReceived :: Int
    , stpeCurrency :: T.Text
    , stpeOrderId :: T.Text
    , stpeEventId :: T.Text
    }
    deriving (Eq, Show)

-- | Decode the immutable ticket binding from the signed PaymentIntent event.
-- Stripe stores the JSON snapshot in @metadata.tdf_context@. A succeeded event
-- without every field is not enough evidence to issue tickets.
parseStripeTicketPaymentEvidence :: Aeson.Value -> Either T.Text StripeTicketPaymentEvidence
parseStripeTicketPaymentEvidence payload = do
    (paymentIntentId, status, amountReceived, currency, contextJson) <-
        maybe (Left "Stripe ticket payment evidence is incomplete") Right $
            parseMaybe
                ( Aeson.withObject "event" $ \eventObject -> do
                    dataObject <- eventObject Aeson..: "data" :: Parser Object
                    paymentIntentObject <- dataObject Aeson..: "object" :: Parser Object
                    (,,,,)
                        <$> paymentIntentObject Aeson..: "id"
                        <*> paymentIntentObject Aeson..: "status"
                        <*> paymentIntentObject Aeson..: "amount_received"
                        <*> paymentIntentObject Aeson..: "currency"
                        <*> (paymentIntentObject Aeson..: "metadata" >>= (Aeson..: "tdf_context"))
                )
                payload
    contextValue <-
        maybe (Left "Stripe ticket payment context is invalid") Right $
            Aeson.decodeStrict' (TE.encodeUtf8 contextJson)
    (orderId, eventId) <-
        maybe (Left "Stripe ticket payment context is incomplete") Right $
            parseMaybe
                ( Aeson.withObject "ticket_payment_context" $ \contextObject ->
                    (,)
                        <$> contextObject Aeson..: "order_id"
                        <*> contextObject Aeson..: "event_id"
                )
                contextValue
    pure
        StripeTicketPaymentEvidence
            { stpePaymentIntentId = paymentIntentId
            , stpeStatus = T.toLower (T.strip status)
            , stpeAmountReceived = amountReceived
            , stpeCurrency = T.toUpper (T.strip currency)
            , stpeOrderId = T.strip orderId
            , stpeEventId = T.strip eventId
            }

validateStripeTicketPaymentEvidence ::
    T.Text ->
    T.Text ->
    T.Text ->
    Int ->
    T.Text ->
    StripeTicketPaymentEvidence ->
    Either T.Text ()
validateStripeTicketPaymentEvidence expectedOrderId expectedEventId expectedPaymentIntentId expectedAmount expectedCurrency evidence
    | stpeStatus evidence /= "succeeded" =
        Left "Stripe ticket PaymentIntent is not succeeded"
    | stpePaymentIntentId evidence /= expectedPaymentIntentId =
        Left "Stripe ticket PaymentIntent does not match the stored order"
    | stpeOrderId evidence /= expectedOrderId =
        Left "Stripe ticket order metadata does not match the stored order"
    | stpeEventId evidence /= expectedEventId =
        Left "Stripe ticket event metadata does not match the stored event"
    | stpeAmountReceived evidence /= expectedAmount =
        Left "Stripe ticket amount does not match the immutable order total"
    | stpeCurrency evidence /= T.toUpper (T.strip expectedCurrency) =
        Left "Stripe ticket currency does not match the immutable order currency"
    | otherwise = Right ()

parseStripeWebhookMarketplaceOrderId :: Aeson.Value -> Maybe T.Text
parseStripeWebhookMarketplaceOrderId payload = do
    contextJson <-
        parseMaybe
            ( Aeson.withObject "event" $ \eventObject -> do
                dataObject <- eventObject Aeson..: "data" :: Parser Object
                paymentIntentObject <- dataObject Aeson..: "object" :: Parser Object
                metadataObject <- paymentIntentObject Aeson..: "metadata" :: Parser Object
                metadataObject Aeson..: "tdf_context"
            )
            payload
    contextValue <- Aeson.decodeStrict' (TE.encodeUtf8 contextJson)
    parseMaybe
        ( Aeson.withObject "tdf_context" $ \contextObject -> do
            purpose <- contextObject Aeson..: "purpose" :: Parser T.Text
            unless (purpose == "marketplace_order") $
                fail "Unexpected Stripe metadata purpose"
            contextObject Aeson..: "marketplace_order_id"
        )
        contextValue

canRecoverMarketplaceStripeOrder :: T.Text -> Maybe T.Text -> Maybe T.Text -> Bool
canRecoverMarketplaceStripeOrder status provider paymentIntentId =
    status == "stripe_pending"
        && provider == Just "stripe"
        && isNothing paymentIntentId

parseStripeRefundResponse :: Aeson.Value -> Either T.Text T.Text
parseStripeRefundResponse =
    parseStripeRequiredText
        "Could not parse Stripe refund response"
        (Aeson.withObject "refund" (Aeson..: "id"))

-- A returned identifier is correlation evidence, not proof of completion.
-- This endpoint does not request expanded PaymentIntents from Stripe.
stripeRefundCompletionMatches :: T.Text -> Int -> T.Text -> Aeson.Value -> Bool
stripeRefundCompletionMatches expectedIntent expectedAmount expectedCurrency =
    isJust . parseMaybe (Aeson.withObject "refund" $ \response -> do
        objectType <- response Aeson..: "object" :: Parser T.Text
        status <- response Aeson..: "status" :: Parser T.Text
        amount <- response Aeson..: "amount" :: Parser Int
        currency <- response Aeson..: "currency" :: Parser T.Text
        paymentIntent <- response Aeson..: "payment_intent" :: Parser T.Text
        let storedCurrency = T.toLower expectedCurrency
        unless
            ( objectType == "refund" && status == "succeeded"
                && expectedAmount > 0 && amount == expectedAmount
                && T.length storedCurrency == 3 && T.all isAsciiLower storedCurrency
                && currency == storedCurrency
                && not (T.null expectedIntent) && paymentIntent == expectedIntent
            )
            (fail "Refund completion evidence does not match its request"))

validObservedStripeRefundId :: T.Text -> Bool
validObservedStripeRefundId value =
    not (T.null value) && T.length value <= 128
        && T.all (\ch -> isAscii ch && ch >= '!' && ch <= '~') value

parseStripeCustomerId :: Aeson.Value -> Either T.Text T.Text
parseStripeCustomerId =
    parseStripeRequiredText
        "Could not parse Stripe customer response"
        (Aeson.withObject "customer" (Aeson..: "id"))

parseStripeEphemeralKeySecret :: Aeson.Value -> Either T.Text T.Text
parseStripeEphemeralKeySecret =
    parseStripeRequiredText
        "Could not parse Stripe ephemeral key response"
        (Aeson.withObject "ephemeral_key" (Aeson..: "secret"))

parseStripeRequiredText ::
    T.Text ->
    (Aeson.Value -> Parser T.Text) ->
    Aeson.Value ->
    Either T.Text T.Text
parseStripeRequiredText errorMessage parser =
    maybe (Left errorMessage) Right . parseMaybe parser

eitherStripeServerError :: Either T.Text a -> AppM a
eitherStripeServerError =
    either
        (\errText -> throwError err500{errBody = textErrBody errText})
        pure

eitherStripeWebhookError :: Either T.Text a -> AppM a
eitherStripeWebhookError =
    either
        (\errText -> throwError err400{errBody = textErrBody errText})
        pure

{- | Look up the Stripe Customer for a Party, creating one (and persisting the
id) if none exists yet. This is the foundation for PaymentSheet's saved-cards
UX: subsequent purchases by the same Party reuse the existing customer so
their saved methods appear automatically.
-}
resolveStripeCustomerForBuyer ::
    Stripe.StripeConfig ->
    PartyId ->
    -- | buyer email passed through to Stripe when creating new
    Maybe T.Text ->
    -- | buyer display name passed through to Stripe when creating new
    Maybe T.Text ->
    AppM T.Text
resolveStripeCustomerForBuyer stripeCfg pid mBuyerEmail mBuyerName = do
    Env{..} <- ask
    mParty <- liftIO $ runSqlPool (get pid) envPool
    party <- maybe (throwError err404{errBody = "Buyer party not found"}) pure mParty
    maybe
        (createAndPersistStripeCustomer envPool party)
        pure
        (partyStripeCustomerId party)
  where
    createAndPersistStripeCustomer envPool party = do
        let emailForCustomer = mBuyerEmail <|> partyPrimaryEmail party
            nameForCustomer = mBuyerName <|> Just (partyDisplayName party)
        result <-
            liftIO $
                runStripeRequestSafely $
                    Stripe.createCustomer stripeCfg emailForCustomer nameForCustomer Nothing
        customerJson <-
            either
                ( \err ->
                    throwError
                        err500
                            { errBody = BL.fromStrict (TE.encodeUtf8 ("Stripe customer error: " <> err))
                            }
                )
                pure
                result
        customerId <- eitherStripeServerError $ parseStripeCustomerId customerJson
        liftIO $
            runSqlPool
                (update pid [PartyStripeCustomerId =. Just customerId])
                envPool
        pure customerId

eitherPromoCodeBadRequest :: Either T.Text a -> AppM a
eitherPromoCodeBadRequest =
    either
        (\errText -> throwError err400{errBody = textErrBody errText})
        pure

textErrBody :: T.Text -> BL.ByteString
textErrBody = BL.fromStrict . TE.encodeUtf8

runStripeRequestSafely :: IO (Either T.Text a) -> IO (Either T.Text a)
runStripeRequestSafely action = do
    result <- try action
    case result of
        Right stripeResult -> pure stripeResult
        Left err ->
            case fromException err :: Maybe SomeAsyncException of
                Just _ -> throwIO (err :: SomeException)
                Nothing -> pure (Left "Stripe request failed")

tryAny :: IO a -> IO (Either SomeException a)
tryAny = try

-- Like tryAny, but cancellation and other asynchronous exceptions propagate.
trySynchronous :: IO a -> IO (Either SomeException a)
trySynchronous action = do
    result <- try action
    case result of
        Left err ->
            case fromException err :: Maybe SomeAsyncException of
                Just _ -> throwIO err
                Nothing -> pure (Left err)
        Right value -> pure (Right value)

isEventTicketCheckoutConflict :: SomeException -> Bool
isEventTicketCheckoutConflict exception =
    case fromException exception of
        Just sqlErr ->
            sqlState sqlErr == "23505"
                && "unique_event_ticket_checkout"
                    `BS8.isInfixOf` (sqlErrorMsg sqlErr <> " " <> sqlErrorDetail sqlErr)
        Nothing -> False

{- | Public Stripe webhook handler. Stripe authenticates this endpoint with
its signature header, so it intentionally has no 'AuthedUser' dependency.
-}
stripeWebhookServer :: Maybe T.Text -> BL.ByteString -> AppM NoContent
stripeWebhookServer mSignature rawBody = do
    Env{..} <- ask
    now <- liftIO getCurrentTime
    case (stripeSecretKey envConfig, stripeWebhookSecret envConfig) of
        (Just secretKey, Just webhookSecret) -> do
            let stripeCfg =
                    Stripe.StripeConfig
                        { Stripe.stripeSecretKey = secretKey
                        , Stripe.stripeWebhookSecret = webhookSecret
                        , Stripe.stripeApiVersion = Stripe.defaultStripeApiVersion
                        }
            payload <-
                eitherStripeWebhookError $
                    verifyAndDecodeStripeWebhook now stripeCfg mSignature rawBody
            (eventId, eventType) <-
                eitherStripeWebhookError $
                    parseStripeWebhookEventEnvelope payload
            mExisting <- liftIO $ runSqlPool (getBy (UniqueStripeWebhookEvent eventId)) envPool
            case mExisting of
                Just _ -> pure NoContent
                Nothing -> do
                    dispatchResult <- case eventType of
                        "payment_intent.succeeded" ->
                            handleStripePaymentIntentSucceeded now payload
                        -- A failed attempt can be retried on the same intent.
                        "payment_intent.payment_failed" -> pure NoContent
                        "payment_intent.canceled" ->
                            handleStripePaymentIntentCanceled now payload
                        "charge.refunded" -> pure NoContent
                        "checkout.session.completed" ->
                            handleStripeCheckoutSessionCompleted now payload
                        "customer.subscription.updated" ->
                            handleStripeSubscriptionUpdated now payload
                        "customer.subscription.deleted" ->
                            handleStripeSubscriptionDeleted now payload
                        "invoice.paid" -> pure NoContent
                        _ -> pure NoContent
                    _ <-
                        liftIO $
                            runSqlPool
                                ( insertUnique
                                    StripeWebhookEvent
                                        { stripeWebhookEventStripeEventId = eventId
                                        , stripeWebhookEventEventType = eventType
                                        , stripeWebhookEventPayload = TE.decodeUtf8 (BL.toStrict rawBody)
                                        , stripeWebhookEventProcessedAt = now
                                        }
                                )
                                envPool
                    pure dispatchResult
        -- Public unsigned callback on an unconfigured provider: unavailable, not a
        -- server fault, like the other provider callbacks (AUTH-PUBLIC-001).
        _ -> throwError err503{errBody = "Stripe is not configured"}

handleStripePaymentIntentSucceeded :: UTCTime -> Aeson.Value -> AppM NoContent
handleStripePaymentIntentSucceeded now payload =
    maybe (pure NoContent) markOrderPaid (parseStripeWebhookPaymentIntentId payload)
  where
    markOrderPaid piId = do
        Env{..} <- ask
        mOrder <-
            liftIO $
                runSqlPool
                    (selectFirst [EventTicketOrderStripePaymentIntentId ==. Just piId] [])
                    envPool
        case mOrder of
            Nothing ->
                markCourseRegistrationStatus
                    now
                    "paid"
                    piId
                    (parseStripeWebhookMarketplaceOrderId payload)
            Just (Entity orderKey order) -> do
                paymentEvidence <-
                    eitherStripeWebhookError (parseStripeTicketPaymentEvidence payload)
                eitherStripeWebhookError $
                    validateStripeTicketPaymentEvidence
                        (renderKeyText orderKey)
                        (renderKeyText (eventTicketOrderEventId order))
                        piId
                        (eventTicketOrderAmountCents order)
                        (eventTicketOrderCurrency order)
                        paymentEvidence
                (statusChanged, ticketCodes) <-
                    liftIO $
                        runSqlPool
                            ( do
                                changedCount <-
                                    updateWhereCount
                                        [ EventTicketOrderId ==. orderKey
                                        , EventTicketOrderStatus ==. "pending"
                                        ]
                                        [ EventTicketOrderStatus =. "paid"
                                        , EventTicketOrderUpdatedAt =. now
                                        ]
                                if changedCount > 0
                                    then do
                                        codes <- issueMissingTicketsForOrder now orderKey order
                                        pure (True, codes)
                                    else pure (False, [])
                            )
                            envPool
                when statusChanged $
                    sendTicketConfirmationForOrder order ticketCodes
                pure NoContent

issueMissingTicketsForOrder ::
    UTCTime ->
    EventTicketOrderId ->
    EventTicketOrder ->
    SqlPersistT IO [T.Text]
issueMissingTicketsForOrder now orderKey order = do
    existingTickets <-
        selectList [EventTicketOrderRefId ==. orderKey] [Asc EventTicketId]
    let missingCount =
            max 0 (eventTicketOrderQuantity order - length existingTickets)
    forM_ [1 .. missingCount] $ \_ -> do
        ticketCodeValue <- generateUniqueTicketCode
        insert_
            EventTicket
                { eventTicketEventId = eventTicketOrderEventId order
                , eventTicketTierRefId = eventTicketOrderTierId order
                , eventTicketOrderRefId = orderKey
                , eventTicketHolderName = eventTicketOrderBuyerName order
                , eventTicketHolderEmail = eventTicketOrderBuyerEmail order
                , eventTicketCode = ticketCodeValue
                , eventTicketStatus = "issued"
                , eventTicketCheckedInAt = Nothing
                , eventTicketCurrentHolderPartyId = eventTicketOrderBuyerPartyId order
                , eventTicketCurrentHolderEmail = eventTicketOrderBuyerEmail order
                , eventTicketCurrentHolderName = eventTicketOrderBuyerName order
                , eventTicketOriginalHolderPartyId = eventTicketOrderBuyerPartyId order
                , eventTicketTransferHistory = Nothing
                , eventTicketCreatedAt = now
                , eventTicketUpdatedAt = now
                }
    allTickets <- selectList [EventTicketOrderRefId ==. orderKey] [Asc EventTicketId]
    pure (map (eventTicketCode . entityVal) (filter (Transfer.retainedByBuyer . entityVal) allTickets))

finalizePaidTicketOrder ::
    UTCTime ->
    EventTicketOrderId ->
    SqlPersistT IO (EventTicketOrder, [T.Text], Bool)
finalizePaidTicketOrder now orderKey = do
    runtimeRows <-
        ( rawSql
            "SELECT runtime.fulfillment_status, runtime.payment_status,\
            \ runtime.promo_code_id, runtime.discount_minor\
            \ FROM event_ticket_checkout_runtime runtime\
            \ JOIN commerce_checkout_session checkout ON checkout.id = runtime.checkout_id\
            \ WHERE runtime.order_id = ? AND checkout.status = 'paid' FOR UPDATE OF runtime"
            [toPersistValue orderKey]
            :: SqlPersistT IO
                [(Single T.Text, Single T.Text, Single (Maybe Int64), Single Int64)]
        )
    (fulfillmentStatus, paymentStatus, promoKey, discountMinor) <-
        case runtimeRows of
            [(Single status, Single payment, Single promoId, Single discount)] ->
                pure (status, payment, toSqlKey <$> promoId, discount)
            _ -> fail "Ticket issuance requires one locked canonical checkout runtime"
    unless (paymentStatus == "paid") $
        fail "Ticket issuance requires a paid canonical checkout"
    order <- getJust orderKey
    when (eventTicketOrderStatus order `notElem` ["pending", "paid"]) $
        fail "Closed ticket order cannot be issued"
    updateWhere
        [ EventTicketOrderId ==. orderKey
        , EventTicketOrderStatus ==. "pending"
        ]
        [ EventTicketOrderStatus =. "paid"
        , EventTicketOrderUpdatedAt =. now
        ]
    case fulfillmentStatus of
        "seat_held" -> do
            ticketCodes <- issueMissingTicketsForOrder now orderKey order
            forM_ promoKey $ \key -> do
                existingRedemption <-
                    selectFirst [PromoCodeRedemptionOrderId ==. orderKey] []
                when (not (isJust existingRedemption)) $
                    insert_
                        PromoCodeRedemption
                            { promoCodeRedemptionPromoCodeId = key
                            , promoCodeRedemptionOrderId = orderKey
                            , promoCodeRedemptionDiscountAmountCents =
                                fromIntegral discountMinor
                            , promoCodeRedemptionRedeemedAt = now
                            }
            rawExecute
                "UPDATE event_ticket_checkout_runtime\
                \ SET fulfillment_status='issued', issued_at=?, updated_at=? WHERE order_id=?"
                [ PersistUTCTime now
                , PersistUTCTime now
                , toPersistValue orderKey
                ]
            rawExecute
                "INSERT INTO event_ticket_fulfillment_event(\
                \ order_id, from_status, to_status, actor_type, reason_code, notes\
                \) VALUES (?, 'seat_held', 'issued', 'provider', 'verified_payment',\
                \ 'Tickets issued only after canonical provider verification')"
                [toPersistValue orderKey]
            -- Persist delivery intent in the issuance transaction. Network SMTP
            -- happens in the leased worker only after this transaction commits.
            _ <- (rawSql "SELECT event_ticket_queue_confirmation(?) IS NULL"
                [toPersistValue orderKey] :: SqlPersistT IO [Single Bool])
            pure (order, ticketCodes, True)
        "issued" -> do
            existingTickets <-
                selectList [EventTicketOrderRefId ==. orderKey] [Asc EventTicketId]
            pure
                ( order
                , map (eventTicketCode . entityVal) (filter (Transfer.retainedByBuyer . entityVal) existingTickets)
                , False
                )
        _ -> fail "Paid ticket checkout is not in an issuable fulfillment state"

sendTicketConfirmationForOrder :: EventTicketOrder -> [T.Text] -> AppM ()
sendTicketConfirmationForOrder order ticketCodes = do
    env <- ask
    liftIO $ sendTicketConfirmationForOrderIO env order ticketCodes

sendTicketConfirmationForOrderIO :: Env -> EventTicketOrder -> [T.Text] -> IO ()
sendTicketConfirmationForOrderIO Env{..} order ticketCodes = do
    (mEvent, mTier, mParty) <-
        runSqlPool
            ( do
                eventRow <- get (eventTicketOrderEventId order)
                tierRow <- get (eventTicketOrderTierId order)
                partyRow <- case partyKey of
                    Nothing -> pure Nothing
                    Just key -> get key
                pure (eventRow, tierRow, partyRow)
            )
            envPool
    case (mEvent, mTier, recipientEmail mParty) of
        (Just eventRow, Just tierRow, Just emailAddress) ->
            sendTicketConfirmationEmailBestEffort
                (emailConfig envConfig)
                (recipientName mParty)
                emailAddress
                (socialEventTitle eventRow)
                (formatTicketEventDate (socialEventStartTime eventRow))
                (eventTicketOrderQuantity order)
                (eventTicketTierName tierRow)
                (formatTicketOrderTotal order)
                ticketCodes
                (Just ticketMobileUrl)
        _ -> pure ()
  where
    partyKey =
        eventTicketOrderBuyerPartyId order
            >>= (fromPathPiece :: T.Text -> Maybe PartyId)
    recipientName mParty =
        fromMaybe
            "Invitado TDF"
            ( cleanMaybeText (eventTicketOrderBuyerName order)
                <|> cleanMaybeText (partyDisplayName <$> mParty)
            )
    recipientEmail mParty =
        cleanMaybeText (eventTicketOrderBuyerEmail order)
            <|> cleanMaybeText (mParty >>= partyPrimaryEmail)

sendTicketConfirmationEmailBestEffort ::
    Maybe EmailConfig ->
    T.Text ->
    T.Text ->
    T.Text ->
    T.Text ->
    Int ->
    T.Text ->
    T.Text ->
    [T.Text] ->
    Maybe T.Text ->
    IO ()
sendTicketConfirmationEmailBestEffort
    smtpConfig
    buyerName
    buyerEmail
    eventTitle
    eventDate
    quantity
    tierName
    total
    ticketCodes
    ticketAppUrl = do
        result <-
            ( try
                    ( Email.sendTicketConfirmationEmail
                        smtpConfig
                        buyerName
                        buyerEmail
                        eventTitle
                        eventDate
                        quantity
                        tierName
                        total
                        ticketCodes
                        ticketAppUrl
                    ) ::
                    IO (Either SomeException ())
                )
        case result of
            Left _ ->
                hPutStrLn
                    stderr
                    "[TicketConfirmation] Email delivery failed after ticket issuance"
            Right () -> pure ()

formatTicketEventDate :: UTCTime -> T.Text
formatTicketEventDate =
    T.pack . formatTime defaultTimeLocale "%Y-%m-%d %H:%M UTC"

ticketMobileUrl :: T.Text
ticketMobileUrl = "tdf://tickets"

formatTicketOrderTotal :: EventTicketOrder -> T.Text
formatTicketOrderTotal order =
    T.pack (printf "%.2f" amount) <> " " <> T.toUpper (eventTicketOrderCurrency order)
  where
    amount = fromIntegral (eventTicketOrderAmountCents order) / 100 :: Double

data TicketPlatformFeeBreakdown = TicketPlatformFeeBreakdown
    { ticketFaceValueCents :: Int
    , ticketBuyerPlatformFeeCents :: Int
    , ticketOrganizerPlatformFeeCents :: Int
    , ticketCheckoutTotalCents :: Int
    }

ticketPlatformFeeBps :: Int
-- 4% total is the platform's configurable self-service ticketing baseline.
-- rates while still covering TDF's platform operations. It is split evenly
-- between buyer checkout and organizer proceeds.
ticketPlatformFeeBps = 400

ticketPlatformFeeBreakdown :: Int -> TicketPlatformFeeBreakdown
ticketPlatformFeeBreakdown faceValue =
    let totalFee = max 0 (faceValue * ticketPlatformFeeBps `div` 10000)
        buyerFee = (totalFee + 1) `div` 2
        organizerFee = totalFee - buyerFee
     in TicketPlatformFeeBreakdown
            { ticketFaceValueCents = faceValue
            , ticketBuyerPlatformFeeCents = buyerFee
            , ticketOrganizerPlatformFeeCents = organizerFee
            , ticketCheckoutTotalCents = faceValue + buyerFee
            }

encodeTicketCheckoutMetadata :: Maybe T.Text -> Maybe T.Text -> Maybe T.Text -> TicketPlatformFeeBreakdown -> Maybe T.Text
encodeTicketCheckoutMetadata mIdempotencyKey mPromoCode mAcceptedTermsVersion TicketPlatformFeeBreakdown{..} =
    Just . TE.decodeUtf8 . BL.toStrict . Aeson.encode $
        Aeson.object
            [ "checkout_idempotency_key" Aeson..= mIdempotencyKey
            , "promo_code" Aeson..= mPromoCode
            , "accepted_terms_version" Aeson..= mAcceptedTermsVersion
            , "face_value_cents" Aeson..= ticketFaceValueCents
            , "buyer_platform_fee_cents" Aeson..= ticketBuyerPlatformFeeCents
            , "organizer_platform_fee_cents" Aeson..= ticketOrganizerPlatformFeeCents
            ]

decodeTicketCheckoutMetadata :: Maybe T.Text -> Maybe (T.Text, Maybe T.Text)
decodeTicketCheckoutMetadata mRawMetadata = do
    rawMetadata <- mRawMetadata
    metadata <- Aeson.decodeStrict' (TE.encodeUtf8 rawMetadata)
    parseMaybe
        ( Aeson.withObject "ticket_checkout_metadata" $ \obj ->
            (,)
                <$> obj Aeson..: "checkout_idempotency_key"
                <*> obj Aeson..:? "promo_code"
        )
        metadata

-- | Terms version the buyer accepted when this order was created, when the event
-- had an approved ticket policy. Orders older than this evidence decode to Nothing.
decodeTicketAcceptedTermsVersion :: Maybe T.Text -> Maybe T.Text
decodeTicketAcceptedTermsVersion mRawMetadata = do
    rawMetadata <- mRawMetadata
    metadata <- Aeson.decodeStrict' (TE.encodeUtf8 rawMetadata)
    join $
        parseMaybe
            (Aeson.withObject "ticket_terms_metadata" (Aeson..:? "accepted_terms_version"))
            metadata

-- | Terms acceptance to record for a legacy ticket purchase. A new order must
-- accept the policy that is active now. A replay stays bound to the acceptance
-- its order recorded, so a later policy change neither blocks the retry nor
-- lets it claim a version the buyer did not accept for that order.
ticketTermsAcceptance ::
    -- | Terms version of the approved active policy, if the event has one.
    Maybe T.Text ->
    -- | Version submitted with this request.
    Maybe T.Text ->
    -- | Acceptance recorded by the existing order for this idempotency key.
    Maybe (Maybe T.Text) ->
    Either ServerError (Maybe T.Text)
ticketTermsAcceptance _ submitted (Just recorded)
    | maybe True ((== submitted) . Just) recorded = Right recorded
    | otherwise =
        Left err409{errBody = "ticketPurchaseIdempotencyKey was already used for different checkout details"}
ticketTermsAcceptance Nothing _ Nothing = Right Nothing
ticketTermsAcceptance (Just _) Nothing Nothing =
    Left err400{errBody = "Ticket terms must be accepted before seats can be held"}
ticketTermsAcceptance (Just active) (Just accepted) Nothing
    | accepted == active = Right (Just active)
    | otherwise = Left ticketTermsChangedError

ticketTermsChangedError :: ServerError
ticketTermsChangedError =
    err409{errBody = "Ticket terms changed; review the current terms and accept them again"}

decodeTicketPlatformFeeBreakdown :: EventTicketOrder -> TicketPlatformFeeBreakdown
decodeTicketPlatformFeeBreakdown order =
    fromMaybe fallback $ do
        rawMetadata <- eventTicketOrderMetadata order
        metadata <- Aeson.decodeStrict' (TE.encodeUtf8 rawMetadata)
        parseMaybe
            ( Aeson.withObject "ticket_fee_metadata" $ \obj ->
                TicketPlatformFeeBreakdown
                    <$> obj Aeson..: "face_value_cents"
                    <*> obj Aeson..: "buyer_platform_fee_cents"
                    <*> obj Aeson..: "organizer_platform_fee_cents"
                    <*> pure (eventTicketOrderAmountCents order)
            )
            metadata
  where
    -- Orders created before the platform-fee rollout retain their historical totals.
    fallback = TicketPlatformFeeBreakdown (eventTicketOrderAmountCents order) 0 0 (eventTicketOrderAmountCents order)

reuseStripeTicketCheckout ::
    Maybe T.Text ->
    EventTicketOrderId ->
    EventTicketOrder ->
    AppM StripePaymentIntentDTO
reuseStripeTicketCheckout mMobileSdkVersion orderKey order = do
    Env{..} <- ask
    stripeCfg <-
        case (stripeSecretKey envConfig, stripeWebhookSecret envConfig) of
            (Just secretKey, Just webhookSecret) ->
                pure
                    Stripe.StripeConfig
                        { Stripe.stripeSecretKey = secretKey
                        , Stripe.stripeWebhookSecret = webhookSecret
                        , Stripe.stripeApiVersion = Stripe.defaultStripeApiVersion
                        }
            _ -> throwError err500{errBody = "Stripe is not configured"}
    paymentIntentId <-
        maybe
            (throwError err409{errBody = "Ticket checkout is still initializing; retry shortly"})
            pure
            (eventTicketOrderStripePaymentIntentId order)
    retrieved <-
        liftIO $
            runStripeRequestSafely $
                Stripe.retrievePaymentIntent stripeCfg paymentIntentId
    paymentIntent <-
        either
            (\err -> throwError err502{errBody = textErrBody ("Stripe retrieval error: " <> err)})
            pure
            retrieved
    (_, clientSecret) <- eitherStripeServerError $ parseStripePaymentIntentResponse paymentIntent
    paymentSheet <- case mMobileSdkVersion of
        Nothing -> pure Nothing
        Just mobileSdkVersion -> do
            publishableKey <-
                maybe
                    (throwError err500{errBody = "Stripe publishable key not configured"})
                    pure
                    (stripePublishableKey envConfig)
            buyerKey <-
                maybe
                    (throwError err500{errBody = "Ticket order buyer is invalid"})
                    pure
                    ( eventTicketOrderBuyerPartyId order
                        >>= (fromPathPiece :: T.Text -> Maybe PartyId)
                    )
            customerId <-
                resolveStripeCustomerForBuyer
                    stripeCfg
                    buyerKey
                    (eventTicketOrderBuyerEmail order)
                    (eventTicketOrderBuyerName order)
            ephemeralResult <-
                liftIO $
                    runStripeRequestSafely $
                        Stripe.createEphemeralKey stripeCfg customerId mobileSdkVersion
            ephemeralSecret <-
                either
                    (\err -> throwError err502{errBody = textErrBody ("Stripe ephemeral key error: " <> err)})
                    (eitherStripeServerError . parseStripeEphemeralKeySecret)
                    ephemeralResult
            pure . Just $
                PaymentSheetParamsDTO
                    { psCustomerId = customerId
                    , psEphemeralKeySecret = ephemeralSecret
                    , psPaymentIntentClientSecret = clientSecret
                    , psPublishableKey = publishableKey
                    }
    pure
        StripePaymentIntentDTO
            { spiClientSecret = clientSecret
            , spiOrderId = renderKeyText orderKey
            , spiAmountCents = eventTicketOrderAmountCents order
            , spiCurrency = eventTicketOrderCurrency order
            , spiPaymentSheet = paymentSheet
            , spiLookupToken = Nothing
            }

handleStripePaymentIntentCanceled :: UTCTime -> Aeson.Value -> AppM NoContent
handleStripePaymentIntentCanceled now payload =
    maybe (pure NoContent) cancelOrder (parseStripeWebhookPaymentIntentId payload)
  where
    cancelOrder piId = do
        Env{..} <- ask
        mOrder <-
            liftIO $
                runSqlPool
                    (selectFirst [EventTicketOrderStripePaymentIntentId ==. Just piId] [])
                    envPool
        case mOrder of
            Nothing ->
                markCourseRegistrationStatus
                    now
                    "cancelled"
                    piId
                    (parseStripeWebhookMarketplaceOrderId payload)
            Just (Entity orderKey order) -> do
                liftIO $
                    runSqlPool
                        ( do
                            changedCount <-
                                updateWhereCount
                                    [ EventTicketOrderId ==. orderKey
                                    , EventTicketOrderStatus ==. "pending"
                                    ]
                                    [ EventTicketOrderStatus =. "cancelled"
                                    , EventTicketOrderUpdatedAt =. now
                                    ]
                            when (changedCount > 0) $ do
                                update
                                    (eventTicketOrderTierId order)
                                    [EventTicketTierQuantitySold +=. (negate (eventTicketOrderQuantity order))]
                                case eventTicketOrderPromoCodeId order of
                                    Nothing -> pure ()
                                    Just promoKey -> update promoKey [PromoCodeCurrentRedemptions +=. (-1)]
                        )
                        envPool
                pure NoContent

{- | Webhook fallback that flips a course registration to @newStatus@ when its
PaymentIntent is the one the webhook fired for. Idempotent: only acts when
the registration is still in @pending_payment@ (Stripe replays events).
Falls through to 'markArtistTipStatus' when no matching course registration
exists, so a single webhook handler can route both course payments and
artist tips.
-}
markCourseRegistrationStatus :: UTCTime -> T.Text -> T.Text -> Maybe T.Text -> AppM NoContent
markCourseRegistrationStatus now newStatus piId mMarketplaceOrderId = do
    Env{..} <- ask
    mReg <-
        liftIO $
            runSqlPool
                (selectFirst [ME.CourseRegistrationStripePaymentIntentId ==. Just piId] [])
                envPool
    case mReg of
        Nothing ->
            markArtistTipStatus
                now
                (translateToArtistTipStatus newStatus)
                piId
                mMarketplaceOrderId
        Just (Entity regKey reg) -> do
            when (ME.courseRegistrationStatus reg == "pending_payment") $
                liftIO $
                    runSqlPool
                        ( update
                            regKey
                            [ ME.CourseRegistrationStatus =. newStatus
                            , ME.CourseRegistrationUpdatedAt =. now
                            ]
                        )
                        envPool
            pure NoContent

{- | Webhook fallback for artist tip PaymentIntents. Same shape as
'markCourseRegistrationStatus' but operates on the @artist_tip@ table.
Idempotent: only acts on tips still in @pending@.
-}
markArtistTipStatus :: UTCTime -> T.Text -> T.Text -> Maybe T.Text -> AppM NoContent
markArtistTipStatus now newStatus piId mMarketplaceOrderId = do
    Env{..} <- ask
    mTip <-
        liftIO $
            runSqlPool
                (selectFirst [ME.ArtistTipStripePaymentIntentId ==. Just piId] [])
                envPool
    case mTip of
        Nothing ->
            markMarketplaceOrderStatus
                now
                (translateToMarketplaceOrderStatus newStatus)
                piId
                mMarketplaceOrderId
        Just (Entity tipKey tip) -> do
            when (ME.artistTipStatus tip == "pending") $
                liftIO $
                    runSqlPool
                        ( update
                            tipKey
                            [ ME.ArtistTipStatus =. newStatus
                            , ME.ArtistTipUpdatedAt =. now
                            ]
                        )
                        envPool
            pure NoContent

{- | Webhook fallback for marketplace Stripe PaymentIntents. Idempotent: only
acts on orders still waiting for Stripe confirmation.
-}
markMarketplaceOrderStatus :: UTCTime -> T.Text -> T.Text -> Maybe T.Text -> AppM NoContent
markMarketplaceOrderStatus now newStatus piId mOrderId = do
    Env{..} <- ask
    mOrder <-
        liftIO $
            runSqlPool
                (selectFirst [ME.MarketplaceOrderStripePaymentIntentId ==. Just piId] [])
                envPool
    case mOrder of
        Just (Entity orderKey order) -> do
            when (ME.marketplaceOrderStatus order `elem` ["stripe_pending", "pending"]) $
                liftIO $
                    runSqlPool
                        ( update
                            orderKey
                            [ ME.MarketplaceOrderStatus =. newStatus
                            , ME.MarketplaceOrderPaymentProvider =. Just "stripe"
                            , ME.MarketplaceOrderStripePaymentIntentId =. Just piId
                            , ME.MarketplaceOrderPaidAt =. if newStatus == "paid" then Just now else ME.marketplaceOrderPaidAt order
                            , ME.MarketplaceOrderUpdatedAt =. now
                            ]
                        )
                        envPool
            pure NoContent
        Nothing -> do
            mOrderByMetadata <-
                case mOrderId >>= fromPathPiece of
                    Nothing -> pure Nothing
                    Just orderKey -> liftIO $ runSqlPool (getEntity orderKey) envPool
            case mOrderByMetadata of
                Just (Entity orderKey order)
                    | canRecoverMarketplaceStripeOrder
                        (ME.marketplaceOrderStatus order)
                        (ME.marketplaceOrderPaymentProvider order)
                        (ME.marketplaceOrderStripePaymentIntentId order) ->
                        liftIO $
                            runSqlPool
                                ( updateWhere
                                    [ ME.MarketplaceOrderId ==. orderKey
                                    , ME.MarketplaceOrderStatus ==. "stripe_pending"
                                    , ME.MarketplaceOrderPaymentProvider ==. Just "stripe"
                                    , ME.MarketplaceOrderStripePaymentIntentId ==. Nothing
                                    ]
                                    [ ME.MarketplaceOrderStatus =. newStatus
                                    , ME.MarketplaceOrderStripePaymentIntentId =. Just piId
                                    , ME.MarketplaceOrderPaidAt
                                        =. if newStatus == "paid"
                                            then Just now
                                            else ME.marketplaceOrderPaidAt order
                                    , ME.MarketplaceOrderUpdatedAt =. now
                                    ]
                                )
                                envPool
                _ -> pure ()
            pure NoContent

{- | The course registration status enum uses @cancelled@ for the failure path;
the artist_tip status enum uses @failed@. This mapping keeps both surfaces
aligned with their own conventions while routing through one webhook.
-}
translateToArtistTipStatus :: T.Text -> T.Text
translateToArtistTipStatus "cancelled" = "failed"
translateToArtistTipStatus s = s

translateToMarketplaceOrderStatus :: T.Text -> T.Text
translateToMarketplaceOrderStatus "cancelled" = "stripe_failed"
translateToMarketplaceOrderStatus "failed" = "stripe_failed"
translateToMarketplaceOrderStatus s = s

{- | Webhook handler for `checkout.session.completed`. Records the
subscription id on the course registration and flips it to @paid@. Looks up
the registration by @metadata.course_registration_id@ on the session, which
our subscription-checkout handler always sets.
-}
handleStripeCheckoutSessionCompleted :: UTCTime -> Aeson.Value -> AppM NoContent
handleStripeCheckoutSessionCompleted now payload =
    maybe (pure NoContent) markRegistrationPaid $
        parseCheckoutSessionCourseSubscription payload
  where
    markRegistrationPaid (regIdNum, subId) = do
        Env{..} <- ask
        let regKey = toSqlKey regIdNum :: ME.CourseRegistrationId
        mReg <- liftIO $ runSqlPool (get regKey) envPool
        maybe
            (pure NoContent)
            ( \reg -> do
                when (ME.courseRegistrationStatus reg == "pending_payment") $
                    liftIO $
                        runSqlPool
                            ( update
                                regKey
                                [ ME.CourseRegistrationStatus =. "paid"
                                , ME.CourseRegistrationStripeSubscriptionId =. Just subId
                                , ME.CourseRegistrationSubscriptionStatus =. Just "active"
                                , ME.CourseRegistrationUpdatedAt =. now
                                ]
                            )
                            envPool
                pure NoContent
            )
            mReg

{- | Parse the course registration id and subscription id from a completed
checkout session webhook payload.
-}
parseCheckoutSessionCourseSubscription :: Aeson.Value -> Maybe (Int64, T.Text)
parseCheckoutSessionCourseSubscription payload = do
    regIdText <-
        parseMaybe
            ( Aeson.withObject "event" $ \evt -> do
                dataObj <- evt Aeson..: "data" :: Parser Object
                obj <- dataObj Aeson..: "object" :: Parser Object
                metadataObj <- obj Aeson..: "metadata" :: Parser Object
                metadataObj Aeson..: "course_registration_id" :: Parser T.Text
            )
            payload
    subId <-
        parseMaybe
            ( Aeson.withObject "event" $ \evt -> do
                dataObj <- evt Aeson..: "data" :: Parser Object
                obj <- dataObj Aeson..: "object" :: Parser Object
                obj Aeson..: "subscription" :: Parser T.Text
            )
            payload
    regIdNum <- readMaybe (T.unpack regIdText)
    pure (regIdNum, subId)

{- | Webhook handler for `customer.subscription.updated`. Mirrors the
subscription status onto the registration. Terminal statuses also flip the
registration status itself so the application treats it as cancelled.
-}
handleStripeSubscriptionUpdated :: UTCTime -> Aeson.Value -> AppM NoContent
handleStripeSubscriptionUpdated now payload =
    maybe (pure NoContent) updateSubscriptionRegistration $
        parseSubscriptionEvent payload
  where
    updateSubscriptionRegistration (subId, subStatus) = do
        Env{..} <- ask
        mReg <-
            liftIO $
                runSqlPool
                    (selectFirst [ME.CourseRegistrationStripeSubscriptionId ==. Just subId] [])
                    envPool
        maybe
            (pure NoContent)
            ( \(Entity regKey _) -> do
                let terminalStatuses = ["canceled", "unpaid", "incomplete_expired"]
                    registrationUpdates =
                        (ME.CourseRegistrationSubscriptionStatus =. Just subStatus)
                            : (ME.CourseRegistrationUpdatedAt =. now)
                            : [ ME.CourseRegistrationStatus =. "cancelled"
                              | subStatus `elem` terminalStatuses
                              ]
                liftIO $ runSqlPool (update regKey registrationUpdates) envPool
                pure NoContent
            )
            mReg

{- | Webhook handler for `customer.subscription.deleted`. Always flips the
registration to @cancelled@.
-}
handleStripeSubscriptionDeleted :: UTCTime -> Aeson.Value -> AppM NoContent
handleStripeSubscriptionDeleted now payload =
    maybe (pure NoContent) cancelSubscriptionRegistration $
        parseSubscriptionEvent payload
  where
    cancelSubscriptionRegistration (subId, _) = do
        Env{..} <- ask
        mReg <-
            liftIO $
                runSqlPool
                    (selectFirst [ME.CourseRegistrationStripeSubscriptionId ==. Just subId] [])
                    envPool
        maybe
            (pure NoContent)
            ( \(Entity regKey _) -> do
                liftIO $
                    runSqlPool
                        ( update
                            regKey
                            [ ME.CourseRegistrationStatus =. "cancelled"
                            , ME.CourseRegistrationSubscriptionStatus =. Just "canceled"
                            , ME.CourseRegistrationUpdatedAt =. now
                            ]
                        )
                        envPool
                pure NoContent
            )
            mReg

-- | Parse (@id@, @status@) from a customer.subscription.* event payload.
parseSubscriptionEvent :: Aeson.Value -> Maybe (T.Text, T.Text)
parseSubscriptionEvent =
    parseMaybe $
        Aeson.withObject "event" $ \evt -> do
            dataObj <- evt Aeson..: "data" :: Parser Object
            obj <- dataObj Aeson..: "object" :: Parser Object
            sid <- obj Aeson..: "id" :: Parser T.Text
            st <- obj Aeson..: "status" :: Parser T.Text
            pure (sid, st)

data TicketCheckInLookup
    = TicketCheckInLookupById Int64
    | TicketCheckInLookupByCode T.Text
    deriving (Show, Eq)

decodeStoredArtistSocialLinks :: Maybe T.Text -> Either T.Text (Maybe ArtistSocialLinksDTO)
decodeStoredArtistSocialLinks Nothing = Right Nothing
decodeStoredArtistSocialLinks (Just raw)
    | T.null (T.strip raw) = Right Nothing
    | otherwise =
        case Aeson.eitherDecodeStrict' (TE.encodeUtf8 raw) of
            Right links -> Right (Just links)
            Left _ -> Left "Stored artist social links are invalid or contain unsupported fields"

encodeSocialLinks :: Maybe ArtistSocialLinksDTO -> Maybe T.Text
encodeSocialLinks mLinks =
    fmap (TE.decodeUtf8 . BL.toStrict . Aeson.encode) mLinks

data EventMetadataDTO = EventMetadataDTO
    { emTicketUrl :: Maybe T.Text
    , emImageUrl :: Maybe T.Text
    , emIsPublic :: Maybe Bool
    , emCurrency :: Maybe T.Text
    , emBudgetCents :: Maybe Int
    }

emptyEventMetadata :: EventMetadataDTO
emptyEventMetadata =
    EventMetadataDTO
        { emTicketUrl = Nothing
        , emImageUrl = Nothing
        , emIsPublic = Nothing
        , emCurrency = Nothing
        , emBudgetCents = Nothing
        }

instance Aeson.ToJSON EventMetadataDTO where
    toJSON EventMetadataDTO{..} =
        Aeson.object
            [ "ticketUrl" Aeson..= emTicketUrl
            , "imageUrl" Aeson..= emImageUrl
            , "isPublic" Aeson..= emIsPublic
            , "currency" Aeson..= emCurrency
            , "budgetCents" Aeson..= emBudgetCents
            ]

instance Aeson.FromJSON EventMetadataDTO where
    parseJSON = Aeson.withObject "EventMetadataDTO" $ \o -> do
        rejectUnknownStoredEventMetadataFields o
        EventMetadataDTO
            <$> o Aeson..:? "ticketUrl"
            <*> o Aeson..:? "imageUrl"
            <*> o Aeson..:? "isPublic"
            <*> o Aeson..:? "currency"
            <*> o Aeson..:? "budgetCents"

rejectUnknownStoredEventMetadataFields :: Object -> Parser ()
rejectUnknownStoredEventMetadataFields obj =
    case filter (`notElem` storedEventMetadataAllowedKeys) providedKeys of
        [] -> pure ()
        unexpected ->
            fail
                ( "Stored event metadata contains unknown fields: "
                    <> T.unpack (T.intercalate ", " unexpected)
                )
  where
    providedKeys = map AesonKey.toText (AesonKeyMap.keys obj)

storedEventMetadataAllowedKeys :: [T.Text]
storedEventMetadataAllowedKeys =
    [ "ticketUrl"
    , "imageUrl"
    , "isPublic"
    , "currency"
    , "budgetCents"
    ]

encodeEventMetadata :: EventMetadataDTO -> Maybe T.Text
encodeEventMetadata EventMetadataDTO{..}
    | isNothing emTicketUrl
        && isNothing emImageUrl
        && isNothing emIsPublic
        && isNothing emCurrency
        && isNothing emBudgetCents =
        Nothing
    | otherwise =
        Just
            ( TE.decodeUtf8 . BL.toStrict . Aeson.encode $
                EventMetadataDTO
                    { emTicketUrl = emTicketUrl
                    , emImageUrl = emImageUrl
                    , emIsPublic = emIsPublic
                    , emCurrency = emCurrency
                    , emBudgetCents = emBudgetCents
                    }
            )

applyNullableTextUpdate :: NullableFieldUpdate T.Text -> Maybe T.Text -> Maybe T.Text
applyNullableTextUpdate field existing =
    case field of
        FieldMissing -> existing
        FieldNull -> Nothing
        FieldValue value -> cleanMaybeText (Just value)

applyNullableBoolUpdate :: NullableFieldUpdate Bool -> Maybe Bool -> Maybe Bool
applyNullableBoolUpdate field existing =
    case field of
        FieldMissing -> existing
        FieldNull -> Nothing
        FieldValue value -> Just value

applyNullableIntUpdate :: (a -> Maybe b) -> NullableFieldUpdate a -> Maybe b -> Maybe b
applyNullableIntUpdate normalizeValue field existing =
    case field of
        FieldMissing -> existing
        FieldNull -> Nothing
        FieldValue value ->
            case normalizeValue value of
                Just normalized -> Just normalized
                Nothing -> existing

applyNullableNormalizedTextUpdate :: (Maybe T.Text -> Maybe T.Text) -> NullableFieldUpdate T.Text -> Maybe T.Text -> Maybe T.Text
applyNullableNormalizedTextUpdate normalizeValue field existing =
    case field of
        FieldMissing -> existing
        FieldNull -> Nothing
        FieldValue value ->
            case normalizeValue (Just value) of
                Just normalized -> Just normalized
                Nothing
                    | T.null (T.strip value) -> Nothing
                    | otherwise -> existing

normalizeNullableTextUpdate ::
    BL.ByteString ->
    (Maybe T.Text -> Maybe T.Text) ->
    NullableFieldUpdate T.Text ->
    Either ServerError (NullableFieldUpdate T.Text)
normalizeNullableTextUpdate _ _ FieldMissing = Right FieldMissing
normalizeNullableTextUpdate _ _ FieldNull = Right FieldNull
normalizeNullableTextUpdate invalidMessage normalizeValue (FieldValue value) =
    case cleanMaybeText (Just value) of
        Nothing -> Right FieldNull
        Just cleaned ->
            case normalizeValue (Just cleaned) of
                Just normalized -> Right (FieldValue normalized)
                Nothing -> Left err400{errBody = invalidMessage}

validateEventMetadataUpdate :: EventMetadataUpdateDTO -> Either ServerError EventMetadataUpdateDTO
validateEventMetadataUpdate EventMetadataUpdateDTO{..} = do
    normalizedTicketUrl <-
        normalizeNullableTextUpdate
            "eventTicketUrl must be an absolute https URL"
            normalizeEventMetadataUrl
            emuTicketUrl
    normalizedImageUrl <-
        normalizeNullableTextUpdate
            "eventImageUrl must be an absolute https URL"
            normalizeEventMetadataUrl
            emuImageUrl
    normalizedCurrency <-
        normalizeNullableTextUpdate
            "eventCurrency must be a 3-letter ISO code"
            normalizeEventCurrencyMaybe
            emuCurrency
    pure
        EventMetadataUpdateDTO
            { emuTicketUrl = normalizedTicketUrl
            , emuImageUrl = normalizedImageUrl
            , emuIsPublic = emuIsPublic
            , emuCurrency = normalizedCurrency
            , emuBudgetCents = emuBudgetCents
            }

validateEventMetadataUrlField :: T.Text -> Maybe T.Text -> Either ServerError (Maybe T.Text)
validateEventMetadataUrlField _ Nothing = Right Nothing
validateEventMetadataUrlField fieldName (Just rawUrl) =
    case cleanMaybeText (Just rawUrl) of
        Nothing -> Right Nothing
        Just urlVal
            | T.length urlVal > maxEventMetadataUrlChars ->
                Left
                    err400
                        { errBody =
                            BL.fromStrict . TE.encodeUtf8 $
                                fieldName
                                    <> " must be "
                                    <> T.pack (show maxEventMetadataUrlChars)
                                    <> " characters or fewer"
                        }
            | Just normalizedUrl <- normalizeEventMetadataUrl (Just urlVal) ->
                Right (Just normalizedUrl)
            | otherwise ->
                Left
                    err400
                        { errBody =
                            BL.fromStrict . TE.encodeUtf8 $
                                fieldName <> " must be an absolute https URL"
                        }

normalizeEventMetadataUrl :: Maybe T.Text -> Maybe T.Text
normalizeEventMetadataUrl rawValue = do
    urlVal <- cleanMaybeText rawValue
    if "https://" `T.isPrefixOf` T.toLower urlVal
        && T.length urlVal <= maxEventMetadataUrlChars
        && TrialsServer.isValidHttpUrl urlVal
        then Just urlVal
        else Nothing

maxEventMetadataUrlChars :: Int
maxEventMetadataUrlChars = 2048

applyEventMetadataUpdate :: EventMetadataUpdateDTO -> EventMetadataDTO -> EventMetadataDTO
applyEventMetadataUpdate EventMetadataUpdateDTO{..} existing =
    EventMetadataDTO
        { emTicketUrl = applyNullableTextUpdate emuTicketUrl (emTicketUrl existing)
        , emImageUrl = applyNullableTextUpdate emuImageUrl (emImageUrl existing)
        , emIsPublic = applyNullableBoolUpdate emuIsPublic (emIsPublic existing)
        , emCurrency = applyNullableNormalizedTextUpdate normalizeCurrencyMaybe emuCurrency (emCurrency existing)
        , emBudgetCents = applyNullableIntUpdate (\value -> normalizeBudgetCentsMaybe (Just value)) emuBudgetCents (emBudgetCents existing)
        }

data VenueContactMetadata = VenueContactMetadata
    { vcmPhone :: Maybe T.Text
    , vcmWebsite :: Maybe T.Text
    , vcmState :: Maybe T.Text
    , vcmZipCode :: Maybe T.Text
    , vcmImageUrl :: Maybe T.Text
    }

emptyVenueContactMetadata :: VenueContactMetadata
emptyVenueContactMetadata =
    VenueContactMetadata
        { vcmPhone = Nothing
        , vcmWebsite = Nothing
        , vcmState = Nothing
        , vcmZipCode = Nothing
        , vcmImageUrl = Nothing
        }

instance Aeson.ToJSON VenueContactMetadata where
    toJSON VenueContactMetadata{..} =
        Aeson.object
            [ "phone" Aeson..= vcmPhone
            , "website" Aeson..= vcmWebsite
            , "state" Aeson..= vcmState
            , "zipCode" Aeson..= vcmZipCode
            , "imageUrl" Aeson..= vcmImageUrl
            ]

instance Aeson.FromJSON VenueContactMetadata where
    parseJSON = Aeson.withObject "VenueContactMetadata" $ \o ->
        VenueContactMetadata
            <$> o Aeson..:? "phone"
            <*> o Aeson..:? "website"
            <*> o Aeson..:? "state"
            <*> o Aeson..:? "zipCode"
            <*> o Aeson..:? "imageUrl"

decodeVenueContactMetadata :: Maybe T.Text -> VenueContactMetadata
decodeVenueContactMetadata mTxt =
    case cleanMaybeText mTxt of
        Nothing -> emptyVenueContactMetadata
        Just raw ->
            case Aeson.decodeStrict (TE.encodeUtf8 raw) of
                Just meta -> meta
                Nothing -> emptyVenueContactMetadata{vcmPhone = Just raw}

encodeVenueContactMetadata :: VenueContactMetadata -> Maybe T.Text
encodeVenueContactMetadata VenueContactMetadata{..}
    | isNothing vcmPhone && isNothing vcmWebsite && isNothing vcmState && isNothing vcmZipCode && isNothing vcmImageUrl = Nothing
    | isJust vcmPhone && isNothing vcmWebsite && isNothing vcmState && isNothing vcmZipCode && isNothing vcmImageUrl = vcmPhone
    | otherwise =
        Just
            ( TE.decodeUtf8 . BL.toStrict . Aeson.encode $
                VenueContactMetadata
                    { vcmPhone = vcmPhone
                    , vcmWebsite = vcmWebsite
                    , vcmState = vcmState
                    , vcmZipCode = vcmZipCode
                    , vcmImageUrl = vcmImageUrl
                    }
            )

venueContactMetadataFromDTO :: VenueDTO -> VenueContactMetadata
venueContactMetadataFromDTO dto =
    let parsedContact = decodeVenueContactMetadata (venueContact dto)
     in VenueContactMetadata
            { vcmPhone = cleanMaybeText (venuePhone dto) <|> vcmPhone parsedContact
            , vcmWebsite = cleanMaybeText (venueWebsite dto) <|> vcmWebsite parsedContact
            , vcmState = cleanMaybeText (venueState dto) <|> vcmState parsedContact
            , vcmZipCode = cleanMaybeText (venueZipCode dto) <|> vcmZipCode parsedContact
            , vcmImageUrl = cleanMaybeText (venueImageUrl dto) <|> vcmImageUrl parsedContact
            }

applyVenueContactUpdate :: VenueContactUpdateDTO -> VenueContactMetadata -> VenueContactMetadata
applyVenueContactUpdate VenueContactUpdateDTO{..} existing =
    VenueContactMetadata
        { vcmPhone = applyNullableTextUpdate vcuPhone (vcmPhone existing)
        , vcmWebsite = applyNullableTextUpdate vcuWebsite (vcmWebsite existing)
        , vcmState = applyNullableTextUpdate vcuState (vcmState existing)
        , vcmZipCode = applyNullableTextUpdate vcuZipCode (vcmZipCode existing)
        , vcmImageUrl = applyNullableTextUpdate vcuImageUrl (vcmImageUrl existing)
        }

validateSocialEventsListOffset :: Maybe Int -> Either ServerError Int
validateSocialEventsListOffset Nothing = Right 0
validateSocialEventsListOffset (Just rawOffset)
    | rawOffset < 0 =
        Left err400{errBody = "offset must be greater than or equal to 0"}
    | rawOffset > maxSocialEventsListOffset =
        Left err400{errBody = "offset must be 10000 or fewer"}
    | otherwise =
        Right rawOffset

maxSocialEventsListOffset :: Int
maxSocialEventsListOffset = 10000

-- | Party identifiers are rendered as decimal Int64 keys; accept only that shape
-- so a filter cannot become a wildcard or a scan over unrelated text values.
validateArtistPartyIdFilter :: Maybe T.Text -> Either ServerError (Maybe T.Text)
validateArtistPartyIdFilter mRaw = do
    cleaned <- validateSocialEventsListFilter "partyId" mRaw
    case cleaned of
        Nothing -> Right Nothing
        Just value
            | T.length value <= 19 && T.all isDigit value && not (T.isPrefixOf "0" value) ->
                Right (Just value)
            | otherwise ->
                Left err400{errBody = "partyId must be a positive integer party identifier"}

validateSocialEventsListFilter :: T.Text -> Maybe T.Text -> Either ServerError (Maybe T.Text)
validateSocialEventsListFilter _ Nothing = Right Nothing
validateSocialEventsListFilter fieldName (Just rawFilter) =
    let trimmed = T.strip rawFilter
        err message =
            Left
                err400
                    { errBody = BL.fromStrict (TE.encodeUtf8 (fieldName <> " " <> message))
                    }
     in if T.null trimmed
            then Right Nothing
            else
                if T.length trimmed > maxSocialEventsListFilterChars
                    then
                        err
                            ( "must be "
                                <> T.pack (show maxSocialEventsListFilterChars)
                                <> " characters or fewer"
                            )
                    else
                        if T.any isUnsafeSocialEventsListFilterChar rawFilter
                            then err "must not contain control characters or hidden formatting characters"
                            else Right (Just trimmed)

maxSocialEventsListFilterChars :: Int
maxSocialEventsListFilterChars = 120

isUnsafeSocialEventsListFilterChar :: Char -> Bool
isUnsafeSocialEventsListFilterChar ch =
    isControl ch || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

validateEventListScope :: Maybe T.Text -> Either ServerError T.Text
validateEventListScope Nothing = Right "all"
validateEventListScope (Just rawScope) =
    case T.toCaseFold (T.strip rawScope) of
        "" -> Right "all"
        "all" -> Right "all"
        "subscribed" -> Right "subscribed"
        _ -> Left err400{errBody = "scope must be one of: all, subscribed"}

validateEventCountryCode :: T.Text -> Either ServerError T.Text
validateEventCountryCode rawCountry =
    let country = T.toUpper (T.strip rawCountry)
     in if T.length country == 2 && T.all isAsciiUpper country
            then Right country
            else Left err400{errBody = "country code must use two ISO-2 letters"}

validateEventCityInputs ::
    [EventCityInputDTO] ->
    Either ServerError [(T.Text, T.Text, T.Text, Maybe T.Text)]
validateEventCityInputs rawCities
    | length rawCities > maxEventCitySubscriptions =
        Left err400{errBody = "A user may subscribe to at most 20 cities"}
    | otherwise =
        fmap reverse (go Set.empty [] rawCities)
  where
    go _ acc [] = Right acc
    go seen acc (EventCityInputDTO{..} : remaining) = do
        let name = T.unwords (T.words (T.strip eventCityInputName))
            normalizedName = normalizeEventCityName name
        whenEither
            ( T.null name
                || T.length name > maxSocialEventsListFilterChars
                || T.any isUnsafeSocialEventsListFilterChar eventCityInputName
            )
            err400{errBody = "city name must be a safe value between 1 and 120 characters"}
        countryCode <- validateEventCountryCode eventCityInputCountryCode
        timeZone <- traverse validateEventTimeZone eventCityInputTimeZone
        let cityKey = (normalizedName, countryCode)
        if Set.member cityKey seen
            then go seen acc remaining
            else
                go
                    (Set.insert cityKey seen)
                    ((name, normalizedName, countryCode, timeZone) : acc)
                    remaining

    whenEither True err = Left err
    whenEither False _ = Right ()

maxEventCitySubscriptions :: Int
maxEventCitySubscriptions = 20

validateEventTimeZone :: T.Text -> Either ServerError T.Text
validateEventTimeZone rawTimeZone =
    let timeZone = T.strip rawTimeZone
        allowed ch = isAlphaNum ch || ch `elem` ("_+-/" :: String)
     in if T.null timeZone
            then Left err400{errBody = "time zone must be omitted instead of blank"}
            else
                if T.length timeZone <= 64 && T.all allowed timeZone
                    then Right timeZone
                    else Left err400{errBody = "time zone must be a valid IANA-style identifier"}

normalizeEventCityName :: T.Text -> T.Text
normalizeEventCityName = T.toCaseFold . T.unwords . T.words . T.strip

loadSubscribedEventCities ::
    ConnectionPool ->
    T.Text ->
    IO [Entity EventCity]
loadSubscribedEventCities pool partyId = do
    subscriptions <-
        runSqlPool
            (selectList [EventCitySubscriptionPartyId ==. partyId] [])
            pool
    let cityKeys = map (eventCitySubscriptionCityId . entityVal) subscriptions
    if null cityKeys
        then pure []
        else runSqlPool (selectList [EventCityId <-. cityKeys] [Asc EventCityName]) pool

eventCityEntityToDTO :: Bool -> Entity EventCity -> EventCityDTO
eventCityEntityToDTO subscribed (Entity cityKey city) =
    EventCityDTO
        { eventCityId = renderKeyText cityKey
        , eventCityName = SM.eventCityName city
        , eventCityCountryCode = SM.eventCityCountryCode city
        , eventCityTimeZone = SM.eventCityTimeZone city
        , eventCitySubscribed = subscribed
        }

type ValidatedDiscoverySourceWrite =
    (T.Text, T.Text, T.Text, Maybe T.Text, Maybe EventCityId, Bool, Int)

validateDiscoverySourceWrite ::
    DiscoverySourceWriteDTO ->
    Either ServerError ValidatedDiscoverySourceWrite
validateDiscoverySourceWrite DiscoverySourceWriteDTO{..} = do
    let sourceKey = T.toLower (T.strip discoverySourceWriteKey)
        sourceName = T.unwords (T.words (T.strip discoverySourceWriteName))
        sourceType = T.toLower (T.strip discoverySourceWriteType)
        feedUrl = cleanMaybeText discoverySourceWriteFeedUrl
    unlessEither
        ( not (T.null sourceKey)
            && T.length sourceKey <= 80
            && T.all (\ch -> isAsciiLower ch || ch `elem` ("0123456789_-" :: String)) sourceKey
        )
        "source key must use lowercase letters, digits, underscores, or hyphens"
    unlessEither
        ( not (T.null sourceName)
            && T.length sourceName <= 160
            && not (T.any isUnsafeSocialEventsListFilterChar discoverySourceWriteName)
        )
        "source name must be a safe value between 1 and 160 characters"
    unlessEither
        (sourceType `elem` ["ticketmaster", "buenplan", "ical", "json", "web"])
        "source type must be one of: ticketmaster, buenplan, ical, json, web"
    unlessEither
        (discoverySourceWritePriority >= 0 && discoverySourceWritePriority <= 10000)
        "source priority must be between 0 and 10000"
    cityKey <-
        traverse
            (fmap toSqlKey . parseInt64Either "event city")
            (cleanMaybeText discoverySourceWriteCityId)
    case sourceType of
        "ticketmaster" -> do
            unlessEither (sourceKey == "ticketmaster") "Ticketmaster must use the ticketmaster source key"
            unlessEither (isNothing feedUrl && isNothing cityKey) "Ticketmaster does not accept a feed URL or city"
        "buenplan" -> do
            unlessEither (sourceKey == "buenplan") "Buen Plan must use the buenplan source key"
            unlessEither (isNothing feedUrl && isNothing cityKey) "Buen Plan does not accept a feed URL or city"
        "web" -> do
            url <-
                maybe
                    (Left err400{errBody = "Web research sources require an HTTPS homepage URL"})
                    Right
                    feedUrl
            unlessEither
                ( T.length url <= 2048
                    && "https://" `T.isPrefixOf` T.toLower url
                    && TrialsServer.isValidHttpUrl url
                )
                "Web research source URL must be a valid HTTPS URL"
            unlessEither (isNothing cityKey) "Web research sources are not tied to one event city"
            unlessEither (not discoverySourceWriteEnabled) "Web research sources must remain disabled for automated cron ingestion"
        _ -> do
            url <-
                maybe
                    (Left err400{errBody = "Venue feeds require an HTTPS feed URL"})
                    Right
                    feedUrl
            unlessEither
                ( T.length url <= 2048
                    && "https://" `T.isPrefixOf` T.toLower url
                    && TrialsServer.isValidHttpUrl url
                )
                "Venue feed URL must be a valid HTTPS URL"
            unlessEither (isJust cityKey) "Venue feeds require an event city"
    pure
        ( sourceKey
        , sourceName
        , sourceType
        , feedUrl
        , cityKey
        , discoverySourceWriteEnabled
        , discoverySourceWritePriority
        )
  where
    unlessEither True _ = Right ()
    unlessEither False message =
        Left err400{errBody = BL.fromStrict (TE.encodeUtf8 message)}

resolveDiscoverySourceCity ::
    ConnectionPool ->
    ValidatedDiscoverySourceWrite ->
    IO (Either ServerError ValidatedDiscoverySourceWrite)
resolveDiscoverySourceCity pool validated@(_, _, _, _, cityKey, _, _) =
    case cityKey of
        Nothing -> pure (Right validated)
        Just key -> do
            city <- runSqlPool (get key) pool
            pure $
                case city of
                    Nothing -> Left err400{errBody = "Configured event city does not exist"}
                    Just _ -> Right validated

discoverySourceEntityToDTO ::
    Entity EventDiscoverySource ->
    SqlPersistT IO DiscoverySourceDTO
discoverySourceEntityToDTO (Entity sourceKey source) = do
    city <- traverse get (eventDiscoverySourceCityId source)
    pure
        DiscoverySourceDTO
            { discoverySourceId = renderKeyText sourceKey
            , discoverySourceKey = eventDiscoverySourceSourceKey source
            , discoverySourceName = eventDiscoverySourceName source
            , discoverySourceType = eventDiscoverySourceSourceType source
            , discoverySourceFeedUrl = eventDiscoverySourceFeedUrl source
            , discoverySourceCityId = renderKeyText <$> eventDiscoverySourceCityId source
            , discoverySourceCityName = SM.eventCityName <$> join city
            , discoverySourceCountryCode = SM.eventCityCountryCode <$> join city
            , discoverySourceEnabled = eventDiscoverySourceEnabled source
            , discoverySourcePriority = eventDiscoverySourcePriority source
            , discoverySourceConsecutiveFailures =
                eventDiscoverySourceConsecutiveFailures source
            , discoverySourceLastSuccessAt = eventDiscoverySourceLastSuccessAt source
            , discoverySourceLastError = eventDiscoverySourceLastError source
            , discoverySourceUpdatedAt = eventDiscoverySourceUpdatedAt source
            }

venueMatchesEventCity :: Venue -> Entity EventCity -> Bool
venueMatchesEventCity venue (Entity _ city) =
    maybe False ((== SM.eventCityNormalizedName city) . normalizeEventCityName) (SM.venueCity venue)
        && countryMatches
  where
    countryMatches =
        case fmap (T.toUpper . T.strip) (SM.venueCountry venue) of
            Nothing -> True
            Just "" -> True
            Just country
                | T.length country == 2 -> country == SM.eventCityCountryCode city
                | otherwise -> True

socialEventsServer :: AuthedUser -> ServerT SocialEventsAPI AppM
socialEventsServer = socialEventsServerWithStripeRefund Stripe.createRefund

-- Keep provider execution injectable for transaction/failure regressions.
socialEventsServerWithStripeRefund
    :: (Stripe.StripeConfig -> T.Text -> Int -> IO (Either T.Text Aeson.Value))
    -> AuthedUser -> ServerT SocialEventsAPI AppM
socialEventsServerWithStripeRefund issueStripeRefund user =
    eventsServer
        :<|> eventCitiesServer
        :<|> eventDiscoverySourcesServer
        :<|> EventResearch.eventResearchServer user
        :<|> venuesServer
        :<|> artistsServer
        :<|> rsvpsServer
        :<|> invitationsServer
        :<|> momentsServer
        :<|> liveBroadcastsServer
        :<|> ticketsServer
        :<|> budgetServer
        :<|> financeServer
        :<|> logisticsServer
        :<|> memoryInvitationsServer
  where
    currentPartyId :: T.Text
    currentPartyId = renderPartyId user

    requireFeatureAction :: T.Text -> T.Text -> AppM ()
    requireFeatureAction featureId action =
        either throwError pure (validateSocialEventsFeatureAction featureId action user)

    requireEventVisibleToUser :: SocialEventId -> AppM ()
    requireEventVisibleToUser eventKey =
        unless (hasStrictAdminAccess user) $ do
            Env{..} <- ask
            hidden <- liftIO $ runSqlPool (isImportedEventHidden eventKey) envPool
            when hidden $ throwError err404{errBody = "Event not found"}

    parseVisibleEventKey :: T.Text -> AppM SocialEventId
    parseVisibleEventKey rawId = do
        eventKey <- parseKeyOr400 "event" rawId
        requireEventVisibleToUser eventKey
        pure eventKey

    memoryInvitationsServer :: ServerT MemoryInvitationRoutes AppM
    memoryInvitationsServer =
        memoryPreferences Nothing
        :<|> (memoryPreferences . Just)
        :<|> (\eventId -> memoryCampaign eventId Nothing)
        :<|> (\eventId desired -> memoryCampaign eventId (Just desired))
        :<|> (\eventId deliveryId -> do
            eventKey <- (parseKeyOr400 "event" eventId :: AppM SocialEventId)
            memoryQuery "SELECT event_memory_open(?,?,?::uuid)::text"
                [toPersistValue eventKey, toPersistValue (auPartyId user), PersistText (UUID.toText deliveryId)])
      where
        memoryPreferences desired = memoryQuery "SELECT event_memory_preferences(?,?)::text"
            [toPersistValue (auPartyId user), maybe PersistNull PersistBool desired]
        memoryCampaign eventId desired = do
            eventKey <- (parseKeyOr400 "event" eventId :: AppM SocialEventId)
            memoryQuery "SELECT event_memory_summary(?,?,?)::text"
                [toPersistValue eventKey, toPersistValue (auPartyId user), maybe PersistNull PersistBool desired]
        memoryQuery :: T.Text -> [PersistValue] -> AppM (Headers '[Header "Cache-Control" T.Text] Aeson.Value)
        memoryQuery statement parameters = do
            Env{..} <- ask
            result <- liftIO $ try $ runSqlPool (withCurrentAuthSession user $ do
                installed <- rawSql "SELECT to_regprocedure('event_memory_dispatch_batch(integer)') IS NOT NULL" [] :: SqlPersistT IO [Single Bool]
                if installed == [Single True]
                    then (rawSql statement parameters :: SqlPersistT IO [Single T.Text])
                    else pure []) envPool
            rows <- case result of
                Left (_ :: SqlError) -> throwError err503{errBody="Memory invitations are temporarily unavailable",errHeaders=[("Cache-Control","no-store")]}
                Right Nothing -> throwError err401
                Right (Just value) -> pure value
            case rows of
                [Single body] -> case Aeson.eitherDecodeStrict' (TE.encodeUtf8 body) of
                    Right value@(Aeson.Object fields)
                        | not (AesonKeyMap.member "error" fields) -> pure (addHeader ("no-store" :: T.Text) value)
                    _ -> throwError err404
                _ -> throwError err404{errBody="Memory invitations are not installed",errHeaders=[("Cache-Control","no-store")]}

    -- Events
    eventsServer :: ServerT EventsRoutes AppM
    eventsServer =
        listEvents
            :<|> createEvent
            :<|> getEvent
            :<|> updateEvent
            :<|> uploadEventImage
            :<|> deleteEvent

    listEvents :: Maybe T.Text -> Maybe T.Text -> Maybe T.Text -> Maybe T.Text -> Maybe T.Text -> Maybe T.Text -> Maybe T.Text -> Maybe Int -> Maybe Int -> AppM [EventDTO]
    listEvents mCity mScope mStartAfter mTypeId mWorkflowStateId mArtistId mVenueId mLimit mOffset = do
        Env{..} <- ask
        limit <- resolveLimit 200 500 mLimit
        offset <- either throwError pure (validateSocialEventsListOffset mOffset)
        scope <- either throwError pure (validateEventListScope mScope)
        eventTypeFilter <- traverse
            (\rawId -> liftIO (runSqlPool (loadKnownEventTypeId rawId) envPool) >>= either throwError pure)
            (cleanMaybeText mTypeId)
        workflowStateFilter <- traverse
            (\rawId -> do
                stateId <- either throwError pure (parseEventWorkflowStateId rawId)
                resolved <- liftIO $ runSqlPool (EventLifecycle.loadActiveSocialEventState stateId) envPool
                maybe (throwError invalidEventWorkflowStateReference) (const (pure stateId)) resolved
            )
            (cleanMaybeText mWorkflowStateId)
        cityFilterText <-
            either throwError pure $
                validateSocialEventsListFilter "city" mCity
        startFilter <- case mStartAfter of
            Nothing -> pure []
            Just raw ->
                case iso8601ParseM (T.unpack raw) of
                    Just t -> pure [SocialEventStartTime >=. t]
                    Nothing -> throwError err400{errBody = "Invalid start_after value (expected ISO-8601 datetime)"}
        cityFilter <- do
            venueRows <- liftIO $ runSqlPool (selectList [] [LimitTo 5000]) envPool
            subscribedCities <-
                if scope == "subscribed"
                    then liftIO (loadSubscribedEventCities envPool currentPartyId)
                    else pure []
            let cityNeedle = T.toCaseFold <$> cityFilterText
                matchesRequestedCity venue =
                    case cityNeedle of
                        Nothing -> True
                        Just needle ->
                            maybe
                                False
                                (T.isInfixOf needle . T.toCaseFold)
                                (SM.venueCity venue)
                requestedVenueIds =
                    [ entityKey venueRow
                    | venueRow@(Entity _ venue) <- venueRows
                    , matchesRequestedCity venue
                    ]
                subscribedVenueIds =
                    [ entityKey venueRow
                    | venueRow@(Entity _ venue) <- venueRows
                    , any (venueMatchesEventCity venue) subscribedCities
                    ]
            subscribedEventIds <-
                if scope /= "subscribed"
                    then pure []
                    else liftIO $ runSqlPool (resolveSubscribedEventIds subscribedCities subscribedVenueIds) envPool
            if (isJust cityFilterText && null requestedVenueIds)
                || (scope == "subscribed" && null subscribedEventIds)
                then pure [SocialEventId ==. toSqlKey 0]
                else
                    pure $
                        (if isJust cityFilterText then [SocialEventVenueId <-. map Just requestedVenueIds] else [])
                            ++ (if scope == "subscribed" then [SocialEventId <-. subscribedEventIds] else [])
        venueFilter <- case fmap T.strip mVenueId of
            Nothing -> pure []
            Just "" -> pure []
            Just raw -> do
                venueKey <- either throwError pure (parseVenueIdEither raw)
                pure [SocialEventVenueId ==. Just venueKey]
        artistFilter <- case fmap T.strip mArtistId of
            Nothing -> pure []
            Just "" -> pure []
            Just raw -> do
                artistKey <- parseArtistId raw
                artistLinks <- liftIO $ runSqlPool (selectList [EventArtistArtistId ==. artistKey] []) envPool
                let eventIds = map (eventArtistEventId . entityVal) artistLinks
                if null eventIds
                    then pure [SocialEventId ==. toSqlKey 0]
                    else pure [SocialEventId <-. eventIds]
        let filters =
                startFilter
                    ++ cityFilter
                    ++ venueFilter
                    ++ artistFilter
                    ++ maybe [] (\eventTypeUuid -> [SocialEventEventTypeId ==. Just eventTypeUuid]) eventTypeFilter
                    ++ maybe [] (\stateUuid -> [SocialEventWorkflowStateId ==. Just stateUuid]) workflowStateFilter
        let dateOrder =
                case mStartAfter of
                    Just _ -> Asc SocialEventStartTime
                    Nothing -> Desc SocialEventStartTime
        rows <-
            liftIO $
                runSqlPool
                    ( if hasStrictAdminAccess user
                        then selectUnsuppressedSocialEvents filters dateOrder limit offset
                        else selectVisibleSocialEvents filters dateOrder limit offset
                    )
                    envPool
        loadSocialEventListDTOs (defaultCurrency envConfig) envPool rows

    resolveSubscribedEventIds ::
        [Entity EventCity] ->
        [VenueId] ->
        SqlPersistT IO [SocialEventId]
    resolveSubscribedEventIds subscribedCities subscribedVenueIds = do
        refs <- selectList [] []
        let referencedEventIds =
                Set.fromList (map (externalEventRefEventId . entityVal) refs)
            importedMatches =
                [ externalEventRefEventId ref
                | Entity _ ref <- refs
                , any (externalRefMatchesCity ref . entityVal) subscribedCities
                ]
        localEvents <-
            if null subscribedVenueIds
                then pure []
                else selectList [SocialEventVenueId <-. map Just subscribedVenueIds] [LimitTo 10000]
        let localMatches =
                [ eventKey
                | Entity eventKey _ <- localEvents
                , Set.notMember eventKey referencedEventIds
                ]
        pure (Set.toList (Set.fromList (importedMatches ++ localMatches)))

    externalRefMatchesCity :: ExternalEventRef -> EventCity -> Bool
    externalRefMatchesCity ref city =
        normalizeEventCityName (externalEventRefCity ref) == SM.eventCityNormalizedName city
            && maybe
                True
                ((== SM.eventCityCountryCode city) . T.toUpper . T.strip)
                (externalEventRefCountryCode ref)

    eventCitiesServer :: ServerT EventCitiesRoutes AppM
    eventCitiesServer =
        listEventCities
            :<|> getCitySubscriptions
            :<|> replaceCitySubscriptions

    eventDiscoverySourcesServer :: ServerT EventDiscoverySourcesRoutes AppM
    eventDiscoverySourcesServer =
        listDiscoverySources
            :<|> createDiscoverySource
            :<|> updateDiscoverySource

    requireDiscoverySourceAdmin :: AppM ()
    requireDiscoverySourceAdmin =
        unless (hasStrictAdminAccess user) $
            throwError err403{errBody = "Strict admin access required"}

    listDiscoverySources :: AppM [DiscoverySourceDTO]
    listDiscoverySources = do
        requireDiscoverySourceAdmin
        Env{..} <- ask
        liftIO $
            runSqlPool
                (do
                    rows <- selectList [] [Desc EventDiscoverySourcePriority, Asc EventDiscoverySourceName]
                    mapM discoverySourceEntityToDTO rows
                )
                envPool

    createDiscoverySource :: DiscoverySourceWriteDTO -> AppM DiscoverySourceDTO
    createDiscoverySource payload = do
        requireDiscoverySourceAdmin
        Env{..} <- ask
        validated <- either throwError pure (validateDiscoverySourceWrite payload)
        resolved <-
            liftIO (resolveDiscoverySourceCity envPool validated)
                >>= either throwError pure
        now <- liftIO getCurrentTime
        result <-
            liftIO $
                runSqlPool
                    (do
                        let (sourceKey, sourceName, sourceType, feedUrl, cityKey, enabled, priority) =
                                resolved
                        existing <- getBy (UniqueEventDiscoverySource sourceKey)
                        case existing of
                            Just _ -> pure (Left err409{errBody = "Event source key already exists"})
                            Nothing -> do
                                let newRow =
                                        EventDiscoverySource
                                            { eventDiscoverySourceSourceKey = sourceKey
                                            , eventDiscoverySourceName = sourceName
                                            , eventDiscoverySourceSourceType = sourceType
                                            , eventDiscoverySourceFeedUrl = feedUrl
                                            , eventDiscoverySourceCityId = cityKey
                                            , eventDiscoverySourceEnabled = enabled
                                            , eventDiscoverySourcePriority = priority
                                            , eventDiscoverySourceConfiguration = Nothing
                                            , eventDiscoverySourceEtag = Nothing
                                            , eventDiscoverySourceLastModified = Nothing
                                            , eventDiscoverySourceConsecutiveFailures = 0
                                            , eventDiscoverySourceLastSuccessAt = Nothing
                                            , eventDiscoverySourceLastError = Nothing
                                            , eventDiscoverySourceCreatedAt = now
                                            , eventDiscoverySourceUpdatedAt = now
                                            }
                                key <- insert newRow
                                Right <$> discoverySourceEntityToDTO (Entity key newRow)
                    )
                    envPool
        either throwError pure result

    updateDiscoverySource :: T.Text -> DiscoverySourceWriteDTO -> AppM DiscoverySourceDTO
    updateDiscoverySource rawSourceId payload = do
        requireDiscoverySourceAdmin
        Env{..} <- ask
        sourceKeyId <-
            either throwError pure $
                fmap toSqlKey (parseInt64Either "event source" rawSourceId)
        validated <- either throwError pure (validateDiscoverySourceWrite payload)
        resolved <-
            liftIO (resolveDiscoverySourceCity envPool validated)
                >>= either throwError pure
        now <- liftIO getCurrentTime
        result <-
            liftIO $
                runSqlPool
                    (do
                        existing <- get sourceKeyId
                        case existing of
                            Nothing -> pure (Left err404)
                            Just existingRow -> do
                                let (sourceKey, sourceName, sourceType, feedUrl, cityKey, enabled, priority) =
                                        resolved
                                if eventDiscoverySourceSourceType existingRow
                                    `elem` ["ticketmaster", "buenplan"]
                                    && ( sourceKey /= eventDiscoverySourceSourceKey existingRow
                                            || sourceType /= eventDiscoverySourceSourceType existingRow
                                       )
                                    then
                                        pure
                                            ( Left
                                                err400
                                                    { errBody =
                                                        "Built-in source identity cannot be changed"
                                                    }
                                            )
                                    else do
                                        conflicting <- getBy (UniqueEventDiscoverySource sourceKey)
                                        case conflicting of
                                            Just (Entity conflictingKey _)
                                                | conflictingKey /= sourceKeyId ->
                                                    pure (Left err409{errBody = "Event source key already exists"})
                                            _ -> do
                                                update
                                                    sourceKeyId
                                                    [ EventDiscoverySourceSourceKey =. sourceKey
                                                    , EventDiscoverySourceName =. sourceName
                                                    , EventDiscoverySourceSourceType =. sourceType
                                                    , EventDiscoverySourceFeedUrl =. feedUrl
                                                    , EventDiscoverySourceCityId =. cityKey
                                                    , EventDiscoverySourceEnabled =. enabled
                                                    , EventDiscoverySourcePriority =. priority
                                                    , EventDiscoverySourceConsecutiveFailures =. 0
                                                    , EventDiscoverySourceLastError =. Nothing
                                                    , EventDiscoverySourceUpdatedAt =. now
                                                    ]
                                                refreshed <- get sourceKeyId
                                                case refreshed of
                                                    Nothing -> pure (Left err404)
                                                    Just row ->
                                                        Right <$> discoverySourceEntityToDTO (Entity sourceKeyId row)
                    )
                    envPool
        either throwError pure result

    listEventCities :: Maybe T.Text -> Maybe T.Text -> AppM [EventCityDTO]
    listEventCities rawQuery rawCountry = do
        Env{..} <- ask
        query <-
            either throwError pure $
                validateSocialEventsListFilter "q" rawQuery
        country <- traverse (either throwError pure . validateEventCountryCode) rawCountry
        liftIO $ do
            cities <- runSqlPool (selectList [] [Asc EventCityName, LimitTo 500]) envPool
            subscribed <- loadSubscribedEventCities envPool currentPartyId
            let subscribedIds = Set.fromList (map entityKey subscribed)
                matchesQuery city =
                    maybe
                        True
                        (\needle -> T.toCaseFold needle `T.isInfixOf` T.toCaseFold (SM.eventCityName city))
                        query
                matchesCountry city =
                    maybe True (== SM.eventCityCountryCode city) country
            pure
                [ eventCityEntityToDTO (Set.member cityKey subscribedIds) cityEntity
                | cityEntity@(Entity cityKey city) <- cities
                , matchesQuery city
                , matchesCountry city
                ]

    getCitySubscriptions :: AppM [EventCityDTO]
    getCitySubscriptions = do
        Env{..} <- ask
        liftIO $ do
            cities <- loadSubscribedEventCities envPool currentPartyId
            pure (map (eventCityEntityToDTO True) cities)

    replaceCitySubscriptions :: EventCitySubscriptionUpdateDTO -> AppM [EventCityDTO]
    replaceCitySubscriptions EventCitySubscriptionUpdateDTO{eventCities = requestedCities} = do
        Env{..} <- ask
        validated <- either throwError pure (validateEventCityInputs requestedCities)
        now <- liftIO getCurrentTime
        liftIO $
            runSqlPool
                (do
                    cityKeys <-
                        forM validated $ \(name, normalizedName, countryCode, timeZone) -> do
                            existing <- getBy (UniqueEventCity normalizedName countryCode)
                            case existing of
                                Just (Entity cityKey _) -> do
                                    update
                                        cityKey
                                        [ EventCityName =. name
                                        , EventCityTimeZone =. timeZone
                                        , EventCityUpdatedAt =. now
                                        ]
                                    pure cityKey
                                Nothing ->
                                    insert
                                        EventCity
                                            { eventCityName = name
                                            , eventCityNormalizedName = normalizedName
                                            , eventCityCountryCode = countryCode
                                            , eventCityTimeZone = timeZone
                                            , eventCityCreatedAt = now
                                            , eventCityUpdatedAt = now
                                            }
                    deleteWhere [EventCitySubscriptionPartyId ==. currentPartyId]
                    forM_ cityKeys $ \cityKey -> do
                        _ <-
                            insertUnique
                                EventCitySubscription
                                    { eventCitySubscriptionPartyId = currentPartyId
                                    , eventCitySubscriptionCityId = cityKey
                                    , eventCitySubscriptionCreatedAt = now
                                    }
                        pure ()
                    rows <- selectList [EventCityId <-. cityKeys] [Asc EventCityName]
                    pure (map (eventCityEntityToDTO True) rows)
                )
                envPool

    loadKnownEventTypeId :: T.Text -> SqlPersistT IO (Either ServerError UUID.UUID)
    loadKnownEventTypeId rawEventTypeId =
        case UUID.fromText (T.strip rawEventTypeId) of
            Nothing -> pure (Left invalidEventTypeReference)
            Just eventTypeUuid ->
                case fromPathPiece (UUID.toText eventTypeUuid) of
                    Nothing -> pure (Left invalidEventTypeReference)
                    Just eventTypeKey -> do
                        mEventType <- getEntity (eventTypeKey :: Catalog.EventTypeId)
                        case mEventType of
                            Nothing -> pure (Left invalidEventTypeReference)
                            Just _ -> pure (Right eventTypeUuid)

    loadSelectableEventTypeId :: UTCTime -> T.Text -> SqlPersistT IO (Either ServerError UUID.UUID)
    loadSelectableEventTypeId now rawEventTypeId = do
        knownResult <- loadKnownEventTypeId rawEventTypeId
        case knownResult of
            Left serverError -> pure (Left serverError)
            Right eventTypeUuid ->
                case fromPathPiece (UUID.toText eventTypeUuid) of
                    Nothing -> pure (Left invalidEventTypeReference)
                    Just eventTypeKey -> do
                        eventType <- getJust (eventTypeKey :: Catalog.EventTypeId)
                        catalog <- getJust (Catalog.eventTypeCatalogId eventType)
                        workflowState <- getJust (Catalog.eventTypeWorkflowStateId eventType)
                        let today = utctDay now
                            effective =
                                maybe True (<= today) (Catalog.eventTypeEffectiveFrom eventType)
                                    && maybe True (>= today) (Catalog.eventTypeEffectiveUntil eventType)
                            selectable =
                                Catalog.eventTypeActive eventType
                                    && Catalog.catalogDefinitionActive catalog
                                    && Catalog.catalogDefinitionCode catalog == "event-types"
                                    && isNothing (Catalog.eventTypeDeprecatedAt eventType)
                                    && Catalog.workflowStateActive workflowState
                                    && Catalog.workflowStateCode workflowState == "published"
                                    && Catalog.workflowStateWorkflowId workflowState
                                        == Catalog.catalogDefinitionWorkflowId catalog
                                    && effective
                        pure (if selectable then Right eventTypeUuid else Left invalidEventTypeReference)

    invalidEventTypeReference :: ServerError
    invalidEventTypeReference =
        err422
            { errBody =
                "eventTypeId must reference an active, effective, published event type"
            }

    invalidEventWorkflowStateReference :: ServerError
    invalidEventWorkflowStateReference =
        err422
            { errBody =
                "eventWorkflowStateId must reference an active state in social-event-lifecycle"
            }

    createEvent :: EventDTO -> AppM EventDTO
    createEvent dto = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        titleVal <- either throwError pure (validateEventTitleInput (eventTitle dto))
        either throwError pure (validateEventTimeRange (eventStart dto) (eventEnd dto))
        timezoneVal <- traverse (either throwError pure . validateEventTimeZone) (eventTimezone dto)
        either throwError pure $
            validateEventCreateUpdateDimensions
                (eventPriceCents dto)
                (eventCapacity dto)
                (eventBudgetCents dto)
        requestedEventTypeId <-
            maybe (throwError invalidEventTypeReference) pure (cleanMaybeText (eventTypeId dto))
        eventTypeUuid <-
            liftIO (runSqlPool (loadSelectableEventTypeId now requestedEventTypeId) envPool)
                >>= either throwError pure
        validateEventReadOnlyProjectionOmitted dto
        initialWorkflowStateId <- liftIO $ runSqlPool EventLifecycle.resolveInitialSocialEventStateId envPool
        workflowStateId <- case cleanMaybeText (eventWorkflowStateId dto) of
            Nothing -> pure initialWorkflowStateId
            Just rawId -> do
                requestedId <- either throwError pure (parseEventWorkflowStateId rawId)
                activeState <- liftIO $ runSqlPool (EventLifecycle.loadActiveSocialEventState requestedId) envPool
                when (isNothing activeState || requestedId /= initialWorkflowStateId) $
                    throwError invalidEventWorkflowStateReference
                pure requestedId
        currencyVal <- either throwError pure (validateEventCurrencyInput (defaultCurrency envConfig) (eventCurrency dto))
        unless (currencyVal `elem` supportedCurrencies envConfig) $
            throwError err400{errBody = "Currency is not enabled by SUPPORTED_CURRENCIES"}
        ticketUrlVal <-
            either throwError pure $
                validateEventMetadataUrlField "eventTicketUrl" (eventTicketUrl dto)
        imageUrlVal <-
            either throwError pure $
                validateEventMetadataUrlField "eventImageUrl" (eventImageUrl dto)
        artistKeys <- either throwError pure (validateEventArtistIds (eventArtists dto))
        let metadataVal =
                encodeEventMetadata
                    EventMetadataDTO
                        { emTicketUrl = ticketUrlVal
                        , emImageUrl = imageUrlVal
                        , emIsPublic = eventIsPublic dto <|> Just True
                        , emCurrency = Just currencyVal
                        , emBudgetCents = normalizeBudgetCentsMaybe (eventBudgetCents dto)
                        }
        mVenueKey <- case eventVenueId dto of
            Nothing -> pure Nothing
            Just txt -> Just <$> either throwError pure (parseVenueIdEither txt)
        key <-
            liftIO $
                runSqlPool
                    ( insert
                        SocialEvent
                            { socialEventOrganizerPartyId = Just currentPartyId
                            , socialEventTitle = titleVal
                            , socialEventDescription = eventDescription dto
                            , socialEventVenueId = mVenueKey
                            , socialEventTimezone = timezoneVal
                            , socialEventEventTypeId = Just eventTypeUuid
                            , socialEventWorkflowStateId = Just workflowStateId
                            , socialEventStartTime = eventStart dto
                            , socialEventEndTime = eventEnd dto
                            , socialEventPriceCents = eventPriceCents dto
                            , socialEventCurrencyId = Nothing
                            , socialEventCapacity = eventCapacity dto
                            , socialEventMetadata = metadataVal
                            , socialEventCreatedAt = now
                            , socialEventUpdatedAt = now
                            }
                    )
                    envPool
        liftIO $
            runSqlPool
                ( forM_ artistKeys $ \artistKey ->
                    insert_ (EventArtist key artistKey Nothing)
                )
                envPool
        let createdEvent =
                SocialEvent
                    { socialEventOrganizerPartyId = Just currentPartyId
                    , socialEventTitle = titleVal
                    , socialEventDescription = eventDescription dto
                    , socialEventVenueId = mVenueKey
                    , socialEventTimezone = timezoneVal
                    , socialEventEventTypeId = Just eventTypeUuid
                    , socialEventWorkflowStateId = Just workflowStateId
                    , socialEventStartTime = eventStart dto
                    , socialEventEndTime = eventEnd dto
                    , socialEventPriceCents = eventPriceCents dto
                    , socialEventCurrencyId = Nothing
                    , socialEventCapacity = eventCapacity dto
                    , socialEventMetadata = metadataVal
                    , socialEventCreatedAt = now
                    , socialEventUpdatedAt = now
                    }
        liftIO (runSqlPool (eventEntityToDTO (defaultCurrency envConfig) key createdEvent (eventArtists dto)) envPool)
            >>= either throwError pure

    getEvent :: T.Text -> AppM EventDTO
    getEvent rawId = do
        Env{..} <- ask
        eventKey <- parseVisibleEventKey rawId
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        case mEvent of
            Nothing -> throwError err404{errBody = "Event not found"}
            Just eventRow -> do
                artists <- loadEventArtists envPool eventKey
                sources <- liftIO (loadExternalEventSources envPool eventKey)
                dto <- liftIO (runSqlPool (eventEntityToDTO (defaultCurrency envConfig) eventKey eventRow artists) envPool) >>= either throwError pure
                pure dto{eventSources = Just sources}

    updateEvent :: T.Text -> EventUpdateDTO -> AppM EventDTO
    updateEvent rawId EventUpdateDTO{..} = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        eventKey <- parseVisibleEventKey rawId
        mExisting <- liftIO $ runSqlPool (get eventKey) envPool
        existing <- maybe (throwError err404{errBody = "Event not found"}) pure mExisting
        -- A strict administrator may edit an event without an organizer and is
        -- assigned as its organizer together with the accepted edit, under
        -- the event lock; a refused edit assigns nobody.
        let editAccess row = case cleanMaybeText (socialEventOrganizerPartyId row) of
                Just owner
                    | owner == currentPartyId -> Right False
                    | otherwise -> Left eventNotOrganizerError
                Nothing
                    | hasStrictAdminAccess user -> Right True
                    | otherwise -> Left eventWithoutOrganizerError
        _ <- either throwError pure (editAccess existing)
        let managedEvent = existing
        let dto = eudEvent
        validateEventReadOnlyProjectionOmitted dto
        requestedEventTypeId <-
            maybe (throwError invalidEventTypeReference) pure (cleanMaybeText (eventTypeId dto))
        eventTypeUuid <-
            liftIO (runSqlPool (loadSelectableEventTypeId now requestedEventTypeId) envPool)
                >>= either throwError pure
        titleVal <- either throwError pure (validateEventTitleInput (eventTitle dto))
        either throwError pure (validateEventTimeRange (eventStart dto) (eventEnd dto))
        timezoneVal <- traverse (either throwError pure . validateEventTimeZone) (eventTimezone dto)
        either throwError pure $
            validateEventCreateUpdateDimensions
                (eventPriceCents dto)
                (eventCapacity dto)
                (eventBudgetCents dto)
        validatedMetadataUpdate <- either throwError pure (validateEventMetadataUpdate eudMetadataUpdate)
        artistKeys <- either throwError pure (validateEventArtistIds (eventArtists dto))
        existingMetadata <-
            either (throwError . storedEventMetadataServerError) pure $
                decodeStoredEventMetadata (socialEventMetadata managedEvent)
        let mergedMetadata = applyEventMetadataUpdate validatedMetadataUpdate existingMetadata
        existingWorkflowStateId <-
            maybe (throwError err500{errBody = "Event has no canonical workflow state"}) pure
                (socialEventWorkflowStateId managedEvent)
        workflowStateId <- case eudWorkflowStateIdUpdate of
            FieldMissing -> pure existingWorkflowStateId
            FieldNull -> throwError invalidEventWorkflowStateReference
            FieldValue rawWorkflowStateId -> do
                requestedId <- either throwError pure (parseEventWorkflowStateId rawWorkflowStateId)
                activeState <- liftIO $ runSqlPool (EventLifecycle.loadActiveSocialEventState requestedId) envPool
                when (isNothing activeState) $ throwError invalidEventWorkflowStateReference
                transitionAllowed <- liftIO $ runSqlPool (EventLifecycle.socialEventTransitionAllowed existingWorkflowStateId requestedId) envPool
                unless transitionAllowed $
                    throwError err409{errBody = "The requested social-event workflow transition is not allowed"}
                pure requestedId
        mVenueKey <- case eventVenueId dto of
            Nothing -> pure Nothing
            Just txt -> Just <$> either throwError pure (parseVenueIdEither txt)
        let proposedEvent =
                managedEvent
                    { socialEventTitle = titleVal
                    , socialEventDescription = eventDescription dto
                    , socialEventVenueId = mVenueKey
                    , socialEventTimezone = timezoneVal
                    , socialEventStartTime = eventStart dto
                    , socialEventEndTime = eventEnd dto
                    , socialEventPriceCents = eventPriceCents dto
                    , socialEventCapacity = eventCapacity dto
                    , socialEventEventTypeId = Just eventTypeUuid
                    , socialEventWorkflowStateId = Just workflowStateId
                    , socialEventMetadata = encodeEventMetadata mergedMetadata
                    , socialEventUpdatedAt = now
                    }
        updatedEvent <- liftIO (runSqlPool (do
            locked <- lockSocialEventForMutation eventKey
            case locked of
                Nothing -> pure (Left err404{errBody = "Event not found"})
                Just (Entity _ currentEvent)
                    | Left refused <- editAccess currentEvent -> pure (Left refused)
                    | socialEventWorkflowStateId currentEvent /= socialEventWorkflowStateId managedEvent
                        && (case eudWorkflowStateIdUpdate of FieldMissing -> False; _ -> True) ->
                        pure (Left err409{errBody = "Event workflow changed; reload before updating"})
                    | otherwise -> do
                        currentRefs <- selectList [ExternalEventRefEventId ==. eventKey] []
                        if any (externalEventRefIsSuppressed . entityVal) currentRefs
                            then pure (Left err404{errBody = "Event not found"})
                            else
                                case decodeStoredEventMetadata (socialEventMetadata currentEvent) of
                                    Left message -> pure (Left (storedEventMetadataServerError message))
                                    Right currentMetadata -> do
                                        let nextWorkflow = case eudWorkflowStateIdUpdate of
                                                FieldMissing -> socialEventWorkflowStateId currentEvent
                                                _ -> Just workflowStateId
                                            proposed = proposedEvent
                                                { socialEventWorkflowStateId = nextWorkflow
                                                , socialEventMetadata = encodeEventMetadata
                                                    (applyEventMetadataUpdate validatedMetadataUpdate currentMetadata)
                                                }
                                            updated = proposed{socialEventMetadata =
                                                EventDiscoveryOwnership.preserveEventOwnership currentEvent proposed}
                                        assigned <-
                                            if editAccess currentEvent == Right True
                                                then assignMissingEventOrganizer
                                                    currentPartyId now eventKey
                                                else pure (Right currentEvent)
                                        case assigned of
                                          Left refused -> pure (Left refused)
                                          Right holder -> do
                                           update eventKey
                                               [ SocialEventTitle =. socialEventTitle updated
                                               , SocialEventDescription
                                                   =. socialEventDescription updated
                                               , SocialEventVenueId =. socialEventVenueId updated
                                               , SocialEventTimezone =. socialEventTimezone updated
                                               , SocialEventStartTime
                                                   =. socialEventStartTime updated
                                               , SocialEventEndTime =. socialEventEndTime updated
                                               , SocialEventPriceCents
                                                   =. socialEventPriceCents updated
                                               , SocialEventCapacity =. socialEventCapacity updated
                                               , SocialEventEventTypeId
                                                   =. socialEventEventTypeId updated
                                               , SocialEventWorkflowStateId
                                                   =. socialEventWorkflowStateId updated
                                               , SocialEventMetadata =. socialEventMetadata updated
                                               , SocialEventUpdatedAt =. now
                                               ]
                                           deleteWhere [EventArtistEventId ==. eventKey]
                                           forM_ artistKeys $ \artistKey ->
                                               insert_ (EventArtist eventKey artistKey Nothing)
                                           pure (Right updated
                                               { socialEventOrganizerPartyId =
                                                   socialEventOrganizerPartyId holder
                                               })
            ) envPool) >>= either throwError pure
        liftIO (runSqlPool (eventEntityToDTO (defaultCurrency envConfig) eventKey updatedEvent (eventArtists dto)) envPool)
            >>= either throwError pure

    uploadEventImage :: T.Text -> EventImageUploadForm -> AppM EventImageUploadDTO
    uploadEventImage rawId rawUploadForm = do
        EventImageUploadForm{..} <-
            either (throwError . eventImageUploadFormServerError) pure $
                validateEventImageUploadForm rawUploadForm
        Env{..} <- ask
        now <- liftIO getCurrentTime
        eventKey <- parseVisibleEventKey rawId
        let mimeTypeVal = T.toLower (T.strip (fdFileCType eiuFile))
            fallbackName = nonEmptyText (fdFileName eiuFile)
            requestedName = eiuName >>= nonEmptyText
            nameWithExt = applyUploadExtension (requestedName <|> fallbackName) fallbackName
            safeName = sanitizeUploadFileName nameWithExt
        unless (isImageUpload mimeTypeVal safeName) $
            throwError
                err400
                    { errBody =
                        "Only raster image uploads with matching MIME type and extension are allowed"
                    }

        uuid <- liftIO UUIDV4.nextRandom
        let eventIdTxt = renderKeyText eventKey
            storedName = UUID.toText uuid <> "-" <> safeName
            relPath = T.intercalate "/" ["social-events", "events", eventIdTxt, storedName]
            targetDir = assetsRootDir envConfig </> "social-events" </> "events" </> T.unpack eventIdTxt
            targetPath = targetDir </> T.unpack storedName
            assetsBase = resolveConfiguredAssetsBase envConfig
            publicUrl = buildUploadAssetUrl assetsBase relPath
        fileSize <- liftIO (getFileSize (fdPayload eiuFile))
        either throwError pure (validateEventImageUploadSize fileSize)
        uploadResult <- liftIO $
            runSqlPool
                ( do
                    lockedEvent <- lockSocialEventForMutation eventKey
                    case lockedEvent of
                        Nothing -> pure (Left err404{errBody = "Event not found"})
                        Just (Entity _ eventRow) -> do
                            refs <- selectList [ExternalEventRefEventId ==. eventKey] []
                            if any (externalEventRefIsSuppressed . entityVal) refs
                                then pure (Left err404{errBody = "Event not found"})
                                else
                                    case cleanMaybeText (socialEventOrganizerPartyId eventRow) of
                                        Just owner
                                            | owner /= currentPartyId ->
                                                pure (Left err403{errBody = "Only the event organizer can manage this event"})
                                        Nothing -> pure (Left eventWithoutOrganizerError)
                                        Just _ ->
                                            case decodeStoredEventMetadata (socialEventMetadata eventRow) of
                                                Left message -> pure (Left (storedEventMetadataServerError message))
                                                Right existingMeta -> do
                                                    -- Keep file creation and metadata publication inside
                                                    -- the event lock. Deletion either waits and removes this
                                                    -- file afterward, or commits first and makes this branch
                                                    -- fail before the directory can be recreated.
                                                    liftIO $ createDirectoryIfMissing True targetDir
                                                    liftIO $ copyFile (fdPayload eiuFile) targetPath
                                                    update
                                                        eventKey
                                                        [ SocialEventMetadata =.
                                                            EventDiscoveryOwnership.preserveEventOwnership eventRow
                                                                eventRow{socialEventMetadata = encodeEventMetadata
                                                                    existingMeta{emImageUrl = Just publicUrl}}
                                                        , SocialEventUpdatedAt =. now
                                                        ]
                                                    pure (Right ())
                )
                envPool
        either throwError pure uploadResult
        pure
            EventImageUploadDTO
                { eiuEventId = eventIdTxt
                , eiuFileName = storedName
                , eiuPath = relPath
                , eiuPublicUrl = publicUrl
                , eiuImageUrl = publicUrl
                }

    lockSocialEventForMutation ::
        SocialEventId ->
        SqlPersistT IO (Maybe (Entity SocialEvent))
    lockSocialEventForMutation eventKey = do
        backendName <- T.toCaseFold <$> getRDBMS
        if "postgres" `T.isInfixOf` backendName
            then
                listToMaybe
                    <$> ( rawSql
                            "SELECT ?? FROM social_event WHERE id = ? FOR UPDATE"
                            [toPersistValue eventKey]
                            :: SqlPersistT IO [Entity SocialEvent]
                        )
            else fmap (Entity eventKey) <$> get eventKey

    deleteEvent :: T.Text -> AppM NoContent
    deleteEvent rawId = do
        Env{..} <- ask
        requireFeatureAction "social.events" "delete"
        eventKey <- parseKeyOr400 "event" rawId
        mExisting <- liftIO $ runSqlPool (get eventKey) envPool
        case mExisting of
            Nothing -> do
                -- DELETE remains retryable if database removal committed but
                -- the following filesystem cleanup failed on the first call.
                liftIO $ removeSocialEventAssets (assetsRootDir envConfig) eventKey
                pure NoContent
            Just existing -> do
                case validateEventDeleteAccess user currentPartyId existing of
                    Left accessError -> do
                        requireEventVisibleToUser eventKey
                        throwError accessError
                    Right () -> pure ()
                now <- liftIO getCurrentTime
                deletionResult <- liftIO $
                    runSqlPool
                        ( do
                            backendName <- T.toCaseFold <$> getRDBMS
                            lockedEvent <- lockSocialEventForMutation eventKey
                            case lockedEvent of
                                Nothing -> pure (Right ())
                                Just (Entity _ currentEvent) ->
                                    case validateEventDeleteAccess user currentPartyId currentEvent of
                                        Left err -> pure (Left err)
                                        Right () -> do
                                            hasTicketOrders <-
                                                isJust <$> selectFirst [EventTicketOrderEventId ==. eventKey] []
                                            case validateEventDeletionCheckoutHistory hasTicketOrders of
                                                Left err -> pure (Left err)
                                                Right () -> do
                                                    importedRefs <- selectList [ExternalEventRefEventId ==. eventKey] []
                                                    if null importedRefs
                                                        then hardDeleteEventGraph now eventKey
                                                        else do
                                                            cancelledStateId <-
                                                                EventLifecycle.resolveActiveSocialEventStateId "cancelled"
                                                            cancellationAllowed <-
                                                                case socialEventWorkflowStateId currentEvent of
                                                                    Nothing -> pure False
                                                                    Just currentStateId ->
                                                                        EventLifecycle.socialEventTransitionAllowed
                                                                            currentStateId
                                                                            cancelledStateId
                                                            let workflowStateUpdates =
                                                                    [ SocialEventWorkflowStateId =. Just cancelledStateId
                                                                    | cancellationAllowed
                                                                    ]
                                                            when ("postgres" `T.isInfixOf` backendName) $
                                                                rawExecute
                                                                    "UPDATE event_ticket_checkout_policy SET active = FALSE, updated_at = ? WHERE event_id = ?"
                                                                    [ PersistUTCTime now
                                                                    , toPersistValue eventKey
                                                                    ]
                                                            updateWhere
                                                                [EventTicketTierEventId ==. eventKey]
                                                                [ EventTicketTierIsActive =. False
                                                                , EventTicketTierUpdatedAt =. now
                                                                ]
                                                            updateWhere
                                                                [ExternalEventRefEventId ==. eventKey]
                                                                [ ExternalEventRefSourceStatus =. externalEventRefSuppressedStatus
                                                                , ExternalEventRefMissingRuns =. 0
                                                                ]
                                                            update
                                                                eventKey
                                                                ( [ SocialEventMetadata =.
                                                                        suppressImportedEventMetadata (socialEventMetadata currentEvent)
                                                                  , SocialEventUpdatedAt =. now
                                                                  ]
                                                                    <> workflowStateUpdates
                                                                )
                                                            withdrawEventDirectorySearch eventKey
                                                            pure (Right ())
                        )
                        envPool
                either throwError pure deletionResult
                liftIO $ removeSocialEventAssets (assetsRootDir envConfig) eventKey
                pure NoContent

    withdrawEventDirectorySearch :: SocialEventId -> SqlPersistT IO ()
    withdrawEventDirectorySearch eventKey = do
        backendName <- T.toCaseFold <$> getRDBMS
        when ("postgres" `T.isInfixOf` backendName) $ do
            directoryTableRows <-
                rawSql
                    "SELECT to_regclass('directory_search_document') IS NOT NULL"
                    []
                    :: SqlPersistT IO [Single Bool]
            when (directoryTableRows == [Single True]) $
                rawExecute
                    "DELETE FROM directory_search_document WHERE entity_kind = 'event' AND entity_id = ?"
                    [PersistText (renderKeyText eventKey)]

    hardDeleteEventGraph :: UTCTime -> SocialEventId -> SqlPersistT IO (Either ServerError ())
    hardDeleteEventGraph now eventKey = do
        -- Checkout runtime and fulfillment rows are rooted in an event ticket order.
        -- Preserve that full audit chain by refusing to hard-delete any event with orders.
        hasTicketOrders <- isJust <$> selectFirst [EventTicketOrderEventId ==. eventKey] []
        case validateEventDeletionCheckoutHistory hasTicketOrders of
            Left err -> pure (Left err)
            Right () -> do
                withdrawEventDirectorySearch eventKey
                updateWhere
                    [EventResearchCandidateEventId ==. Just eventKey]
                    [EventResearchCandidateEventId =. Nothing]
                updateWhere
                    [EventResearchChangeEventId ==. Just eventKey]
                    [EventResearchChangeEventId =. Nothing]
                deleteWhere [EventArtistEventId ==. eventKey]
                deleteWhere [EventRsvpEventId ==. eventKey]
                deleteWhere [EventInvitationEventId ==. eventKey]
                momentKeys <- selectKeysList [EventMomentEventId ==. eventKey] []
                canonicalInteractions <- Interactions.activated
                unless (canonicalInteractions || null momentKeys) $ do
                    deleteWhere [EventMomentReactionMomentId <-. momentKeys]
                    deleteWhere [EventMomentCommentMomentId <-. momentKeys]
                deleteWhere [EventMomentEventId ==. eventKey]
                deleteWhere [EventLiveBroadcastEventId ==. eventKey]
                deleteWhere [EventWaitlistEventId ==. eventKey]
                ticketKeys <- selectKeysList [EventTicketEventId ==. eventKey] []
                unless (null ticketKeys) $ do
                    deleteWhere [TicketQRCodeTicketId <-. ticketKeys]
                    deleteWhere [TicketTransferTicketId <-. ticketKeys]
                deleteWhere [EventTicketEventId ==. eventKey]
                backendName <- T.toCaseFold <$> getRDBMS
                -- SQLite tests do not install the production-only checkout policy table.
                when ("postgres" `T.isInfixOf` backendName) $
                    rawExecute
                        "DELETE FROM event_ticket_checkout_policy WHERE event_id = ?"
                        [PersistInt64 (fromSqlKey eventKey)]
                updateWhere
                    [PromoCodeEventId ==. Just eventKey]
                    [ PromoCodeEventId =. Nothing
                    , PromoCodeIsActive =. False
                    , PromoCodeUpdatedAt =. now
                    ]
                deleteWhere [EventTicketTierEventId ==. eventKey]
                deleteWhere [EventFinanceEntryEventId ==. eventKey]
                deleteWhere [EventBudgetLineEventId ==. eventKey]
                logisticsActivityKeys <- selectKeysList [EventLogisticsActivityEventId ==. eventKey] []
                unless (null logisticsActivityKeys) $ do
                    deleteWhere [EventLogisticsAlertDeliveryActivityId <-. logisticsActivityKeys]
                    deleteWhere [EventRouteVerificationActivityId <-. logisticsActivityKeys]
                    deleteWhere [EventLogisticsAssignmentActivityId <-. logisticsActivityKeys]
                    deleteWhere
                        [ FilterOr
                            [ EventLogisticsDependencyActivityId <-. logisticsActivityKeys
                            , EventLogisticsDependencyDependsOnActivityId <-. logisticsActivityKeys
                            ]
                        ]
                deleteWhere [EventLogisticsActivityEventId ==. eventKey]
                deleteWhere [EventLogisticsPlaceEventId ==. eventKey]
                deleteWhere [EventLogisticsMemberEventId ==. eventKey]
                deleteWhere [EventLogisticsPlanEventId ==. eventKey]
                deleteWhere [ExternalEventRefEventId ==. eventKey]
                delete eventKey
                pure (Right ())

    -- Venues
    venuesServer :: ServerT VenuesRoutes AppM
    venuesServer =
        listVenues
            :<|> createVenue
            :<|> getVenue
            :<|> updateVenue

    listVenues :: Maybe T.Text -> Maybe T.Text -> Maybe T.Text -> Maybe Int -> Maybe Int -> AppM [VenueDTO]
    listVenues mCity mNear mQuery mLimit mOffset = do
        Env{..} <- ask
        limit <- resolveLimit 200 500 mLimit
        offset <- either throwError pure (validateSocialEventsListOffset mOffset)
        cityFilterText <-
            either throwError pure $
                validateSocialEventsListFilter "city" mCity
        searchNeedle <-
            either throwError pure $
                fmap T.toCaseFold <$> validateSocialEventsListFilter "q" mQuery
        nearFilter <- case mNear of
            Nothing -> pure Nothing
            Just raw ->
                case parseNearQueryEither raw of
                    Left e -> throwError e
                    Right parsed -> pure (Just parsed)
        let filters = case cityFilterText of
                Just c -> [VenueCity ==. Just c]
                _ -> []
        let hasTextQuery = maybe False (not . T.null) searchNeedle
            hasNearQuery = isJust nearFilter
            needsInMemoryFilter = hasTextQuery || hasNearQuery
        seeded <-
            if needsInMemoryFilter
                then liftIO $ runSqlPool (selectList filters [Asc VenueName, LimitTo 2000]) envPool
                else liftIO $ runSqlPool (selectList filters [Asc VenueName, LimitTo limit, OffsetBy offset]) envPool
        let matchesText q (Entity _ v) =
                let nameVal = T.toCaseFold (SM.venueName v)
                    cityVal = maybe "" T.toCaseFold (SM.venueCity v)
                    addressVal = maybe "" T.toCaseFold (SM.venueAddress v)
                 in T.isInfixOf q nameVal || T.isInfixOf q cityVal || T.isInfixOf q addressVal
            matchesNear (lat, lng, radiusKm) (Entity _ v) =
                case (venueLatitude v, venueLongitude v) of
                    (Just venueLat, Just venueLng) ->
                        haversineDistanceKm lat lng venueLat venueLng <= radiusKm
                    _ -> False
            rowsFilteredByText = case searchNeedle of
                Just q | not (T.null q) -> filter (matchesText q) seeded
                _ -> seeded
            rowsFiltered = case nearFilter of
                Just nearSpec -> filter (matchesNear nearSpec) rowsFilteredByText
                Nothing -> rowsFilteredByText
            rows =
                if needsInMemoryFilter
                    then take limit (drop offset rowsFiltered)
                    else seeded
        pure $
            map
                ( \(Entity vid v) ->
                    let contactMeta = decodeVenueContactMetadata (SM.venueContact v)
                     in VenueDTO
                            { venueId = Just (renderKeyText vid)
                            , venueName = SM.venueName v
                            , venueAddress = SM.venueAddress v
                            , venueCity = SM.venueCity v
                            , venueCountry = SM.venueCountry v
                            , venueLat = venueLatitude v
                            , venueLng = venueLongitude v
                            , venueCapacity = SM.venueCapacity v
                            , venueContact = vcmPhone contactMeta
                            , venuePhone = vcmPhone contactMeta
                            , venueWebsite = vcmWebsite contactMeta
                            , venueState = vcmState contactMeta
                            , venueZipCode = vcmZipCode contactMeta
                            , venueImageUrl = vcmImageUrl contactMeta
                            , venueCreatedAt = Just (SM.venueCreatedAt v)
                            , venueUpdatedAt = Just (SM.venueUpdatedAt v)
                            }
                )
                rows

    createVenue :: VenueDTO -> AppM VenueDTO
    createVenue dto = do
        requireFeatureAction "social.venue.create" "create"
        Env{..} <- ask
        now <- liftIO getCurrentTime
        either throwError pure $
            validateVenueCreateUpdateFields
                (venueName dto)
                (venueLat dto)
                (venueLng dto)
                (venueCapacity dto)
        let contactMeta = venueContactMetadataFromDTO dto
        key <-
            liftIO $
                runSqlPool
                    ( insert
                        Venue
                            { venueName = venueName dto
                            , venueAddress = venueAddress dto
                            , venueCity = venueCity dto
                            , venueCountry = venueCountry dto
                            , venueCountryCode = Nothing
                            , venueCountryId = Nothing
                            , venueCityId = Nothing
                            , venueTimezone = Nothing
                            , venueLatitude = venueLat dto
                            , venueLongitude = venueLng dto
                            , venueCapacity = venueCapacity dto
                            , venueContact = encodeVenueContactMetadata contactMeta
                            , venueCreatedAt = now
                            , venueUpdatedAt = now
                            }
                    )
                    envPool
        pure
            ( dto
                { venueId = Just (renderKeyText key)
                , venueContact = vcmPhone contactMeta
                , venuePhone = vcmPhone contactMeta
                , venueWebsite = vcmWebsite contactMeta
                , venueState = vcmState contactMeta
                , venueZipCode = vcmZipCode contactMeta
                , venueImageUrl = vcmImageUrl contactMeta
                , venueCreatedAt = Just now
                , venueUpdatedAt = Just now
                }
            )

    getVenue :: T.Text -> AppM VenueDTO
    getVenue rawId = do
        Env{..} <- ask
        venueKey <- parseKeyOr400 "venue" rawId
        mEnt <- liftIO $ runSqlPool (get venueKey) envPool
        case mEnt of
            Nothing -> throwError err404{errBody = "Venue not found"}
            Just v ->
                let contactMeta = decodeVenueContactMetadata (SM.venueContact v)
                 in pure
                        VenueDTO
                            { venueId = Just (T.strip rawId)
                            , venueName = SM.venueName v
                            , venueAddress = SM.venueAddress v
                            , venueCity = SM.venueCity v
                            , venueCountry = SM.venueCountry v
                            , venueLat = venueLatitude v
                            , venueLng = venueLongitude v
                            , venueCapacity = SM.venueCapacity v
                            , venueContact = vcmPhone contactMeta
                            , venuePhone = vcmPhone contactMeta
                            , venueWebsite = vcmWebsite contactMeta
                            , venueState = vcmState contactMeta
                            , venueZipCode = vcmZipCode contactMeta
                            , venueImageUrl = vcmImageUrl contactMeta
                            , venueCreatedAt = Just (SM.venueCreatedAt v)
                            , venueUpdatedAt = Just (SM.venueUpdatedAt v)
                            }

    updateVenue :: T.Text -> VenueUpdateDTO -> AppM VenueDTO
    updateVenue rawId VenueUpdateDTO{..} = do
        requireFeatureAction "social.venues" "edit"
        Env{..} <- ask
        now <- liftIO getCurrentTime
        venueKey <- parseKeyOr400 "venue" rawId
        mExisting <- liftIO $ runSqlPool (get venueKey) envPool
        existing <- maybe (throwError err404{errBody = "Venue not found"}) pure mExisting
        let dto = vudVenue
        either throwError pure $
            validateVenueCreateUpdateFields
                (venueName dto)
                (venueLat dto)
                (venueLng dto)
                (venueCapacity dto)
        let existingContactMeta = decodeVenueContactMetadata (SM.venueContact existing)
            mergedContactMeta = applyVenueContactUpdate vudContactUpdate existingContactMeta
        liftIO $
            runSqlPool
                ( update
                    venueKey
                    [ VenueName =. venueName dto
                    , VenueAddress =. venueAddress dto
                    , VenueCity =. venueCity dto
                    , VenueCountry =. venueCountry dto
                    , VenueLatitude =. venueLat dto
                    , VenueLongitude =. venueLng dto
                    , VenueCapacity =. venueCapacity dto
                    , VenueContact =. encodeVenueContactMetadata mergedContactMeta
                    , VenueUpdatedAt =. now
                    ]
                )
                envPool
        pure
            ( dto
                { venueId = Just rawId
                , venueContact = vcmPhone mergedContactMeta
                , venuePhone = vcmPhone mergedContactMeta
                , venueWebsite = vcmWebsite mergedContactMeta
                , venueState = vcmState mergedContactMeta
                , venueZipCode = vcmZipCode mergedContactMeta
                , venueImageUrl = vcmImageUrl mergedContactMeta
                , venueCreatedAt = Just (SM.venueCreatedAt existing)
                , venueUpdatedAt = Just now
                }
            )

    -- Artists
    artistsServer :: ServerT ArtistsRoutes AppM
    artistsServer =
        listArtists
            :<|> createArtist
            :<|> getArtist
            :<|> updateArtist
            :<|> listArtistFollowers
            :<|> followArtist
            :<|> unfollowArtist

    listArtists :: Maybe T.Text -> Maybe UUID.UUID -> Maybe T.Text -> Maybe T.Text -> Maybe Int -> Maybe Int -> AppM [ArtistDTO]
    listArtists mNameFilter mGenreIdFilter mLegacyGenreFilter mPartyIdFilter mLimit mOffset = do
        Env{..} <- ask
        when (isJust mLegacyGenreFilter) $
            throwError err400{errBody = "genre is obsolete; use the canonical genreId UUID parameter"}
        limit <- resolveLimit 500 1000 mLimit
        offset <- either throwError pure (validateSocialEventsListOffset mOffset)
        nameFilter <-
            either throwError pure $
                fmap T.toCaseFold <$> validateSocialEventsListFilter "name" mNameFilter
        -- Party relationship lookup is an exact indexed equality, so callers never
        -- have to page through the whole catalog (bounded by the offset cap) to
        -- find the one profile that belongs to a Party.
        partyFilter <- either throwError pure (validateArtistPartyIdFilter mPartyIdFilter)
        let hasFilter = isJust nameFilter || isJust mGenreIdFilter
            partyCondition = maybe [] (\partyIdText -> [ArtistProfilePartyId ==. Just partyIdText]) partyFilter
        rows <-
            liftIO $
                runSqlPool
                    ( selectList
                        partyCondition
                        ( [Desc ArtistProfileCreatedAt]
                            ++ if hasFilter
                                then [LimitTo 1000]
                                else [LimitTo limit, OffsetBy offset]
                        )
                    )
                    envPool
        artists <- forM rows $ \(Entity aid a) -> do
            (genreList, genreIds) <- liftIO $ runSqlPool (loadArtistGenreSelections aid a) envPool
            let nameMatches = case nameFilter of
                    Nothing -> True
                    Just name -> T.isInfixOf name (T.toCaseFold (artistProfileName a))
            let genreMatches = case mGenreIdFilter of
                    Nothing -> True
                    Just genreId -> genreId `elem` genreIds
            if nameMatches && genreMatches
                then Just <$> either throwError pure (artistProfileToDTO aid a genreList genreIds)
                else pure Nothing
        let filtered = catMaybes artists
        pure
            ( if hasFilter
                then take limit (drop offset filtered)
                else filtered
            )

    resolveLimit :: Int -> Int -> Maybe Int -> AppM Int
    resolveLimit defaultLimit maxLimit mVal =
        case mVal of
            Nothing -> pure defaultLimit
            Just n
                | n <= 0 -> throwError err400{errBody = "limit must be greater than 0"}
                | n > maxLimit -> throwError err400{errBody = "limit exceeds allowed maximum"}
                | otherwise -> pure n

    listArtistFollowers :: T.Text -> AppM [ArtistFollowerDTO]
    listArtistFollowers artistIdStr = do
        Env{..} <- ask
        artistKey <- parseArtistId artistIdStr
        mArtist <- liftIO $ runSqlPool (get artistKey) envPool
        when (isNothing mArtist) $ throwError err404{errBody = "Artist not found"}
        rows <-
            liftIO $
                runSqlPool
                    (selectList [ArtistFollowArtistId ==. artistKey] [Desc ArtistFollowCreatedAt])
                    envPool
        let artistIdTxt = renderKeyText artistKey
        pure $
            map
                ( \(Entity _ follow) ->
                    ArtistFollowerDTO
                        { afFollowId = Just (renderFollowId artistKey (artistFollowFollowerPartyId follow))
                        , afArtistId = Just artistIdTxt
                        , afFollowerPartyId = artistFollowFollowerPartyId follow
                        , afCreatedAt = Just (artistFollowCreatedAt follow)
                        }
                )
                rows

    createArtist :: ArtistDTO -> AppM ArtistDTO
    createArtist dto = do
        requireFeatureAction "artist.onboarding" "create"
        Env{..} <- ask
        now <- liftIO getCurrentTime
        artistNameVal <- either throwError pure (validateArtistName (artistName dto))
        let requestedPartyId = cleanMaybeText (artistPartyId dto)
        targetPartyId <- either throwError pure (validateArtistProfileCreateParty user requestedPartyId)
        duplicate <- liftIO $ runSqlPool (selectFirst [ArtistProfilePartyId ==. Just targetPartyId] []) envPool
        when (isJust duplicate) $
            throwError err409{errBody = "An artist profile already exists for this party"}
        resolvedGenres <-
            liftIO (runSqlPool (resolvePublishedArtistGenres (artistGenreIds dto)) envPool)
                >>= either (throwError . invalidArtistGenreIdsError) pure
        result <- liftIO $ runSqlPool
            ( do
                activation <- if targetPartyId == renderPartyId user
                    then fmap (fmap (const ())) (ArtistProfiles.activateOwnArtistProfile (auPartyId user) now)
                    else pure (Right ())
                case activation of
                    Left message -> pure (Left err403{errBody = BL.fromStrict (TE.encodeUtf8 message)})
                    Right () -> do
                        current <- selectFirst [ArtistProfilePartyId ==. Just targetPartyId] []
                        case current of
                            Just _ -> pure (Left err409{errBody = "An artist profile already exists for this party"})
                            Nothing -> do
                                artistKey <- insert
                                        ArtistProfile
                                            { artistProfilePartyId = Just targetPartyId
                                            , artistProfileName = artistNameVal
                                            , artistProfileBio = artistBio dto
                                            , artistProfileAvatarUrl = artistAvatarUrl dto
                                            , -- Keep this nullable for compatibility with deployments where the
                                              -- legacy column type is TEXT instead of TEXT[].
                                              artistProfileGenres = Nothing
                                            , artistProfileSocialLinks = encodeSocialLinks (artistSocialLinks dto)
                                            , artistProfileCountryCode = Nothing
                                            , artistProfileCountryId = Nothing
                                            , artistProfileCreatedAt = now
                                            , artistProfileUpdatedAt = now
                                            }
                                forM_ (zip [0 :: Int ..] resolvedGenres) $ \(position, (genreId, _)) ->
                                    insert_ ArtistGenreMembership
                                        { artistGenreMembershipArtistId = artistKey
                                        , artistGenreMembershipGenreId = genreId
                                        , artistGenreMembershipSortOrder = position
                                        , artistGenreMembershipCreatedAt = now
                                        }
                                pure (Right artistKey)
            ) envPool
        key <- either throwError pure result
        let genreIds = map fst resolvedGenres
            genreList = map snd resolvedGenres
        pure
            ArtistDTO
                { artistId = Just (renderKeyText key)
                , artistPartyId = Just targetPartyId
                , artistName = artistNameVal
                , artistGenres = genreList
                , artistGenreIds = genreIds
                , artistBio = artistBio dto
                , artistAvatarUrl = artistAvatarUrl dto
                , artistSocialLinks = artistSocialLinks dto
                , artistCreatedAt = Just now
                , artistUpdatedAt = Just now
                }

    getArtist :: T.Text -> AppM ArtistDTO
    getArtist idStr = do
        Env{..} <- ask
        artistKey <- parseArtistId idStr
        mArtist <- liftIO $ runSqlPool (get artistKey) envPool
        case mArtist of
            Nothing -> throwError err404{errBody = "Artist not found"}
            Just a -> do
                (genreList, genreIds) <- liftIO $ runSqlPool (loadArtistGenreSelections artistKey a) envPool
                either throwError pure (artistProfileToDTO artistKey a genreList genreIds)

    updateArtist :: T.Text -> ArtistDTO -> AppM ArtistDTO
    updateArtist idStr dto = do
        requireFeatureAction "artist.profile.edit" "edit"
        Env{..} <- ask
        artistKey <- parseArtistId idStr
        now <- liftIO getCurrentTime
        artistNameVal <- either throwError pure (validateArtistName (artistName dto))
        mExisting <- liftIO $ runSqlPool (get artistKey) envPool
        existing <- maybe (throwError err404{errBody = "Artist not found"}) pure mExisting
        either throwError pure (validateArtistProfileWriteAccess user (artistProfilePartyId existing))
        importedRef <-
            liftIO $
                runSqlPool
                    (selectFirst [ExternalArtistRefArtistId ==. artistKey] [])
                    envPool
        when (isJust importedRef) $
            throwError err403{errBody = "Imported artists are managed automatically"}
        resolvedGenres <-
            liftIO (runSqlPool (resolvePublishedArtistGenres (artistGenreIds dto)) envPool)
                >>= either (throwError . invalidArtistGenreIdsError) pure
        let nextPartyId = cleanMaybeText (artistPartyId dto) <|> artistProfilePartyId existing
        liftIO $ runSqlPool
            ( do
                update
                    artistKey
                    [ ArtistProfilePartyId =. nextPartyId
                    , ArtistProfileName =. artistNameVal
                    , ArtistProfileBio =. artistBio dto
                    , ArtistProfileAvatarUrl =. artistAvatarUrl dto
                    , ArtistProfileSocialLinks =. encodeSocialLinks (artistSocialLinks dto)
                    , ArtistProfileUpdatedAt =. now
                    ]
                deleteWhere [ArtistGenreMembershipArtistId ==. artistKey]
                forM_ (zip [0 :: Int ..] resolvedGenres) $ \(position, (genreId, _)) ->
                    insert_ ArtistGenreMembership
                        { artistGenreMembershipArtistId = artistKey
                        , artistGenreMembershipGenreId = genreId
                        , artistGenreMembershipSortOrder = position
                        , artistGenreMembershipCreatedAt = now
                        }
            ) envPool
        let genreIds = map fst resolvedGenres
            genreList = map snd resolvedGenres
        pure
            dto
                { artistId = Just (T.strip idStr)
                , artistName = artistNameVal
                , artistGenres = genreList
                , artistGenreIds = genreIds
                , artistPartyId = nextPartyId
                , artistCreatedAt = Just (artistProfileCreatedAt existing)
                , artistUpdatedAt = Just now
                }

    followArtist :: T.Text -> ArtistFollowRequest -> AppM ArtistFollowerDTO
    followArtist artistIdStr ArtistFollowRequest{..} = do
        Env{..} <- ask
        artistKey <- parseArtistId artistIdStr
        mArtist <- liftIO $ runSqlPool (get artistKey) envPool
        when (isNothing mArtist) $ throwError err404{errBody = "Artist not found"}
        followerParty <-
            liftIO (resolveExistingPartyIdText envPool "followerPartyId" afrFollowerPartyId)
                >>= either throwError pure
        either throwError pure (validateAuthenticatedPartyReference user followerParty)
        liftIO $ followArtistDb envPool artistKey followerParty

    unfollowArtist :: T.Text -> Maybe T.Text -> AppM NoContent
    unfollowArtist artistIdStr mFollower = do
        Env{..} <- ask
        artistKey <- parseArtistId artistIdStr
        mArtist <- liftIO $ runSqlPool (get artistKey) envPool
        when (isNothing mArtist) $ throwError err404{errBody = "Artist not found"}
        followerParty <- either throwError pure (parseFollowerQueryParamEither mFollower)
        either throwError pure (validateAuthenticatedPartyReference user followerParty)
        liftIO $
            runSqlPool
                (deleteWhere [ArtistFollowArtistId ==. artistKey, ArtistFollowFollowerPartyId ==. followerParty])
                envPool
        pure NoContent

    -- RSVP identity is always derived from the validated session. Public
    -- responses deliberately contain aggregate counts only.
    rsvpsServer :: ServerT RsvpRoutes AppM
    rsvpsServer =
        getMyRsvp
            :<|> upsertMyRsvp
            :<|> deleteMyRsvp
            :<|> getRsvpSummary
            :<|> listRsvpsForOrganizer
            :<|> listProfileRsvpFeed
            :<|> listDirectoryProfileRsvpFeed

    getMyRsvp :: T.Text -> AppM (Maybe RsvpDTO)
    getMyRsvp eventIdStr = do
        Env{..} <- ask
        eventKey <- parseKeyOr400 "event" eventIdStr
        _ <- requireRsvpEventAccess eventKey False
        row <- liftIO $ runSqlPool (getBy (UniqueEventRsvp eventKey currentPartyId)) envPool
        pure (rsvpEntityToSelfDTO eventKey <$> row)

    upsertMyRsvp :: T.Text -> RsvpCreateDTO -> AppM RsvpDTO
    upsertMyRsvp eventIdStr RsvpCreateDTO{..} = do
        Env{..} <- ask
        eventKey <- parseKeyOr400 "event" eventIdStr
        _ <- requireRsvpEventAccess eventKey True `catchError` \serverError -> do
            liftIO $ logRsvpMutation "upsert" eventKey rsvpStatus ("rejected_" <> T.pack (show (errHTTPCode serverError)))
            throwError serverError
        let statusValue = rsvpStatus
        now <- liftIO getCurrentTime
        let visibleOnProfile = statusValue /= "declined" && rsvpShowOnProfile
            newRow =
                EventRsvp
                    { eventRsvpEventId = eventKey
                    , eventRsvpPartyId = currentPartyId
                    , eventRsvpStatus = statusValue
                    , eventRsvpShowOnProfile = visibleOnProfile
                    , eventRsvpVisibilityDecidedAt = Just now
                    , eventRsvpMetadata = Nothing
                    , eventRsvpCreatedAt = now
                    , eventRsvpUpdatedAt = now
                    }
        rateAllowed <- liftIO $ runSqlPool (consumeRsvpMutationRateLimit currentPartyId now) envPool
        unless rateAllowed $ do
            liftIO $ logRsvpMutation "upsert" eventKey statusValue "rate_limited"
            throwError err429{errBody = "Too many RSVP changes; try again later"}
        result <- liftIO $ runSqlPool (do
            upsertBy
                (UniqueEventRsvp eventKey currentPartyId)
                newRow
                [ EventRsvpStatus =. statusValue
                , EventRsvpShowOnProfile =. visibleOnProfile
                , EventRsvpVisibilityDecidedAt =. Just now
                , EventRsvpUpdatedAt =. now
                ]) envPool
        liftIO $ logRsvpMutation "upsert" eventKey statusValue "success"
        pure (rsvpEntityToSelfDTO eventKey result)

    deleteMyRsvp :: T.Text -> AppM NoContent
    deleteMyRsvp eventIdStr = do
        Env{..} <- ask
        eventKey <- parseKeyOr400 "event" eventIdStr
        now <- liftIO getCurrentTime
        rateAllowed <- liftIO $ runSqlPool (consumeRsvpMutationRateLimit currentPartyId now) envPool
        unless rateAllowed $ do
            liftIO $ logRsvpMutation "delete" eventKey "absent" "rate_limited"
            throwError err429{errBody = "Too many RSVP changes; try again later"}
        liftIO $ runSqlPool (deleteBy (UniqueEventRsvp eventKey currentPartyId)) envPool
        liftIO $ logRsvpMutation "delete" eventKey "absent" "success"
        pure NoContent

    getRsvpSummary :: T.Text -> AppM RsvpSummaryDTO
    getRsvpSummary eventIdStr = do
        Env{..} <- ask
        eventKey <- parseKeyOr400 "event" eventIdStr
        _ <- requireRsvpEventAccess eventKey False
        liftIO $ runSqlPool (rsvpSummaryForEvent eventKey) envPool

    listRsvpsForOrganizer :: T.Text -> Maybe T.Text -> Maybe Int -> AppM RsvpAdminPageDTO
    listRsvpsForOrganizer eventIdStr mCursor mLimit = do
        Env{..} <- ask
        eventKey <- parseKeyOr400 "event" eventIdStr
        eventRow <- maybe (throwError err404{errBody = "Event not found"}) pure
            =<< liftIO (runSqlPool (get eventKey) envPool)
        unless (hasStrictAdminAccess user || socialEventOrganizerPartyId eventRow == Just currentPartyId) $
            throwError err403{errBody = "Organizer RSVP access is required"}
        limit <- either throwError pure (validateRsvpPageLimit mLimit)
        cursor <- either throwError pure (traverse decodeRsvpCursor (cleanMaybeText mCursor))
        rows <- liftIO $ runSqlPool (loadOrganizerRsvpPage eventKey cursor (limit + 1)) envPool
        let visible = take limit rows
            next = if length rows > limit then encodeRsvpCursorFromAdmin <$> listToMaybe (reverse visible) else Nothing
        pure RsvpAdminPageDTO{adminRsvpItems = visible, adminRsvpNextCursor = next}

    listProfileRsvpFeed :: T.Text -> Maybe T.Text -> Maybe Int -> AppM RsvpFeedPageDTO
    listProfileRsvpFeed partyIdInput mCursor mLimit = do
        Env{..} <- ask
        targetPartyId <-
            liftIO (resolveExistingPartyIdText envPool "partyId" partyIdInput)
                >>= either throwError pure
        let self = targetPartyId == currentPartyId
        unless self $ do
            allowed <- liftIO $ runSqlPool (canViewRsvpProfileFeed currentPartyId targetPartyId) envPool
            unless allowed $ throwError err404{errBody = "Profile not found"}
        limit <- either throwError pure (validateRsvpPageLimit mLimit)
        cursor <- either throwError pure (traverse decodeRsvpCursor (cleanMaybeText mCursor))
        rows <- liftIO $ runSqlPool (loadRsvpFeedPage targetPartyId currentPartyId self cursor (limit + 1)) envPool
        let visible = take limit rows
            next = if length rows > limit then encodeRsvpCursorFromFeed <$> listToMaybe (reverse visible) else Nothing
        pure RsvpFeedPageDTO{feedItems = visible, feedNextCursor = next}

    listDirectoryProfileRsvpFeed :: T.Text -> Maybe T.Text -> Maybe Int -> AppM RsvpFeedPageDTO
    listDirectoryProfileRsvpFeed slugInput mCursor mLimit = do
        Env{..} <- ask
        let slug = T.toLower (T.strip slugInput)
        when (T.null slug || T.length slug > 160 || T.any (`elem` ['/', '\\', '\NUL', '\n', '\r']) slug) $
            throwError err404{errBody = "Profile not found"}
        candidates <- liftIO $ runSqlPool
            (rawSql
                "SELECT canonical.subject_party_id::text FROM directory_public_profile_resolution public_profile \
                \JOIN directory_profile canonical ON canonical.id=public_profile.id \
                \WHERE public_profile.requested_slug=? AND public_profile.profile_kind='person' \
                \AND canonical.subject_party_id IS NOT NULL"
                [PersistText slug]
                :: SqlPersistT IO [Single T.Text])
            envPool
        targetPartyId <- case candidates of
            [Single partyIdValue] -> pure partyIdValue
            _ -> throwError err404{errBody = "Profile not found"}
        listProfileRsvpFeed targetPartyId mCursor mLimit

    requireRsvpEventAccess :: SocialEventId -> Bool -> AppM SocialEvent
    requireRsvpEventAccess eventKey requireEligible = do
        Env{..} <- ask
        (eventRow, accessible, eligible) <- liftIO $ runSqlPool (do
            mEvent <- get eventKey
            case mEvent of
                Nothing -> pure (Nothing, False, False)
                Just row -> do
                    publicListable <- maybe (pure False) (`EventLifecycle.socialEventStateHasCapability` "public-listable") (socialEventWorkflowStateId row)
                    rsvpEligible <- maybe (pure False) (`EventLifecycle.socialEventStateHasCapability` "rsvp") (socialEventWorkflowStateId row)
                    stateCode <- traverse EventLifecycle.resolveSocialEventStateCode (socialEventWorkflowStateId row)
                    invited <- isJust <$> selectFirst
                        [ EventInvitationEventId ==. eventKey
                        , EventInvitationToPartyId ==. Just currentPartyId
                        , EventInvitationStatus !=. Just "declined"
                        ] []
                    let isOwner = socialEventOrganizerPartyId row == Just currentPartyId
                        publicFlag = case decodeStoredEventMetadata (socialEventMetadata row) of
                            Right metadata -> emIsPublic metadata == Just True
                            Left _ -> False
                        stillPublic = publicFlag && (publicListable || stateCode == Just "cancelled")
                    pure (Just row, stillPublic || invited || isOwner || hasStrictAdminAccess user, rsvpEligible)
            ) envPool
        row <- maybe (throwError err404{errBody = "Event not found"}) pure eventRow
        unless accessible $ throwError err404{errBody = "Event not found"}
        when (requireEligible && not eligible) $
            throwError err409{errBody = "Event is not currently accepting RSVPs"}
        pure row

    -- Invitations
    invitationsServer :: ServerT InvitationsRoutes AppM
    invitationsServer eventIdStr =
        listInvitations eventIdStr
            :<|> createInvitation eventIdStr
            :<|> updateInvitation eventIdStr

    momentsServer :: ServerT MomentsRoutes AppM
    momentsServer =
        listMoments
            :<|> createMoment
            :<|> uploadMomentImage
            :<|> (\eventId (EventMemoryMediaUploadForm form) -> uploadMomentFile False eventId form)
            :<|> reactToMoment
            :<|> commentOnMoment
            :<|> editMoment
            :<|> deleteMoment

    liveBroadcastsServer :: ServerT LiveBroadcastsRoutes AppM
    liveBroadcastsServer =
        listLiveBroadcasts
            :<|> createLiveBroadcast
            :<|> heartbeatLiveBroadcast
            :<|> endLiveBroadcast

    listInvitations :: T.Text -> AppM [InvitationDTO]
    listInvitations eventIdStr = do
        Env{..} <- ask
        eventKey <- parseVisibleEventKey eventIdStr
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        eventRow <- maybe (throwError err404{errBody = "Event not found"}) pure mEvent
        let canManage = hasStrictAdminAccess user || isEventManager currentPartyId eventRow
            invitationFilters =
                [EventInvitationEventId ==. eventKey]
                    <> if canManage
                        then []
                        else [EventInvitationToPartyId ==. Just currentPartyId]
        rows <- liftIO $ runSqlPool (selectList invitationFilters [Desc EventInvitationCreatedAt]) envPool
        pure $
            map
                ( \(Entity iid inv) ->
                    InvitationDTO
                        { invitationId = Just (renderKeyText iid)
                        , invitationEventId = Just (T.strip eventIdStr)
                        , invitationFromPartyId = eventInvitationFromPartyId inv
                        , invitationToPartyId = maybe "" id (eventInvitationToPartyId inv)
                        , invitationStatus = eventInvitationStatus inv
                        , invitationMessage = eventInvitationMessage inv
                        , invitationCreatedAt = Just (eventInvitationCreatedAt inv)
                        , invitationUpdatedAt = Just (eventInvitationUpdatedAt inv)
                        }
                )
                rows

    createInvitation :: T.Text -> InvitationDTO -> AppM InvitationDTO
    createInvitation eventIdStr dto = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        eventKey <- parseVisibleEventKey eventIdStr
        toParty <- either throwError pure (validateInvitationToPartyId (invitationToPartyId dto))
        fromParty <-
            either
                throwError
                pure
                (validateInvitationFromPartyId currentPartyId (invitationFromPartyId dto))
        statusVal <- either throwError pure (validateInvitationStatusInput (invitationStatus dto))
        when (statusVal /= "pending") $
            throwError err400{errBody = "New invitations must have pending status"}
        result <- liftIO $ runSqlPool (do
            -- Serialize authority changes and insertion on the same event row.
            -- SQLite needs a write lock before reading its current authority.
            backendName <- T.toCaseFold <$> getRDBMS
            when ("sqlite" `T.isInfixOf` backendName) $
                rawExecute "UPDATE social_event SET id = id WHERE id = ?" [toPersistValue eventKey]
            mEvent <- lockSocialEventForMutation eventKey
            case mEvent of
                Nothing -> pure (Left err404{errBody = "Event not found"})
                Just (Entity _ eventRow)
                    | not (hasStrictAdminAccess user || isEventManager currentPartyId eventRow) ->
                        pure (Left err403{errBody = "Only the event organizer can create invitations"})
                    | otherwise -> Right <$> insert EventInvitation
                        { eventInvitationEventId = eventKey
                        , eventInvitationFromPartyId = Just fromParty
                        , eventInvitationToPartyId = Just toParty
                        , eventInvitationStatus = Just statusVal
                        , eventInvitationMessage = invitationMessage dto
                        , eventInvitationCreatedAt = now
                        , eventInvitationUpdatedAt = now
                        }
            ) envPool
        key <- either throwError pure result
        pure
            InvitationDTO
                { invitationId = Just (renderKeyText key)
                , invitationEventId = Just (T.strip eventIdStr)
                , invitationFromPartyId = Just fromParty
                , invitationToPartyId = toParty
                , invitationStatus = Just statusVal
                , invitationMessage = invitationMessage dto
                , invitationCreatedAt = Just now
                , invitationUpdatedAt = Just now
                }

    updateInvitation :: T.Text -> T.Text -> InvitationUpdateDTO -> AppM InvitationDTO
    updateInvitation eventIdStr invitationIdStr InvitationUpdateDTO{..} = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        (eventKey, invitationKey) <- parseIds eventIdStr invitationIdStr
        let dto = iudInvitation
        mStatusVal <- either throwError pure (validateInvitationStatusUpdateInput (invitationStatus dto))
        toPartyVal <- either throwError pure (validateInvitationToPartyId (invitationToPartyId dto))
        result <- liftIO $ runSqlPool (do
            -- Lock before reading authority or recipient state. PostgreSQL locks
            -- event then invitation; SQLite acquires its database write lock
            -- before either read. Both locks live through the authorized update.
            backendName <- T.toCaseFold <$> getRDBMS
            when ("sqlite" `T.isInfixOf` backendName) $
                rawExecute "UPDATE event_invitation SET id = id WHERE id = ?"
                    [toPersistValue invitationKey]
            mEvent <- lockSocialEventForMutation eventKey
            case mEvent of
                Nothing -> pure (Left err404{errBody = "Event not found"})
                Just (Entity _ eventRow) -> do
                    when ("postgres" `T.isInfixOf` backendName) $ do
                        _ <- (rawSql "SELECT id FROM event_invitation WHERE id = ? FOR UPDATE"
                            [toPersistValue invitationKey] :: SqlPersistT IO [Single Int64])
                        pure ()
                    mExisting <- get invitationKey
                    case mExisting of
                        Nothing -> pure (Left err404{errBody = "Invitation not found"})
                        Just inv
                            | eventInvitationEventId inv /= eventKey ->
                                pure (Left err400{errBody = "Invitation does not belong to this event"})
                            | otherwise ->
                                case validateInvitationUpdateAuthorization
                                    (hasStrictAdminAccess user || isEventManager currentPartyId eventRow)
                                    currentPartyId
                                    (eventInvitationToPartyId inv)
                                    (eventInvitationStatus inv)
                                    toPartyVal
                                    mStatusVal
                                    iudMessageUpdate of
                                    Left authError -> pure (Left authError)
                                    Right () -> do
                                        let messageVal = applyNullableTextUpdate iudMessageUpdate (eventInvitationMessage inv)
                                            statusUpdates = maybe [] (\statusVal -> [EventInvitationStatus =. Just statusVal]) mStatusVal
                                        update invitationKey
                                            (statusUpdates <>
                                                [ EventInvitationMessage =. messageVal
                                                , EventInvitationToPartyId =. Just toPartyVal
                                                , EventInvitationUpdatedAt =. now
                                                ])
                                        pure $ Right InvitationDTO
                                            { invitationId = Just (renderKeyText invitationKey)
                                            , invitationEventId = Just (T.strip eventIdStr)
                                            , invitationFromPartyId = eventInvitationFromPartyId inv
                                            , invitationToPartyId = toPartyVal
                                            , invitationStatus = mStatusVal <|> eventInvitationStatus inv
                                            , invitationMessage = messageVal
                                            , invitationCreatedAt = Just (eventInvitationCreatedAt inv)
                                            , invitationUpdatedAt = Just now
                                            }
            ) envPool
        either throwError pure result

    -- Reuse the existing per-account budget in its own committed transaction,
    -- so validation/storage failures cannot refund an abusive write attempt.
    chargeMomentWrite :: AppM ()
    chargeMomentWrite = do
        Env{..} <- ask
        charged <- liftIO $ runSqlPool (withCurrentAuthSession user
            (rawSql "SELECT interaction_consume_write_budget(?)" [toPersistValue (auPartyId user)] :: SqlPersistT IO [Single Bool])) envPool
        case charged of
            Nothing -> throwError err401
            Just [Single True] -> pure ()
            _ -> throwError err429{errBody="Too many memory write attempts; wait before retrying",errHeaders=[("Retry-After","60"),("Cache-Control","no-store")]}

    -- Moments
    listMoments :: T.Text -> Bool -> AppM (Headers '[Header "Cache-Control" T.Text] [EventMomentDTO])
    listMoments eventIdStr extended = do
        Env{..} <- ask
        eventKey <- parseVisibleEventKey eventIdStr
        allowed <- liftIO $ runSqlPool (Interactions.visible (auPartyId user) "event" (renderKeyText eventKey)) envPool
        unless allowed $ throwError err404{errBody = "Event not found"}
        _ <- requireExistingEvent envPool eventKey
        moments <- liftIO $ loadEventMoments envPool currentPartyId eventKey
        pure $ addHeader ("private, no-store" :: T.Text) $ if extended then moments else filter (\moment -> emMediaType moment `elem` ["image", "video"]) moments

    createMoment :: T.Text -> EventMomentCreateDTO -> AppM EventMomentDTO
    createMoment eventIdStr EventMomentCreateDTO{..} = do
        chargeMomentWrite
        Env{..} <- ask
        now <- liftIO getCurrentTime
        eventKey <- parseVisibleEventKey eventIdStr
        allowed <- liftIO $ runSqlPool (Interactions.visible (auPartyId user) "event" (renderKeyText eventKey)) envPool
        unless allowed $ throwError err404{errBody = "Event not found"}
        _ <- requireExistingEvent envPool eventKey
        mediaType <- maybe (throwError err400{errBody = "Invalid moment media type"}) pure (normalizeMomentMediaType emCreateMediaType)
        caption <- either throwError pure (normalizeMomentCaption emCreateCaption)
        mediaUrl <- if mediaType == "text" then do
            when (isNothing caption || not (T.null (T.strip emCreateMediaUrl))) $
                throwError err400{errBody="A text memory requires a caption and no media URL"}
            pure ""
          else do
            normalized <- either throwError pure (validateEventMetadataUrlField "Moment media URL" (Just emCreateMediaUrl))
            maybe (throwError err400{errBody="Moment media URL is required"}) pure normalized
        mediaWidth <-
            either
                throwError
                pure
                (validateMomentMediaDimension "Moment media width" emCreateMediaWidth)
        mediaHeight <-
            either
                throwError
                pure
                (validateMomentMediaDimension "Moment media height" emCreateMediaHeight)
        mediaDurationMs <-
            either
                throwError
                pure
                (validateMomentMediaDuration emCreateMediaDurationMs)
        -- Attribution is derived from the authenticated Party, never from a
        -- client-supplied display name.
        authorName <- liftIO $ loadAuthenticatedPartyDisplayName envPool currentPartyId
        inserted <-
            liftIO $
                runSqlPool
                    (withCurrentAuthSession user $ do
                        _ <- lockSocialEventForMutation eventKey
                        visible <- Interactions.visible (auPartyId user) "event" (renderKeyText eventKey)
                        if not visible then pure (Left err404{errBody="Event not found"}) else Right <$> insert
                            EventMoment
                            { eventMomentEventId = eventKey
                            , eventMomentAuthorPartyId = Just currentPartyId
                            , eventMomentAuthorName = authorName
                            , eventMomentCaption = caption
                            , eventMomentMediaUrl = mediaUrl
                            , eventMomentMediaType = mediaType
                            , eventMomentMediaWidth = mediaWidth
                            , eventMomentMediaHeight = mediaHeight
                            , eventMomentMediaDurationMs = mediaDurationMs
                            , eventMomentCreatedAt = now
                            , eventMomentUpdatedAt = now
                            }
                    )
                    envPool
        momentKey <- maybe (throwError err401) (either throwError pure) inserted
        liftIO $ loadMomentDTO envPool currentPartyId momentKey

    -- Source authorship, parent visibility and the live session are all required.
    -- Canonical interaction deletion triggers retain conversation tombstones.
    editMoment :: T.Text -> T.Text -> EventMomentEditDTO -> AppM EventMomentDTO
    editMoment rawEvent rawMoment EventMomentEditDTO{..} = do
        caption <- either throwError pure (normalizeMomentCaption (Just emeCaption))
        momentKey <- changeOwnMoment rawEvent rawMoment $ \key row ->
          do
            visible <- Interactions.visible (auPartyId user) "event_moment" (renderKeyText key)
            if not visible then pure (Left err404{errBody="Memory not found"})
            else if eventMomentUpdatedAt row /= emeExpectedUpdatedAt then pure (Left err409{errBody="The memory changed; refresh before editing"})
            else if eventMomentMediaType row == "text" && isNothing caption then pure (Left err400{errBody="A text memory requires a caption"})
            else do
                now <- liftIO getCurrentTime
                update key [EventMomentCaption =. caption, EventMomentUpdatedAt =. now]
                pure (Right key)
        Env{..} <- ask
        liftIO $ loadMomentDTO envPool currentPartyId momentKey

    deleteMoment :: T.Text -> T.Text -> AppM NoContent
    deleteMoment rawEvent rawMoment = do
        _ <- changeOwnMoment rawEvent rawMoment $ \key _ -> do
            canonical <- Interactions.activated
            -- After cutover, direct writes to frozen children are fenced. The
            -- parent deletion trigger clears them and retains canonical
            -- tombstones, including when interaction commands are paused.
            unless canonical $ do
                deleteWhere [EventMomentReactionMomentId ==. key]
                deleteWhere [EventMomentCommentMomentId ==. key]
            delete key
            pure (Right key)
        pure NoContent

    changeOwnMoment :: T.Text -> T.Text -> (EventMomentId -> EventMoment -> SqlPersistT IO (Either ServerError EventMomentId)) -> AppM EventMomentId
    changeOwnMoment rawEvent rawMoment action = do
        chargeMomentWrite
        Env{..} <- ask
        eventKey <- parseKeyOr400 "event" rawEvent
        momentKey <- parseKeyOr400 "moment" rawMoment
        checked <- liftIO $ runSqlPool (withCurrentAuthSession user $ do
            -- Same parent-first lock order as event deletion and media upload.
            _ <- lockSocialEventForMutation eventKey
            allowed <- Interactions.visible (auPartyId user) "event" (renderKeyText eventKey)
            rows <- rawSql "SELECT ?? FROM event_moment WHERE id=? AND event_id=? FOR UPDATE"
                [toPersistValue momentKey,toPersistValue eventKey]
            case rows of
                [Entity _ row] | allowed && eventMomentAuthorPartyId row == Just currentPartyId -> action momentKey row
                _ -> pure (Left err404{errBody="Memory not found"})) envPool
        result <- maybe (throwError err401) pure checked
        either throwError pure result

    uploadMomentImage :: T.Text -> EventImageUploadForm -> AppM EventImageUploadDTO
    uploadMomentImage = uploadMomentFile True

    uploadMomentFile :: Bool -> T.Text -> EventImageUploadForm -> AppM EventImageUploadDTO
    uploadMomentFile imageOnly rawId rawUploadForm = do
        chargeMomentWrite
        EventImageUploadForm{..} <-
            either (throwError . eventImageUploadFormServerError) pure $
                (if imageOnly then validateEventImageUploadForm else validateEventMemoryMediaUploadForm) rawUploadForm
        Env{..} <- ask
        eventKey <- parseVisibleEventKey rawId
        let mimeTypeVal = T.toLower (T.strip (fdFileCType eiuFile))
            fallbackName = nonEmptyText (fdFileName eiuFile)
            requestedName = eiuName >>= nonEmptyText
            nameWithExt = applyUploadExtension (requestedName <|> fallbackName) fallbackName
            safeName = sanitizeUploadFileName nameWithExt
        fileSize <- liftIO (getFileSize (fdPayload eiuFile))
        if "image/" `T.isPrefixOf` mimeTypeVal then either throwError pure (validateEventImageUploadSize fileSize)
          else unless (fileSize > 0 && fileSize <= 25 * 1024 * 1024) $ throwError err400{errBody="Audio and video files must be between 1 byte and 25 MB"}
        signature <- liftIO $ BS.take 32 <$> BS.readFile (fdPayload eiuFile)
        unless (validMomentMediaSignature mimeTypeVal signature) $ throwError err400{errBody="File content does not match its declared media type"}
        uuid <- liftIO UUIDV4.nextRandom
        let eventIdTxt = renderKeyText eventKey
            storedName = UUID.toText uuid <> "-" <> safeName
            relPath = T.intercalate "/" ["social-events", "events", eventIdTxt, "moments", storedName]
            targetDir = assetsRootDir envConfig </> "social-events" </> "events" </> T.unpack eventIdTxt </> "moments"
            targetPath = targetDir </> T.unpack storedName
            publicUrl = buildUploadAssetUrl (resolveConfiguredAssetsBase envConfig) relPath
        uploadResult <- liftIO $
            runSqlPool
                (withCurrentAuthSession user $ do
                    lockedEvent <- lockSocialEventForMutation eventKey
                    case lockedEvent of
                        Nothing -> pure (Left err404{errBody = "Event not found"})
                        Just _ -> do
                            visible <- Interactions.visible (auPartyId user) "event" (renderKeyText eventKey)
                            publicRows <- rawSql "SELECT id FROM directory_public_rsvp_event WHERE id=?" [toPersistValue eventKey] :: SqlPersistT IO [Single Int64]
                            refs <- selectList [ExternalEventRefEventId ==. eventKey] []
                            if not visible then pure (Left err404{errBody="Event not found"})
                            else if null publicRows then pure (Left err403{errBody="This upload produces a public file; private-event uploads are unavailable"})
                            else if any (externalEventRefIsSuppressed . entityVal) refs
                                then pure (Left err404{errBody = "Event not found"})
                                else do
                                    -- Deletion uses the same event lock before removing
                                    -- this directory. It therefore either removes a
                                    -- completed upload or makes this path fail before
                                    -- any deleted-event media can be recreated.
                                    liftIO $ createDirectoryIfMissing True targetDir
                                    liftIO $ copyFile (fdPayload eiuFile) targetPath
                                    pure (Right ())
                )
                envPool
        maybe (throwError err401) (either throwError pure) uploadResult
        pure EventImageUploadDTO
            { eiuEventId = eventIdTxt
            , eiuFileName = storedName
            , eiuPath = relPath
            , eiuPublicUrl = publicUrl
            , eiuImageUrl = publicUrl
            }

    reactToMoment :: T.Text -> T.Text -> EventMomentReactionRequestDTO -> AppM EventMomentDTO
    reactToMoment eventIdStr momentIdStr EventMomentReactionRequestDTO{..} = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        eventKey <- parseVisibleEventKey eventIdStr
        allowed <- liftIO $ runSqlPool (Interactions.visible (auPartyId user) "event" (renderKeyText eventKey)) envPool
        unless allowed $ throwError err404{errBody = "Event not found"}
        _ <- requireExistingEvent envPool eventKey
        momentKey <- parseKeyOr400 "moment" momentIdStr
        _ <- requireMomentForEvent envPool eventKey momentKey
        canonical <- liftIO $ runSqlPool Interactions.activated envPool
        if canonical then void (Interactions.legacyCommand user "event_moment" (renderKeyText momentKey)
            (Aeson.object ["operation" Aeson..= ("legacy.reaction" :: T.Text), "reactionTypeId" Aeson..= emrrReactionTypeId,
                "active" Aeson..= emrrActive]) :: AppM Aeson.Value)
        else do
            reactionTypeId <-
                liftIO (runSqlPool (loadSelectableMomentReactionTypeId emrrReactionTypeId) envPool)
                    >>= either throwError pure
            void $ liftIO $ runSqlPool
                (toggleMomentReactionDb (auPartyId user) currentPartyId momentKey reactionTypeId emrrActive now) envPool
        liftIO $ loadMomentDTO envPool currentPartyId momentKey

    commentOnMoment :: T.Text -> T.Text -> EventMomentCommentCreateDTO -> AppM EventMomentCommentDTO
    commentOnMoment eventIdStr momentIdStr EventMomentCommentCreateDTO{..} = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        eventKey <- parseVisibleEventKey eventIdStr
        allowed <- liftIO $ runSqlPool (Interactions.visible (auPartyId user) "event" (renderKeyText eventKey)) envPool
        unless allowed $ throwError err404{errBody = "Event not found"}
        _ <- requireExistingEvent envPool eventKey
        momentKey <- parseKeyOr400 "moment" momentIdStr
        _ <- requireMomentForEvent envPool eventKey momentKey
        body <- either throwError pure (normalizeMomentCommentBody emccBody)
        canonical <- liftIO $ runSqlPool Interactions.activated envPool
        if canonical then Interactions.legacyCommand user "event_moment" (renderKeyText momentKey)
            (Aeson.object ["operation" Aeson..= ("legacy.comment" :: T.Text), "body" Aeson..= body])
        else do
            let authorName = resolveMomentAuthorName currentPartyId emccAuthorName
            commentKey <-
                liftIO $
                    runSqlPool
                        ( insert
                            EventMomentComment
                                { eventMomentCommentMomentId = momentKey
                                , eventMomentCommentAuthorPartyId = Just currentPartyId
                                , eventMomentCommentAuthorName = authorName
                                , eventMomentCommentBody = body
                                , eventMomentCommentCreatedAt = now
                                , eventMomentCommentUpdatedAt = now
                                }
                        )
                        envPool
            mComment <- liftIO $ runSqlPool (get commentKey) envPool
            case mComment of
                Nothing -> throwError err500{errBody = "Moment comment could not be loaded after insert"}
                Just commentRow -> pure (momentCommentEntityToDTO commentKey commentRow)

    -- Live broadcasts
    listLiveBroadcasts :: T.Text -> AppM [EventLiveBroadcastDTO]
    listLiveBroadcasts eventIdStr = do
        Env{..} <- ask
        eventKey <- parseVisibleEventKey eventIdStr
        _ <- requireExistingEvent envPool eventKey
        rows <-
            liftIO $
                runSqlPool
                    (selectList [EventLiveBroadcastEventId ==. eventKey] [Desc EventLiveBroadcastStartedAt])
                    envPool
        accessibleRows <-
            liftIO $
                filterM
                    ( \(Entity _ broadcastRow) ->
                        canAccessLiveBroadcast envPool currentPartyId broadcastRow
                    )
                    rows
        liftIO $
            mapM
                ( \(Entity broadcastKey broadcastRow) ->
                    liveBroadcastEntityToDTO envPool broadcastKey broadcastRow
                )
                accessibleRows

    createLiveBroadcast ::
        T.Text ->
        EventLiveBroadcastCreateDTO ->
        AppM EventLiveBroadcastDTO
    createLiveBroadcast eventIdStr EventLiveBroadcastCreateDTO{..} = do
        Env{..} <- ask
        eventKey <- parseVisibleEventKey eventIdStr
        _ <- requireExistingEvent envPool eventKey
        artistKey <- parseArtistId elbCreateArtistId
        _ <- requireEventArtistProfile envPool eventKey artistKey
        requireArtistFollower envPool artistKey currentPartyId
        validateLiveBroadcastBroadcaster currentPartyId elbCreateBroadcasterPartyId
        throwError nativeBroadcastUnavailable

    heartbeatLiveBroadcast ::
        T.Text ->
        T.Text ->
        EventLiveBroadcastHeartbeatDTO ->
        AppM EventLiveBroadcastDTO
    heartbeatLiveBroadcast eventIdStr broadcastIdStr EventLiveBroadcastHeartbeatDTO{..} = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        eventKey <- parseVisibleEventKey eventIdStr
        _ <- requireExistingEvent envPool eventKey
        broadcastKey <- parseKeyOr400 "live broadcast" broadcastIdStr
        broadcastRow <- requireLiveBroadcastForEvent envPool eventKey broadcastKey
        canAccess <- liftIO $ canAccessLiveBroadcast envPool currentPartyId broadcastRow
        unless canAccess $
            throwError err403{errBody = "Live broadcast is only available to this artist fanclub"}
        let viewerDelta = max (-1000) (min 1000 (fromMaybe 0 elbhViewerDelta))
            nextViewerCount = max 0 (eventLiveBroadcastViewerCount broadcastRow + viewerDelta)
        liftIO $
            runSqlPool
                ( update
                    broadcastKey
                    [ EventLiveBroadcastViewerCount =. nextViewerCount
                    , EventLiveBroadcastLastHeartbeatAt =. now
                    , EventLiveBroadcastUpdatedAt =. now
                    ]
                )
                envPool
        liftIO $ loadLiveBroadcastDTO envPool broadcastKey

    endLiveBroadcast ::
        T.Text ->
        T.Text ->
        EventLiveBroadcastEndDTO ->
        AppM EventLiveBroadcastDTO
    endLiveBroadcast eventIdStr broadcastIdStr EventLiveBroadcastEndDTO{..} = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        eventKey <- parseVisibleEventKey eventIdStr
        _ <- requireExistingEvent envPool eventKey
        broadcastKey <- parseKeyOr400 "live broadcast" broadcastIdStr
        broadcastRow <- requireLiveBroadcastForEvent envPool eventKey broadcastKey
        validateLiveBroadcastBroadcaster currentPartyId elbEndBroadcasterPartyId
        when (eventLiveBroadcastBroadcasterPartyId broadcastRow /= currentPartyId) $
            throwError err403{errBody = "Only the broadcaster can end this live session"}
        liftIO $
            runSqlPool
                ( update
                    broadcastKey
                    [ EventLiveBroadcastStatus =. "ended"
                    , EventLiveBroadcastEndedAt =. Just now
                    , EventLiveBroadcastLastHeartbeatAt =. now
                    , EventLiveBroadcastUpdatedAt =. now
                    ]
                )
                envPool
        liftIO $ loadLiveBroadcastDTO envPool broadcastKey

    -- Tickets
    ticketsServer :: ServerT TicketsRoutes AppM
    ticketsServer =
        listTicketTiers
            :<|> createTicketTier
            :<|> updateTicketTier
            :<|> listCurrentPartyTicketOrders
            :<|> listTicketOrders
            :<|> createTicketOrder
            :<|> updateTicketOrderStatus
            :<|> listTickets
            :<|> checkInTicket
            -- Promo Codes
            :<|> listPromoCodes
            :<|> createPromoCode
            :<|> updatePromoCode
            :<|> validatePromoCode
            -- Stripe Payment
            :<|> createStripePaymentIntent
            -- Refunds
            :<|> createRefundRequest
            :<|> listRefunds
            :<|> approveRefund
            :<|> rejectRefund
            -- Manual bank transfer review
            :<|> listManualPayments
            :<|> reviewManualPayment
            :<|> getManualPaymentReceipt
            -- SRI electronic invoices
            :<|> listTaxDocuments
            :<|> retryTaxDocument
            :<|> completeBankTransferRefund
            -- Transfers
            :<|> createTransfer
            :<|> listTransfers
            :<|> acceptTransfer
            :<|> cancelTransfer
            -- Waitlist
            :<|> joinWaitlist
            :<|> listWaitlist
            :<|> notifyWaitlist
            :<|> removeFromWaitlist
            -- QR Codes
            :<|> getTicketQR

    listTicketTiers :: T.Text -> AppM [TicketTierDTO]
    listTicketTiers eventIdStr = do
        Env{..} <- ask
        eventKey <- parseVisibleEventKey eventIdStr
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        when (isNothing mEvent) $ throwError err404{errBody = "Event not found"}
        rows <-
            liftIO $
                runSqlPool
                    (selectList [EventTicketTierEventId ==. eventKey] [Asc EventTicketTierPosition, Asc EventTicketTierId])
                    envPool
        pure (map (ticketTierEntityToDTO eventKey) rows)

    createTicketTier :: T.Text -> TicketTierDTO -> AppM TicketTierDTO
    createTicketTier eventIdStr dto = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        eventKey <- parseVisibleEventKey eventIdStr
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        eventVal <- maybe (throwError err404{errBody = "Event not found"}) pure mEvent
        _ <- requireEventManager currentPartyId eventVal
        let tierName = T.strip (ticketTierName dto)
        when (T.null tierName) $ throwError err400{errBody = "ticket tier name is required"}
        when (ticketTierPriceCents dto < 0) $ throwError err400{errBody = "ticket tier price must be >= 0"}
        when (ticketTierQuantityTotal dto <= 0) $ throwError err400{errBody = "ticket tier quantity must be > 0"}
        (eventCurrencyVal, _) <-
            either
                (throwError . storedEventMetadataServerError)
                pure
                (validateStoredEventFinanceMetadata (defaultCurrency envConfig) eventVal)
        currencyVal <-
            either throwError pure $
                validateTicketTierCurrencyInput eventCurrencyVal (ticketTierCurrency dto)
        tierCode <-
            either throwError pure $
                validateTicketTierCodeInput tierName (ticketTierCode dto)
        let salesStartVal = ticketTierSalesStart dto
            salesEndVal = ticketTierSalesEnd dto
        when (invalidSalesWindow salesStartVal salesEndVal) $ throwError err400{errBody = "invalid sales window"}
        mInserted <-
            liftIO $
                runSqlPool
                    ( insertUnique
                        EventTicketTier
                            { eventTicketTierEventId = eventKey
                            , eventTicketTierCode = tierCode
                            , eventTicketTierName = tierName
                            , eventTicketTierDescription = cleanMaybeText (ticketTierDescription dto)
                            , eventTicketTierPriceCents = ticketTierPriceCents dto
                            , eventTicketTierCurrency = currencyVal
                            , eventTicketTierCurrencyId = Nothing
                            , eventTicketTierQuantityTotal = ticketTierQuantityTotal dto
                            , eventTicketTierQuantitySold = 0
                            , eventTicketTierSalesStart = salesStartVal
                            , eventTicketTierSalesEnd = salesEndVal
                            , eventTicketTierIsActive = ticketTierActive dto
                            , eventTicketTierPosition = ticketTierPosition dto
                            , eventTicketTierEnableWaitlist = False
                            , eventTicketTierAllowTransfers = True
                            , eventTicketTierRefundPolicy = "full"
                            , eventTicketTierRefundDeadline = Nothing
                            , eventTicketTierCreatedAt = now
                            , eventTicketTierUpdatedAt = now
                            }
                    )
                    envPool
        tierKey <- maybe (throwError err409{errBody = "ticket tier code already exists for this event"}) pure mInserted
        mTier <- liftIO $ runSqlPool (getEntity tierKey) envPool
        maybe
            (throwError err500{errBody = "Could not create ticket tier"})
            (pure . ticketTierEntityToDTO eventKey)
            mTier

    updateTicketTier :: T.Text -> T.Text -> TicketTierDTO -> AppM TicketTierDTO
    updateTicketTier eventIdStr tierIdStr dto = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        eventKey <- parseVisibleEventKey eventIdStr
        tierKey <- parseKeyOr400 "ticket tier" tierIdStr
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        eventVal <- maybe (throwError err404{errBody = "Event not found"}) pure mEvent
        _ <- requireEventManager currentPartyId eventVal
        mTier <- liftIO $ runSqlPool (get tierKey) envPool
        tier <- maybe (throwError err404{errBody = "Ticket tier not found"}) pure mTier
        when (eventTicketTierEventId tier /= eventKey) $ throwError err400{errBody = "Ticket tier does not belong to this event"}
        let tierName = T.strip (ticketTierName dto)
        when (T.null tierName) $ throwError err400{errBody = "ticket tier name is required"}
        when (ticketTierPriceCents dto < 0) $ throwError err400{errBody = "ticket tier price must be >= 0"}
        when (ticketTierQuantityTotal dto < eventTicketTierQuantitySold tier) $ throwError err400{errBody = "ticket tier quantity cannot be below sold quantity"}
        (eventCurrencyVal, _) <-
            either
                (throwError . storedEventMetadataServerError)
                pure
                (validateStoredEventFinanceMetadata (defaultCurrency envConfig) eventVal)
        currencyVal <-
            either throwError pure $
                validateTicketTierCurrencyInput eventCurrencyVal (ticketTierCurrency dto)
        tierCode <-
            either throwError pure $
                validateTicketTierCodeInput tierName (ticketTierCode dto)
        let salesStartVal = ticketTierSalesStart dto
            salesEndVal = ticketTierSalesEnd dto
        when (invalidSalesWindow salesStartVal salesEndVal) $ throwError err400{errBody = "invalid sales window"}
        mCodeOwner <- liftIO $ runSqlPool (getBy (UniqueEventTicketTierCode eventKey tierCode)) envPool
        case mCodeOwner of
            Just (Entity existingKey _)
                | existingKey /= tierKey ->
                    throwError err409{errBody = "ticket tier code already exists for this event"}
            _ -> pure ()
        liftIO $
            runSqlPool
                ( update
                    tierKey
                    [ EventTicketTierCode =. tierCode
                    , EventTicketTierName =. tierName
                    , EventTicketTierDescription =. cleanMaybeText (ticketTierDescription dto)
                    , EventTicketTierPriceCents =. ticketTierPriceCents dto
                    , EventTicketTierCurrency =. currencyVal
                    , EventTicketTierQuantityTotal =. ticketTierQuantityTotal dto
                    , EventTicketTierSalesStart =. salesStartVal
                    , EventTicketTierSalesEnd =. salesEndVal
                    , EventTicketTierIsActive =. ticketTierActive dto
                    , EventTicketTierPosition =. ticketTierPosition dto
                    , EventTicketTierUpdatedAt =. now
                    ]
                )
                envPool
        mUpdated <- liftIO $ runSqlPool (getEntity tierKey) envPool
        maybe
            (throwError err500{errBody = "Could not update ticket tier"})
            (pure . ticketTierEntityToDTO eventKey)
            mUpdated

    listCurrentPartyTicketOrders :: Maybe T.Text -> AppM [TicketOrderDTO]
    listCurrentPartyTicketOrders mStatus = do
        Env{..} <- ask
        statusFilters <- case cleanMaybeText mStatus of
            Nothing -> pure []
            Just raw -> case parseTicketOrderStatus raw of
                Nothing -> throwError err400{errBody = "Invalid ticket order status"}
                Just statusVal -> pure [EventTicketOrderStatus ==. statusVal]
        let filters =
                [EventTicketOrderBuyerPartyId ==. Just currentPartyId]
                    ++ statusFilters
        rows <-
            liftIO $
                runSqlPool
                    ( selectList
                        filters
                        [ Desc EventTicketOrderPurchasedAt
                        , Desc EventTicketOrderId
                        , LimitTo 500
                        ]
                    )
                    envPool
        forM rows $ \orderEnt@(Entity orderKey orderRow) -> do
            _ <-
                either
                    throwError
                    pure
                    (validateStoredTicketOrderStatus (Just (eventTicketOrderStatus orderRow)))
            tickets <-
                liftIO $
                    runSqlPool
                        (selectList [EventTicketOrderRefId ==. orderKey] [Asc EventTicketId])
                        envPool
            pure (ticketOrderEntityToDTO orderEnt tickets)

    listTicketOrders :: T.Text -> Maybe T.Text -> Maybe T.Text -> AppM [TicketOrderDTO]
    listTicketOrders eventIdStr mBuyerPartyId mStatus = do
        Env{..} <- ask
        eventKey <- parseVisibleEventKey eventIdStr
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        eventVal <- maybe (throwError err404{errBody = "Event not found"}) pure mEvent
        let manager = isEventManager currentPartyId eventVal
        requestedBuyer <-
            either
                throwError
                pure
                (validateOptionalTicketBuyerPartyId "buyerPartyId" mBuyerPartyId)
        buyerFilters <-
            if manager
                then pure $ maybe [] (\buyer -> [EventTicketOrderBuyerPartyId ==. Just buyer]) requestedBuyer
                else case requestedBuyer of
                    Nothing -> pure [EventTicketOrderBuyerPartyId ==. Just currentPartyId]
                    Just buyer
                        | buyer == currentPartyId -> pure [EventTicketOrderBuyerPartyId ==. Just currentPartyId]
                        | otherwise -> throwError err403{errBody = "You can only list your own ticket orders"}
        statusFilters <- case cleanMaybeText mStatus of
            Nothing -> pure []
            Just raw -> case parseTicketOrderStatus raw of
                Nothing -> throwError err400{errBody = "Invalid ticket order status"}
                Just statusVal -> pure [EventTicketOrderStatus ==. statusVal]
        let filters = [EventTicketOrderEventId ==. eventKey] ++ buyerFilters ++ statusFilters
        rows <- liftIO $ runSqlPool (selectList filters [Desc EventTicketOrderPurchasedAt, LimitTo 200]) envPool
        forM rows $ \orderEnt@(Entity orderKey orderRow) -> do
            _ <-
                either
                    throwError
                    pure
                    (validateStoredTicketOrderStatus (Just (eventTicketOrderStatus orderRow)))
            tickets <- liftIO $ runSqlPool (selectList [EventTicketOrderRefId ==. orderKey] [Asc EventTicketId]) envPool
            pure (ticketOrderEntityToDTO orderEnt tickets)

    createTicketOrder :: T.Text -> TicketPurchaseRequestDTO -> AppM TicketOrderDTO
    createTicketOrder eventIdStr TicketPurchaseRequestDTO{..} = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        eventKey <- parseVisibleEventKey eventIdStr
        tierKey <- parseKeyOr400 "ticket tier" ticketPurchaseTierId
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        eventVal <- maybe (throwError err404{errBody = "Event not found"}) pure mEvent
        purchaseEnabled <- liftIO $ runSqlPool (eventTicketPurchaseEnabledFor eventVal) envPool
        either throwError pure $
            validateTicketPurchaseEventEligibility (socialEventMetadata eventVal) purchaseEnabled
        mTier <- liftIO $ runSqlPool (get tierKey) envPool
        tier <- maybe (throwError err404{errBody = "Ticket tier not found"}) pure mTier
        when (eventTicketTierEventId tier /= eventKey) $ throwError err400{errBody = "Ticket tier does not belong to this event"}
        when (ticketPurchaseQuantity <= 0) $ throwError err400{errBody = "Quantity must be > 0"}
        when (not (isTicketTierSaleOpen now tier)) $ throwError err400{errBody = "Ticket sales are closed for this tier"}

        let manager = isEventManager currentPartyId eventVal
        either throwError pure $
            validateDirectTicketOrderPricing manager (eventTicketTierPriceCents tier)
        requestedBuyer <-
            either
                throwError
                pure
                (validateOptionalTicketBuyerPartyId "ticketPurchaseBuyerPartyId" ticketPurchaseBuyerPartyId)
        buyerParty <- case requestedBuyer of
            Nothing -> pure (Just currentPartyId)
            Just buyer
                | buyer == currentPartyId -> pure (Just currentPartyId)
                | manager -> pure (Just buyer)
                | otherwise -> throwError err403{errBody = "Cannot assign tickets to another buyer"}

        let availableInTier = ticketTierAvailability tier
        when (ticketPurchaseQuantity > availableInTier) $ throwError err409{errBody = "Not enough tickets available"}

        orderAmountCents <-
            either throwError pure $
                validateTicketCheckoutAmount
                    ticketPurchaseQuantity
                    (eventTicketTierPriceCents tier)
        buyerName <-
            either
                throwError
                pure
                (validateTicketPurchaseBuyerName ticketPurchaseBuyerName)
        buyerEmail <-
            either throwError pure (validateTicketPurchaseBuyerEmail ticketPurchaseBuyerEmail)
        when (orderAmountCents < 0) $ throwError err400{errBody = "Invalid amount"}
        let orderRecord =
                EventTicketOrder
                    { eventTicketOrderEventId = eventKey
                    , eventTicketOrderTierId = tierKey
                    , eventTicketOrderBuyerPartyId = buyerParty
                    , eventTicketOrderBuyerName = buyerName
                    , eventTicketOrderBuyerEmail = buyerEmail
                    , eventTicketOrderQuantity = ticketPurchaseQuantity
                    , eventTicketOrderAmountCents = orderAmountCents
                    , eventTicketOrderCurrency = eventTicketTierCurrency tier
                    , eventTicketOrderStatus = "paid"
                    , eventTicketOrderMetadata = Nothing
                    , eventTicketOrderCheckoutIdempotencyKey = Nothing
                    , eventTicketOrderPurchasedAt = now
                    , eventTicketOrderStripePaymentIntentId = Nothing
                    , eventTicketOrderPromoCodeId = Nothing
                    , eventTicketOrderOriginalAmountCents = Nothing
                    , eventTicketOrderPaymentMethod = Nothing
                    , eventTicketOrderCreatedAt = now
                    , eventTicketOrderUpdatedAt = now
                    }

        createdOrder <-
            liftIO $
                runSqlPool
                    ( do
                        lockedEvents <-
                            rawSql
                                "SELECT ?? FROM social_event WHERE id = ? FOR UPDATE"
                                [toPersistValue eventKey]
                        when (null (lockedEvents :: [Entity SocialEvent])) $
                            fail "Event not found while reserving tickets"
                        soldAcross <- selectList [EventTicketTierEventId ==. eventKey] []
                        let soldCount =
                                sum (map (eventTicketTierQuantitySold . entityVal) soldAcross)
                            capacityAvailable =
                                maybe
                                    True
                                    (\cap -> soldCount + ticketPurchaseQuantity <= cap)
                                    (socialEventCapacity eventVal)
                        if not capacityAvailable
                            then pure Nothing
                            else do
                                reservedCount <-
                                    updateWhereCount
                                        [ EventTicketTierId ==. tierKey
                                        , EventTicketTierIsActive ==. True
                                        , EventTicketTierQuantitySold
                                            <=. eventTicketTierQuantityTotal tier - ticketPurchaseQuantity
                                        ]
                                        [ EventTicketTierQuantitySold +=. ticketPurchaseQuantity
                                        , EventTicketTierUpdatedAt =. now
                                        ]
                                if reservedCount == 0
                                    then pure Nothing
                                    else do
                                        orderKey <- insert orderRecord
                                        codes <-
                                            issueMissingTicketsForOrder now orderKey orderRecord
                                        tickets <-
                                            selectList
                                                [EventTicketOrderRefId ==. orderKey]
                                                [Asc EventTicketId]
                                        pure . Just $
                                            ( ticketOrderEntityToDTO
                                                (Entity orderKey orderRecord)
                                                tickets
                                            , orderRecord
                                            , codes
                                            )
                    )
                    envPool
        (orderDto, orderRecord, ticketCodes) <-
            maybe
                (throwError err409{errBody = "Not enough tickets available"})
                pure
                createdOrder
        sendTicketConfirmationForOrder orderRecord ticketCodes
        pure orderDto

    updateTicketOrderStatus :: T.Text -> T.Text -> TicketOrderStatusUpdateDTO -> AppM TicketOrderDTO
    updateTicketOrderStatus eventIdStr orderIdStr TicketOrderStatusUpdateDTO{..} = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        eventKey <- parseVisibleEventKey eventIdStr
        orderKey <- parseKeyOr400 "ticket order" orderIdStr
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        eventVal <- maybe (throwError err404{errBody = "Event not found"}) pure mEvent
        newStatus <- case parseTicketOrderStatus ticketOrderStatus of
            Nothing -> throwError err400{errBody = "Invalid ticket order status"}
            Just "pending" -> throwError err400{errBody = "Use paid, cancelled or refunded"}
            Just s -> pure s

        mOrder <- liftIO $ runSqlPool (get orderKey) envPool
        order <- maybe (throwError err404{errBody = "Ticket order not found"}) pure mOrder
        when (eventTicketOrderEventId order /= eventKey) $ throwError err400{errBody = "Ticket order does not belong to this event"}
        canonicalOrder <- liftIO $ runSqlPool
            (rawSql "SELECT EXISTS(SELECT 1 FROM event_ticket_checkout_runtime WHERE order_id=?)"
                [toPersistValue orderKey] :: SqlPersistT IO [Single Bool]) envPool
        when (canonicalOrder /= [Single False]) $
            throwError err409 {errBody = "Use the canonical cancellation or refund workflow for this order"}
        oldStatus <-
            either
                throwError
                pure
                (validateStoredTicketOrderStatus (Just (eventTicketOrderStatus order)))
        when (oldStatus `elem` ["cancelled", "refunded"] && newStatus == "paid") $
            throwError err400{errBody = "Closed orders cannot be moved back to paid"}
        when (oldStatus /= "paid" && newStatus == "paid") $
            throwError
                err409
                    { errBody =
                        "Ticket payment can only be confirmed by verified provider processing"
                    }
        let buyerOwnPendingCancellation =
                eventTicketOrderBuyerPartyId order == Just currentPartyId
                    && oldStatus == "pending"
                    && newStatus == "cancelled"
        when (not buyerOwnPendingCancellation) $ do
            _ <- requireEventManager currentPartyId eventVal
            pure ()

        when (oldStatus == "pending" && newStatus == "cancelled") $
            forM_ (eventTicketOrderStripePaymentIntentId order) $ \paymentIntentId -> do
                stripeCfg <-
                    case (stripeSecretKey envConfig, stripeWebhookSecret envConfig) of
                        (Just secretKey, Just webhookSecret) ->
                            pure
                                Stripe.StripeConfig
                                    { Stripe.stripeSecretKey = secretKey
                                    , Stripe.stripeWebhookSecret = webhookSecret
                                    , Stripe.stripeApiVersion = Stripe.defaultStripeApiVersion
                                    }
                        _ ->
                            throwError
                                err500{errBody = "Stripe is not configured; order remains pending"}
                cancelResult <-
                    liftIO $
                        runStripeRequestSafely $
                            Stripe.cancelPaymentIntent stripeCfg paymentIntentId
                case cancelResult of
                    Left _ ->
                        throwError
                            err502
                                { errBody =
                                    "Could not cancel Stripe payment; order remains pending"
                                }
                    Right _ -> pure ()

        mTier <- liftIO $ runSqlPool (get (eventTicketOrderTierId order)) envPool
        tier <- maybe (throwError err404{errBody = "Ticket tier not found"}) pure mTier
        let qty = eventTicketOrderQuantity order
            tierAvailable = ticketTierAvailability tier
            capacity = socialEventCapacity eventVal
            soldAdjust = ticketOrderInventoryAdjustment qty oldStatus newStatus
        when (soldAdjust > 0 && soldAdjust > tierAvailable) $ throwError err409{errBody = "Not enough ticket inventory to mark as paid"}
        when (soldAdjust > 0) $ do
            soldAcross <-
                liftIO $
                    runSqlPool
                        (selectList [EventTicketTierEventId ==. eventKey] [])
                        envPool
            let soldCount = sum (map (eventTicketTierQuantitySold . entityVal) soldAcross)
            case capacity of
                Nothing -> pure ()
                Just cap ->
                    when (soldCount + soldAdjust > cap) $ throwError err409{errBody = "Event capacity reached"}
        when (eventTicketTierQuantitySold tier + soldAdjust < 0) $ throwError err409{errBody = "Sold quantity underflow"}

        let nextTicketStatus = case newStatus of
                "paid" -> "issued"
                "cancelled" -> "cancelled"
                "refunded" -> "refunded"
                _ -> "issued"
        (canonicalBlocked, statusChanged, orderDto) <-
            liftIO $
                runSqlPool
                    ( do
                        -- Match refund/admission lock order and recheck inside the
                        -- mutation transaction; an earlier authorization read is not a fence.
                        backendName <- T.toCaseFold <$> getRDBMS
                        let lockSuffix = if "postgres" `T.isInfixOf` backendName then " FOR UPDATE" else ""
                        _ <- (rawSql ("SELECT id FROM social_event WHERE id=?" <> lockSuffix)
                            [toPersistValue eventKey] :: SqlPersistT IO [Single Int64])
                        _ <- (rawSql ("SELECT id FROM event_ticket_order WHERE id=?" <> lockSuffix)
                            [toPersistValue orderKey] :: SqlPersistT IO [Single Int64])
                        canonical <- (rawSql
                            "SELECT EXISTS(SELECT 1 FROM event_ticket_checkout_runtime WHERE order_id=?)"
                            [toPersistValue orderKey] :: SqlPersistT IO [Single Bool])
                        if canonical /= [Single False] then pure (True, False, Nothing) else do
                            changedCount <-
                                updateWhereCount
                                    [ EventTicketOrderId ==. orderKey
                                    , EventTicketOrderStatus ==. eventTicketOrderStatus order
                                    ]
                                    [ EventTicketOrderStatus =. newStatus
                                    , EventTicketOrderUpdatedAt =. now
                                    ]
                            let changed = changedCount > 0
                            when changed $ do
                                when (soldAdjust /= 0) $
                                    update
                                        (eventTicketOrderTierId order)
                                        [ EventTicketTierQuantitySold +=. soldAdjust
                                        , EventTicketTierUpdatedAt =. now
                                        ]
                                when (oldStatus == "pending" && newStatus == "paid") $ do
                                    _ <- issueMissingTicketsForOrder now orderKey order
                                    pure ()
                                let ticketUpdates =
                                        [ EventTicketStatus =. nextTicketStatus
                                        , EventTicketUpdatedAt =. now
                                        ]
                                            ++ if nextTicketStatus == "issued"
                                                then [EventTicketCheckedInAt =. Nothing]
                                                else []
                                updateWhere [EventTicketOrderRefId ==. orderKey] ticketUpdates
                                when
                                    ( oldStatus == "pending"
                                        && newStatus `elem` ["cancelled", "refunded"]
                                    )
                                    $ forM_ (eventTicketOrderPromoCodeId order)
                                    $ \promoKey ->
                                        update promoKey [PromoCodeCurrentRedemptions +=. (-1)]
                            mOrderEnt <- getEntity orderKey
                            case mOrderEnt of
                                Nothing -> pure (False, changed, Nothing)
                                Just orderEnt -> do
                                    tickets <- selectList [EventTicketOrderRefId ==. orderKey] [Asc EventTicketId]
                                    pure (False, changed, Just (ticketOrderEntityToDTO orderEnt tickets))
                    )
                    envPool

        when canonicalBlocked $
            throwError err409 {errBody = "Use the canonical cancellation or refund workflow for this order"}
        case orderDto of
            Nothing -> throwError err500{errBody = "Could not update ticket order"}
            Just dto
                | statusChanged -> pure dto
                | ticketOrderStatusValue dto == newStatus -> pure dto
                | otherwise -> throwError err409{errBody = "Ticket order status changed; refresh and retry"}

    listTickets :: T.Text -> Maybe T.Text -> Maybe T.Text -> AppM [TicketDTO]
    listTickets eventIdStr mOrderId mStatus = do
        Env{..} <- ask
        eventKey <- parseVisibleEventKey eventIdStr
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        eventVal <- maybe (throwError err404{errBody = "Event not found"}) pure mEvent
        let manager = isEventManager currentPartyId eventVal
        orderFilters <- case cleanMaybeText mOrderId of
            Nothing -> pure []
            Just rawOrderId -> do
                orderKey <- parseKeyOr400 "ticket order" rawOrderId
                pure [EventTicketOrderRefId ==. orderKey]
        let holderFilters = if manager then [] else [EventTicketCurrentHolderPartyId ==. Just currentPartyId]

        statusFilters <- case cleanMaybeText mStatus of
            Nothing -> pure []
            Just raw -> case parseTicketStatus raw of
                Nothing -> throwError err400{errBody = "Invalid ticket status"}
                Just statusVal -> pure [EventTicketStatus ==. statusVal]

        let filters = [EventTicketEventId ==. eventKey] ++ orderFilters ++ holderFilters ++ statusFilters
        rows <- liftIO $ runSqlPool (selectList filters [Asc EventTicketId, LimitTo 400]) envPool
        pure (map ticketEntityToDTO rows)

    checkInTicket :: T.Text -> TicketCheckInRequestDTO -> AppM TicketDTO
    checkInTicket eventIdStr request = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        eventKey <- parseVisibleEventKey eventIdStr
        ticketLookup <- either throwError pure (validateTicketCheckInLookup request)
        let lookupValue = case ticketLookup of
                TicketCheckInLookupById ticketId -> Admission.AdmissionById (toSqlKey ticketId)
                TicketCheckInLookupByCode code -> Admission.AdmissionByCode code
        result <- liftIO $ runSqlPool (Admission.admitTicket currentPartyId eventKey lookupValue now) envPool
        case result of
            Right ticket -> pure (ticketEntityToDTO ticket)
            Left Admission.AdmissionNotFound -> throwError err404{errBody = "Ticket not found for this event"}
            Left Admission.AdmissionForbidden -> throwError err403{errBody = "Only the event organizer can check in tickets"}
            Left Admission.AdmissionUnpaid -> throwError err409{errBody = "Ticket payment is not confirmed"}
            Left Admission.AdmissionCancelled -> throwError err409{errBody = "Ticket is cancelled"}
            Left Admission.AdmissionRefunded -> throwError err409{errBody = "Ticket is refunded"}
            Left Admission.AdmissionAlreadyUsed -> throwError err409{errBody = "Ticket was already checked in"}
            Left Admission.AdmissionPaymentReview -> throwError err409{errBody = "Ticket admission is suspended pending refund or reversal reconciliation"}
            Left Admission.AdmissionInvalidState -> throwError err409{errBody = "Ticket is not valid for admission"}

    -- Promo Codes
    listPromoCodes :: T.Text -> AppM [PromoCodeDTO]
    listPromoCodes eventIdStr = do
        Env{..} <- ask
        eventKey <- parseVisibleEventKey eventIdStr
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        _ <- maybe (throwError err404{errBody = "Event not found"}) pure mEvent
        rows <-
            liftIO $
                runSqlPool
                    (selectList [PromoCodeEventId ==. Just eventKey] [Desc PromoCodeCreatedAt])
                    envPool
        pure (map promoCodeEntityToDTO rows)

    createPromoCode :: T.Text -> PromoCodeDTO -> AppM PromoCodeDTO
    createPromoCode eventIdStr PromoCodeDTO{..} = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        (eventKey, _) <- requireManagedEvent eventIdStr
        let code = T.toUpper (T.strip promoCodeCode)
        when (T.null code) $ throwError err400{errBody = "Promo code is required"}
        when (promoCodeDiscountValue < 0) $ throwError err400{errBody = "Discount value must be >= 0"}
        when (promoCodeDiscountType `notElem` ["percentage", "fixed", "fixed_amount"]) $
            throwError err400{errBody = "Discount type must be 'percentage' or 'fixed'"}
        when (promoCodeDiscountType == "percentage" && promoCodeDiscountValue > 10000) $
            throwError err400{errBody = "Percentage discount cannot exceed 100% (10000 basis points)"}
        let tierIdsJson = encodePromoCodeTierIds promoCodeTierIds
        mInserted <-
            liftIO $
                runSqlPool
                    ( insertUnique
                        PromoCode
                            { promoCodeEventId = Just eventKey
                            , promoCodeCode = code
                            , promoCodeDescription = promoCodeDescription
                            , promoCodeDiscountType = promoCodeDiscountType
                            , promoCodeDiscountValue = promoCodeDiscountValue
                            , promoCodeCurrency = promoCodeCurrency
                            , promoCodeMaxRedemptions = promoCodeMaxRedemptions
                            , promoCodeCurrentRedemptions = 0
                            , promoCodeValidFrom = promoCodeValidFrom
                            , promoCodeValidUntil = promoCodeValidUntil
                            , promoCodeTierIds = tierIdsJson
                            , promoCodeMinPurchaseAmountCents = promoCodeMinPurchaseAmountCents
                            , promoCodeIsActive = promoCodeIsActive
                            , promoCodeCreatedByPartyId = Just currentPartyId
                            , promoCodeCreatedAt = now
                            , promoCodeUpdatedAt = now
                            }
                    )
                    envPool
        codeKey <- maybe (throwError err409{errBody = "Promo code already exists"}) pure mInserted
        mCode <- liftIO $ runSqlPool (getEntity codeKey) envPool
        maybe
            (throwError err500{errBody = "Could not create promo code"})
            (pure . promoCodeEntityToDTO)
            mCode

    updatePromoCode :: T.Text -> T.Text -> PromoCodeDTO -> AppM PromoCodeDTO
    updatePromoCode eventIdStr codeIdStr PromoCodeDTO{..} = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        (eventKey, _) <- requireManagedEvent eventIdStr
        codeKey <- parseKeyOr400 "promo code" codeIdStr
        mCode <- liftIO $ runSqlPool (get codeKey) envPool
        codeRow <- maybe (throwError err404{errBody = "Promo code not found"}) pure mCode
        when (SM.promoCodeEventId codeRow /= Just eventKey) $
            throwError err400{errBody = "Promo code does not belong to this event"}
        when (promoCodeDiscountValue < 0) $ throwError err400{errBody = "Discount value must be >= 0"}
        when (promoCodeDiscountType `notElem` ["percentage", "fixed", "fixed_amount"]) $
            throwError err400{errBody = "Discount type must be 'percentage' or 'fixed'"}
        when (promoCodeDiscountType == "percentage" && promoCodeDiscountValue > 10000) $
            throwError err400{errBody = "Percentage discount cannot exceed 100% (10000 basis points)"}
        let tierIdsJson = encodePromoCodeTierIds promoCodeTierIds
        liftIO $
            runSqlPool
                ( update
                    codeKey
                    [ PromoCodeDescription =. promoCodeDescription
                    , PromoCodeDiscountType =. promoCodeDiscountType
                    , PromoCodeDiscountValue =. promoCodeDiscountValue
                    , PromoCodeCurrency =. promoCodeCurrency
                    , PromoCodeMaxRedemptions =. promoCodeMaxRedemptions
                    , PromoCodeValidFrom =. promoCodeValidFrom
                    , PromoCodeValidUntil =. promoCodeValidUntil
                    , PromoCodeTierIds =. tierIdsJson
                    , PromoCodeMinPurchaseAmountCents =. promoCodeMinPurchaseAmountCents
                    , PromoCodeIsActive =. promoCodeIsActive
                    , PromoCodeUpdatedAt =. now
                    ]
                )
                envPool
        mUpdated <- liftIO $ runSqlPool (getEntity codeKey) envPool
        maybe
            (throwError err500{errBody = "Could not update promo code"})
            (pure . promoCodeEntityToDTO)
            mUpdated

    validatePromoCode :: T.Text -> T.Text -> Maybe T.Text -> Maybe T.Text -> AppM PromoCodeDTO
    validatePromoCode eventIdStr codeStr mQueryCode mTierId = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        eventKey <- parseVisibleEventKey eventIdStr
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        _ <- maybe (throwError err404{errBody = "Event not found"}) pure mEvent
        let cleanCode = T.toUpper (T.strip codeStr)
        forM_ (cleanMaybeText mQueryCode) $ \queryCode ->
            when (T.toUpper queryCode /= cleanCode) $
                throwError err400{errBody = "Promo code query must match the promo code path"}
        mCodeEnt <- liftIO $ runSqlPool (getBy (UniquePromoCode cleanCode)) envPool
        codeEnt <- maybe (throwError err404{errBody = "Promo code not found"}) pure mCodeEnt
        let code = entityVal codeEnt
        when (SM.promoCodeEventId code /= Just eventKey) $
            throwError err400{errBody = "Promo code does not belong to this event"}
        when (not (SM.promoCodeIsActive code)) $
            throwError err400{errBody = "Promo code is not active"}
        eitherPromoCodeBadRequest $
            validatePromoCodeDateWindow
                now
                (SM.promoCodeValidFrom code)
                (SM.promoCodeValidUntil code)
        eitherPromoCodeBadRequest $
            validatePromoCodeRedemptionLimit
                (SM.promoCodeCurrentRedemptions code)
                (SM.promoCodeMaxRedemptions code)
        eitherPromoCodeBadRequest $
            validatePromoCodeTierEligibility (SM.promoCodeTierIds code) mTierId
        pure (promoCodeEntityToDTO codeEnt)

    -- Stripe Payment
    createStripePaymentIntent :: TicketPurchaseWithPromoDTO -> AppM StripePaymentIntentDTO
    createStripePaymentIntent TicketPurchaseWithPromoDTO{..} = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        let TicketPurchaseRequestDTO{..} = tpwpPurchase
        tierKey <- parseKeyOr400 "ticket tier" ticketPurchaseTierId
        mTier <- liftIO $ runSqlPool (get tierKey) envPool
        tier <- maybe (throwError err404{errBody = "Ticket tier not found"}) pure mTier
        let eventKey = eventTicketTierEventId tier
        requireEventVisibleToUser eventKey
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        eventVal <- maybe (throwError err404{errBody = "Event not found"}) pure mEvent
        purchaseEnabled <- liftIO $ runSqlPool (eventTicketPurchaseEnabledFor eventVal) envPool
        either throwError pure $
            validateTicketPurchaseEventEligibility (socialEventMetadata eventVal) purchaseEnabled
        -- Events with an approved ticket policy need the buyer to accept its current terms,
        -- exactly as the public storefront checkout does.
        mTermsVersion <- liftIO $ runSqlPool (loadActiveTicketTermsVersion now eventKey) envPool
        when (ticketPurchaseQuantity <= 0) $ throwError err400{errBody = "Quantity must be > 0"}
        when (not (isTicketTierSaleOpen now tier)) $
            throwError err400{errBody = "Ticket sales are closed for this tier"}
        let manager = isEventManager currentPartyId eventVal
        requestedBuyer <-
            either
                throwError
                pure
                (validateOptionalTicketBuyerPartyId "ticketPurchaseBuyerPartyId" ticketPurchaseBuyerPartyId)
        buyerParty <- case requestedBuyer of
            Nothing -> pure (Just currentPartyId)
            Just buyer
                | buyer == currentPartyId -> pure (Just currentPartyId)
                | manager -> pure (Just buyer)
                | otherwise -> throwError err403{errBody = "Cannot assign tickets to another buyer"}
        buyerName <-
            either
                throwError
                pure
                (validateTicketPurchaseBuyerName ticketPurchaseBuyerName)
        buyerEmail <-
            either
                throwError
                pure
                (validateTicketPurchaseBuyerEmail ticketPurchaseBuyerEmail)
        mExistingCheckout <- case tpwpIdempotencyKey of
            Nothing -> pure Nothing
            Just idempotencyKey ->
                liftIO $
                    runSqlPool
                        ( getBy
                            ( UniqueEventTicketCheckout
                                buyerParty
                                (Just idempotencyKey)
                            )
                        )
                        envPool
        forM_ mExistingCheckout $ \(Entity _ existingOrder) -> do
            let storedPromoCode =
                    decodeTicketCheckoutMetadata (eventTicketOrderMetadata existingOrder)
                        >>= snd
                requestMatches =
                    eventTicketOrderEventId existingOrder == eventKey
                        && eventTicketOrderTierId existingOrder == tierKey
                        && eventTicketOrderQuantity existingOrder == ticketPurchaseQuantity
                        && eventTicketOrderBuyerPartyId existingOrder == buyerParty
                        && eventTicketOrderBuyerName existingOrder == buyerName
                        && eventTicketOrderBuyerEmail existingOrder == buyerEmail
                        && eventTicketOrderCheckoutIdempotencyKey existingOrder
                            == tpwpIdempotencyKey
                        && storedPromoCode == tpwpPromoCode
            unless requestMatches $
                throwError err409{errBody = "ticketPurchaseIdempotencyKey was already used for different checkout details"}
        acceptedTermsVersion <-
            either throwError pure $
                ticketTermsAcceptance
                    mTermsVersion
                    tpwpAcceptedTermsVersion
                    (decodeTicketAcceptedTermsVersion . eventTicketOrderMetadata . entityVal <$> mExistingCheckout)
        baseAmountCents <-
            either throwError pure $
                validateTicketCheckoutAmount
                    ticketPurchaseQuantity
                    (eventTicketTierPriceCents tier)
        (faceValueCents, mPromoCodeKey, mPromoCodeEnt) <- case mExistingCheckout of
            Just (Entity _ existingOrder) ->
                pure
                    ( eventTicketOrderAmountCents existingOrder
                    , eventTicketOrderPromoCodeId existingOrder
                    , Nothing
                    )
            Nothing -> case tpwpPromoCode of
                Nothing -> pure (baseAmountCents, Nothing, Nothing)
                Just promoCodeStr -> do
                    let cleanCode = T.toUpper (T.strip promoCodeStr)
                    mCodeEnt <- liftIO $ runSqlPool (getBy (UniquePromoCode cleanCode)) envPool
                    codeEnt <- maybe (throwError err404{errBody = "Promo code not found"}) pure mCodeEnt
                    let code = entityVal codeEnt
                    when (SM.promoCodeEventId code /= Just eventKey) $
                        throwError err400{errBody = "Promo code does not belong to this event"}
                    when (not (SM.promoCodeIsActive code)) $
                        throwError err400{errBody = "Promo code is not active"}
                    eitherPromoCodeBadRequest $
                        validatePromoCodeDateWindow
                            now
                            (SM.promoCodeValidFrom code)
                            (SM.promoCodeValidUntil code)
                    eitherPromoCodeBadRequest $
                        validatePromoCodeRedemptionLimit
                            (SM.promoCodeCurrentRedemptions code)
                            (SM.promoCodeMaxRedemptions code)
                    eitherPromoCodeBadRequest $
                        validatePromoCodeTierEligibility
                            (SM.promoCodeTierIds code)
                            (Just ticketPurchaseTierId)
                    eitherPromoCodeBadRequest $
                        validatePromoCodeMinimumPurchaseCents
                            (SM.promoCodeMinPurchaseAmountCents code)
                            baseAmountCents
                    when
                        ( SM.promoCodeDiscountType code `elem` ["fixed_amount", "fixed"]
                            && normalizeCurrency (SM.promoCodeCurrency code)
                                /= normalizeCurrency (eventTicketTierCurrency tier)
                        )
                        $ throwError err400{errBody = "Fixed promo code currency does not match the ticket tier"}
                    discountAmount <-
                        eitherPromoCodeBadRequest $
                            promoCodeDiscountAmountEither
                                baseAmountCents
                                (SM.promoCodeDiscountType code)
                                (SM.promoCodeDiscountValue code)
                    let discountedAmount = max 0 (baseAmountCents - discountAmount)
                    pure (discountedAmount, Just (entityKey codeEnt), Just codeEnt)
        let feeBreakdown = case mExistingCheckout of
                Just (Entity _ existingOrder) -> decodeTicketPlatformFeeBreakdown existingOrder
                Nothing -> ticketPlatformFeeBreakdown faceValueCents
            finalAmountCents = ticketCheckoutTotalCents feeBreakdown
        createdOrder <- case mExistingCheckout of
            Just (Entity existingOrderKey existingOrder) -> do
                existingTickets <-
                    liftIO $
                        runSqlPool
                            (selectList [EventTicketOrderRefId ==. existingOrderKey] [Asc EventTicketId])
                            envPool
                pure . Just $
                    ( existingOrderKey
                    , existingOrder
                    , map (eventTicketCode . entityVal) (filter (Transfer.retainedByBuyer . entityVal) existingTickets)
                    , True
                    )
            Nothing -> do
                let createReservedOrder = do
                        promoClaimed <- case mPromoCodeEnt of
                            Nothing -> pure True
                            Just (Entity promoKey promo) -> do
                                let redemptionFilters =
                                        [ PromoCodeId ==. promoKey
                                        , PromoCodeIsActive ==. True
                                        ]
                                            ++ maybe
                                                []
                                                (\limit -> [PromoCodeCurrentRedemptions <. limit])
                                                (SM.promoCodeMaxRedemptions promo)
                                (> 0)
                                    <$> updateWhereCount
                                        redemptionFilters
                                        [PromoCodeCurrentRedemptions +=. 1]
                        if not promoClaimed
                            then do
                                update
                                    tierKey
                                    [ EventTicketTierQuantitySold +=. negate ticketPurchaseQuantity
                                    , EventTicketTierUpdatedAt =. now
                                    ]
                                pure Nothing
                            else do
                                let zeroTotal = finalAmountCents == 0
                                    orderRecord =
                                        EventTicketOrder
                                            { eventTicketOrderEventId = eventKey
                                            , eventTicketOrderTierId = tierKey
                                            , eventTicketOrderBuyerPartyId = buyerParty
                                            , eventTicketOrderBuyerName = buyerName
                                            , eventTicketOrderBuyerEmail = buyerEmail
                                            , eventTicketOrderQuantity = ticketPurchaseQuantity
                                            , eventTicketOrderAmountCents = finalAmountCents
                                            , eventTicketOrderCurrency = eventTicketTierCurrency tier
                                            , eventTicketOrderStatus = if zeroTotal then "paid" else "pending"
                                            , eventTicketOrderMetadata =
                                                encodeTicketCheckoutMetadata
                                                    tpwpIdempotencyKey
                                                    tpwpPromoCode
                                                    acceptedTermsVersion
                                                    feeBreakdown
                                            , eventTicketOrderCheckoutIdempotencyKey = tpwpIdempotencyKey
                                            , eventTicketOrderPurchasedAt = now
                                            , eventTicketOrderStripePaymentIntentId = Nothing
                                            , eventTicketOrderPromoCodeId = mPromoCodeKey
                                            , eventTicketOrderOriginalAmountCents = Just baseAmountCents
                                            , eventTicketOrderPaymentMethod =
                                                Just
                                                    ( if zeroTotal
                                                        then if isJust mPromoCodeKey then "promo" else "free"
                                                        else "stripe"
                                                    )
                                            , eventTicketOrderCreatedAt = now
                                            , eventTicketOrderUpdatedAt = now
                                            }
                                orderKey <- insert orderRecord
                                issuedCodes <-
                                    if zeroTotal
                                        then issueMissingTicketsForOrder now orderKey orderRecord
                                        else pure []
                                pure (Just (orderKey, orderRecord, issuedCodes, False))
                    createOrder =
                        runSqlPool
                            ( do
                                lockedEvents <-
                                    rawSql
                                        "SELECT ?? FROM social_event WHERE id = ? FOR UPDATE"
                                        [toPersistValue eventKey]
                                when (null (lockedEvents :: [Entity SocialEvent])) $
                                    fail "Event not found while reserving tickets"
                                -- The acceptance was checked before this transaction. Read the
                                -- policy again now that the hold is being taken: a policy
                                -- replaced in between must not be recorded as accepted. The
                                -- row stays share-locked until the order is committed.
                                termsVersionAtHold <- lockActiveTicketTermsVersion now eventKey
                                when (termsVersionAtHold /= mTermsVersion) $
                                    liftIO (throwIO ticketTermsChangedError)
                                soldAcross <-
                                    selectList [EventTicketTierEventId ==. eventKey] []
                                let soldCount =
                                        sum
                                            (map (eventTicketTierQuantitySold . entityVal) soldAcross)
                                    capacityAvailable =
                                        maybe
                                            True
                                            (\cap -> soldCount + ticketPurchaseQuantity <= cap)
                                            (socialEventCapacity eventVal)
                                if not capacityAvailable
                                    then pure Nothing
                                    else do
                                        reservedCount <-
                                            updateWhereCount
                                                [ EventTicketTierId ==. tierKey
                                                , EventTicketTierIsActive ==. True
                                                , EventTicketTierQuantitySold
                                                    <=. eventTicketTierQuantityTotal tier - ticketPurchaseQuantity
                                                ]
                                                [ EventTicketTierQuantitySold +=. ticketPurchaseQuantity
                                                , EventTicketTierUpdatedAt =. now
                                                ]
                                        if reservedCount == 0
                                            then pure Nothing
                                            else createReservedOrder
                            )
                            envPool
                createResult <- liftIO (tryAny createOrder)
                case createResult of
                    Right result -> pure result
                    Left createErr ->
                        case fromException createErr :: Maybe SomeAsyncException of
                            Just _ -> liftIO (throwIO createErr)
                            Nothing
                                | Just serverError <- fromException createErr ->
                                    throwError (serverError :: ServerError)
                                | isEventTicketCheckoutConflict createErr ->
                                    case tpwpIdempotencyKey of
                                        Nothing -> liftIO (throwIO createErr)
                                        Just idempotencyKey -> do
                                            concurrentWinner <-
                                                liftIO $
                                                    runSqlPool
                                                        ( getBy
                                                            ( UniqueEventTicketCheckout
                                                                buyerParty
                                                                (Just idempotencyKey)
                                                            )
                                                        )
                                                        envPool
                                            case concurrentWinner of
                                                Nothing -> liftIO (throwIO createErr)
                                                Just (Entity winnerKey winnerOrder) -> do
                                                    winnerTickets <-
                                                        liftIO $
                                                            runSqlPool
                                                                ( selectList
                                                                    [EventTicketOrderRefId ==. winnerKey]
                                                                    [Asc EventTicketId]
                                                                )
                                                                envPool
                                                    pure . Just $
                                                        ( winnerKey
                                                        , winnerOrder
                                                        , map (eventTicketCode . entityVal) (filter (Transfer.retainedByBuyer . entityVal) winnerTickets)
                                                        , True
                                                        )
                                | otherwise -> liftIO (throwIO createErr)
        (orderKey, orderRecord, issuedCodes, reusedCheckout) <-
            maybe
                (throwError err409{errBody = "Tickets or promo code are no longer available"})
                pure
                createdOrder
        let
            currency = eventTicketOrderCurrency orderRecord
            -- Roll the order back to a state where the caller can retry without
            -- double-selling tickets or double-counting promo redemptions.
            rollbackOrder providerError = do
                liftIO . hPutStrLn stderr . T.unpack . TE.decodeUtf8 . BL.toStrict . Aeson.encode $
                    Aeson.object
                        [ "event" Aeson..= ("stripe_ticket_checkout_failed" :: T.Text)
                        , "orderId" Aeson..= renderKeyText orderKey
                        , "reason" Aeson..= (if "No valid payment method types" `T.isInfixOf` providerError
                            then "payment_methods_unavailable" else "initialization_failed" :: T.Text)
                        ]
                unless reusedCheckout $
                    liftIO $
                        runSqlPool
                            ( do
                                update
                                    orderKey
                                    [ EventTicketOrderStatus =. "cancelled"
                                    , EventTicketOrderUpdatedAt =. now
                                    ]
                                update tierKey [EventTicketTierQuantitySold +=. (negate ticketPurchaseQuantity)]
                                case mPromoCodeKey of
                                    Nothing -> pure ()
                                    Just promoKey -> update promoKey [PromoCodeCurrentRedemptions +=. (-1)]
                            )
                            envPool
                throwError err503
                    { errBody = "Ticket card payments are temporarily unavailable. Please try again later." }
            storedPromoCode =
                decodeTicketCheckoutMetadata (eventTicketOrderMetadata orderRecord)
                    >>= snd
            canonicalRequestMatches =
                eventTicketOrderEventId orderRecord == eventKey
                    && eventTicketOrderTierId orderRecord == tierKey
                    && eventTicketOrderQuantity orderRecord == ticketPurchaseQuantity
                    && eventTicketOrderBuyerPartyId orderRecord == buyerParty
                    && eventTicketOrderBuyerName orderRecord == buyerName
                    && eventTicketOrderBuyerEmail orderRecord == buyerEmail
                    && eventTicketOrderCheckoutIdempotencyKey orderRecord
                        == tpwpIdempotencyKey
                    && storedPromoCode == tpwpPromoCode
                    && maybe
                        True
                        ((== tpwpAcceptedTermsVersion) . Just)
                        (decodeTicketAcceptedTermsVersion (eventTicketOrderMetadata orderRecord))
        when (reusedCheckout && not canonicalRequestMatches) $
            throwError err409{errBody = "ticketPurchaseIdempotencyKey was already used for different checkout details"}
        when
            ( reusedCheckout
                && eventTicketOrderStatus orderRecord `elem` ["cancelled", "refunded"]
            )
            $ throwError err409{errBody = "Ticket checkout is already closed; start a new checkout"}
        when
            ( reusedCheckout
                && eventTicketOrderStatus orderRecord == "paid"
                && finalAmountCents > 0
                && isNothing (eventTicketOrderStripePaymentIntentId orderRecord)
            )
            $ throwError err409{errBody = "Ticket checkout is already paid"}
        if finalAmountCents == 0
            then do
                unless reusedCheckout $
                    sendTicketConfirmationForOrder orderRecord issuedCodes
                pure
                    StripePaymentIntentDTO
                        { spiClientSecret = ""
                        , spiOrderId = renderKeyText orderKey
                        , spiAmountCents = 0
                        , spiCurrency = currency
                        , spiPaymentSheet = Nothing
                        , spiLookupToken = Nothing
                        }
            else
                if reusedCheckout && isJust (eventTicketOrderStripePaymentIntentId orderRecord)
                    then reuseStripeTicketCheckout tpwpMobileSdkStripeVersion orderKey orderRecord
                    else do
                        (secretKey, webhookSecret) <-
                            case (stripeSecretKey envConfig, stripeWebhookSecret envConfig) of
                                (Just configuredSecretKey, Just configuredWebhookSecret) ->
                                    pure (configuredSecretKey, configuredWebhookSecret)
                                _ -> rollbackOrder "Stripe is not configured"
                        let stripeCfg =
                                Stripe.StripeConfig
                                    { Stripe.stripeSecretKey = secretKey
                                    , Stripe.stripeWebhookSecret = webhookSecret
                                    , Stripe.stripeApiVersion = Stripe.defaultStripeApiVersion
                                    }
                            description = "Tickets for event " <> renderKeyText eventKey
                            metadata =
                                Aeson.object
                                    [ "order_id" Aeson..= renderKeyText orderKey
                                    , "event_id" Aeson..= renderKeyText eventKey
                                    ]
                            metadataJson = Just (TE.decodeUtf8 (BL.toStrict (Aeson.encode metadata)))
                            stripeIdempotencyKey =
                                (\key -> "ticket-order-" <> currentPartyId <> "-" <> key)
                                    <$> tpwpIdempotencyKey
                            persistPaymentIntentId piId =
                                liftIO $
                                    runSqlPool
                                        (update orderKey [EventTicketOrderStripePaymentIntentId =. Just piId])
                                        envPool
                            createLegacyPaymentIntent = do
                                result <-
                                    liftIO $
                                        runStripeRequestSafely $
                                            case stripeIdempotencyKey of
                                                Nothing ->
                                                    Stripe.createPaymentIntent
                                                        stripeCfg
                                                        finalAmountCents
                                                        currency
                                                        description
                                                        metadataJson
                                                Just idempotencyKey ->
                                                    Stripe.createPaymentIntentWithIdempotencyKey
                                                        stripeCfg
                                                        idempotencyKey
                                                        finalAmountCents
                                                        currency
                                                        description
                                                        metadataJson
                                either rollbackOrder handleLegacyPaymentIntent result
                            handleLegacyPaymentIntent paymentIntent = do
                                (piId, clientSecret) <-
                                    eitherStripeServerError $
                                        parseStripePaymentIntentResponse paymentIntent
                                persistPaymentIntentId piId
                                pure
                                    StripePaymentIntentDTO
                                        { spiClientSecret = clientSecret
                                        , spiOrderId = renderKeyText orderKey
                                        , spiAmountCents = finalAmountCents
                                        , spiCurrency = currency
                                        , spiPaymentSheet = Nothing
                                        , spiLookupToken = Nothing
                                        }
                            createMobilePaymentSheetIntent mobileSdkVer = do
                                publishableKey <-
                                    maybe
                                        (rollbackOrder "Stripe publishable key not configured")
                                        pure
                                        (stripePublishableKey envConfig)
                                -- Order: customer -> ephemeral key -> PI. Failing fast on
                                -- ephemeral key creation avoids orphaning a PI we cannot return
                                -- to the mobile client.
                                buyerKey <- parseKeyOr400 "buyer party" currentPartyId
                                customerId <-
                                    resolveStripeCustomerForBuyer stripeCfg buyerKey buyerEmail buyerName
                                        `catchError` const (rollbackOrder "customer setup failed")
                                ephResult <-
                                    liftIO $
                                        runStripeRequestSafely $
                                            Stripe.createEphemeralKey stripeCfg customerId mobileSdkVer
                                ephemeralKeySecret <-
                                    either
                                        (\err -> rollbackOrder ("ephemeral key: " <> err))
                                        (eitherStripeServerError . parseStripeEphemeralKeySecret)
                                        ephResult
                                piResult <-
                                    liftIO $
                                        runStripeRequestSafely $
                                            case stripeIdempotencyKey of
                                                Nothing ->
                                                    Stripe.createPaymentIntentForCustomer
                                                        stripeCfg
                                                        customerId
                                                        finalAmountCents
                                                        currency
                                                        description
                                                        metadataJson
                                                Just idempotencyKey ->
                                                    Stripe.createPaymentIntentForCustomerWithIdempotencyKey
                                                        stripeCfg
                                                        idempotencyKey
                                                        customerId
                                                        finalAmountCents
                                                        currency
                                                        description
                                                        metadataJson
                                either
                                    rollbackOrder
                                    (handleMobilePaymentIntent customerId ephemeralKeySecret publishableKey)
                                    piResult
                            handleMobilePaymentIntent customerId ephemeralKeySecret publishableKey paymentIntent = do
                                (piId, clientSecret) <-
                                    eitherStripeServerError $
                                        parseStripePaymentIntentResponse paymentIntent
                                persistPaymentIntentId piId
                                pure
                                    StripePaymentIntentDTO
                                        { spiClientSecret = clientSecret
                                        , spiOrderId = renderKeyText orderKey
                                        , spiAmountCents = finalAmountCents
                                        , spiCurrency = currency
                                        , spiPaymentSheet =
                                            Just
                                                PaymentSheetParamsDTO
                                                    { psCustomerId = customerId
                                                    , psEphemeralKeySecret = ephemeralKeySecret
                                                    , psPaymentIntentClientSecret = clientSecret
                                                    , psPublishableKey = publishableKey
                                                    }
                                        , spiLookupToken = Nothing
                                        }
                        maybe createLegacyPaymentIntent createMobilePaymentSheetIntent tpwpMobileSdkStripeVersion

    -- Refunds
    refundProvidersForOrder :: EventTicketOrderId -> SqlPersistT IO (Bool, [Single T.Text])
    refundProvidersForOrder key = do
        canonical <- rawSql
            "SELECT order_id FROM event_ticket_checkout_runtime WHERE order_id=?"
            [toPersistValue key] :: SqlPersistT IO [Single Int64]
        providers <- if null canonical then pure [] else rawSql
            "SELECT DISTINCT attempt.provider FROM event_ticket_checkout_runtime runtime\
            \ JOIN commerce_payment_attempt attempt ON attempt.checkout_id=runtime.checkout_id\
            \ WHERE runtime.order_id=? AND attempt.status='succeeded'"
            [toPersistValue key]
        pure (not (null canonical), providers)

    createRefundRequest :: T.Text -> T.Text -> RefundRequestDTO -> AppM RefundDTO
    createRefundRequest eventIdStr orderIdStr RefundRequestDTO{..} = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        -- Buyers must retain the refund lifecycle after an imported event is
        -- delisted, especially when the upstream provider cancelled it.
        eventKey <- parseKeyOr400 "event" eventIdStr
        orderKey <- parseKeyOr400 "ticket order" orderIdStr
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        eventVal <- maybe (throwError err404{errBody = "Event not found"}) pure mEvent
        let manager = isEventManager currentPartyId eventVal
        mOrder <- liftIO $ runSqlPool (get orderKey) envPool
        order <- case mOrder of
            Just order -> pure order
            Nothing -> do
                unless manager $ requireEventVisibleToUser eventKey
                throwError err404{errBody = "Ticket order not found"}
        let belongsToEvent = eventTicketOrderEventId order == eventKey
            ownsOrder = eventTicketOrderBuyerPartyId order == Just currentPartyId
            refundableOrder = eventTicketOrderStatus order == "paid"
        unless (manager || (belongsToEvent && ownsOrder && refundableOrder)) $
            requireEventVisibleToUser eventKey
        unless belongsToEvent $
            throwError err400{errBody = "Ticket order does not belong to this event"}
        unless refundableOrder $
            throwError err400{errBody = "Only paid orders can be refunded"}
        unless (manager || ownsOrder) $
            throwError err403{errBody = "You can only request refunds for your own orders"}
        (canonical, providers) <- liftIO $ runSqlPool (refundProvidersForOrder orderKey) envPool
        when (canonical && length providers /= 1) $
            throwError err409 {errBody = "Refund requires one unambiguous verified payment provider"}
        if providers `elem` [[Single "paypal"], [Single "bank_transfer"]] then do
            result <- liftIO $ try (runSqlPool
                (TicketRefund.requestTicketRefundForOrder currentPartyId eventKey orderKey
                    refundRequestAmountCents refundRequestReason now) envPool)
                :: AppM (Either IOException (Entity TicketRefundRequest))
            either (const (throwError err409 {errBody="Refund selection or state is not eligible"}))
                (pure . refundEntityToDTO (eventTicketOrderCurrency order)) result
        else do
            -- Use the canonical event -> order lock order. The existence read
            -- must get a fresh snapshot AFTER a competing request commits.
            result <- liftIO $ runSqlPoolWithIsolation
                (do
                    backendName <- T.toCaseFold <$> getRDBMS
                    let lockSuffix = if "postgres" `T.isInfixOf` backendName then " FOR UPDATE" else ""
                    events <- rawSql ("SELECT ?? FROM social_event WHERE id=?" <> lockSuffix)
                        [toPersistValue eventKey]
                    orders <- rawSql ("SELECT ?? FROM event_ticket_order WHERE id=?" <> lockSuffix)
                        [toPersistValue orderKey]
                    case (events, orders) of
                        ([Entity _ currentEvent], [Entity _ currentOrder])
                            | eventTicketOrderEventId currentOrder /= eventKey ->
                                pure (Left err400{errBody = "Ticket order does not belong to this event"})
                            | eventTicketOrderStatus currentOrder /= "paid" ->
                                pure (Left err400{errBody = "Only paid orders can be refunded"})
                            | not (isEventManager currentPartyId currentEvent
                                || eventTicketOrderBuyerPartyId currentOrder == Just currentPartyId) ->
                                pure (Left err403{errBody = "You can only request refunds for your own orders"})
                            | otherwise -> do
                                currentRoute <- refundProvidersForOrder orderKey
                                if currentRoute /= (canonical, providers) then
                                    pure (Left err409{errBody = "Refund payment routing changed; reload the order"})
                                else do
                                    existing <- selectFirst [TicketRefundRequestOrderId ==. orderKey] []
                                    let amountCents = fromMaybe (eventTicketOrderAmountCents currentOrder)
                                            refundRequestAmountCents
                                    if isJust existing then
                                        pure (Left err409{errBody = "Refund request already exists for this order"})
                                    else if amountCents > eventTicketOrderAmountCents currentOrder then
                                        pure (Left err400{errBody = "Refund amount cannot exceed order amount"})
                                    else if amountCents <= 0 then
                                        pure (Left err400{errBody = "Refund amount must be > 0"})
                                    else do
                                        created <- insertEntity TicketRefundRequest
                                            { ticketRefundRequestOrderId = orderKey
                                            , ticketRefundRequestRequestedByPartyId = Just currentPartyId
                                            , ticketRefundRequestReason = refundRequestReason
                                            , ticketRefundRequestAmountCents = amountCents
                                            , ticketRefundRequestStatus = "pending"
                                            , ticketRefundRequestApprovedByPartyId = Nothing
                                            , ticketRefundRequestApprovedAt = Nothing
                                            , ticketRefundRequestRejectionReason = Nothing
                                            , ticketRefundRequestStripeRefundId = Nothing
                                            , ticketRefundRequestProcessedAt = Nothing
                                            , ticketRefundRequestCreatedAt = now
                                            , ticketRefundRequestUpdatedAt = now
                                            }
                                        pure (Right (created, eventTicketOrderCurrency currentOrder))
                        ([], _) -> pure (Left err404{errBody = "Event not found"})
                        _ -> pure (Left err404{errBody = "Ticket order not found"})
                ) envPool ReadCommitted
            either throwError (\(created, currency) -> pure (refundEntityToDTO currency created)) result

    listRefunds :: T.Text -> AppM [RefundDTO]
    listRefunds eventIdStr = do
        Env{..} <- ask
        eventKey <- parseKeyOr400 "event" eventIdStr
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        eventVal <- maybe (throwError err404{errBody = "Event not found"}) pure mEvent
        hiddenImportedAdmin <-
            if hasStrictAdminAccess user
                then liftIO $ runSqlPool (isImportedEventHidden eventKey) envPool
                else pure False
        let manager = isEventManager currentPartyId eventVal
            canViewAllRefunds = manager || hiddenImportedAdmin || hasStrictAdminAccess user
        candidateOrders <-
            if canViewAllRefunds
                then
                    liftIO $
                        runSqlPool
                            (selectList [EventTicketOrderEventId ==. eventKey] [])
                            envPool
                else
                    liftIO $
                        runSqlPool
                            (selectList [EventTicketOrderEventId ==. eventKey, EventTicketOrderBuyerPartyId ==. Just currentPartyId] [])
                            envPool
        let candidateOrderIds = map entityKey candidateOrders
        candidateRefunds <-
            liftIO $
                runSqlPool
                    (selectList [TicketRefundRequestOrderId <-. candidateOrderIds] [Desc TicketRefundRequestCreatedAt])
                    envPool
        let refundOrderIds =
                Set.fromList
                    [ ticketRefundRequestOrderId refundRow
                    | Entity _ refundRow <- candidateRefunds
                    ]
            orders =
                if canViewAllRefunds
                    then candidateOrders
                    else
                        filter
                            ( \orderEntity ->
                                let orderRow = entityVal orderEntity
                                 in eventTicketOrderStatus orderRow `elem` ["paid", "refunded"]
                                        || entityKey orderEntity `Set.member` refundOrderIds
                            )
                            candidateOrders
        when (not canViewAllRefunds && null orders) $
            requireEventVisibleToUser eventKey
        let orderIds = map entityKey orders
            visibleOrderIds = Set.fromList orderIds
            orderCurrencies =
                Map.fromList
                    [ (entityKey orderEntity, eventTicketOrderCurrency (entityVal orderEntity))
                    | orderEntity <- orders
                    ]
            refunds =
                filter
                    ( \(Entity _ refundRow) ->
                        ticketRefundRequestOrderId refundRow `Set.member` visibleOrderIds
                    )
                    candidateRefunds
        forM refunds $ \refundEntity@(Entity _ refundRow) ->
            case Map.lookup (ticketRefundRequestOrderId refundRow) orderCurrencies of
                Just currency -> pure (refundEntityToDTO currency refundEntity)
                Nothing -> throwError err500{errBody = "Refund order currency not found"}

    approveRefund :: T.Text -> T.Text -> AppM RefundDTO
    approveRefund eventIdStr refundIdStr = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        (eventKey, _) <- requireRefundManagedEvent eventIdStr
        refundKey <- parseKeyOr400 "refund" refundIdStr
        mRefund <- liftIO $ runSqlPool (get refundKey) envPool
        refund <- maybe (throwError err404{errBody = "Refund request not found"}) pure mRefund
        let orderKey = ticketRefundRequestOrderId refund
        mOrder <- liftIO $ runSqlPool (get orderKey) envPool
        order <- maybe (throwError err404{errBody = "Ticket order not found"}) pure mOrder
        when (eventTicketOrderEventId order /= eventKey) $
            throwError err400{errBody = "Refund does not belong to this event"}
        canonical <- liftIO $ runSqlPool (TicketRefund.loadTicketRefundReference refundKey) envPool
        case canonical of
            Just _ -> refundEntityToDTO (eventTicketOrderCurrency order) <$>
                TicketRefunds.approvePaypalTicketRefund user eventKey refundKey
            Nothing -> do
                when (ticketRefundRequestStatus refund /= "pending") $
                    throwError err409{errBody = "Refund request is not pending"}
                case (eventTicketOrderStripePaymentIntentId order, stripeSecretKey envConfig, stripeWebhookSecret envConfig) of
                    (Just piId, Just secretKey, Just webhookSecret) -> do
                        let stripeCfg =
                                Stripe.StripeConfig
                                    { Stripe.stripeSecretKey = secretKey
                                    , Stripe.stripeWebhookSecret = webhookSecret
                                    , Stripe.stripeApiVersion = Stripe.defaultStripeApiVersion
                                    }
                        -- Commit a non-expiring execution fence before provider IO.
                        -- A lost response or process crash must never grant a second POST.
                        claimed <- liftIO $ runSqlPool
                            (updateWhereCount
                                [ TicketRefundRequestId ==. refundKey
                                , TicketRefundRequestOrderId ==. orderKey
                                , TicketRefundRequestAmountCents ==. ticketRefundRequestAmountCents refund
                                , TicketRefundRequestStatus ==. "pending"
                                ]
                                [ TicketRefundRequestStatus =. "processing"
                                , TicketRefundRequestApprovedByPartyId =. Just currentPartyId
                                , TicketRefundRequestApprovedAt =. Just now
                                , TicketRefundRequestUpdatedAt =. now
                                ]) envPool
                        unless (claimed == 1) $
                            throwError err409{errBody = "Refund request was already claimed or changed"}
                        result <- liftIO $ issueStripeRefund stripeCfg piId (ticketRefundRequestAmountCents refund)
                        case result of
                            Left err -> throwError err500{errBody = BL.fromStrict (TE.encodeUtf8 ("Stripe refund error: " <> err))}
                            Right refundResponse -> do
                                let unverified = err502
                                        { errBody = "Refund outcome requires reconciliation; request remains processing" }
                                refundId <-
                                    either (const (throwError unverified)) pure $
                                        parseStripeRefundResponse refundResponse
                                unless (validObservedStripeRefundId refundId) $
                                    throwError unverified
                                -- Retain an observed ID even when status or money
                                -- fails validation. It is not verified payment binding.
                                observed <- liftIO $ runSqlPool
                                    (updateWhereCount
                                        ([ TicketRefundRequestId ==. refundKey
                                         , TicketRefundRequestOrderId ==. orderKey
                                         , TicketRefundRequestAmountCents
                                            ==. ticketRefundRequestAmountCents refund
                                         , TicketRefundRequestStatus ==. "processing"
                                         ] <>
                                         ([TicketRefundRequestStripeRefundId ==. Nothing]
                                            ||. [TicketRefundRequestStripeRefundId ==. Just refundId]))
                                        [ TicketRefundRequestStripeRefundId =. Just refundId
                                        , TicketRefundRequestUpdatedAt =. now
                                        ]) envPool
                                unless (observed == 1 && stripeRefundCompletionMatches
                                    piId (ticketRefundRequestAmountCents refund)
                                    (eventTicketOrderCurrency order) refundResponse) $
                                    throwError unverified
                                completed <- liftIO $ trySynchronous $
                                    runSqlPool
                                        ( do
                                            changed <- updateWhereCount
                                                [ TicketRefundRequestId ==. refundKey
                                                , TicketRefundRequestOrderId ==. orderKey
                                                , TicketRefundRequestAmountCents
                                                    ==. ticketRefundRequestAmountCents refund
                                                , TicketRefundRequestStatus ==. "processing"
                                                , TicketRefundRequestStripeRefundId ==. Just refundId
                                                ]
                                                [ TicketRefundRequestStatus =. "approved"
                                                , TicketRefundRequestApprovedByPartyId =. Just currentPartyId
                                                , TicketRefundRequestApprovedAt =. Just now
                                                , TicketRefundRequestStripeRefundId =. Just refundId
                                                , TicketRefundRequestProcessedAt =. Just now
                                                , TicketRefundRequestUpdatedAt =. now
                                                ]
                                            unless (changed == 1) $
                                                fail "Refund execution state changed before completion"
                                            update orderKey [EventTicketOrderStatus =. "refunded", EventTicketOrderUpdatedAt =. now]
                                            updateWhere
                                                [EventTicketOrderRefId ==. orderKey]
                                                [EventTicketStatus =. "refunded", EventTicketUpdatedAt =. now]
                                            let quantity = eventTicketOrderQuantity order
                                            unless (quantity > 0) $
                                                fail "Refund inventory release requires a positive quantity"
                                            released <- updateWhereCount
                                                [ EventTicketTierId ==. eventTicketOrderTierId order
                                                , EventTicketTierEventId ==. eventTicketOrderEventId order
                                                , EventTicketTierQuantitySold >=. quantity
                                                ]
                                                [ EventTicketTierQuantitySold +=. negate quantity
                                                , EventTicketTierUpdatedAt =. now
                                                ]
                                            unless (released == 1) $
                                                fail "Refund inventory release requires reconciliation"
                                        )
                                        envPool
                                either (const (throwError unverified)) pure completed
                                mUpdated <- liftIO $ runSqlPool (getEntity refundKey) envPool
                                maybe
                                    (throwError err500{errBody = "Could not approve refund"})
                                    (pure . refundEntityToDTO (eventTicketOrderCurrency order))
                                    mUpdated
                    _ -> throwError err500{errBody = "Cannot process refund: Stripe not configured or order has no payment intent"}

    rejectRefund :: T.Text -> T.Text -> RejectionReasonDTO -> AppM RefundDTO
    rejectRefund eventIdStr refundIdStr RejectionReasonDTO{..} = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        (eventKey, _) <- requireRefundManagedEvent eventIdStr
        refundKey <- parseKeyOr400 "refund" refundIdStr
        mRefund <- liftIO $ runSqlPool (get refundKey) envPool
        refund <- maybe (throwError err404{errBody = "Refund request not found"}) pure mRefund
        let orderKey = ticketRefundRequestOrderId refund
        mOrder <- liftIO $ runSqlPool (get orderKey) envPool
        order <- maybe (throwError err404{errBody = "Ticket order not found"}) pure mOrder
        when (eventTicketOrderEventId order /= eventKey) $
            throwError err400{errBody = "Refund does not belong to this event"}
        when (ticketRefundRequestStatus refund /= "pending") $
            throwError err409{errBody = "Refund request is not pending"}
        when (T.null (T.strip rrReason)) $
            throwError err400{errBody = "Rejection reason is required"}
        rejected <- liftIO $ trySynchronous $
            runSqlPool
                ( do
                    binding <- TicketRefund.loadTicketRefundReference refundKey
                    forM_ binding $ \ref -> TicketRefund.cancelTicketRefundAs user ref now
                    -- Recheck after a competing approval's row lock. Raising on
                    -- loss also rolls back any canonical cancellation above.
                    changed <- updateWhereCount
                        [ TicketRefundRequestId ==. refundKey
                        , TicketRefundRequestOrderId ==. orderKey
                        , TicketRefundRequestStatus ==. "pending"
                        ]
                        [ TicketRefundRequestStatus =. "rejected"
                        , TicketRefundRequestRejectionReason =. Just rrReason
                        , TicketRefundRequestUpdatedAt =. now
                        ]
                    unless (changed == 1) $ fail "Refund request is no longer pending"
                )
                envPool
        either (const (throwError err409{errBody = "Refund request is no longer pending"})) pure rejected
        mUpdated <- liftIO $ runSqlPool (getEntity refundKey) envPool
        maybe
            (throwError err500{errBody = "Could not reject refund"})
            (pure . refundEntityToDTO (eventTicketOrderCurrency order))
            mUpdated

    -- Manual bank transfer review
    listManualPayments :: T.Text -> AppM [TicketManualPaymentDTO]
    listManualPayments eventIdStr = do
        Env{..} <- ask
        (eventKey, _) <- requireRefundManagedEvent eventIdStr
        liftIO $ runSqlPool (ManualPayments.listTicketManualPayments eventKey) envPool

    reviewManualPayment :: T.Text -> T.Text -> TicketManualPaymentReviewDTO -> AppM TicketManualPaymentDTO
    reviewManualPayment eventIdStr orderIdStr TicketManualPaymentReviewDTO{..} = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        (eventKey, _) <- requireRefundManagedEvent eventIdStr
        orderKey <- parseKeyOr400 "order" orderIdStr
        action <- either (\msg -> throwError err400{errBody = BL.fromStrict (TE.encodeUtf8 msg)}) pure $
            ManualPayments.parseManualReviewAction tmprAction
        notes <- either (\msg -> throwError err400{errBody = BL.fromStrict (TE.encodeUtf8 msg)}) pure $
            ManualPayments.validateManualReviewNotes tmprNotes
        let reviewer =
                ManualPayments.ManualReviewer
                    { ManualPayments.mrPartyId = fromSqlKey (auPartyId user)
                    , ManualPayments.mrStrictAdmin = hasStrictAdminAccess user
                    }
        -- Approval and the idempotent issuance commit together; a failed
        -- issuance leaves the transfer reviewable instead of paid without tickets.
        outcome <- liftIO $ trySynchronous $
            runSqlPool
                ( ManualPayments.reviewTicketManualPayment reviewer eventKey orderKey action notes now
                    (void (finalizePaidTicketOrder now orderKey))
                )
                envPool
        result <- either
            (const (throwError err409{errBody = "Tickets could not be issued, so the transfer was not approved; try again"}))
            pure
            outcome
        _ <- either (\msg -> throwError err409{errBody = BL.fromStrict (TE.encodeUtf8 msg)}) pure result
        rows <- liftIO $ runSqlPool (ManualPayments.listTicketManualPayments eventKey) envPool
        case filter ((== T.pack (show (fromSqlKey orderKey))) . tmpOrderId) rows of
            dto : _ -> pure dto
            [] -> throwError err404{errBody = "Ticket order not found"}

    getManualPaymentReceipt :: T.Text -> T.Text -> AppM (Headers '[Header "Cache-Control" T.Text] Receipt.TicketPaymentReceipt)
    getManualPaymentReceipt eventIdStr orderIdStr = do
        Env{..} <- ask
        (eventKey, _) <- requireRefundManagedEvent eventIdStr
        orderKey <- parseKeyOr400 "order" orderIdStr
        rows <- liftIO $ runSqlPool (rawSql
            "SELECT evidence.evidence_object_key FROM commerce_manual_payment_evidence evidence\
            \ JOIN commerce_payment_attempt attempt ON attempt.id = evidence.payment_attempt_id\
            \ JOIN event_ticket_checkout_runtime runtime ON runtime.checkout_id = evidence.checkout_id\
            \ WHERE runtime.event_id = ? AND runtime.order_id = ?\
            \ AND attempt.checkout_id = evidence.checkout_id\
            \ AND attempt.provider = 'bank_transfer' AND attempt.operation = 'manual_verify'"
            [toPersistValue eventKey, toPersistValue (orderKey :: EventTicketOrderId)]
            :: SqlPersistT IO [Single (Maybe T.Text)]) envPool
        case rows of
            [Single (Just key)] -> addHeader ("no-store" :: T.Text) <$> Receipt.loadReceipt (fromSqlKey orderKey) key
            _ -> throwError err404{errBody = "No receipt was attached to this transfer"}

    -- SRI electronic invoices
    listTaxDocuments :: T.Text -> AppM [TicketTaxDocumentDTO]
    listTaxDocuments eventIdStr = do
        Env{..} <- ask
        (eventKey, _) <- requireRefundManagedEvent eventIdStr
        liftIO $ runSqlPool (TaxDocuments.listTicketTaxDocuments eventKey) envPool

    retryTaxDocument :: T.Text -> T.Text -> AppM [TicketTaxDocumentDTO]
    retryTaxDocument eventIdStr documentIdStr = do
        Env{..} <- ask
        (eventKey, _) <- requireRefundManagedEvent eventIdStr
        unless (hasStrictAdminAccess user) $
            throwError err403{errBody = "Only administrators may resend an invoice"}
        when (T.length documentIdStr /= 36 || T.any (\c -> not (c == '-' || isHexDigit c)) documentIdStr) $
            throwError err400{errBody = "Invalid invoice document id"}
        retried <- liftIO $ runSqlPool (TaxDocuments.retryFailedTicketTaxDocument eventKey documentIdStr) envPool
        unless retried $
            throwError err409{errBody = "Only invoices the provider refused before creating them can be resent"}
        liftIO $ runSqlPool (TaxDocuments.listTicketTaxDocuments eventKey) envPool

    completeBankTransferRefund :: T.Text -> T.Text -> BankRefundCompletionDTO -> AppM RefundDTO
    completeBankTransferRefund eventIdStr refundIdStr BankRefundCompletionDTO{..} = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        (eventKey, _) <- requireRefundManagedEvent eventIdStr
        refundKey <- parseKeyOr400 "refund" refundIdStr
        providerRefund <- either (\msg -> throwError err400{errBody = BL.fromStrict (TE.encodeUtf8 msg)}) pure $
            ManualPayments.validateBankRefundReference brcReference
        let reviewer =
                ManualPayments.ManualReviewer
                    { ManualPayments.mrPartyId = fromSqlKey (auPartyId user)
                    , ManualPayments.mrStrictAdmin = hasStrictAdminAccess user
                    }
        result <- liftIO $ try (runSqlPool
            (ManualPayments.completeBankTransferTicketRefund reviewer eventKey refundKey providerRefund now) envPool)
            :: AppM (Either IOException (Either T.Text ()))
        case result of
            Left _ -> throwError err409{errBody = "Refund tickets or state do not permit completion"}
            Right (Left msg) -> throwError err409{errBody = BL.fromStrict (TE.encodeUtf8 msg)}
            Right (Right ()) -> pure ()
        mRefund <- liftIO $ runSqlPool (getEntity refundKey) envPool
        refund <- maybe (throwError err404{errBody = "Refund request not found"}) pure mRefund
        mOrder <- liftIO $ runSqlPool (get (ticketRefundRequestOrderId (entityVal refund))) envPool
        order <- maybe (throwError err404{errBody = "Ticket order not found"}) pure mOrder
        pure (refundEntityToDTO (eventTicketOrderCurrency order) refund)

    -- Transfers
    createTransfer :: T.Text -> T.Text -> TicketTransferCreateDTO -> AppM TicketTransferDTO
    createTransfer eventIdStr ticketIdStr TicketTransferCreateDTO{..} = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        eventKey <- parseVisibleEventKey eventIdStr
        ticketKey <- parseKeyOr400 "ticket" ticketIdStr
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        eventVal <- maybe (throwError err404{errBody = "Event not found"}) pure mEvent
        mTicket <- liftIO $ runSqlPool (get ticketKey) envPool
        ticket <- maybe (throwError err404{errBody = "Ticket not found"}) pure mTicket
        when (eventTicketEventId ticket /= eventKey) $
            throwError err400{errBody = "Ticket does not belong to this event"}
        let manager = isEventManager currentPartyId eventVal
        when (not manager && eventTicketCurrentHolderPartyId ticket /= Just currentPartyId) $
            throwError err403{errBody = "You can only transfer your own tickets"}
        when (eventTicketStatus ticket `elem` ["cancelled", "refunded", "checked_in"]) $
            throwError err400{errBody = "Cannot transfer this ticket"}
        transferCode <- liftIO Admission.newTicketCode
        let expiresAt = addUTCTime (48 * 3600) now
        result <-
            liftIO $
                runSqlPool
                    ( Transfer.createTransfer currentPartyId eventKey
                        TicketTransfer
                            { ticketTransferTicketId = ticketKey
                            , ticketTransferFromPartyId = Just currentPartyId
                            , ticketTransferToPartyId = Nothing
                            , ticketTransferToEmail = Just ttcToEmail
                            , ticketTransferToName = ttcToName
                            , ticketTransferStatus = "pending"
                            , ticketTransferTransferCode = transferCode
                            , ticketTransferMessage = ttcMessage
                            , ticketTransferExpiresAt = Just expiresAt
                            , ticketTransferAcceptedAt = Nothing
                            , ticketTransferCreatedAt = now
                            , ticketTransferUpdatedAt = now
                            }
                        now
                    )
                    envPool
        either (throwError . (\message -> err409{errBody = BL.fromStrict (TE.encodeUtf8 message)}))
            (pure . transferEntityToDTO) result

    listTransfers :: T.Text -> T.Text -> AppM [TicketTransferDTO]
    listTransfers eventIdStr ticketIdStr = do
        Env{..} <- ask
        eventKey <- parseVisibleEventKey eventIdStr
        ticketKey <- parseKeyOr400 "ticket" ticketIdStr
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        eventVal <- maybe (throwError err404{errBody = "Event not found"}) pure mEvent
        mTicket <- liftIO $ runSqlPool (get ticketKey) envPool
        ticket <- maybe (throwError err404{errBody = "Ticket not found"}) pure mTicket
        when (eventTicketEventId ticket /= eventKey) $
            throwError err400{errBody = "Ticket does not belong to this event"}
        let manager = isEventManager currentPartyId eventVal
        when (not manager && eventTicketCurrentHolderPartyId ticket /= Just currentPartyId) $
            throwError err403{errBody = "You can only view transfers for your own tickets"}
        -- Recheck ownership in the same statement that reads invitation credentials.
        transfers <- liftIO $ runSqlPool
            (rawSql
                "SELECT ?? FROM ticket_transfer WHERE ticket_id=? AND EXISTS (SELECT 1 FROM event_ticket t JOIN social_event e ON e.id=t.event_id WHERE t.id=ticket_transfer.ticket_id AND t.event_id=? AND (t.current_holder_party_id=? OR e.organizer_party_id=?)) ORDER BY created_at DESC"
                [toPersistValue ticketKey, toPersistValue eventKey, PersistText currentPartyId, PersistText currentPartyId])
            envPool
        pure (map transferEntityToDTO transfers)

    acceptTransfer :: T.Text -> AppM TicketDTO
    acceptTransfer transferCode = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        mTransferEnt <- liftIO $ runSqlPool (getBy (UniqueTicketTransferCode transferCode)) envPool
        transferEnt <- maybe (throwError err404{errBody = "Transfer not found"}) pure mTransferEnt
        let transfer = entityVal transferEnt
            ticketKey = ticketTransferTicketId transfer
        mTicket <- liftIO $ runSqlPool (get ticketKey) envPool
        ticket <- maybe (throwError err404{errBody = "Ticket not found"}) pure mTicket
        requireEventVisibleToUser (eventTicketEventId ticket)
        replacement <- liftIO Admission.newTicketCode
        result <- liftIO $ runSqlPool
            (Transfer.acceptTransfer currentPartyId transferCode replacement now) envPool
        either (throwError . (\message -> err409{errBody = BL.fromStrict (TE.encodeUtf8 message)}))
            (pure . ticketEntityToDTO) result

    cancelTransfer :: T.Text -> AppM TicketTransferDTO
    cancelTransfer transferIdStr = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        transferKey <- parseKeyOr400 "transfer" transferIdStr
        mTransfer <- liftIO $ runSqlPool (get transferKey) envPool
        transfer <- maybe (throwError err404{errBody = "Transfer not found"}) pure mTransfer
        mTicket <- liftIO $ runSqlPool (get (ticketTransferTicketId transfer)) envPool
        ticket <- maybe (throwError err404{errBody = "Ticket not found"}) pure mTicket
        requireEventVisibleToUser (eventTicketEventId ticket)
        when (ticketTransferFromPartyId transfer /= Just currentPartyId) $
            throwError err403{errBody = "You can only cancel your own transfers"}
        result <- liftIO $ runSqlPool (Transfer.cancelTransfer currentPartyId transferKey now) envPool
        either (throwError . (\message -> err409{errBody = BL.fromStrict (TE.encodeUtf8 message)}))
            (pure . transferEntityToDTO) result

    -- Waitlist
    joinWaitlist :: T.Text -> WaitlistJoinDTO -> AppM WaitlistEntryDTO
    joinWaitlist eventIdStr WaitlistJoinDTO{..} = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        eventKey <- parseVisibleEventKey eventIdStr
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        _ <- maybe (throwError err404{errBody = "Event not found"}) pure mEvent
        mTierKey <- case cleanMaybeText wjTierId of
            Nothing -> pure Nothing
            Just tierIdStr -> do
                tierKey <- parseKeyOr400 "ticket tier" tierIdStr
                mTier <- liftIO $ runSqlPool (get tierKey) envPool
                tier <- maybe (throwError err404{errBody = "Ticket tier not found"}) pure mTier
                when (eventTicketTierEventId tier /= eventKey) $
                    throwError err400{errBody = "Ticket tier does not belong to this event"}
                pure (Just tierKey)
        when (wjQuantity < 1 || wjQuantity > 10) $
            throwError err400{errBody = "Quantity must be between 1 and 10"}
        mExisting <-
            liftIO $
                runSqlPool
                    ( selectFirst
                        [EventWaitlistEventId ==. eventKey, EventWaitlistEmail ==. wjEmail, EventWaitlistStatus ==. "active"]
                        []
                    )
                    envPool
        when (isJust mExisting) $
            throwError err409{errBody = "Already on waitlist for this event"}
        waitlistKey <-
            liftIO $
                runSqlPool
                    ( insert
                        EventWaitlist
                            { eventWaitlistEventId = eventKey
                            , eventWaitlistTierId = mTierKey
                            , eventWaitlistPartyId = Nothing
                            , eventWaitlistEmail = wjEmail
                            , eventWaitlistName = wjName
                            , eventWaitlistQuantity = wjQuantity
                            , eventWaitlistStatus = "active"
                            , eventWaitlistPriority = 0
                            , eventWaitlistNotifiedAt = Nothing
                            , eventWaitlistExpiresAt = Nothing
                            , eventWaitlistConvertedOrderId = Nothing
                            , eventWaitlistCreatedAt = now
                            , eventWaitlistUpdatedAt = now
                            }
                    )
                    envPool
        mWaitlist <- liftIO $ runSqlPool (getEntity waitlistKey) envPool
        maybe
            (throwError err500{errBody = "Could not join waitlist"})
            (pure . waitlistEntityToDTO)
            mWaitlist

    listWaitlist :: T.Text -> Maybe T.Text -> AppM [WaitlistEntryDTO]
    listWaitlist eventIdStr mStatus = do
        Env{..} <- ask
        (eventKey, _) <- requireManagedEvent eventIdStr
        let statusFilters = case cleanMaybeText mStatus of
                Nothing -> []
                Just status -> [EventWaitlistStatus ==. status]
            filters = [EventWaitlistEventId ==. eventKey] ++ statusFilters
        entries <-
            liftIO $
                runSqlPool
                    (selectList filters [Asc EventWaitlistPriority, Asc EventWaitlistCreatedAt])
                    envPool
        pure (map waitlistEntityToDTO entries)

    notifyWaitlist :: T.Text -> T.Text -> AppM WaitlistEntryDTO
    notifyWaitlist eventIdStr waitlistIdStr = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        (eventKey, _) <- requireManagedEvent eventIdStr
        waitlistKey <- parseKeyOr400 "waitlist entry" waitlistIdStr
        mWaitlist <- liftIO $ runSqlPool (get waitlistKey) envPool
        waitlist <- maybe (throwError err404{errBody = "Waitlist entry not found"}) pure mWaitlist
        when (eventWaitlistEventId waitlist /= eventKey) $
            throwError err400{errBody = "Waitlist entry does not belong to this event"}
        when (eventWaitlistStatus waitlist /= "active") $
            throwError err400{errBody = "Waitlist entry is not active"}
        let expiresAt = addUTCTime (24 * 3600) now
        liftIO $
            runSqlPool
                ( update
                    waitlistKey
                    [ EventWaitlistStatus =. "notified"
                    , EventWaitlistNotifiedAt =. Just now
                    , EventWaitlistExpiresAt =. Just expiresAt
                    , EventWaitlistUpdatedAt =. now
                    ]
                )
                envPool
        mUpdated <- liftIO $ runSqlPool (getEntity waitlistKey) envPool
        maybe
            (throwError err500{errBody = "Could not notify waitlist entry"})
            (pure . waitlistEntityToDTO)
            mUpdated

    removeFromWaitlist :: T.Text -> T.Text -> AppM NoContent
    removeFromWaitlist eventIdStr waitlistIdStr = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        eventKey <- parseVisibleEventKey eventIdStr
        waitlistKey <- parseKeyOr400 "waitlist entry" waitlistIdStr
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        eventVal <- maybe (throwError err404{errBody = "Event not found"}) pure mEvent
        mWaitlist <- liftIO $ runSqlPool (get waitlistKey) envPool
        waitlist <- maybe (throwError err404{errBody = "Waitlist entry not found"}) pure mWaitlist
        when (eventWaitlistEventId waitlist /= eventKey) $
            throwError err400{errBody = "Waitlist entry does not belong to this event"}
        let manager = isEventManager currentPartyId eventVal
        when (not manager) $
            throwError err403{errBody = "Only event managers can remove waitlist entries"}
        liftIO $
            runSqlPool
                ( update
                    waitlistKey
                    [ EventWaitlistStatus =. "removed"
                    , EventWaitlistUpdatedAt =. now
                    ]
                )
                envPool
        pure NoContent

    -- QR Code
    getTicketQR :: T.Text -> T.Text -> AppM TicketWithQRDTO
    getTicketQR eventIdStr ticketIdStr = do
        Env{..} <- ask
        eventKey <- parseVisibleEventKey eventIdStr
        ticketKey <- parseKeyOr400 "ticket" ticketIdStr
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        eventVal <- maybe (throwError err404{errBody = "Event not found"}) pure mEvent
        mTicket <- liftIO $ runSqlPool (get ticketKey) envPool
        ticket <- maybe (throwError err404{errBody = "Ticket not found"}) pure mTicket
        when (eventTicketEventId ticket /= eventKey) $
            throwError err400{errBody = "Ticket does not belong to this event"}
        let manager = isEventManager currentPartyId eventVal
        when (not manager && eventTicketCurrentHolderPartyId ticket /= Just currentPartyId) $
            throwError err403{errBody = "You can only view QR codes for your own tickets"}
        -- A QR is an opaque ticket credential, never a PII-bearing signed payload.
        -- Stored legacy QR strings are deliberately not returned.
        let qrData = eventTicketCode ticket
        let ticketDto = ticketEntityToDTO (Entity ticketKey ticket)
        pure
            TicketWithQRDTO
                { twqTicket = ticketDto
                , twqQRData = qrData
                , twqQRImageUrl = Nothing
                }

    -- Budget
    budgetServer :: ServerT BudgetRoutes AppM
    budgetServer =
        listBudgetLines
            :<|> createBudgetLine
            :<|> updateBudgetLine

    listBudgetLines :: T.Text -> AppM [EventBudgetLineDTO]
    listBudgetLines eventIdStr = do
        Env{..} <- ask
        (eventKey, _) <- requireManagedEvent eventIdStr
        budgetRows <-
            liftIO $
                runSqlPool
                    (selectList [EventBudgetLineEventId ==. eventKey] [Asc EventBudgetLineLineType, Asc EventBudgetLineCategory, Asc EventBudgetLineCode])
                    envPool
        postedEntries <-
            liftIO $
                runSqlPool
                    (selectList [EventFinanceEntryEventId ==. eventKey, EventFinanceEntryStatus ==. "posted"] [])
                    envPool
        forM budgetRows $ \lineEnt@(Entity lineKey lineRec) -> do
            let lineTypeVal = normalizeBudgetLineType (Just (eventBudgetLineLineType lineRec))
                exactActualCents = sum
                    [ toInteger (eventFinanceEntryAmountCents entry)
                    | Entity _ entry <- postedEntries
                    , eventFinanceEntryBudgetLineId entry == Just lineKey
                    , normalizeFinanceDirection (Just (eventFinanceEntryDirection entry)) == lineTypeVal
                    ]
            actualCents <- checkedEventFinanceCents exactActualCents
            pure (budgetLineEntityToDTO eventKey (Just actualCents) lineEnt)

    createBudgetLine :: T.Text -> EventBudgetLineDTO -> AppM EventBudgetLineDTO
    createBudgetLine eventIdStr dto = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        (eventKey, _) <- requireManagedEvent eventIdStr
        let lineName = T.strip (eblName dto)
        when (T.null lineName) $ throwError err400{errBody = "budget line name is required"}
        when (eblPlannedCents dto < 0) $ throwError err400{errBody = "planned cents must be >= 0"}
        lineTypeVal <- either throwError pure (validateBudgetLineTypeInput (eblType dto))
        let codeVal = normalizeBudgetLineCode (fromMaybe lineName (cleanMaybeText (Just (eblCode dto))))
            categoryVal = normalizeCategory (Just (eblCategory dto))
        mInserted <-
            liftIO $
                runSqlPool
                    ( insertUnique
                        EventBudgetLine
                            { eventBudgetLineEventId = eventKey
                            , eventBudgetLineCode = codeVal
                            , eventBudgetLineName = lineName
                            , eventBudgetLineLineType = lineTypeVal
                            , eventBudgetLineCategory = categoryVal
                            , eventBudgetLinePlannedCents = eblPlannedCents dto
                            , eventBudgetLineNotes = cleanMaybeText (eblNotes dto)
                            , eventBudgetLineCreatedAt = now
                            , eventBudgetLineUpdatedAt = now
                            }
                    )
                    envPool
        lineKey <- maybe (throwError err409{errBody = "budget line code already exists for this event"}) pure mInserted
        mLine <- liftIO $ runSqlPool (getEntity lineKey) envPool
        maybe
            (throwError err500{errBody = "Could not create budget line"})
            (pure . budgetLineEntityToDTO eventKey (Just 0))
            mLine

    updateBudgetLine :: T.Text -> T.Text -> EventBudgetLineDTO -> AppM EventBudgetLineDTO
    updateBudgetLine eventIdStr lineIdStr dto = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        (eventKey, _) <- requireManagedEvent eventIdStr
        lineKey <- parseKeyOr400 "budget line" lineIdStr
        mLine <- liftIO $ runSqlPool (get lineKey) envPool
        lineRec <- maybe (throwError err404{errBody = "Budget line not found"}) pure mLine
        when (eventBudgetLineEventId lineRec /= eventKey) $ throwError err400{errBody = "Budget line does not belong to this event"}
        let lineName = T.strip (eblName dto)
        when (T.null lineName) $ throwError err400{errBody = "budget line name is required"}
        when (eblPlannedCents dto < 0) $ throwError err400{errBody = "planned cents must be >= 0"}
        lineTypeVal <- either throwError pure (validateBudgetLineTypeInput (eblType dto))
        let codeVal = normalizeBudgetLineCode (fromMaybe lineName (cleanMaybeText (Just (eblCode dto))))
            categoryVal = normalizeCategory (Just (eblCategory dto))
        mCodeOwner <- liftIO $ runSqlPool (getBy (UniqueEventBudgetLineCode eventKey codeVal)) envPool
        case mCodeOwner of
            Just (Entity existingKey _)
                | existingKey /= lineKey ->
                    throwError err409{errBody = "budget line code already exists for this event"}
            _ -> pure ()
        postedEntries <-
            liftIO $
                runSqlPool
                    ( selectList
                        [ EventFinanceEntryEventId ==. eventKey
                        , EventFinanceEntryBudgetLineId ==. Just lineKey
                        , EventFinanceEntryStatus ==. "posted"
                        ]
                        []
                    )
                    envPool
        let exactActualCents =
                sum
                    [ toInteger (eventFinanceEntryAmountCents entry)
                    | Entity _ entry <- postedEntries
                    , normalizeFinanceDirection (Just (eventFinanceEntryDirection entry)) == lineTypeVal
                    ]
        actualCents <- checkedEventFinanceCents exactActualCents
        liftIO $
            runSqlPool
                ( update
                    lineKey
                    [ EventBudgetLineCode =. codeVal
                    , EventBudgetLineName =. lineName
                    , EventBudgetLineLineType =. lineTypeVal
                    , EventBudgetLineCategory =. categoryVal
                    , EventBudgetLinePlannedCents =. eblPlannedCents dto
                    , EventBudgetLineNotes =. cleanMaybeText (eblNotes dto)
                    , EventBudgetLineUpdatedAt =. now
                    ]
                )
                envPool
        mUpdated <- liftIO $ runSqlPool (getEntity lineKey) envPool
        maybe
            (throwError err500{errBody = "Could not update budget line"})
            (pure . budgetLineEntityToDTO eventKey (Just actualCents))
            mUpdated

    -- Finance
    financeServer :: ServerT FinanceRoutes AppM
    financeServer =
        listFinanceEntries
            :<|> createFinanceEntry
            :<|> updateFinanceEntry
            :<|> getFinanceSummary

    listFinanceEntries :: T.Text -> Maybe T.Text -> Maybe T.Text -> Maybe T.Text -> AppM [EventFinanceEntryDTO]
    listFinanceEntries eventIdStr mDirection mSource mStatus = do
        Env{..} <- ask
        (eventKey, _) <- requireManagedEvent eventIdStr
        directionFilter <- normalizeFinanceDirectionFilter mDirection
        sourceFilter <- normalizeFinanceSourceFilter mSource
        statusFilter <- normalizeFinanceEntryStatusFilter mStatus
        manualRows <-
            liftIO $
                runSqlPool
                    (selectList [EventFinanceEntryEventId ==. eventKey] [Desc EventFinanceEntryOccurredAt, Desc EventFinanceEntryId])
                    envPool
        ticketOrders <-
            liftIO $
                runSqlPool
                    (selectList [EventTicketOrderEventId ==. eventKey] [Desc EventTicketOrderPurchasedAt, Desc EventTicketOrderId])
                    envPool
        manualDtos <-
            either
                (throwError . financeInvariantServerError)
                pure
                (traverse financeEntryEntityToDTOEither manualRows)
        ticketDtos <-
            either
                (throwError . financeInvariantServerError)
                pure
                (fmap concat (traverse (ticketOrderAccountingEntriesEither eventKey) ticketOrders))
        let merged = manualDtos ++ ticketDtos
            filtered = filter (matchesFinanceFilters directionFilter sourceFilter statusFilter) merged
        pure (sortOn (Down . efeOccurredAt) filtered)

    createFinanceEntry :: T.Text -> EventFinanceEntryDTO -> AppM EventFinanceEntryDTO
    createFinanceEntry eventIdStr dto = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        (eventKey, eventRec) <- requireManagedEvent eventIdStr
        directionVal <- normalizeFinanceDirectionInput (efeDirection dto)
        sourceVal <- normalizeFinanceSourceInput (efeSource dto)
        statusVal <- normalizeFinanceEntryStatusInput (efeStatus dto)
        when (sourceVal `elem` ["ticket_sale", "ticket_refund"]) $
            throwError err400{errBody = "ticket_sale and ticket_refund entries are generated from ticket orders"}
        (eventCurrencyVal, _) <-
            either
                (throwError . storedEventMetadataServerError)
                pure
                (validateStoredEventFinanceMetadata (defaultCurrency envConfig) eventRec)
        let categoryVal = normalizeCategory (Just (efeCategory dto))
            conceptVal = T.strip (efeConcept dto)
            amountVal = efeAmountCents dto
        currencyVal <-
            either
                throwError
                pure
                (validateFinanceEntryCurrencyInput eventCurrencyVal (efeCurrency dto))
        when (T.null conceptVal) $ throwError err400{errBody = "concept is required"}
        when (amountVal <= 0) $ throwError err400{errBody = "amountCents must be greater than 0"}
        budgetLineKey <- resolveBudgetLineKey envPool eventKey (efeBudgetLineId dto)
        entryKey <-
            liftIO $
                runSqlPool
                    ( insert
                        EventFinanceEntry
                            { eventFinanceEntryEventId = eventKey
                            , eventFinanceEntryBudgetLineId = budgetLineKey
                            , eventFinanceEntryDirection = directionVal
                            , eventFinanceEntrySource = sourceVal
                            , eventFinanceEntryCategory = categoryVal
                            , eventFinanceEntryConcept = conceptVal
                            , eventFinanceEntryAmountCents = amountVal
                            , eventFinanceEntryCurrency = currencyVal
                            , eventFinanceEntryStatus = statusVal
                            , eventFinanceEntryExternalRef = cleanMaybeText (efeExternalRef dto)
                            , eventFinanceEntryNotes = cleanMaybeText (efeNotes dto)
                            , eventFinanceEntryMetadata = Nothing
                            , eventFinanceEntryOccurredAt = efeOccurredAt dto
                            , eventFinanceEntryRecordedByPartyId = Just currentPartyId
                            , eventFinanceEntryCreatedAt = now
                            , eventFinanceEntryUpdatedAt = now
                            }
                    )
                    envPool
        mCreated <- liftIO $ runSqlPool (getEntity entryKey) envPool
        created <- maybe (throwError err500{errBody = "Could not create finance entry"}) pure mCreated
        either (throwError . financeInvariantServerError) pure (financeEntryEntityToDTOEither created)

    updateFinanceEntry :: T.Text -> T.Text -> EventFinanceEntryDTO -> AppM EventFinanceEntryDTO
    updateFinanceEntry eventIdStr entryIdStr dto = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        (eventKey, eventRec) <- requireManagedEvent eventIdStr
        entryKey <- parseKeyOr400 "finance entry" entryIdStr
        mExisting <- liftIO $ runSqlPool (get entryKey) envPool
        existing <- maybe (throwError err404{errBody = "Finance entry not found"}) pure mExisting
        when (eventFinanceEntryEventId existing /= eventKey) $ throwError err400{errBody = "Finance entry does not belong to this event"}
        directionVal <- normalizeFinanceDirectionInput (efeDirection dto)
        sourceVal <- normalizeFinanceSourceInput (efeSource dto)
        statusVal <- normalizeFinanceEntryStatusInput (efeStatus dto)
        when (sourceVal `elem` ["ticket_sale", "ticket_refund"]) $
            throwError err400{errBody = "ticket_sale and ticket_refund entries are generated from ticket orders"}
        (eventCurrencyVal, _) <-
            either
                (throwError . storedEventMetadataServerError)
                pure
                (validateStoredEventFinanceMetadata (defaultCurrency envConfig) eventRec)
        let categoryVal = normalizeCategory (Just (efeCategory dto))
            conceptVal = T.strip (efeConcept dto)
            amountVal = efeAmountCents dto
        currencyVal <-
            either
                throwError
                pure
                (validateFinanceEntryCurrencyInput eventCurrencyVal (efeCurrency dto))
        when (T.null conceptVal) $ throwError err400{errBody = "concept is required"}
        when (amountVal <= 0) $ throwError err400{errBody = "amountCents must be greater than 0"}
        budgetLineKey <- resolveBudgetLineKey envPool eventKey (efeBudgetLineId dto)
        liftIO $
            runSqlPool
                ( update
                    entryKey
                    [ EventFinanceEntryBudgetLineId =. budgetLineKey
                    , EventFinanceEntryDirection =. directionVal
                    , EventFinanceEntrySource =. sourceVal
                    , EventFinanceEntryCategory =. categoryVal
                    , EventFinanceEntryConcept =. conceptVal
                    , EventFinanceEntryAmountCents =. amountVal
                    , EventFinanceEntryCurrency =. currencyVal
                    , EventFinanceEntryStatus =. statusVal
                    , EventFinanceEntryExternalRef =. cleanMaybeText (efeExternalRef dto)
                    , EventFinanceEntryNotes =. cleanMaybeText (efeNotes dto)
                    , EventFinanceEntryOccurredAt =. efeOccurredAt dto
                    , EventFinanceEntryRecordedByPartyId =. Just currentPartyId
                    , EventFinanceEntryUpdatedAt =. now
                    ]
                )
                envPool
        mUpdated <- liftIO $ runSqlPool (getEntity entryKey) envPool
        updated <- maybe (throwError err500{errBody = "Could not update finance entry"}) pure mUpdated
        either (throwError . financeInvariantServerError) pure (financeEntryEntityToDTOEither updated)

    getFinanceSummary :: T.Text -> AppM EventFinanceSummaryDTO
    getFinanceSummary eventIdStr = do
        Env{..} <- ask
        now <- liftIO getCurrentTime
        (eventKey, eventRec) <- requireManagedEvent eventIdStr
        (eventCurrencyVal, budgetOverride) <-
            either
                (throwError . storedEventMetadataServerError)
                pure
                (validateStoredEventFinanceMetadata (defaultCurrency envConfig) eventRec)
        budgetRows <- liftIO $ runSqlPool (selectList [EventBudgetLineEventId ==. eventKey] []) envPool
        allFinanceRows <-
            liftIO $
                runSqlPool
                    (selectList [EventFinanceEntryEventId ==. eventKey] [])
                    envPool
        ticketOrders <- liftIO $ runSqlPool (selectList [EventTicketOrderEventId ==. eventKey] []) envPool
        normalizedBudgetRows <-
            either
                (throwError . financeInvariantServerError)
                pure
                (traverse storedBudgetLineSummaryFields budgetRows)
        normalizedFinanceRows <-
            either
                (throwError . financeInvariantServerError)
                pure
                (traverse storedFinanceEntrySummaryFields allFinanceRows)
        captured <- liftIO $ runSqlPool (TicketRefund.capturedTicketRevenue eventKey eventCurrencyVal) envPool
        let capturedIds = Set.fromList [key | (key,_,_) <- captured]
            canonicalGross = sum [toInteger paid | (_,paid,_) <- captured]
            canonicalRefunded = sum [toInteger refunded | (_,_,refunded) <- captured]
        when (canonicalGross > toInteger (maxBound :: Int) || canonicalRefunded > toInteger (maxBound :: Int)) $
            throwError err500 {errBody="Event ticket revenue exceeds the supported reporting range"}
        normalizedTicketOrders <-
            either
                (throwError . financeInvariantServerError)
                pure
                (traverse storedTicketOrderSummaryFields (filter (\(Entity key _) -> key `Set.notMember` capturedIds) ticketOrders))

        let plannedIncomeCents =
                sum
                    [ toInteger plannedCents
                    | (plannedCents, lineTypeVal) <- normalizedBudgetRows
                    , lineTypeVal == "income"
                    ]
            plannedExpenseCents =
                sum
                    [ toInteger plannedCents
                    | (plannedCents, lineTypeVal) <- normalizedBudgetRows
                    , lineTypeVal == "expense"
                    ]
            entryAmount (amountCents, _, _, _) = toInteger amountCents
            entryDirection (_, directionVal, _, _) = directionVal
            entrySource (_, _, sourceVal, _) = sourceVal
            entryStatus (_, _, _, statusVal) = statusVal
            isPosted entry = entryStatus entry == "posted"
            isPendingLike entry =
                let statusVal = entryStatus entry
                 in statusVal == "pending" || statusVal == "draft"
            isNonVoid entry = entryStatus entry /= "void"
            manualIncomeCents =
                sum
                    [ entryAmount entry
                    | entry <- normalizedFinanceRows
                    , isPosted entry
                    , entryDirection entry == "income"
                    ]
            manualExpenseCents =
                sum
                    [ entryAmount entry
                    | entry <- normalizedFinanceRows
                    , isPosted entry
                    , entryDirection entry == "expense"
                    ]
            ticketPaidRevenueCents =
                canonicalGross + sum
                    [ toInteger amountCents
                    | (amountCents, statusVal) <- normalizedTicketOrders
                    , statusVal == "paid"
                    ]
            ticketRefundedRevenueCents =
                canonicalRefunded + sum
                    [ toInteger amountCents
                    | (amountCents, statusVal) <- normalizedTicketOrders
                    , statusVal == "refunded"
                    ]
            ticketPendingRevenueCents =
                sum
                    [ toInteger amountCents
                    | (amountCents, statusVal) <- normalizedTicketOrders
                    , statusVal == "pending"
                    ]
            accountsPayableCents =
                sum
                    [ entryAmount entry
                    | entry <- normalizedFinanceRows
                    , isPendingLike entry
                    , entryDirection entry == "expense"
                    ]
            accountsReceivableManualCents =
                sum
                    [ entryAmount entry
                    | entry <- normalizedFinanceRows
                    , isPendingLike entry
                    , entryDirection entry == "income"
                    ]
            accountsReceivableCents = accountsReceivableManualCents + ticketPendingRevenueCents
            contractCommittedCents =
                sum
                    [ entryAmount entry
                    | entry <- normalizedFinanceRows
                    , isNonVoid entry
                    , entrySource entry == "contract_commitment"
                    ]
            contractPaidCents =
                sum
                    [ entryAmount entry
                    | entry <- normalizedFinanceRows
                    , isPosted entry
                    , entrySource entry == "contract_payment"
                    ]
            procurementCommittedCents =
                sum
                    [ entryAmount entry
                    | entry <- normalizedFinanceRows
                    , isNonVoid entry
                    , entrySource entry == "purchase_order"
                    ]
            procurementPaidCents =
                sum
                    [ entryAmount entry
                    | entry <- normalizedFinanceRows
                    , isPosted entry
                    , entrySource entry == "purchase_payment"
                    ]
            assetInvestmentCents =
                sum
                    [ entryAmount entry
                    | entry <- normalizedFinanceRows
                    , isPosted entry
                    , entrySource entry == "asset_purchase"
                    ]
            liabilityIncurredCents =
                sum
                    [ entryAmount entry
                    | entry <- normalizedFinanceRows
                    , isPosted entry
                    , entrySource entry == "liability_loan"
                    , entryDirection entry == "income"
                    ]
            liabilityPaidCents =
                sum
                    [ entryAmount entry
                    | entry <- normalizedFinanceRows
                    , isPosted entry
                    , entrySource entry == "liability_payment"
                    , entryDirection entry == "expense"
                    ]
            liabilityBalanceCents = liabilityIncurredCents - liabilityPaidCents
            actualIncomeCents = manualIncomeCents + ticketPaidRevenueCents
            actualExpenseCents = manualExpenseCents + ticketRefundedRevenueCents
            netCents = actualIncomeCents - actualExpenseCents
            budgetCentsVal = fmap toInteger budgetOverride <|> fallbackBudget plannedExpenseCents
            budgetVarianceCents = fmap (\budgetCap -> budgetCap - actualExpenseCents) budgetCentsVal
            budgetUtilizationPct =
                case budgetCentsVal of
                    Just budgetCap
                        | budgetCap > 0 ->
                            Just ((fromIntegral actualExpenseCents / fromIntegral budgetCap) * 100)
                    _ -> Nothing

        -- All sums and differences above are Integer. Validate every monetary
        -- output before constructing the bounded DTO; no wrapped value is sent.
        forM_ (
            [ plannedIncomeCents, plannedExpenseCents, actualIncomeCents, actualExpenseCents
            , netCents, ticketPaidRevenueCents, ticketRefundedRevenueCents, ticketPendingRevenueCents
            , accountsPayableCents, accountsReceivableCents, contractCommittedCents, contractPaidCents
            , procurementCommittedCents, procurementPaidCents, assetInvestmentCents, liabilityBalanceCents
            ]
            ++ maybe [] pure budgetCentsVal
            ++ maybe [] pure budgetVarianceCents
            ) checkedEventFinanceCents

        pure
            EventFinanceSummaryDTO
                { efsEventId = renderKeyText eventKey
                , efsCurrency = eventCurrencyVal
                , efsBudgetCents = fmap fromInteger budgetCentsVal
                , efsPlannedIncomeCents = fromInteger plannedIncomeCents
                , efsPlannedExpenseCents = fromInteger plannedExpenseCents
                , efsActualIncomeCents = fromInteger actualIncomeCents
                , efsActualExpenseCents = fromInteger actualExpenseCents
                , efsNetCents = fromInteger netCents
                , efsTicketPaidRevenueCents = fromInteger ticketPaidRevenueCents
                , efsTicketRefundedRevenueCents = fromInteger ticketRefundedRevenueCents
                , efsTicketPendingRevenueCents = fromInteger ticketPendingRevenueCents
                , efsAccountsPayableCents = fromInteger accountsPayableCents
                , efsAccountsReceivableCents = fromInteger accountsReceivableCents
                , efsContractCommittedCents = fromInteger contractCommittedCents
                , efsContractPaidCents = fromInteger contractPaidCents
                , efsProcurementCommittedCents = fromInteger procurementCommittedCents
                , efsProcurementPaidCents = fromInteger procurementPaidCents
                , efsAssetInvestmentCents = fromInteger assetInvestmentCents
                , efsLiabilityBalanceCents = fromInteger liabilityBalanceCents
                , efsBudgetVarianceCents = fmap fromInteger budgetVarianceCents
                , efsBudgetUtilizationPct = budgetUtilizationPct
                , efsGeneratedAt = now
                }

    -- Event logistics
    logisticsServer :: ServerT LogisticsRoutes AppM
    logisticsServer eventIdStr =
        getLogisticsPlan eventIdStr
            :<|> updateLogisticsSettings eventIdStr
            :<|> createLogisticsMember eventIdStr
            :<|> updateLogisticsMember eventIdStr
            :<|> deleteLogisticsMember eventIdStr
            :<|> createLogisticsPlace eventIdStr
            :<|> updateLogisticsPlace eventIdStr
            :<|> deleteLogisticsPlace eventIdStr
            :<|> createLogisticsActivity eventIdStr
            :<|> updateLogisticsActivity eventIdStr
            :<|> deleteLogisticsActivity eventIdStr
            :<|> verifyLogisticsRoute eventIdStr
            :<|> verifyAllLogisticsRoutes eventIdStr

    getLogisticsPlan :: T.Text -> AppM EventLogisticsPlanDTO
    getLogisticsPlan eventIdStr = do
        Env{..} <- ask
        (eventKey, _, accessRole) <- requireLogisticsAccess eventIdStr False
        settings <- loadLogisticsSettings (defaultTimezone envConfig) envPool eventKey
        memberRows <- liftIO $ runSqlPool (selectList [EventLogisticsMemberEventId ==. eventKey] [Asc EventLogisticsMemberCreatedAt]) envPool
        members <- mapM (logisticsMemberEntityToDTO envPool) memberRows
        placeRows <- liftIO $ runSqlPool (selectList [EventLogisticsPlaceEventId ==. eventKey] [Asc EventLogisticsPlaceLabel]) envPool
        activityRows <- liftIO $ runSqlPool (selectList [EventLogisticsActivityEventId ==. eventKey] [Asc EventLogisticsActivityStartTime, Asc EventLogisticsActivityId]) envPool
        activities <- mapM (logisticsActivityEntityToDTO envPool) activityRows
        pure
            EventLogisticsPlanDTO
                { elgEventId = renderKeyText eventKey
                , elgAccessRole = accessRole
                , elgSettings = settings
                , elgMembers = members
                , elgPlaces = map logisticsPlaceEntityToDTO placeRows
                , elgActivities = activities
                , elgIssues = buildLogisticsIssues activities
                }

    updateLogisticsSettings :: T.Text -> EventLogisticsSettingsDTO -> AppM EventLogisticsSettingsDTO
    updateLogisticsSettings eventIdStr dto = do
        Env{..} <- ask
        (eventKey, _, _) <- requireLogisticsOwner eventIdStr
        now <- liftIO getCurrentTime
        timezoneVal <- validateLogisticsTimezone (elsTimezone dto)
        modeVal <- validateLogisticsTravelMode (elsDefaultTravelMode dto)
        mExisting <- liftIO $ runSqlPool (getBy (UniqueEventLogisticsPlan eventKey)) envPool
        liftIO $ runSqlPool
            (case mExisting of
                Nothing -> insert_ EventLogisticsPlan
                    { eventLogisticsPlanEventId = eventKey
                    , eventLogisticsPlanTimezone = timezoneVal
                    , eventLogisticsPlanDefaultTravelMode = modeVal
                    , eventLogisticsPlanCreatedAt = now
                    , eventLogisticsPlanUpdatedAt = now
                    }
                Just (Entity planKey _) -> update planKey
                    [ EventLogisticsPlanTimezone =. timezoneVal
                    , EventLogisticsPlanDefaultTravelMode =. modeVal
                    , EventLogisticsPlanUpdatedAt =. now
                    ]) envPool
        pure EventLogisticsSettingsDTO{elsTimezone = timezoneVal, elsDefaultTravelMode = modeVal}

    createLogisticsMember :: T.Text -> EventLogisticsMemberDTO -> AppM EventLogisticsMemberDTO
    createLogisticsMember eventIdStr dto = do
        Env{..} <- ask
        (eventKey, _, _) <- requireLogisticsOwner eventIdStr
        partyIdVal <- validateLogisticsParty envPool (elmPartyId dto)
        roleVal <- validateLogisticsMemberRole (elmRole dto)
        now <- liftIO getCurrentTime
        inserted <- liftIO $ runSqlPool
            (insertUnique EventLogisticsMember
                { eventLogisticsMemberEventId = eventKey
                , eventLogisticsMemberPartyId = partyIdVal
                , eventLogisticsMemberMemberRole = roleVal
                , eventLogisticsMemberCreatedAt = now
                , eventLogisticsMemberUpdatedAt = now
                }) envPool
        memberKey <- maybe (throwError err409{errBody = "This person is already on the logistics team"}) pure inserted
        mCreated <- liftIO $ runSqlPool (getEntity memberKey) envPool
        maybe (throwError err500{errBody = "Could not create logistics member"}) (logisticsMemberEntityToDTO envPool) mCreated

    updateLogisticsMember :: T.Text -> T.Text -> EventLogisticsMemberDTO -> AppM EventLogisticsMemberDTO
    updateLogisticsMember eventIdStr rawPartyId dto = do
        Env{..} <- ask
        (eventKey, _, _) <- requireLogisticsOwner eventIdStr
        partyIdVal <- validateLogisticsParty envPool rawPartyId
        when (T.strip (elmPartyId dto) /= partyIdVal) $ throwError err400{errBody = "member party id does not match URL"}
        roleVal <- validateLogisticsMemberRole (elmRole dto)
        now <- liftIO getCurrentTime
        mMember <- liftIO $ runSqlPool (getBy (UniqueEventLogisticsMember eventKey partyIdVal)) envPool
        (memberKey, memberRow) <- maybe (throwError err404{errBody = "Logistics member not found"}) (pure . (\(Entity k v) -> (k, v))) mMember
        liftIO $ runSqlPool (update memberKey [EventLogisticsMemberMemberRole =. roleVal, EventLogisticsMemberUpdatedAt =. now]) envPool
        logisticsMemberEntityToDTO envPool (Entity memberKey memberRow{eventLogisticsMemberMemberRole = roleVal, eventLogisticsMemberUpdatedAt = now})

    deleteLogisticsMember :: T.Text -> T.Text -> AppM NoContent
    deleteLogisticsMember eventIdStr rawPartyId = do
        Env{..} <- ask
        (eventKey, _, _) <- requireLogisticsOwner eventIdStr
        partyIdVal <- pure (T.strip rawPartyId)
        liftIO $ runSqlPool (deleteBy (UniqueEventLogisticsMember eventKey partyIdVal)) envPool
        pure NoContent

    createLogisticsPlace :: T.Text -> EventLogisticsPlaceDTO -> AppM EventLogisticsPlaceDTO
    createLogisticsPlace eventIdStr dto = do
        Env{..} <- ask
        (eventKey, _, _) <- requireLogisticsAccess eventIdStr True
        now <- liftIO getCurrentTime
        (labelVal, typeVal, venueKey) <- validateLogisticsPlaceInput envPool eventKey dto
        key <- liftIO $ runSqlPool
            (insert EventLogisticsPlace
                { eventLogisticsPlaceEventId = eventKey
                , eventLogisticsPlaceVenueId = venueKey
                , eventLogisticsPlaceLabel = labelVal
                , eventLogisticsPlacePlaceType = typeVal
                , eventLogisticsPlaceAddress = cleanMaybeText (elpAddress dto)
                , eventLogisticsPlaceGooglePlaceId = cleanMaybeText (elpGooglePlaceId dto)
                , eventLogisticsPlaceLatitude = elpLatitude dto
                , eventLogisticsPlaceLongitude = elpLongitude dto
                , eventLogisticsPlaceInstructions = cleanMaybeText (elpInstructions dto)
                , eventLogisticsPlaceContactName = cleanMaybeText (elpContactName dto)
                , eventLogisticsPlaceContactPhone = cleanMaybeText (elpContactPhone dto)
                , eventLogisticsPlaceCreatedAt = now
                , eventLogisticsPlaceUpdatedAt = now
                }) envPool
        mCreated <- liftIO $ runSqlPool (getEntity key) envPool
        maybe (throwError err500{errBody = "Could not create logistics place"}) (pure . logisticsPlaceEntityToDTO) mCreated

    updateLogisticsPlace :: T.Text -> T.Text -> EventLogisticsPlaceDTO -> AppM EventLogisticsPlaceDTO
    updateLogisticsPlace eventIdStr placeIdStr dto = do
        Env{..} <- ask
        (eventKey, _, _) <- requireLogisticsAccess eventIdStr True
        placeKey <- parseKeyOr400 "logistics place" placeIdStr
        existing <- requireLogisticsPlace envPool eventKey placeKey
        now <- liftIO getCurrentTime
        (labelVal, typeVal, venueKey) <- validateLogisticsPlaceInput envPool eventKey dto
        liftIO $ runSqlPool (update placeKey
            [ EventLogisticsPlaceVenueId =. venueKey
            , EventLogisticsPlaceLabel =. labelVal
            , EventLogisticsPlacePlaceType =. typeVal
            , EventLogisticsPlaceAddress =. cleanMaybeText (elpAddress dto)
            , EventLogisticsPlaceGooglePlaceId =. cleanMaybeText (elpGooglePlaceId dto)
            , EventLogisticsPlaceLatitude =. elpLatitude dto
            , EventLogisticsPlaceLongitude =. elpLongitude dto
            , EventLogisticsPlaceInstructions =. cleanMaybeText (elpInstructions dto)
            , EventLogisticsPlaceContactName =. cleanMaybeText (elpContactName dto)
            , EventLogisticsPlaceContactPhone =. cleanMaybeText (elpContactPhone dto)
            , EventLogisticsPlaceUpdatedAt =. now
            ]) envPool
        pure $ logisticsPlaceEntityToDTO (Entity placeKey existing
            { eventLogisticsPlaceVenueId = venueKey
            , eventLogisticsPlaceLabel = labelVal
            , eventLogisticsPlacePlaceType = typeVal
            , eventLogisticsPlaceAddress = cleanMaybeText (elpAddress dto)
            , eventLogisticsPlaceGooglePlaceId = cleanMaybeText (elpGooglePlaceId dto)
            , eventLogisticsPlaceLatitude = elpLatitude dto
            , eventLogisticsPlaceLongitude = elpLongitude dto
            , eventLogisticsPlaceInstructions = cleanMaybeText (elpInstructions dto)
            , eventLogisticsPlaceContactName = cleanMaybeText (elpContactName dto)
            , eventLogisticsPlaceContactPhone = cleanMaybeText (elpContactPhone dto)
            , eventLogisticsPlaceUpdatedAt = now
            })

    deleteLogisticsPlace :: T.Text -> T.Text -> AppM NoContent
    deleteLogisticsPlace eventIdStr placeIdStr = do
        Env{..} <- ask
        (eventKey, _, _) <- requireLogisticsAccess eventIdStr True
        placeKey <- parseKeyOr400 "logistics place" placeIdStr
        _ <- requireLogisticsPlace envPool eventKey placeKey
        referenceCount <- liftIO $ runSqlPool (count
            [ FilterOr
                [ EventLogisticsActivityPlaceId ==. Just placeKey
                , EventLogisticsActivityOriginPlaceId ==. Just placeKey
                , EventLogisticsActivityDestinationPlaceId ==. Just placeKey
                ]
            ]) envPool
        when (referenceCount > 0) $ throwError err409{errBody = "Place is used by one or more logistics activities"}
        liftIO $ runSqlPool (delete placeKey) envPool
        pure NoContent

    createLogisticsActivity :: T.Text -> EventLogisticsActivityDTO -> AppM EventLogisticsActivityDTO
    createLogisticsActivity eventIdStr dto = do
        Env{..} <- ask
        (eventKey, _, _) <- requireLogisticsAccess eventIdStr True
        now <- liftIO getCurrentTime
        validated <- validateLogisticsActivityInput envPool eventKey Nothing dto
        let (typeVal, titleVal, endVal, placeKey, originKey, destinationKey, modeVal, bufferVal, priorityVal, statusVal, dependencyKeys) = validated
        modeToStore <- if typeVal == "travel" && isNothing modeVal
            then Just . elsDefaultTravelMode <$>
                loadLogisticsSettings (defaultTimezone envConfig) envPool eventKey
            else pure modeVal
        -- The activity and its dependency/assignment snapshot are one versioned write.
        -- Database DAG guards can therefore reject the whole command without leaving
        -- an activity whose visible relations belong to another state.
        key <- liftIO $ runSqlPool (do
            activityKey <- insert EventLogisticsActivity
                { eventLogisticsActivityEventId = eventKey
                , eventLogisticsActivityActivityType = typeVal
                , eventLogisticsActivityTitle = titleVal
                , eventLogisticsActivityNotes = cleanMaybeText (eacNotes dto)
                , eventLogisticsActivityStartTime = eacStart dto
                , eventLogisticsActivityEndTime = endVal
                , eventLogisticsActivityPlaceId = placeKey
                , eventLogisticsActivityOriginPlaceId = originKey
                , eventLogisticsActivityDestinationPlaceId = destinationKey
                , eventLogisticsActivityTravelMode = modeToStore
                , eventLogisticsActivityBufferMinutes = bufferVal
                , eventLogisticsActivityPriority = priorityVal
                , eventLogisticsActivityStatus = statusVal
                , eventLogisticsActivityVersion = 1
                , eventLogisticsActivityCreatedByPartyId = currentPartyId
                , eventLogisticsActivityCreatedAt = now
                , eventLogisticsActivityUpdatedAt = now
                }
            replaceLogisticsActivityRelations activityKey (eacAssignments dto) dependencyKeys now
            pure activityKey) envPool
        when (typeVal == "travel") $ void (verifyLogisticsActivityInternal envPool envConfig key Nothing)
        mCreated <- liftIO $ runSqlPool (getEntity key) envPool
        maybe (throwError err500{errBody = "Could not create logistics activity"}) (logisticsActivityEntityToDTO envPool) mCreated

    updateLogisticsActivity :: T.Text -> T.Text -> EventLogisticsActivityDTO -> AppM EventLogisticsActivityDTO
    updateLogisticsActivity eventIdStr activityIdStr dto = do
        Env{..} <- ask
        (eventKey, _, _) <- requireLogisticsAccess eventIdStr True
        activityKey <- parseKeyOr400 "logistics activity" activityIdStr
        existing <- requireLogisticsActivity envPool eventKey activityKey
        expectedVersion <- maybe (throwError err400{errBody = "activity version is required"}) pure (eacVersion dto)
        when (expectedVersion /= eventLogisticsActivityVersion existing) $ throwError err409{errBody = "This activity was changed by another collaborator. Reload and try again."}
        validated <- validateLogisticsActivityInput envPool eventKey (Just activityKey) dto
        let (typeVal, titleVal, endVal, placeKey, originKey, destinationKey, modeVal, bufferVal, priorityVal, statusVal, dependencyKeys) = validated
            nextVersion = expectedVersion + 1
        modeToStore <- if typeVal == "travel" && isNothing modeVal
            then Just . elsDefaultTravelMode <$>
                loadLogisticsSettings (defaultTimezone envConfig) envPool eventKey
            else pure modeVal
        now <- liftIO getCurrentTime
        -- Keep the optimistic compare-and-swap and relation replacement in the same
        -- transaction. A concurrent version loss or relation constraint failure
        -- leaves both the activity row and its prior relations unchanged.
        updatedRows <- liftIO $ runSqlPool (do
            rowCount <- updateWhereCount
                [ EventLogisticsActivityId ==. activityKey
                , EventLogisticsActivityVersion ==. expectedVersion
                ]
                [ EventLogisticsActivityActivityType =. typeVal
                , EventLogisticsActivityTitle =. titleVal
                , EventLogisticsActivityNotes =. cleanMaybeText (eacNotes dto)
                , EventLogisticsActivityStartTime =. eacStart dto
                , EventLogisticsActivityEndTime =. endVal
                , EventLogisticsActivityPlaceId =. placeKey
                , EventLogisticsActivityOriginPlaceId =. originKey
                , EventLogisticsActivityDestinationPlaceId =. destinationKey
                , EventLogisticsActivityTravelMode =. modeToStore
                , EventLogisticsActivityBufferMinutes =. bufferVal
                , EventLogisticsActivityPriority =. priorityVal
                , EventLogisticsActivityStatus =. statusVal
                , EventLogisticsActivityVersion =. nextVersion
                , EventLogisticsActivityUpdatedAt =. now
                ]
            when (rowCount > 0) $
                replaceLogisticsActivityRelations activityKey (eacAssignments dto) dependencyKeys now
            pure rowCount) envPool
        when (updatedRows == 0) $ throwError err409{errBody = "This activity was changed by another collaborator. Reload and try again."}
        when (typeVal == "travel") $ void (verifyLogisticsActivityInternal envPool envConfig activityKey Nothing)
        mUpdated <- liftIO $ runSqlPool (getEntity activityKey) envPool
        maybe (throwError err500{errBody = "Could not update logistics activity"}) (logisticsActivityEntityToDTO envPool) mUpdated

    deleteLogisticsActivity :: T.Text -> T.Text -> AppM NoContent
    deleteLogisticsActivity eventIdStr activityIdStr = do
        Env{..} <- ask
        (eventKey, _, _) <- requireLogisticsAccess eventIdStr True
        activityKey <- parseKeyOr400 "logistics activity" activityIdStr
        _ <- requireLogisticsActivity envPool eventKey activityKey
        liftIO $ runSqlPool (do
            -- Opt-in foundation guards must inspect incoming edges before this
            -- legacy cleanup removes them. Keep its event fence through commit.
            backendName <- T.toCaseFold <$> getRDBMS
            when ("postgres" `T.isInfixOf` backendName) $ do
                installed <- (rawSql
                    "SELECT to_regprocedure('event_operation_assert_task_deletable(bigint)') IS NOT NULL AND EXISTS (SELECT 1 FROM pg_trigger WHERE tgrelid = 'event_logistics_activity'::regclass AND tgname = 'event_operation_00_task_lock' AND tgenabled <> 'D')"
                    [] :: SqlPersistT IO [Single Bool])
                when (installed == [Single True]) $ do
                    _ <- (rawSql "SELECT event_operation_assert_task_deletable(?) IS NULL"
                        [toPersistValue activityKey] :: SqlPersistT IO [Single Bool])
                    pure ()
            deleteWhere [EventLogisticsAlertDeliveryActivityId ==. activityKey]
            deleteWhere [EventRouteVerificationActivityId ==. activityKey]
            deleteWhere [EventLogisticsAssignmentActivityId ==. activityKey]
            deleteWhere [FilterOr [EventLogisticsDependencyActivityId ==. activityKey, EventLogisticsDependencyDependsOnActivityId ==. activityKey]]
            delete activityKey) envPool
        pure NoContent

    verifyLogisticsRoute :: T.Text -> T.Text -> AppM EventRouteVerificationDTO
    verifyLogisticsRoute eventIdStr activityIdStr = do
        Env{..} <- ask
        (eventKey, _, _) <- requireLogisticsAccess eventIdStr True
        activityKey <- parseKeyOr400 "logistics activity" activityIdStr
        _ <- requireLogisticsActivity envPool eventKey activityKey
        verifyLogisticsActivityInternal envPool envConfig activityKey Nothing

    verifyAllLogisticsRoutes :: T.Text -> AppM [EventRouteVerificationDTO]
    verifyAllLogisticsRoutes eventIdStr = do
        Env{..} <- ask
        (eventKey, _, _) <- requireLogisticsAccess eventIdStr True
        rows <- liftIO $ runSqlPool (selectList
            [ EventLogisticsActivityEventId ==. eventKey
            , EventLogisticsActivityActivityType ==. "travel"
            , EventLogisticsActivityStatus !=. "cancelled"
            ] [Asc EventLogisticsActivityStartTime]) envPool
        mapM (\(Entity key _) -> verifyLogisticsActivityInternal envPool envConfig key Nothing) rows

    requireLogisticsOwner :: T.Text -> AppM (SocialEventId, SocialEvent, T.Text)
    requireLogisticsOwner rawEventId = do
        result@(_, _, role) <- requireLogisticsAccess rawEventId False
        when (role /= "owner") $ throwError err403{errBody = "Only the event organizer can manage the logistics team and settings"}
        pure result

    requireLogisticsAccess :: T.Text -> Bool -> AppM (SocialEventId, SocialEvent, T.Text)
    requireLogisticsAccess rawEventId requireEdit = do
        Env{..} <- ask
        eventKey <- parseVisibleEventKey rawEventId
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        eventRow <- maybe (throwError err404{errBody = "Event not found"}) pure mEvent
        role <- case cleanMaybeText (socialEventOrganizerPartyId eventRow) of
            Just owner | owner == currentPartyId -> pure "owner"
            -- With no organizer the event has no owner role to hand out;
            -- only its recorded logistics team keeps access.
            _ -> do
                mMember <- liftIO $ runSqlPool (getBy (UniqueEventLogisticsMember eventKey currentPartyId)) envPool
                maybe (throwError err403{errBody = "You are not on this event's logistics team"}) (pure . eventLogisticsMemberMemberRole . entityVal) mMember
        when (requireEdit && role == "viewer") $ throwError err403{errBody = "This logistics team role is read-only"}
        pure (eventKey, eventRow, role)

    validateLogisticsPlaceInput :: ConnectionPool -> SocialEventId -> EventLogisticsPlaceDTO -> AppM (T.Text, T.Text, Maybe VenueId)
    validateLogisticsPlaceInput pool _eventKey dto = do
        let labelVal = T.strip (elpLabel dto)
            typeVal = T.toCaseFold (T.strip (elpType dto))
        when (T.null labelVal || T.length labelVal > 160) $ throwError err400{errBody = "place label is required and must be 160 characters or fewer"}
        unless (typeVal `elem` ["venue", "hotel", "airport", "pickup", "custom"]) $ throwError err400{errBody = "invalid logistics place type"}
        validateFiniteCoordinates (elpLatitude dto) (elpLongitude dto)
        venueKey <- case elpVenueId dto >>= cleanMaybeText . Just of
            Nothing -> pure Nothing
            Just raw -> do
                key <- parseKeyOr400 "venue" raw
                mVenue <- liftIO $ runSqlPool (get key) pool
                when (isNothing mVenue) $ throwError err400{errBody = "venue does not exist"}
                pure (Just key)
        pure (labelVal, typeVal, venueKey)

    validateLogisticsActivityInput :: ConnectionPool -> SocialEventId -> Maybe EventLogisticsActivityId -> EventLogisticsActivityDTO -> AppM (T.Text, T.Text, Maybe UTCTime, Maybe EventLogisticsPlaceId, Maybe EventLogisticsPlaceId, Maybe EventLogisticsPlaceId, Maybe T.Text, Maybe Int, T.Text, T.Text, [EventLogisticsActivityId])
    validateLogisticsActivityInput pool eventKey mActivityKey dto = do
        let typeVal = T.toCaseFold (T.strip (eacType dto))
            titleVal = T.strip (eacTitle dto)
            priorityVal = T.toCaseFold (T.strip (eacPriority dto))
            statusVal = T.toCaseFold (T.strip (eacStatus dto))
        unless (typeVal `elem` ["task", "milestone", "wait", "travel"]) $ throwError err400{errBody = "invalid logistics activity type"}
        when (T.null titleVal || T.length titleVal > 200) $ throwError err400{errBody = "activity title is required and must be 200 characters or fewer"}
        unless (priorityVal `elem` ["low", "normal", "high", "critical"]) $ throwError err400{errBody = "invalid logistics priority"}
        unless (statusVal `elem` ["planned", "confirmed", "in_progress", "completed", "cancelled"]) $ throwError err400{errBody = "invalid logistics status"}
        endVal <- if typeVal == "milestone"
            then pure Nothing
            else case eacEnd dto of
                Just value | value > eacStart dto -> pure (Just value)
                _ -> throwError err400{errBody = "non-milestone activities require an end after the start"}
        placeKey <- traverse (requirePlaceReference pool eventKey) (eacPlaceId dto >>= cleanMaybeText . Just)
        originKey <- traverse (requirePlaceReference pool eventKey) (eacOriginPlaceId dto >>= cleanMaybeText . Just)
        destinationKey <- traverse (requirePlaceReference pool eventKey) (eacDestinationPlaceId dto >>= cleanMaybeText . Just)
        modeVal <- traverse validateLogisticsTravelMode (eacTravelMode dto >>= cleanMaybeText . Just)
        when (typeVal == "travel" && (isNothing originKey || isNothing destinationKey)) $ throwError err400{errBody = "travel activities require origin and destination places"}
        when (typeVal == "travel" && originKey == destinationKey) $ throwError err400{errBody = "travel origin and destination must be different"}
        when (typeVal == "travel" && isJust placeKey) $ throwError err400{errBody = "travel activities use origin and destination instead of a single place"}
        when (typeVal /= "travel" && (isJust originKey || isJust destinationKey)) $ throwError err400{errBody = "origin and destination are only valid for travel activities"}
        when (typeVal /= "travel" && isJust modeVal) $ throwError err400{errBody = "travel mode is only valid for travel activities"}
        bufferVal <- case eacBufferMinutes dto of
            Just value | value < 0 || value > 1440 -> throwError err400{errBody = "buffer minutes must be between 0 and 1440"}
            value -> pure value
        dependencyKeys <- mapM (parseKeyOr400 "logistics dependency") (eacDependencyIds dto)
        forM_ dependencyKeys $ \dependencyKey -> do
            when (Just dependencyKey == mActivityKey) $ throwError err400{errBody = "an activity cannot depend on itself"}
            _ <- requireLogisticsActivity pool eventKey dependencyKey
            case mActivityKey of
                Nothing -> pure ()
                Just activityKey -> do
                    cyclic <- liftIO (logisticsDependencyReaches pool dependencyKey activityKey Set.empty)
                    when cyclic $ throwError err400{errBody = "logistics dependencies must not contain cycles"}
        validateLogisticsAssignments pool (eacAssignments dto)
        pure (typeVal, titleVal, endVal, placeKey, originKey, destinationKey, modeVal, bufferVal, priorityVal, statusVal, dependencyKeys)

    replaceLogisticsActivityRelations :: EventLogisticsActivityId -> [EventLogisticsAssignmentDTO] -> [EventLogisticsActivityId] -> UTCTime -> SqlPersistT IO ()
    replaceLogisticsActivityRelations activityKey assignments dependencyKeys now = do
        deleteWhere [EventLogisticsAssignmentActivityId ==. activityKey]
        replaceLogisticsActivityDependencies activityKey dependencyKeys now
        forM_ assignments $ \assignment -> insert_ EventLogisticsAssignment
            { eventLogisticsAssignmentActivityId = activityKey
            , eventLogisticsAssignmentPartyId = cleanMaybeText (elaPartyId assignment)
            , eventLogisticsAssignmentExternalName = cleanMaybeText (elaExternalName assignment)
            , eventLogisticsAssignmentExternalPhone = cleanMaybeText (elaExternalPhone assignment)
            , eventLogisticsAssignmentExternalEmail = cleanMaybeText (elaExternalEmail assignment)
            , eventLogisticsAssignmentCreatedAt = now
            }

    verifyLogisticsActivityInternal :: ConnectionPool -> AppConfig -> EventLogisticsActivityId -> Maybe T.Text -> AppM EventRouteVerificationDTO
    verifyLogisticsActivityInternal pool config activityKey checkpoint = do
        activity <- maybe (throwError err404{errBody = "Logistics activity not found"}) pure =<< liftIO (runSqlPool (get activityKey) pool)
        when (eventLogisticsActivityActivityType activity /= "travel") $ throwError err400{errBody = "Only travel activities can be route-verified"}
        endTime <- maybe (throwError err400{errBody = "Travel activity requires an end time"}) pure (eventLogisticsActivityEndTime activity)
        originKey <- maybe (throwError err400{errBody = "Travel activity requires an origin"}) pure (eventLogisticsActivityOriginPlaceId activity)
        destinationKey <- maybe (throwError err400{errBody = "Travel activity requires a destination"}) pure (eventLogisticsActivityDestinationPlaceId activity)
        origin <- maybe (throwError err400{errBody = "Travel origin no longer exists"}) pure =<< liftIO (runSqlPool (get originKey) pool)
        destination <- maybe (throwError err400{errBody = "Travel destination no longer exists"}) pure =<< liftIO (runSqlPool (get destinationKey) pool)
        let modeVal = fromMaybe "drive" (eventLogisticsActivityTravelMode activity)
            allocatedSeconds = max 0 (floor (diffUTCTime endTime (eventLogisticsActivityStartTime activity)))
            input = RouteEstimateInput
                { reiOriginLatitude = eventLogisticsPlaceLatitude origin
                , reiOriginLongitude = eventLogisticsPlaceLongitude origin
                , reiDestinationLatitude = eventLogisticsPlaceLatitude destination
                , reiDestinationLongitude = eventLogisticsPlaceLongitude destination
                , reiTravelMode = modeVal
                , reiDepartureTime = eventLogisticsActivityStartTime activity
                }
        result <- case googleRoutesApiKey config of
            Nothing -> pure (Left "GOOGLE_ROUTES_API_KEY no está configurada.")
            Just apiKey -> liftIO (computeGoogleRoute apiKey (googleRoutesApiBase config) (defaultLocale config) input)
        now <- liftIO getCurrentTime
        let computed = routeVerificationValues activity allocatedSeconds result
            (durationVal, staticVal, distanceVal, bufferSeconds, verdictVal, polylineVal, errorVal) = computed
        key <- liftIO $ runSqlPool (insert EventRouteVerification
            { eventRouteVerificationActivityId = activityKey
            , eventRouteVerificationActivityVersion = eventLogisticsActivityVersion activity
            , eventRouteVerificationProvider = "google_routes"
            , eventRouteVerificationTravelMode = modeVal
            , eventRouteVerificationDepartureTime = eventLogisticsActivityStartTime activity
            , eventRouteVerificationDurationSeconds = durationVal
            , eventRouteVerificationStaticDurationSeconds = staticVal
            , eventRouteVerificationDistanceMeters = distanceVal
            , eventRouteVerificationBufferSeconds = bufferSeconds
            , eventRouteVerificationAllocatedSeconds = allocatedSeconds
            , eventRouteVerificationVerdict = verdictVal
            , eventRouteVerificationEncodedPolyline = polylineVal
            , eventRouteVerificationErrorMessage = errorVal
            , eventRouteVerificationCheckpoint = checkpoint
            , eventRouteVerificationVerifiedAt = now
            }) pool
        pure EventRouteVerificationDTO
            { ervId = Just (renderKeyText key)
            , ervActivityVersion = eventLogisticsActivityVersion activity
            , ervProvider = "google_routes"
            , ervTravelMode = modeVal
            , ervDepartureTime = eventLogisticsActivityStartTime activity
            , ervDurationSeconds = durationVal
            , ervStaticDurationSeconds = staticVal
            , ervDistanceMeters = distanceVal
            , ervBufferSeconds = bufferSeconds
            , ervAllocatedSeconds = allocatedSeconds
            , ervVerdict = verdictVal
            , ervEncodedPolyline = polylineVal
            , ervErrorMessage = errorVal
            , ervCheckpoint = checkpoint
            , ervVerifiedAt = now
            }

    requireManagedEvent :: T.Text -> AppM (SocialEventId, SocialEvent)
    requireManagedEvent rawEventId = do
        Env{..} <- ask
        eventKey <- parseVisibleEventKey rawEventId
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        eventVal <- maybe (throwError err404{errBody = "Event not found"}) pure mEvent
        claimed <- requireEventManager currentPartyId eventVal
        pure (eventKey, claimed)

    requireRefundManagedEvent :: T.Text -> AppM (SocialEventId, SocialEvent)
    requireRefundManagedEvent rawEventId = do
        Env{..} <- ask
        eventKey <- parseKeyOr400 "event" rawEventId
        mEvent <- liftIO $ runSqlPool (get eventKey) envPool
        eventVal <- maybe (throwError err404{errBody = "Event not found"}) pure mEvent
        if hasStrictAdminAccess user
            then pure (eventKey, eventVal)
            else do
                requireEventVisibleToUser eventKey
                claimed <- requireEventManager currentPartyId eventVal
                pure (eventKey, claimed)

    requireExistingEvent :: ConnectionPool -> SocialEventId -> AppM SocialEvent
    requireExistingEvent pool eventKey = do
        mEvent <- liftIO $ runSqlPool (get eventKey) pool
        maybe (throwError err404{errBody = "Event not found"}) pure mEvent

    requireMomentForEvent :: ConnectionPool -> SocialEventId -> EventMomentId -> AppM EventMoment
    requireMomentForEvent pool eventKey momentKey = do
        mMoment <- liftIO $ runSqlPool (get momentKey) pool
        momentRow <- maybe (throwError err404{errBody = "Moment not found"}) pure mMoment
        when (eventMomentEventId momentRow /= eventKey) $
            throwError err400{errBody = "Moment does not belong to this event"}
        pure momentRow

    requireLiveBroadcastForEvent ::
        ConnectionPool ->
        SocialEventId ->
        EventLiveBroadcastId ->
        AppM EventLiveBroadcast
    requireLiveBroadcastForEvent pool eventKey broadcastKey = do
        mBroadcast <- liftIO $ runSqlPool (get broadcastKey) pool
        broadcastRow <- maybe (throwError err404{errBody = "Live broadcast not found"}) pure mBroadcast
        when (eventLiveBroadcastEventId broadcastRow /= eventKey) $
            throwError err400{errBody = "Live broadcast does not belong to this event"}
        pure broadcastRow

    requireEventArtistProfile ::
        ConnectionPool ->
        SocialEventId ->
        ArtistProfileId ->
        AppM ArtistProfile
    requireEventArtistProfile pool eventKey artistKey = do
        mArtist <- liftIO $ runSqlPool (get artistKey) pool
        artistRow <- maybe (throwError err404{errBody = "Artist not found"}) pure mArtist
        mLineup <- liftIO $ runSqlPool (get (EventArtistKey eventKey artistKey)) pool
        when (isNothing mLineup) $
            throwError err400{errBody = "Artist is not in this event lineup"}
        pure artistRow

    requireArtistFollower :: ConnectionPool -> ArtistProfileId -> T.Text -> AppM ()
    requireArtistFollower pool artistKey partyId = do
        mFollow <- liftIO $ runSqlPool (get (ArtistFollowKey artistKey partyId)) pool
        when (isNothing mFollow) $
            throwError err403{errBody = "Only followers of this artist can start a fanclub live broadcast"}

    parseIds :: T.Text -> T.Text -> AppM (SocialEventId, EventInvitationId)
    parseIds eventIdStr invitationIdStr = do
        case parseInvitationIdsEither eventIdStr invitationIdStr of
            Right ids@(eventKey, _) -> do
                requireEventVisibleToUser eventKey
                pure ids
            Left e -> throwError e

    parseArtistId :: T.Text -> AppM ArtistProfileId
    parseArtistId = parseKeyOr400 "artist"

validateLogisticsTimezone :: T.Text -> AppM T.Text
validateLogisticsTimezone raw =
    let value = T.strip raw
     in if T.null value || T.length value > 80 || T.any isUnsafeSocialEventsListFilterChar value
            then throwError err400{errBody = "timezone is required and must be a valid IANA name"}
            else
                if value /= "UTC" && not ("/" `T.isInfixOf` value)
                    then throwError err400{errBody = "timezone must be UTC or an IANA area/location name"}
                    else pure value

validateLogisticsTravelMode :: T.Text -> AppM T.Text
validateLogisticsTravelMode raw =
    let value = T.toCaseFold (T.strip raw)
     in if value `elem` ["drive", "walk", "bicycle", "two_wheeler", "transit"]
            then pure value
            else throwError err400{errBody = "invalid logistics travel mode"}

validateLogisticsMemberRole :: T.Text -> AppM T.Text
validateLogisticsMemberRole raw =
    let value = T.toCaseFold (T.strip raw)
     in if value `elem` ["viewer", "editor"]
            then pure value
            else throwError err400{errBody = "logistics member role must be viewer or editor"}

validateLogisticsParty :: ConnectionPool -> T.Text -> AppM T.Text
validateLogisticsParty pool rawPartyId = do
    let normalized = T.strip rawPartyId
    partyKey <- parseKeyOr400 "party" normalized :: AppM PartyId
    mParty <- liftIO $ runSqlPool (get partyKey) pool
    when (isNothing mParty) $ throwError err400{errBody = "party does not exist"}
    pure (renderKeyText partyKey)

validateFiniteCoordinates :: Double -> Double -> AppM ()
validateFiniteCoordinates latitude longitude
    | isNaN latitude || isInfinite latitude = throwError err400{errBody = "latitude must be finite"}
    | isNaN longitude || isInfinite longitude = throwError err400{errBody = "longitude must be finite"}
    | latitude < (-90) || latitude > 90 = throwError err400{errBody = "latitude must be between -90 and 90"}
    | longitude < (-180) || longitude > 180 = throwError err400{errBody = "longitude must be between -180 and 180"}
    | otherwise = pure ()

requirePlaceReference :: ConnectionPool -> SocialEventId -> T.Text -> AppM EventLogisticsPlaceId
requirePlaceReference pool eventKey rawPlaceId = do
    placeKey <- parseKeyOr400 "logistics place" rawPlaceId
    _ <- requireLogisticsPlace pool eventKey placeKey
    pure placeKey

requireLogisticsPlace :: ConnectionPool -> SocialEventId -> EventLogisticsPlaceId -> AppM EventLogisticsPlace
requireLogisticsPlace pool eventKey placeKey = do
    row <- maybe (throwError err404{errBody = "Logistics place not found"}) pure =<< liftIO (runSqlPool (get placeKey) pool)
    when (eventLogisticsPlaceEventId row /= eventKey) $ throwError err400{errBody = "Logistics place does not belong to this event"}
    pure row

requireLogisticsActivity :: ConnectionPool -> SocialEventId -> EventLogisticsActivityId -> AppM EventLogisticsActivity
requireLogisticsActivity pool eventKey activityKey = do
    row <- maybe (throwError err404{errBody = "Logistics activity not found"}) pure =<< liftIO (runSqlPool (get activityKey) pool)
    when (eventLogisticsActivityEventId row /= eventKey) $ throwError err400{errBody = "Logistics activity does not belong to this event"}
    pure row

validateLogisticsAssignments :: ConnectionPool -> [EventLogisticsAssignmentDTO] -> AppM ()
validateLogisticsAssignments pool assignments = forM_ assignments $ \assignment -> do
    let partyIdVal = cleanMaybeText (elaPartyId assignment)
        externalNameVal = cleanMaybeText (elaExternalName assignment)
    when (isJust partyIdVal == isJust externalNameVal) $
        throwError err400{errBody = "each assignment must identify either one TDF user or one external person"}
    forM_ partyIdVal $ \partyId -> void (validateLogisticsParty pool partyId)
    forM_ externalNameVal $ \name ->
        when (T.length name > 160) $ throwError err400{errBody = "external assignee name must be 160 characters or fewer"}
    forM_ (cleanMaybeText (elaExternalEmail assignment)) $ \email ->
        when (T.length email > 320 || not ("@" `T.isInfixOf` email)) $
            throwError err400{errBody = "external assignee email is invalid"}

loadLogisticsSettings :: T.Text -> ConnectionPool -> SocialEventId -> AppM EventLogisticsSettingsDTO
loadLogisticsSettings fallbackTimezone pool eventKey = do
    row <- liftIO $ runSqlPool (getBy (UniqueEventLogisticsPlan eventKey)) pool
    pure $ case row of
        Nothing -> EventLogisticsSettingsDTO fallbackTimezone "drive"
        Just (Entity _ value) -> EventLogisticsSettingsDTO
            { elsTimezone = eventLogisticsPlanTimezone value
            , elsDefaultTravelMode = eventLogisticsPlanDefaultTravelMode value
            }

logisticsMemberEntityToDTO :: ConnectionPool -> Entity EventLogisticsMember -> AppM EventLogisticsMemberDTO
logisticsMemberEntityToDTO pool (Entity _ member) = do
    let partyIdVal = eventLogisticsMemberPartyId member
        mPartyKey = fromPathPiece partyIdVal :: Maybe PartyId
    mParty <- case mPartyKey of
        Nothing -> pure Nothing
        Just partyKey -> liftIO $ runSqlPool (get partyKey) pool
    pure EventLogisticsMemberDTO
        { elmPartyId = partyIdVal
        , elmDisplayName = partyDisplayName <$> mParty
        , elmEmail = mParty >>= partyPrimaryEmail
        , elmRole = eventLogisticsMemberMemberRole member
        , elmCreatedAt = Just (eventLogisticsMemberCreatedAt member)
        }

logisticsPlaceEntityToDTO :: Entity EventLogisticsPlace -> EventLogisticsPlaceDTO
logisticsPlaceEntityToDTO (Entity key place) = EventLogisticsPlaceDTO
    { elpId = Just (renderKeyText key)
    , elpVenueId = renderKeyText <$> eventLogisticsPlaceVenueId place
    , elpLabel = eventLogisticsPlaceLabel place
    , elpType = eventLogisticsPlacePlaceType place
    , elpAddress = eventLogisticsPlaceAddress place
    , elpGooglePlaceId = eventLogisticsPlaceGooglePlaceId place
    , elpLatitude = eventLogisticsPlaceLatitude place
    , elpLongitude = eventLogisticsPlaceLongitude place
    , elpInstructions = eventLogisticsPlaceInstructions place
    , elpContactName = eventLogisticsPlaceContactName place
    , elpContactPhone = eventLogisticsPlaceContactPhone place
    , elpCreatedAt = Just (eventLogisticsPlaceCreatedAt place)
    , elpUpdatedAt = Just (eventLogisticsPlaceUpdatedAt place)
    }

logisticsActivityEntityToDTO :: ConnectionPool -> Entity EventLogisticsActivity -> AppM EventLogisticsActivityDTO
logisticsActivityEntityToDTO pool (Entity key activity) = do
    assignmentRows <- liftIO $ runSqlPool (selectList [EventLogisticsAssignmentActivityId ==. key] [Asc EventLogisticsAssignmentId]) pool
    dependencyRows <- liftIO $ runSqlPool (selectList [EventLogisticsDependencyActivityId ==. key] [Asc EventLogisticsDependencyDependsOnActivityId]) pool
    latestRoute <- liftIO $ runSqlPool (selectFirst [EventRouteVerificationActivityId ==. key] [Desc EventRouteVerificationVerifiedAt, Desc EventRouteVerificationId]) pool
    assignments <- mapM assignmentToDTO assignmentRows
    pure EventLogisticsActivityDTO
        { eacId = Just (renderKeyText key)
        , eacType = eventLogisticsActivityActivityType activity
        , eacTitle = eventLogisticsActivityTitle activity
        , eacNotes = eventLogisticsActivityNotes activity
        , eacStart = eventLogisticsActivityStartTime activity
        , eacEnd = eventLogisticsActivityEndTime activity
        , eacPlaceId = renderKeyText <$> eventLogisticsActivityPlaceId activity
        , eacOriginPlaceId = renderKeyText <$> eventLogisticsActivityOriginPlaceId activity
        , eacDestinationPlaceId = renderKeyText <$> eventLogisticsActivityDestinationPlaceId activity
        , eacTravelMode = eventLogisticsActivityTravelMode activity
        , eacBufferMinutes = eventLogisticsActivityBufferMinutes activity
        , eacPriority = eventLogisticsActivityPriority activity
        , eacStatus = eventLogisticsActivityStatus activity
        , eacVersion = Just (eventLogisticsActivityVersion activity)
        , eacAssignments = assignments
        , eacDependencyIds = map (renderKeyText . eventLogisticsDependencyDependsOnActivityId . entityVal) dependencyRows
        , eacLatestVerification = routeVerificationEntityToDTO <$> latestRoute
        , eacCreatedAt = Just (eventLogisticsActivityCreatedAt activity)
        , eacUpdatedAt = Just (eventLogisticsActivityUpdatedAt activity)
        }
  where
    assignmentToDTO (Entity _ assignment) = do
        let partyIdVal = eventLogisticsAssignmentPartyId assignment
        displayName <- case partyIdVal >>= (fromPathPiece :: T.Text -> Maybe PartyId) of
            Nothing -> pure Nothing
            Just partyKey -> fmap partyDisplayName <$> liftIO (runSqlPool (get partyKey) pool)
        pure EventLogisticsAssignmentDTO
            { elaPartyId = partyIdVal
            , elaDisplayName = displayName
            , elaExternalName = eventLogisticsAssignmentExternalName assignment
            , elaExternalPhone = eventLogisticsAssignmentExternalPhone assignment
            , elaExternalEmail = eventLogisticsAssignmentExternalEmail assignment
            }

routeVerificationEntityToDTO :: Entity EventRouteVerification -> EventRouteVerificationDTO
routeVerificationEntityToDTO (Entity key verification) = EventRouteVerificationDTO
    { ervId = Just (renderKeyText key)
    , ervActivityVersion = eventRouteVerificationActivityVersion verification
    , ervProvider = eventRouteVerificationProvider verification
    , ervTravelMode = eventRouteVerificationTravelMode verification
    , ervDepartureTime = eventRouteVerificationDepartureTime verification
    , ervDurationSeconds = eventRouteVerificationDurationSeconds verification
    , ervStaticDurationSeconds = eventRouteVerificationStaticDurationSeconds verification
    , ervDistanceMeters = eventRouteVerificationDistanceMeters verification
    , ervBufferSeconds = eventRouteVerificationBufferSeconds verification
    , ervAllocatedSeconds = eventRouteVerificationAllocatedSeconds verification
    , ervVerdict = eventRouteVerificationVerdict verification
    , ervEncodedPolyline = eventRouteVerificationEncodedPolyline verification
    , ervErrorMessage = eventRouteVerificationErrorMessage verification
    , ervCheckpoint = eventRouteVerificationCheckpoint verification
    , ervVerifiedAt = eventRouteVerificationVerifiedAt verification
    }

routeVerificationValues :: EventLogisticsActivity -> Int -> Either T.Text RouteEstimateResult -> (Maybe Int, Maybe Int, Maybe Int, Int, T.Text, Maybe T.Text, Maybe T.Text)
routeVerificationValues activity allocatedSeconds result = case result of
    Left message ->
        let bufferSeconds = maybe 900 (* 60) (eventLogisticsActivityBufferMinutes activity)
         in (Nothing, Nothing, Nothing, bufferSeconds, "unavailable", Nothing, Just message)
    Right RouteEstimateResult{..} ->
        let automaticBuffer = max 900 (ceiling (fromIntegral rerDurationSeconds * (0.2 :: Double)))
            bufferSeconds = maybe automaticBuffer (* 60) (eventLogisticsActivityBufferMinutes activity)
            verdict
                | allocatedSeconds < rerDurationSeconds = "infeasible"
                | allocatedSeconds < rerDurationSeconds + bufferSeconds = "tight"
                | otherwise = "feasible"
         in (Just rerDurationSeconds, rerStaticDurationSeconds, Just rerDistanceMeters, bufferSeconds, verdict, rerEncodedPolyline, Nothing)

logisticsDependencyReaches :: ConnectionPool -> EventLogisticsActivityId -> EventLogisticsActivityId -> Set.Set EventLogisticsActivityId -> IO Bool
logisticsDependencyReaches pool current target visited
    | current == target = pure True
    | Set.member current visited = pure False
    | otherwise = do
        rows <- runSqlPool (selectList [EventLogisticsDependencyActivityId ==. current] []) pool
        or <$> mapM (\row -> logisticsDependencyReaches pool (eventLogisticsDependencyDependsOnActivityId (entityVal row)) target (Set.insert current visited)) rows

buildLogisticsIssues :: [EventLogisticsActivityDTO] -> [EventScheduleIssueDTO]
buildLogisticsIssues activities =
    concatMap routeIssue activities
        <> concatMap dependencyIssues activities
        <> overlappingAssignmentIssues
        <> missingTransferIssues
  where
    routeIssue activity = case eacLatestVerification activity of
        Just verification | ervVerdict verification `elem` ["tight", "infeasible", "unavailable"] ->
            [ EventScheduleIssueDTO
                { esiCode = "route_" <> ervVerdict verification
                , esiSeverity = if ervVerdict verification == "tight" then "warning" else "error"
                , esiActivityId = eacId activity
                , esiMessage = fromMaybe (routeMessage (ervVerdict verification)) (ervErrorMessage verification)
                }
            ]
        _ -> []
    dependencyIssues activity =
        [ EventScheduleIssueDTO
            { esiCode = "dependency_timing"
            , esiSeverity = "error"
            , esiActivityId = eacId activity
            , esiMessage = "La actividad comienza antes de que termine una dependencia."
            }
        | dependencyId <- eacDependencyIds activity
        , Just dependency <- [findActivity dependencyId]
        , fromMaybe (eacStart dependency) (eacEnd dependency) > eacStart activity
        ]
    findActivity activityId = listToMaybe [activity | activity <- activities, eacId activity == Just activityId]
    overlappingAssignmentIssues =
        [ EventScheduleIssueDTO
            { esiCode = "assignment_overlap"
            , esiSeverity = "warning"
            , esiActivityId = eacId leftActivity
            , esiMessage =
                "El mismo responsable está asignado a actividades simultáneas: “"
                    <> eacTitle leftActivity
                    <> "” y “"
                    <> eacTitle rightActivity
                    <> "”."
            }
        | (index, leftActivity) <- zip [0 :: Int ..] activities
        , rightActivity <- drop (index + 1) activities
        , eacStatus leftActivity /= "cancelled"
        , eacStatus rightActivity /= "cancelled"
        , activityRangesOverlap leftActivity rightActivity
        , not (Set.null (assignmentIdentities leftActivity `Set.intersection` assignmentIdentities rightActivity))
        ]
    activityRangesOverlap leftActivity rightActivity =
        let leftEnd = fromMaybe (eacStart leftActivity) (eacEnd leftActivity)
            rightEnd = fromMaybe (eacStart rightActivity) (eacEnd rightActivity)
         in eacStart leftActivity < rightEnd && eacStart rightActivity < leftEnd
    assignmentIdentities activity = Set.fromList (map assignmentIdentity (eacAssignments activity))
    assignmentIdentity assignment = case elaPartyId assignment of
        Just partyId -> "party:" <> T.strip partyId
        Nothing ->
            "external:"
                <> T.toCaseFold (T.strip (fromMaybe "" (elaExternalName assignment)))
                <> ":"
                <> T.toCaseFold (T.strip (fromMaybe "" (elaExternalEmail assignment)))
                <> ":"
                <> T.strip (fromMaybe "" (elaExternalPhone assignment))
    missingTransferIssues =
        [ EventScheduleIssueDTO
            { esiCode = "missing_transfer"
            , esiSeverity = "warning"
            , esiActivityId = eacId rightActivity
            , esiMessage =
                "Falta un traslado para "
                    <> assignmentDisplayFor identity leftActivity
                    <> " entre “"
                    <> eacTitle leftActivity
                    <> "” y “"
                    <> eacTitle rightActivity
                    <> "”."
            }
        | identity <- Set.toList allAssignmentIdentities
        , let assignedActivities = sortOn eacStart
                [ activity
                | activity <- activities
                , eacStatus activity /= "cancelled"
                , Set.member identity (assignmentIdentities activity)
                ]
        , (leftActivity, rightActivity) <- zip assignedActivities (drop 1 assignedActivities)
        , fromMaybe (eacStart leftActivity) (eacEnd leftActivity) <= eacStart rightActivity
        , Just leftLocation <- [activityEndLocation leftActivity]
        , Just rightLocation <- [activityStartLocation rightActivity]
        , leftLocation /= rightLocation
        ]
    allAssignmentIdentities = Set.unions (map assignmentIdentities activities)
    activityStartLocation activity
        | eacType activity == "travel" = eacOriginPlaceId activity
        | otherwise = eacPlaceId activity
    activityEndLocation activity
        | eacType activity == "travel" = eacDestinationPlaceId activity
        | otherwise = eacPlaceId activity
    assignmentDisplayFor identity activity =
        fromMaybe "el responsable" $ listToMaybe
            [ fromMaybe (fromMaybe "el responsable" (elaPartyId assignment))
                (elaDisplayName assignment <|> elaExternalName assignment)
            | assignment <- eacAssignments activity
            , assignmentIdentity assignment == identity
            ]
    routeMessage "tight" = "El traslado cabe, pero no respeta la holgura recomendada."
    routeMessage "infeasible" = "El tiempo reservado es menor que la duración estimada del traslado."
    routeMessage _ = "No se pudo verificar la ruta."

-- | Stable, human-friendly identifier for a follow (artistId + follower id).
renderFollowId :: ArtistProfileId -> T.Text -> T.Text
renderFollowId artistId followerPartyId =
    T.intercalate ":" [renderKeyText artistId, followerPartyId]

-- | Insert or fetch an artist follow while keeping the created timestamp stable.
followArtistDb :: ConnectionPool -> ArtistProfileId -> T.Text -> IO ArtistFollowerDTO
followArtistDb pool artistId followerPartyIdRaw = do
    now <- getCurrentTime
    let followerPartyId = fromMaybe (T.strip followerPartyIdRaw) (normalizePositivePartyIdText followerPartyIdRaw)
    let followKey = ArtistFollowKey artistId followerPartyId
    existing <- runSqlPool (get followKey) pool
    _ <- case existing of
        Just _ -> pure followKey
        Nothing -> do
            mInserted <- runSqlPool (insertUnique (ArtistFollow artistId followerPartyId now)) pool
            pure (fromMaybe followKey mInserted)
    let createdAtVal = maybe now artistFollowCreatedAt existing
    pure
        ArtistFollowerDTO
            { afFollowId = Just (renderFollowId artistId followerPartyId)
            , afArtistId = Just (renderKeyText artistId)
            , afFollowerPartyId = followerPartyId
            , afCreatedAt = Just createdAtVal
            }

normalizePositivePartyIdText :: T.Text -> Maybe T.Text
normalizePositivePartyIdText rawPartyId =
    normalizePositiveIdentifierText rawPartyId

resolveExistingPartyIdText :: ConnectionPool -> T.Text -> T.Text -> IO (Either ServerError T.Text)
resolveExistingPartyIdText pool fieldName rawPartyId =
    case normalizePositivePartyIdText rawPartyId of
        Nothing ->
            pure (Left err400{errBody = BL.fromStrict (TE.encodeUtf8 (fieldName <> " must be a positive integer"))})
        Just normalized ->
            case readMaybe (T.unpack normalized) :: Maybe Int64 of
                Nothing ->
                    pure (Left err400{errBody = BL.fromStrict (TE.encodeUtf8 (fieldName <> " must be a positive integer"))})
                Just partyIdValue -> do
                    mParty <- runSqlPool (get (toSqlKey partyIdValue :: Key Party)) pool
                    pure $
                        case mParty of
                            Just _ -> Right normalized
                            Nothing ->
                                Left
                                    err422
                                        { errBody =
                                            BL.fromStrict
                                                (TE.encodeUtf8 (fieldName <> " references an unknown party"))
                                        }

resolveUniqueRsvpRow :: [Entity EventRsvp] -> Either ServerError (Maybe (Entity EventRsvp))
resolveUniqueRsvpRow [] = Right Nothing
resolveUniqueRsvpRow [row] = Right (Just row)
resolveUniqueRsvpRow _ =
    Left
        err409
            { errBody =
                "Multiple RSVP rows exist for this event and party; resolve duplicate rows before updating RSVP"
            }

data RsvpCursor = RsvpCursor
    { rsvpCursorUpdatedAt :: UTCTime
    , rsvpCursorStableId :: Int64
    }
    deriving (Show, Eq)

rsvpEntityToSelfDTO :: SocialEventId -> Entity EventRsvp -> RsvpDTO
rsvpEntityToSelfDTO eventKey (Entity _ row) =
    RsvpDTO
        { rsvpEventId = renderKeyText eventKey
        , rsvpStatus = eventRsvpStatus row
        , rsvpShowOnProfile = eventRsvpShowOnProfile row
        , rsvpCreatedAt = Just (eventRsvpCreatedAt row)
        , rsvpUpdatedAt = Just (eventRsvpUpdatedAt row)
        }

consumeRsvpMutationRateLimit :: T.Text -> UTCTime -> SqlPersistT IO Bool
consumeRsvpMutationRateLimit partyIdValue now = do
    deleteWhere
        [ EventRsvpMutationRateWindowStart <. addUTCTime (-7200) now
        ]
    backendName <- T.toCaseFold <$> getRDBMS
    if "sqlite" `T.isInfixOf` backendName
        then consumeSqlite
        else do
            counts <- (rawSql
                "INSERT INTO event_rsvp_mutation_rate_limit(party_id,window_start,mutation_count,updated_at) \
                \VALUES (?,date_trunc('hour',?::timestamptz),1,?) \
                \ON CONFLICT (party_id,window_start) DO UPDATE SET mutation_count=event_rsvp_mutation_rate_limit.mutation_count+1,updated_at=excluded.updated_at \
                \RETURNING mutation_count"
                [PersistText partyIdValue, toPersistValue now, toPersistValue now]
                :: SqlPersistT IO [Single Int])
            pure $ case counts of
                [Single countValue] -> countValue <= 120
                _ -> False
  where
    consumeSqlite = do
        let hourText = T.pack (formatTime defaultTimeLocale "%Y-%m-%dT%H:00:00Z" now)
            hourStart = fromMaybe now (iso8601ParseM (T.unpack hourText) :: Maybe UTCTime)
            seed = EventRsvpMutationRate partyIdValue hourStart 1 now
        inserted <- insertUnique seed
        case inserted of
            Just _ -> pure True
            Nothing -> do
                updateWhere
                    [ EventRsvpMutationRatePartyId ==. partyIdValue
                    , EventRsvpMutationRateWindowStart ==. hourStart
                    ]
                    [ EventRsvpMutationRateMutationCount +=. 1
                    , EventRsvpMutationRateUpdatedAt =. now
                    ]
                current <- getBy (UniqueEventRsvpMutationWindow partyIdValue hourStart)
                pure $ maybe False ((<= 120) . eventRsvpMutationRateMutationCount . entityVal) current

logRsvpMutation :: T.Text -> SocialEventId -> T.Text -> T.Text -> IO ()
logRsvpMutation operation eventKey statusValue outcome =
    hPutStrLn stderr . T.unpack . TE.decodeUtf8 . BL.toStrict . Aeson.encode $
        Aeson.object
            [ "event" Aeson..= ("event_rsvp_mutation" :: T.Text)
            , "operation" Aeson..= operation
            , "eventId" Aeson..= renderKeyText eventKey
            , "status" Aeson..= statusValue
            , "outcome" Aeson..= outcome
            ]

rsvpSummaryForEvent :: SocialEventId -> SqlPersistT IO RsvpSummaryDTO
rsvpSummaryForEvent eventKey = do
    rows <- rawSql
        "SELECT count(*) FILTER (WHERE status='accepted'),count(*) FILTER (WHERE status='maybe') FROM event_rsvp WHERE event_id=?"
        [toPersistValue eventKey]
    pure $ case rows of
        [(Single acceptedCount, Single maybeCount)] ->
            RsvpSummaryDTO
                { rsvpAcceptedCount = fromIntegral (acceptedCount :: Int64)
                , rsvpMaybeCount = fromIntegral (maybeCount :: Int64)
                }
        _ -> RsvpSummaryDTO 0 0

validateRsvpPageLimit :: Maybe Int -> Either ServerError Int
validateRsvpPageLimit Nothing = Right 20
validateRsvpPageLimit (Just limit)
    | limit >= 1 && limit <= 50 = Right limit
    | otherwise = Left err400{errBody = "limit must be between 1 and 50"}

encodeRsvpCursor :: RsvpCursor -> T.Text
encodeRsvpCursor RsvpCursor{..} =
    TE.decodeUtf8 . B64URL.encode . TE.encodeUtf8 $
        T.pack (formatTime defaultTimeLocale "%Y-%m-%dT%H:%M:%S%QZ" rsvpCursorUpdatedAt)
            <> "|"
            <> T.pack (show rsvpCursorStableId)

decodeRsvpCursor :: T.Text -> Either ServerError RsvpCursor
decodeRsvpCursor rawCursor =
    case B64URL.decode (TE.encodeUtf8 (T.strip rawCursor)) of
        Left _ -> invalid
        Right bytes ->
            case TE.decodeUtf8' bytes of
                Left _ -> invalid
                Right decoded ->
                    case T.splitOn "|" decoded of
                        [rawTime, rawId] ->
                            case (iso8601ParseM (T.unpack rawTime) :: Maybe UTCTime, normalizePositiveIdentifier rawId) of
                                (Just timestamp, Just stableId) -> Right (RsvpCursor timestamp stableId)
                                _ -> invalid
                        _ -> invalid
  where
    invalid = Left err400{errBody = "cursor is malformed or expired"}

encodeRsvpCursorFromAdmin :: RsvpAdminDTO -> T.Text
encodeRsvpCursorFromAdmin item =
    encodeRsvpCursor
        RsvpCursor
            { rsvpCursorUpdatedAt = adminRsvpUpdatedAt item
            , rsvpCursorStableId = fromMaybe 0 (normalizePositiveIdentifier (adminRsvpId item))
            }

encodeRsvpCursorFromFeed :: RsvpFeedItemDTO -> T.Text
encodeRsvpCursorFromFeed item =
    encodeRsvpCursor
        RsvpCursor
            { rsvpCursorUpdatedAt = feedActionAt item
            , rsvpCursorStableId = fromMaybe 0 (normalizePositiveIdentifier (feedEventId item))
            }

loadOrganizerRsvpPage :: SocialEventId -> Maybe RsvpCursor -> Int -> SqlPersistT IO [RsvpAdminDTO]
loadOrganizerRsvpPage eventKey mCursor limit = do
    let cursorTime = maybe PersistNull (toPersistValue . rsvpCursorUpdatedAt) mCursor
        cursorId = maybe PersistNull (PersistInt64 . rsvpCursorStableId) mCursor
    rows <- rawSql
        "SELECT id,party_id,status,show_on_profile,created_at,updated_at FROM event_rsvp \
        \WHERE event_id=? AND (?::timestamptz IS NULL OR (updated_at,id)<(?::timestamptz,?::bigint)) \
        \ORDER BY updated_at DESC,id DESC LIMIT ?"
        [toPersistValue eventKey, cursorTime, cursorTime, cursorId, PersistInt64 (fromIntegral limit)]
    pure
        [ RsvpAdminDTO
            { adminRsvpId = T.pack (show (rowId :: Int64))
            , adminRsvpPartyId = partyIdValue
            , adminRsvpStatus = statusValue
            , adminRsvpShowOnProfile = showOnProfile
            , adminRsvpCreatedAt = createdAt
            , adminRsvpUpdatedAt = updatedAt
            }
        | (Single rowId, Single partyIdValue, Single statusValue, Single showOnProfile, Single createdAt, Single updatedAt) <- rows
        ]

canViewRsvpProfileFeed :: T.Text -> T.Text -> SqlPersistT IO Bool
canViewRsvpProfileFeed viewerPartyId targetPartyId = do
    rows <- rawSql
        "WITH target_public AS ( \
        \ SELECT DISTINCT coalesce(profile.canonical_profile_id,profile.id) AS id \
        \ FROM directory_profile profile JOIN directory_public_profile public_profile ON public_profile.id=coalesce(profile.canonical_profile_id,profile.id) \
        \ WHERE profile.subject_party_id=?::bigint AND profile.profile_kind='person' \
        \), target_all AS ( \
        \ SELECT profile.id FROM directory_profile profile WHERE profile.subject_party_id=?::bigint \
        \ UNION SELECT id FROM target_public \
        \), viewer_all AS ( \
        \ SELECT profile.id FROM directory_profile profile WHERE profile.subject_party_id=?::bigint \
        \ UNION SELECT coalesce(profile.canonical_profile_id,profile.id) FROM directory_profile profile WHERE profile.subject_party_id=?::bigint \
        \) \
        \SELECT (SELECT count(*)=1 FROM target_public) AND NOT EXISTS ( \
        \ SELECT 1 FROM directory_profile_block block \
        \ WHERE (block.blocker_profile_id IN (SELECT id FROM target_all) AND block.blocked_profile_id IN (SELECT id FROM viewer_all)) \
        \ OR (block.blocked_profile_id IN (SELECT id FROM target_all) AND block.blocker_profile_id IN (SELECT id FROM viewer_all)) \
        \)"
        [ PersistText targetPartyId
        , PersistText targetPartyId
        , PersistText viewerPartyId
        , PersistText viewerPartyId
        ]
    pure $ rows == [Single True]

loadRsvpFeedPage :: T.Text -> T.Text -> Bool -> Maybe RsvpCursor -> Int -> SqlPersistT IO [RsvpFeedItemDTO]
loadRsvpFeedPage targetPartyId _viewerPartyId self mCursor limit = do
    let cursorTime = maybe PersistNull (toPersistValue . rsvpCursorUpdatedAt) mCursor
        cursorId = maybe PersistNull (PersistInt64 . rsvpCursorStableId) mCursor
    rows <- rawSql
        "SELECT event.id,rsvp.status,event.title,event.start_time,event.timezone, \
        \ CASE WHEN event.metadata IS JSON OBJECT \
        \ AND strpos(event.metadata::jsonb->>'imageUrl',chr(92))=0 \
        \ AND (((event.metadata::jsonb->>'imageUrl') ~* '^https://[^[:space:][:cntrl:]]+$' AND split_part(event.metadata::jsonb->>'imageUrl','/',3) NOT LIKE '%@%') \
        \ OR (event.metadata::jsonb->>'imageUrl') ~ '^/[^/[:space:][:cntrl:]][^[:space:][:cntrl:]]*$') \
        \ THEN event.metadata::jsonb->>'imageUrl' ELSE NULL END, \
        \ venue.name,venue.city,state.code,rsvp.updated_at \
        \FROM event_rsvp rsvp \
        \JOIN social_event event ON event.id=rsvp.event_id \
        \JOIN workflow_state state ON state.id=event.workflow_state_id \
        \JOIN workflow_definition workflow ON workflow.id=state.workflow_id AND workflow.code='social-event-lifecycle' AND workflow.active \
        \LEFT JOIN venue ON venue.id=event.venue_id \
        \WHERE rsvp.party_id=? AND rsvp.show_on_profile AND rsvp.visibility_decided_at IS NOT NULL \
        \AND rsvp.status IN ('accepted','maybe') \
        \AND coalesce(CASE WHEN event.metadata IS JSON OBJECT AND event.metadata::jsonb->>'isPublic' IN ('true','false') THEN (event.metadata::jsonb->>'isPublic')::boolean ELSE FALSE END,FALSE) \
        \AND (state.code='cancelled' OR EXISTS (SELECT 1 FROM workflow_state_capability capability WHERE capability.state_id=state.id AND capability.capability_code='public-listable' AND capability.enabled)) \
        \AND (?::timestamptz IS NULL OR (rsvp.updated_at,event.id)<(?::timestamptz,?::bigint)) \
        \ORDER BY rsvp.updated_at DESC,event.id DESC LIMIT ?"
        [ PersistText targetPartyId
        , cursorTime
        , cursorTime
        , cursorId
        , PersistInt64 (fromIntegral limit)
        ]
    pure
        [ RsvpFeedItemDTO
            { feedItemType = "event_rsvp"
            , feedEventId = T.pack (show (eventIdValue :: Int64))
            , feedStatus = statusValue
            , feedShowOnProfile = True
            , feedEventTitle = title
            , feedEventStart = startTime
            , feedEventTimezone = eventTimezone
            , feedEventImageUrl = imageUrl
            , feedVenueName = venueName
            , feedCity = venueCity
            , feedWorkflowStateCode = stateCode
            , feedActionAt = actionAt
            , feedCanonicalUrl = "/eventos/" <> T.pack (show eventIdValue)
            , feedCanEdit = self
            , feedCanShare = stateCode /= "cancelled"
            }
        | ( Single eventIdValue
            , Single statusValue
            , Single title
            , Single startTime
            , Single eventTimezone
            , Single imageUrl
            , Single venueName
            , Single venueCity
            , Single stateCode
            , Single actionAt
            ) <- rows
        ]

normalizePositiveIdentifierText :: T.Text -> Maybe T.Text
normalizePositiveIdentifierText rawIdentifier =
    T.pack . show <$> normalizePositiveIdentifier rawIdentifier

normalizePositiveIdentifier :: T.Text -> Maybe Int64
normalizePositiveIdentifier rawIdentifier =
    let trimmed = T.strip rawIdentifier
     in if T.null trimmed || not (T.all isAsciiDecimalDigit trimmed)
            then Nothing
            else case readMaybe (T.unpack trimmed) of
                Just identifier | identifier > 0 -> Just identifier
                _ -> Nothing

isAsciiDecimalDigit :: Char -> Bool
isAsciiDecimalDigit ch =
    ch >= '0' && ch <= '9'

parseFollowerQueryParamEither :: Maybe T.Text -> Either ServerError T.Text
parseFollowerQueryParamEither mFollower =
    case cleanMaybeText mFollower of
        Nothing -> Left err400{errBody = "follower query param is required"}
        Just rawFollower ->
            case normalizePositivePartyIdText rawFollower of
                Nothing -> Left err400{errBody = "follower query param must be a positive integer"}
                Just normalized -> Right normalized

validateInvitationToPartyId :: T.Text -> Either ServerError T.Text
validateInvitationToPartyId rawInvitationPartyId =
    case cleanMaybeText (Just rawInvitationPartyId) of
        Nothing -> Left err400{errBody = "invitationToPartyId is required"}
        Just trimmed ->
            case normalizePositivePartyIdText trimmed of
                Nothing -> Left err400{errBody = "invitationToPartyId must be a positive integer"}
                Just normalized -> Right normalized

validateInvitationFromPartyId :: T.Text -> Maybe T.Text -> Either ServerError T.Text
validateInvitationFromPartyId currentPartyId rawInvitationPartyId =
    case cleanMaybeText rawInvitationPartyId of
        Nothing -> Right currentPartyId
        Just trimmed ->
            case normalizePositivePartyIdText trimmed of
                Nothing -> Left err400{errBody = "invitationFromPartyId must be a positive integer"}
                Just normalized
                    | normalized == currentPartyId -> Right currentPartyId
                    | otherwise ->
                        Left err403{errBody = "invitationFromPartyId must match the authenticated party"}

parseInvitationStatus :: T.Text -> Maybe T.Text
parseInvitationStatus raw =
    case T.toLower (T.strip raw) of
        "pending" -> Just "pending"
        "accepted" -> Just "accepted"
        "declined" -> Just "declined"
        _ -> Nothing

validateInvitationStatusInput :: Maybe T.Text -> Either ServerError T.Text
validateInvitationStatusInput Nothing = Right "pending"
validateInvitationStatusInput (Just rawStatus) =
    case T.strip rawStatus of
        "" -> Right "pending"
        _ ->
            case parseInvitationStatus rawStatus of
                Just statusVal -> Right statusVal
                Nothing ->
                    Left
                        err400
                            { errBody = "invitationStatus must be one of: pending, accepted, declined"
                            }

validateInvitationStatusUpdateInput :: Maybe T.Text -> Either ServerError (Maybe T.Text)
validateInvitationStatusUpdateInput Nothing = Right Nothing
validateInvitationStatusUpdateInput (Just rawStatus) =
    case cleanMaybeText (Just rawStatus) of
        Nothing ->
            Left
                err400
                    { errBody = "invitationStatus must be one of: pending, accepted, declined"
                    }
        Just _ ->
            Just <$> validateInvitationStatusInput (Just rawStatus)

validateInvitationUpdateAuthorization
    :: Bool
    -> T.Text
    -> Maybe T.Text
    -> Maybe T.Text
    -> T.Text
    -> Maybe T.Text
    -> NullableFieldUpdate T.Text
    -> Either ServerError ()
validateInvitationUpdateAuthorization
    isManager
    currentPartyId
    existingToPartyId
    existingStatus
    requestedToPartyId
    requestedStatus
    messageUpdate
        | isManager = Right ()
        | existingToPartyId /= Just currentPartyId =
            Left err403{errBody = "Only the event organizer or invited party can update this invitation"}
        | requestedToPartyId /= currentPartyId =
            Left err403{errBody = "Invited parties cannot transfer invitations"}
        | messageUpdate /= FieldMissing =
            Left err403{errBody = "Invited parties cannot edit invitation messages"}
        | otherwise =
            case requestedStatus of
                Just targetStatus
                    | allowedRecipientTransition
                        (normalizeInvitationStatus existingStatus)
                        targetStatus -> Right ()
                _ ->
                    Left
                        err403
                            { errBody =
                                "Invited parties may only accept or decline pending invitations"
                            }
  where
    allowedRecipientTransition currentStatus targetStatus =
        targetStatus == currentStatus
            || (currentStatus == "pending" && targetStatus `elem` ["accepted", "declined"])

toggleMomentReactionDb
    :: PartyId
    -> T.Text
    -> EventMomentId
    -> UUID.UUID
    -> Maybe Bool
    -> UTCTime
    -> SqlPersistT IO Bool
toggleMomentReactionDb actorPartyId actorPartyText momentKey reactionTypeId requestedActive now = do
    -- Serialize every reaction mutation for this moment, including the absent
    -- reaction case. Locking reaction rows alone cannot protect a first insert.
    backendName <- T.toCaseFold <$> getRDBMS
    if "sqlite" `T.isInfixOf` backendName
        then rawExecute "UPDATE event_moment SET id = id WHERE id = ?" [toPersistValue momentKey]
        else do
            _ <- (rawSql "SELECT id FROM event_moment WHERE id = ? FOR UPDATE"
                [toPersistValue momentKey] :: SqlPersistT IO [Single Int64])
            pure ()
    existingSameReaction <-
        selectFirst
            [ EventMomentReactionMomentId ==. momentKey
            , EventMomentReactionReactionTypeId ==. Just reactionTypeId
            , EventMomentReactionReactorPartyId ==. actorPartyText
            ]
            []
    let shouldBeActive = fromMaybe (isNothing existingSameReaction) requestedActive
    if shouldBeActive
        then do
            when (isNothing existingSameReaction) $ do
                deleteWhere
                    [ EventMomentReactionMomentId ==. momentKey
                    , EventMomentReactionReactorPartyId ==. actorPartyText
                    ]
                insert_
                    EventMomentReaction
                        { eventMomentReactionMomentId = momentKey
                        , eventMomentReactionReactionTypeId = Just reactionTypeId
                        , eventMomentReactionReaction = Nothing
                        , eventMomentReactionReactorPartyId = actorPartyText
                        , eventMomentReactionCreatedAt = now
                        }
            -- Repair pre-evidence reactions on replay, retaining the original
            -- action time so an old reaction cannot qualify as a new action.
            let evidenceTime = maybe now (eventMomentReactionCreatedAt . entityVal) existingSameReaction
            existingEvidence <- selectFirst
                [ EngagementEventActorPartyId ==. Just actorPartyId
                , EngagementEventEntityType ==. "event_moment"
                , EngagementEventEntityId ==. Just (fromIntegral (fromSqlKey momentKey))
                , EngagementEventEventType ==. "reaction_added"
                , EngagementEventMetadata ==. Just (UUID.toText reactionTypeId)
                , EngagementEventCreatedAt ==. evidenceTime
                ] []
            when (isNothing existingEvidence) $
                insert_
                    EngagementEvent
                        { engagementEventActorPartyId = Just actorPartyId
                        , engagementEventTargetArtistId = Nothing
                        , engagementEventEntityType = "event_moment"
                        , engagementEventEntityId = Just (fromIntegral (fromSqlKey momentKey))
                        , engagementEventEventType = "reaction_added"
                        , engagementEventMetadata = Just (UUID.toText reactionTypeId)
                        , engagementEventCreatedAt = evidenceTime
                        }
            pure True
        else do
            deleteWhere
                [ EventMomentReactionMomentId ==. momentKey
                , EventMomentReactionReactionTypeId ==. Just reactionTypeId
                , EventMomentReactionReactorPartyId ==. actorPartyText
                ]
            pure False

validateEventArtistIds :: [ArtistDTO] -> Either ServerError [ArtistProfileId]
validateEventArtistIds artists
    | length artists > maxEventArtistsPerEvent =
        Left err400{errBody = "eventArtists supports at most 50 artists"}
    | otherwise = do
        artistKeys <- traverse validateArtistId artists
        if Set.size (Set.fromList artistKeys) == length artistKeys
            then Right artistKeys
            else Left err400{errBody = "eventArtists[].artistId must be unique"}
  where
    validateArtistId artist =
        case artistId artist of
            Nothing -> Left err400{errBody = "eventArtists[].artistId is required"}
            Just rawArtistId ->
                case normalizePositiveIdentifierText rawArtistId of
                    Nothing -> Left err400{errBody = "eventArtists[].artistId must be a positive integer"}
                    Just normalizedArtistId ->
                        case readMaybe (T.unpack normalizedArtistId) :: Maybe Int64 of
                            Just artistIdValue -> Right (toSqlKey artistIdValue)
                            Nothing -> Left err400{errBody = "eventArtists[].artistId must be a positive integer"}

maxEventArtistsPerEvent :: Int
maxEventArtistsPerEvent = 50

validateArtistName :: T.Text -> Either ServerError T.Text
validateArtistName rawName
    | T.null normalized =
        Left err400{errBody = "artist name is required"}
    | T.any isControl rawName =
        Left err400{errBody = "artist name must not contain control characters"}
    | otherwise =
        Right normalized
  where
    normalized = T.strip rawName

-- | Normalize invitation status to a lowercase, non-empty value.
normalizeInvitationStatus :: Maybe T.Text -> T.Text
normalizeInvitationStatus mStatus =
    case mStatus >>= parseInvitationStatus of
        Nothing -> "pending"
        Just s -> s

normalizeTicketOrderStatus :: Maybe T.Text -> T.Text
normalizeTicketOrderStatus mStatus =
    case cleanMaybeText mStatus of
        Nothing -> "pending"
        Just rawStatus ->
            fromMaybe (T.toLower rawStatus) (parseTicketOrderStatus rawStatus)

{- | Both pending Stripe orders and paid orders reserve inventory. Closed
orders consume none, so status retries naturally produce a zero delta.
-}
ticketOrderInventoryAdjustment :: Int -> T.Text -> T.Text -> Int
ticketOrderInventoryAdjustment quantity oldStatus newStatus =
    reservedQuantity newStatus - reservedQuantity oldStatus
  where
    reservedQuantity rawStatus =
        case parseTicketOrderStatus rawStatus of
            Just "pending" -> quantity
            Just "paid" -> quantity
            _ -> 0

{- | Direct issuance is limited to tiers whose authoritative price is exactly
zero. A manager is not payment evidence: priced tickets must use a verified
provider checkout or a separately implemented dual-controlled manual-payment
workflow.
-}
validateDirectTicketOrderPricing :: Bool -> Int -> Either ServerError ()
validateDirectTicketOrderPricing _ authoritativeTierPriceCents
    | authoritativeTierPriceCents < 0 =
        Left err500{errBody = "Stored ticket tier price is invalid"}
    | authoritativeTierPriceCents > 0 =
        Left
            err409
                { errBody =
                    "Priced ticket orders require a server-verified checkout"
                }
    | otherwise = Right ()

validateTicketPurchaseEventEligibility :: Maybe T.Text -> Bool -> Either ServerError ()
validateTicketPurchaseEventEligibility rawMetadata purchaseEnabled = do
    metadata <-
        either (Left . storedEventMetadataServerError) Right $
            decodeStoredEventMetadata rawMetadata
    when (emIsPublic metadata == Just False) $
        Left err403{errBody = "Tickets are not available for private events"}
    unless purchaseEnabled $
        Left err409{errBody = "Tickets are not on sale for this event"}

eventTicketPurchaseEnabledFor :: SocialEvent -> SqlPersistT IO Bool
eventTicketPurchaseEnabledFor eventRow =
    case socialEventWorkflowStateId eventRow of
        Nothing -> pure False
        Just stateId -> EventLifecycle.socialEventStateHasCapability stateId "ticket-purchase"

normalizeTicketStatus :: Maybe T.Text -> T.Text
normalizeTicketStatus mStatus =
    case mStatus >>= parseTicketStatus of
        Nothing -> "issued"
        Just s -> s

validateStoredTicketOrderStatus :: Maybe T.Text -> Either ServerError T.Text
validateStoredTicketOrderStatus Nothing =
    Left err500{errBody = "Ticket order could not be loaded"}
validateStoredTicketOrderStatus (Just rawStatus) =
    case parseTicketOrderStatus rawStatus of
        Just statusVal -> Right statusVal
        Nothing -> Left err500{errBody = "Stored ticket order status is invalid"}

validateTicketCheckInOrderStatus :: Maybe T.Text -> Either ServerError T.Text
validateTicketCheckInOrderStatus = validateStoredTicketOrderStatus

validateTicketCheckInTicketStatus :: T.Text -> Either ServerError T.Text
validateTicketCheckInTicketStatus rawStatus =
    case parseTicketStatus rawStatus of
        Just statusVal -> Right statusVal
        Nothing -> Left err500{errBody = "Stored ticket status is invalid"}

findTicketForCheckIn :: SocialEventId -> TicketCheckInLookup -> SqlPersistT IO (Maybe (Entity EventTicket))
findTicketForCheckIn eventKey ticketLookup =
    case ticketLookup of
        TicketCheckInLookupById ticketId ->
            selectFirst [EventTicketId ==. toSqlKey ticketId, EventTicketEventId ==. eventKey] []
        TicketCheckInLookupByCode codeVal ->
            selectFirst [EventTicketEventId ==. eventKey, EventTicketCode ==. codeVal] []

validateTicketCheckInLookup :: TicketCheckInRequestDTO -> Either ServerError TicketCheckInLookup
validateTicketCheckInLookup TicketCheckInRequestDTO{..} =
    case (ticketCheckInTicketId, ticketCheckInTicketCode) of
        (Just _, Just _) ->
            Left err400{errBody = "Provide exactly one of ticketCheckInTicketId or ticketCheckInTicketCode"}
        (Just rawTicketId, Nothing) ->
            case normalizePositiveIdentifier rawTicketId of
                Just ticketId -> Right (TicketCheckInLookupById ticketId)
                Nothing ->
                    Left err400{errBody = "ticketCheckInTicketId must be a positive integer"}
        (Nothing, Just rawCode) ->
            case normalizeTicketCheckInCode rawCode of
                Just codeVal -> Right (TicketCheckInLookupByCode codeVal)
                Nothing ->
                    Left err400{errBody = "ticketCheckInTicketCode must be a generated ticket code"}
        (Nothing, Nothing) ->
            Left err400{errBody = "Provide ticketCheckInTicketId or ticketCheckInTicketCode"}

validateOptionalTicketBuyerPartyId :: T.Text -> Maybe T.Text -> Either ServerError (Maybe T.Text)
validateOptionalTicketBuyerPartyId fieldName mPartyId =
    case cleanMaybeText mPartyId of
        Nothing -> Right Nothing
        Just rawPartyId ->
            case normalizePositivePartyIdText rawPartyId of
                Nothing ->
                    Left
                        err400
                            { errBody =
                                BL.fromStrict
                                    (TE.encodeUtf8 (fieldName <> " must be a positive integer"))
                            }
                Just normalized -> Right (Just normalized)

validateTicketPurchaseBuyerName :: Maybe T.Text -> Either ServerError (Maybe T.Text)
validateTicketPurchaseBuyerName rawName =
    case cleanMaybeText rawName of
        Nothing -> Right Nothing
        Just buyerName
            | T.length buyerName > 160 ->
                Left
                    err400
                        { errBody = "ticketPurchaseBuyerName must be 160 characters or fewer"
                        }
            | T.any isUnsafeTicketPurchaseBuyerNameChar buyerName ->
                Left
                    err400
                        { errBody =
                            "ticketPurchaseBuyerName must not contain control characters "
                                <> "or hidden formatting characters"
                        }
            | not (T.any isAlphaNum buyerName) ->
                Left
                    err400
                        { errBody = "ticketPurchaseBuyerName must include letters or numbers"
                        }
            | otherwise ->
                Right (Just buyerName)

isUnsafeTicketPurchaseBuyerNameChar :: Char -> Bool
isUnsafeTicketPurchaseBuyerNameChar ch =
    isControl ch || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

validateTicketPurchaseBuyerEmail :: Maybe T.Text -> Either ServerError (Maybe T.Text)
validateTicketPurchaseBuyerEmail rawEmail =
    case cleanMaybeText rawEmail of
        Nothing -> Right Nothing
        Just email
            | T.length normalized > 254 ->
                Left
                    err400
                        { errBody = "ticketPurchaseBuyerEmail must be 254 characters or fewer"
                        }
            | isValidSocialEventEmail normalized ->
                Right (Just normalized)
            | otherwise ->
                Left
                    err400
                        { errBody = "ticketPurchaseBuyerEmail must be a valid email address"
                        }
          where
            normalized = T.toLower email

isValidSocialEventEmail :: T.Text -> Bool
isValidSocialEventEmail candidate =
    case T.splitOn "@" candidate of
        [localPart, domain] ->
            T.length candidate <= 254
                && isValidSocialEventEmailLocalPart localPart
                && not (T.null domain)
                && not (T.any (`elem` (" \t\n\r" :: String)) candidate)
                && T.isInfixOf "." domain
                && hasValidSocialEventEmailFinalDomainLabel domain
                && all isValidSocialEventEmailDomainLabel (T.splitOn "." domain)
        _ -> False

hasValidSocialEventEmailFinalDomainLabel :: T.Text -> Bool
hasValidSocialEventEmailFinalDomainLabel domain =
    case reverse (T.splitOn "." domain) of
        finalLabel : _ ->
            T.length finalLabel >= 2 && T.any isAsciiLower finalLabel
        [] -> False

isValidSocialEventEmailLocalPart :: T.Text -> Bool
isValidSocialEventEmailLocalPart localPart =
    not (T.null localPart)
        && T.length localPart <= 64
        && not (T.isPrefixOf "." localPart)
        && not (T.isSuffixOf "." localPart)
        && not (".." `T.isInfixOf` localPart)
        && T.all isValidSocialEventEmailLocalChar localPart

isValidSocialEventEmailLocalChar :: Char -> Bool
isValidSocialEventEmailLocalChar c =
    isAscii c
        && (isAlphaNum c || c `elem` ("!#$%&'*+/=?^_`{|}~.-" :: String))

isValidSocialEventEmailDomainLabel :: T.Text -> Bool
isValidSocialEventEmailDomainLabel label =
    not (T.null label)
        && T.length label <= 63
        && not (T.isPrefixOf "-" label)
        && not (T.isSuffixOf "-" label)
        && T.all isValidSocialEventEmailDomainChar label

isValidSocialEventEmailDomainChar :: Char -> Bool
isValidSocialEventEmailDomainChar c =
    isAscii c && (isAlphaNum c || c == '-')

normalizeTicketCheckInCode :: T.Text -> Maybe T.Text
normalizeTicketCheckInCode = Admission.normalizeTicketCode

normalizeMomentMediaType :: T.Text -> Maybe T.Text
normalizeMomentMediaType raw =
    case T.toLower (T.strip raw) of
        "image" -> Just "image"
        "photo" -> Just "image"
        "picture" -> Just "image"
        "video" -> Just "video"
        "clip" -> Just "video"
        "audio" -> Just "audio"
        "text" -> Just "text"
        _ -> Nothing

loadSelectableMomentReactionTypeId :: T.Text -> SqlPersistT IO (Either ServerError UUID.UUID)
loadSelectableMomentReactionTypeId rawId =
    case UUID.fromText (T.strip rawId) of
        Nothing -> pure (Left invalidReactionTypeReference)
        Just reactionTypeUuid -> do
            let reactionTypeKey = Catalog.ReactionTypeKey reactionTypeUuid
            mReactionType <- get reactionTypeKey
            case mReactionType of
                Nothing -> pure (Left invalidReactionTypeReference)
                Just reactionType -> do
                    catalog <- getJust (Catalog.reactionTypeCatalogId reactionType)
                    workflowState <- getJust (Catalog.reactionTypeWorkflowStateId reactionType)
                    let selectable =
                            Catalog.reactionTypeActive reactionType
                                && Catalog.catalogDefinitionActive catalog
                                && Catalog.catalogDefinitionCode catalog == "reaction-types"
                                && Catalog.workflowStateActive workflowState
                                && Catalog.workflowStateCode workflowState == "published"
                                && Catalog.workflowStateWorkflowId workflowState == Catalog.catalogDefinitionWorkflowId catalog
                    pure (if selectable then Right reactionTypeUuid else Left invalidReactionTypeReference)
  where
    invalidReactionTypeReference =
        err422{errBody = "reactionTypeId must identify an active published reaction type"}

normalizeMomentCaption :: Maybe T.Text -> Either ServerError (Maybe T.Text)
normalizeMomentCaption mCaption =
    case cleanMaybeText mCaption of
        Nothing -> Right Nothing
        Just captionVal
            | T.length captionVal > 280 ->
                Left err400{errBody = "Moment caption must be 280 characters or less"}
            | maybe False (T.any isUnsafeMomentTextChar) mCaption ->
                Left
                    err400
                        { errBody =
                            "Moment caption must not contain control characters or hidden formatting characters"
                        }
            | otherwise -> Right (Just captionVal)

normalizeMomentCommentBody :: T.Text -> Either ServerError T.Text
normalizeMomentCommentBody rawBody =
    case nonEmptyText rawBody of
        Nothing ->
            Left err400{errBody = "Moment comment body is required"}
        Just bodyVal
            | T.length bodyVal > 500 ->
                Left err400{errBody = "Moment comment body must be 500 characters or less"}
            | T.any isUnsafeMomentTextChar rawBody ->
                Left
                    err400
                        { errBody =
                            "Moment comment body must not contain control characters or hidden formatting characters"
                        }
            | otherwise -> Right bodyVal

isUnsafeMomentTextChar :: Char -> Bool
isUnsafeMomentTextChar ch =
    isControl ch
        || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

validateMomentMediaDimension :: T.Text -> Maybe Int -> Either ServerError (Maybe Int)
validateMomentMediaDimension _ Nothing = Right Nothing
validateMomentMediaDimension fieldName (Just value)
    | value > 0 = Right (Just value)
    | otherwise =
        Left
            err400
                { errBody =
                    BL.fromStrict
                        (TE.encodeUtf8 (fieldName <> " must be greater than 0"))
                }

validateMomentMediaDuration :: Maybe Int -> Either ServerError (Maybe Int)
validateMomentMediaDuration Nothing = Right Nothing
validateMomentMediaDuration (Just value)
    | value >= 0 = Right (Just value)
    | otherwise =
        Left err400{errBody = "Moment media duration must be 0 or greater"}

resolveMomentAuthorName :: T.Text -> Maybe T.Text -> T.Text
resolveMomentAuthorName currentParty mAuthorName =
    fromMaybe ("Party " <> currentParty) (cleanMaybeText mAuthorName)

loadAuthenticatedPartyDisplayName :: ConnectionPool -> T.Text -> IO T.Text
loadAuthenticatedPartyDisplayName pool currentParty =
    case readMaybe (T.unpack currentParty) :: Maybe Int64 of
        Nothing -> pure ("Party " <> currentParty)
        Just partyId -> do
            mParty <- runSqlPool (get (toSqlKey partyId)) pool
            pure $ maybe ("Party " <> currentParty) partyDisplayName mParty

validateLiveBroadcastBroadcaster :: T.Text -> Maybe T.Text -> AppM ()
validateLiveBroadcastBroadcaster currentPartyId mRawBroadcaster =
    maybe (pure ()) validateBroadcaster (cleanMaybeText mRawBroadcaster)
  where
    validateBroadcaster rawBroadcaster =
        maybe
            (throwError err400{errBody = "broadcasterPartyId must be a positive integer"})
            requireMatchingParty
            (normalizePositivePartyIdText rawBroadcaster)

    requireMatchingParty normalized
        | normalized == currentPartyId = pure ()
        | otherwise =
            throwError err403{errBody = "broadcasterPartyId must match authenticated party"}

normalizeLiveBroadcastTitle :: Maybe T.Text -> Either ServerError T.Text
normalizeLiveBroadcastTitle mTitle =
    maybe
        (Left err400{errBody = "Live broadcast title is required"})
        validateTitle
        (cleanMaybeText mTitle)
  where
    validateTitle titleVal
        | T.length titleVal > 120 =
            Left err400{errBody = "Live broadcast title must be 120 characters or less"}
        | maybe False (T.any isUnsafeMomentTextChar) mTitle =
            Left
                err400
                    { errBody =
                        "Live broadcast title must not contain control characters or hidden formatting characters"
                    }
        | otherwise = Right titleVal

normalizeLiveBroadcastDescription :: Maybe T.Text -> Either ServerError (Maybe T.Text)
normalizeLiveBroadcastDescription mDescription =
    maybe (Right Nothing) validateDescription (cleanMaybeText mDescription)
  where
    validateDescription descriptionVal
        | T.length descriptionVal > 280 =
            Left err400{errBody = "Live broadcast description must be 280 characters or less"}
        | maybe False (T.any isUnsafeMomentTextChar) mDescription =
            Left
                err400
                    { errBody =
                        "Live broadcast description must not contain control characters or hidden formatting characters"
                    }
        | otherwise = Right (Just descriptionVal)

normalizeLiveBroadcastQuality :: Maybe T.Text -> Either ServerError T.Text
normalizeLiveBroadcastQuality mQuality =
    maybe (Right "auto") validateQuality (fmap (T.toLower . T.strip) mQuality)
  where
    validateQuality quality
        | T.null quality = Right "auto"
        | quality `elem` ["auto", "720p", "480p"] = Right quality
        | otherwise =
            Left err400{errBody = "Live broadcast quality must be one of: auto, 720p, 480p"}

normalizeBudgetCentsMaybe :: Maybe Int -> Maybe Int
normalizeBudgetCentsMaybe mBudget =
    case mBudget of
        Just n | n >= 0 -> Just n
        _ -> Nothing

validateEventTitleInput :: T.Text -> Either ServerError T.Text
validateEventTitleInput rawTitle
    | T.null titleVal =
        Left err400{errBody = "title is required"}
    | T.length titleVal > maxEventTitleChars =
        Left err400{errBody = "title must be 160 characters or fewer"}
    | T.any isUnsafeEventTitleChar titleVal =
        Left
            err400
                { errBody =
                    "title must not contain control characters or hidden formatting characters"
                }
    | otherwise =
        Right titleVal
  where
    titleVal = T.strip rawTitle

-- An event may legitimately have no confirmed end yet. When an end is
-- supplied, keep the invariant strict instead of deriving a duration.
validateEventTimeRange :: UTCTime -> Maybe UTCTime -> Either ServerError ()
validateEventTimeRange _ Nothing = Right ()
validateEventTimeRange startTime (Just endTime)
    | startTime < endTime = Right ()
    | otherwise = Left err400{errBody = "start time must be before end time"}

maxEventTitleChars :: Int
maxEventTitleChars = 160

isUnsafeEventTitleChar :: Char -> Bool
isUnsafeEventTitleChar ch =
    isControl ch
        || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

validateEventCreateUpdateDimensions :: Maybe Int -> Maybe Int -> Maybe Int -> Either ServerError ()
validateEventCreateUpdateDimensions mPriceCents mCapacity mBudgetCents
    | maybe False (< 0) mPriceCents =
        Left err400{errBody = "event price must be >= 0"}
    | maybe False (< 0) mCapacity =
        Left err400{errBody = "event capacity must be >= 0"}
    | maybe False (< 0) mBudgetCents =
        Left err400{errBody = "event budget must be >= 0"}
    | otherwise =
        Right ()

validateVenueCreateUpdateFields ::
    T.Text ->
    Maybe Double ->
    Maybe Double ->
    Maybe Int ->
    Either ServerError ()
validateVenueCreateUpdateFields rawName mLat mLng mCapacity
    | T.null (T.strip rawName) =
        Left err400{errBody = "venue name is required"}
    | T.any isUnsafeVenueNameChar rawName =
        Left
            err400
                { errBody =
                    "venue name must not contain control characters or hidden formatting characters"
                }
    | maybe False (< 0) mCapacity =
        Left err400{errBody = "venue capacity must be >= 0"}
    | otherwise =
        validateVenueCoordinatePair mLat mLng

isUnsafeVenueNameChar :: Char -> Bool
isUnsafeVenueNameChar ch =
    isControl ch
        || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

validateVenueCoordinatePair :: Maybe Double -> Maybe Double -> Either ServerError ()
validateVenueCoordinatePair Nothing Nothing = Right ()
validateVenueCoordinatePair (Just lat) (Just lng)
    | isNaN lat || isInfinite lat =
        Left err400{errBody = "Invalid venue latitude"}
    | isNaN lng || isInfinite lng =
        Left err400{errBody = "Invalid venue longitude"}
    | lat < (-90) || lat > 90 =
        Left err400{errBody = "venue latitude must be between -90 and 90"}
    | lng < (-180) || lng > 180 =
        Left err400{errBody = "venue longitude must be between -180 and 180"}
    | otherwise =
        Right ()
validateVenueCoordinatePair _ _ =
    Left err400{errBody = "venue latitude and longitude must be provided together"}

validateEventCurrencyInput :: T.Text -> Maybe T.Text -> Either ServerError T.Text
validateEventCurrencyInput configuredDefault mCurrency =
    case cleanMaybeText mCurrency of
        Nothing ->
            maybe
                (Left err500{errBody = "Configured default currency is invalid"})
                Right
                (normalizeCurrencyCode configuredDefault)
        Just rawCurrency ->
            case normalizeCurrencyCode rawCurrency of
                Just currency -> Right currency
                Nothing -> Left err400{errBody = "eventCurrency must be a valid ISO 4217 code"}

normalizeEventCurrencyMaybe :: Maybe T.Text -> Maybe T.Text
normalizeEventCurrencyMaybe = (>>= normalizeEventCurrencyCode) . cleanMaybeText

normalizeEventCurrencyCode :: T.Text -> Maybe T.Text
normalizeEventCurrencyCode = normalizeCurrencyCode

normalizeCurrencyMaybe :: Maybe T.Text -> Maybe T.Text
normalizeCurrencyMaybe mCurrency = normalizeCurrency <$> cleanMaybeText mCurrency

validateFinanceEntryCurrencyInput :: T.Text -> T.Text -> Either ServerError T.Text
validateFinanceEntryCurrencyInput defaultCurrency rawCurrency =
    case cleanMaybeText (Just rawCurrency) of
        Nothing ->
            case normalizeEventCurrencyCode defaultCurrency of
                Just fallbackCurrency -> Right fallbackCurrency
                Nothing ->
                    Left
                        err409
                            { errBody =
                                "event default currency must be a 3-letter ISO code before finance entries can inherit it"
                            }
        Just providedCurrency ->
            case normalizeEventCurrencyCode providedCurrency of
                Just currency -> Right currency
                Nothing ->
                    Left err400{errBody = "finance entry currency must be a 3-letter ISO code"}

validateTicketTierCodeInput :: T.Text -> T.Text -> Either ServerError T.Text
validateTicketTierCodeInput rawTierName rawCode =
    let source = fromMaybe (T.strip rawTierName) (cleanMaybeText (Just rawCode))
        normalized = normalizeTicketTierCode source
     in if not (T.any isAlphaNum source)
            then Left err400{errBody = "ticket tier code must include at least one letter or digit"}
            else
                if T.length normalized > 64
                    then Left err400{errBody = "ticket tier code must be 64 characters or fewer"}
                    else Right normalized

validateTicketTierCurrencyInput :: T.Text -> T.Text -> Either ServerError T.Text
validateTicketTierCurrencyInput defaultCurrency rawCurrency =
    case cleanMaybeText (Just rawCurrency) of
        Nothing ->
            case normalizeEventCurrencyCode defaultCurrency of
                Just fallbackCurrency -> Right fallbackCurrency
                Nothing ->
                    Left
                        err409
                            { errBody =
                                "event default currency must be a 3-letter ISO code before ticket tiers can inherit it"
                            }
        Just providedCurrency ->
            case normalizeEventCurrencyCode providedCurrency of
                Just currency -> Right currency
                Nothing ->
                    Left err400{errBody = "ticket tier currency must be a 3-letter ISO code"}

normalizeBudgetLineType :: Maybe T.Text -> T.Text
normalizeBudgetLineType mType =
    case mType >>= parseBudgetLineType of
        Just lineTypeVal -> lineTypeVal
        Nothing -> "expense"

parseBudgetLineType :: T.Text -> Maybe T.Text
parseBudgetLineType raw =
    case T.toLower (T.strip raw) of
        "income" -> Just "income"
        "expense" -> Just "expense"
        _ -> Nothing

validateBudgetLineTypeInput :: T.Text -> Either ServerError T.Text
validateBudgetLineTypeInput raw =
    case parseBudgetLineType raw of
        Just lineTypeVal -> Right lineTypeVal
        Nothing -> Left err400{errBody = "budget line type must be income or expense"}

validateStoredBudgetLineDimensions :: EventBudgetLine -> Either T.Text (Int, T.Text)
validateStoredBudgetLineDimensions line = do
    lineTypeVal <-
        maybe
            (Left "Stored budget line type is invalid")
            Right
            (parseBudgetLineType (eventBudgetLineLineType line))
    if eventBudgetLinePlannedCents line < 0
        then Left "Stored budget line planned cents is invalid"
        else Right (eventBudgetLinePlannedCents line, lineTypeVal)

normalizeBudgetLineCode :: T.Text -> T.Text
normalizeBudgetLineCode raw =
    let upper = T.toUpper (T.strip raw)
        withDash = T.map (\c -> if c == ' ' then '-' else c) upper
        cleaned = T.filter (\c -> isAlphaNum c || c == '-' || c == '_') withDash
        chunks = filter (not . T.null) (T.splitOn "-" cleaned)
        normalized = T.intercalate "-" chunks
     in if T.null normalized then "LINE" else normalized

normalizeCategory :: Maybe T.Text -> T.Text
normalizeCategory mCategory =
    case fmap (T.toLower . T.strip) mCategory of
        Nothing -> "general"
        Just "" -> "general"
        Just v -> v

parseFinanceDirection :: T.Text -> Maybe T.Text
parseFinanceDirection raw =
    case T.toLower (T.strip raw) of
        "income" -> Just "income"
        "expense" -> Just "expense"
        _ -> Nothing

normalizeFinanceDirection :: Maybe T.Text -> T.Text
normalizeFinanceDirection mDirection =
    case mDirection >>= parseFinanceDirection of
        Just directionVal -> directionVal
        Nothing -> "expense"

normalizeFinanceSource :: Maybe T.Text -> T.Text
normalizeFinanceSource mSource =
    case mSource >>= parseFinanceSource of
        Just src -> src
        Nothing -> "manual"

parseFinanceSource :: T.Text -> Maybe T.Text
parseFinanceSource raw =
    case T.toLower (T.strip raw) of
        "ticket_sale" -> Just "ticket_sale"
        "ticket_refund" -> Just "ticket_refund"
        "sponsorship" -> Just "sponsorship"
        "vendor_payment" -> Just "vendor_payment"
        "merchandise" -> Just "merchandise"
        "operations" -> Just "operations"
        "manual" -> Just "manual"
        "other" -> Just "other"
        "contract_commitment" -> Just "contract_commitment"
        "contract_payment" -> Just "contract_payment"
        "purchase_order" -> Just "purchase_order"
        "purchase_payment" -> Just "purchase_payment"
        "asset_purchase" -> Just "asset_purchase"
        "liability_loan" -> Just "liability_loan"
        "liability_payment" -> Just "liability_payment"
        "accounts_receivable" -> Just "accounts_receivable"
        "accounts_receivable_collection" -> Just "accounts_receivable_collection"
        "accounts_receivable_settlement" -> Just "accounts_receivable_collection"
        _ -> Nothing

parseFinanceEntryStatus :: T.Text -> Maybe T.Text
parseFinanceEntryStatus raw =
    case T.toLower (T.strip raw) of
        "draft" -> Just "draft"
        "posted" -> Just "posted"
        "void" -> Just "void"
        "pending" -> Just "pending"
        _ -> Nothing

normalizeFinanceEntryStatus :: Maybe T.Text -> T.Text
normalizeFinanceEntryStatus mStatus =
    case mStatus >>= parseFinanceEntryStatus of
        Just statusVal -> statusVal
        Nothing -> "posted"

validateStoredFinanceEntryDimensions :: EventFinanceEntry -> Either T.Text (T.Text, T.Text, T.Text)
validateStoredFinanceEntryDimensions entry = do
    directionVal <-
        maybe
            (Left "Stored finance entry direction is invalid")
            Right
            (parseFinanceDirection (eventFinanceEntryDirection entry))
    sourceVal <-
        maybe
            (Left "Stored finance entry source is invalid")
            Right
            (parseFinanceSource (eventFinanceEntrySource entry))
    statusVal <-
        maybe
            (Left "Stored finance entry status is invalid")
            Right
            (parseFinanceEntryStatus (eventFinanceEntryStatus entry))
    _currencyVal <-
        maybe
            (Left "Stored finance entry currency is invalid")
            Right
            (normalizeEventCurrencyCode (eventFinanceEntryCurrency entry))
    if eventFinanceEntryAmountCents entry <= 0
        then Left "Stored finance entry amount is invalid"
        else pure ()
    pure (directionVal, sourceVal, statusVal)

normalizeFinanceDirectionInput :: T.Text -> AppM T.Text
normalizeFinanceDirectionInput raw =
    case parseFinanceDirection raw of
        Just directionVal -> pure directionVal
        Nothing -> throwError err400{errBody = "direction must be income or expense"}

normalizeFinanceSourceInput :: T.Text -> AppM T.Text
normalizeFinanceSourceInput raw =
    case parseFinanceSource raw of
        Just sourceVal -> pure sourceVal
        Nothing -> throwError err400{errBody = "Invalid finance source"}

normalizeFinanceEntryStatusInput :: T.Text -> AppM T.Text
normalizeFinanceEntryStatusInput raw =
    case parseFinanceEntryStatus raw of
        Just statusVal -> pure statusVal
        Nothing -> throwError err400{errBody = "Invalid finance status"}

normalizeFinanceDirectionFilter :: Maybe T.Text -> AppM (Maybe T.Text)
normalizeFinanceDirectionFilter Nothing = pure Nothing
normalizeFinanceDirectionFilter (Just raw) =
    case T.toLower (T.strip raw) of
        "" -> pure Nothing
        _ ->
            case parseFinanceDirection raw of
                Just directionVal -> pure (Just directionVal)
                Nothing -> throwError err400{errBody = "Invalid direction filter"}

normalizeFinanceSourceFilter :: Maybe T.Text -> AppM (Maybe T.Text)
normalizeFinanceSourceFilter Nothing = pure Nothing
normalizeFinanceSourceFilter (Just raw) =
    case T.strip raw of
        "" -> pure Nothing
        nonEmpty ->
            case parseFinanceSource nonEmpty of
                Just sourceVal -> pure (Just sourceVal)
                Nothing -> throwError err400{errBody = "Invalid source filter"}

normalizeFinanceEntryStatusFilter :: Maybe T.Text -> AppM (Maybe T.Text)
normalizeFinanceEntryStatusFilter Nothing = pure Nothing
normalizeFinanceEntryStatusFilter (Just raw) =
    case T.toLower (T.strip raw) of
        "" -> pure Nothing
        _ ->
            case parseFinanceEntryStatus raw of
                Just statusVal -> pure (Just statusVal)
                Nothing -> throwError err400{errBody = "Invalid status filter"}

parseTicketOrderStatus :: T.Text -> Maybe T.Text
parseTicketOrderStatus raw =
    case T.toLower (T.strip raw) of
        "pending" -> Just "pending"
        "paid" -> Just "paid"
        "cancelled" -> Just "cancelled"
        "canceled" -> Just "cancelled"
        "refunded" -> Just "refunded"
        _ -> Nothing

parseTicketStatus :: T.Text -> Maybe T.Text
parseTicketStatus raw =
    case T.toLower (T.strip raw) of
        "issued" -> Just "issued"
        "checked_in" -> Just "checked_in"
        "checkedin" -> Just "checked_in"
        "cancelled" -> Just "cancelled"
        "canceled" -> Just "cancelled"
        "refunded" -> Just "refunded"
        "refund_pending" -> Just "refund_pending"
        _ -> Nothing

-- | Parse event and invitation ids, returning a typed pair or an HTTP 400 error.
parseInvitationIdsEither :: T.Text -> T.Text -> Either ServerError (SocialEventId, EventInvitationId)
parseInvitationIdsEither eventIdStr invitationIdStr =
    case (parseInt64Either "event" eventIdStr, parseInt64Either "invitation" invitationIdStr) of
        (Right eventNum, Right invitationNum) -> Right (toSqlKey eventNum, toSqlKey invitationNum)
        _ -> Left err400{errBody = "Invalid event or invitation id"}

parseVenueIdEither :: T.Text -> Either ServerError VenueId
parseVenueIdEither =
    fmap toSqlKey . parseInt64Either "venue"

parseInt64Either :: T.Text -> T.Text -> Either ServerError Int64
parseInt64Either label raw =
    case normalizePositiveIdentifier raw of
        Just n -> Right n
        Nothing ->
            Left
                err400
                    { errBody = BL.fromStrict (TE.encodeUtf8 ("Invalid " <> label <> " id"))
                    }

parseDoubleEither :: T.Text -> T.Text -> Either ServerError Double
parseDoubleEither label raw =
    case readMaybe (T.unpack (T.strip raw)) :: Maybe Double of
        Just n
            | isNaN n || isInfinite n ->
                Left
                    err400
                        { errBody = BL.fromStrict (TE.encodeUtf8 ("Invalid " <> label))
                        }
            | otherwise -> Right n
        Nothing ->
            Left
                err400
                    { errBody = BL.fromStrict (TE.encodeUtf8 ("Invalid " <> label))
                    }

parseNearQueryEither :: T.Text -> Either ServerError (Double, Double, Double)
parseNearQueryEither raw =
    case map T.strip (T.splitOn "," raw) of
        [latRaw, lngRaw] -> do
            lat <- parseDoubleEither "near latitude" latRaw
            lng <- parseDoubleEither "near longitude" lngRaw
            validateCoordinates lat lng
            pure (lat, lng, 25)
        [latRaw, lngRaw, radiusRaw] -> do
            lat <- parseDoubleEither "near latitude" latRaw
            lng <- parseDoubleEither "near longitude" lngRaw
            radiusKm <- parseDoubleEither "near radiusKm" radiusRaw
            validateCoordinates lat lng
            validateRadius radiusKm
            pure (lat, lng, radiusKm)
        _ ->
            Left
                err400
                    { errBody = "near must use format lat,lng or lat,lng,radiusKm"
                    }

validateCoordinates :: Double -> Double -> Either ServerError ()
validateCoordinates lat lng
    | lat < (-90) || lat > 90 = Left err400{errBody = "near latitude must be between -90 and 90"}
    | lng < (-180) || lng > 180 = Left err400{errBody = "near longitude must be between -180 and 180"}
    | otherwise = Right ()

validateRadius :: Double -> Either ServerError ()
validateRadius radiusKm
    | radiusKm <= 0 = Left err400{errBody = "near radiusKm must be greater than 0"}
    | radiusKm > 1000 = Left err400{errBody = "near radiusKm exceeds allowed maximum"}
    | otherwise = Right ()

haversineDistanceKm :: Double -> Double -> Double -> Double -> Double
haversineDistanceKm lat1 lng1 lat2 lng2 =
    let earthRadiusKm = 6371
        dLat = degToRad (lat2 - lat1)
        dLng = degToRad (lng2 - lng1)
        lat1Rad = degToRad lat1
        lat2Rad = degToRad lat2
        a =
            (sin (dLat / 2) * sin (dLat / 2))
                + (cos lat1Rad * cos lat2Rad * sin (dLng / 2) * sin (dLng / 2))
        c = 2 * atan2 (sqrt a) (sqrt (1 - a))
     in earthRadiusKm * c

degToRad :: Double -> Double
degToRad deg = deg * pi / 180

parseKeyOr400 :: (ToBackendKey SqlBackend record) => T.Text -> T.Text -> AppM (Key record)
parseKeyOr400 label raw =
    case parseInt64Either label raw of
        Left e -> throwError e
        Right n -> pure (toSqlKey n)

renderPartyId :: AuthedUser -> T.Text
renderPartyId = renderKeyText . auPartyId

renderKeyText :: (ToBackendKey SqlBackend record) => Key record -> T.Text
renderKeyText = T.pack . show . fromSqlKey

cleanMaybeText :: Maybe T.Text -> Maybe T.Text
cleanMaybeText mVal =
    case fmap T.strip mVal of
        Just txt | not (T.null txt) -> Just txt
        _ -> Nothing

normalizeArtistGenres :: [T.Text] -> [T.Text]
normalizeArtistGenres rawGenres =
    reverse normalizedRev
  where
    (_, normalizedRev) = foldl' step (Set.empty, []) rawGenres

    step :: (Set.Set T.Text, [T.Text]) -> T.Text -> (Set.Set T.Text, [T.Text])
    step (seen, acc) rawGenre =
        case nonEmptyText rawGenre of
            Nothing -> (seen, acc)
            Just genreVal ->
                let dedupeKey = T.toCaseFold genreVal
                 in if Set.member dedupeKey seen
                        then (seen, acc)
                        else (Set.insert dedupeKey seen, genreVal : acc)

resolvePublishedArtistGenres
    :: [UUID.UUID]
    -> SqlPersistT IO (Either T.Text [(UUID.UUID, T.Text)])
resolvePublishedArtistGenres rawGenreIds
    | Set.size uniqueGenreIds /= length rawGenreIds =
        pure (Left "artistGenreIds must not contain duplicates")
    | otherwise = do
        resolved <- forM rawGenreIds $ \genreId -> do
            mGenre <- get (Catalog.GenreKey genreId)
            case mGenre of
                Nothing -> pure (Left ("Unknown genre id: " <> UUID.toText genreId))
                Just genre -> do
                    mCatalog <- get (Catalog.genreCatalogId genre)
                    mState <- get (Catalog.genreWorkflowStateId genre)
                    pure $
                        if Catalog.genreActive genre
                            && maybe False ((== "genres") . Catalog.catalogDefinitionCode) mCatalog
                            && maybe False
                                (\state -> Catalog.workflowStateActive state && Catalog.workflowStateCode state == "published")
                                mState
                            then Right (genreId, Catalog.genreNameEs genre)
                            else Left ("Genre is not active and published: " <> UUID.toText genreId)
        pure (sequence resolved)
  where
    uniqueGenreIds = Set.fromList rawGenreIds

loadArtistGenreSelections
    :: ArtistProfileId
    -> ArtistProfile
    -> SqlPersistT IO ([T.Text], [UUID.UUID])
loadArtistGenreSelections artistKey artist = do
    memberships <-
        selectList
            [ArtistGenreMembershipArtistId ==. artistKey]
            [Asc ArtistGenreMembershipSortOrder]
    if null memberships
        then do
            legacyRows <- selectList [ArtistGenreArtistId ==. artistKey] []
            pure (artistGenresFromRowsAndFallback legacyRows (artistProfileGenres artist), [])
        else do
            resolved <- forM memberships $ \(Entity _ membership) -> do
                let genreId = artistGenreMembershipGenreId membership
                mGenre <- get (Catalog.GenreKey genreId)
                pure (fmap (\genre -> (genreId, Catalog.genreNameEs genre)) mGenre)
            let available = catMaybes resolved
            pure (map snd available, map fst available)

invalidArtistGenreIdsError :: T.Text -> ServerError
invalidArtistGenreIdsError message =
    err400{errBody = BL.fromStrict (TE.encodeUtf8 message)}

artistGenresFromRowsAndFallback :: [Entity ArtistGenre] -> Maybe [T.Text] -> [T.Text]
artistGenresFromRowsAndFallback genreRows fallbackGenres =
    let normalizedFromRows = normalizeArtistGenres (map (artistGenreGenre . entityVal) genreRows)
        normalizedFallback = normalizeArtistGenres (fromMaybe [] fallbackGenres)
     in if null normalizedFromRows then normalizedFallback else normalizedFromRows

artistProfileToDTO ::
    ArtistProfileId ->
    ArtistProfile ->
    [T.Text] ->
    [UUID.UUID] ->
    Either ServerError ArtistDTO
artistProfileToDTO artistKey artist genreList genreIds = do
    socialLinks <-
        either (Left . storedArtistSocialLinksServerError) Right $
            decodeStoredArtistSocialLinks (artistProfileSocialLinks artist)
    Right
        ArtistDTO
            { artistId = Just (renderKeyText artistKey)
            , artistPartyId = artistProfilePartyId artist
            , artistName = artistProfileName artist
            , artistGenres = genreList
            , artistGenreIds = genreIds
            , artistBio = artistProfileBio artist
            , artistAvatarUrl = artistProfileAvatarUrl artist
            , artistSocialLinks = socialLinks
            , artistCreatedAt = Just (artistProfileCreatedAt artist)
            , artistUpdatedAt = Just (artistProfileUpdatedAt artist)
            }

storedArtistSocialLinksServerError :: T.Text -> ServerError
storedArtistSocialLinksServerError message =
    err500{errBody = BL.fromStrict (TE.encodeUtf8 message)}

resolveBudgetLineKey :: ConnectionPool -> SocialEventId -> Maybe T.Text -> AppM (Maybe EventBudgetLineId)
resolveBudgetLineKey _ _ Nothing = pure Nothing
resolveBudgetLineKey pool eventKey rawInput = do
    normalizedBudgetLineId <- either throwError pure (validateOptionalBudgetLineIdInput rawInput)
    case normalizedBudgetLineId of
        Nothing -> pure Nothing
        Just raw -> do
            lineKey <- parseKeyOr400 "budget line" raw
            mLine <- liftIO $ runSqlPool (get lineKey) pool
            lineRec <- maybe (throwError err404{errBody = "Budget line not found"}) pure mLine
            when (eventBudgetLineEventId lineRec /= eventKey) $
                throwError err400{errBody = "Budget line does not belong to this event"}
            pure (Just lineKey)

validateOptionalBudgetLineIdInput :: Maybe T.Text -> Either ServerError (Maybe T.Text)
validateOptionalBudgetLineIdInput Nothing = Right Nothing
validateOptionalBudgetLineIdInput (Just raw)
    | T.null stripped =
        Left
            err400
                { errBody = "budgetLineId must be omitted or null when no budget line should be linked"
                }
    | otherwise = Right (Just stripped)
  where
    stripped = T.strip raw

decodeStoredEventMetadata :: Maybe T.Text -> Either T.Text EventMetadataDTO
decodeStoredEventMetadata Nothing = Right emptyEventMetadata
decodeStoredEventMetadata (Just raw)
    | T.null (T.strip raw) = Right emptyEventMetadata
    | otherwise =
        case decodeStoredEventMetadataValue raw of
            Right metadata ->
                case duplicateTopLevelJsonKeys raw of
                    [] -> Right metadata
                    duplicates ->
                        Left
                            ( "Stored event metadata contains duplicate fields: "
                                <> T.intercalate ", " duplicates
                            )
            Left err -> Left (storedEventMetadataDecodeError err)

-- Only this stored-data decoder recognizes ingestion's private namespace. Public
-- request DTOs keep their strict allowlists, and output projections never expose it.
decodeStoredEventMetadataValue :: T.Text -> Either String EventMetadataDTO
decodeStoredEventMetadataValue raw = do
    value <- Aeson.eitherDecodeStrict' (TE.encodeUtf8 raw)
    publicValue <- case value of
        Aeson.Object fields -> case AesonKeyMap.lookup "_discoveryOwned" fields of
            Nothing -> Right value
            Just (Aeson.Object _) -> Right (Aeson.Object (AesonKeyMap.delete "_discoveryOwned" fields))
            Just _ -> Left "Stored event ownership evidence must be an object"
        _ -> Right value
    case Aeson.fromJSON publicValue of
        Aeson.Success metadata -> Right metadata
        Aeson.Error message -> Left message

duplicateTopLevelJsonKeys :: T.Text -> [T.Text]
duplicateTopLevelJsonKeys raw =
    nub
        [ key
        | key <- keys
        , length (filter (== key) keys) > 1
        ]
  where
    keys = topLevelJsonObjectKeys (T.unpack raw)

-- Aeson intentionally materializes objects as a key map, so duplicate key
-- spelling is no longer observable after decoding. Scan only the already
-- validated top-level object syntax and decode each key literal with Aeson so
-- escaped spellings compare exactly as the object decoder sees them.
topLevelJsonObjectKeys :: String -> [T.Text]
topLevelJsonObjectKeys = reverse . go (0 :: Int) False []
  where
    go _ _ keys [] = keys
    go depth expectsKey keys ('"' : rest) =
        let (literal, remaining) = takeJsonStringLiteral rest
            decodedKey =
                Aeson.eitherDecodeStrict' (TE.encodeUtf8 (T.pack literal))
                    :: Either String T.Text
            nextKeys =
                case (depth == 1 && expectsKey, decodedKey) of
                    (True, Right key) -> key : keys
                    _ -> keys
         in go depth False nextKeys remaining
    go depth _ keys ('{' : rest) =
        go (depth + 1) (depth == 0) keys rest
    go depth expectsKey keys ('[' : rest) =
        go (depth + 1) expectsKey keys rest
    go depth expectsKey keys ('}' : rest) =
        go (max 0 (depth - 1)) expectsKey keys rest
    go depth expectsKey keys (']' : rest) =
        go (max 0 (depth - 1)) expectsKey keys rest
    go 1 _ keys (',' : rest) = go 1 True keys rest
    go depth expectsKey keys (_ : rest) = go depth expectsKey keys rest

    takeJsonStringLiteral = consume ['"'] False
      where
        consume acc _ [] = (reverse acc, [])
        consume acc True (char : rest) = consume (char : acc) False rest
        consume acc False ('\\' : rest) = consume ('\\' : acc) True rest
        consume acc False ('"' : rest) = (reverse ('"' : acc), rest)
        consume acc False (char : rest) = consume (char : acc) False rest

storedEventMetadataDecodeError :: String -> T.Text
storedEventMetadataDecodeError rawError =
    case T.breakOn unknownFieldsPrefix (T.pack rawError) of
        (_, message) | not (T.null message) -> message
        _ -> "Stored event metadata is invalid JSON"
  where
    unknownFieldsPrefix = "Stored event metadata contains unknown fields:"

parseEventWorkflowStateId :: T.Text -> Either ServerError UUID.UUID
parseEventWorkflowStateId rawId =
    maybe
        (Left err400{errBody = "workflow_state_id must be a UUID"})
        Right
        (UUID.fromText (T.strip rawId))

validateEventReadOnlyProjectionOmitted :: EventDTO -> AppM ()
validateEventReadOnlyProjectionOmitted dto =
    when
        ( any
            isJust
            [ eventWorkflowStateCode dto
            , eventWorkflowStateNameEs dto
            , eventWorkflowStateNameEn dto
            ]
            || isJust (eventPublicListable dto)
            || isJust (eventTicketPurchaseEnabled dto)
        ) $
        throwError err400{errBody = "Workflow labels and capabilities are read-only"}

validateStoredEventFinanceMetadata :: T.Text -> SocialEvent -> Either T.Text (T.Text, Maybe Int)
validateStoredEventFinanceMetadata configuredDefault eventRec = do
    metadata <- decodeStoredEventMetadata (socialEventMetadata eventRec)
    currencyVal <-
        case emCurrency metadata of
            Nothing -> maybe (Left "Configured default currency is invalid") Right (normalizeCurrencyCode configuredDefault)
            Just rawCurrency ->
                maybe
                    (Left "Stored event currency is invalid")
                    Right
                    (normalizeEventCurrencyCode rawCurrency)
    budgetVal <-
        case emBudgetCents metadata of
            Just budgetCents
                | budgetCents < 0 ->
                    Left "Stored event budget is invalid"
            value -> Right value
    Right (currencyVal, budgetVal)

decodeStoredPromoCodeTierIds :: Maybe T.Text -> Maybe [T.Text]
decodeStoredPromoCodeTierIds rawTierIds = do
    tierIdsText <- rawTierIds
    Aeson.decodeStrict' (TE.encodeUtf8 tierIdsText)

encodePromoCodeTierIds :: Maybe [T.Text] -> Maybe T.Text
encodePromoCodeTierIds =
    fmap (TE.decodeUtf8 . BL.toStrict . Aeson.encode)

validatePromoCodeDateWindow :: UTCTime -> Maybe UTCTime -> Maybe UTCTime -> Either T.Text ()
validatePromoCodeDateWindow now mValidFrom mValidUntil =
    validateNotBefore *> validateNotExpired
  where
    validateNotBefore =
        maybe
            (Right ())
            ( \validFrom ->
                if now < validFrom
                    then Left "Promo code is not yet valid"
                    else Right ()
            )
            mValidFrom
    validateNotExpired =
        maybe
            (Right ())
            ( \validUntil ->
                if now > validUntil
                    then Left "Promo code has expired"
                    else Right ()
            )
            mValidUntil

validatePromoCodeRedemptionLimit :: Int -> Maybe Int -> Either T.Text ()
validatePromoCodeRedemptionLimit currentRedemptions =
    maybe
        (Right ())
        ( \maxRedemptions ->
            if currentRedemptions >= maxRedemptions
                then Left "Promo code redemption limit reached"
                else Right ()
        )

validatePromoCodeTierEligibility :: Maybe T.Text -> Maybe T.Text -> Either T.Text ()
validatePromoCodeTierEligibility mStoredTierIds mRequestedTierId =
    maybe (Right ()) validateStoredTierIds mStoredTierIds
  where
    validateStoredTierIds storedTierIds =
        decodePromoCodeTierIdsText storedTierIds >>= validateRequestedTier
    validateRequestedTier tierIds =
        maybe
            (Right ())
            ( \requestedTierId ->
                if requestedTierId `elem` tierIds
                    then Right ()
                    else Left "Promo code is not valid for this ticket tier"
            )
            mRequestedTierId

validatePromoCodeMinimumPurchaseParam :: Maybe Int -> Maybe T.Text -> Either T.Text ()
validatePromoCodeMinimumPurchaseParam mMinimumAmount mAmountText =
    maybe (Right ()) validateMinimum mMinimumAmount
  where
    validateMinimum minimumAmount =
        maybe
            (Right ())
            ( \amountText ->
                parsePromoCodePurchaseAmount amountText >>= validatePromoCodePurchaseAmountAtLeast minimumAmount
            )
            mAmountText

validatePromoCodeMinimumPurchaseCents :: Maybe Int -> Int -> Either T.Text ()
validatePromoCodeMinimumPurchaseCents mMinimumAmount amountCents =
    maybe
        (Right ())
        ( \minimumAmount ->
            if amountCents < minimumAmount
                then Left "Purchase amount does not meet minimum requirement"
                else Right ()
        )
        mMinimumAmount

validateTicketCheckoutAmount :: Int -> Int -> Either ServerError Int
validateTicketCheckoutAmount quantity unitPriceCents
    | quantity <= 0 = Left err400{errBody = "Quantity must be > 0"}
    | unitPriceCents < 0 =
        Left err500{errBody = "Stored ticket tier price is invalid"}
    | total > 99999999 =
        Left err400{errBody = "Ticket checkout amount exceeds Stripe's supported limit"}
    | otherwise = Right (fromInteger total)
  where
    total = toInteger quantity * toInteger unitPriceCents

promoCodeDiscountAmountEither :: Int -> T.Text -> Int -> Either T.Text Int
promoCodeDiscountAmountEither baseAmountCents discountType discountValue
    | discountValue < 0 =
        Left "Promo code discount value is invalid"
    | discountType == "percentage" =
        if discountValue > 10000
            then Left "Promo code percentage discount is invalid"
            else
                Right . fromInteger $
                    (toInteger baseAmountCents * toInteger discountValue) `div` 10000
    | discountType `elem` ["fixed_amount", "fixed"] =
        Right (min discountValue baseAmountCents)
    | otherwise =
        Left "Promo code discount type is invalid"

decodePromoCodeTierIdsText :: T.Text -> Either T.Text [T.Text]
decodePromoCodeTierIdsText storedTierIds =
    maybe
        (Left "Promo code tier restrictions are invalid")
        Right
        (Aeson.decodeStrict' (TE.encodeUtf8 storedTierIds))

parsePromoCodePurchaseAmount :: T.Text -> Either T.Text Int
parsePromoCodePurchaseAmount amountText =
    maybe
        (Left "Invalid amount")
        Right
        (readMaybe (T.unpack amountText))

validatePromoCodePurchaseAmountAtLeast :: Int -> Int -> Either T.Text ()
validatePromoCodePurchaseAmountAtLeast minimumAmount amount =
    if amount < minimumAmount
        then Left "Purchase amount does not meet minimum requirement"
        else Right ()

storedEventMetadataServerError :: T.Text -> ServerError
storedEventMetadataServerError message =
    err500{errBody = BL.fromStrict (TE.encodeUtf8 message)}

eventImageUploadFormServerError :: T.Text -> ServerError
eventImageUploadFormServerError message =
    err400{errBody = BL.fromStrict (TE.encodeUtf8 message)}

fallbackBudget :: Integer -> Maybe Integer
fallbackBudget plannedExpenseCents
    | plannedExpenseCents > 0 = Just plannedExpenseCents
    | otherwise = Nothing

normalizeCurrency :: T.Text -> T.Text
normalizeCurrency raw =
    T.toUpper (T.strip raw)

nonEmptyText :: T.Text -> Maybe T.Text
nonEmptyText txt =
    let trimmed = T.strip txt
     in if T.null trimmed then Nothing else Just trimmed

applyUploadExtension :: Maybe T.Text -> Maybe T.Text -> T.Text
applyUploadExtension name fallback =
    let resolved = fromMaybe "upload" name
        extFromFallback =
            case fallback of
                Nothing -> ""
                Just raw -> T.pack (takeExtension (T.unpack raw))
        extFromName = T.pack (takeExtension (T.unpack resolved))
     in if T.null extFromName && not (T.null extFromFallback)
            then resolved <> extFromFallback
            else resolved

sanitizeUploadFileName :: T.Text -> T.Text
sanitizeUploadFileName raw =
    let trimmed = T.strip raw
        baseName = T.pack (takeFileName (T.unpack trimmed))
        cleaned = T.map normalizeUploadChar baseName
        stripped = T.dropWhile (== '-') (T.dropWhileEnd (== '-') cleaned)
     in if T.null stripped || stripped == "." || stripped == ".."
            then "upload"
            else stripped

normalizeUploadChar :: Char -> Char
normalizeUploadChar ch
    | isAscii ch && isAlphaNum ch = ch
    | ch == '.' || ch == '-' || ch == '_' = ch
    | ch == ' ' = '-'
    | otherwise = '-'

buildUploadAssetUrl :: T.Text -> T.Text -> T.Text
buildUploadAssetUrl assetsBase relPath =
    let base = T.dropWhileEnd (== '/') assetsBase
        path = T.dropWhile (== '/') relPath
     in base <> "/" <> path

isImageUpload :: T.Text -> T.Text -> Bool
isImageUpload mimeType fileName
    | T.any isUnsafeUploadMetadataChar mimeType = False
    | otherwise =
        let normalizedMime = normalizeUploadMimeType mimeType
            ext = T.toLower (T.pack (takeExtension (T.unpack fileName)))
         in case normalizedMime of
                "image/jpeg" -> ext `elem` [".jpg", ".jpeg"]
                "image/png" -> ext == ".png"
                "image/webp" -> ext == ".webp"
                "image/gif" -> ext == ".gif"
                "image/bmp" -> ext == ".bmp"
                _ -> False

isUnsafeUploadMetadataChar :: Char -> Bool
isUnsafeUploadMetadataChar ch =
    isControl ch
        || generalCategory ch `elem` [Format, LineSeparator, ParagraphSeparator]

-- File signatures supplement MIME/extension and byte limits. No untrusted
-- document/SVG/HTML is accepted. Container validation is not transcoding.
validMomentMediaSignature :: T.Text -> BS.ByteString -> Bool
validMomentMediaSignature mime bytes = case normalizeUploadMimeType mime of
    "image/jpeg" -> BS.pack [255,216,255] `BS.isPrefixOf` bytes
    "image/png" -> BS.pack [137,80,78,71,13,10,26,10] `BS.isPrefixOf` bytes
    "image/gif" -> any (`BS.isPrefixOf` bytes) ["GIF87a","GIF89a"]
    "image/webp" -> riff && BS.take 4 (BS.drop 8 bytes) == "WEBP"
    "image/bmp" -> "BM" `BS.isPrefixOf` bytes
    "video/mp4" -> mp4
    "video/quicktime" -> mp4
    "audio/mp4" -> mp4
    "video/webm" -> BS.pack [26,69,223,163] `BS.isPrefixOf` bytes
    "audio/mpeg" -> "ID3" `BS.isPrefixOf` bytes || (BS.length bytes >= 2 && BS.head bytes == 255 && BS.index bytes 1 >= 224)
    "audio/wav" -> wav
    "audio/x-wav" -> wav
    "audio/ogg" -> "OggS" `BS.isPrefixOf` bytes
    "audio/flac" -> "fLaC" `BS.isPrefixOf` bytes
    _ -> False
  where
    riff = "RIFF" `BS.isPrefixOf` bytes
    wav = riff && BS.take 4 (BS.drop 8 bytes) == "WAVE"
    mp4 = BS.take 4 (BS.drop 4 bytes) == "ftyp"

maxEventImageUploadBytes :: Integer
maxEventImageUploadBytes = 10 * 1024 * 1024

validateEventImageUploadSize :: Integer -> Either ServerError ()
validateEventImageUploadSize size
    | size < 0 =
        Left err400{errBody = "event image upload size is invalid"}
    | size == 0 =
        Left err400{errBody = "event image upload must not be empty"}
    | size > maxEventImageUploadBytes =
        Left err400{errBody = "event image upload must be 10 MB or smaller"}
    | otherwise =
        Right ()

normalizeUploadMimeType :: T.Text -> T.Text
normalizeUploadMimeType raw =
    T.toLower (T.strip (fst (T.breakOn ";" raw)))

normalizeTicketTierCode :: T.Text -> T.Text
normalizeTicketTierCode raw =
    let upper = T.toUpper (T.strip raw)
        withDash = T.map (\c -> if c == ' ' then '-' else c) upper
        cleaned = T.filter (\c -> isAlphaNum c || c == '-' || c == '_') withDash
        chunks = filter (not . T.null) (T.splitOn "-" cleaned)
        normalized = T.intercalate "-" chunks
     in if T.null normalized then "GENERAL" else normalized

invalidSalesWindow :: Maybe UTCTime -> Maybe UTCTime -> Bool
invalidSalesWindow (Just startAt) (Just endAt) = startAt >= endAt
invalidSalesWindow _ _ = False

ticketTierAvailability :: EventTicketTier -> Int
ticketTierAvailability tier =
    max 0 (eventTicketTierQuantityTotal tier - eventTicketTierQuantitySold tier)

isTicketTierSaleOpen :: UTCTime -> EventTicketTier -> Bool
isTicketTierSaleOpen now tier =
    eventTicketTierIsActive tier
        && maybe True (<= now) (eventTicketTierSalesStart tier)
        && maybe True (>= now) (eventTicketTierSalesEnd tier)

isEventManager :: T.Text -> SocialEvent -> Bool
isEventManager currentParty eventRow =
    case cleanMaybeText (socialEventOrganizerPartyId eventRow) of
        Nothing -> False
        Just owner -> owner == currentParty

eventWithoutOrganizerError :: ServerError
eventWithoutOrganizerError =
    err403{errBody = "This event has no organizer; \
                    \a strict administrator must assign one by editing the event"}

eventNotOrganizerError :: ServerError
eventNotOrganizerError =
    err403{errBody = "Only the event organizer can manage this event"}

-- An event without an organizer is never taken by whoever reaches it first:
-- organizer-only routes refuse it and write nothing.
requireEventManager :: T.Text -> SocialEvent -> AppM SocialEvent
requireEventManager currentParty eventRow =
    case cleanMaybeText (socialEventOrganizerPartyId eventRow) of
        Just owner | owner == currentParty -> pure eventRow
        Just _ -> throwError eventNotOrganizerError
        Nothing -> throwError eventWithoutOrganizerError

-- The one assignment of a missing organizer. The caller has established that
-- the party may be assigned. Whether the field is empty is judged here with the
-- same rule as every other check (cleanMaybeText), and the update applies only
-- while the field still holds exactly the empty value that was read, so the
-- database decides between simultaneous callers, and the stored row, not an
-- earlier read, decides the outcome.
assignMissingEventOrganizer
    :: T.Text -> UTCTime -> SocialEventId -> SqlPersistT IO (Either ServerError SocialEvent)
assignMissingEventOrganizer party now eventKey = do
    before <- get eventKey
    case before of
        Just row | isNothing (cleanMaybeText (socialEventOrganizerPartyId row)) ->
            rawExecute
                "UPDATE social_event SET organizer_party_id = ?, updated_at = ? \
                \WHERE id = ? AND organizer_party_id IS NOT DISTINCT FROM ?"
                [ toPersistValue party, toPersistValue now, toPersistValue eventKey
                , toPersistValue (socialEventOrganizerPartyId row)
                ]
        _ -> pure ()
    stored <- get eventKey
    pure $ case stored of
        Nothing -> Left err404{errBody = "Event not found"}
        Just current
            | cleanMaybeText (socialEventOrganizerPartyId current) == Just party -> Right current
            | otherwise -> Left eventNotOrganizerError

loadEventArtists :: ConnectionPool -> SocialEventId -> AppM [ArtistDTO]
loadEventArtists pool eventKey = do
    loaded <-
        liftIO $
            runSqlPool
                ( do
                    artistLinks <- selectList [EventArtistEventId ==. eventKey] []
                    forM artistLinks $ \(Entity _ link) -> do
                        mArtist <- get (eventArtistArtistId link)
                        case mArtist of
                            Nothing ->
                                pure $
                                    Right
                                        ArtistDTO
                                            { artistId = Nothing
                                            , artistPartyId = Nothing
                                            , artistName = "(unknown)"
                                            , artistGenres = []
                                            , artistGenreIds = []
                                            , artistBio = Nothing
                                            , artistAvatarUrl = Nothing
                                            , artistSocialLinks = Nothing
                                            , artistCreatedAt = Nothing
                                            , artistUpdatedAt = Nothing
                                            }
                            Just a -> do
                                (genreList, genreIds) <- loadArtistGenreSelections (eventArtistArtistId link) a
                                pure (artistProfileToDTO (eventArtistArtistId link) a genreList genreIds)
                )
                pool
    either throwError pure (sequence loaded)

data EventWorkflowProjection = EventWorkflowProjection
    { ewpCode :: T.Text
    , ewpNameEs :: T.Text
    , ewpNameEn :: T.Text
    , ewpPublicListable :: Bool
    , ewpRsvpEligible :: Bool
    , ewpTicketPurchaseEnabled :: Bool
    }

loadSocialEventListDTOs ::
    T.Text ->
    ConnectionPool ->
    [Entity SocialEvent] ->
    AppM [EventDTO]
loadSocialEventListDTOs _ _ [] = pure []
loadSocialEventListDTOs configuredDefault pool eventRows = do
    let eventKeys = map entityKey eventRows
    (artistsResult, sourcesByEvent, workflowsById) <-
        liftIO $
            runSqlPool
                ( do
                    artists <- loadEventArtistsByEvent eventKeys
                    sources <- loadExternalEventSourcesByEvent eventKeys
                    workflows <- loadEventWorkflowProjections eventRows
                    pure (artists, sources, workflows)
                )
                pool
    artistsByEvent <- either throwError pure artistsResult
    either throwError pure $
        forM eventRows $ \(Entity eventKey eventRow) -> do
            _ <-
                either (Left . storedEventMetadataServerError) Right $
                    decodeStoredEventMetadata (socialEventMetadata eventRow)
            workflowStateId <-
                maybe
                    (Left err500{errBody = "Event has no canonical workflow state"})
                    Right
                    (socialEventWorkflowStateId eventRow)
            workflow <-
                maybe
                    (Left err500{errBody = "Event references an invalid workflow state"})
                    Right
                    (Map.lookup workflowStateId workflowsById)
            dto <-
                eventEntityToDTOWithWorkflow
                    configuredDefault
                    eventKey
                    eventRow
                    (Map.findWithDefault [] eventKey artistsByEvent)
                    workflow
            pure
                dto
                    { eventSources =
                        Just (Map.findWithDefault [] eventKey sourcesByEvent)
                    }

loadEventArtistsByEvent ::
    [SocialEventId] ->
    SqlPersistT IO (Either ServerError (Map.Map SocialEventId [ArtistDTO]))
loadEventArtistsByEvent [] = pure (Right Map.empty)
loadEventArtistsByEvent eventKeys = do
    artistLinks <- selectList [EventArtistEventId <-. eventKeys] []
    let artistKeys = nub (map (eventArtistArtistId . entityVal) artistLinks)
    if null artistKeys
        then pure (Right Map.empty)
        else do
            artistRows <- selectList [ArtistProfileId <-. artistKeys] []
            membershipRows <-
                selectList
                    [ArtistGenreMembershipArtistId <-. artistKeys]
                    [Asc ArtistGenreMembershipSortOrder]
            legacyGenreRows <- selectList [ArtistGenreArtistId <-. artistKeys] []
            let membershipGenreIds =
                    nub (map (artistGenreMembershipGenreId . entityVal) membershipRows)
            genreRows <-
                if null membershipGenreIds
                    then pure []
                    else
                        selectList
                            [Catalog.GenreId <-. map Catalog.GenreKey membershipGenreIds]
                            []
            let artistsById =
                    Map.fromList
                        [ (artistKey, artistRow)
                        | Entity artistKey artistRow <- artistRows
                        ]
                membershipsByArtist =
                    Map.fromListWith (flip (++))
                        [ (artistGenreMembershipArtistId membership, [membership])
                        | Entity _ membership <- membershipRows
                        ]
                legacyGenresByArtist =
                    Map.fromListWith (flip (++))
                        [ (artistGenreArtistId legacyGenre, [legacyGenreEntity])
                        | legacyGenreEntity@(Entity _ legacyGenre) <- legacyGenreRows
                        ]
                genresById =
                    Map.fromList
                        [ (genreId, genre)
                        | Entity (Catalog.GenreKey genreId) genre <- genreRows
                        ]
                artistDTOResultById =
                    Map.fromList
                        [ (artistKey, artistDTOFor artistKey)
                        | artistKey <- artistKeys
                        ]
                artistDTOFor artistKey =
                    case Map.lookup artistKey artistsById of
                        Nothing -> Right unknownArtistDTO
                        Just artist ->
                            let memberships =
                                    Map.findWithDefault [] artistKey membershipsByArtist
                                availableMemberships =
                                    mapMaybe
                                        ( \membership -> do
                                            genre <-
                                                Map.lookup
                                                    (artistGenreMembershipGenreId membership)
                                                    genresById
                                            pure
                                                ( artistGenreMembershipGenreId membership
                                                , Catalog.genreNameEs genre
                                                )
                                        )
                                        memberships
                                (genreList, genreIds)
                                    | null memberships =
                                        ( artistGenresFromRowsAndFallback
                                            (Map.findWithDefault [] artistKey legacyGenresByArtist)
                                            (artistProfileGenres artist)
                                        , []
                                        )
                                    | otherwise =
                                        (map snd availableMemberships, map fst availableMemberships)
                             in artistProfileToDTO artistKey artist genreList genreIds
                linkedArtistResults =
                    [ fmap
                        (\artistDTO -> (eventArtistEventId link, [artistDTO]))
                        (Map.findWithDefault (Right unknownArtistDTO) (eventArtistArtistId link) artistDTOResultById)
                    | Entity _ link <- artistLinks
                    ]
            pure $
                fmap
                    (Map.fromListWith (flip (++)))
                    (sequence linkedArtistResults)
  where
    unknownArtistDTO =
        ArtistDTO
            { artistId = Nothing
            , artistPartyId = Nothing
            , artistName = "(unknown)"
            , artistGenres = []
            , artistGenreIds = []
            , artistBio = Nothing
            , artistAvatarUrl = Nothing
            , artistSocialLinks = Nothing
            , artistCreatedAt = Nothing
            , artistUpdatedAt = Nothing
            }

loadExternalEventSourcesByEvent ::
    [SocialEventId] ->
    SqlPersistT IO (Map.Map SocialEventId [EventSourceDTO])
loadExternalEventSourcesByEvent [] = pure Map.empty
loadExternalEventSourcesByEvent eventKeys = do
    refs <- selectList [ExternalEventRefEventId <-. eventKeys] []
    let providerKeys = nub (map (externalEventRefProvider . entityVal) refs)
    sourceRows <-
        if null providerKeys
            then pure []
            else selectList [EventDiscoverySourceSourceKey <-. providerKeys] []
    let sourcesByKey =
            Map.fromList
                [ ( eventDiscoverySourceSourceKey source
                  , (eventDiscoverySourcePriority source, eventDiscoverySourceName source)
                  )
                | Entity _ source <- sourceRows
                ]
        rankedSourcesByEvent =
            Map.fromListWith (flip (++))
                [ ( externalEventRefEventId ref
                  , [ ( priority
                      , EventSourceDTO
                            { eventSourceProvider = externalEventRefProvider ref
                            , eventSourceLabel = label
                            , eventSourceUrl = externalEventRefSourceUrl ref
                            , eventSourcePriceCents = externalEventRefPriceCents ref
                            , eventSourceCurrency = externalEventRefCurrency ref
                            , eventSourceStatus = externalEventRefSourceStatus ref
                            }
                      )
                    ]
                  )
                | Entity _ ref <- refs
                , let (priority, label) =
                        Map.findWithDefault
                            (1000, externalEventRefProvider ref)
                            (externalEventRefProvider ref)
                            sourcesByKey
                ]
    pure (Map.map (map snd . sortOn (Down . fst)) rankedSourcesByEvent)

loadEventWorkflowProjections ::
    [Entity SocialEvent] ->
    SqlPersistT IO (Map.Map UUID.UUID EventWorkflowProjection)
loadEventWorkflowProjections eventRows = do
    let stateIds =
            nub (mapMaybe (socialEventWorkflowStateId . entityVal) eventRows)
        requestedStateIds = Set.fromList stateIds
    stateRows <-
        rawSql
            "SELECT state.id, state.code, state.name_es, state.name_en FROM workflow_state state JOIN workflow_definition workflow ON workflow.id=state.workflow_id WHERE workflow.code=? AND workflow.active=TRUE AND state.active=TRUE ORDER BY state.id"
            [PersistText EventLifecycle.socialEventWorkflowCode]
    capabilityRows <-
        rawSql
            "SELECT capability.state_id, capability.capability_code FROM workflow_state_capability capability JOIN workflow_state state ON state.id=capability.state_id JOIN workflow_definition workflow ON workflow.id=state.workflow_id WHERE workflow.code=? AND workflow.active=TRUE AND state.active=TRUE AND capability.enabled=TRUE AND capability.capability_code IN ('public-listable','rsvp','ticket-purchase') ORDER BY capability.state_id, capability.capability_code"
            [PersistText EventLifecycle.socialEventWorkflowCode]
    let typedStateRows =
            stateRows
                :: [(Single UUID.UUID, Single T.Text, Single T.Text, Single T.Text)]
        typedCapabilityRows =
            capabilityRows :: [(Single UUID.UUID, Single T.Text)]
        capabilitiesByState =
            Map.fromListWith Set.union
                [ ( stateId
                  , Set.singleton capabilityCode
                  )
                | (Single stateId, Single capabilityCode) <- typedCapabilityRows
                ]
    pure $
        Map.fromList
            [ ( stateId
              , EventWorkflowProjection
                    { ewpCode = stateCode
                    , ewpNameEs = nameEs
                    , ewpNameEn = nameEn
                    , ewpPublicListable =
                        "public-listable" `Set.member` capabilities
                    , ewpRsvpEligible =
                        "rsvp" `Set.member` capabilities
                    , ewpTicketPurchaseEnabled =
                        "ticket-purchase" `Set.member` capabilities
                    }
              )
            | (Single stateId, Single stateCode, Single nameEs, Single nameEn) <- typedStateRows
            , stateId `Set.member` requestedStateIds
            , let capabilities =
                    Map.findWithDefault
                        Set.empty
                        stateId
                        capabilitiesByState
            ]

redactMomentReactionIdentity :: T.Text -> EventMomentReactionDTO -> EventMomentReactionDTO
redactMomentReactionIdentity viewerPartyId reaction
    | emrPartyId reaction == Just viewerPartyId = reaction
    | otherwise = reaction {emrPartyId = Nothing, emrCreatedAt = Nothing}

momentReactionEntityToDTO :: T.Text -> Map.Map UUID.UUID Catalog.ReactionType -> Entity EventMomentReaction -> Maybe EventMomentReactionDTO
momentReactionEntityToDTO viewerPartyId reactionTypes (Entity _ reactionRow) = do
    reactionTypeId <- eventMomentReactionReactionTypeId reactionRow
    reactionType <- Map.lookup reactionTypeId reactionTypes
    pure $ redactMomentReactionIdentity viewerPartyId
        EventMomentReactionDTO
            { emrReactionTypeId = UUID.toText reactionTypeId
            , emrReactionCode = Catalog.reactionTypeCode reactionType
            , emrReactionNameEs = Catalog.reactionTypeNameEs reactionType
            , emrReactionNameEn = Catalog.reactionTypeNameEn reactionType
            , emrReactionEmoji = Catalog.reactionTypeEmoji reactionType
            , emrPartyId = Just (eventMomentReactionReactorPartyId reactionRow)
            , emrCreatedAt = Just (eventMomentReactionCreatedAt reactionRow)
            }

momentCommentEntityToDTO :: EventMomentCommentId -> EventMomentComment -> EventMomentCommentDTO
momentCommentEntityToDTO commentKey commentRow =
    EventMomentCommentDTO
        { emcId = Just (renderKeyText commentKey)
        , emcMomentId = Just (renderKeyText (eventMomentCommentMomentId commentRow))
        , emcAuthorPartyId = eventMomentCommentAuthorPartyId commentRow
        , emcAuthorName = eventMomentCommentAuthorName commentRow
        , emcBody = eventMomentCommentBody commentRow
        , emcCreatedAt = Just (eventMomentCommentCreatedAt commentRow)
        , emcUpdatedAt = Just (eventMomentCommentUpdatedAt commentRow)
        }

momentEntityToDTO ::
    EventMomentId ->
    EventMoment ->
    [EventMomentReactionDTO] ->
    [EventMomentCommentDTO] ->
    EventMomentDTO
momentEntityToDTO momentKey momentRow reactions comments =
    EventMomentDTO
        { emId = Just (renderKeyText momentKey)
        , emEventId = Just (renderKeyText (eventMomentEventId momentRow))
        , emAuthorPartyId = eventMomentAuthorPartyId momentRow
        , emAuthorName = eventMomentAuthorName momentRow
        , emCaption = eventMomentCaption momentRow
        , emMediaUrl = eventMomentMediaUrl momentRow
        , emMediaType =
            fromMaybe
                (eventMomentMediaType momentRow)
                (normalizeMomentMediaType (eventMomentMediaType momentRow))
        , emMediaWidth = eventMomentMediaWidth momentRow
        , emMediaHeight = eventMomentMediaHeight momentRow
        , emMediaDurationMs = eventMomentMediaDurationMs momentRow
        , emCreatedAt = Just (eventMomentCreatedAt momentRow)
        , emUpdatedAt = Just (eventMomentUpdatedAt momentRow)
        , emReactions = reactions
        , emComments = comments
        }

loadMomentDTO :: ConnectionPool -> T.Text -> EventMomentId -> IO EventMomentDTO
loadMomentDTO pool viewerPartyId momentKey =
    runSqlPool
        ( do
            mMoment <- get momentKey
            case mMoment of
                Nothing -> liftIO (ioError (userError "Moment not found"))
                Just momentRow -> do
                    canonical <- Interactions.momentPreview viewerPartyId (renderKeyText momentKey)
                    case canonical of
                        Just (reactions,comments) -> pure (momentEntityToDTO momentKey momentRow reactions comments)
                        Nothing -> do
                            reactionRows <- selectList [EventMomentReactionMomentId ==. momentKey] [Asc EventMomentReactionCreatedAt]
                            reactionTypes <- loadMomentReactionTypes reactionRows
                            commentRows <- selectList [EventMomentCommentMomentId ==. momentKey] [Asc EventMomentCommentCreatedAt]
                            let reactions = mapMaybe (momentReactionEntityToDTO viewerPartyId reactionTypes) reactionRows
                                comments = map (\(Entity commentKey commentRow) -> momentCommentEntityToDTO commentKey commentRow) commentRows
                            when (length reactions /= length reactionRows) $
                                liftIO (ioError (userError "Moment reaction is missing its canonical reaction type"))
                            pure (momentEntityToDTO momentKey momentRow reactions comments)
        )
        pool

loadEventMoments :: ConnectionPool -> T.Text -> SocialEventId -> IO [EventMomentDTO]
loadEventMoments pool viewerPartyId eventKey =
    runSqlPool
        ( do
            canonical <- Interactions.activated
            if canonical then do
                sources <- selectList [EventMomentEventId ==. eventKey] [Desc EventMomentCreatedAt]
                previews <- Interactions.momentPreviews viewerPartyId (map (renderKeyText . entityKey) sources)
                pure [ momentEntityToDTO key row reactions comments
                     | Entity key row <- sources
                     , Just (reactions, comments) <- [Map.lookup (renderKeyText key) previews]
                     ]
            else do
                momentRows <- selectList [EventMomentEventId ==. eventKey] [Desc EventMomentCreatedAt]
                let momentKeys = map entityKey momentRows
                reactionRows <- selectList [EventMomentReactionMomentId <-. momentKeys] [Asc EventMomentReactionCreatedAt]
                reactionTypes <- loadMomentReactionTypes reactionRows
                commentRows <- selectList [EventMomentCommentMomentId <-. momentKeys] [Asc EventMomentCommentCreatedAt]
                let reactionsByMoment = Map.fromListWith (<>)
                        [ ( eventMomentReactionMomentId reactionRow
                          , maybe [] pure (momentReactionEntityToDTO viewerPartyId reactionTypes reactionEntity)
                          )
                        | reactionEntity@(Entity _ reactionRow) <- reactionRows
                        ]
                    commentsByMoment = Map.fromListWith (<>)
                        [ ( eventMomentCommentMomentId commentRow
                          , [momentCommentEntityToDTO commentKey commentRow]
                          )
                        | Entity commentKey commentRow <- commentRows
                        ]
                    canonicalReactionCount = sum (map length (Map.elems reactionsByMoment))
                when (canonicalReactionCount /= length reactionRows) $
                    liftIO (ioError (userError "Moment reaction is missing its canonical reaction type"))
                pure
                    [ momentEntityToDTO
                        momentKey
                        momentRow
                        (Map.findWithDefault [] momentKey reactionsByMoment)
                        (Map.findWithDefault [] momentKey commentsByMoment)
                    | Entity momentKey momentRow <- momentRows
                    ]
        )
        pool

loadMomentReactionTypes :: [Entity EventMomentReaction] -> SqlPersistT IO (Map.Map UUID.UUID Catalog.ReactionType)
loadMomentReactionTypes reactionRows = do
    let reactionTypeIds = nub (catMaybes (map (eventMomentReactionReactionTypeId . entityVal) reactionRows))
    rows <- selectList [Catalog.ReactionTypeId <-. map Catalog.ReactionTypeKey reactionTypeIds] []
    pure (Map.fromList [(reactionTypeId, reactionType) | Entity (Catalog.ReactionTypeKey reactionTypeId) reactionType <- rows])

liveBroadcastEntityToDTO ::
    ConnectionPool ->
    EventLiveBroadcastId ->
    EventLiveBroadcast ->
    IO EventLiveBroadcastDTO
liveBroadcastEntityToDTO pool broadcastKey broadcastRow =
    runSqlPool
        ( do
            mArtist <- get (eventLiveBroadcastArtistId broadcastRow)
            let artistName = maybe "Artista" artistProfileName mArtist
            pure
                EventLiveBroadcastDTO
                    { elbId = Just (renderKeyText broadcastKey)
                    , elbEventId = Just (renderKeyText (eventLiveBroadcastEventId broadcastRow))
                    , elbArtistId = renderKeyText (eventLiveBroadcastArtistId broadcastRow)
                    , elbArtistName = artistName
                    , elbBroadcasterName = eventLiveBroadcastBroadcasterName broadcastRow
                    , elbBroadcasterPartyId = Just (eventLiveBroadcastBroadcasterPartyId broadcastRow)
                    , elbTitle = eventLiveBroadcastTitle broadcastRow
                    , elbDescription = eventLiveBroadcastDescription broadcastRow
                    , elbStatus = eventLiveBroadcastStatus broadcastRow
                    , elbPlaybackUrl = Nothing
                    , elbIngestUrl = Nothing
                    , elbWhipUrl = Nothing
                    , elbStreamKey = Nothing
                    , elbViewerCount = eventLiveBroadcastViewerCount broadcastRow
                    , elbStartedAt = Just (eventLiveBroadcastStartedAt broadcastRow)
                    , elbEndedAt = eventLiveBroadcastEndedAt broadcastRow
                    , elbLastHeartbeatAt = Just (eventLiveBroadcastLastHeartbeatAt broadcastRow)
                    }
        )
        pool

loadLiveBroadcastDTO :: ConnectionPool -> EventLiveBroadcastId -> IO EventLiveBroadcastDTO
loadLiveBroadcastDTO pool broadcastKey =
    runSqlPool
        ( do
            mBroadcast <- get broadcastKey
            maybe
                (liftIO (ioError (userError "Live broadcast not found")))
                (\broadcastRow -> liftIO (liveBroadcastEntityToDTO pool broadcastKey broadcastRow))
                mBroadcast
        )
        pool

canAccessLiveBroadcast :: ConnectionPool -> T.Text -> EventLiveBroadcast -> IO Bool
canAccessLiveBroadcast pool partyId broadcastRow =
    if eventLiveBroadcastBroadcasterPartyId broadcastRow == partyId
        then pure True
        else do
            mFollow <-
                runSqlPool
                    (get (ArtistFollowKey (eventLiveBroadcastArtistId broadcastRow) partyId))
                    pool
            pure (isJust mFollow)

loadExternalEventSources ::
    ConnectionPool ->
    SocialEventId ->
    IO [EventSourceDTO]
loadExternalEventSources pool eventKey =
    runSqlPool
        (do
            refs <- selectList [ExternalEventRefEventId ==. eventKey] []
            ranked <-
                forM refs $ \(Entity _ ref) -> do
                    source <- getBy (UniqueEventDiscoverySource (externalEventRefProvider ref))
                    let (priority, label) =
                            case source of
                                Just (Entity _ sourceRow) ->
                                    ( eventDiscoverySourcePriority sourceRow
                                    , eventDiscoverySourceName sourceRow
                                    )
                                Nothing -> (1000, externalEventRefProvider ref)
                    pure
                        ( priority
                        , EventSourceDTO
                            { eventSourceProvider = externalEventRefProvider ref
                            , eventSourceLabel = label
                            , eventSourceUrl = externalEventRefSourceUrl ref
                            , eventSourcePriceCents = externalEventRefPriceCents ref
                            , eventSourceCurrency = externalEventRefCurrency ref
                            , eventSourceStatus = externalEventRefSourceStatus ref
                            }
                        )
            pure (map snd (sortOn (negate . fst) ranked))
        )
        pool

selectUnsuppressedSocialEvents ::
    [Filter SocialEvent] ->
    SelectOpt SocialEvent ->
    Int ->
    Int ->
    SqlPersistT IO [Entity SocialEvent]
selectUnsuppressedSocialEvents filters dateOrder limit offset = do
    backend <- ask :: SqlPersistT IO SqlBackend
    eventTable <- getEscapedRawName "social_event"
    externalRefTable <- getEscapedRawName "external_event_ref"
    eventIdField <- getEscapedRawName "id"
    externalRefEventIdField <- getEscapedRawName "event_id"
    externalRefSourceStatusField <- getEscapedRawName "source_status"
    let (baseFilterClause, filterValues) =
            filterClauseWithVals (Just PrefixTableName) backend filters
        eventIdColumn = eventTable <> "." <> eventIdField
        externalRefEventIdColumn =
            externalRefTable <> "." <> externalRefEventIdField
        externalRefSourceStatusColumn =
            externalRefTable <> "." <> externalRefSourceStatusField
        suppressionClause =
            "NOT EXISTS (SELECT 1 FROM "
                <> externalRefTable
                <> " WHERE "
                <> externalRefEventIdColumn
                <> "="
                <> eventIdColumn
                <> " AND lower(trim("
                <> externalRefSourceStatusColumn
                <> "))=?)"
        combinedFilterClause
            | T.null baseFilterClause = " WHERE " <> suppressionClause
            | otherwise = baseFilterClause <> " AND " <> suppressionClause
        orderedQuery =
            "SELECT ?? FROM "
                <> eventTable
                <> combinedFilterClause
                <> orderClause (Just PrefixTableName) backend [dateOrder, Asc SocialEventId]
    query <- getConnLimitOffset (limit, offset) orderedQuery
    rawSql query (filterValues <> [PersistText externalEventRefSuppressedStatus])

selectVisibleSocialEvents ::
    [Filter SocialEvent] ->
    SelectOpt SocialEvent ->
    Int ->
    Int ->
    SqlPersistT IO [Entity SocialEvent]
selectVisibleSocialEvents filters dateOrder limit offset = do
    backend <- ask :: SqlPersistT IO SqlBackend
    eventTable <- getEscapedRawName "social_event"
    externalRefTable <- getEscapedRawName "external_event_ref"
    eventIdField <- getEscapedRawName "id"
    eventMetadataField <- getEscapedRawName "metadata"
    externalRefEventIdField <- getEscapedRawName "event_id"
    backendName <- T.toCaseFold <$> getRDBMS
    let (baseFilterClause, filterValues) =
            filterClauseWithVals (Just PrefixTableName) backend filters
        eventIdColumn = eventTable <> "." <> eventIdField
        eventMetadataColumn =
            eventTable <> "." <> eventMetadataField
        externalRefEventIdColumn =
            externalRefTable <> "." <> externalRefEventIdField
        visibilityClause =
            "(NOT EXISTS (SELECT 1 FROM "
                <> externalRefTable
                <> " WHERE "
                <> externalRefEventIdColumn
                <> "="
                <> eventIdColumn
                <> ") OR "
                <> visibleImportedMetadataClause backendName eventMetadataColumn
                <> ")"
        combinedFilterClause
            | T.null baseFilterClause = " WHERE " <> visibilityClause
            | otherwise = baseFilterClause <> " AND " <> visibilityClause
        orderedQuery =
            "SELECT ?? FROM "
                <> eventTable
                <> combinedFilterClause
                <> orderClause (Just PrefixTableName) backend [dateOrder, Asc SocialEventId]
    query <- getConnLimitOffset (limit, offset) orderedQuery
    rawSql query filterValues

-- Keep the imported-event visibility predicate correlated with each candidate
-- row. This avoids expanding the complete retained import history into a NOT IN
-- parameter list on every page request. Both supported databases validate the
-- complete canonical metadata shape before reading isPublic, so malformed or
-- unsupported metadata fails closed.
visibleImportedMetadataClause :: T.Text -> T.Text -> T.Text
visibleImportedMetadataClause backendName metadataColumn
    | "postgres" `T.isInfixOf` backendName = postgresVisibleImportedMetadataClause metadataColumn
    | "sqlite" `T.isInfixOf` backendName = sqliteVisibleImportedMetadataClause metadataColumn
    | otherwise = "1=0"

sqliteVisibleImportedMetadataClause :: T.Text -> T.Text
sqliteVisibleImportedMetadataClause metadataColumn =
    "CASE"
        <> " WHEN "
        <> metadataColumn
        <> " IS NULL OR trim("
        <> metadataColumn
        <> ")='' THEN 1"
        <> " WHEN NOT json_valid("
        <> metadataColumn
        <> ") THEN 0"
        <> " ELSE json_type("
        <> metadataColumn
        <> ")='object'"
        <> " AND NOT EXISTS (SELECT 1 FROM json_each("
        <> metadataColumn
        <> ") AS metadata_field WHERE metadata_field.key"
        <> " NOT IN ('ticketUrl','imageUrl','isPublic','currency','budgetCents','_discoveryOwned'))"
        <> " AND (SELECT count(*) FROM json_each("
        <> metadataColumn
        <> "))=(SELECT count(DISTINCT metadata_field.key) FROM json_each("
        <> metadataColumn
        <> ") AS metadata_field)"
        <> " AND (json_type("
        <> metadataColumn
        <> ",'$._discoveryOwned') IS NULL OR json_type("
        <> metadataColumn
        <> ",'$._discoveryOwned')='object')"
        <> sqliteOptionalMetadataType metadataColumn "ticketUrl" "text"
        <> sqliteOptionalMetadataType metadataColumn "imageUrl" "text"
        <> sqliteOptionalMetadataType metadataColumn "currency" "text"
        <> sqliteOptionalIntegralMetadataType metadataColumn "budgetCents"
        <> " AND (json_type("
        <> metadataColumn
        <> ",'$.isPublic') IS NULL OR json_type("
        <> metadataColumn
        <> ",'$.isPublic') IN ('null','true'))"
        <> " END"

sqliteOptionalMetadataType :: T.Text -> T.Text -> T.Text -> T.Text
sqliteOptionalMetadataType metadataColumn fieldName expectedType =
    " AND (json_type("
        <> metadataColumn
        <> ",'$."
        <> fieldName
        <> "') IS NULL OR json_type("
        <> metadataColumn
        <> ",'$."
        <> fieldName
        <> "') IN ('null','"
        <> expectedType
        <> "'))"

sqliteOptionalIntegralMetadataType :: T.Text -> T.Text -> T.Text
sqliteOptionalIntegralMetadataType metadataColumn fieldName =
    " AND ("
        <> fieldType
        <> " IS NULL OR "
        <> fieldType
        <> "='null' OR ("
        <> fieldType
        <> " IN ('integer','real') AND "
        <> sqliteJsonNumberFitsInt64 metadataColumn fieldName
        <> "))"
  where
    fieldPath = "'$." <> fieldName <> "'"
    fieldType = "json_type(" <> metadataColumn <> "," <> fieldPath <> ")"

-- SQLite exposes JSON real numbers as binary doubles, which cannot distinguish
-- every Int64 or preserve large fractional tokens. Parse the original JSON
-- number text into a decimal coefficient and scale so visibility follows
-- Aeson's exact Int decoder at both fractional and 64-bit boundaries.
sqliteJsonNumberFitsInt64 :: T.Text -> T.Text -> T.Text
sqliteJsonNumberFitsInt64 metadataColumn fieldName =
    "EXISTS (WITH number_token(value) AS (SELECT lower("
        <> metadataColumn
        <> "->"
        <> fieldPath
        <> ")), number_parts(value,mantissa,exponent_value) AS (SELECT value,"
        <> "CASE WHEN instr(value,'e')=0 THEN value ELSE substr(value,1,instr(value,'e')-1) END,"
        <> "CASE WHEN instr(value,'e')=0 THEN 0 ELSE CAST(substr(value,instr(value,'e')+1) AS INTEGER) END"
        <> " FROM number_token), scaled_number(value,coefficient,decimal_scale) AS (SELECT value,"
        <> "replace(ltrim(mantissa,'-'),'.',''),"
        <> "(CASE WHEN instr(ltrim(mantissa,'-'),'.')=0 THEN 0 ELSE length(ltrim(mantissa,'-'))"
        <> "-instr(ltrim(mantissa,'-'),'.') END)-exponent_value FROM number_parts),"
        <> " integral_number(value,coefficient,decimal_scale,significant_coefficient) AS (SELECT value,"
        <> "coefficient,decimal_scale,ltrim(coefficient,'0') FROM scaled_number),"
        <> " bounded_number(value,significant_coefficient,integer_digit_count,integer_digits,max_abs) AS (SELECT value,"
        <> "significant_coefficient,length(significant_coefficient)-decimal_scale,"
        <> "CASE WHEN decimal_scale>=0 THEN substr(significant_coefficient,1,length(significant_coefficient)-decimal_scale)"
        <> " ELSE significant_coefficient||substr('0000000000000000000',1,-decimal_scale) END,"
        <> "CASE WHEN substr(value,1,1)='-' THEN '9223372036854775808' ELSE '9223372036854775807' END"
        <> " FROM integral_number WHERE significant_coefficient='' OR decimal_scale<=0 OR decimal_scale"
        <> "<=length(coefficient)-length(rtrim(coefficient,'0'))) SELECT 1 FROM bounded_number"
        <> " WHERE significant_coefficient='' OR integer_digit_count<19 OR (integer_digit_count=19"
        <> " AND integer_digits<=max_abs COLLATE BINARY))"
  where
    fieldPath = "'$." <> fieldName <> "'"

postgresVisibleImportedMetadataClause :: T.Text -> T.Text
postgresVisibleImportedMetadataClause metadataColumn =
    "CASE"
        <> " WHEN "
        <> metadataColumn
        <> " IS NULL OR btrim("
        <> metadataColumn
        <> ")='' THEN TRUE"
        <> " WHEN NOT pg_input_is_valid("
        <> metadataColumn
        <> ",'jsonb') THEN FALSE"
        <> " ELSE jsonb_typeof("
        <> jsonMetadata
        <> ")='object'"
        <> " AND (SELECT count(*) FROM json_each(("
        <> metadataColumn
        <> ")::json))=(SELECT count(DISTINCT metadata_field.key) FROM json_each(("
        <> metadataColumn
        <> ")::json) AS metadata_field)"
        <> " AND NOT EXISTS (SELECT 1 FROM jsonb_object_keys("
        <> jsonMetadata
        <> ") AS metadata_key WHERE metadata_key"
        <> " NOT IN ('ticketUrl','imageUrl','isPublic','currency','budgetCents','_discoveryOwned'))"
        <> " AND (jsonb_typeof("
        <> jsonMetadata
        <> "->'_discoveryOwned') IS NULL OR jsonb_typeof("
        <> jsonMetadata
        <> "->'_discoveryOwned')='object')"
        <> postgresOptionalMetadataType jsonMetadata "ticketUrl" "string"
        <> postgresOptionalMetadataType jsonMetadata "imageUrl" "string"
        <> postgresOptionalMetadataType jsonMetadata "currency" "string"
        <> postgresOptionalIntegralMetadataType jsonMetadata "budgetCents"
        <> " AND (jsonb_typeof("
        <> jsonMetadata
        <> "->'isPublic') IS NULL OR jsonb_typeof("
        <> jsonMetadata
        <> "->'isPublic')='null' OR "
        <> jsonMetadata
        <> "->'isPublic'='true'::jsonb)"
        <> " END"
  where
    jsonMetadata = "(" <> metadataColumn <> ")::jsonb"

postgresOptionalMetadataType :: T.Text -> T.Text -> T.Text -> T.Text
postgresOptionalMetadataType jsonMetadata fieldName expectedType =
    " AND (jsonb_typeof("
        <> jsonMetadata
        <> "->'"
        <> fieldName
        <> "') IS NULL OR jsonb_typeof("
        <> jsonMetadata
        <> "->'"
        <> fieldName
        <> "') IN ('null','"
        <> expectedType
        <> "'))"

postgresOptionalIntegralMetadataType :: T.Text -> T.Text -> T.Text
postgresOptionalIntegralMetadataType jsonMetadata fieldName =
    " AND ("
        <> fieldType
        <> " IS NULL OR "
        <> fieldType
        <> "='null' OR CASE WHEN "
        <> fieldType
        <> "='number' THEN "
        <> numericValue
        <> "=trunc("
        <> numericValue
        <> ") AND "
        <> numericValue
        <> " BETWEEN -9223372036854775808 AND 9223372036854775807 ELSE FALSE END)"
  where
    fieldValue = jsonMetadata <> "->'" <> fieldName <> "'"
    fieldType = "jsonb_typeof(" <> fieldValue <> ")"
    numericValue = "(" <> jsonMetadata <> "->>'" <> fieldName <> "')::numeric"

isImportedEventHidden :: SocialEventId -> SqlPersistT IO Bool
isImportedEventHidden eventKey = do
    rows <-
        rawSql
            "SELECT social_event.metadata\
            \ FROM social_event\
            \ INNER JOIN external_event_ref\
            \ ON external_event_ref.event_id=social_event.id\
            \ WHERE social_event.id=?\
            \ LIMIT 1"
            [toPersistValue eventKey]
    pure $
        case rows of
            Single metadata : _ -> importedEventMetadataHidden metadata
            [] -> False

importedEventMetadataHidden :: Maybe T.Text -> Bool
importedEventMetadataHidden storedMetadata =
    case decodeStoredEventMetadata storedMetadata of
        Left _ -> True
        Right metadata -> emIsPublic metadata == Just False

eventEntityToDTO :: T.Text -> SocialEventId -> SocialEvent -> [ArtistDTO] -> SqlPersistT IO (Either ServerError EventDTO)
eventEntityToDTO configuredDefault eid eventRow artists = do
    case decodeStoredEventMetadata (socialEventMetadata eventRow) of
      Left message -> pure (Left (storedEventMetadataServerError message))
      Right _ -> case socialEventWorkflowStateId eventRow of
        Nothing -> pure (Left err500{errBody = "Event has no canonical workflow state"})
        Just workflowStateId -> do
          workflowState <- EventLifecycle.loadActiveSocialEventState workflowStateId
          case workflowState of
            Nothing -> pure (Left err500{errBody = "Event references an invalid workflow state"})
            Just (stateCode, nameEs, nameEn) -> do
              publicListable <- EventLifecycle.socialEventStateHasCapability workflowStateId "public-listable"
              rsvpEligible <- EventLifecycle.socialEventStateHasCapability workflowStateId "rsvp"
              ticketPurchaseEnabled <- EventLifecycle.socialEventStateHasCapability workflowStateId "ticket-purchase"
              pure $
                eventEntityToDTOWithWorkflow
                  configuredDefault
                  eid
                  eventRow
                  artists
                  EventWorkflowProjection
                    { ewpCode = stateCode
                    , ewpNameEs = nameEs
                    , ewpNameEn = nameEn
                    , ewpPublicListable = publicListable
                    , ewpRsvpEligible = rsvpEligible
                    , ewpTicketPurchaseEnabled = ticketPurchaseEnabled
                    }

eventEntityToDTOWithWorkflow ::
    T.Text ->
    SocialEventId ->
    SocialEvent ->
    [ArtistDTO] ->
    EventWorkflowProjection ->
    Either ServerError EventDTO
eventEntityToDTOWithWorkflow configuredDefault eid eventRow artists workflow = do
    metadata <-
        either (Left . storedEventMetadataServerError) Right $
            decodeStoredEventMetadata (socialEventMetadata eventRow)
    workflowStateId <-
        maybe
            (Left err500{errBody = "Event has no canonical workflow state"})
            Right
            (socialEventWorkflowStateId eventRow)
    Right
        EventDTO
            { eventId = Just (renderKeyText eid)
            , eventOrganizerPartyId = socialEventOrganizerPartyId eventRow
            , eventTitle = socialEventTitle eventRow
            , eventDescription = socialEventDescription eventRow
            , eventStart = socialEventStartTime eventRow
            , eventEnd = socialEventEndTime eventRow
            , eventTimezone = socialEventTimezone eventRow
            , eventVenueId = fmap renderKeyText (socialEventVenueId eventRow)
            , eventPriceCents = socialEventPriceCents eventRow
            , eventCapacity = socialEventCapacity eventRow
            , eventTicketUrl = emTicketUrl metadata
            , eventImageUrl = emImageUrl metadata
            , eventIsPublic = emIsPublic metadata <|> Just True
            , eventTypeId = UUID.toText <$> socialEventEventTypeId eventRow
            , eventWorkflowStateId = Just (UUID.toText workflowStateId)
            , eventWorkflowStateCode = Just (ewpCode workflow)
            , eventWorkflowStateNameEs = Just (ewpNameEs workflow)
            , eventWorkflowStateNameEn = Just (ewpNameEn workflow)
            , eventPublicListable = Just (ewpPublicListable workflow)
            , eventRsvpEligible = Just (ewpRsvpEligible workflow)
            , eventTicketPurchaseEnabled = Just (ewpTicketPurchaseEnabled workflow)
            , eventCurrency = emCurrency metadata <|> Just configuredDefault
            , eventBudgetCents = emBudgetCents metadata
            , eventSources = Nothing
            , eventCreatedAt = Just (socialEventCreatedAt eventRow)
            , eventUpdatedAt = Just (socialEventUpdatedAt eventRow)
            , eventArtists = artists
            }

ticketTierEntityToDTO :: SocialEventId -> Entity EventTicketTier -> TicketTierDTO
ticketTierEntityToDTO eventKey (Entity tierKey tier) =
    TicketTierDTO
        { ticketTierId = Just (renderKeyText tierKey)
        , ticketTierEventId = Just (renderKeyText eventKey)
        , ticketTierCode = eventTicketTierCode tier
        , ticketTierName = eventTicketTierName tier
        , ticketTierDescription = eventTicketTierDescription tier
        , ticketTierPriceCents = eventTicketTierPriceCents tier
        , ticketTierCurrency = eventTicketTierCurrency tier
        , ticketTierQuantityTotal = eventTicketTierQuantityTotal tier
        , ticketTierQuantitySold = eventTicketTierQuantitySold tier
        , ticketTierSalesStart = eventTicketTierSalesStart tier
        , ticketTierSalesEnd = eventTicketTierSalesEnd tier
        , ticketTierActive = eventTicketTierIsActive tier
        , ticketTierPosition = eventTicketTierPosition tier
        }

ticketEntityToDTO :: Entity EventTicket -> TicketDTO
ticketEntityToDTO (Entity ticketKey ticketRow) =
    TicketDTO
        { ticketId = Just (renderKeyText ticketKey)
        , ticketEventId = Just (renderKeyText (eventTicketEventId ticketRow))
        , ticketTierId = Just (renderKeyText (eventTicketTierRefId ticketRow))
        , ticketOrderId = Just (renderKeyText (eventTicketOrderRefId ticketRow))
        , ticketCode = eventTicketCode ticketRow
        , ticketStatus = normalizeTicketStatus (Just (eventTicketStatus ticketRow))
        , ticketHolderName = if Transfer.retainedByBuyer ticketRow then eventTicketHolderName ticketRow else eventTicketCurrentHolderName ticketRow
        , ticketHolderEmail = if Transfer.retainedByBuyer ticketRow then eventTicketHolderEmail ticketRow else eventTicketCurrentHolderEmail ticketRow
        , ticketCheckedInAt = eventTicketCheckedInAt ticketRow
        , ticketCreatedAt = Just (eventTicketCreatedAt ticketRow)
        , ticketUpdatedAt = Just (eventTicketUpdatedAt ticketRow)
        }

ticketOrderEntityToDTO :: Entity EventTicketOrder -> [Entity EventTicket] -> TicketOrderDTO
ticketOrderEntityToDTO (Entity orderKey orderRow) tickets =
    let feeBreakdown = decodeTicketPlatformFeeBreakdown orderRow
     in TicketOrderDTO
        { ticketOrderId = Just (renderKeyText orderKey)
        , ticketOrderEventId = Just (renderKeyText (eventTicketOrderEventId orderRow))
        , ticketOrderTierId = Just (renderKeyText (eventTicketOrderTierId orderRow))
        , ticketOrderBuyerPartyId = eventTicketOrderBuyerPartyId orderRow
        , ticketOrderBuyerName = eventTicketOrderBuyerName orderRow
        , ticketOrderBuyerEmail = eventTicketOrderBuyerEmail orderRow
        , ticketOrderQuantity = eventTicketOrderQuantity orderRow
        , ticketOrderFaceValueCents = ticketFaceValueCents feeBreakdown
        , ticketOrderBuyerPlatformFeeCents = ticketBuyerPlatformFeeCents feeBreakdown
        , ticketOrderOrganizerPlatformFeeCents = ticketOrganizerPlatformFeeCents feeBreakdown
        , ticketOrderAmountCents = eventTicketOrderAmountCents orderRow
        , ticketOrderCurrency = eventTicketOrderCurrency orderRow
        , ticketOrderStatusValue = normalizeTicketOrderStatus (Just (eventTicketOrderStatus orderRow))
        , ticketOrderPurchasedAt = Just (eventTicketOrderPurchasedAt orderRow)
        , ticketOrderCreatedAt = Just (eventTicketOrderCreatedAt orderRow)
        , ticketOrderUpdatedAt = Just (eventTicketOrderUpdatedAt orderRow)
        , ticketOrderTickets = map ticketEntityToDTO (filter (Transfer.retainedByBuyer . entityVal) tickets)
        }

promoCodeEntityToDTO :: Entity SM.PromoCode -> PromoCodeDTO
promoCodeEntityToDTO (Entity codeKey codeRow) =
    PromoCodeDTO
        { promoCodeId = Just (renderKeyText codeKey)
        , promoCodeEventId = fmap renderKeyText (SM.promoCodeEventId codeRow)
        , promoCodeCode = SM.promoCodeCode codeRow
        , promoCodeDescription = SM.promoCodeDescription codeRow
        , promoCodeDiscountType = normalizeStoredPromoCodeDiscountType (SM.promoCodeDiscountType codeRow)
        , promoCodeDiscountValue = SM.promoCodeDiscountValue codeRow
        , promoCodeCurrency = SM.promoCodeCurrency codeRow
        , promoCodeMaxRedemptions = SM.promoCodeMaxRedemptions codeRow
        , promoCodeCurrentRedemptions = SM.promoCodeCurrentRedemptions codeRow
        , promoCodeValidFrom = SM.promoCodeValidFrom codeRow
        , promoCodeValidUntil = SM.promoCodeValidUntil codeRow
        , promoCodeTierIds = decodeStoredPromoCodeTierIds (SM.promoCodeTierIds codeRow)
        , promoCodeMinPurchaseAmountCents = SM.promoCodeMinPurchaseAmountCents codeRow
        , promoCodeIsActive = SM.promoCodeIsActive codeRow
        , promoCodeCreatedAt = Just (SM.promoCodeCreatedAt codeRow)
        , promoCodeUpdatedAt = Just (SM.promoCodeUpdatedAt codeRow)
        }

normalizeStoredPromoCodeDiscountType :: T.Text -> T.Text
normalizeStoredPromoCodeDiscountType "fixed_amount" = "fixed"
normalizeStoredPromoCodeDiscountType discountType = discountType

refundEntityToDTO :: T.Text -> Entity TicketRefundRequest -> RefundDTO
refundEntityToDTO currency (Entity refundKey refundRow) =
    RefundDTO
        { refundId = Just (renderKeyText refundKey)
        , refundOrderId = renderKeyText (ticketRefundRequestOrderId refundRow)
        , refundRequestedByPartyId = ticketRefundRequestRequestedByPartyId refundRow
        , refundReason = ticketRefundRequestReason refundRow
        , refundAmountCents = ticketRefundRequestAmountCents refundRow
        , refundCurrency = currency
        , refundStatus = ticketRefundRequestStatus refundRow
        , refundApprovedByPartyId = ticketRefundRequestApprovedByPartyId refundRow
        , refundApprovedAt = ticketRefundRequestApprovedAt refundRow
        , refundRejectionReason = ticketRefundRequestRejectionReason refundRow
        , refundStripeRefundId = ticketRefundRequestStripeRefundId refundRow
        , refundProcessedAt = ticketRefundRequestProcessedAt refundRow
        , refundCreatedAt = Just (ticketRefundRequestCreatedAt refundRow)
        , refundUpdatedAt = Just (ticketRefundRequestUpdatedAt refundRow)
        }

transferEntityToDTO :: Entity TicketTransfer -> TicketTransferDTO
transferEntityToDTO (Entity transferKey transferRow) =
    TicketTransferDTO
        { ttId = Just (renderKeyText transferKey)
        , ttTicketId = renderKeyText (ticketTransferTicketId transferRow)
        , ttFromPartyId = ticketTransferFromPartyId transferRow
        , ttToEmail = fromMaybe "" (ticketTransferToEmail transferRow)
        , ttToName = ticketTransferToName transferRow
        , ttStatus = ticketTransferStatus transferRow
        , ttTransferCode = ticketTransferTransferCode transferRow
        , ttMessage = ticketTransferMessage transferRow
        , ttExpiresAt = ticketTransferExpiresAt transferRow
        , ttAcceptedAt = ticketTransferAcceptedAt transferRow
        , ttCreatedAt = Just (ticketTransferCreatedAt transferRow)
        , ttUpdatedAt = Just (ticketTransferUpdatedAt transferRow)
        }

waitlistEntityToDTO :: Entity EventWaitlist -> WaitlistEntryDTO
waitlistEntityToDTO (Entity waitlistKey waitlistRow) =
    WaitlistEntryDTO
        { weId = Just (renderKeyText waitlistKey)
        , weEventId = renderKeyText (eventWaitlistEventId waitlistRow)
        , weTierId = fmap renderKeyText (eventWaitlistTierId waitlistRow)
        , weEmail = eventWaitlistEmail waitlistRow
        , weName = eventWaitlistName waitlistRow
        , weQuantity = eventWaitlistQuantity waitlistRow
        , weStatus = eventWaitlistStatus waitlistRow
        , wePriority = eventWaitlistPriority waitlistRow
        , weNotifiedAt = eventWaitlistNotifiedAt waitlistRow
        , weExpiresAt = eventWaitlistExpiresAt waitlistRow
        , weConvertedOrderId = fmap renderKeyText (eventWaitlistConvertedOrderId waitlistRow)
        , weCreatedAt = Just (eventWaitlistCreatedAt waitlistRow)
        , weUpdatedAt = Just (eventWaitlistUpdatedAt waitlistRow)
        }

budgetLineEntityToDTO :: SocialEventId -> Maybe Int -> Entity EventBudgetLine -> EventBudgetLineDTO
budgetLineEntityToDTO eventKey mActualCents (Entity lineKey lineRec) =
    EventBudgetLineDTO
        { eblId = Just (renderKeyText lineKey)
        , eblEventId = Just (renderKeyText eventKey)
        , eblCode = eventBudgetLineCode lineRec
        , eblName = eventBudgetLineName lineRec
        , eblType = normalizeBudgetLineType (Just (eventBudgetLineLineType lineRec))
        , eblCategory = normalizeCategory (Just (eventBudgetLineCategory lineRec))
        , eblPlannedCents = eventBudgetLinePlannedCents lineRec
        , eblActualCents = mActualCents
        , eblNotes = eventBudgetLineNotes lineRec
        , eblCreatedAt = Just (eventBudgetLineCreatedAt lineRec)
        , eblUpdatedAt = Just (eventBudgetLineUpdatedAt lineRec)
        }

-- Event DTO amounts use host Int. Arithmetic must be exact before checking
-- both bounds: negative net, liability and budget-variance values are valid.
checkedEventFinanceCents :: Integer -> AppM Int
checkedEventFinanceCents exact
    | exact < toInteger (minBound :: Int) || exact > toInteger (maxBound :: Int) =
        throwError (financeInvariantServerError "Event finance amount exceeds the supported reporting range")
    | otherwise = pure (fromInteger exact)

financeInvariantServerError :: T.Text -> ServerError
financeInvariantServerError message =
    err500{errBody = BL.fromStrict (TE.encodeUtf8 message)}

financeEntryEntityToDTOEither :: Entity EventFinanceEntry -> Either T.Text EventFinanceEntryDTO
financeEntryEntityToDTOEither (Entity entryKey entryRec) = do
    (directionVal, sourceVal, statusVal) <- validateStoredFinanceEntryDimensions entryRec
    pure
        EventFinanceEntryDTO
            { efeId = Just (renderKeyText entryKey)
            , efeEventId = Just (renderKeyText (eventFinanceEntryEventId entryRec))
            , efeBudgetLineId = fmap renderKeyText (eventFinanceEntryBudgetLineId entryRec)
            , efeDirection = directionVal
            , efeSource = sourceVal
            , efeCategory = normalizeCategory (Just (eventFinanceEntryCategory entryRec))
            , efeConcept = eventFinanceEntryConcept entryRec
            , efeAmountCents = eventFinanceEntryAmountCents entryRec
            , efeCurrency = normalizeCurrency (eventFinanceEntryCurrency entryRec)
            , efeStatus = statusVal
            , efeExternalRef = eventFinanceEntryExternalRef entryRec
            , efeNotes = eventFinanceEntryNotes entryRec
            , efeOccurredAt = eventFinanceEntryOccurredAt entryRec
            , efeRecordedByPartyId = eventFinanceEntryRecordedByPartyId entryRec
            , efeCreatedAt = Just (eventFinanceEntryCreatedAt entryRec)
            , efeUpdatedAt = Just (eventFinanceEntryUpdatedAt entryRec)
            }

storedFinanceEntrySummaryFields :: Entity EventFinanceEntry -> Either T.Text (Int, T.Text, T.Text, T.Text)
storedFinanceEntrySummaryFields (Entity _ entryRec) = do
    (directionVal, sourceVal, statusVal) <- validateStoredFinanceEntryDimensions entryRec
    pure (eventFinanceEntryAmountCents entryRec, directionVal, sourceVal, statusVal)

storedBudgetLineSummaryFields :: Entity EventBudgetLine -> Either T.Text (Int, T.Text)
storedBudgetLineSummaryFields (Entity _ lineRec) =
    validateStoredBudgetLineDimensions lineRec

storedTicketOrderSummaryFields :: Entity EventTicketOrder -> Either T.Text (Int, T.Text)
storedTicketOrderSummaryFields (Entity _ orderRec) =
    case parseTicketOrderStatus (eventTicketOrderStatus orderRec) of
        Just statusVal -> Right (eventTicketOrderAmountCents orderRec, statusVal)
        Nothing -> Left "Stored ticket order status is invalid"

ticketOrderAccountingEntriesEither ::
    SocialEventId ->
    Entity EventTicketOrder ->
    Either T.Text [EventFinanceEntryDTO]
ticketOrderAccountingEntriesEither eventKey orderEnt@(Entity _ orderRec) =
    case parseTicketOrderStatus (eventTicketOrderStatus orderRec) of
        Just statusVal -> Right (ticketOrderAccountingEntriesWithStatus eventKey orderEnt statusVal)
        Nothing -> Left "Stored ticket order status is invalid"

ticketOrderAccountingEntriesWithStatus ::
    SocialEventId ->
    Entity EventTicketOrder ->
    T.Text ->
    [EventFinanceEntryDTO]
ticketOrderAccountingEntriesWithStatus eventKey (Entity orderKey orderRec) statusVal =
    case statusVal of
        "paid" ->
            [ mkEntry "paid" "income" "ticket_sale" "posted" "Ticket sale"
            ]
        "refunded" ->
            [ mkEntry "refunded" "expense" "ticket_refund" "posted" "Ticket refund"
            ]
        "pending" ->
            [ mkEntry "pending" "income" "ticket_sale" "pending" "Ticket sale pending"
            ]
        _ -> []
  where
    orderIdTxt = renderKeyText orderKey
    feeBreakdown = decodeTicketPlatformFeeBreakdown orderRec
    organizerNetCents = max 0 (ticketFaceValueCents feeBreakdown - ticketOrganizerPlatformFeeCents feeBreakdown)
    mkEntry suffix direction source statusLabel conceptPrefix =
        EventFinanceEntryDTO
            { efeId = Just ("ticket-order-" <> orderIdTxt <> "-" <> suffix)
            , efeEventId = Just (renderKeyText eventKey)
            , efeBudgetLineId = Nothing
            , efeDirection = direction
            , efeSource = source
            , efeCategory = "tickets"
            , efeConcept = conceptPrefix <> " #" <> orderIdTxt
            , efeAmountCents =
                if source == "ticket_sale"
                    then organizerNetCents
                    else eventTicketOrderAmountCents orderRec
            , efeCurrency = normalizeCurrency (eventTicketOrderCurrency orderRec)
            , efeStatus = statusLabel
            , efeExternalRef = Just orderIdTxt
            , efeNotes = Nothing
            , efeOccurredAt = eventTicketOrderPurchasedAt orderRec
            , efeRecordedByPartyId = eventTicketOrderBuyerPartyId orderRec
            , efeCreatedAt = Just (eventTicketOrderCreatedAt orderRec)
            , efeUpdatedAt = Just (eventTicketOrderUpdatedAt orderRec)
            }

matchesFinanceFilters :: Maybe T.Text -> Maybe T.Text -> Maybe T.Text -> EventFinanceEntryDTO -> Bool
matchesFinanceFilters mDirection mSource mStatus entry =
    directionOk && sourceOk && statusOk
  where
    directionOk = maybe True (== efeDirection entry) mDirection
    sourceOk = maybe True (== efeSource entry) mSource
    statusOk = maybe True (== efeStatus entry) mStatus

-- Keep retained edges and their provenance intact. Re-inserting an unchanged
-- edge would falsely classify it as a newly acquired prerequisite in the
-- deferred completion guard. The caller owns the activity transaction/lock.
replaceLogisticsActivityDependencies
    :: EventLogisticsActivityId -> [EventLogisticsActivityId] -> UTCTime -> SqlPersistT IO ()
replaceLogisticsActivityDependencies activityKey dependencyKeys now = do
    existing <- selectList [EventLogisticsDependencyActivityId ==. activityKey] []
    let requested = Set.fromList dependencyKeys
        previous = Set.fromList
            (map (eventLogisticsDependencyDependsOnActivityId . entityVal) existing)
    forM_ existing $ \(Entity dependencyId dependency) ->
        unless (Set.member (eventLogisticsDependencyDependsOnActivityId dependency) requested) $
            delete dependencyId
    forM_ (Set.toList (Set.difference requested previous)) $ \dependencyKey ->
        insert_ EventLogisticsDependency
            { eventLogisticsDependencyActivityId = activityKey
            , eventLogisticsDependencyDependsOnActivityId = dependencyKey
            , eventLogisticsDependencyCreatedAt = now
            }

generateUniqueTicketCode :: (MonadIO m) => ReaderT SqlBackend m T.Text
generateUniqueTicketCode = do
    code <- liftIO Admission.newTicketCode
    mExisting <- getBy (UniqueEventTicketCode code)
    case mExisting of
        Nothing -> pure code
        Just _ -> generateUniqueTicketCode
