import { createRequire } from 'node:module';
import { writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const { chromium, expect } = createRequire('/private/tmp/tdf-user-value-20261025/package.json')('@playwright/test');
const preview = 'https://e79de665.tdf-app.pages.dev';
const commit = 'e9f23483c7d4164a4551e6a90d6b82e6b09fd13a';
const output = '/private/tmp/tdf-player-privacy-release-evidence-20261027';
const sha = b => createHash('sha256').update(b).digest('hex');
async function source() {
  const htmlResponse = await fetch(preview);
  if (!htmlResponse.ok) throw new Error('Preview HTML status ' + htmlResponse.status);
  const html = await htmlResponse.text();
  const entry = [...html.matchAll(/<script\b[^>]*>/g)]
    .find(match => match[0].includes('type="module"'))?.[0].match(/src="([^"]+)"/)?.[1];
  if (!entry) throw new Error('No module entry');
  const url = new URL(entry, preview).href;
  const response = await fetch(url);
  if (!response.ok) throw new Error('Entry status ' + response.status);
  const bytes = Buffer.from(await response.arrayBuffer());
  if (!bytes.includes(Buffer.from(commit))) throw new Error('Entry does not embed candidate commit');
  return { url, sha256: sha(bytes), embedsCandidate: true };
}
const receipt = {
  observedAt: new Date().toISOString(), preview, commit, status: 'RUNNING', cases: [],
  policy: 'Fresh anonymous contexts; allow GET/HEAD only to preview/API; no fixtures, Play, login or writes.',
  scope: 'Preview technical smoke only; not production, real authorized playback or continuity of an active session.',
};
let browser;
try {
  receipt.before = await source();
  browser = await chromium.launch({ headless: true });
  for (const viewport of [{ width: 1440, height: 1000 }, { width: 390, height: 844 }]) {
    const context = await browser.newContext({ locale: 'es-EC', viewport, serviceWorkers: 'block' });
    const page = await context.newPage();
    const item = { viewport, blockedRequests: [], pageErrors: [] };
    receipt.cases.push(item);
    await page.route('**/*', async route => {
      const request = route.request(), url = new URL(request.url());
      if (!['GET', 'HEAD'].includes(request.method()) ||
          ![new URL(preview).hostname, 'api.tdfrecords.net'].includes(url.hostname)) {
        item.blockedRequests.push({ method: request.method(), host: url.hostname, path: url.pathname });
        return route.abort('blockedbyclient');
      }
      return route.continue();
    });
    page.on('pageerror', error => item.pageErrors.push(String(error)));
    const response = await page.goto(preview + '/buscar?q=rock', { waitUntil: 'domcontentloaded', timeout: 30000 });
    expect(response.status()).toBe(200);
    await expect(page.locator('h1').first()).toBeVisible({ timeout: 30000 });
    await expect(page.locator('audio')).toHaveCount(1);
    item.audio = await page.locator('audio').evaluateAll(elements => elements.map(audio => ({
      paused: audio.paused, source: audio.getAttribute('src'), connected: audio.isConnected,
    })));
    expect(item.audio[0].paused).toBe(true);
    expect(item.audio[0].source).toBeNull();
    expect(item.pageErrors).toEqual([]);
    item.result = 'PASS: directory renders, one idle source-free engine, no accidental playback';
    await page.screenshot({ path: output + '/preview-' + viewport.width + '.png' });
    await context.close();
  }
  receipt.after = await source();
  expect(receipt.after).toEqual(receipt.before);
  receipt.status = 'PASS';
} catch (error) {
  receipt.status = 'FAILED'; receipt.error = String(error); process.exitCode = 1;
} finally {
  await browser?.close();
  receipt.browserClosed = true;
  writeFileSync(output + '/preview-smoke.json', JSON.stringify(receipt, null, 2) + '\n');
  console.log(JSON.stringify(receipt));
}
