import { createRequire } from 'node:module';
import base from '/private/tmp/tdf-player-privacy-release-20261027/playwright.music-native.config.mjs';
const root='/private/tmp/tdf-player-privacy-release-20261027';
const {defineConfig}=createRequire(root+'/package.json')('@playwright/test');
export default defineConfig({...base,testDir:root+'/e2e/web',globalSetup:root+'/e2e/web/fixtures/native-music-setup.mjs',projects:base.projects.filter(p=>p.name==='chromium-desktop').map(p=>({...p,grep:/PW-MUSIC-NATIVE-09/})),webServer:{...base.webServer,cwd:root}});
