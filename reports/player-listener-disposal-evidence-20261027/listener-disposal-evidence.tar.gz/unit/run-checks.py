from pathlib import Path
import json,subprocess,os,hashlib,datetime
W=Path('/private/tmp/tdf-player-privacy-release-20261027');P=Path(__file__).resolve().parent;N='/private/tmp/tdf-node22-20261026/node-v22.14.0-darwin-x64/bin/node';env=dict(os.environ);env['PATH']=str(Path(N).parent)+os.pathsep+env['PATH'];env['NODE_OPTIONS']='--experimental-vm-modules'
paths=['tdf-hq-ui/src/player/PlayerProvider.tsx','tdf-hq-ui/src/player/PlayerProvider.test.tsx','tdf-hq-ui/src/player/PlayerIdentity.test.tsx']
def sources():return {n:hashlib.sha256((W/n).read_bytes()).hexdigest() for n in paths}
before=sources();(P/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');steps=[]
commands=[('unit',[N,'../node_modules/jest/bin/jest.js','--runInBand','--runTestsByPath','src/player/PlayerProvider.test.tsx','src/player/PlayerIdentity.test.tsx','src/player/queue.test.ts','src/session/SessionContext.test.ts','src/session/SessionContext.reconciliation.test.tsx','src/session/SessionProvider.bootstrapTimeout.test.tsx','src/session/SessionProviders.test.tsx','src/session/SessionQueryProvider.test.tsx']),('lint',[N,'../node_modules/eslint/bin/eslint.js','src/player/PlayerProvider.tsx','src/player/PlayerProvider.test.tsx','src/player/PlayerIdentity.test.tsx','--max-warnings=0']),('typecheck',[N,'../node_modules/typescript/bin/tsc','--noEmit','-p','tsconfig.app.json'])]
for label,cmd in commands:
 with (P/(label+'.log')).open('wb') as log:result=subprocess.run(cmd,cwd=W/'tdf-hq-ui',env=env,stdout=log,stderr=subprocess.STDOUT)
 (P/(label+'.exit')).write_text(str(result.returncode)+'\n');steps.append({'label':label,'command':cmd,'exit':result.returncode});print(json.dumps(steps[-1]),flush=True)
after=sources();assert before==after
r={'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS' if all(x['exit']==0 for x in steps) else 'FAILED','node':subprocess.check_output([N,'--version'],text=True).strip(),'steps':steps,'sourceBefore':before,'sourceAfter':after,'sourceUnchanged':True,'scope':'Oldprivacy+1129only;cleanupfixdoesnotcopy640source/readiness/search tests. JSDOM/API/media doubles; rootnativeexecution separate.'};(P/'checks-receipt.json').write_text(json.dumps(r,indent=2)+'\n');raise SystemExit(0 if r['status']=='PASS' else 1)
