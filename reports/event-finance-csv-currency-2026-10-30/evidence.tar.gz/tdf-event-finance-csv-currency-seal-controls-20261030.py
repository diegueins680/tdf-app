from pathlib import Path
import ast,json,copy,hashlib,subprocess,datetime
w=Path('/private/tmp/tdf-event-finance-csv-currency-fix-20261030');o=Path('/private/tmp/tdf-event-finance-csv-currency-qualification-20261030');p=Path('/private/tmp/tdf-event-finance-csv-currency-seal-20261030.py');sha=lambda b:hashlib.sha256(b).hexdigest();tree=ast.parse(p.read_text());defs=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='verify_csv_bindings'];assert len(defs)==1;ns={'sha':sha,'json':json};exec(compile(ast.Module(body=defs,type_ignores=[]),str(p),'exec'),ns);check=ns['verify_csv_bindings']
m=json.loads((o/'preparation-state.json').read_text())['sourceCommit'];q=json.loads((o/'ui-quality.json').read_text());f=json.loads((o/'assurance-committed/report.json').read_text());s=json.loads((o/'assurance-committed/sources.json').read_text());inputs=json.loads((o/'ui-qualified-inputs.json').read_text());actual={path:(w/path).read_bytes() for path in inputs['sourceFilesSha256']};alt=json.loads((o/'alternative-verification.json').read_text());expected=set(subprocess.check_output(['git','ls-tree','-r','-z','--name-only',m,'--','tdf-hq-ui','package.json','package-lock.json','tdf-hq/assets/feature-registry.json','scripts/quality-ui.sh','scripts/check-initial-bundle.mjs','formal/system/requirements.json'],cwd=w).decode().strip('\0').split('\0'))
check(m,q,f,s,inputs,expected,actual,alt);rows=[]
def control(label,mutate):
 v={'q':copy.deepcopy(q),'f':copy.deepcopy(f),'s':copy.deepcopy(s),'inputs':copy.deepcopy(inputs),'actual':dict(actual),'alt':copy.deepcopy(alt)};mutate(v)
 try:check(m,v['q'],v['f'],v['s'],v['inputs'],expected,v['actual'],v['alt'])
 except AssertionError:rows.append({'label':label,'expectedRejection':True,'actual':'ASSERTION_REJECTED'});return
 raise RuntimeError('Invalid evidence accepted:'+label)
control('FailedLintPromoted',lambda v:v['q']['actualExits'].__setitem__('lint',1))
control('ReducedTargetedCount',lambda v:v['q'].__setitem__('targetedTests',77))
def borrowed(v):v['q']['fullUiCurrentSource']='PASSED historical3811';v['q']['fullTests']=3811
control('ParentFullUiPromotedToCurrent',borrowed)
control('WrongSourceCommit',lambda v:v['q'].__setitem__('sourceCommit','0'*40))
control('AssuranceDigestMismatch',lambda v:v['f']['provenance'].__setitem__('digest','0'*64))
control('UnsupportedWholeRequirementProof',lambda v:v['f']['metrics']['requirements'].update(PROVEN=1,UNPROVEN=160))
control('UnexpectedReleasePermission',lambda v:v['f']['release'].__setitem__('executionAllowed',True))
def omit(v):path=next(iter(v['actual']));v['actual'].pop(path);v['inputs']['sourceFilesSha256'].pop(path)
control('OmittedUiInputWithMatchedReducedTable',omit)
control('UndetectedOldUnitBinding',lambda v:v['alt'].__setitem__('faultyUnitMismatches',0))
control('UnexpectedDefaultCurrencyFallback',lambda v:v['alt'].__setitem__('defaultCurrencyCalls',1))
control('WrongCsvSourceFingerprint',lambda v:v['alt']['sourceInputsSha256'].__setitem__('tdf-hq-ui/src/utils/eventFinanceCsv.ts','0'*64))
check(m,q,f,s,inputs,expected,actual,alt)
for path,b in actual.items():assert (w/path).read_bytes()==b,path
result={'sourceCommit':m,'sealScriptSha256':sha(p.read_bytes()),'method':'AST-extract actual CSV seal binder, actualvalid receipts before/after; onein-memorycorruptionpercontrol. CompleteUIinputset independentGit enumeration. Checkout/artifacts nevermutated.','validBefore':True,'negativeControls':rows,'intendedAssertionRejections':len(rows),'restoredValidAfter':True,'diskArtifactsUnchanged':True,'scope':'Evidence binder negative controls; no complete verification-pipeline theorem','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/'seal-binding-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'validBefore':True,'negativeControlsRejected':len(rows),'restoredValidAfter':True}))
