from pathlib import Path
import os,subprocess,json,hashlib,re,sys,datetime
w=Path('/private/tmp/tdf-event-finance-csv-currency-fix-20261030');o=Path('/private/tmp/tdf-event-finance-csv-currency-qualification-20261030');cache=Path('/private/tmp/tdf-correctness-cycle-20261028');label=sys.argv[1];assert label in ['baseline','corrected'];sha=lambda b:hashlib.sha256(b).hexdigest()
assert (w/'package-lock.json').read_bytes()==(cache/'package-lock.json').read_bytes()
a=json.loads((w/'package.json').read_text());b=json.loads((cache/'package.json').read_text());assert {k:v for k,v in a.items() if k!='scripts'}=={k:v for k,v in b.items() if k!='scripts'}
assert (w/'tdf-hq-ui/package.json').read_bytes()==(cache/'tdf-hq-ui/package.json').read_bytes()
inputs={p:sha((w/p).read_bytes()) for p in ['tdf-hq-ui/src/utils/eventFinanceCsv.ts','tdf-hq-ui/src/utils/eventFinanceCsv.test.ts','tdf-hq-ui/src/utils/eventFinanceMoney.ts','tdf-hq-ui/src/utils/formatters.ts']};made=[]
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL']};env['PATH']='/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin';env['NODE_OPTIONS']='--experimental-vm-modules'
try:
 for name in ['node_modules','tdf-hq-ui/node_modules']:
  p,t=w/name,cache/name;assert not(p.exists() or p.is_symlink()) and t.is_dir();p.symlink_to(t,target_is_directory=True);made.append((p,t))
 with (o/(label+'.log')).open('w') as log:
  result=subprocess.run(['npm','test','--','--runTestsByPath','src/utils/eventFinanceCsv.test.ts'],cwd=w/'tdf-hq-ui',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
finally:
 for p,t in reversed(made):assert p.is_symlink() and p.resolve()==t.resolve();p.unlink()
assert all(sha((w/p).read_bytes())==h for p,h in inputs.items())
raw=(o/(label+'.log')).read_text();matches=re.findall(r'Tests:\s+(?:(\d+) failed, )?(\d+) passed, (\d+) total',raw)
record={'label':label,'actualExit':result.returncode,'sourceInputsSha256':inputs,'sourceInputsUnchanged':True,'ownedAliasesRemoved':all(not(w/x).exists() and not(w/x).is_symlink() for x in ['node_modules','tdf-hq-ui/node_modules']),'cacheAdmission':{'rootLockByteExact':True,'dependencyManifestExactExceptRootScripts':True,'uiManifestByteExact':True},'scope':'Actual CSV helper Jest only; no mountedPage/HTTP/backend/DB/provider/browser qualification','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
if not matches or 'Test suite failed to run' in raw:
 record['classification']='SETUP_OR_RUNNER_FAILURE_NOT_PRODUCT_COUNTEREXAMPLE';(o/(label+'-execution.json')).write_text(json.dumps(record,indent=2)+'\n');raise RuntimeError('No valid six-case Jest result; retain setup failure separately')
failed,passed,total=matches[-1];record.update(failed=int(failed or 0),passed=int(passed),total=int(total));assert record['total']==6
if label=='baseline':
 assert result.returncode==1 and (record['failed'],record['passed'])==(1,5)
 assert 'keeps a foreign void entry in its own currency' in raw and '"EUR"' in raw and '"USD"' in raw
 record['classification']='CONFIRMED_INTENDED_ASSERTION_FAILURE'
else:
 assert result.returncode==0 and (record['failed'],record['passed'])==(0,6);record['classification']='TESTED_FINITE_CORRECTED_CSV_HELPER'
(o/(label+'-execution.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
