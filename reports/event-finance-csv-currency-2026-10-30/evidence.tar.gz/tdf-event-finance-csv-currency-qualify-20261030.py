from pathlib import Path
import os,subprocess,json,hashlib,signal,datetime,re
w=Path('/private/tmp/tdf-event-finance-csv-currency-fix-20261030');o=Path('/private/tmp/tdf-event-finance-csv-currency-qualification-20261030');cache=Path('/private/tmp/tdf-correctness-cycle-20261028');m=json.loads((o/'preparation-state.json').read_text())['sourceCommit'];base=json.loads((o/'preparation-state.json').read_text())['parentHead'];sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=w)
assert git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip()
paths=git('ls-tree','-r','-z','--name-only',m,'--','tdf-hq-ui','package.json','package-lock.json','tdf-hq/assets/feature-registry.json','scripts/quality-ui.sh','scripts/check-initial-bundle.mjs','formal/system/requirements.json').decode().strip('\0').split('\0');inputs={p:sha((w/p).read_bytes()) for p in paths}
refs=[m+':'+p for p in inputs];assert all('\n' not in p for p in refs)
raw=subprocess.check_output(['git','cat-file','--batch'],cwd=w,input=('\n'.join(refs)+'\n').encode());pos=0
for p,h in inputs.items():
 end=raw.index(b'\n',pos);header=raw[pos:end].split();assert header[1]==b'blob';n=int(header[2]);assert sha(raw[end+1:end+1+n])==h,p;pos=end+1+n+1
assert pos==len(raw)
(o/'ui-qualified-inputs.json').write_text(json.dumps({'sourceCommit':m,'sourceFilesSha256':inputs,'scope':'All tracked UI inputs, root dependencies, existing feature JSON and UI quality/bundle scripts; provider credentials absent'},indent=2)+'\n')
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env.update(PATH='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/Users/macpro/.ghcup/bin:/usr/local/bin:/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1')
state={'sourceCommit':m,'phase':'QUALIFYING_FINAL_COMMITTED_SOURCE','startedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actualExits':{}}
def save():(o/'ui-run-state.json').write_text(json.dumps(state,indent=2)+'\n')
def stop(signum,frame):raise SystemExit(128+signum)
signal.signal(signal.SIGTERM,stop)
made=[]
def run(cmd,cwd,log):
 p=None
 try:
  p=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);state['activePID']=p.pid;save();return p.wait(timeout=1200)
 except BaseException:
  if p is not None and p.poll() is None:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
  state['phase']='FAILED_OR_INTERRUPTED';save();raise
try:
 assert (w/'package-lock.json').read_bytes()==(cache/'package-lock.json').read_bytes()
 for name in ['node_modules','tdf-hq-ui/node_modules']:
  p,t=w/name,cache/name;assert not(p.exists() or p.is_symlink());p.symlink_to(t,target_is_directory=True);made.append((p,t))
 tasks=[('targeted',['npm','test','--','--runTestsByPath','src/utils/eventFinanceMoney.test.ts','src/utils/eventFinanceCsv.test.ts','src/api/socialEvents.test.ts','src/pages/SocialEventsPage.finance.test.tsx'],w/'tdf-hq-ui'),('typecheck',['npm','run','typecheck'],w/'tdf-hq-ui'),('lint',['npm','run','lint'],w/'tdf-hq-ui'),('build',['npm','run','build'],w/'tdf-hq-ui'),('root-quality',['bash','scripts/quality-repo.sh'],w),('source-admission',['python3','scripts/check-new-specification-surfaces.py','--base',base,'--head',m],w),('catalog-unit',['node','--test','scripts/__tests__/catalog-list-audit.test.mjs'],w)]
 for label,cmd,cwd in tasks:
  state['phase']='RUNNING_'+label;save()
  with (o/('final-'+label+'.log')).open('w') as log:code=run(cmd,cwd,log)
  state['actualExits'][label]=code;save();print(label+' actualexit '+str(code),flush=True);assert code==0,label
finally:
 for p,t in reversed(made):assert p.is_symlink() and p.resolve()==t.resolve();p.unlink()
for p,h in inputs.items():assert sha((w/p).read_bytes())==h,p
assert git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip()
for label in ['targeted']:
 raw=(o/('final-'+label+'.log')).read_text();mat=re.findall(r'Tests:\s+(\d+) passed, (\d+) total',raw);assert mat and mat[-1][0]==mat[-1][1];state[label+'Tests']=int(mat[-1][0]);suites=re.findall(r'Test Suites:\s+(\d+) passed, (\d+) total',raw);assert suites and suites[-1][0]==suites[-1][1];state[label+'Suites']=int(suites[-1][0])
assert state['targetedTests']==78
state.update(fullUiCurrentSource='NOT_RUN_LOCAL; selected hosted UI quality remains required',parentFullUi={'sourceCommit':'83533b3d980432aea6bab30361453311da4f3905','tests':3811,'suites':327,'scope':'Historical parent source only, not current CSV source'},phase='QUALIFIED_SCOPED_CSV_SOURCE',allInputsGitExactAndUnchanged=True,aliasesRemoved=True,sourceCleanAfter=True,finishedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat());save();(o/'ui-quality.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(state),flush=True)
