from pathlib import Path
import json,subprocess,hashlib,csv,datetime
w=Path('/private/tmp/tdf-event-finance-csv-currency-fix-20261030');o=Path('/private/tmp/tdf-event-finance-csv-currency-qualification-20261030');sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=w):return subprocess.check_output(['git',*a],cwd=cwd)
def blob(ref,p):return git('show',ref+':'+p)
def verify_csv_bindings(m,q,f,s,inputs,expected_paths,actual,alt):
 assert q['sourceCommit']==f['provenance']['revision']==s['revision']==inputs['sourceCommit']==m
 assert set(q['actualExits'])=={'targeted','typecheck','lint','build','root-quality','source-admission','catalog-unit'} and all(x==0 for x in q['actualExits'].values())
 assert q['phase']=='QUALIFIED_SCOPED_CSV_SOURCE' and q['targetedTests']==78 and q['targetedSuites']==4
 assert q['fullUiCurrentSource']=='NOT_RUN_LOCAL; selected hosted UI quality remains required' and 'fullTests' not in q
 assert q['parentFullUi']=={'sourceCommit':'83533b3d980432aea6bab30361453311da4f3905','tests':3811,'suites':327,'scope':'Historical parent source only, not current CSV source'}
 assert q['allInputsGitExactAndUnchanged'] and q['aliasesRemoved'] and q['sourceCleanAfter']
 for key in ['files','digest','revision','mobileGitlink','worktreeDirty']:assert f['provenance'][key]==s[key],key
 assert not s['worktreeDirty'] and s['digest']==sha(json.dumps(s['files'],sort_keys=True).encode())
 expected={'PROVEN':0,'REFUTED':0,'UNPROVEN':161,'NOT_APPLICABLE':0};assert f['metrics']['requirements']==expected
 for category in ['implementation','refinement']:assert f['metrics']['obligationsByCategory'][category]==expected
 for category,count in [('source-derived-SMT',4),('source-derived-authorization-SMT',3),('source-derived-recovery-SMT',4)]:assert f['metrics']['obligationsByCategory'][category]=={'PROVEN':count,'REFUTED':0,'UNPROVEN':0,'NOT_APPLICABLE':0}
 assert f['execution']['passed'] and f['release']['decision']=='BLOCKED' and f['release']['executionAllowed'] is False
 assert set(inputs['sourceFilesSha256'])==set(actual)==expected_paths
 for path,h in inputs['sourceFilesSha256'].items():assert sha(actual[path])==h,path
 assert (alt['cases'],alt['currentPass'],alt['faultyUnitMismatches'],alt['faultyCompatiblePass'],alt['restoredPass'],alt['defaultCurrencyCalls'])==(27,27,18,9,27,0) and alt['sourceUnchanged']
 for path,h in alt['sourceInputsSha256'].items():assert sha(actual[path])==h,path

p=json.loads((o/'preparation-state.json').read_text());m=p['sourceCommit'];parent=p['parentHead'];main=p['mainSha'];q=json.loads((o/'ui-quality.json').read_text());f=json.loads((o/'assurance-committed/report.json').read_text());s=json.loads((o/'assurance-committed/sources.json').read_text());inputs=json.loads((o/'ui-qualified-inputs.json').read_text());alt=json.loads((o/'alternative-verification.json').read_text());actual={path:(w/path).read_bytes() for path in inputs['sourceFilesSha256']}
expected_paths=set(git('ls-tree','-r','-z','--name-only',m,'--','tdf-hq-ui','package.json','package-lock.json','tdf-hq/assets/feature-registry.json','scripts/quality-ui.sh','scripts/check-initial-bundle.mjs','formal/system/requirements.json').decode().strip('\0').split('\0'))
assert git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip();verify_csv_bindings(m,q,f,s,inputs,expected_paths,actual,alt)
mobile=git('rev-parse',m+':tdf-mobile').decode().strip();assert git('rev-parse','HEAD',cwd=w/'tdf-mobile').decode().strip()==mobile
for table in [inputs['sourceFilesSha256'],s['files']]:
 for ism in [False,True]:
  pairs=[(path,h) for path,h in table.items() if path.startswith('tdf-mobile/')==ism]
  if not pairs:continue
  cwd=w/'tdf-mobile' if ism else w;ref=mobile if ism else m;refs=[ref+':'+(path.removeprefix('tdf-mobile/') if ism else path) for path,h in pairs];assert all('\n' not in x for x in refs)
  raw=subprocess.check_output(['git','cat-file','--batch'],cwd=cwd,input=('\n'.join(refs)+'\n').encode());pos=0
  for path,h in pairs:
   end=raw.index(b'\n',pos);header=raw[pos:end].split();assert header[1]==b'blob';n=int(header[2]);assert sha(raw[end+1:end+1+n])==h==sha((w/path).read_bytes()),path;pos=end+1+n+1
  assert pos==len(raw)
for path,h in f['evidenceHashes'].items():
 pp=Path(path);assert not pp.is_absolute() and '..' not in pp.parts;file=o/'assurance-committed'/pp;assert file.is_file() and not file.is_symlink() and sha(file.read_bytes())==h,path
for path in ['tdf-hq','.github','scripts','ops','tdf-mobile','package.json','package-lock.json']:assert git('rev-parse',m+':'+path)==git('rev-parse',main+':'+path),path
owned={'tdf-hq-ui/src/utils/eventFinanceCsv.ts','tdf-hq-ui/src/utils/eventFinanceCsv.test.ts'};assert set(git('diff','--name-only','-z',parent,m,'--','tdf-hq-ui').decode().strip('\0').split('\0'))==owned
code=blob(parent,'tdf-hq-ui/src/utils/eventFinanceCsv.ts');marker=b'  financeEntries.forEach((entry) => {';assert code.count(marker)==1;i=code.index(marker);assert blob(m,'tdf-hq-ui/src/utils/eventFinanceCsv.ts')==code[:i]+code[i:].replace(b'      eventCurrency,\n',b'      entry.efeCurrency,\n',1)
assert blob(m,'tdf-hq-ui/src/utils/eventFinanceCsv.test.ts').startswith(blob(parent,'tdf-hq-ui/src/utils/eventFinanceCsv.test.ts'))
req=json.loads(blob(m,'formal/system/requirements.json'))['requirements'];prior=json.loads(blob(parent,'formal/system/requirements.json'))['requirements'];by={x['id']:x for x in req};assert len(by)==len(req)==len(prior)+1==161 and all(by[x['id']]==x for x in prior)
path='docs/catalog-persistence/catalog-list-decisions.json';old=json.loads(blob(parent,path));now=json.loads(blob(m,path));assert now['decisions'][:-1]==old['decisions'] and now['decisions'][-1]['id']=='280d7c369a6f39bd4a13' and now['decisions'][-1]['reviewed'] and {k:v for k,v in now.items() if k!='decisions'}=={k:v for k,v in old.items() if k!='decisions'}
cat=json.loads(blob(m,'docs/catalog-persistence/reports/static-list-inventory.json'));assert cat['candidateCount']==1356 and all(x['decision']!='unreviewed' for x in cat['candidates']);assert (o/'current-catalog.json').read_bytes()==blob(m,'docs/catalog-persistence/reports/static-list-inventory.json')
with (o/'current-catalog.csv').open(newline='') as handle:rows=list(csv.DictReader(handle))
assert len(rows)==1356 and (o/'current-catalog.csv').read_bytes()==blob(m,'docs/catalog-persistence/reports/list-consumer-matrix.csv')
assert all(x==0 for x in p['metadataResults']['actualExits'].values()) and len(p['metadataResults']['actualExits'])==7 and all(x==0 for x in p['committedChecks'].values())
assert git('rev-parse',m+':reports')==git('rev-parse',parent+':reports')
for path,h in p['parentFourReportBlobsSha256'].items():assert sha(blob(parent,path))==h==sha(blob(m,path))==sha((w/path).read_bytes()),path
b=json.loads((o/'baseline-execution.json').read_text());c=json.loads((o/'corrected-execution.json').read_text());assert(b['actualExit'],b['failed'],b['passed'],b['total'])==(1,1,5,6) and(c['actualExit'],c['failed'],c['passed'],c['total'])==(0,0,6,6)
assert (o/'baseline-eventFinanceCsv.ts.txt').read_bytes()==blob(parent,'tdf-hq-ui/src/utils/eventFinanceCsv.ts')
for label,row in [('baseline',b),('corrected',c)]:
 for path,h in row['sourceInputsSha256'].items():
  if label=='baseline' and path=='tdf-hq-ui/src/utils/eventFinanceCsv.ts':assert h==sha(code)
  else:assert h==sha(blob(m,path)),path
assert sha((o/'alternative-actual-source.js.txt').read_bytes())==alt['emittedSourceSha256'] and sha((o/'alternative-faulty-source.js.txt').read_bytes())==alt['faultyEmittedSourceSha256']
rootreview=json.loads((o/'root-independent-preparation-review.json').read_text());assert rootreview['oneProductionCellDiffOnly'] and rootreview['all160ParentNormativeObjectsExactPlusCsv161']
result={'sourceCommit':m,'baselineMain':main,'qualifiedParent':parent,'parentFunctionalSource':'83533b3d980432aea6bab30361453311da4f3905','sourceDigest':s['digest'],'registeredHashesVerified':len(s['files']),'uiInputHashesVerified':len(inputs['sourceFilesSha256']),'assuranceArtifactHashesVerified':len(f['evidenceHashes']),'all160ParentNormativeObjectsExactPlusCsv161':True,'allBackendWorkflowsMobileOpsScriptsDependenciesExactMain':True,'onlyOneProductionCurrencyCellChanged':True,'allOtherUiExactParentExceptAppendOnlyTwoTests':True,'allParentHistoricalReportTreeExact':True,'parentFourReportBlobsSha256':p['parentFourReportBlobsSha256'],'strictCatalogCandidates':1356,'all1355PriorCatalogDecisionsExactPlusSyntheticFixture':True,'currentTargetedTests':78,'currentFullUi':'NOT_RUN_LOCAL; current-head mandatory selected CI stillrequired','parentFullUi':q['parentFullUi'],'baselineCases':6,'baselineAssertionFailures':1,'baselineCompatibilityPasses':5,'correctedCsvCases':6,'alternativeActualSourceCases':27,'alternativeOldBindingMismatches':18,'alternativeRestoredCases':27,'alternativeScope':alt['scope'],'assuranceMetrics':f['metrics'],'formalRelease':f['release']['decision'],'newCompleteProofs':0,'sourceCleanAfter':True,'limitations':['TESTED finite source-function/Jest/component cases, no complete implementation/refinement proof.','Full3811UI result belongsparent83533 only, not current CSV source; selected hostedUI fullsuite required beforeintegration.','CommonCSVcolumn per-record amountunit interpretation is nowexplicit; no authoritativeexternalconsumercontract found, externalcompatibility expectationsunknown.','BackendDTOcurrency validationtrusted; noFX/defaultunit invention, malformedDTOdecoder, financialrecord/provider or snapshotguarantee.','No new localbrowser/HTTP/DB/native run forone-cellpresentation correction. Parenthistoricalreports remainimmutable.','Ownedprocessgroup/SIGTERM cleanup exists inrunner but interruptedrun cleanupnotfault-tested.'],'createdAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/'source-correspondence.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['sourceCommit','qualifiedParent','registeredHashesVerified','uiInputHashesVerified','strictCatalogCandidates','currentTargetedTests','currentFullUi','formalRelease']}))
