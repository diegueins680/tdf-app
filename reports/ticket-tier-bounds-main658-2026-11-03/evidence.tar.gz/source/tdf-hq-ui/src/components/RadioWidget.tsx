import MarkdownText from './MarkdownText';
import { readOptionalBrowserStorage, writeOptionalBrowserPreference } from '../utils/optionalBrowserStorage';
import { ABOVE_GLOBAL_PLAYER, RADIO_BAR_HEIGHT_VAR, useDockedBarHeight } from '../utils/bottomDock';
import { logger } from '../utils/logger';
import { useEffect, useMemo, useRef, useState, useCallback, type ChangeEvent } from 'react';
import { createPortal } from 'react-dom';
import { useQuery } from '@tanstack/react-query';
import {
  Box,
  Card,
  CardContent,
  Chip,
  Collapse,
  Divider,
  IconButton,
  LinearProgress,
  Stack,
  TextField,
  Typography,
  Tooltip,
  Button,
  Switch,
  FormControlLabel,
  MenuItem,
  Slider,
  useMediaQuery,
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import PauseIcon from '@mui/icons-material/Pause';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import RadioIcon from '@mui/icons-material/Radio';
import GraphicEqIcon from '@mui/icons-material/GraphicEq';
import VolumeOffIcon from '@mui/icons-material/VolumeOff';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import { generateTidalCode } from '../utils/tidalAgent';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import DragIndicatorIcon from '@mui/icons-material/DragIndicator';
import { RadioAPI, type RadioStreamDTO, type RadioTransmissionInfo } from '../api/radio';
import RestartAltIcon from '@mui/icons-material/RestartAlt';
import StarIcon from '@mui/icons-material/Star';
import StarBorderIcon from '@mui/icons-material/StarBorder';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import CloudDownloadIcon from '@mui/icons-material/CloudDownload';
import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord';
import VolumeUpIcon from '@mui/icons-material/VolumeUp';
import SkipNextIcon from '@mui/icons-material/SkipNext';
import SkipPreviousIcon from '@mui/icons-material/SkipPrevious';
import BoltIcon from '@mui/icons-material/Bolt';
import ShareIcon from '@mui/icons-material/Share';
import PeopleAltIcon from '@mui/icons-material/PeopleAlt';
import PushPinIcon from '@mui/icons-material/PushPin';
import StopCircleIcon from '@mui/icons-material/StopCircle';
import OpenInFullIcon from '@mui/icons-material/OpenInFull';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import { useNavigate, useLocation } from 'react-router-dom';
import { Catalogs, type CatalogItem } from '../api/catalogs';
import { toLocalDateInputValue } from '../utils/dateOnly';
import {
  createTorrentAudioSession,
  isMagnetLink,
  isTorrentFile,
  magnetDisplayName,
  MAX_TORRENT_FILE_BYTES,
  type TorrentAudioSession,
  type TorrentPlaybackProgress,
} from '../utils/torrentAudio';
import LazyPaginatedList from './LazyPaginatedList';
import { PLAYER_TAKEOVER_EVENT, RADIO_TAKEOVER_EVENT } from '../player/types';

interface Prompt {
  text: string;
  author?: string;
  createdAt?: string;
  code?: string;
}

interface LoadStreamDetail {
  streamUrl: string;
  stationName?: string;
  stationId?: string;
}

interface Station {
  id: string;
  name: string;
  streamUrl: string;
  region?: string;
  stationId?: string;
  countryId?: string;
  country?: string;
  genreId?: string;
  genre?: string;
  mood: string;
  prompts: Prompt[];
  source?: 'custom' | 'db' | 'shared' | 'torrent';
  torrentFile?: File;
}

const RADIO_STATION_INITIAL_ROWS_PER_PAGE: number = 3 * 8;
const RADIO_STATION_ROWS_PER_PAGE_OPTIONS = [
  RADIO_STATION_INITIAL_ROWS_PER_PAGE,
  RADIO_STATION_INITIAL_ROWS_PER_PAGE * 2,
  RADIO_STATION_INITIAL_ROWS_PER_PAGE * 4,
] as const satisfies readonly number[];

const EMPTY_STATION: Station = {
  id: 'radio-empty',
  name: 'Sin emisoras disponibles',
  mood: 'Radio',
  streamUrl: '',
  prompts: [],
};

function PromptList({ prompts }: { prompts: Prompt[] }) {
  if (prompts.length === 0) {
    return (
      <Typography variant="body2" color="text.secondary">
        No hay prompts aún.
      </Typography>
    );
  }
  return (
    <Stack spacing={1}>
      {prompts.map((p, idx) => (
        <Card key={`${p.text}-${idx}`} variant="outlined">
          <CardContent sx={{ py: 1.25, display: 'flex', flexDirection: 'column', gap: 0.75 }}>
            <MarkdownText variant="body2" fontWeight={600}>
              {p.text}
            </MarkdownText>
            <Typography variant="caption" color="text.secondary">
              {p.author ?? 'Agente Tidal'} {p.createdAt ? `· ${p.createdAt}` : ''}
            </Typography>
            {p.code && (
              <Box
                sx={{
                  bgcolor: 'rgba(148,163,184,0.08)',
                  border: '1px dashed',
                  borderColor: 'divider',
                  borderRadius: 1.5,
                  p: 1,
                  fontFamily: 'monospace',
                  fontSize: 12,
                  whiteSpace: 'pre-line',
                  position: 'relative',
                }}
              >
                {p.code}
                <Box sx={{ position: 'absolute', top: 4, right: 4 }}>
                  <Tooltip title="Copiar instrucciones Tidal">
                    <IconButton
                      size="small"
                      aria-label="Copiar instrucciones Tidal"
                      onClick={() => {
                        if (navigator?.clipboard?.writeText) {
                          navigator.clipboard
                            .writeText(p.code ?? '')
                            .catch((err) => logger.warn('No se pudo copiar las instrucciones Tidal', err));
                        }
                      }}
                    >
                      <ContentCopyIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                </Box>
              </Box>
            )}
          </CardContent>
        </Card>
      ))}
    </Stack>
  );
}

/** CSS custom property carrying the docked radio bar's height (px) while it is shown. */

export default function RadioWidget() {
  const navigate = useNavigate();
  const location = useLocation();
  const LAST_AUDIO_INPUT_KEY = 'radio-last-audio-input';
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [position, setPosition] = useState<{ x: number; y: number }>({ x: 16, y: 16 });
  const [dragging, setDragging] = useState(false);
  const dragState = useRef<{ offsetX: number; offsetY: number; active: boolean }>({
    offsetX: 0,
    offsetY: 0,
    active: false,
  });
  const dragMovedRef = useRef(false);
  const miniContainerRef = useRef<HTMLDivElement | null>(null);
  const dockedBarRef = useRef<HTMLDivElement | null>(null);
  const muiTheme = useTheme();
  // Phones (~360px) cannot fit six 44px controls plus the status text, so the
  // docked bar drops prev/next there; both remain in the expanded panel.
  const compactMiniBar = useMediaQuery(muiTheme.breakpoints.down('sm'));

  const [customStations, setCustomStations] = useState<Station[]>([]);
  const [newStationCountryId, setNewStationCountryId] = useState('');
  const [newStationGenreId, setNewStationGenreId] = useState('');
  const [searchCountryId, setSearchCountryId] = useState('');
  const [searchGenreId, setSearchGenreId] = useState('');
  const [favoriteKeys, setFavoriteKeys] = useState<string[]>([]);
  const [hiddenKeys, setHiddenKeys] = useState<string[]>([]);
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);
  const [showHidden, setShowHidden] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);
  const [importMessage, setImportMessage] = useState<string | null>(null);
  const [miniBarDismissed, setMiniBarDismissed] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return readOptionalBrowserStorage('local', 'radio-mini-dismissed') === '1';
  });
  const [importing, setImporting] = useState(false);
  const [editName, setEditName] = useState('');
  const [editCountryId, setEditCountryId] = useState('');
  const [editGenreId, setEditGenreId] = useState('');
  const [lastUpdatedTs, setLastUpdatedTs] = useState<number | null>(null);
  const [autoSkipOnError, setAutoSkipOnError] = useState(false);
  // Start minimized by default; respect previous user choice if stored.
  const [miniBarVisible, setMiniBarVisible] = useState<boolean>(() => {
    if (typeof window === 'undefined') return true;
    const saved = readOptionalBrowserStorage('local', 'radio-mini-visible');
    if (saved === '0') return false;
    if (saved === '1') return true;
    return true; // default minimized to reduce initial noise
  });
  const [loginMiniBarHost, setLoginMiniBarHost] = useState<HTMLElement | null>(null);
  const [pinned, setPinned] = useState(() => {
    if (typeof window === 'undefined') return false;
    return readOptionalBrowserStorage('local', 'radio-pinned') === '1';
  });
  const [showAdvanced, setShowAdvanced] = useState(() => {
    if (typeof window === 'undefined') return false;
    const stored = readOptionalBrowserStorage('local', 'radio-show-advanced');
    if (stored === '1') return true;
    if (stored === '0') return false;
    return false; // default to simple mode
  });
  const [showCatalogSection, setShowCatalogSection] = useState(true);
  const [showAddSection, setShowAddSection] = useState(false);
  const [shareNotice, setShareNotice] = useState<string | null>(null);
  const [broadcastInfo, setBroadcastInfo] = useState<RadioTransmissionInfo | null>(null);
  const [broadcastLoading, setBroadcastLoading] = useState(false);
  const [broadcastError, setBroadcastError] = useState<string | null>(null);
  const [broadcastForm, setBroadcastForm] = useState({ name: '', genreId: '', countryId: '' });
  const [inputLevel, setInputLevel] = useState(0);
  const meterRafRef = useRef<number | null>(null);
  const meterContextRef = useRef<AudioContext | null>(null);
  const previewAudioRef = useRef<HTMLAudioElement | null>(null);
  const [previewError, setPreviewError] = useState<string | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewStatus, setPreviewStatus] = useState<'idle' | 'connecting' | 'live' | 'error'>('idle');
  const customPreviewAudioRef = useRef<HTMLAudioElement | null>(null);
  const [customPreviewStatus, setCustomPreviewStatus] = useState<'idle' | 'loading' | 'playing' | 'error'>('idle');
  const [customPreviewError, setCustomPreviewError] = useState<string | null>(null);
  const [liveStartedAt, setLiveStartedAt] = useState<number | null>(null);
  const [liveElapsedMs, setLiveElapsedMs] = useState(0);
  const [autoStopOptionId, setAutoStopOptionId] = useState('');
  const [audioInputs, setAudioInputs] = useState<MediaDeviceInfo[]>([]);
  const [selectedAudioInput, setSelectedAudioInput] = useState<string>(() => {
    if (typeof window === 'undefined') return '';
    try {
      return readOptionalBrowserStorage('local', LAST_AUDIO_INPUT_KEY) ?? '';
    } catch {
      return '';
    }
  });
  const [browserBroadcastState, setBrowserBroadcastState] = useState<'idle' | 'starting' | 'live'>('idle');
  const [browserBroadcastError, setBrowserBroadcastError] = useState<string | null>(null);
  const browserBroadcastRef = useRef<{ pc: RTCPeerConnection; stream: MediaStream } | null>(null);
  const [inputTestLevel, setInputTestLevel] = useState<number | null>(null);
  const [inputTestActive, setInputTestActive] = useState(false);
  const inputTestStreamRef = useRef<MediaStream | null>(null);
  const inputTestFrameRef = useRef<number | null>(null);
  const inputTestAudioCtxRef = useRef<AudioContext | null>(null);
  const controlFadeSx = {
    opacity: 0.65,
    transition: 'opacity 0.2s ease',
    '&:hover': { opacity: 1 },
  } as const;
  const mediaDevicesSupported = typeof navigator !== 'undefined' && !!navigator.mediaDevices?.getUserMedia;
  const [recentStations, setRecentStations] = useState<Station[]>([]);
  const [muteOnLoad, setMuteOnLoad] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return readOptionalBrowserStorage('local', 'radio-mute-on-load') === '1';
  });
  const sizeOptions = {
    compact: { width: { xs: '95%', sm: 340 }, bodyHeight: '55vh' },
    cozy: { width: { xs: '95%', sm: 440 }, bodyHeight: '68vh' },
    roomy: { width: { xs: '95%', sm: 540 }, bodyHeight: '80vh' },
  } as const;
  const panelSizes = ['compact', 'cozy', 'roomy'] as const;
  type PanelSize = (typeof panelSizes)[number];
  const isPanelSize = (value: string): value is PanelSize =>
    panelSizes.some((size) => size === value);
  const parsePanelSize = (value: string | null): PanelSize | null => {
    const trimmed = value?.trim() ?? '';
    return isPanelSize(trimmed) ? trimmed : null;
  };
  const [panelSize, setPanelSize] = useState<PanelSize>(() => {
    if (typeof window === 'undefined') return 'cozy';
    const stored = parsePanelSize(readOptionalBrowserStorage('local', 'radio-panel-size'));
    if (stored) return stored;
    return 'cozy';
  });
  useEffect(() => {
    try {
      writeOptionalBrowserPreference('radio-panel-size', panelSize);
    } catch {
      // ignore
    }
  }, [panelSize]);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const torrentSessionRef = useRef<TorrentAudioSession | null>(null);
  const torrentAbortRef = useRef<AbortController | null>(null);
  const torrentLoadRequestRef = useRef(0);
  const [expanded, setExpanded] = useState(false);
  const [activeId, setActiveId] = useState<string>(() => {
    if (typeof window === 'undefined') return EMPTY_STATION.id;
    const stored = readOptionalBrowserStorage('local', 'radio-active-id');
    return stored ?? EMPTY_STATION.id;
  });
  const [isPlaying, setIsPlaying] = useState(false);
  const isPlayingRef = useRef(false);
  const [muted, setMuted] = useState(false);
  const [nowPlayingTitle, setNowPlayingTitle] = useState<string | null>(null);
  const [volume, setVolume] = useState<number>(() => {
    if (typeof window === 'undefined') return 0.8;
    const raw = readOptionalBrowserStorage('local', 'radio-volume');
    const parsed = raw ? Number(raw) : NaN;
    if (Number.isFinite(parsed) && parsed >= 0 && parsed <= 1) return parsed;
    return 0.8;
  });
  const [playbackWarning, setPlaybackWarning] = useState<string | null>(null);
  const [torrentLoadAttempt, setTorrentLoadAttempt] = useState(0);
  const [torrentStatus, setTorrentStatus] = useState<'idle' | 'loading' | 'ready' | 'error'>('idle');
  const [torrentProgress, setTorrentProgress] = useState<TorrentPlaybackProgress | null>(null);
  const [promptDraft, setPromptDraft] = useState('');
  const promptInputRef = useRef<HTMLInputElement | null>(null);
  const [promptState, setPromptState] = useState<Record<string, Prompt[]>>({});
  useEffect(() => {
    isPlayingRef.current = isPlaying;
  }, [isPlaying]);
  const keyFor = useCallback((station: Station) => station.streamUrl.toLowerCase(), []);
  const countryIdQuery = searchCountryId.trim();
  const genreIdQuery = searchGenreId.trim();
  const countriesQuery = useQuery({
    queryKey: ['catalog', 'countries', 'es', 'radio'],
    queryFn: () => Catalogs.listItems('countries', { locale: 'es', page: 1, pageSize: 500 }),
    staleTime: 5 * 60 * 1000,
    gcTime: 30 * 60 * 1000,
    retry: false,
  });
  const genresQuery = useQuery({
    queryKey: ['catalog', 'genres', 'es', 'radio'],
    queryFn: () => Catalogs.listItems('genres', { locale: 'es', page: 1, pageSize: 500 }),
    staleTime: 5 * 60 * 1000,
    gcTime: 30 * 60 * 1000,
    retry: false,
  });
  const autoStopOptionsQuery = useQuery({
    queryKey: ['radio-auto-stop-options', 'es'],
    queryFn: () => RadioAPI.listAutoStopOptions('es'),
    staleTime: 5 * 60 * 1000,
    gcTime: 30 * 60 * 1000,
    retry: false,
  });
  const autoStopOptions = useMemo(
    () => autoStopOptionsQuery.data?.options ?? [],
    [autoStopOptionsQuery.data?.options],
  );
  const selectedAutoStopOption = useMemo(
    () => autoStopOptions.find((option) => option.id === autoStopOptionId) ?? null,
    [autoStopOptionId, autoStopOptions],
  );
  const autoStopMinutes = selectedAutoStopOption?.durationMinutes ?? 0;
  useEffect(() => {
    if (autoStopOptions.length === 0) {
      setAutoStopOptionId('');
      return;
    }
    if (autoStopOptions.some((option) => option.id === autoStopOptionId)) return;
    const persistedDefault = autoStopOptions.find((option) => option.defaultForBroadcast);
    setAutoStopOptionId(persistedDefault?.id ?? '');
  }, [autoStopOptionId, autoStopOptions]);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      writeOptionalBrowserPreference('radio-expanded', expanded ? '1' : '0');
    } catch {
      // ignore
    }
  }, [expanded]);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      writeOptionalBrowserPreference('radio-pinned', pinned ? '1' : '0');
    } catch {
      // ignore
    }
  }, [pinned]);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      writeOptionalBrowserPreference('radio-show-advanced', showAdvanced ? '1' : '0');
    } catch {
      // ignore
    }
  }, [showAdvanced]);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      writeOptionalBrowserPreference('radio-mute-on-load', muteOnLoad ? '1' : '0');
    } catch {
      // ignore
    }
  }, [muteOnLoad]);
  const meterLevel = inputTestActive && inputTestLevel !== null ? inputTestLevel : inputLevel;
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = muted ? 0 : volume;
    }
    if (typeof window !== 'undefined') {
      try {
        writeOptionalBrowserPreference('radio-volume', volume.toString());
      } catch {
        // ignore
      }
    }
  }, [muted, volume]);

  const refreshAudioInputs = useCallback(async () => {
    if (!mediaDevicesSupported || !navigator.mediaDevices?.enumerateDevices) return;
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      if (!devices) return;
      const inputs = devices.filter((d) => d.kind === 'audioinput');
      setBrowserBroadcastError(null);
      setAudioInputs(inputs);
      const exists = inputs.find((d) => d.deviceId === selectedAudioInput);
      if (exists) return;
      const firstInput = inputs[0];
      if (firstInput) {
        setSelectedAudioInput(firstInput.deviceId);
      }
    } catch {
      setBrowserBroadcastError('No pudimos leer tus entradas de audio. Revisa permisos del navegador.');
    }
  }, [mediaDevicesSupported, selectedAudioInput]);

  useEffect(() => {
    void refreshAudioInputs();
  }, [refreshAudioInputs]);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      const stored = readOptionalBrowserStorage('local', LAST_AUDIO_INPUT_KEY);
      if (stored && !selectedAudioInput) {
        setSelectedAudioInput(stored);
      }
    } catch {
      // ignore
    }
  }, [LAST_AUDIO_INPUT_KEY, selectedAudioInput]);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (!selectedAudioInput) return;
    try {
      writeOptionalBrowserPreference(LAST_AUDIO_INPUT_KEY, selectedAudioInput);
    } catch {
      // ignore
    }
  }, [LAST_AUDIO_INPUT_KEY, selectedAudioInput]);

  useEffect(() => {
    if (!mediaDevicesSupported || !navigator.mediaDevices?.addEventListener) return;
    const handleChange = () => {
      void refreshAudioInputs();
    };
    navigator.mediaDevices.addEventListener('devicechange', handleChange);
    return () => navigator.mediaDevices.removeEventListener('devicechange', handleChange);
  }, [mediaDevicesSupported, refreshAudioInputs]);

  const warmMicPermission = useCallback(async () => {
    if (!mediaDevicesSupported || !navigator.mediaDevices?.getUserMedia) return;
    try {
      await navigator.mediaDevices.getUserMedia({ audio: true });
      setBrowserBroadcastError(null);
      await refreshAudioInputs();
    } catch {
      setBrowserBroadcastError('Necesitamos permiso de micrófono para listar tus entradas.');
    }
  }, [mediaDevicesSupported, refreshAudioInputs]);

  const radioSearch = useQuery<RadioStreamDTO[], Error>({
    queryKey: ['radio-streams', countryIdQuery, genreIdQuery],
    queryFn: () => RadioAPI.search({ countryId: countryIdQuery, genreId: genreIdQuery }),
    staleTime: 60_000,
    gcTime: 5 * 60_000,
    retry: false,
  });
  const refetchStreams = radioSearch.refetch;
  const streamsFetching = radioSearch.isFetching;
  const streamsError = radioSearch.error;
  useEffect(() => {
    if (streamsError) {
      const msg = streamsError instanceof Error ? streamsError.message : 'No se pudo cargar el catálogo de radios.';
      setApiError(msg);
    } else {
      setApiError(null);
    }
  }, [streamsError]);

  useEffect(() => {
    if (radioSearch.data) {
      setLastUpdatedTs(Date.now());
    }
  }, [radioSearch.data]);

  // Hydrate favorites/hidden preferences
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      const favRaw = readOptionalBrowserStorage('local', 'radio-favorites');
      if (favRaw) {
        const parsed = JSON.parse(favRaw);
        if (Array.isArray(parsed)) {
          setFavoriteKeys(parsed.filter((item): item is string => typeof item === 'string'));
        }
      }
      const hidRaw = readOptionalBrowserStorage('local', 'radio-hidden');
      if (hidRaw) {
        const parsed = JSON.parse(hidRaw);
        if (Array.isArray(parsed)) {
          setHiddenKeys(parsed.filter((item): item is string => typeof item === 'string'));
        }
      }
      const favFilter = readOptionalBrowserStorage('local', 'radio-show-favorites');
      if (favFilter) setShowFavoritesOnly(favFilter === '1');
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      writeOptionalBrowserPreference('radio-favorites', JSON.stringify(favoriteKeys));
      writeOptionalBrowserPreference('radio-hidden', JSON.stringify(hiddenKeys));
      writeOptionalBrowserPreference('radio-show-favorites', showFavoritesOnly ? '1' : '0');
    } catch {
      // ignore
    }
  }, [favoriteKeys, hiddenKeys, showFavoritesOnly]);
  const favoriteSet = useMemo(() => new Set(favoriteKeys), [favoriteKeys]);
  const hiddenSet = useMemo(() => new Set(hiddenKeys), [hiddenKeys]);

  const dbStations = useMemo<Station[]>(() => {
    if (!radioSearch.data) return [];
    return radioSearch.data.map((dto) => ({
      id: `db-${dto.rsId}`,
      name: dto.rsName ?? 'Radio',
      streamUrl: dto.rsStreamUrl,
      countryId: dto.rsCountryId ?? undefined,
      country: dto.rsCountry ?? undefined,
      genreId: dto.rsGenreId ?? undefined,
      genre: dto.rsGenre ?? undefined,
      mood: dto.rsGenre ?? 'Live',
      prompts: [],
      source: 'db',
    }));
  }, [radioSearch.data]);
  const allStations = useMemo<Station[]>(() => {
    const merged = [...dbStations, ...customStations];
    const map = new Map<string, Station>();
    merged.forEach((station) => {
      const key = station.streamUrl.toLowerCase();
      if (!map.has(key)) {
        map.set(key, station);
      } else {
        const current = map.get(key)!;
        map.set(key, { ...current, ...station, prompts: current.prompts?.length ? current.prompts : station.prompts });
      }
    });
    return Array.from(map.values());
  }, [customStations, dbStations]);
  const defaultStation = allStations[0] ?? EMPTY_STATION;
  useEffect(() => {
    if (allStations.length > 0 && !allStations.some((station) => station.id === activeId)) {
      setActiveId(allStations[0]!.id);
    }
  }, [activeId, allStations]);
  const availableStations = allStations;
  const visibleStations = useMemo(
    () =>
      allStations.filter((s) => {
        const key = keyFor(s);
        if (!showHidden && hiddenSet.has(key)) return false;
        if (showFavoritesOnly && !favoriteSet.has(key)) return false;
        return true;
      }),
    [allStations, favoriteSet, hiddenSet, showHidden, showFavoritesOnly, keyFor],
  );
  const sortedVisibleStations = useMemo(() => {
    const arr = [...visibleStations];
    arr.sort((a, b) => {
      const aFav = favoriteSet.has(keyFor(a));
      const bFav = favoriteSet.has(keyFor(b));
      if (aFav !== bFav) return aFav ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
    return arr;
  }, [favoriteSet, keyFor, visibleStations]);
  const hiddenStations = useMemo(
    () => allStations.filter((s) => hiddenSet.has(keyFor(s))),
    [allStations, hiddenSet, keyFor],
  );
  const activeStation = useMemo<Station>(
    () => allStations.find((s) => s.id === activeId) ?? defaultStation,
    [activeId, allStations, defaultStation],
  );
  const activeTorrentSource = activeStation.torrentFile ?? (
    isMagnetLink(activeStation.streamUrl) ? activeStation.streamUrl : null
  );
  const isActiveTorrent = activeTorrentSource !== null;
  const countryOptions = useMemo<CatalogItem[]>(
    () => (countriesQuery.data?.items ?? [])
      .filter((country) => country.active)
      .sort((a, b) => a.sortOrder - b.sortOrder || a.name.localeCompare(b.name, 'es')),
    [countriesQuery.data?.items],
  );
  const countryLabels = useMemo(
    () => new Map(countryOptions.map((country) => [country.id, country.name])),
    [countryOptions],
  );
  const genreOptions = useMemo<CatalogItem[]>(
    () => (genresQuery.data?.items ?? [])
      .filter((genre) => genre.active && genre.workflowState === 'published')
      .sort((a, b) => a.sortOrder - b.sortOrder || a.name.localeCompare(b.name, 'es')),
    [genresQuery.data?.items],
  );
  const genreLabels = useMemo(
    () => new Map(genreOptions.map((genre) => [genre.id, genre.name])),
    [genreOptions],
  );
  const stationPrompts = promptState[activeStation.id] ?? activeStation.prompts;
  useEffect(() => {
    setEditName(activeStation.name);
    setEditCountryId(activeStation.countryId ?? '');
    setEditGenreId(activeStation.genreId ?? '');
  }, [activeStation]);
  useEffect(() => {
    setRecentStations((prev) => {
      if (!isPlaying || !activeStation.streamUrl) return prev;
      const exists = prev.find((s) => s.id === activeStation.id);
      const next = [activeStation, ...(exists ? prev.filter((s) => s.id !== activeStation.id) : prev)];
      return next.slice(0, 3);
    });
  }, [activeStation, isPlaying]);
  const toggleFavorite = useCallback(
    (station: Station) => {
      const key = keyFor(station);
      setFavoriteKeys((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
    },
    [keyFor],
  );
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      writeOptionalBrowserPreference('radio-active-id', activeId);
    } catch {
      // ignore
    }
  }, [activeId]);
  const hideStation = useCallback(
    (station: Station) => {
      const key = keyFor(station);
      setHiddenKeys((prev) => (prev.includes(key) ? prev : [...prev, key]));
      if (key === keyFor(activeStation)) {
        setActiveId(defaultStation.id);
      }
    },
    [activeStation, defaultStation.id, keyFor],
  );
  const unhideStation = useCallback(
    (station: Station) => {
      const key = keyFor(station);
      setHiddenKeys((prev) => prev.filter((k) => k !== key));
    },
    [keyFor],
  );
  const jumpToNextStation = useCallback(() => {
    if (sortedVisibleStations.length === 0) return;
    const idx = sortedVisibleStations.findIndex((s) => s.id === activeStation.id);
    const safeIdx = idx === -1 ? 0 : idx;
    const next = sortedVisibleStations[(safeIdx + 1) % sortedVisibleStations.length];
    if (!next) return;
    setActiveId(next.id);
    setPlaybackWarning(null);
    setMuted(false);
    setIsPlaying(true);
  }, [activeStation.id, sortedVisibleStations]);
  const jumpToPreviousStation = useCallback(() => {
    if (sortedVisibleStations.length === 0) return;
    const idx = sortedVisibleStations.findIndex((s) => s.id === activeStation.id);
    const safeIdx = idx === -1 ? 0 : idx;
    const previous =
      sortedVisibleStations[(safeIdx - 1 + sortedVisibleStations.length) % sortedVisibleStations.length];
    if (!previous) return;
    setActiveId(previous.id);
    setPlaybackWarning(null);
    setMuted(false);
    setIsPlaying(true);
  }, [activeStation.id, sortedVisibleStations]);
  const isFavoriteActive = useMemo(() => favoriteSet.has(keyFor(activeStation)), [favoriteSet, activeStation, keyFor]);
  const favoriteToggleLabel = isFavoriteActive
    ? `Quitar ${activeStation.name || 'esta estación'} de favoritos`
    : `Agregar ${activeStation.name || 'esta estación'} a favoritos`;
  const canSkipStations = sortedVisibleStations.length > 1;
  const nowPlayingStatus = isActiveTorrent && torrentStatus === 'loading'
    ? 'Preparando'
    : isPlaying
      ? 'Reproduciendo'
      : 'En pausa';
  const normalizedNowPlayingTitle = nowPlayingTitle?.trim() ?? '';
  const hasNowPlayingTitle =
    normalizedNowPlayingTitle.length > 0 &&
    normalizedNowPlayingTitle.toLowerCase() !== activeStation.name.toLowerCase();
  const stationDescriptor = [activeStation.name, activeStation.mood].filter(Boolean).join(' · ');
  const nowPlayingLabel = hasNowPlayingTitle ? normalizedNowPlayingTitle : activeStation.name;
  const nowPlayingSubtitle = hasNowPlayingTitle ? stationDescriptor : activeStation.genre ?? activeStation.mood;
  const torrentProgressPercent = Math.round((torrentProgress?.progress ?? 0) * 100);
  const torrentDownloadSpeed = torrentProgress
    ? `${(torrentProgress.downloadSpeed / 1024).toFixed(torrentProgress.downloadSpeed >= 1024 * 100 ? 0 : 1)} KB/s`
    : '0 KB/s';

  const clampPosition = useCallback(
    (x: number, y: number) => {
      if (typeof window === 'undefined') return { x, y };
      const rect = containerRef.current?.getBoundingClientRect();
      const margin = 12;
      const width = rect?.width ?? 300;
      const height = rect?.height ?? 260;
      const maxX = Math.max(margin, window.innerWidth - width - margin);
      const maxY = Math.max(margin, window.innerHeight - height - margin);
      return {
        x: Math.min(Math.max(margin, x), maxX),
        y: Math.min(Math.max(margin, y), maxY),
      };
    },
    [],
  );

  // Hydrate initial position
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const fromStorage = readOptionalBrowserStorage('local', 'radio-position');
    if (fromStorage) {
      try {
        const parsed = JSON.parse(fromStorage) as { x: number; y: number };
        setPosition(clampPosition(parsed.x, parsed.y));
        return;
      } catch {
        // ignore parsing errors
      }
    }
    const width = window.innerWidth;
    const height = window.innerHeight;
    const initial = clampPosition(width - 320, height - 320);
    setPosition(initial);
  }, [clampPosition]);

  // Opening the panel or changing its contents can make a saved position too low.
  useEffect(() => {
    if (miniBarVisible || miniBarDismissed || compactMiniBar) return;
    const keepInBounds = () => setPosition((p) => {
      const next = clampPosition(p.x, p.y);
      return next.x === p.x && next.y === p.y ? p : next;
    });
    keepInBounds();
    const observer = typeof ResizeObserver === 'undefined' ? null : new ResizeObserver(keepInBounds);
    if (containerRef.current) observer?.observe(containerRef.current);
    return () => observer?.disconnect();
  }, [clampPosition, compactMiniBar, expanded, miniBarDismissed, miniBarVisible, panelSize]);
  const resetPosition = useCallback(() => {
    if (typeof window === 'undefined') return;
    const width = window.innerWidth;
    const height = window.innerHeight;
    const initial = clampPosition(width - 320, height - 320);
    setPosition(initial);
    try {
      writeOptionalBrowserPreference('radio-position', JSON.stringify(initial));
    } catch {
      // ignore
    }
  }, [clampPosition]);

  // Keep the widget within bounds on resize
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const onResize = () => {
      setPosition((p) => clampPosition(p.x, p.y));
    };
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, [clampPosition]);

  // Drag handlers
  const isInteractiveTarget = useCallback((target?: HTMLElement | null) =>
    Boolean(target?.closest('button, a, input, textarea, select, option, [data-no-drag]')),
  []);
  const onPointerDown = useCallback(
    (e: React.PointerEvent) => {
      const target = e.target as HTMLElement | null;
      const dragHandle = target?.closest('[data-drag-handle]');
      const isInteractive = isInteractiveTarget(target);
      // Controls inside the handle must keep their native click/touch behavior.
      if (!dragHandle || isInteractive) {
        return;
      }
      e.preventDefault();
      dragMovedRef.current = false;
      dragState.current = { offsetX: e.clientX - position.x, offsetY: e.clientY - position.y, active: true };
      setDragging(true);
      target?.setPointerCapture?.(e.pointerId);
    },
    [isInteractiveTarget, position.x, position.y],
  );

  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (!dragging || !dragState.current.active) return;
    const move = (e: PointerEvent) => {
      if (!dragState.current.active) return;
      dragMovedRef.current = true;
      const next = clampPosition(e.clientX - dragState.current.offsetX, e.clientY - dragState.current.offsetY);
      setPosition(next);
      try {
        writeOptionalBrowserPreference('radio-position', JSON.stringify(next));
      } catch {
        // ignore storage errors
      }
    };
    const up = () => {
      dragState.current.active = false;
      setDragging(false);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
    window.addEventListener('pointercancel', up);
    return () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      window.removeEventListener('pointercancel', up);
    };
  }, [clampPosition, dragging]);

  // Hydrate prompts and radio settings from localStorage to keep user submissions/settings across reloads.
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      const rawStations = readOptionalBrowserStorage('local', 'radio-stations');
      if (rawStations) {
        const parsedStations: Station[] = JSON.parse(rawStations);
        setCustomStations(
          parsedStations.map((s) => ({
            ...s,
            source: s.source ?? 'custom',
            mood: s.mood ?? s.genre ?? 'Custom',
          })),
        );
      }
      const raw = readOptionalBrowserStorage('local', 'radio-prompts');
      if (!raw) return;
      const saved: Record<string, Prompt[]> = JSON.parse(raw);
      setPromptState((prev) => ({ ...prev, ...saved }));
    } catch {
      // ignore parse errors
    }
    try {
      const rawSettings = readOptionalBrowserStorage('local', 'radio-settings');
      if (rawSettings) {
        const parsed = JSON.parse(rawSettings) as { stationId?: string; playOnLoad?: boolean; muted?: boolean };
        if (parsed.stationId) setActiveId(parsed.stationId);
        if (parsed.muted !== undefined) setMuted(parsed.muted);
        if (parsed.playOnLoad) setIsPlaying(true);
      }
    } catch {
      // ignore parse errors
    }
  }, []);

  // Persist prompts and settings to localStorage when they change.
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      writeOptionalBrowserPreference('radio-prompts', JSON.stringify(promptState));
    } catch {
      // ignore quota errors
    }
  }, [promptState]);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      const settings = {
        stationId: activeStation.id,
        playOnLoad: isPlaying,
        muted,
      };
      writeOptionalBrowserPreference('radio-settings', JSON.stringify(settings));
      const persistentStations = customStations.filter((station) => !station.torrentFile);
      writeOptionalBrowserPreference('radio-stations', JSON.stringify(persistentStations));
    } catch {
      // ignore
    }
  }, [activeStation.id, isPlaying, muted, customStations]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return undefined;

    const requestId = torrentLoadRequestRef.current + 1;
    torrentLoadRequestRef.current = requestId;
    torrentAbortRef.current?.abort();
    torrentAbortRef.current = null;
    torrentSessionRef.current?.destroy();
    torrentSessionRef.current = null;
    audio.pause();
    audio.removeAttribute('src');
    audio.load();
    setTorrentProgress(null);

    if (!activeStation.streamUrl) {
      setTorrentStatus('idle');
      setIsPlaying(false);
      setPlaybackWarning('La emisora no tiene un stream disponible. Elige otra estación.');
      return undefined;
    }

    if (!activeTorrentSource) {
      setTorrentStatus('idle');
      audio.src = activeStation.streamUrl;
      audio.load();
      return undefined;
    }

    setTorrentStatus('loading');
    setPlaybackWarning('Buscando peers y metadata del torrent…');
    const torrentAbort = new AbortController();
    torrentAbortRef.current = torrentAbort;
    void createTorrentAudioSession({
      source: activeTorrentSource,
      audio,
      signal: torrentAbort.signal,
      onProgress: (progress) => {
        if (torrentLoadRequestRef.current !== requestId) return;
        setTorrentProgress(progress);
      },
      onWarning: (message) => {
        if (torrentLoadRequestRef.current !== requestId) return;
        logger.warn('Aviso de WebTorrent', message);
      },
    })
      .then((session) => {
        if (torrentLoadRequestRef.current !== requestId) {
          session.destroy();
          return;
        }
        torrentSessionRef.current = session;
        setTorrentStatus('ready');
        setPlaybackWarning(null);
        if (audioRef.current && isPlayingRef.current) {
          void audioRef.current.play().catch(() => {
            setIsPlaying(false);
            setPlaybackWarning('El torrent está listo. Pulsa reproducir para iniciar el audio.');
          });
        }
      })
      .catch((error: unknown) => {
        if (torrentLoadRequestRef.current !== requestId) return;
        const message = error instanceof Error ? error.message : 'No pudimos abrir este torrent.';
        setTorrentStatus('error');
        setIsPlaying(false);
        setPlaybackWarning(message);
      });

    return () => {
      if (torrentLoadRequestRef.current === requestId) {
        torrentLoadRequestRef.current += 1;
      }
      torrentAbort.abort();
      if (torrentAbortRef.current === torrentAbort) {
        torrentAbortRef.current = null;
      }
      torrentSessionRef.current?.destroy();
      torrentSessionRef.current = null;
    };
  }, [
    activeStation.id,
    activeStation.streamUrl,
    activeTorrentSource,
    torrentLoadAttempt,
  ]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.muted = muted;
    if (!isPlaying) {
      audio.pause();
      return;
    }
    if (isActiveTorrent && torrentStatus !== 'ready') return;
    window.dispatchEvent(new CustomEvent(RADIO_TAKEOVER_EVENT));
    void audio.play().catch(() => {
      setIsPlaying(false);
      setPlaybackWarning(
        isActiveTorrent
          ? 'El torrent está listo. Pulsa reproducir otra vez para iniciar el audio.'
          : 'No se pudo reproducir este stream. Intenta con otra estación o revisa la URL.',
      );
    });
  }, [activeStation.streamUrl, isActiveTorrent, isPlaying, muted, torrentStatus]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    let clearTimer: number | undefined;
    const handleError = () => {
      setIsPlaying(false);
      const fallbackToDefault = !isActiveTorrent && activeStation.id !== defaultStation.id;
      setPlaybackWarning(
        isActiveTorrent
          ? `No pudimos reproducir ${torrentProgress?.fileName ?? 'el audio de este torrent'}.`
          : fallbackToDefault
          ? `No pudimos reproducir ${activeStation.name || 'esta emisora'}. Cambiamos a ${defaultStation.name}.`
          : 'No pudimos reproducir esta emisora. Revisa el stream o prueba con otra.',
      );
      if (fallbackToDefault) {
        setActiveId(defaultStation.id);
        setTimeout(() => setIsPlaying(true), 160);
      }
    };
    const handleCanPlay = () => {
      if (clearTimer) {
        window.clearTimeout(clearTimer);
      }
      if (!playbackWarning) return;
      clearTimer = window.setTimeout(() => setPlaybackWarning(null), 2400);
    };
    audio.addEventListener('error', handleError);
    audio.addEventListener('canplay', handleCanPlay);
    return () => {
      if (clearTimer) {
        window.clearTimeout(clearTimer);
      }
      audio.removeEventListener('error', handleError);
      audio.removeEventListener('canplay', handleCanPlay);
    };
  }, [
    activeStation.id,
    activeStation.name,
    defaultStation.id,
    defaultStation.name,
    isActiveTorrent,
    playbackWarning,
    torrentProgress?.fileName,
  ]);

  // Publish presence so other perfiles can see current stream.
  useEffect(() => {
    if (!isPlaying || !activeStation.streamUrl || isActiveTorrent) {
      void RadioAPI.clearPresence().catch(() => undefined);
      return undefined;
    }
    const timer = setTimeout(() => {
      void RadioAPI.setPresence({
        rpuStreamUrl: activeStation.streamUrl,
        rpuStationName: activeStation.name,
        rpuStationId: activeStation.id,
      }).catch(() => {
        // ignore presence errors
      });
    }, 180);
    return () => {
      clearTimeout(timer);
    };
  }, [activeStation.id, activeStation.name, activeStation.streamUrl, isActiveTorrent, isPlaying]);

  const fetchNowPlaying = useCallback(async () => {
    if (!activeStation.streamUrl || isActiveTorrent) {
      setNowPlayingTitle(null);
      return;
    }
    try {
      const resp = await RadioAPI.nowPlaying({ rnpStreamUrl: activeStation.streamUrl });
      const rawTitle = resp?.rnpTitle?.trim() ?? '';
      const artist = resp?.rnpArtist?.trim() ?? '';
      const track = resp?.rnpTrack?.trim() ?? '';
      const combined = artist && track ? `${artist} - ${track}` : track || rawTitle;
      setNowPlayingTitle(combined.length > 0 ? combined : null);
    } catch {
      setNowPlayingTitle(null);
    }
  }, [activeStation.streamUrl, isActiveTorrent]);

  useEffect(() => {
    if (!isPlaying || !activeStation.streamUrl || isActiveTorrent) {
      setNowPlayingTitle(null);
      return;
    }
    setNowPlayingTitle(null);
    void fetchNowPlaying();
    const interval = window.setInterval(() => {
      void fetchNowPlaying();
    }, 30000);
    return () => window.clearInterval(interval);
  }, [activeStation.streamUrl, fetchNowPlaying, isActiveTorrent, isPlaying]);

  useEffect(() => {
    const handleLoadStream = (event: Event) => {
      const detail = (event as CustomEvent<LoadStreamDetail>).detail;
      if (!detail?.streamUrl) return;
      setPlaybackWarning(null);
      const existing = availableStations.find((s) => s.streamUrl === detail.streamUrl);
      if (existing) {
        setActiveId(existing.id);
      } else {
        const id = detail.stationId ?? `shared-${Math.random().toString(36).slice(2, 8)}`;
        const station: Station = {
          id,
          stationId: detail.stationId,
          name: detail.stationName?.trim() ?? 'Stream compartido',
          streamUrl: detail.streamUrl,
          mood: 'Compartido',
          prompts: [],
          source: 'shared',
        };
        setCustomStations((prev) => {
          if (prev.some((s) => s.streamUrl === station.streamUrl)) return prev;
          return [...prev, station];
        });
        setActiveId(id);
      }
      setExpanded(true);
      setMuted(muteOnLoad);
      setIsPlaying(!muteOnLoad);
    };
    window.addEventListener('tdf-radio-load-stream', handleLoadStream);
    return () => window.removeEventListener('tdf-radio-load-stream', handleLoadStream);
  }, [availableStations, muteOnLoad]);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
      setPlaybackWarning(null);
    } else {
      if (muted) setMuted(false);
      if (
        isActiveTorrent
        && (torrentStatus === 'error' || torrentStatus === 'idle' || !torrentSessionRef.current)
      ) {
        setPlaybackWarning('Reintentando conexión con el torrent…');
        setIsPlaying(true);
        setTorrentLoadAttempt((attempt) => attempt + 1);
        return;
      }
      if (isActiveTorrent && torrentStatus !== 'ready') {
        setPlaybackWarning('Buscando peers y preparando el audio del torrent…');
        setIsPlaying(true);
        return;
      }
      window.dispatchEvent(new CustomEvent(RADIO_TAKEOVER_EVENT));
      void audio
        .play()
        .then(() => {
          setPlaybackWarning(null);
          setIsPlaying(true);
        })
        .catch(() => {
          setIsPlaying(false);
          setPlaybackWarning('No se pudo reproducir este stream. Intenta con otra estación o revisa la URL.');
          if (autoSkipOnError) {
            setTimeout(() => jumpToNextStation(), 200);
          }
        });
    }
  };

  const promptsWithCode = useMemo(() => {
    return stationPrompts.map((p) => ({
      ...p,
      code: p.code ?? generateTidalCode(p.text, activeStation.mood).code,
    }));
  }, [activeStation, stationPrompts]);

  const handleShare = useCallback(async () => {
    if (!activeStation.streamUrl) return;
    const shareableUrl = activeStation.torrentFile ? null : activeStation.streamUrl;
    const message = [
      `Escuchando ${activeStation.name} (${activeStation.mood || 'Radio'})`,
      shareableUrl,
    ].filter(Boolean).join('\n');
    try {
      if (navigator.share) {
        await navigator.share({
          title: activeStation.name,
          text: message,
          ...(shareableUrl ? { url: shareableUrl } : {}),
        });
        setShareNotice('Enviado para compartir');
      } else if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(message);
        setShareNotice('Copiado al portapapeles');
      }
      setTimeout(() => setShareNotice(null), 2200);
    } catch {
      setShareNotice('No se pudo compartir. Intenta de nuevo.');
      setTimeout(() => setShareNotice(null), 2200);
    }
  }, [activeStation]);

  const [newStationName, setNewStationName] = useState('');
  const [newStationUrl, setNewStationUrl] = useState('');
  const newStationIsMagnet = isMagnetLink(newStationUrl);
  const normalizeField = useCallback((value?: string | null) => {
    const trimmed = (value ?? '').trim();
    return trimmed === '' ? undefined : trimmed;
  }, []);
  const clearFilters = useCallback(() => {
    setSearchCountryId('');
    setSearchGenreId('');
    void refetchStreams();
  }, [refetchStreams]);
  const handleImportClick = useCallback(() => {
    void (async () => {
      setImporting(true);
      setImportMessage(null);
      setApiError(null);
      try {
        const res = await RadioAPI.importSources({ rirLimit: 800 });
        setImportMessage(`Importadas ${res.rirInserted} nuevas, ${res.rirUpdated} actualizadas de ${res.rirProcessed} streams.`);
        void refetchStreams();
        setLastUpdatedTs(Date.now());
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'No se pudo importar el catálogo.';
        setImportMessage(msg);
      } finally {
        setImporting(false);
      }
    })();
  }, [refetchStreams]);

  const createBroadcast = useCallback(async () => {
    setBroadcastLoading(true);
    setBroadcastError(null);
    try {
      const resp = await RadioAPI.createTransmission({
        name: broadcastForm.name || undefined,
        genreId: broadcastForm.genreId || undefined,
        countryId: broadcastForm.countryId || undefined,
      });
      setBroadcastInfo(resp);
      setApiError(null);
      return resp;
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'No se pudo crear la transmisión.';
      setBroadcastError(msg);
      setBroadcastInfo(null);
      throw new Error(msg);
    } finally {
      setBroadcastLoading(false);
    }
  }, [broadcastForm.countryId, broadcastForm.genreId, broadcastForm.name]);

  const handleCreateBroadcast = useCallback(() => {
    void createBroadcast().catch(() => undefined);
  }, [createBroadcast]);

  const waitForIceGathering = useCallback((pc: RTCPeerConnection) => {
    return new Promise<void>((resolve) => {
      if (pc.iceGatheringState === 'complete') {
        resolve();
        return;
      }
      const timeout = setTimeout(() => {
        pc.removeEventListener('icegatheringstatechange', handler);
        resolve();
      }, 2000);
      const handler = () => {
        if (pc.iceGatheringState === 'complete') {
          clearTimeout(timeout);
          pc.removeEventListener('icegatheringstatechange', handler);
          resolve();
        }
      };
      pc.addEventListener('icegatheringstatechange', handler);
    });
  }, []);

  const stopLevelMonitor = useCallback(() => {
    if (meterRafRef.current) {
      cancelAnimationFrame(meterRafRef.current);
      meterRafRef.current = null;
    }
    if (meterContextRef.current) {
      meterContextRef.current.close().catch(() => undefined);
      meterContextRef.current = null;
    }
    setInputLevel(0);
  }, []);

  const stopInputTest = useCallback(() => {
    if (inputTestFrameRef.current) {
      cancelAnimationFrame(inputTestFrameRef.current);
      inputTestFrameRef.current = null;
    }
    inputTestStreamRef.current?.getTracks().forEach((t) => t.stop());
    inputTestStreamRef.current = null;
    if (inputTestAudioCtxRef.current) {
      inputTestAudioCtxRef.current.close().catch(() => undefined);
      inputTestAudioCtxRef.current = null;
    }
    setInputTestLevel(null);
    setInputTestActive(false);
  }, []);

  const stopBrowserBroadcast = useCallback(() => {
    const current = browserBroadcastRef.current;
    if (current) {
      current.stream.getTracks().forEach((t) => t.stop());
      current.pc.onconnectionstatechange = null;
      current.pc.close();
    }
    browserBroadcastRef.current = null;
    setBrowserBroadcastState('idle');
    stopLevelMonitor();
    setLiveStartedAt(null);
    setLiveElapsedMs(0);
    setPreviewStatus('idle');
  }, [stopLevelMonitor]);

  const stopAllAudio = useCallback(() => {
    const audio = audioRef.current;
    if (audio) {
      audio.pause();
      audio.currentTime = 0;
    }
    if (previewAudioRef.current) {
      previewAudioRef.current.pause();
    }
    if (customPreviewAudioRef.current) {
      customPreviewAudioRef.current.pause();
    }
    torrentSessionRef.current?.destroy();
    torrentSessionRef.current = null;
    torrentLoadRequestRef.current += 1;
    torrentAbortRef.current?.abort();
    torrentAbortRef.current = null;
    setTorrentStatus('idle');
    setTorrentProgress(null);
    void RadioAPI.clearPresence().catch(() => undefined);
    stopInputTest();
    stopBrowserBroadcast();
    setCustomPreviewStatus('idle');
    setCustomPreviewError(null);
    setIsPlaying(false);
    setPlaybackWarning(null);
  }, [stopBrowserBroadcast, stopInputTest]);

  useEffect(() => {
    window.addEventListener(PLAYER_TAKEOVER_EVENT, stopAllAudio);
    return () => window.removeEventListener(PLAYER_TAKEOVER_EVENT, stopAllAudio);
  }, [stopAllAudio]);

  const startInputTest = useCallback(async () => {
    if (!mediaDevicesSupported || !navigator.mediaDevices?.getUserMedia) {
      setBrowserBroadcastError('Tu navegador no permite capturar audio.');
      return;
    }
    try {
      setInputTestActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { deviceId: selectedAudioInput || undefined },
      });
      inputTestStreamRef.current = stream;
      const AudioCtor = window.AudioContext ?? (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtor) {
        setInputTestLevel(null);
        return;
      }
      const ctx = new AudioCtor();
      inputTestAudioCtxRef.current = ctx;
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 512;
      const data = new Uint8Array(analyser.fftSize);
      ctx.createMediaStreamSource(stream).connect(analyser);
      const tick = () => {
        analyser.getByteTimeDomainData(data);
        let sum = 0;
        for (const sample of data) {
          const safeSample = sample ?? 128;
          const v = safeSample - 128;
          sum += v * v;
        }
        const rms = Math.min(1, Math.sqrt(sum / data.length) / 128);
        setInputTestLevel(rms);
        inputTestFrameRef.current = requestAnimationFrame(tick);
      };
      tick();
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'No se pudo acceder al micrófono.';
      setBrowserBroadcastError(msg);
      stopInputTest();
    }
  }, [mediaDevicesSupported, selectedAudioInput, stopInputTest]);

  useEffect(() => () => stopInputTest(), [stopInputTest]);
  useEffect(() => {
    if (browserBroadcastState !== 'live' || !liveStartedAt) {
      setLiveElapsedMs(0);
      return;
    }
    const interval = window.setInterval(() => {
      const elapsed = Date.now() - liveStartedAt;
      setLiveElapsedMs(elapsed);
      if (autoStopMinutes > 0 && elapsed >= autoStopMinutes * 60 * 1000) {
        setBrowserBroadcastError(`Se detuvo automáticamente tras ${autoStopMinutes} min.`);
        stopBrowserBroadcast();
      }
      if (
        autoStopMinutes > 0 &&
        elapsed >= Math.max(0, autoStopMinutes * 60 * 1000 - 2 * 60 * 1000) &&
        elapsed < autoStopMinutes * 60 * 1000
      ) {
        const minsLeft = Math.ceil((autoStopMinutes * 60 * 1000 - elapsed) / 60000);
        setBrowserBroadcastError((prev) => prev ?? `Auto-stop en ${minsLeft} min.`);
      }
    }, 1000);
    return () => window.clearInterval(interval);
  }, [autoStopMinutes, browserBroadcastState, liveStartedAt, stopBrowserBroadcast]);

  const startLevelMonitor = useCallback(
    (stream: MediaStream) => {
      stopLevelMonitor();
      if (typeof AudioContext === 'undefined') return;
      const ctx = new AudioContext();
      meterContextRef.current = ctx;
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 512;
      const data = new Uint8Array(analyser.fftSize);
      source.connect(analyser);
      const tick = () => {
        analyser.getByteTimeDomainData(data);
        let sum = 0;
        for (const sample of data) {
          const safeSample = sample ?? 128;
          const v = safeSample - 128;
          sum += v * v;
        }
        const rms = Math.min(1, Math.sqrt(sum / data.length) / 128);
        setInputLevel(rms);
        meterRafRef.current = requestAnimationFrame(tick);
      };
      tick();
    },
    [stopLevelMonitor],
  );

  const startBrowserBroadcast = useCallback(async () => {
    if (browserBroadcastState === 'live') {
      stopBrowserBroadcast();
      return;
    }
    if (!selectedAutoStopOption) {
      setBrowserBroadcastError('No se pudo validar la política de auto-stop publicada. Recarga el catálogo antes de transmitir.');
      return;
    }
    stopInputTest();
    setBrowserBroadcastError(null);
    setBrowserBroadcastState('starting');
    try {
      const info = broadcastInfo ?? (await createBroadcast());
      if (!info?.rtiWhipUrl) {
        throw new Error('El servidor no expone WHIP/HTTP ingest para publicar desde navegador.');
      }
      if (!mediaDevicesSupported || !navigator.mediaDevices?.getUserMedia) {
        throw new Error('Tu navegador no permite capturar audio.');
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { deviceId: selectedAudioInput || undefined },
      });
      startLevelMonitor(stream);
      const pc = new RTCPeerConnection({
        iceServers: [{ urls: ['stun:stun.l.google.com:19302'] }],
      });
      stream.getAudioTracks().forEach((track) => pc.addTrack(track, stream));
      const offer = await pc.createOffer({ offerToReceiveAudio: false, offerToReceiveVideo: false });
      await pc.setLocalDescription(offer);
      await waitForIceGathering(pc);
      const localSdp = pc.localDescription?.sdp;
      if (!localSdp) {
        throw new Error('No se pudo preparar la oferta de WebRTC.');
      }
      const resp = await fetch(info.rtiWhipUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/sdp' },
        body: localSdp,
        mode: 'cors',
      });
      if (!resp.ok) {
        throw new Error(`WHIP respondió ${resp.status}`);
      }
      const answerSdp = await resp.text();
      await pc.setRemoteDescription(new RTCSessionDescription({ type: 'answer', sdp: answerSdp }));
      pc.onconnectionstatechange = () => {
        if (pc.connectionState === 'connected') {
          setBrowserBroadcastState('live');
          if (!liveStartedAt) {
            setLiveStartedAt(Date.now());
          }
        } else if (['failed', 'disconnected', 'closed'].includes(pc.connectionState)) {
          setBrowserBroadcastError('La conexión de streaming se cerró.');
          stopBrowserBroadcast();
        }
      };
      browserBroadcastRef.current = { pc, stream };
      if (pc.connectionState === 'connected') {
        setBrowserBroadcastState('live');
        if (!liveStartedAt) {
          setLiveStartedAt(Date.now());
        }
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'No se pudo iniciar el stream desde el navegador.';
      setBrowserBroadcastError(msg);
      stopBrowserBroadcast();
    }
  }, [
    broadcastInfo,
    browserBroadcastState,
    createBroadcast,
    mediaDevicesSupported,
    selectedAudioInput,
    startLevelMonitor,
    stopBrowserBroadcast,
    stopInputTest,
    liveStartedAt,
    selectedAutoStopOption,
    waitForIceGathering,
  ]);

  const handlePreviewPlay = useCallback(async () => {
    if (!broadcastInfo?.rtiStreamUrl) return;
    setPreviewError(null);
    setPreviewLoading(true);
    setPreviewStatus('connecting');
    try {
      const audio = previewAudioRef.current ?? new Audio();
      audio.crossOrigin = 'anonymous';
      audio.pause();
      audio.currentTime = 0;
      audio.src = broadcastInfo.rtiStreamUrl;
      previewAudioRef.current = audio;
      audio.onplaying = () => setPreviewStatus('live');
      audio.onerror = () => {
        setPreviewStatus('error');
        setPreviewError('No pudimos reproducir el stream.');
      };
      window.dispatchEvent(new CustomEvent(RADIO_TAKEOVER_EVENT));
      await audio.play();
      setPreviewStatus('live');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'No pudimos reproducir el stream.';
      setPreviewError(msg);
      setPreviewStatus('error');
    } finally {
      setPreviewLoading(false);
    }
  }, [broadcastInfo?.rtiStreamUrl]);

  const liveElapsedLabel = useMemo(() => {
    const totalSeconds = Math.max(0, Math.floor(liveElapsedMs / 1000));
    const h = String(Math.floor(totalSeconds / 3600)).padStart(2, '0');
    const m = String(Math.floor((totalSeconds % 3600) / 60)).padStart(2, '0');
    const s = String(totalSeconds % 60).padStart(2, '0');
    return `${h}:${m}:${s}`;
  }, [liveElapsedMs]);

  const liveCountdownLabel = useMemo(() => {
    if (autoStopMinutes <= 0 || browserBroadcastState !== 'live' || !liveStartedAt) return null;
    const remainingMs = autoStopMinutes * 60 * 1000 - liveElapsedMs;
    if (remainingMs <= 0) return '00:00';
    const totalSeconds = Math.max(0, Math.floor(remainingMs / 1000));
    const m = String(Math.floor(totalSeconds / 60)).padStart(2, '0');
    const s = String(totalSeconds % 60).padStart(2, '0');
    return `${m}:${s}`;
  }, [autoStopMinutes, browserBroadcastState, liveElapsedMs, liveStartedAt]);
  const persistActiveStream = useCallback(
    async (url: string, name?: string, countryId?: string, genreId?: string) => {
      try {
        const payload = {
          rsuStreamUrl: url,
          rsuName: normalizeField(name),
          rsuCountryId: normalizeField(countryId),
          rsuClearCountry: !normalizeField(countryId),
          rsuGenreId: normalizeField(genreId),
          rsuClearGenre: !normalizeField(genreId),
        };
        const saved = await RadioAPI.upsertActive(payload);
        void refetchStreams();
        setApiError(null);
        return saved;
      } catch (err) {
        logger.warn('No se pudo guardar metadata del stream', err);
        const msg = err instanceof Error ? err.message : 'No se pudo guardar metadata del stream.';
        setApiError(msg);
        return null;
      }
    },
    [normalizeField, refetchStreams],
  );
  const addCustomStation = () => {
    const url = newStationUrl.trim();
    const torrentSource = isMagnetLink(url);
    const name = newStationName.trim() || (torrentSource ? magnetDisplayName(url) ?? 'Torrent' : '');
    if (!name || !url) {
      setTestResult('Ingresa un nombre y una URL, o pega un magnet válido.');
      return;
    }
    const id = `${torrentSource ? 'torrent' : 'custom'}-${Math.random().toString(36).slice(2, 8)}`;
    const countryId = normalizeField(newStationCountryId);
    const country = countryId ? countryLabels.get(countryId) : undefined;
    const genreId = normalizeField(newStationGenreId);
    const genre = genreId ? genreLabels.get(genreId) : undefined;
    const station: Station = {
      id,
      name,
      streamUrl: url,
      countryId,
      country,
      genreId,
      genre,
      mood: genre ?? (torrentSource ? 'Torrent P2P' : 'Custom'),
      prompts: [],
      source: torrentSource ? 'torrent' : 'custom',
    };
    setCustomStations((prev) => [...prev, station]);
    setPromptState((prev) => ({ ...prev, [id]: [] }));
    setActiveId(id);
    setPlaybackWarning(null);
    setNewStationName('');
    setNewStationUrl('');
    setNewStationCountryId('');
    setNewStationGenreId('');
    if (torrentSource) {
      setIsPlaying(true);
      setTestResult('Magnet agregado. Buscando peers WebRTC…');
    }
  };

  const handleTorrentFileUpload = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    if (!isTorrentFile(file)) {
      const maxMb = Math.round(MAX_TORRENT_FILE_BYTES / (1024 * 1024));
      setTestResult(`Selecciona un archivo .torrent válido de hasta ${maxMb} MB.`);
      return;
    }

    const id = `torrent-file-${Math.random().toString(36).slice(2, 8)}`;
    const countryId = normalizeField(newStationCountryId);
    const country = countryId ? countryLabels.get(countryId) : undefined;
    const genreId = normalizeField(newStationGenreId);
    const genre = genreId ? genreLabels.get(genreId) : undefined;
    const station: Station = {
      id,
      name: newStationName.trim() || file.name.replace(/\.torrent$/i, '') || 'Torrent',
      streamUrl: `torrent-file:${id}`,
      torrentFile: file,
      countryId,
      country,
      genreId,
      genre,
      mood: genre ?? 'Torrent P2P',
      prompts: [],
      source: 'torrent',
    };

    setCustomStations((prev) => [...prev, station]);
    setPromptState((prev) => ({ ...prev, [id]: [] }));
    setActiveId(id);
    setPlaybackWarning(null);
    setTestResult('Archivo .torrent cargado. Buscando peers WebRTC…');
    setIsPlaying(true);
  };

  const removeCustomStation = (id: string) => {
    setCustomStations((prev) => prev.filter((s) => s.id !== id));
    setPromptState((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
    if (activeId === id) {
      setActiveId(defaultStation.id);
    }
  };

  const [testResult, setTestResult] = useState<string | null>(null);
  const testStream = async () => {
    const url = newStationUrl.trim();
    if (!url) {
      setTestResult('Ingresa una URL para probar.');
      return;
    }
    if (isMagnetLink(url)) {
      setTestResult('Los magnets se verifican al reproducirlos porque necesitan peers WebRTC.');
      return;
    }
    setPlaybackWarning(null);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 6000);
    try {
      const res = await fetch(url, { method: 'HEAD', signal: controller.signal });
      if (res.ok) {
        const saved = await persistActiveStream(url, newStationName, newStationCountryId, newStationGenreId);
        setTestResult(saved ? 'Stream disponible ✅ · guardado en catálogo' : 'Stream disponible ✅');
      } else {
        setTestResult('No pudimos validar el stream. Verifica la URL.');
      }
    } catch {
      setTestResult('No pudimos validar el stream. Verifica la URL.');
    } finally {
      clearTimeout(timeout);
    }
  };

  const previewCustomStream = async () => {
    if (customPreviewStatus === 'playing') {
      if (customPreviewAudioRef.current) {
        customPreviewAudioRef.current.pause();
      }
      setCustomPreviewStatus('idle');
      setCustomPreviewError(null);
      return;
    }
    const url = newStationUrl.trim();
    if (!url) {
      setCustomPreviewStatus('error');
      setCustomPreviewError('Ingresa una URL para previsualizar.');
      return;
    }
    if (isMagnetLink(url)) {
      setCustomPreviewStatus('error');
      setCustomPreviewError('Guarda el magnet para reproducirlo en el player principal.');
      return;
    }
    setCustomPreviewError(null);
    setCustomPreviewStatus('loading');
    try {
      const audio = customPreviewAudioRef.current ?? new Audio();
      audio.pause();
      audio.currentTime = 0;
      audio.crossOrigin = 'anonymous';
      audio.src = url;
      customPreviewAudioRef.current = audio;
      window.dispatchEvent(new CustomEvent(RADIO_TAKEOVER_EVENT));
      await audio.play();
      setCustomPreviewStatus('playing');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'No pudimos reproducir el stream.';
      setCustomPreviewError(msg);
      setCustomPreviewStatus('error');
    }
  };

  const handleAddPrompt = () => {
    const value = promptDraft.trim();
    if (!value) return;
    const newPrompt: Prompt = {
      text: value,
      author: 'Tú',
      createdAt: toLocalDateInputValue(),
      code: generateTidalCode(value, activeStation.mood).code,
    };
    setPromptState((prev) => ({
      ...prev,
      [activeStation.id]: [newPrompt, ...(prev[activeStation.id] ?? [])],
    }));
    setPromptDraft('');
  };

  const openAndFocusPrompt = useCallback(() => {
    setExpanded(true);
    // focus after collapse anim completes
    setTimeout(() => {
      promptInputRef.current?.focus();
    }, 120);
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      writeOptionalBrowserPreference('radio-mini-visible', miniBarVisible ? '1' : '0');
    } catch {
      // ignore persistence issues
    }
  }, [miniBarVisible]);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      writeOptionalBrowserPreference('radio-mini-dismissed', miniBarDismissed ? '1' : '0');
    } catch {
      // ignore
    }
  }, [miniBarDismissed]);

  useEffect(() => {
    // We now keep the player docked globally; skip inline mounting on login.
    setLoginMiniBarHost(null);
  }, [location.pathname]);

  useEffect(
    () => () => {
      stopBrowserBroadcast();
    },
    [stopBrowserBroadcast],
  );

  const shouldInlineMiniBar = false; // always docked at bottom, even on login
  const dockedBarVisible = !miniBarDismissed && miniBarVisible && !shouldInlineMiniBar;

  // Publish the docked bar's height (and reserve it on <body>) so the last
  // form fields and submit buttons can scroll above it instead of under it.
  useDockedBarHeight(RADIO_BAR_HEIGHT_VAR, dockedBarRef, dockedBarVisible);

  const miniBarNode = (
    <Box
      ref={dockedBarRef}
      data-testid="radio-docked-bar"
      sx={{
        position: shouldInlineMiniBar ? 'relative' : 'fixed',
        left: 0,
        right: 0,
        bottom: shouldInlineMiniBar ? 'auto' : ABOVE_GLOBAL_PLAYER,
        // Keep playback controls above the sidebar (drawer), while dialogs
        // retain their modal layer above both.
        zIndex: (theme) => shouldInlineMiniBar ? 'auto' : theme.zIndex.drawer + 1,
        display: 'flex',
        justifyContent: 'center',
        px: 0,
        maxWidth: '100vw',
        boxSizing: 'border-box',
        pb: shouldInlineMiniBar ? 0 : 'env(safe-area-inset-bottom, 0px)',
        pointerEvents: shouldInlineMiniBar ? 'auto' : 'none',
        outline: 'none',
      }}
      tabIndex={0}
      aria-label="Control de radio"
    >
      <Box
        sx={{
          pointerEvents: 'auto',
          bgcolor: 'background.paper',
          boxShadow: shouldInlineMiniBar ? 2 : 10,
          borderRadius: shouldInlineMiniBar ? 2.5 : 0,
          px: shouldInlineMiniBar ? 1.5 : { xs: 1.5, sm: 2 },
          py: shouldInlineMiniBar ? 1 : { xs: 0.75, sm: 1 },
          display: 'flex',
          alignItems: 'center',
          gap: shouldInlineMiniBar ? 1 : { xs: 0.5, sm: 1.25 },
          boxSizing: 'border-box',
          minWidth: 0,
          overflow: 'hidden',
          border: '1px solid',
          borderColor: 'divider',
          width: '100%',
          maxWidth: shouldInlineMiniBar ? 520 : '100%',
          mx: 0,
          cursor: 'default',
          userSelect: 'none',
          '&:focus-visible': {
            outline: '2px solid',
            outlineColor: 'primary.main',
            outlineOffset: 4,
          },
        }}
        ref={miniContainerRef}
      >
        <Tooltip title={isPlaying ? 'Pausar' : 'Reproducir'}>
          <IconButton sx={{ minWidth: 44, minHeight: 44 }} onClick={togglePlay} data-no-drag aria-label={isPlaying ? 'Pausar radio' : 'Reproducir radio'}>
            {isPlaying ? <PauseIcon fontSize="small" /> : <PlayArrowIcon fontSize="small" />}
          </IconButton>
        </Tooltip>
        {!compactMiniBar && (
          <>
            <Tooltip title="Saltar al anterior">
              <span>
                <IconButton
                  sx={{ minWidth: 44, minHeight: 44 }}
                  onClick={jumpToPreviousStation}
                  data-no-drag
                  aria-label="Saltar a la estación anterior"
                  disabled={!canSkipStations}
                >
                  <SkipPreviousIcon fontSize="small" />
                </IconButton>
              </span>
            </Tooltip>
            <Tooltip title="Saltar al siguiente">
              <span>
                <IconButton
                  sx={{ minWidth: 44, minHeight: 44 }}
                  onClick={jumpToNextStation}
                  data-no-drag
                  aria-label="Saltar a la siguiente estación"
                  disabled={!canSkipStations}
                >
                  <SkipNextIcon fontSize="small" />
                </IconButton>
              </span>
            </Tooltip>
          </>
        )}
        <Tooltip title={muted ? 'Quitar silencio' : 'Silenciar'}>
          <IconButton
            sx={{ minWidth: 44, minHeight: 44 }}
            onClick={() => setMuted((m) => !m)}
            data-no-drag
            aria-label={muted ? 'Quitar silencio' : 'Silenciar radio'}
          >
            {muted ? <VolumeOffIcon fontSize="small" /> : <VolumeUpIcon fontSize="small" />}
          </IconButton>
        </Tooltip>
        <Tooltip title="Minimizar radio">
          <IconButton
            sx={{ minWidth: 44, minHeight: 44 }}
            onClick={(e) => {
              e.stopPropagation();
              setMiniBarDismissed(true);
            }}
            data-no-drag
            aria-label="Minimizar radio"
          >
            <KeyboardArrowDownIcon fontSize="small" />
          </IconButton>
        </Tooltip>
        <Tooltip title="Mostrar radio">
          <IconButton
            sx={{ minWidth: 44, minHeight: 44 }}
            onClick={() => {
              setMiniBarVisible(false);
              setExpanded(true);
            }}
            data-no-drag
            aria-label="Expandir radio"
          >
            <OpenInFullIcon fontSize="small" />
          </IconButton>
        </Tooltip>
        <Box
          data-testid="radio-docked-status"
          sx={{ flex: '1 1 auto', minWidth: 0, maxWidth: shouldInlineMiniBar ? '100%' : { xs: 'none', sm: 220 } }}
        >
          <Typography variant="caption" fontWeight={700} noWrap component="p" sx={{ display: 'block' }}>
            {nowPlayingStatus}: {nowPlayingLabel}
          </Typography>
          <Typography variant="caption" color="text.secondary" noWrap component="p" sx={{ display: 'block' }}>
            {nowPlayingSubtitle}
          </Typography>
        </Box>
      </Box>
    </Box>
  );
  const miniBarContent =
    shouldInlineMiniBar && loginMiniBarHost ? createPortal(miniBarNode, loginMiniBarHost) : miniBarNode;

  return (
    <>
      {miniBarDismissed && (
        <Box
          sx={{
            position: 'fixed',
            right: 16,
            bottom: `calc(${ABOVE_GLOBAL_PLAYER} + 16px + env(safe-area-inset-bottom, 0px))`,
            zIndex: (theme) => theme.zIndex.appBar,
            bgcolor: 'background.paper',
            border: '1px solid',
            borderColor: 'divider',
            borderRadius: 999,
            boxShadow: 6,
            display: 'flex',
            alignItems: 'center',
            gap: 1,
            px: 1.5,
            py: 0.75,
          }}
        >
          <Typography variant="caption" color="text.secondary">
            Radio minimizada
          </Typography>
          <Button
            size="small"
            onClick={() => {
              setMiniBarDismissed(false);
              setMiniBarVisible(true);
            }}
            startIcon={<RadioIcon fontSize="small" />}
          >
            Mostrar
          </Button>
        </Box>
      )}
      {!miniBarDismissed && !miniBarVisible && (
        <Box
          data-testid="radio-floating-panel"
          sx={{
            position: 'fixed',
            left: compactMiniBar ? 12 : position.x,
            right: compactMiniBar ? 12 : 'auto',
            top: compactMiniBar ? 'auto' : position.y,
            bottom: compactMiniBar ? `calc(${ABOVE_GLOBAL_PLAYER} + env(safe-area-inset-bottom, 0px) + 12px)` : 'auto',
            zIndex: (theme) => theme.zIndex.appBar,
            width: compactMiniBar ? 'auto' : expanded ? sizeOptions[panelSize].width : 340,
            maxWidth: 'calc(100vw - 24px)',
          }}
          ref={containerRef}
          onPointerDown={pinned || compactMiniBar ? undefined : onPointerDown}
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Escape') {
              e.preventDefault();
              setMiniBarVisible(true);
              return;
            }
            if (e.target !== e.currentTarget) return;
            const step = e.shiftKey ? 20 : 10;
            const tag = (e.target as HTMLElement | null)?.tagName?.toLowerCase();
            if (['input', 'textarea'].includes(tag ?? '')) return;
            if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
              e.preventDefault();
              setPosition((p) => {
                const next = clampPosition(
                  e.key === 'ArrowLeft' ? p.x - step : e.key === 'ArrowRight' ? p.x + step : p.x,
                  e.key === 'ArrowUp' ? p.y - step : e.key === 'ArrowDown' ? p.y + step : p.y,
                );
                try {
                  writeOptionalBrowserPreference('radio-position', JSON.stringify(next));
                } catch {
                  // ignore
                }
                return next;
              });
              return;
            }
            if (e.key.toLowerCase() === 'f') {
              e.preventDefault();
              setShowFavoritesOnly((v) => !v);
            }
            if (e.key.toLowerCase() === 'r') {
              e.preventDefault();
              resetPosition();
            }
            if (e.key.toLowerCase() === 'n') {
              e.preventDefault();
              jumpToNextStation();
            }
            if (e.key.toLowerCase() === 'p') {
              e.preventDefault();
              jumpToPreviousStation();
            }
          }}
        >
      <Card
        elevation={6}
        sx={{
          borderRadius: 3,
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
          maxHeight: compactMiniBar
            ? `calc(100dvh - ${ABOVE_GLOBAL_PLAYER} - env(safe-area-inset-bottom, 0px) - 96px)`
            : `min(${sizeOptions[panelSize].bodyHeight}, calc(100dvh - 24px))`,
        }}
      >
        <Box sx={{ flexShrink: 0, bgcolor: 'action.hover', borderBottom: '1px solid', borderColor: 'divider' }}>
        <Box
          data-drag-handle
          sx={{
            display: 'flex',
            alignItems: 'center',
            gap: 1,
            px: 1.5,
            py: 0.75,
            bgcolor: dragging ? 'action.selected' : 'action.hover',
            cursor: pinned || compactMiniBar ? 'default' : dragging ? 'grabbing' : 'grab',
            touchAction: compactMiniBar ? 'auto' : 'none',
            userSelect: 'none',
          }}
        >
          {!compactMiniBar && <DragIndicatorIcon fontSize="small" color="action" />}
          <Typography variant="caption" color="text.secondary" fontWeight={600} noWrap sx={{ minWidth: 0 }}>
            {compactMiniBar ? 'Radio' : pinned ? 'Fijado' : 'Arrastra para mover'}
          </Typography>
            <Box sx={{ flex: 1 }} />
            <Button
              size="small"
              onClick={() => setMiniBarVisible(true)}
              data-no-drag
              aria-label="Minimizar radio a la barra"
              startIcon={<ExpandMoreIcon fontSize="small" />}
              sx={{ minHeight: 44, flexShrink: 0 }}
            >
              Minimizar
            </Button>
        </Box>
        <Stack direction="row" alignItems="center" flexWrap="wrap" useFlexGap sx={{ px: 1.5, pb: 0.75 }}>
            <Button
              size="small"
              variant="text"
              sx={{ flex: { xs: 1, sm: '0 1 auto' }, minWidth: 0 }}
              onClick={() => setShowAdvanced((v) => !v)}
              data-no-drag
              startIcon={showAdvanced ? <ExpandLessIcon fontSize="small" /> : <ExpandMoreIcon fontSize="small" />}
            >
              {showAdvanced ? 'Modo simple' : 'Controles avanzados'}
            </Button>
            <Tooltip title={pinned ? 'Permitir mover' : 'Fijar posición'}>
              <IconButton
                size="small"
                onClick={() => setPinned((v) => !v)}
                data-no-drag
                color={pinned ? 'primary' : 'inherit'}
                aria-label="Alternar fijación del radio"
                aria-pressed={pinned}
              >
              <PushPinIcon fontSize="small" sx={{ transform: pinned ? 'rotate(25deg)' : 'none' }} />
            </IconButton>
          </Tooltip>
          <Tooltip title="Volver a la esquina">
            <IconButton size="small" onClick={resetPosition} data-no-drag aria-label="Volver a la esquina">
              <RestartAltIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        </Stack>
        </Box>
        <Box data-testid="radio-panel-content" sx={{ overflowY: 'auto', minHeight: 0, overscrollBehavior: 'contain', touchAction: 'pan-y' }}>
        <CardContent
          sx={{ p: 2, cursor: 'pointer' }}
          onClick={(e) => {
            if (dragging || dragMovedRef.current) {
              dragMovedRef.current = false;
              return;
            }
            // Avoid toggling when clicking control buttons
            const tag = (e.target as HTMLElement | null)?.tagName?.toLowerCase();
            if (tag === 'button' || tag === 'svg' || tag === 'path') return;
            openAndFocusPrompt();
          }}
        >
          <Stack direction="row" alignItems="center" spacing={1} flexWrap="wrap" useFlexGap>
            <RadioIcon color="secondary" />
            <Box sx={{ flex: '1 1 calc(100% - 40px)', minWidth: 0 }}>
              <Typography variant="subtitle1" fontWeight={800} noWrap>
                Radio Inteligente
              </Typography>
              <Typography component="p" variant="caption" color="text.secondary" noWrap>
                {nowPlayingStatus}: {nowPlayingLabel}
              </Typography>
              <Typography component="p" variant="caption" color="text.secondary" noWrap>
                {nowPlayingSubtitle}
              </Typography>
              {recentStations.length > 1 && (
                <Stack direction="row" spacing={0.5} flexWrap="wrap" useFlexGap sx={{ mt: 0.5 }}>
                  <Typography variant="caption" color="text.secondary">
                    Recientes:
                  </Typography>
                  {recentStations.slice(1).map((s) => (
                    <Chip
                      key={s.id}
                      label={s.name}
                      size="small"
                      onClick={() => {
                        setActiveId(s.id);
                        setIsPlaying(false);
                        setMuted(muteOnLoad);
                      }}
                      variant="outlined"
                    />
                  ))}
                </Stack>
              )}
            </Box>
            <Tooltip title="Estación anterior">
              <span>
                <IconButton
                  onClick={jumpToPreviousStation}
                  data-no-drag
                  sx={controlFadeSx}
                  aria-label="Saltar a la estación anterior"
                  disabled={!canSkipStations}
                >
                  <SkipPreviousIcon />
                </IconButton>
              </span>
            </Tooltip>
            <Tooltip title={isPlaying ? 'Pausar' : 'Reproducir'}>
              <IconButton
                onClick={togglePlay}
                color="primary"
                data-no-drag
                aria-label={isPlaying ? 'Pausar radio' : 'Reproducir radio'}
              >
                {isPlaying ? <PauseIcon /> : <PlayArrowIcon />}
              </IconButton>
            </Tooltip>
            <Tooltip title="Estación siguiente">
              <span>
                <IconButton
                  onClick={jumpToNextStation}
                  data-no-drag
                  sx={controlFadeSx}
                  aria-label="Saltar a la siguiente estación"
                  disabled={!canSkipStations}
                >
                  <SkipNextIcon />
                </IconButton>
              </span>
            </Tooltip>
            <Tooltip title="Detener todo (audio y presencia)">
              <IconButton
                onClick={stopAllAudio}
                color="error"
                data-no-drag
                sx={controlFadeSx}
                aria-label="Detener todo el audio y la presencia"
              >
                <StopCircleIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title={isFavoriteActive ? 'Quitar de favoritos' : 'Marcar favorito'}>
              <IconButton
                onClick={() => toggleFavorite(activeStation)}
                color={isFavoriteActive ? 'warning' : 'inherit'}
                data-no-drag
                sx={controlFadeSx}
                aria-label={favoriteToggleLabel}
              >
                {isFavoriteActive ? <StarIcon /> : <StarBorderIcon />}
              </IconButton>
            </Tooltip>
            <Tooltip title={muted ? 'Quitar silencio' : 'Silenciar'}>
              <IconButton
                onClick={() => setMuted((m) => !m)}
                color="inherit"
                data-no-drag
                sx={controlFadeSx}
                aria-label={muted ? 'Quitar silencio' : 'Silenciar'}
              >
                {muted ? <VolumeOffIcon /> : <GraphicEqIcon />}
              </IconButton>
            </Tooltip>
            <Box sx={{ flex: '1 1 160px', minWidth: 0, px: 1 }}>
              <Stack direction="row" spacing={1} alignItems="center">
                <VolumeUpIcon fontSize="small" />
                <Slider
                  size="small"
                  aria-label="Volumen"
                  value={muted ? 0 : Math.round(volume * 100)}
                  onChange={(_, val) => {
                    const numeric = Array.isArray(val) ? val[0] : val;
                    if (typeof numeric !== 'number') return;
                    setMuted(false);
                    setVolume(Math.min(1, Math.max(0, numeric / 100)));
                  }}
                  valueLabelDisplay="auto"
                  sx={{ flex: 1 }}
                />
                <Typography variant="caption" color="text.secondary">
                  {Math.round((muted ? 0 : volume) * 100)}%
                </Typography>
                <Button
                  size="small"
                  variant="text"
                  onClick={() => {
                    setMuted(false);
                    setVolume(0.8);
                  }}
                >
                  Reset
                </Button>
              </Stack>
            </Box>
            <FormControlLabel
              control={
                <Switch
                  size="small"
                  checked={muteOnLoad}
                  onChange={(e) => setMuteOnLoad(e.target.checked)}
                  color="warning"
                />
              }
              label="Silenciar al cargar"
              sx={{ ml: 1 }}
            />
            <Tooltip title={showAdvanced ? 'Ocultar catálogo y transmisión' : 'Mostrar catálogo y transmisión'}>
              <IconButton
                onClick={() => setShowAdvanced((v) => !v)}
                color={showAdvanced ? 'secondary' : 'inherit'}
                data-no-drag
                aria-label={showAdvanced ? 'Ocultar catálogo y transmisión' : 'Mostrar catálogo y transmisión'}
                aria-pressed={showAdvanced}
                sx={controlFadeSx}
              >
                {showAdvanced ? <ExpandLessIcon /> : <ExpandMoreIcon />}
              </IconButton>
            </Tooltip>
            <Tooltip title={autoSkipOnError ? 'Desactivar auto-skip al fallar' : 'Saltar al siguiente si falla'}>
              <IconButton
                onClick={() => setAutoSkipOnError((v) => !v)}
                color={autoSkipOnError ? 'success' : 'inherit'}
                data-no-drag
                aria-label={autoSkipOnError ? 'Desactivar auto-skip al fallar' : 'Saltar al siguiente si falla'}
                aria-pressed={autoSkipOnError}
                sx={controlFadeSx}
              >
                <BoltIcon />
              </IconButton>
            </Tooltip>
            <IconButton
              onClick={() => {
                setExpanded((p) => !p);
                if (!expanded) {
                  setTimeout(() => promptInputRef.current?.focus(), 120);
                }
              }}
              color="inherit"
              data-no-drag
              aria-label={expanded ? 'Ocultar panel completo de radio' : 'Mostrar panel completo de radio'}
              aria-expanded={expanded}
              aria-controls="radio-widget-expanded-panel"
              sx={controlFadeSx}
            >
              {expanded ? <ExpandMoreIcon /> : <ExpandLessIcon />}
            </IconButton>
          </Stack>
          <Collapse in={!expanded}>
            <Stack direction="row" spacing={1} mt={1} alignItems="center">
              <GraphicEqIcon fontSize="small" color="secondary" />
              <Typography variant="caption" color="text.secondary">
                Generada en vivo con prompts de usuarios
              </Typography>
            </Stack>
            <Typography variant="caption" color="text.secondary" display="block" mt={0.5}>
              {nowPlayingStatus}: {nowPlayingLabel}
            </Typography>
            <Stack direction="row" spacing={1} mt={1} alignItems="center" sx={{ flexWrap: 'wrap' }}>
              <Button
                variant="outlined"
                size="small"
                startIcon={<ShareIcon fontSize="small" />}
                onClick={() => {
                  void handleShare();
                }}
                data-no-drag
              >
                Compartir stream
              </Button>
              <Button
                variant="text"
                size="small"
                startIcon={<PeopleAltIcon fontSize="small" />}
                onClick={() => navigate('/social')}
                data-no-drag
              >
                Conexiones
              </Button>
              {shareNotice && (
                <Chip label={shareNotice} size="small" color="info" variant="outlined" />
              )}
            </Stack>
          </Collapse>
          {isActiveTorrent && torrentStatus !== 'idle' && (
            <Stack spacing={0.5} sx={{ mt: 1 }} data-no-drag>
              <Stack direction="row" spacing={1} alignItems="center" justifyContent="space-between">
                <Typography variant="caption" color="text.secondary" noWrap>
                  {torrentStatus === 'loading'
                    ? 'Torrent P2P · buscando peers y metadata…'
                    : torrentStatus === 'error'
                      ? 'Torrent P2P · conexión fallida'
                      : `${torrentProgress?.fileName ?? 'Audio'} · ${torrentProgress?.peers ?? 0} peers · ${torrentDownloadSpeed}`}
                </Typography>
                {torrentStatus === 'ready' && (
                  <Typography variant="caption" color="text.secondary">
                    {torrentProgressPercent}%
                  </Typography>
                )}
              </Stack>
              <LinearProgress
                variant={torrentStatus === 'ready' ? 'determinate' : 'indeterminate'}
                value={torrentStatus === 'ready' ? torrentProgressPercent : undefined}
                color={torrentStatus === 'error' ? 'warning' : 'secondary'}
                sx={{ height: 4, borderRadius: 999 }}
              />
              <Typography variant="caption" color="text.secondary">
                WebTorrent comparte las piezas descargadas con otros peers mientras esta fuente esté abierta.
              </Typography>
            </Stack>
          )}
          {playbackWarning && (
            <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap sx={{ mt: 1 }} data-no-drag>
              <WarningAmberIcon fontSize="small" color="warning" />
              <Typography variant="caption" sx={{ color: 'warning.main', flex: '1 1 160px', overflowWrap: 'anywhere' }}>
                {playbackWarning}
              </Typography>
              {sortedVisibleStations.length > 1 && (
                <Button size="small" variant="text" onClick={jumpToNextStation} data-no-drag>
                  Probar siguiente
                </Button>
              )}
            </Stack>
          )}
        </CardContent>
        <Collapse in={expanded} id="radio-widget-expanded-panel">
          <Divider />
          <CardContent
            sx={{
              p: 2,
              pr: 1,
            }}
          >
              <Stack spacing={1.5}>
                <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap">
                  <Typography variant="caption" color="text.secondary">
                    Tamaño del widget:
                  </Typography>
                  {panelSizes.map((key) => (
                    <Chip
                      key={key}
                      size="small"
                      label={key === 'compact' ? 'S' : key === 'cozy' ? 'M' : 'L'}
                      color={panelSize === key ? 'primary' : 'default'}
                      onClick={() => setPanelSize(key)}
                      sx={{ borderRadius: 999 }}
                    />
                  ))}
                  <Typography variant="caption" color="text.secondary">
                    Desplázate para ver más secciones.
                  </Typography>
                </Stack>
                <Stack direction={{ xs: 'column', sm: 'row' }} alignItems={{ xs: 'flex-start', sm: 'center' }} spacing={1}>
                  <Typography variant="body2" color="text.secondary">
                    Estaciones del mundo (usa el widget para escuchar):
                  </Typography>
                  <Box flex={1} />
                  <Stack direction="row" spacing={1}>
                    <Tooltip title={showCatalogSection ? 'Ocultar catálogo' : 'Mostrar catálogo'}>
                      <Button
                        size="small"
                        variant="text"
                        startIcon={showCatalogSection ? <ExpandLessIcon /> : <ExpandMoreIcon />}
                        onClick={() => setShowCatalogSection((v) => !v)}
                        data-no-drag
                      >
                        Catálogo
                      </Button>
                    </Tooltip>
                    <Tooltip title={showAddSection ? 'Ocultar agregar/editar' : 'Mostrar agregar/editar'}>
                      <Button
                        size="small"
                        variant="text"
                        startIcon={showAddSection ? <ExpandLessIcon /> : <ExpandMoreIcon />}
                        onClick={() => setShowAddSection((v) => !v)}
                        data-no-drag
                      >
                        Editar/añadir
                      </Button>
                    </Tooltip>
                  </Stack>
                </Stack>

              <Collapse in={showAdvanced && showCatalogSection} timeout="auto">
                <Stack spacing={1.5}>
                  <Stack spacing={1}>
                    <Typography variant="caption" color="text.secondary">
                      Busca por país o género en el catálogo guardado:
                    </Typography>
                    <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} alignItems="center">
                      <TextField
                        select
                        size="small"
                        label="País"
                        value={searchCountryId}
                        onChange={(e) => setSearchCountryId(e.target.value)}
                        fullWidth
                      >
                        <MenuItem value="">Todos los países</MenuItem>
                        {countryOptions.map((country) => (
                          <MenuItem key={country.id} value={country.id}>{country.name}</MenuItem>
                        ))}
                      </TextField>
                      <TextField
                        select
                        size="small"
                        label="Género"
                        value={searchGenreId}
                        onChange={(e) => setSearchGenreId(e.target.value)}
                        fullWidth
                      >
                        <MenuItem value="">Todos los géneros</MenuItem>
                        {genreOptions.map((genre) => (
                          <MenuItem key={genre.id} value={genre.id}>{genre.name}</MenuItem>
                        ))}
                      </TextField>
                      <Stack direction="row" spacing={1} alignItems="center" sx={{ minWidth: { sm: 220 } }}>
                        <Button
                          variant="contained"
                          size="small"
                          onClick={() => {
                            void refetchStreams();
                          }}
                          disabled={streamsFetching}
                          data-no-drag
                        >
                          {streamsFetching ? 'Buscando...' : 'Buscar'}
                        </Button>
                        {(countryIdQuery || genreIdQuery) && (
                          <Button variant="text" size="small" onClick={clearFilters} data-no-drag>
                            Limpiar
                          </Button>
                        )}
                      </Stack>
                    </Stack>
                    <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} alignItems="center">
                      <FormControlLabel
                        control={
                          <Switch
                            checked={showFavoritesOnly}
                            onChange={() => setShowFavoritesOnly((v) => !v)}
                            color="warning"
                            size="small"
                          />
                        }
                        label="Solo favoritos"
                      />
                      <Button
                        variant="contained"
                        color="secondary"
                        size="small"
                        startIcon={<CloudDownloadIcon fontSize="small" />}
                        onClick={handleImportClick}
                        disabled={importing}
                        data-no-drag
                      >
                        {importing ? 'Importando...' : 'Importar'}
                      </Button>
                      {lastUpdatedTs && (
                        <Typography variant="caption" color="text.secondary">
                          Última actualización: {new Date(lastUpdatedTs).toLocaleTimeString()}
                        </Typography>
                      )}
                    </Stack>

                    <Card variant="outlined" sx={{ mt: 1 }}>
                      <CardContent>
                        <Stack spacing={1}>
                          <Stack direction="row" spacing={1} alignItems="center">
                            <FiberManualRecordIcon color="error" fontSize="small" />
                            <Typography variant="subtitle1" fontWeight={700}>
                              Transmitir mi audio
                            </Typography>
                          </Stack>
                          <Typography variant="body2" color="text.secondary">
                            Genera un stream y publícalo directo desde tu navegador (elige la entrada de tu tarjeta o micrófono) o con OBS/RTMP usando el ingest y la clave generados. Si no quieres configurar nada extra, usa el botón “Ir en vivo aquí”.
                          </Typography>
                          <Stack spacing={1}>
                            <Stack
                              direction={{ xs: 'column', sm: 'row' }}
                              spacing={1}
                              alignItems={{ xs: 'stretch', sm: 'center' }}
                            >
                              <TextField
                                select
                                label="Fuente de audio"
                                value={selectedAudioInput}
                                onChange={(e) => setSelectedAudioInput(e.target.value)}
                                fullWidth
                                size="small"
                                disabled={!mediaDevicesSupported || browserBroadcastState === 'starting'}
                              helperText={
                                !mediaDevicesSupported
                                  ? 'Tu navegador no permite captura de audio.'
                                  : audioInputs.length === 0
                                    ? 'Concede permiso para listar las entradas.'
                                    : 'Usa la entrada de tu tarjeta de sonido o micrófono.'
                              }
                            >
                              {audioInputs.length === 0 ? (
                                <MenuItem value="" disabled>
                                  No hay entradas disponibles
                                </MenuItem>
                              ) : (
                                audioInputs.map((dev) => (
                                  <MenuItem key={`${dev.deviceId}-${dev.label}`} value={dev.deviceId}>
                                    {dev.label || 'Entrada de audio'}
                                  </MenuItem>
                                ))
                              )}
                            </TextField>
                            {audioInputs.length === 0 && mediaDevicesSupported && (
                              <Button variant="text" size="small" onClick={() => void warmMicPermission()}>
                                Permitir micrófono
                              </Button>
                            )}
                              <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} alignItems="center">
                                <Button
                                  variant={browserBroadcastState === 'live' ? 'outlined' : 'contained'}
                                  color={browserBroadcastState === 'live' ? 'error' : 'primary'}
                                  onClick={() => {
                                    void startBrowserBroadcast();
                                  }}
                                  disabled={
                                    !mediaDevicesSupported ||
                                    browserBroadcastState === 'starting' ||
                                    broadcastLoading ||
                                    !selectedAutoStopOption
                                  }
                                  startIcon={<FiberManualRecordIcon color="error" fontSize="small" />}
                                >
                              {browserBroadcastState === 'live'
                                ? 'Detener transmisión'
                                : browserBroadcastState === 'starting'
                                  ? 'Conectando…'
                                  : 'Ir en vivo aquí'}
                              </Button>
                              <Button
                                variant={inputTestActive ? 'outlined' : 'text'}
                                onClick={() => {
                                  if (inputTestActive) {
                                    stopInputTest();
                                  } else {
                                    void startInputTest();
                                  }
                                }}
                                disabled={!mediaDevicesSupported || browserBroadcastState === 'starting'}
                              >
                                {inputTestActive ? 'Detener prueba' : 'Probar entrada'}
                              </Button>
                            </Stack>
                            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} alignItems="center">
                              <Chip
                                label={`Tiempo en vivo: ${liveElapsedLabel}`}
                                size="small"
                                color={browserBroadcastState === 'live' ? 'success' : 'default'}
                              />
                              {liveCountdownLabel && (
                                <Chip
                                  label={`Auto-stop en ${liveCountdownLabel}`}
                                  size="small"
                                  color="warning"
                                  variant="outlined"
                                />
                              )}
                              <TextField
                                select
                                label="Auto-stop"
                                size="small"
                                value={autoStopOptionId}
                                onChange={(e) => setAutoStopOptionId(e.target.value)}
                                sx={{ minWidth: 140 }}
                                disabled={autoStopOptionsQuery.isPending || autoStopOptionsQuery.isError}
                                helperText={
                                  autoStopOptionsQuery.isError
                                    ? 'No se pudo cargar la política publicada.'
                                    : undefined
                                }
                              >
                                {autoStopOptions.map((option) => (
                                  <MenuItem key={option.id} value={option.id}>
                                    {option.label}
                                  </MenuItem>
                                ))}
                              </TextField>
                            </Stack>
                            </Stack>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                              <Typography variant="caption" color="text.secondary">
                                Nivel de entrada
                              </Typography>
                              <Box
                                sx={{
                                  flex: 1,
                                  height: 8,
                                  bgcolor: 'rgba(148,163,184,0.16)',
                                  borderRadius: 1,
                                  overflow: 'hidden',
                                }}
                              >
                                <Box
                                  sx={{
                                    width: `${Math.round(Math.min(1, meterLevel || 0) * 100)}%`,
                                    height: '100%',
                                    bgcolor:
                                      meterLevel && meterLevel > 0.7
                                        ? 'error.main'
                                        : meterLevel && meterLevel > 0.4
                                          ? 'warning.main'
                                          : 'success.main',
                                    transition: 'width 120ms linear',
                                  }}
                                />
                              </Box>
                            </Box>
                          {browserBroadcastState === 'live' && (
                            <Chip label="En vivo desde este navegador" size="small" color="success" />
                          )}
                          {browserBroadcastError && <Typography color="error">{browserBroadcastError}</Typography>}
                          {previewStatus !== 'idle' && (
                            <Typography variant="caption" color="text.secondary">
                              Estado de vista previa: {previewStatus === 'live' ? 'En vivo' : previewStatus === 'connecting' ? 'Conectando' : 'Error'}
                            </Typography>
                          )}
                        </Stack>
                          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}>
                            <TextField
                              label="Nombre"
                              value={broadcastForm.name}
                              onChange={(e) => setBroadcastForm((p) => ({ ...p, name: e.target.value }))}
                              fullWidth
                              size="small"
                            />
                            <TextField
                              select
                              label="Género"
                              value={broadcastForm.genreId}
                              onChange={(e) => setBroadcastForm((p) => ({ ...p, genreId: e.target.value }))}
                              fullWidth
                              size="small"
                            >
                              <MenuItem value="">Sin género</MenuItem>
                              {genreOptions.map((genre) => (
                                <MenuItem key={genre.id} value={genre.id}>{genre.name}</MenuItem>
                              ))}
                            </TextField>
                            <TextField
                              select
                              label="País"
                              value={broadcastForm.countryId}
                              onChange={(e) => setBroadcastForm((p) => ({ ...p, countryId: e.target.value }))}
                              fullWidth
                              size="small"
                            >
                              <MenuItem value="">Sin país</MenuItem>
                              {countryOptions.map((country) => (
                                <MenuItem key={country.id} value={country.id}>{country.name}</MenuItem>
                              ))}
                            </TextField>
                          </Stack>
                          {broadcastError && <Typography color="error">{broadcastError}</Typography>}
                          <Button
                            variant="contained"
                            size="small"
                            onClick={handleCreateBroadcast}
                            disabled={broadcastLoading}
                            startIcon={<FiberManualRecordIcon color="error" fontSize="small" />}
                          >
                            {broadcastLoading ? 'Creando…' : 'Generar ingest/clave'}
                          </Button>
                          {broadcastInfo && (
                            <Stack spacing={1}>
                              <Typography variant="subtitle2">Configura tu emisor</Typography>
                              <TextField
                                label="Ingest URL"
                                value={broadcastInfo.rtiIngestUrl}
                                InputProps={{
                                  readOnly: true,
                                  endAdornment: (
                                    <Tooltip title="Copiar">
                                      <IconButton
                                        size="small"
                                        aria-label="Copiar Ingest URL"
                                        onClick={() => void navigator.clipboard.writeText(broadcastInfo.rtiIngestUrl)}
                                      >
                                        <ContentCopyIcon fontSize="small" />
                                      </IconButton>
                                    </Tooltip>
                                  ),
                                }}
                                fullWidth
                                size="small"
                              />
                              <TextField
                                label="Stream Key"
                                value={broadcastInfo.rtiStreamKey}
                                InputProps={{
                                  readOnly: true,
                                  endAdornment: (
                                    <Tooltip title="Copiar">
                                      <IconButton
                                        size="small"
                                        aria-label="Copiar Stream Key"
                                        onClick={() => void navigator.clipboard.writeText(broadcastInfo.rtiStreamKey)}
                                      >
                                        <ContentCopyIcon fontSize="small" />
                                      </IconButton>
                                    </Tooltip>
                                  ),
                                }}
                                fullWidth
                                size="small"
                              />
                              <TextField
                                label="Publicar desde navegador (WHIP)"
                                value={broadcastInfo.rtiWhipUrl}
                                InputProps={{
                                  readOnly: true,
                                  endAdornment: (
                                    <Tooltip title="Copiar">
                                      <IconButton
                                        size="small"
                                        aria-label="Copiar URL WHIP"
                                        onClick={() => void navigator.clipboard.writeText(broadcastInfo.rtiWhipUrl)}
                                      >
                                        <ContentCopyIcon fontSize="small" />
                                      </IconButton>
                                    </Tooltip>
                                  ),
                                }}
                                fullWidth
                                size="small"
                              />
                              <TextField
                                label="URL público"
                                value={broadcastInfo.rtiStreamUrl}
                                InputProps={{
                                  readOnly: true,
                                  endAdornment: (
                                    <Tooltip title="Copiar">
                                      <IconButton
                                        size="small"
                                        aria-label="Copiar URL publica"
                                        onClick={() => void navigator.clipboard.writeText(broadcastInfo.rtiStreamUrl)}
                                      >
                                        <ContentCopyIcon fontSize="small" />
                                      </IconButton>
                                    </Tooltip>
                                  ),
                                }}
                                fullWidth
                                size="small"
                              />
                              <Typography variant="caption" color="text.secondary">
                                Para evitar software externo, pulsa “Ir en vivo aquí” (usa el WHIP automáticamente). Si prefieres OBS/Larix, coloca Ingest + Stream Key, o usa el enlace WHIP con clientes WebRTC. Comparte el URL público o agrégalo como estación personalizada.
                              </Typography>
                              <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} alignItems="center">
                                <Button
                                  variant="outlined"
                                  size="small"
                                  startIcon={<PlayArrowIcon />}
                                  onClick={() => void handlePreviewPlay()}
                                  disabled={!broadcastInfo?.rtiStreamUrl || previewLoading}
                                >
                                  {previewLoading ? 'Reproduciendo…' : 'Probar reproducción'}
                                </Button>
                                <Chip
                                  size="small"
                                  label={
                                    previewStatus === 'live'
                                      ? 'En vivo'
                                      : previewStatus === 'connecting'
                                        ? 'Conectando...'
                                        : previewStatus === 'error'
                                          ? 'Error'
                                          : 'Sin iniciar'
                                  }
                                  color={
                                    previewStatus === 'live'
                                      ? 'success'
                                      : previewStatus === 'error'
                                        ? 'error'
                                        : 'default'
                                  }
                                />
                                {previewError && (
                                  <Typography variant="caption" color="error">
                                    {previewError}
                                  </Typography>
                                )}
                              </Stack>
                            </Stack>
                          )}
                        </Stack>
                      </CardContent>
                    </Card>
                    {(countryOptions.length > 0 || genreOptions.length > 0) && (
                      <Stack spacing={0.5}>
                        <Typography variant="caption" color="text.secondary">
                          Sugerencias rápidas:
                        </Typography>
                        {countryOptions.length > 0 && (
                          <Stack direction="row" spacing={1} flexWrap="wrap" alignItems="center">
                            <Typography variant="caption" color="text.secondary">
                              País:
                            </Typography>
                            {countryOptions.slice(0, 16).map((country) => (
                              <Chip
                                key={`country-${country.id}`}
                                size="small"
                                label={country.name}
                                onClick={() => setSearchCountryId(country.id)}
                              />
                            ))}
                          </Stack>
                        )}
                        {genreOptions.length > 0 && (
                          <Stack direction="row" spacing={1} flexWrap="wrap" alignItems="center">
                            <Typography variant="caption" color="text.secondary">
                              Género:
                            </Typography>
                            {genreOptions.slice(0, 16).map((genre) => (
                              <Chip
                                key={`genre-${genre.id}`}
                                size="small"
                                label={genre.name}
                                onClick={() => setSearchGenreId(genre.id)}
                              />
                            ))}
                          </Stack>
                        )}
                      </Stack>
                    )}
                    {streamsFetching && (
                      <LinearProgress variant="indeterminate" sx={{ height: 4, borderRadius: 999, maxWidth: 320 }} />
                    )}
                    {streamsError && (
                      <Typography variant="caption" color="error">
                        No se pudo cargar el catálogo de radios.
                      </Typography>
                    )}
                    {apiError && (
                      <Typography variant="caption" color="error">
                        {apiError}
                      </Typography>
                    )}
                    {importMessage && (
                      <Typography variant="caption" color={importMessage.includes('Importadas') ? 'success.main' : 'error'}>
                        {importMessage}
                      </Typography>
                    )}
                  </Stack>
                  <Stack spacing={1}>
                    <Stack direction="row" spacing={1} flexWrap="wrap" alignItems="center">
                      <Typography variant="caption" color="text.secondary">
                        {streamsFetching
                          ? 'Buscando estaciones...'
                          : `Catálogo: ${sortedVisibleStations.length} coincidencias${countryIdQuery || genreIdQuery ? ' (filtrado)' : ''}`}
                      </Typography>
                      {(countryIdQuery || genreIdQuery) && sortedVisibleStations.length === 0 ? (
                        <Typography variant="caption" color="text.secondary">
                          Sin resultados con estos filtros.
                        </Typography>
                      ) : null}
                      {hiddenStations.length > 0 && (
                        <Tooltip title="Mostrar/ocultar estaciones que marcaste como ocultas">
                          <Button
                            size="small"
                            variant={showHidden ? 'contained' : 'outlined'}
                            startIcon={<VisibilityOffIcon fontSize="small" />}
                            onClick={() => setShowHidden((v) => !v)}
                            data-no-drag
                          >
                            {showHidden ? 'Ocultar ocultos' : `Ver ocultos (${hiddenStations.length})`}
                          </Button>
                        </Tooltip>
                      )}
                    </Stack>
                    <LazyPaginatedList
                      items={sortedVisibleStations}
                      loading={streamsFetching}
                      pagination={{
                        itemLabel: 'estaciones',
                        initialRowsPerPage: RADIO_STATION_INITIAL_ROWS_PER_PAGE,
                        rowsPerPageOptions: RADIO_STATION_ROWS_PER_PAGE_OPTIONS,
                        resetKey: [countryIdQuery, genreIdQuery, showHidden, showFavoritesOnly].join('|'),
                      }}
                      renderItems={(visibleStationsPage) => (
                        <Stack direction="row" spacing={1} flexWrap="wrap">
                          {visibleStationsPage.map((station) => (
                            <Chip
                              key={station.id}
                              label={
                                station.country || station.region || station.genre
                                  ? `${station.name} · ${station.country ?? station.region ?? station.genre}`
                                  : station.name
                              }
                              color={station.id === activeId ? 'primary' : 'default'}
                              onClick={() => {
                                setPlaybackWarning(null);
                                setActiveId(station.id);
                              }}
                              variant={station.id === activeId ? 'filled' : 'outlined'}
                              onDelete={
                                station.source === 'custom' || station.source === 'torrent'
                                  ? () => removeCustomStation(station.id)
                                  : () => hideStation(station)
                              }
                              deleteIcon={
                                station.source === 'custom' || station.source === 'torrent'
                                  ? undefined
                                  : <VisibilityOffIcon fontSize="small" />
                              }
                              icon={
                                station.id === activeId ? (
                                  <FiberManualRecordIcon fontSize="small" color="success" />
                                ) : favoriteSet.has(keyFor(station)) ? (
                                  <StarIcon fontSize="small" />
                                ) : undefined
                              }
                            />
                          ))}
                        </Stack>
                      )}
                    />
                    {showHidden && hiddenStations.length > 0 && (
                      <Stack spacing={0.5}>
                        <Typography variant="caption" color="text.secondary">
                          Ocultas ({hiddenStations.length})
                        </Typography>
                        <LazyPaginatedList
                          items={hiddenStations}
                          pagination={{
                            itemLabel: 'ocultas',
                            initialRowsPerPage: RADIO_STATION_INITIAL_ROWS_PER_PAGE,
                            rowsPerPageOptions: RADIO_STATION_ROWS_PER_PAGE_OPTIONS,
                            resetKey: hiddenStations.length,
                          }}
                          renderItems={(visibleHiddenStations) => (
                            <Stack direction="row" spacing={1} flexWrap="wrap">
                              {visibleHiddenStations.map((station) => (
                                <Chip
                                  key={`hidden-${station.id}`}
                                  label={
                                    station.country || station.region || station.genre
                                      ? `${station.name} · ${station.country ?? station.region ?? station.genre}`
                                      : station.name
                                  }
                                  variant="outlined"
                                  onDelete={() => unhideStation(station)}
                                  deleteIcon={<RestartAltIcon fontSize="small" />}
                                />
                              ))}
                            </Stack>
                          )}
                        />
                      </Stack>
                    )}
                  </Stack>
                </Stack>
              </Collapse>

              <Collapse in={showAdvanced && showAddSection} timeout="auto">
                <Stack spacing={1}>
                  <Typography variant="caption" color="text.secondary">
                    Pega una URL de radio o un magnet, o abre un archivo .torrent para escucharlo aquí.
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    Los torrents usan peers WebRTC y reproducen automáticamente el archivo de audio compatible más grande.
                  </Typography>
                  <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}>
                    <TextField
                      size="small"
                      label="Nombre"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      fullWidth
                    />
                    <TextField
                      select
                      size="small"
                      label="País"
                      value={editCountryId}
                      onChange={(e) => setEditCountryId(e.target.value)}
                      fullWidth
                    >
                      <MenuItem value="">Sin país</MenuItem>
                      {countryOptions.map((country) => (
                        <MenuItem key={country.id} value={country.id}>{country.name}</MenuItem>
                      ))}
                    </TextField>
                    <TextField
                      select
                      size="small"
                      label="Género"
                      value={editGenreId}
                      onChange={(e) => setEditGenreId(e.target.value)}
                      fullWidth
                    >
                      <MenuItem value="">Sin género</MenuItem>
                      {genreOptions.map((genre) => (
                        <MenuItem key={genre.id} value={genre.id}>{genre.name}</MenuItem>
                      ))}
                    </TextField>
                    <Button
                      variant="outlined"
                      onClick={() => {
                        void persistActiveStream(activeStation.streamUrl, editName, editCountryId, editGenreId);
                      }}
                      disabled={isActiveTorrent}
                      data-no-drag
                    >
                      Guardar metadata
                    </Button>
                  </Stack>
                  <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}>
                    <TextField
                      size="small"
                      label="Nombre de la radio"
                      value={newStationName}
                      onChange={(e) => setNewStationName(e.target.value)}
                      fullWidth
                    />
                    <TextField
                      size="small"
                      label="URL del stream o magnet"
                      value={newStationUrl}
                      onChange={(e) => setNewStationUrl(e.target.value)}
                      placeholder="https://… o magnet:?xt=urn:btih:…"
                      fullWidth
                    />
                    <TextField
                      select
                      size="small"
                      label="País"
                      value={newStationCountryId}
                      onChange={(e) => setNewStationCountryId(e.target.value)}
                      fullWidth
                    >
                      <MenuItem value="">Sin país</MenuItem>
                      {countryOptions.map((country) => (
                        <MenuItem key={country.id} value={country.id}>{country.name}</MenuItem>
                      ))}
                    </TextField>
                    <TextField
                      select
                      size="small"
                      label="Género"
                      value={newStationGenreId}
                      onChange={(e) => setNewStationGenreId(e.target.value)}
                      fullWidth
                    >
                      <MenuItem value="">Sin género</MenuItem>
                      {genreOptions.map((genre) => (
                        <MenuItem key={genre.id} value={genre.id}>{genre.name}</MenuItem>
                      ))}
                    </TextField>
                    <Stack direction={{ xs: 'row', sm: 'column' }} spacing={1} sx={{ minWidth: { sm: 160 } }}>
                      <Button
                        variant="outlined"
                        onClick={() => {
                          void testStream();
                        }}
                        data-no-drag
                        disabled={newStationIsMagnet}
                      >
                        Probar stream
                      </Button>
                      <Button
                        variant={customPreviewStatus === 'playing' ? 'outlined' : 'text'}
                        onClick={() => {
                          void previewCustomStream();
                        }}
                        data-no-drag
                        disabled={newStationIsMagnet}
                      >
                        {customPreviewStatus === 'playing' ? 'Detener preview' : 'Escuchar preview'}
                      </Button>
                      <Button
                        variant="contained"
                        onClick={addCustomStation}
                        disabled={!newStationUrl.trim() || (!newStationName.trim() && !newStationIsMagnet)}
                        data-no-drag
                      >
                        Guardar
                      </Button>
                      <Button component="label" variant="outlined" data-no-drag>
                        Abrir .torrent
                        <input
                          hidden
                          type="file"
                          accept=".torrent,application/x-bittorrent"
                          onChange={handleTorrentFileUpload}
                        />
                      </Button>
                    </Stack>
                  </Stack>
                  {testResult && (
                    <Stack direction="row" spacing={1} alignItems="center">
                      <WarningAmberIcon fontSize="small" color={testResult.includes('✅') ? 'success' : 'warning'} />
                      <Typography variant="caption" color="text.secondary">
                        {testResult}
                      </Typography>
                    </Stack>
                  )}
                  {customPreviewStatus !== 'idle' && (
                    <Typography variant="caption" color={customPreviewStatus === 'error' ? 'error' : 'text.secondary'}>
                      {customPreviewStatus === 'loading'
                        ? 'Conectando preview…'
                        : customPreviewStatus === 'playing'
                          ? 'Preview reproduciéndose (no se publica).'
                          : customPreviewError ?? 'No pudimos reproducir la preview.'}
                    </Typography>
                  )}
                  <LinearProgress
                    variant="indeterminate"
                    sx={{ height: 6, borderRadius: 999, bgcolor: 'rgba(148,163,184,0.2)' }}
                  />
                  <Typography variant="caption" color="text.secondary">
                    Streams de muestra; agrega tus prompts para escuchar nuevas variaciones.
                  </Typography>
                  <Typography variant="subtitle2">Prompts en uso</Typography>
                  <PromptList prompts={promptsWithCode} />
                  <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}>
                    <TextField
                      fullWidth
                      size="small"
                      label="Nuevo prompt"
                      InputLabelProps={{ shrink: true }}
                      placeholder="Escribe tu prompt (ej. dembow con quenas y delay granular)"
                      value={promptDraft}
                      onChange={(e) => setPromptDraft(e.target.value)}
                      inputRef={promptInputRef}
                    />
                    <Button variant="contained" onClick={handleAddPrompt} disabled={!promptDraft.trim()} data-no-drag>
                      Generar Tidal
                    </Button>
                  </Stack>
                  <Box>
                    <Typography variant="caption" color="text.secondary">
                      Tip: estos streams se generan con un agente que convierte prompts en código Tidal Cycles y los publica en tiempo real.
                    </Typography>
                  </Box>
                </Stack>
              </Collapse>
            </Stack>
          </CardContent>
        </Collapse>
        </Box>
      </Card>
    </Box>
      )}
      {/* Audio is programmatically controlled; captions are not available for live streams. */}
      {/* eslint-disable-next-line jsx-a11y/media-has-caption */}
      <audio ref={audioRef} preload="none" aria-hidden="true" />
      {!miniBarDismissed && miniBarVisible && miniBarContent}
    </>
  );
}
