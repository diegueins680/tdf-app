from pathlib import Path
import subprocess,json,datetime,hashlib
root=Path('/Users/macpro/GitHub/tdf-app');w=Path('/private/tmp/tdf-google-name-main643-20261031T0039');o=Path('/private/tmp/tdf-google-name-main643-qualification-20261031T0039');main='234ff6f7faf1aecf347c8e92a374228f4ec07aaa';old='39b9c78d7fa41b58e468e987914388be6acdf76c';branch='fix/google-name-main643-20261031T0039';o.mkdir();assert not w.exists()
def git(*a,cwd=w):return subprocess.check_output(['git',*a],cwd=cwd)
def run(label,args,cwd):
 r=subprocess.run(args,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(o/(label+'.log')).write_text(r.stdout);return r
r=run('worktree-add',['git','worktree','add','-b',branch,str(w),old],root);assert r.returncode==0
r=run('initial-merge',['git','merge','--no-commit','--no-ff',main],w);merge_exit=r.returncode;assert merge_exit in [0,1]
unmerged=set(git('diff','--name-only','--diff-filter=U','-z').decode().strip('\0').split('\0'))-{''};generated={'formal/system/inventory.json','formal/system/traceability.json','docs/catalog-persistence/reports/static-list-inventory.json','docs/catalog-persistence/reports/list-consumer-matrix.csv'};allowed=generated|{'formal/system/requirements.json','scripts/ci-change-scope.mjs','scripts/__tests__/ci-change-scope.test.mjs'};assert unmerged<=allowed,unmerged
for p in unmerged&generated:(w/p).write_bytes(git('show',main+':'+p))
for p in ['scripts/ci-change-scope.mjs','scripts/__tests__/ci-change-scope.test.mjs']:
 base=git('show',main+':'+p).decode();needle="    || file === 'scripts/test-checkout-money-verifier.py'" if p.endswith('scope.mjs') else "    'scripts/test-checkout-money-verifier.py',";addition="\n    || file === 'scripts/verify-google-account-name.py'" if p.endswith('scope.mjs') else "\n    'scripts/verify-google-account-name.py',";assert base.count(needle)==1 and 'verify-google-account-name.py' not in base;expected=base.replace(needle,needle+addition);(w/p).write_text(expected)
base=json.loads(git('show',main+':formal/system/requirements.json'));prior=json.loads(git('show',old+':formal/system/requirements.json'));own=next(x for x in prior['requirements'] if x['id']=='AUTH-ENTRY-002');assert len(base['requirements'])==159;seen=0
for i,x in enumerate(base['requirements']):
 if x['id']==own['id']:base['requirements'][i]=own;seen+=1
assert seen==1;(w/'formal/system/requirements.json').write_text(json.dumps(base,indent=2,ensure_ascii=False)+'\n')
subprocess.run(['git','add','--',*sorted(allowed)],cwd=w,check=True);assert not git('diff','--name-only','--diff-filter=U').strip()
backend=git('ls-tree','-r','-z',old,'--','tdf-hq');actual={}
for row in backend.split(b'\0'):
 if not row:continue
 header,path=row.split(b'\t',1);mode,kind,oid=header.split();assert kind==b'blob';p=path.decode();assert (w/p).read_bytes()==git('show',old+':'+p),p
for p in ['tdf-hq-ui','.github','ops','package.json','package-lock.json','tdf-mobile']:
 assert not git('diff','--name-only',main,'--',p).strip(),p
for p in ['formal/system/auth-predicates.json','formal/system/recovery-expiry-arithmetic.json','formal/system/mobile-entry-ux.md','scripts/verify-google-account-name.py','scripts/quality-backend.sh']:assert (w/p).read_bytes()==git('show',old+':'+p),p
mobile=w/'tdf-mobile';assert not any(mobile.iterdir());r=run('mobile-clone',['git','clone','--shared','--no-checkout','/private/tmp/tdf-event-finance-range-main643-20261030T2302/tdf-mobile',str(mobile)],w);assert r.returncode==0;pin=git('rev-parse',main+':tdf-mobile').decode().strip();r=run('mobile-checkout',['git','checkout','--detach',pin],mobile);assert r.returncode==0
p={'phase':'NORMAL_MERGE_STAGED_FOR_METADATA','baselineHead':old,'mainSha':main,'branch':branch,'worktree':str(w),'parents':[old,main],'mergeActualExit':merge_exit,'resolvedPaths':sorted(unmerged),'normativeObjects':159,'all158NonownedMainNormsExact':True,'ownAuthEntry002ExactOld':True,'mainPayCheckout001003Preserved':True,'wholeBackendExactOld39':True,'mobile':pin,'ciSelectionUnion':'Main byte-exact plus one existing Google verifier path in classifier and test; retain both Checkout paths and all other main tests.','allNewFilesTrackedBeforeAudit':True,'startedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/'preparation-state.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(p),flush=True)
