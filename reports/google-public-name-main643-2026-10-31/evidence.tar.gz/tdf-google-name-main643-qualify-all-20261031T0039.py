from pathlib import Path
import subprocess,json,hashlib,datetime
w=Path('/private/tmp/tdf-google-name-main643-20261031T0039');o=Path('/private/tmp/tdf-google-name-main643-qualification-20261031T0039');m=json.loads((o/'preparation-state.json').read_text())['sourceCommit'];root=json.loads((o/'root-quality-result.json').read_text());assert root['sourceCommit']==m and all(v==0 for v in root['actualExits'].values()) and root['aliasesRemoved']
r={'sourceCommit':m,'actualExits':{},'scripts':{},'ordering':'Allsourcefingerprint-sensitivephases execute sequentially aftercompletedrootQA/aliascleanup; no concurrentdependencyaliascreation.','startedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
for label in ['qualify-native','fragment','assurance','seal','seal-controls']:
 p=Path('/private/tmp/tdf-google-name-main643-'+label+'-20261031T0039.py');r['scripts'][str(p)]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 with (o/(label+'-execution.log')).open('w') as log:c=subprocess.run(['python3',str(p)],stdout=log,stderr=subprocess.STDOUT)
 r['actualExits'][label]=c.returncode;r['atUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat();(o/'qualification-execution.json').write_text(json.dumps(r,indent=2)+'\n');print(label+' actualexit '+str(c.returncode),flush=True);assert c.returncode==0,label
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip();print('AllcurrentGooglephases passed oncleansource; independentfinalreviewstillrequired',flush=True)
