from pathlib import Path
import os,subprocess,json,datetime,hashlib
w=Path('/private/tmp/tdf-google-name-main643-20261031T0039');o=Path('/private/tmp/tdf-google-name-main643-qualification-20261031T0039');m=json.loads((o/'preparation-state.json').read_text())['sourceCommit']
def git(*a):return subprocess.check_output(['git',*a],cwd=w)
assert git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip()
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env.update(PATH='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.ghcup/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/usr/local/bin:/usr/bin:/bin',STACK_ROOT='/Users/macpro/.stack',PYTHONDONTWRITEBYTECODE='1')
with (o/'google-fragment-driver.log').open('w') as log:r=subprocess.run(['python3','scripts/verify-google-account-name.py'],cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
(o/'google-fragment-execution.json').write_text(json.dumps({'sourceCommit':m,'actualExit':r.returncode,'method':'Existingrepositoryactual-sourcefragmentverifier executes intended19/0 andrestoredemailfallback19/8; realServerAuthmodule15regression separatelyexecutednative.','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n');assert r.returncode==0
f=json.loads((o/'google-fragment-driver.log').read_text());assert f['revision']==m and not f['worktreeDirty'];assert len(f['runs'])==2 and [(x['variant'],x['expectedFailures'],x['expectedResultObserved']) for x in f['runs']]==[('intended',0,True),('restore-email-fallback',8,True)]
for p,h in f['sources'].items():assert hashlib.sha256((w/p).read_bytes()).hexdigest()==h==hashlib.sha256(git('show',m+':'+p)).hexdigest()
assert not git('status','--porcelain').strip();(o/'google-fragment-qualified.json').write_text(json.dumps(f,indent=2)+'\n');print('Currentactualsourcefragment19/0 andrestoredfallback19/8 assertevidence admitted; no HTTP/SQL claim',flush=True)
