from pathlib import Path
import subprocess,json,os,datetime
w=Path('/private/tmp/tdf-google-name-main643-20261031T0039');o=Path('/private/tmp/tdf-google-name-main643-qualification-20261031T0039');p=json.loads((o/'preparation-state.json').read_text());main=p['mainSha'];old=p['baselineHead']
def git(*a):return subprocess.check_output(['git',*a],cwd=w)
md=json.loads((o/'metadata-results.json').read_text());assert len(md['actualExits'])==7 and all(x==0 for x in md['actualExits'].values()) and md['ownedAliasRemoved'];assert git('rev-parse','HEAD').decode().strip()==old and git('rev-parse','MERGE_HEAD').decode().strip()==main
req=json.loads((w/'formal/system/requirements.json').read_text())['requirements'];newmain=json.loads(git('show',main+':formal/system/requirements.json'))['requirements'];prior=json.loads(git('show',old+':formal/system/requirements.json'))['requirements'];by={x['id']:x for x in req};assert len(by)==len(req)==159 and all(by[x['id']]==x for x in newmain if x['id']!='AUTH-ENTRY-002');assert by['AUTH-ENTRY-002']==next(x for x in prior if x['id']=='AUTH-ENTRY-002')
subprocess.run(['git','diff','--check'],cwd=w,check=True);subprocess.run(['git','add','formal/system/inventory.json','formal/system/traceability.json','docs/catalog-persistence/reports/static-list-inventory.json','docs/catalog-persistence/reports/list-consumer-matrix.csv','formal/system/requirements.json'],cwd=w,check=True);r=subprocess.run(['git','commit','-m','Merge protected checkout-verification main into Google name privacy fix'],cwd=w,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(o/'source-commit.log').write_text(r.stdout);assert r.returncode==0,r.stdout
m=git('rev-parse','HEAD').decode().strip();assert git('show','-s','--format=%P',m).decode().split()==[old,main] and not git('status','--porcelain').strip();assert git('rev-parse',m+':tdf-hq')==git('rev-parse',old+':tdf-hq')
# Every historical blob in both parent report/evidence namespaces must remain exact.
def blobs(ref,paths):
 data=git('ls-tree','-r','-z',ref,'--',*paths);out={}
 for row in data.split(b'\0'):
  if not row:continue
  header,name=row.split(b'\t',1);mode,kind,oid=header.split();assert kind==b'blob';out[name.decode()]=oid.decode()
 return out
history={}
current=blobs(m,['reports','formal/system/evidence'])
for parent in [old,main]:
 prior=blobs(parent,['reports','formal/system/evidence'])
 for path,oid in prior.items():assert current.get(path)==oid,path
 history[parent]=len(prior)
env={k:v for k,v in os.environ.items() if k in ['HOME','TMPDIR','USER','LOGNAME','SHELL','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR']};env.update(PATH='/private/tmp/tdf-correctness-bin-20261028:/private/tmp/tdf-event-report-venv-20261027/bin:/Users/macpro/.nvm/versions/node/v24.13.1/bin:/Users/macpro/.ghcup/bin:/usr/local/bin:/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1');checks={}
for label,cmd in [('committed-inventory',['python3','scripts/specification-inventory.py','--check']),('committed-conformance',['python3','scripts/specification-conformance.py','--check']),('source-admission',['python3','scripts/check-new-specification-surfaces.py','--base',main,'--head',m]),('source-ci-selection',['node','scripts/ci-change-scope.mjs','--base',main,'--head',m])]:
 with (o/(label+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 checks[label]=r.returncode;assert r.returncode==0,label
assert not git('status','--porcelain').strip();p.update(phase='CLEAN_CURRENT_MAIN643_SOURCE_PREPARED',sourceCommit=m,normalParents=[old,main],metadataResults=md,committedChecks=checks,historicalParentBlobCountsPreserved=history,wholeBackendGitTreeExactPreviousQualifiedHead=True,all158NonownedMainNormsExactPlusOwnedAuth=True,sourceCleanAfter=True,completedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat());(o/'preparation-state.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps({'sourceCommit':m,'main':main,'parents':[old,main],'historyCounts':history,'checks':checks}),flush=True)
