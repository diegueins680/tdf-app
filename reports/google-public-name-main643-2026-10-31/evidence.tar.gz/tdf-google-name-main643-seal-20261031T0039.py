from pathlib import Path
import json,subprocess,hashlib,datetime,re
w=Path('/private/tmp/tdf-google-name-main643-20261031T0039');o=Path('/private/tmp/tdf-google-name-main643-qualification-20261031T0039');sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=w):return subprocess.check_output(['git',*a],cwd=cwd)
def verify_bindings(m,q,f,s,force,binary,version,n,root,fragment):
 assert q['sourceCommit']==root['sourceCommit']==fragment['revision']==force['sourceCommit']==m and not fragment['worktreeDirty']
 assert set(q['actualExits'])=={'build','targeted','full'} and all(v==0 for v in q['actualExits'].values()) and q['phase']=='QUALIFIED_TARGETED_AND_FULL'
 assert set(root['actualExits'])=={'root-quality','new-surface-admission','catalog-unit'} and all(v==0 for v in root['actualExits'].values()) and root['catalogUnitCases']==8 and root['aliasesRemoved'] and root['sourceCleanAfter']
 assert sha(binary)==force['binarySha256']==q['binarySha256'] and sha(version)==force['versionObjectSha256'] and m.encode() in binary and m.encode() in version and q['forceDirtyIdentity']==force
 assert q['targeted']=={'examples':15,'failures':0,'pending':0} and q['full']=={'examples':4060,'failures':0,'pending':21}
 for key in ['files','digest','revision','mobileGitlink','worktreeDirty']:assert f['provenance'][key]==s[key]
 assert s['revision']==m and not s['worktreeDirty'] and s['digest']==sha(json.dumps(s['files'],sort_keys=True).encode())
 counts={'PROVEN':0,'REFUTED':0,'UNPROVEN':n,'NOT_APPLICABLE':0};assert f['metrics']['requirements']==counts
 for c in ['implementation','refinement']:assert f['metrics']['obligationsByCategory'][c]==counts
 for c,k in [('source-derived-SMT',4),('source-derived-authorization-SMT',3),('source-derived-recovery-SMT',4)]:assert f['metrics']['obligationsByCategory'][c]=={'PROVEN':k,'REFUTED':0,'UNPROVEN':0,'NOT_APPLICABLE':0}
 assert f['execution']['passed'] and f['release']['decision']=='BLOCKED' and f['release']['executionAllowed'] is False
 assert set(fragment['sources'])=={'tdf-hq/test/TDF/Auth/AccountNameSpec.hs', 'tdf-hq/tdf-hq.cabal', 'scripts/verify-google-account-name.py', 'tdf-hq/src/TDF/ServerAuth.hs', 'tdf-hq/test/TDF/Auth/GoogleProfileNameSpec.hs', 'tdf-hq/stack.yaml.lock', 'tdf-hq/src/TDF/Auth/AccountName.hs', 'tdf-hq/stack.yaml'}
 assert len(fragment['runs'])==2
 for r,label,failures in zip(fragment['runs'],['intended','restore-email-fallback'],[0,8]):
  assert r['variant']==label and r['expectedFailures']==failures and r['expectedResultObserved'] and ((r['exit']==0) if not failures else (r['exit']!=0))
  assert len(re.findall(r'^19 examples, '+str(failures)+r' failures?(?:, 0 pending)?\s*$',r['output'],re.M))==1
p=json.loads((o/'preparation-state.json').read_text());m=p['sourceCommit'];old=p['baselineHead'];main=p['mainSha'];assert git('rev-parse','HEAD').decode().strip()==m and not git('status','--porcelain').strip() and git('show','-s','--format=%P',m).decode().split()==[old,main]
assert git('rev-parse',m+':tdf-hq')==git('rev-parse',old+':tdf-hq')
server=git('show',m+':tdf-hq/src/TDF/ServerAuth.hs');needle=b'gpName = normalizedName\n';assert server.count(needle)==1 and server.replace(needle,b'gpName = normalizedName <|> Just normalizedEmail\n')==git('show',main+':tdf-hq/src/TDF/ServerAuth.hs')
for path in ['tdf-hq-ui','.github','ops','package.json','package-lock.json','tdf-mobile','docs/catalog-persistence/catalog-list-decisions.json','scripts/verify-checkout-money.py','scripts/test-checkout-money-verifier.py']:assert git('rev-parse',m+':'+path)==git('rev-parse',main+':'+path),path
for path in ['formal/system/auth-predicates.json','formal/system/recovery-expiry-arithmetic.json','formal/system/mobile-entry-ux.md','scripts/verify-google-account-name.py','scripts/quality-backend.sh']:assert git('show',m+':'+path)==git('show',old+':'+path),path
for path in ['scripts/ci-change-scope.mjs','scripts/__tests__/ci-change-scope.test.mjs']:
 base=git('show',main+':'+path).decode();needle="    || file === 'scripts/test-checkout-money-verifier.py'" if path.endswith('scope.mjs') else "    'scripts/test-checkout-money-verifier.py',";extra="\n    || file === 'scripts/verify-google-account-name.py'" if path.endswith('scope.mjs') else "\n    'scripts/verify-google-account-name.py',";assert base.count(needle)==1 and git('show',m+':'+path).decode()==base.replace(needle,needle+extra)
changed_scripts=set(git('diff','--name-only','-z',main,m,'--','scripts').decode().strip('\0').split('\0'));assert changed_scripts=={'scripts/verify-google-account-name.py','scripts/quality-backend.sh','scripts/ci-change-scope.mjs','scripts/__tests__/ci-change-scope.test.mjs'}
req=json.loads(git('show',m+':formal/system/requirements.json'))['requirements'];mainreq=json.loads(git('show',main+':formal/system/requirements.json'))['requirements'];oldreq=json.loads(git('show',old+':formal/system/requirements.json'))['requirements'];by={x['id']:x for x in req};assert len(by)==len(req)==159 and all(by[x['id']]==x for x in mainreq if x['id']!='AUTH-ENTRY-002') and by['AUTH-ENTRY-002']==next(x for x in oldreq if x['id']=='AUTH-ENTRY-002')
def history(ref):
 table={}
 for row in git('ls-tree','-r','-z',ref,'--','reports','formal/system/evidence').split(b'\0'):
  if not row:continue
  header,path=row.split(b'\t',1);mode,kind,oid=header.split();assert kind==b'blob';table[path]=oid
 return table
current=history(m);historical={}
for ref in [old,main]:
 prior=history(ref);assert all(current.get(path)==oid for path,oid in prior.items());historical[ref]=len(prior)
q=json.loads((o/'native-quality.json').read_text());root=json.loads((o/'root-quality-result.json').read_text());f=json.loads((o/'assurance-committed/report.json').read_text());s=json.loads((o/'assurance-committed/sources.json').read_text());force=json.loads((o/'native-force-dirty-confirmed.json').read_text());fragment=json.loads((o/'google-fragment-qualified.json').read_text());binary=Path(q['binary']).read_bytes();objects=list((w/'tdf-hq/.stack-work/dist').glob('**/tdf-hq-test-tmp/TDF/Version.o'));assert len(objects)==1;verify_bindings(m,q,f,s,force,binary,objects[0].read_bytes(),159,root,fragment)
inputs=json.loads((o/'native-qualified-inputs.json').read_text())['allBackendTrackedGitSha256'];expected=set(git('ls-tree','-r','-z','--name-only',m,'--','tdf-hq').decode().strip('\0').split('\0'));assert set(inputs)==expected
mobile=git('rev-parse',m+':tdf-mobile').decode().strip();assert git('rev-parse','HEAD',cwd=w/'tdf-mobile').decode().strip()==mobile
for table in [s['files'],inputs,fragment['sources']]:
 for ism in [False,True]:
  pairs=[(path,h) for path,h in table.items() if path.startswith('tdf-mobile/')==ism]
  if not pairs:continue
  cwd=w/'tdf-mobile' if ism else w;ref=mobile if ism else m;refs=[ref+':'+(path.removeprefix('tdf-mobile/') if ism else path) for path,h in pairs];assert all('\n' not in x for x in refs);raw=subprocess.check_output(['git','cat-file','--batch'],cwd=cwd,input=('\n'.join(refs)+'\n').encode());pos=0
  for path,h in pairs:
   end=raw.index(b'\n',pos);header=raw[pos:end].split();assert header[1]==b'blob';n=int(header[2]);assert sha(raw[end+1:end+1+n])==h==sha((w/path).read_bytes()),path;pos=end+1+n+1
  assert pos==len(raw)
for path,h in f['evidenceHashes'].items():
 pp=Path(path);assert not pp.is_absolute() and '..' not in pp.parts;assert sha((o/'assurance-committed'/pp).read_bytes())==h,path
assert json.loads((w/'docs/catalog-persistence/reports/static-list-inventory.json').read_text())['candidateCount']==1354
assert (o/'current-catalog.json').read_bytes()==git('show',m+':docs/catalog-persistence/reports/static-list-inventory.json') and (o/'current-catalog.csv').read_bytes()==git('show',m+':docs/catalog-persistence/reports/list-consumer-matrix.csv')
assert all(x==0 for x in p['metadataResults']['actualExits'].values()) and all(x==0 for x in p['committedChecks'].values())
r={'sourceCommit':m,'baselineMain':main,'previousPublishedHead':old,'normalParents':[old,main],'sourceDigest':s['digest'],'wholeBackendExactOld39':True,'onlyProductionSourceDifferenceFromMain':'Remove exactly gpName automaticprivateemail fallback; reversingthe oneassignment reproducesmainServerAuth byteexact.','all158NonownedMainNormsExact':True,'authEntry002ExactPrevious':True,'totalRequirements':159,'bothCheckoutMainAmendmentsPreserved':True,'ciScopeUnionByteExactMainPlusGoogle':True,'allParentHistoricalEvidencePreserved':historical,'registeredHashesVerified':len(s['files']),'allBackendInputCount':len(inputs),'assuranceArtifactHashesVerified':len(f['evidenceHashes']),'fragmentSourceInputs':fragment['sources'],'fragmentRuns':[{'variant':x['variant'],'actualExit':x['exit'],'expectedFailures':x['expectedFailures'],'expectedObserved':x['expectedResultObserved']} for x in fragment['runs']],'nativeTargeted':q['targeted'],'nativeFull':q['full'],'forceDirtyIdentity':force,'assuranceMetrics':f['metrics'],'formalRelease':f['release']['decision'],'newCompleteProofs':0,'sourceCleanAfter':True,'limitations':['TESTED finiteactualServerAuthmodule+syntheticdecoder/sourcefragment; no GoogleHTTP/providercredentialvalidation, accountSQLpersistence, existingaccountbackfill or completeimplementation/refinement theorem.','Explicit validprovidername values arepreserved evenifuser/providerchoseanemail-lookingname; property concerns automatic substitution only.','Source-fragment verifier trusts extraction/caller correspondence andsingle-programHspec reporting underdocumented shapes; itmatchesone19-example summaryratherthanrejectingeverypossiblemixedtranscript. Actualnative15 importServerAuth separately; no currentbadtranscriptobserved.','Native64bitmacOS/GHC9.10.3 only; no fresh servingexecutable/productionPostgreSQL/Docker/physicaldevice qualification; newpublished-headhostedCI/reviewrequired.','Authorization/recovery sourcecontextreview andeleven inheritedconditionalSMTclaims keepassumptions; whole159/318 obligations UNPROVEN, releaseBLOCKED.','Historicalgallery/campaign/workerfailures remainunknowncauses/unrepaired, successfulsamples not repairproof.','Runner cleanup not interruptionfault-tested; no universalcleanup guarantee.'],'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/'source-correspondence.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ['sourceCommit','registeredHashesVerified','allBackendInputCount','assuranceArtifactHashesVerified','nativeTargeted','nativeFull','formalRelease']}),flush=True)
