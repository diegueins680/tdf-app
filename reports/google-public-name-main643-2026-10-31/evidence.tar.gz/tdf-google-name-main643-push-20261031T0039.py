from pathlib import Path
import subprocess,json,datetime
w=Path('/private/tmp/tdf-google-name-main643-20261031T0039');o=Path('/private/tmp/tdf-google-name-main643-qualification-20261031T0039');p=json.loads((o/'preparation-state.json').read_text());pack=json.loads((o/'packaged-head.json').read_text());m=p['sourceCommit'];head=pack['head'];old=p['baselineHead'];main=p['mainSha'];branch='fix/google-profile-name-privacy-20261027'
def git(*a):return subprocess.check_output(['git',*a],cwd=w)
def ref(name):
 rows=git('ls-remote','origin','refs/heads/'+name).decode().splitlines();assert len(rows)==1;sha,n=rows[0].split();assert n=='refs/heads/'+name;return sha
assert git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain').strip();assert git('show','-s','--format=%P',head).decode().split()==[m];subprocess.run(['git','merge-base','--is-ancestor',old,head],cwd=w,check=True);subprocess.run(['git','merge-base','--is-ancestor',main,head],cwd=w,check=True)
assert ref('main')==main and ref(branch)==old,'Main orownerhead advanced; re-evaluate beforepublication'
a=json.loads(subprocess.check_output(['gh','api','repos/diegueins680/tdf-app/pulls/646'],cwd=w));assert a['head']['sha']==old and a['head']['ref']==branch and a['state']=='open' and a['base']['ref']=='main' and a['auto_merge'] is None
subprocess.run(['git','push','origin',head+':refs/heads/'+branch],cwd=w,check=True);assert ref(branch)==head
r={'pr':646,'sourceCommit':m,'publishedHead':head,'previousHead':old,'baselineMain':main,'ordinaryFastForward':True,'forcePush':False,'beforeDraft':a['draft'],'autoMerge':False,'currentHeadCiAndNewReviewRequired':True,'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/'publication-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
