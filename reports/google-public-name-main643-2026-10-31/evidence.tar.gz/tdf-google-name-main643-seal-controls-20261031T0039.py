from pathlib import Path
import ast,json,hashlib,copy,re,datetime
w=Path('/private/tmp/tdf-google-name-main643-20261031T0039');o=Path('/private/tmp/tdf-google-name-main643-qualification-20261031T0039');p=Path('/private/tmp/tdf-google-name-main643-seal-20261031T0039.py');sha=lambda b:hashlib.sha256(b).hexdigest();defs=[x for x in ast.parse(p.read_text()).body if isinstance(x,ast.FunctionDef) and x.name=='verify_bindings'];assert len(defs)==1;ns={'sha':sha,'json':json,'re':re};exec(compile(ast.Module(body=defs,type_ignores=[]),str(p),'exec'),ns);check=ns['verify_bindings']
m=json.loads((o/'preparation-state.json').read_text())['sourceCommit'];q=json.loads((o/'native-quality.json').read_text());f=json.loads((o/'assurance-committed/report.json').read_text());s=json.loads((o/'assurance-committed/sources.json').read_text());force=json.loads((o/'native-force-dirty-confirmed.json').read_text());root=json.loads((o/'root-quality-result.json').read_text());fragment=json.loads((o/'google-fragment-qualified.json').read_text());binary=Path(q['binary']).read_bytes();path=list((w/'tdf-hq/.stack-work/dist').glob('**/tdf-hq-test-tmp/TDF/Version.o'));assert len(path)==1;version=path[0].read_bytes()
def invoke(v):check(m,v['q'],v['f'],v['s'],v['force'],v['binary'],v['version'],159,v['root'],v['fragment'])
def valid():return {'q':copy.deepcopy(q),'f':copy.deepcopy(f),'s':copy.deepcopy(s),'force':copy.deepcopy(force),'root':copy.deepcopy(root),'fragment':copy.deepcopy(fragment),'binary':binary,'version':version}
invoke(valid());rows=[]
def control(label,mutate):
 v=valid();mutate(v)
 try:invoke(v)
 except AssertionError:rows.append({'label':label,'actual':'ASSERTION_REJECTED','expectedRejection':True});return
 raise RuntimeError('Invalid evidence accepted:'+label)
control('MissingNativeExits',lambda v:v['q'].__setitem__('actualExits',{}))
control('MissingFullExit',lambda v:v['q']['actualExits'].pop('full'))
control('IncompleteNativePhase',lambda v:v['q'].__setitem__('phase','BUILDING'))
control('MissingRootQualityExit',lambda v:v['root']['actualExits'].pop('root-quality'))
control('CorruptedVersionBytes',lambda v:v.__setitem__('version',v['version']+b'CORRUPTED'))
control('AssuranceDigestMismatch',lambda v:v['f']['provenance'].__setitem__('digest','0'*64))
control('AssuranceFilesMismatch',lambda v:v['f']['provenance']['files'].__setitem__(next(iter(v['f']['provenance']['files'])),'0'*64))
control('AssuranceDirtyFlag',lambda v:v['f']['provenance'].__setitem__('worktreeDirty',True))
control('UnsupportedWholeProof',lambda v:v['f']['metrics']['requirements'].update(PROVEN=1,UNPROVEN=158))
control('UnsupportedRefinementProof',lambda v:v['f']['metrics']['obligationsByCategory']['refinement'].update(PROVEN=1,UNPROVEN=158))
control('UnsupportedExtraSmtClaim',lambda v:v['f']['metrics']['obligationsByCategory']['source-derived-SMT'].__setitem__('PROVEN',5))
control('UnsupportedReleasePermission',lambda v:v['f']['release'].__setitem__('executionAllowed',True))
def remove_literal(v):
 v['version']=v['version'].replace(m.encode(),b'X'*len(m));assert m.encode() not in v['version'];v['force']['versionObjectSha256']=sha(v['version']);v['q']['forceDirtyIdentity']=copy.deepcopy(v['force'])
control('MissingGitLiteralDespiteConsistentObjectHash',remove_literal)
control('MissingActualFragmentMutation',lambda v:v['fragment']['runs'].pop())
control('WrongMutationFailureCount',lambda v:v['fragment']['runs'][1].__setitem__('expectedFailures',1))
control('WrongFragmentCommit',lambda v:v['fragment'].__setitem__('revision','0'*40))
control('DirtyFragmentSource',lambda v:v['fragment'].__setitem__('worktreeDirty',True))
control('OmittedFragmentInputDespiteConsistentRemainingTable',lambda v:v['fragment']['sources'].pop(next(iter(v['fragment']['sources']))))
invoke(valid());assert Path(q['binary']).read_bytes()==binary and path[0].read_bytes()==version
r={'sourceCommit':m,'sealScriptSha256':sha(p.read_bytes()),'method':'ASTextractactualbindingfunction, actualvalidbefore/after, onein-memoryevidencecorruptionpernegativecase. No bounddisk/sourceartifactmutation.','validBefore':True,'negativeControls':rows,'intendedAssertionRejections':len(rows),'restoredValidAfter':True,'diskArtifactsUnchanged':True,'scope':'Temporaryevidenceadmissioncontrols, not18productdefects orproof ofentireverificationpipeline.','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};(o/'seal-binding-controls.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'validBefore':True,'negativeControlsRejected':len(rows),'restoredValidAfter':True}),flush=True)
