"""Own isolated test-component mutation; restore sources even after failure."""
import datetime,hashlib,json,os,re,subprocess
from pathlib import Path
root=Path('/private/tmp/tdf-music-purchase-asset-admission-20261027')
source=root/'tdf-hq/src/TDF/Server/MusicReleaseCommerce.hs'
prefix=Path('/private/tmp/tdf-music-asset-native-control-20261027')
phase=Path(str(prefix)+'-phase.json')
qualified='c2cd0a2d8f42c15d03cb169190040ce37ac1beec'
env=dict(os.environ,STACK_ROOT='/Users/macpro/.stack',PGUSER='tdf_music_asset_probe',APP_ENV='sandbox',COMMERCE_CHECKOUT_ENV='sandbox',TDF_MUSIC_PURCHASE_DATABASE_URL='postgresql://127.0.0.1:55579/tdf_music_asset_probe_test')
binary=root/'tdf-hq/.stack-work/dist/x86_64-osx/ghc-9.10.3/build/tdf-hq-test/tdf-hq-test'
def state(value):phase.write_text(json.dumps({'phase':value,'root':str(root),'qualifiedSource':qualified,'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
def compile_target(variant):
 with Path(str(prefix)+'-'+variant+'-build.log').open('wb') as f:
  subprocess.run(['stack','test','tdf-hq:test:tdf-hq-test','--fast','--no-run-tests'],cwd=root/'tdf-hq',env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
def examples(variant,wanted):
 result=subprocess.run([str(binary),'--match=music-purchase-postgresql','--fail-on=empty','--seed=20261027'],cwd=root/'tdf-hq',env=env,capture_output=True)
 Path(str(prefix)+'-'+variant+'-tests.log').write_bytes(result.stdout+result.stderr)
 text=re.sub(r'\x1b\[[0-9;]*m','',(result.stdout+result.stderr).decode())
 counts=re.findall(r'^(\d+) examples, (\d+) failures(?:, (\d+) pending)?$',text,re.M)
 expectedExit=0 if wanted==0 else 1
 if not counts or tuple(int(x or 0) for x in counts[-1])!=(32,wanted,0) or result.returncode!=expectedExit:
  raise ValueError('Unexpected '+variant+' result '+str(counts)+' exit'+str(result.returncode))
 if wanted and (text.count('expected: 404')!=9 or text.count('but got: 201')!=9):
  raise ValueError('Failures do not reproduce the intended nine admission defects')
 return {'examples':32,'failures':wanted,'pending':0,'exit':result.returncode,'seed':20261027}
if git('rev-parse','HEAD').decode().strip()!=qualified or git('status','--porcelain').strip():raise ValueError('Own qualified checkout must be clean')
original=source.read_bytes();baseline=git('show','301810ae3861ea36b1fa790beee940bfe2461a02:tdf-hq/src/TDF/Server/MusicReleaseCommerce.hs')
result={'qualifiedSource':qualified,'originalSourceSha256':hashlib.sha256(original).hexdigest(),'baselineSourceRevision':'301810ae3861ea36b1fa790beee940bfe2461a02','baselineSourceSha256':hashlib.sha256(baseline).hexdigest(),'scope':'actual compiled MusicReleaseCommerce in the existing real handler/PostgreSQL test component; no provider HTTP; server executable not used by the control'}
state('clean-before-control')
try:
 source.write_bytes(baseline);state('baseline-installed-in-own-isolated-checkout')
 compile_target('baseline');state('baseline-test-component-compiled')
 result['baseline']=examples('baseline',9)
finally:
 source.write_bytes(original);state('source-restored-rebuild-required')
if git('status','--porcelain').strip():raise ValueError('Checkout not restored')
compile_target('fixed');result['fixed']=examples('fixed',0)
if source.read_bytes()!=original or git('status','--porcelain').strip():raise ValueError('Source drift after fixed rerun')
state('complete-clean-fixed')
Path(str(prefix)+'.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
