import importlib.util,json,re,subprocess,sys,hashlib
from pathlib import Path
root=Path(sys.argv[1]).resolve()
source=root/'tdf-hq/test/TDF/MusicPublicationSpec.hs'
text=source.read_text()
a=text.index('[ "CREATE OR REPLACE FUNCTION music_spec_publishable(')
b=text.index('    ]) []',a)
lines=[json.loads(m.group(0)) for m in re.finditer(r'"(?:[^"\\]|\\.)*"',text[a:b])]
function='\n'.join(lines)
old="encode(sha256((vid||'c')::bytea),'hex'),'ready',TRUE,actor,NOW()) RETURNING id INTO cover;"
new=old.replace("'ready'","'valid'")
if function.count(old)!=1:raise ValueError('Cover fixture shape changed')
function=function.replace(old,new)
old="INSERT INTO music_availability_rule(release_version_id,territories,listening_policy,download_policy,purchasable) VALUES (vid,ARRAY['Worldwide'],'full','none',FALSE);"
new="INSERT INTO music_availability_rule(release_version_id,territories,listening_policy,download_policy,purchasable,price_minor,currency,downloadable_asset_id) VALUES (vid,ARRAY['Worldwide'],'full','purchase',TRUE,250,'USD',cover);"
if function.count(old)!=1:raise ValueError('Offer fixture shape changed')
function=function.replace(old,new)
spec=importlib.util.spec_from_file_location('probe',root/'scripts/test-music-purchase-asset-query.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
fixed,_=p.offer_query()
base=subprocess.check_output(['git','show','301810ae3861ea36b1fa790beee940bfe2461a02:tdf-hq/src/TDF/Server/MusicReleaseCommerce.hs'],cwd=root,text=True)
oldquery=json.loads(next(x.strip() for x in base.splitlines() if 'SELECT public.release_version_id,rule.price_minor' in x))
for v in ['1',"'00000000-0000-0000-0000-000000000001'::uuid",'NULL','NULL','NULL']:oldquery=oldquery.replace('?',v,1)
queries=[q.replace('party.id=1',"party.id=(SELECT created_by FROM music_release_version WHERE id=(SELECT version_id FROM asset_probe_release))").replace("'00000000-0000-0000-0000-000000000001'::uuid","(SELECT id FROM music_availability_rule WHERE release_version_id=(SELECT version_id FROM asset_probe_release) AND purchasable)") for q in [oldquery,fixed]]
sql="BEGIN;\nINSERT INTO party(display_name,is_org,primary_email,created_at) VALUES('Music publication spec',false,'buyer@fixture.invalid',NOW());\n"+function+';\n'
sql+="CREATE TEMP TABLE asset_probe_release AS SELECT * FROM music_spec_publishable('purchase-asset-admission');\n"
sql+="SELECT 'submission_errors='||count(*) FROM music_check_submission((SELECT version_id FROM asset_probe_release));\n"
sql+="UPDATE music_release_version SET state='scheduled',scheduled_by=created_by,release_at_utc=clock_timestamp()+interval '50 milliseconds',release_timezone='UTC' WHERE id=(SELECT version_id FROM asset_probe_release);\nCOMMIT;\nSELECT pg_sleep(0.06);\nBEGIN;\nSELECT 'published='||count(*) FROM music_publish_due(100);\n"
sql+="SELECT 'public_rows='||count(*) FROM music_public_release WHERE release_version_id=(SELECT version_id FROM asset_probe_release);\n"
for name,q in zip(['baseline_offers','fixed_offers'],queries):sql+=f"SELECT '{name}='||count(*) FROM ({q}) offer;\n"
sql+='ROLLBACK;\n'
Path('/private/tmp/tdf-music-asset-publication-probe-20261027.sql').write_text(sql)
r=subprocess.run(['psql','postgresql://tdf_music_asset_probe@127.0.0.1:55579/tdf_music_asset_publication_test','-X','-qAt','-v','ON_ERROR_STOP=1'],input=sql,text=True,capture_output=True)
if r.returncode:raise RuntimeError(r.stderr)
values=[s for s in r.stdout.splitlines() if s]
expected=['submission_errors=0','published=1','public_rows=1','baseline_offers=1','fixed_offers=0']
if values!=expected:raise ValueError(values)
print(json.dumps({'schemaMigrations':227,'publicationTriggers':'enabled throughout; no replication-role change','fixtureSource':str(source.relative_to(root)),'fixtureSourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'fixtureChanges':['original cover processing state ready -> valid','Worldwide download sale points at that cover'],'observed':values,'transaction':'synthetic authoring fixture committed in dedicated disposable DB to advance transaction time; publication/read transaction rolled back','providerCalls':0,'scope':'actual database authoring validation, approval/scheduling/publication state triggers and extracted offer SQL; HTTP/session/provider execution not established'},indent=2))
