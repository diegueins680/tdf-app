BEGIN;
INSERT INTO party(display_name,is_org,primary_email,created_at) VALUES('Music publication spec',false,'buyer@fixture.invalid',NOW());
CREATE OR REPLACE FUNCTION music_spec_publishable(slug TEXT) RETURNS TABLE(release_id UUID, version_id UUID) LANGUAGE plpgsql AS $$
DECLARE actor BIGINT; rid UUID; vid UUID; rec UUID; mp UUID; mr UUID; cr UUID; master UUID; cover UUID;
BEGIN
  SELECT id INTO actor FROM party WHERE display_name='Music publication spec' ORDER BY id LIMIT 1;
  INSERT INTO music_release(artist_party_id,canonical_slug,release_kind,created_by) VALUES (actor,'music-spec-'||slug||'-'||gen_random_uuid(),'single',actor) RETURNING id INTO rid;
  INSERT INTO music_release_version(release_id,version_number,title,display_artist,explicit_content,recording_copyright_text,work_copyright_text,primary_genre_id,created_by)
    VALUES (rid,1,'Spec '||slug,'Spec Artist','not_explicit','℗ 2026 Spec','© 2026 Spec','ea0ee25a-326a-4174-9682-72d063caf6f9',actor) RETURNING id INTO vid;
  INSERT INTO music_recording(canonical_title,duration_ms,explicit_content,created_by) VALUES ('Spec '||slug,180000,'not_explicit',actor) RETURNING id INTO rec;
  INSERT INTO music_party(tdf_party_id,display_name,created_by) VALUES (actor,'Spec Artist',actor) ON CONFLICT DO NOTHING;
  SELECT id INTO mp FROM music_party WHERE tdf_party_id=actor;
  INSERT INTO music_release_track(release_version_id,recording_id,track_number,display_artist) VALUES (vid,rec,1,'Spec Artist');
  INSERT INTO music_credit(release_version_id,recording_id,music_party_id,credit_role) VALUES (vid,rec,mp,'main_artist'),(vid,rec,mp,'composer');
  INSERT INTO music_terms_acceptance(release_version_id,terms_kind,terms_version,accepted_by,evidence) VALUES (vid,'publication_authority','publication-v1',actor,'{"source":"music-publication-spec"}');
  INSERT INTO music_rights_declaration(release_version_id,recording_id,rights_scope,authority_basis,territories,starts_on,declared_by) VALUES (vid,rec,'master','owned',ARRAY['Worldwide'],'2026-09-11',actor) RETURNING id INTO mr;
  INSERT INTO music_rights_declaration(release_version_id,recording_id,rights_scope,authority_basis,territories,starts_on,declared_by) VALUES (vid,rec,'composition','licensed',ARRAY['Worldwide'],'2026-09-11',actor) RETURNING id INTO cr;
  INSERT INTO music_rights_split(declaration_id,rights_holder_id,basis_points,territories,starts_on) VALUES (mr,mp,10000,ARRAY['Worldwide'],'2026-09-11'),(cr,mp,10000,ARRAY['Worldwide'],'2026-09-11');
  INSERT INTO music_asset(release_version_id,recording_id,asset_role,storage_provider,storage_class,bucket_name,object_key,original_filename,media_type,byte_size,sha256,processing_state,immutable,created_by,ready_at)
    VALUES (vid,rec,'master_audio','local_private','standard','music-private','masters/'||vid||'/master.wav','master.wav','audio/wav',123456,encode(sha256((vid||'m')::bytea),'hex'),'ready',TRUE,actor,NOW()) RETURNING id INTO master;
  INSERT INTO music_asset(release_version_id,recording_id,parent_asset_id,asset_role,storage_provider,storage_class,bucket_name,object_key,media_type,byte_size,sha256,processing_state,immutable,created_by,ready_at)
    VALUES (vid,rec,master,'stream_audio','local_private','standard','music-private','derivatives/'||vid||'/stream.m4a','audio/mp4',65432,encode(sha256((vid||'s')::bytea),'hex'),'ready',TRUE,actor,NOW());
  INSERT INTO music_asset(release_version_id,asset_role,storage_provider,storage_class,bucket_name,object_key,original_filename,media_type,byte_size,sha256,processing_state,immutable,created_by,ready_at)
    VALUES (vid,'cover_original','local_private','standard','music-private','art/'||vid||'/cover.png','cover.png','image/png',23456,encode(sha256((vid||'c')::bytea),'hex'),'valid',TRUE,actor,NOW()) RETURNING id INTO cover;
  INSERT INTO music_asset(release_version_id,parent_asset_id,asset_role,storage_provider,storage_class,bucket_name,object_key,media_type,byte_size,sha256,processing_state,immutable,created_by,ready_at)
    VALUES (vid,cover,'cover_display','local_private','standard','music-private','art/'||vid||'/cover.webp','image/webp',12345,encode(sha256((vid||'d')::bytea),'hex'),'ready',TRUE,actor,NOW());
  INSERT INTO music_availability_rule(release_version_id,territories,listening_policy,download_policy,purchasable,price_minor,currency,downloadable_asset_id) VALUES (vid,ARRAY['Worldwide'],'full','purchase',TRUE,250,'USD',cover);
  INSERT INTO music_release_version_party(release_version_id,music_party_id,party_details,details_source)
    VALUES (vid,mp,jsonb_build_object('displayName','Spec Artist','partyKind','person','identifiers','[]'::jsonb),'user_provided');
  PERFORM music_refresh_validation_flags(vid);
  UPDATE music_release_version SET immutable_snapshot=jsonb_build_object('version',vid), snapshot_sha256=encode(sha256(vid::text::bytea),'hex') WHERE id=vid;
  UPDATE music_release_version SET state='ready_for_review' WHERE id=vid;
  UPDATE music_release_version SET state='in_review' WHERE id=vid;
  UPDATE music_release_version SET state='approved',approved_by=actor,approved_at=NOW() WHERE id=vid;
  RETURN QUERY SELECT rid, vid;
END $$;;
CREATE TEMP TABLE asset_probe_release AS SELECT * FROM music_spec_publishable('purchase-asset-admission');
SELECT 'submission_errors='||count(*) FROM music_check_submission((SELECT version_id FROM asset_probe_release));
UPDATE music_release_version SET state='scheduled',scheduled_by=created_by,release_at_utc=clock_timestamp()+interval '50 milliseconds',release_timezone='UTC' WHERE id=(SELECT version_id FROM asset_probe_release);
COMMIT;
SELECT pg_sleep(0.06);
BEGIN;
SELECT 'published='||count(*) FROM music_publish_due(100);
SELECT 'public_rows='||count(*) FROM music_public_release WHERE release_version_id=(SELECT version_id FROM asset_probe_release);
SELECT 'baseline_offers='||count(*) FROM (SELECT public.release_version_id,rule.price_minor,rule.currency,rule.downloadable_asset_id,public.title,party.display_name,party.primary_email FROM music_availability_rule rule JOIN music_public_release public ON public.release_version_id=rule.release_version_id JOIN party ON party.id=(SELECT created_by FROM music_release_version WHERE id=(SELECT version_id FROM asset_probe_release)) WHERE rule.id=(SELECT id FROM music_availability_rule WHERE release_version_id=(SELECT version_id FROM asset_probe_release) AND purchasable)::uuid AND rule.purchasable=TRUE AND rule.download_policy='purchase' AND rule.price_minor>0 AND rule.currency='USD' AND rule.downloadable_asset_id IS NOT NULL AND (rule.starts_at IS NULL OR rule.starts_at<=NOW()) AND (rule.ends_at IS NULL OR rule.ends_at>NOW()) AND ((rule.territory_mode='include' AND ('Worldwide'=ANY(rule.territories) OR NULL::text=ANY(rule.territories))) OR (rule.territory_mode='exclude' AND NULL::text IS NOT NULL AND NOT (NULL::text=ANY(rule.territories))))) offer;
SELECT 'fixed_offers='||count(*) FROM (SELECT public.release_version_id,rule.price_minor,rule.currency,rule.downloadable_asset_id,public.title,party.display_name,party.primary_email FROM music_availability_rule rule JOIN music_public_release public ON public.release_version_id=rule.release_version_id JOIN music_asset asset ON asset.id=rule.downloadable_asset_id AND asset.release_version_id=public.release_version_id JOIN party ON party.id=(SELECT created_by FROM music_release_version WHERE id=(SELECT version_id FROM asset_probe_release)) WHERE rule.id=(SELECT id FROM music_availability_rule WHERE release_version_id=(SELECT version_id FROM asset_probe_release) AND purchasable)::uuid AND rule.purchasable=TRUE AND rule.download_policy='purchase' AND rule.price_minor>0 AND rule.currency='USD' AND rule.downloadable_asset_id IS NOT NULL AND (asset.processing_state='ready' OR (asset.processing_state='valid' AND asset.asset_role='master_audio' AND asset.immutable=TRUE AND asset.storage_class<>'quarantine')) AND (rule.starts_at IS NULL OR rule.starts_at<=NOW()) AND (rule.ends_at IS NULL OR rule.ends_at>NOW()) AND ((rule.territory_mode='include' AND ('Worldwide'=ANY(rule.territories) OR NULL::text=ANY(rule.territories))) OR (rule.territory_mode='exclude' AND NULL::text IS NOT NULL AND NOT (NULL::text=ANY(rule.territories))))) offer;
ROLLBACK;
