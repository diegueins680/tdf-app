from pathlib import Path
import subprocess, os, json, datetime, hashlib
root = Path('/private/tmp/tdf-ledger-event-identity-20261025')
out = Path('/private/tmp/tdf-ledger-header-main-qualified-results-20261026')
out.mkdir(mode=448)
env = {k: v for k, v in os.environ.items() if k in ['HOME', 'PATH', 'USER', 'LOGNAME', 'SHELL', 'LANG', 'LC_CTYPE', 'TZ', 'TMPDIR']}
env['PATH'] = '/usr/local/opt/postgresql@16/bin:/private/tmp/tdf-release-verification-venv/bin:' + env['PATH']
env['STACK_ROOT'] = '/Users/macpro/.stack'
env['PGPASSFILE'] = str(out / 'no-pgpass')
env['CI'] = 'false'
port = '56935'
db = 'tdf_ledger_header_main_qualified_20261026_test'
url = 'postgresql://macpro@127.0.0.1:' + port + '/' + db
for k in ['TDF_MUSIC_REHEARSAL_DATABASE_URL', 'TDF_LEDGER_POSTING_DATABASE_URL', 'TDF_IDENTITY_HTTP_DATABASE_URL']:
    env[k] = url
cluster = out / 'cluster'
sock = out / 'socket'
sock.mkdir(mode=448)
report = {'sourceAtStart': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'workingDiffSha256': hashlib.sha256(subprocess.check_output(['git', 'diff', 'HEAD'], cwd=root)).hexdigest(), 'manifestEntries': 222, 'productionOperations': False, 'steps': [], 'cleanup': {}}
report['sourceSha256'] = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in [root / 'scripts/production-migrations.json', root / 'scripts/__tests__/ledger-startup-namespace.mjs', root / 'formal/event-operations/LedgerHeader.tla', root / 'formal/event-operations/LedgerHeader.cfg', root / 'formal/event-operations/LedgerHeaderMutable.cfg', root / 'scripts/lib/production-release.mjs', root / 'scripts/__tests__/ledger-event-identity.mjs', root / 'tdf-hq/sql/2026-10-25_ledger_posted_header.sql', root / 'scripts/test-ledger-posting.sh', root / 'scripts/__tests__/ledger-posting-namespace.py', root / 'scripts/__tests__/ledger-posting-upgrade.py', root / 'scripts/__tests__/ledger-posting-snapshot.py', *[root / e['path'] for e in json.loads((root / 'scripts/production-migrations.json').read_text())['migrations']]]}
report['driverSha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
report['versions'] = {'python': subprocess.check_output(['python3', '--version'], env=env, text=True).strip(), 'node': subprocess.check_output(['node', '--version'], env=env, text=True).strip(), 'psql': subprocess.check_output(['psql', '--version'], env=env, text=True).strip()}

def save():
    (out / 'results.json').write_text(json.dumps(report, indent=2) + '\n')

def run(label, args, input=None, expected=None, cwd=None):
    r = subprocess.run(args, input=input, cwd=cwd or root, env=env, text=True, capture_output=True, timeout=600)
    (out / (label + '.log')).write_text(r.stdout + r.stderr)
    report['steps'].append({'name': label, 'exitCode': r.returncode, 'expectedFailure': expected})
    save()
    if not (r.returncode != 0 and expected in r.stderr if expected else r.returncode == 0):
        raise AssertionError((label, r.stderr[-2500:]))
    print(label, 'EXPECTED REJECTION' if expected else 'PASS', flush=True)
    return r.stdout.strip()
psql = ['psql', '-XqAt', '-v', 'ON_ERROR_STOP=1', '-d', url]
if not not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True).strip():
    raise AssertionError('Qualification requires a clean committed source')
started = created = False
try:
    if not subprocess.run(['lsof', '-tiTCP:' + port, '-sTCP:LISTEN'], capture_output=True).returncode != 0:
        raise AssertionError('Verification obligation failed')
    run('init', ['initdb', '-D', str(cluster), '--username=macpro', '--encoding=UTF8', '--locale=C', '--auth=trust'])
    run('start', ['pg_ctl', '-D', str(cluster), '-l', str(out / 'postgres.log'), '-o', '-p ' + port + ' -h 127.0.0.1 -k ' + str(sock), 'start'])
    started = True
    run('create', ['createdb', '-h', '127.0.0.1', '-p', port, '-U', 'macpro', '--template=template0', db])
    created = True
    run('full222-apply-replay', ['node', 'scripts/test-music-integration-rehearsal.mjs'])
    if not run('manifest-cardinality', psql, input='SELECT count(*) FROM public.tdf_schema_migration;') == '222':
        raise AssertionError('Verification obligation failed')
    binary = root / 'tdf-hq/.stack-work/dist/x86_64-osx/ghc-9.10.3/build/tdf-hq-test/tdf-hq-test'
    report['runtimeArtifact'] = {'compiledSource': report['sourceAtStart'], 'freshCanonicalStackBuild': True, 'sha256': hashlib.sha256(binary.read_bytes()).hexdigest()}
    save()
    run('canonical-ledger-runner', ['sh', 'scripts/test-ledger-posting.sh'])
    run('optimized-namespace-controls', ['python3', '-O', 'scripts/__tests__/ledger-posting-namespace.py', '--negative-controls'])
    report['counterexample'] = 'Separately reproduced on protected main e938c72ba4b87010214f6838f06bfac45a0f45c0 with all 221 migrations: an ordinary non-owner with SELECT/UPDATE on ledger headers and no entry UPDATE/public CREATE changes the event key of a real posted balanced transaction'
    save()
finally:
    try:
        if created:
            run('drop', ['dropdb', '-h', '127.0.0.1', '-p', port, '-U', 'macpro', db])
            report['cleanup']['ownedDatabaseRemoved'] = True
    finally:
        if started:
            run('stop', ['pg_ctl', '-D', str(cluster), '-m', 'fast', '-w', 'stop'])
            report['cleanup']['ownedClusterStopped'] = True
        report['sourceHashesUnchanged'] = all((hashlib.sha256((root / p).read_bytes()).hexdigest() == h for p, h in report['sourceSha256'].items()))
        report['sourceStillClean'] = not bool(subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True).strip())
        report['sourceRevisionUnchanged'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == report['sourceAtStart']
        report['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save()

if not all(report[k] for k in ["sourceHashesUnchanged", "sourceStillClean", "sourceRevisionUnchanged"]):
    raise RuntimeError("Qualification sources changed; all results are stale")
