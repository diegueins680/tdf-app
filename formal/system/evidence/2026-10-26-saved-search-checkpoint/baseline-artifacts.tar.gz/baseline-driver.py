from pathlib import Path
import datetime, hashlib, json, os, socket, subprocess
root=Path('/private/tmp/tdf-ledger-event-identity-20261025');out=Path('/private/tmp/tdf-saved-search-prefix-baseline-20261026');out.mkdir(mode=0o700)
env={k:v for k,v in os.environ.items() if k in ['HOME','PATH','USER','LOGNAME','SHELL','LANG','LC_CTYPE','TZ','TMPDIR']};env['PATH']='/usr/local/opt/postgresql@16/bin:/private/tmp/tdf-release-verification-venv/bin:'+env['PATH'];env['PGPASSFILE']=str(out/'no-pgpass');env['CI']='false'
port='56955';db='tdf_directory_alert_parity_test';url='postgresql://macpro@127.0.0.1:'+port+'/'+db;env['TDF_DIRECTORY_ALERT_PARITY_DATABASE_URL']=url
cluster=out/'cluster';sock=out/'socket';sock.mkdir(mode=0o700)
if subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip():raise RuntimeError('Clean baseline source required')
files=['scripts/test-directory-saved-search-parity.mjs','scripts/lib/production-release.mjs','scripts/production-migrations.json']
report={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sourceSha256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files},'steps':[],'cleanup':{},'productionOperations':False,'versions':{k:subprocess.check_output(v,env=env,text=True).strip() for k,v in {'python':['python3','--version'],'node':['node','--version'],'psql':['psql','--version']}.items()}}
def save():(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name,args,negative=False):
 r=subprocess.run(args,cwd=root,env=env,text=True,capture_output=True,timeout=600);(out/(name+'.log')).write_text(r.stdout+r.stderr);report['steps'].append({'name':name,'exitCode':r.returncode,'expectedFailure':negative});save()
 if (r.returncode==0)==negative:raise RuntimeError((name,r.returncode,(r.stdout+r.stderr)[-2000:]))
 print(name+' '+('EXPECTED REJECTION' if negative else 'PASS'),flush=True);return r
started=created=False
try:
 with socket.socket() as probe:probe.bind(('127.0.0.1',int(port)))
 run('init',['initdb','-D',str(cluster),'--username=macpro','--encoding=UTF8','--locale=C','--auth=trust'])
 run('start',['pg_ctl','-D',str(cluster),'-l',str(out/'postgres.log'),'-o','-p '+port+' -h127.0.0.1 -k '+str(sock),'start']);started=True
 run('create',['createdb','-h','127.0.0.1','-p',port,'-U','macpro',db]);created=True
 run('original-saved-search-runner',['node','scripts/test-directory-saved-search-parity.mjs'],negative=True)
 marker='Posted ledger header immutability guard is missing or changed'
 if marker not in (out/'postgres.log').read_text():raise RuntimeError('Named startup rejection not witnessed')
 rows=run('prefix-witness',['psql','-XqAt','-v','ON_ERROR_STOP=1','-d',url,'-c',"SELECT count(*),bool_or(migration_id='2026-10-25_directory_saved_search_parity'),bool_or(migration_id='2026-10-25_ledger_posted_header') FROM public.tdf_schema_migration"]).stdout.strip()
 if rows!='220|f|f':raise RuntimeError(rows)
 report['counterexample']={'rejection':marker,'prefixState':rows,'classification':'Historical setup incorrectly invokes current full-schema readiness before later mandatory migrations. Production rejection is correct; harness model is wrong.'};save()
finally:
 try:
  if created:run('drop',['dropdb','-h','127.0.0.1','-p',port,'-U','macpro',db]);report['cleanup']['ownedDatabaseRemoved']=True
 finally:
  if started:run('stop',['pg_ctl','-D',str(cluster),'-m','fast','-w','stop']);report['cleanup']['ownedClusterStopped']=True
  report['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
