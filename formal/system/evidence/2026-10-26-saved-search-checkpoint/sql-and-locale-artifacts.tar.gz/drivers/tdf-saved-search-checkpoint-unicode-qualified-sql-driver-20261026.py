from pathlib import Path
import datetime, hashlib, json, os, re, socket, subprocess
root=Path('/private/tmp/tdf-ledger-event-identity-20261025');out=Path('/private/tmp/tdf-saved-search-checkpoint-unicode-qualified-sql-20261026');out.mkdir(mode=0o700)
env={k:v for k,v in os.environ.items() if k in ['HOME','PATH','USER','LOGNAME','SHELL','LANG','LC_CTYPE','TZ','TMPDIR']};env['PATH']='/usr/local/opt/postgresql@16/bin:/private/tmp/tdf-release-verification-venv/bin:'+env['PATH'];env['PGPASSFILE']=str(out/'no-pgpass');env['CI']='false'
port='56960';db='tdf_directory_alert_parity_test';url='postgresql://macpro@127.0.0.1:'+port+'/'+db;env['TDF_DIRECTORY_ALERT_PARITY_DATABASE_URL']=url
cluster=out/'cluster';sock=out/'socket';sock.mkdir(mode=0o700)
if subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip():raise RuntimeError('Clean baseline source required')
files=['scripts/test-directory-saved-search-parity.mjs','scripts/lib/production-release.mjs','scripts/production-migrations.json','scripts/__tests__/directory-saved-search-http.mjs','scripts/__tests__/directory-search-plan-parity.mjs','scripts/test-community-search.py','tdf-hq/src/TDF/Server/Directory.hs']+[x['path'] for x in json.loads((root/'scripts/production-migrations.json').read_text())['migrations']]
report={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sourceSha256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files},'steps':[],'cleanup':{},'productionOperations':False,'versions':{k:subprocess.check_output(v,env=env,text=True).strip() for k,v in {'python':['python3','--version'],'node':['node','--version'],'psql':['psql','--version']}.items()}}
def save():(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name,args,negative=False):
 r=subprocess.run(args,cwd=root,env=env,text=True,capture_output=True,timeout=600);(out/(name+'.log')).write_text(r.stdout+r.stderr);report['steps'].append({'name':name,'exitCode':r.returncode,'expectedFailure':negative});save()
 if (r.returncode==0)==negative:raise RuntimeError((name,r.returncode,(r.stdout+r.stderr)[-2000:]))
 print(name+' '+('EXPECTED REJECTION' if negative else 'PASS'),flush=True);return r
started=created=False
try:
 with socket.socket() as probe:probe.bind(('127.0.0.1',int(port)))
 run('init',['initdb','-D',str(cluster),'--username=macpro','--encoding=UTF8','--locale=en_US.UTF-8','--auth=trust'])
 run('start',['pg_ctl','-D',str(cluster),'-l',str(out/'postgres.log'),'-o','-p '+port+' -h127.0.0.1 -k '+str(sock),'start']);started=True
 run('create',['createdb','-h','127.0.0.1','-p',port,'-U','macpro',db]);created=True
 report['databaseLocale']=run('database-locale',['psql','-XqAt','-d',url,'-c',"SELECT datctype,datcollate,pg_encoding_to_char(encoding),version() FROM pg_database WHERE datname=current_database();"]).stdout.strip();save()
 binary=root/'tdf-hq/.stack-work/dist/x86_64-osx/ghc-9.10.3/build/tdf-hq-exe/tdf-hq-exe'
 report['scope']='SQL/plan/rollback only; HTTP awaits fresh compiled executable';report['driverSha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();save()
 result=run('complete-saved-search-rehearsal',['node','scripts/test-directory-saved-search-parity.mjs'])
 log=result.stdout+result.stderr
 markers=['PASS: full prefix, forward/replay, shared predicate regressions, exact rollback/reapply, saved JSON/hash preservation','PASS: IDs/scores/order/facets, scalar-helper inlining, observed indexed paths and once-per-query alias evaluation']
 for marker in markers:
  if marker not in log:raise RuntimeError('Missing completion marker '+marker)
 state=run('checkpoint-and-complete-counts',['psql','-XqAt','-v','ON_ERROR_STOP=1','-d',url,'-c',"SELECT (SELECT count(*) FROM public.tdf_schema_migration),(SELECT jsonb_array_length(prefix_ids) FROM directory_alert_qualification.before_target),(SELECT tgenabled FROM pg_trigger WHERE tgname='trg_commerce_ledger_header_immutable');"]).stdout.strip()
 if state!='222|220|O':raise RuntimeError(state)
 report['historicalAndCurrentWitness']=state;save()
 verifier=run('render-current-verifier',['node','--input-type=module','-e',"import{buildSchemaVerificationSql}from './scripts/lib/production-release.mjs';process.stdout.write(buildSchemaVerificationSql({includePsqlHeader:false}));"]).stdout
 control='BEGIN; ALTER TABLE public.commerce_ledger_transaction DISABLE TRIGGER trg_commerce_ledger_header_immutable;\n'+verifier+'\nROLLBACK;'
 r=subprocess.run(['psql','-XqAt','-v','ON_ERROR_STOP=1','-d',url],input=control,cwd=root,env=env,text=True,capture_output=True,timeout=60)
 (out/'disabled-header-control.log').write_text(r.stdout+r.stderr)
 report['steps'].append({'name':'disabled-header-control','exitCode':r.returncode,'expectedFailure':True});save()
 if r.returncode==0 or not re.search(r'(?m)^ERROR:\s+Posted ledger header immutability guard is missing or changed\s*$',r.stderr):raise RuntimeError('Mandatory guard control failed')
 r=subprocess.run(['psql','-XqAt','-v','ON_ERROR_STOP=1','-d',url],input=verifier,cwd=root,env=env,text=True,capture_output=True,timeout=60)
 (out/'restored-current-verifier.log').write_text(r.stdout+r.stderr)
 if r.returncode:raise RuntimeError(('Guard did not restore',r.stderr[-2000:]))
 report['steps'].append({'name':'restored-current-verifier','exitCode':r.returncode,'expectedFailure':False});report['mandatoryGuardControl']='Named rejection with trigger disabled, transaction rollback, then current verifier succeeds';save()

finally:
 try:
  if created:run('drop',['dropdb','-h','127.0.0.1','-p',port,'-U','macpro',db]);report['cleanup']['ownedDatabaseRemoved']=True
 finally:
  if started:run('stop',['pg_ctl','-D',str(cluster),'-m','fast','-w','stop']);report['cleanup']['ownedClusterStopped']=True
  report['sourceHashesUnchanged']=all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in report['sourceSha256'].items());report['sourceStillClean']=not bool(subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip());report['sourceRevisionUnchanged']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==report['source'];report['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()

if not all(report[k] for k in ['sourceHashesUnchanged','sourceStillClean','sourceRevisionUnchanged']):raise RuntimeError('Qualification sources changed')
