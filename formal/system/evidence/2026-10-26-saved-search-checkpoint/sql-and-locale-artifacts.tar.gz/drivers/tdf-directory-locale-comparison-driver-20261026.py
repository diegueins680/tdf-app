from pathlib import Path
import datetime, hashlib, json, os, socket, subprocess
root=Path('/private/tmp/tdf-ledger-event-identity-20261025');out=Path('/private/tmp/tdf-directory-locale-comparison-20261026');out.mkdir(mode=0o700)
env={k:v for k,v in os.environ.items() if k in ['HOME','PATH','USER','LOGNAME','SHELL','LANG','LC_CTYPE','TZ','TMPDIR']};env['PATH']='/usr/local/opt/postgresql@16/bin:/private/tmp/tdf-release-verification-venv/bin:'+env['PATH'];env['PGPASSFILE']=str(out/'no-pgpass');env['CI']='false'
port='56961';db='tdf_directory_alert_parity_test';url='postgresql://macpro@127.0.0.1:'+port+'/'+db;env['TDF_DIRECTORY_ALERT_PARITY_DATABASE_URL']=url
cluster=out/'cluster';sock=out/'socket';sock.mkdir(mode=0o700)
if subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip():raise RuntimeError('Clean baseline source required')
files=['scripts/test-directory-saved-search-parity.mjs','scripts/lib/production-release.mjs','scripts/production-migrations.json']
report={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sourceSha256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files},'steps':[],'cleanup':{},'productionOperations':False,'versions':{k:subprocess.check_output(v,env=env,text=True).strip() for k,v in {'python':['python3','--version'],'node':['node','--version'],'psql':['psql','--version']}.items()}}
def save():(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name,args,negative=False):
 r=subprocess.run(args,cwd=root,env=env,text=True,capture_output=True,timeout=600);(out/(name+'.log')).write_text(r.stdout+r.stderr);report['steps'].append({'name':name,'exitCode':r.returncode,'expectedFailure':negative});save()
 if (r.returncode==0)==negative:raise RuntimeError((name,r.returncode,(r.stdout+r.stderr)[-2000:]))
 print(name+' '+('EXPECTED REJECTION' if negative else 'PASS'),flush=True);return r
started=created=False
try:
 with socket.socket() as probe:probe.bind(('127.0.0.1',int(port)))
 run('init',['initdb','-D',str(cluster),'--username=macpro','--encoding=UTF8','--locale=en_US.UTF-8','--auth=trust'])
 run('start',['pg_ctl','-D',str(cluster),'-l',str(out/'postgres.log'),'-o','-p '+port+' -h127.0.0.1 -k '+str(sock),'start']);started=True
 run('create',['createdb','-h','127.0.0.1','-p',port,'-U','macpro',db]);created=True
 source=root/'tdf-hq/sql/2026-08-14_music_directory_core.sql'
 text=source.read_text();start=text.index('CREATE OR REPLACE FUNCTION directory_normalize_text(');end=text.index('$$;',start)+3;function=text[start:end]
 report['functionSourceSha256']=hashlib.sha256(function.encode()).hexdigest();report['sourceFileSha256']=hashlib.sha256(source.read_bytes()).hexdigest();report['cases']=[];save()
 for locale in ['C','en_US.UTF-8']:
  name='tdf_directory_c_locale_test' if locale=='C' else 'tdf_directory_unicode_locale_test'
  run('create-'+locale.replace('/','_'),['createdb','-h','127.0.0.1','-p',port,'-U','macpro','--template=template0','--locale='+locale,name])
  try:
   target='postgresql://macpro@127.0.0.1:'+port+'/'+name
   query=function+"\nSELECT json_build_object('lower',directory_normalize_text('luna'),'upper',directory_normalize_text('LÚNA'),'locale',datctype,'encoding',pg_encoding_to_char(encoding),'server',version()) FROM pg_database WHERE datname=current_database();"
   r=subprocess.run(['psql','-XqAt','-v','ON_ERROR_STOP=1','-d',target],input=query,cwd=root,env=env,text=True,capture_output=True,timeout=30)
   (out/('normalize-'+locale+'.log')).write_text(r.stdout+r.stderr)
   if r.returncode:raise RuntimeError(r.stderr)
   report['cases'].append(json.loads(r.stdout.strip()));save()
  finally:run('drop-'+locale,['dropdb','-h','127.0.0.1','-p',port,'-U','macpro',name])
 c,u=report['cases']
 if c['lower']!='luna' or c['upper']==c['lower'] or u['lower']!='luna' or u['upper']!='luna':raise RuntimeError(('Locale hypothesis not established',report['cases']))
 report['finding']={'status':'FAILED in POSIX C, TESTED equality in en_US.UTF-8','property':'Existing case/accent normalization expects uppercase and lowercase forms to agree.','classification':'Independent directory normalization portability counterexample; supported locale policy remains an explicit open requirement, not an invented business exception.','financialGuardRelation':'Unrelated to immutable headers; does not justify relaxing any existing query assertion.'};save();print(json.dumps(report['cases']),flush=True)

finally:
 try:
  if created:run('drop',['dropdb','-h','127.0.0.1','-p',port,'-U','macpro',db]);report['cleanup']['ownedDatabaseRemoved']=True
 finally:
  if started:run('stop',['pg_ctl','-D',str(cluster),'-m','fast','-w','stop']);report['cleanup']['ownedClusterStopped']=True
  report['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
