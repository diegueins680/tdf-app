from pathlib import Path
import unittest
__file__='/private/tmp/tdf-provider-domain-current-main-20261026/scripts/test-provider-domain-harness.py'

class ProviderRunnerGateControls(unittest.TestCase):
    """Execute the real shell runner with inert tools, checking fail-closed wiring."""

    def run_runner(self, expiry_exit):
        import os
        import subprocess
        import sys
        import tempfile

        with tempfile.TemporaryDirectory(prefix='tdf-provider-gate-') as directory:
            root = Path(directory)
            scripts = root / 'scripts'
            scripts.mkdir()
            (root / 'tdf-hq').mkdir()
            tools = root / 'bin'
            tools.mkdir()
            for name in ('test-provider-retry-runtime.sh', 'load-payment-test-schema.sh'):
                (scripts / name).write_bytes(Path(__file__).with_name(name).read_bytes())
            # Every database, Node, Python and Stack command is inert. No fixture
            # database or Docker daemon is contacted by this orchestration test.
            stub = '''#!PYTHON
import os, pathlib, sys
name = pathlib.Path(sys.argv[0]).name
args = sys.argv[1:]
trace = pathlib.Path(os.environ['GATE_TRACE'])
if name == 'python3' and args[0].endswith('/verify-payment-intent-expiry.py'):
    with trace.open('a') as output: output.write('expiry\\n')
    sys.exit(int(os.environ['GATE_EXPIRY_EXIT']))
if name == 'stack':
    with trace.open('a') as output: output.write('stack\\n')
if name == 'node' and args and args[0] == '-p': print('223')
if name == 'psql':
    if '-c' in args:
        query = args[args.index('-c') + 1]
        if 'current_database()' in query: print('tdf_provider_retry_test')
        elif 'tdf_schema_migration' in query: print('223')
        elif 'revenue_feature_flag' in query: print('1')
        elif 'pg_class' in query: print('0')
        else: print('1')
    if '-f' in args and args[args.index('-f') + 1].endswith('provider_query_recovery_rollback.sql'):
        if trace.exists() and 'stack' in trace.read_text(): sys.exit(1)
'''.replace('PYTHON', sys.executable, 1)
            for name in ('node', 'psql', 'python3', 'stack'):
                target = tools / name
                target.write_text(stub)
                target.chmod(0o700)
            trace = root / 'trace'
            environment = {
                'PATH': str(tools) + os.pathsep + os.environ['PATH'],
                'TDF_PROVIDER_RETRY_DATABASE_URL': 'postgresql://localhost/tdf_provider_retry_test',
                'GATE_TRACE': str(trace),
                'GATE_EXPIRY_EXIT': str(expiry_exit),
            }
            result = subprocess.run(['sh', str(scripts / 'test-provider-retry-runtime.sh')],
                                    env=environment, text=True, capture_output=True)
            return result, trace.read_text().splitlines() if trace.exists() else []

    def test_intent_expiry_verification_precedes_compiled_provider_suite(self):
        result, trace = self.run_runner(0)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(trace, ['expiry', 'stack'])

    def test_intent_expiry_verification_failure_blocks_compiled_suite(self):
        result, trace = self.run_runner(37)
        self.assertEqual(result.returncode, 37, result.stderr)
        self.assertEqual(trace, ['expiry'])

unittest.main()
