from pathlib import Path
import datetime, hashlib, json, os, re, socket, subprocess, time
root = Path('/private/tmp/tdf-provider-domain-current-main-20261026')
out = Path('/private/tmp/tdf-provider-expiry-restored-native-results-20261026')
out.mkdir(mode=0o700)
env = {k:v for k,v in os.environ.items() if k in ['HOME','PATH','USER','LOGNAME','SHELL','LANG','LC_CTYPE','TZ','TMPDIR']}
env['PATH']='/usr/local/opt/postgresql@16/bin:/private/tmp/tdf-provider-verification-venv-20261026/bin:'+env['PATH']
env['STACK_ROOT']='/Users/macpro/.stack'
env['PGPASSFILE']=str(out/'no-pgpass')
env['CI']='false'
port='56971'; db='tdf_provider_retry_test'
url='postgresql://macpro@127.0.0.1:'+port+'/'+db
env['TDF_PROVIDER_RETRY_DATABASE_URL']=url
cluster=out/'cluster'; sock=out/'socket'; sock.mkdir(mode=0o700)
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
if revision!='98f3ed230d2bcc87971d9e7c9b2083bd1cb9700d': raise RuntimeError('Unexpected qualification revision')
build=json.loads(Path('/private/tmp/tdf-provider-expiry-restored-build-receipt-20261026.json').read_text())
if build['source']!=revision or build['exitCode']!=0 or not build['sourceRevisionUnchanged']: raise RuntimeError('Missing exact-source successful build')
if subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip(): raise RuntimeError('Qualification requires clean committed source')
manifest=json.loads((root/'scripts/production-migrations.json').read_text())['migrations']
files=['scripts/production-migrations.json','scripts/load-payment-test-schema.sh','scripts/test-provider-retry-runtime.sh','scripts/test-provider-domain-binding.py','scripts/test-provider-domain-harness.py','scripts/__tests__/fixtures/provider-domain-fixtures.sql','tdf-hq/test/TDF/Commerce/ProviderRetrySpec.hs','tdf-hq/tdf-hq.cabal','tdf-hq/stack.yaml','tdf-hq/stack.yaml.lock']
files += [x['path'] for x in manifest]
report={'source':revision,'startedClean':True,'manifestEntries':len(manifest),'productionOperations':False,'sourceSha256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files},'driverSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'steps':[],'cleanup':{}}
def save(): (out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name,args,cwd=None):
    started=time.monotonic()
    result=subprocess.run(args,cwd=cwd or root,env=env,capture_output=True,text=True,timeout=2400)
    log=result.stdout+result.stderr; (out/(name+'.log')).write_text(log)
    report['steps'].append({'name':name,'command':args,'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-started,'logSha256':hashlib.sha256(log.encode()).hexdigest()});save()
    if result.returncode!=0: raise RuntimeError((name,result.returncode,log[-3500:]))
    print(name+' PASS',flush=True)
    return log
started=created=False
try:
    with socket.socket() as probe: probe.bind(('127.0.0.1',int(port)))
    report['versions']={name:subprocess.check_output(cmd,env=env,text=True).strip() for name,cmd in {'python':['python3','--version'],'node':['node','--version'],'psql':['psql','--version'],'stack':['stack','--numeric-version'],'psycopg2':['python3','-c','import psycopg2;print(psycopg2.__version__)']}.items()};save()
    run('init',['initdb','-D',str(cluster),'--username=macpro','--encoding=UTF8','--locale=C','--auth=trust'])
    run('start',['pg_ctl','-D',str(cluster),'-l',str(out/'postgres.log'),'-o','-p '+port+' -h 127.0.0.1 -k '+str(sock),'start']);started=True
    run('create',['createdb','-h','127.0.0.1','-p',port,'-U','macpro','--template=template0',db]);created=True
    binary=root/'tdf-hq/.stack-work/dist/x86_64-osx/ghc-9.10.3/build/tdf-hq-test/tdf-hq-test'
    report['buildReceipt']=build
    report['discoveryBinarySha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
    discovery=run('compiled-provider-discovery',[str(binary),'--dry-run','--match=provider-retry-runtime','--fail-on=empty'])
    discovered=re.findall(r'(\d+) examples, (\d+) failures',discovery)
    if not discovered or int(discovered[-1][0])<317 or discovered[-1][1]!='0': raise RuntimeError('Incomplete compiled provider discovery')
    if 'rejects an unpaid runtime order before attempting provider selection' not in discovery: raise RuntimeError('New refund boundary test was not discovered')
    report['discoveredProviderExamples']=int(discovered[-1][0]);save()
    try:
        log=run('canonical-provider-runner',['sh','scripts/test-provider-retry-runtime.sh'])
    finally:
        report['executedBinarySha256']=hashlib.sha256(binary.read_bytes()).hexdigest();save()
    executed=re.findall(r'(\d+) examples, (\d+) failures(?:, (\d+) pending)?',log)
    if not executed or int(executed[-1][0])!=report['discoveredProviderExamples'] or executed[-1][1]!='0' or int(executed[-1][2] or '0')!=0: raise RuntimeError(('Incomplete runtime execution',executed))
    report['executedProviderExamples']=int(executed[-1][0]);save()
    marker = '{\n  "schemaVersion": 1,\n  "claim": "Fresh intent expiry'
    start = log.find(marker)
    if start < 0: raise RuntimeError('Restored expiry verifier report missing')
    expiry, _ = json.JSONDecoder().raw_decode(log[start:])
    expected_variants = ['intended', 'request-time', 'transaction-start-time', 'clock-before-lock']
    if expiry.get('passed') is not True or expiry.get('sourcesUnchanged') is not True or [x['variant'] for x in expiry['runs']] != expected_variants or not all(x['expectedResultObserved'] for x in expiry['runs']):
        raise RuntimeError('Expiry verifier did not qualify all intended/mutation runs')
    report['expiryProbe'] = {k:v for k,v in expiry.items() if k!='runs'}
    report['expiryProbe']['runs'] = [{k:v for k,v in x.items() if k!='output'} for x in expiry['runs']]
    save()

    expected=['Full payment schema applied and replayed: 223 migrations','224 cases passed','Witnessed concurrency and retry: 16 cases passed','Original guard and reference mutation controls: 10 expected failures witnessed']
    missing=[x for x in expected if x not in log]
    report['expectedMarkers']=expected; report['missingMarkers']=missing; save()
    if missing: raise RuntimeError(('Missing independent completion markers',missing))
finally:
    try:
        if created: run('drop',['dropdb','-h','127.0.0.1','-p',port,'-U','macpro',db]);report['cleanup']['ownedDatabaseRemoved']=True
    finally:
        if started: run('stop',['pg_ctl','-D',str(cluster),'-m','fast','-w','stop']);report['cleanup']['ownedClusterStopped']=True
        report['sourceHashesUnchanged']=all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in report['sourceSha256'].items())
        report['sourceStillClean']=not bool(subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip())
        report['sourceRevisionUnchanged']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==revision
        report['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat(); save()
if not all(report[k] for k in ['sourceHashesUnchanged','sourceStillClean','sourceRevisionUnchanged']): raise RuntimeError('Qualification sources changed; evidence stale')
